CREATE PROCEDURE [dbo].[usp_ProCobranzaNoBancarizadoCancelarPagosAbonos]
	@IdCobranzaNoBancarizado int,
	@CanceladoPor int,
	@CanceladoEl datetime,
	@IdPeticion varchar(100),
	@MotivoCancelacion varchar(500),
	@CanceladoElSistema datetime,
	@CancelaConContraRecibo int, -- Bandera de cancela con contra recibo 0= cancela normal / 1 = cancela con contra recibo	
	@CancelacionExterna bit,
	@CancelaSAT bit
AS
DECLARE
	@IdCliente int,
	@ImporteClienteDLLS money,
	@ImporteClientePESOS money,
	@IdFacturaCursor int,
	@IdMonedaCursor int,
	@AbonoCursor money,
	@IdContraReciboClienteCursor int,
	@ImporteClienteDLLSContraRecibo money,
	@ImporteClientePESOSContraRecibo money,
	@ImporteCursor money,
	@IdFactura int,
	@IdMoneda int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdCobranzaNoBancarizado,0) <= 0
		RAISERROR(N'El movimiento es un campo requerido',
			16,
			1
			)
	
	IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND (CanceladoEl IS NOT NULL AND @CancelaSAT=0))
		RAISERROR(N'El movimiento fue cancelado por otro usuario',
			16,
			1
			)

	IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranza WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND (CanceladoEl IS NOT NULL AND @CancelaSAT=0))
		RAISERROR(N'Alguno de los movimientos de cobranza fueron cancelados por otro usuario',
			16,
			1
			)

	IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND CAST(Fecha as DATE) > CAST(@CanceladoEl as Date))
		RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de registro.',
			16,
			1
			)

	IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranza WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND CAST(FechaHora as DATE) > CAST(@CanceladoEl as Date))
		RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de registro del movimiento de pago/abono',
			16,
			1
			)		
	----Validar Si el Pago que se Esta Cancelando Genero un saldo a Favor y ese saldo  fAVOR ya SE APLICO
	--IF EXISTS(Select * from ProCobranza Where IsNull(CanceladoEl,0) = 0 And IdCobranzaSaldoAFavor = (Select IdCobranza From ProCobranza Where IdMovimientoBancario = @IdMovimientoBancario And IdConceptoCobranza = 5))
	--	RAISERROR(N'No es posible cancelar el pago, esta ligado a un movimiento de saldo a favor aplicado.',
	--		16,
	--		1
	--		)
	--IF EXISTS(Select IdCobranza From ProCobranza Where IdMovimientoBancario = @IdMovimientoBancario And IdConceptoCobranza = 5 AND (CanceladoEl is not null AND @CancelaSAT=0))
	--	RAISERROR(N'El Saldo a Favor fue cancelado por otro usuario',
	--		16,
	--		1
	--		)
			
	--Se comento esta validación ya que no permite cancelar Pagos y Abonos ligados a contrarecibos. Derivado de la solicitud 7157
	--	IF EXISTS(SELECT pcrcf.IdFactura  FROM ProContraRecibosClienteFacturas AS pcrcf INNER JOIN ProContraRecibosCliente AS pcrc ON pcrc.IdContraReciboCliente = pcrcf.IdContraReciboCliente
	--			INNER JOIN ProCobranza AS pc ON pcrcf.IdFactura = pc.IdFactura INNER JOIN ProMovimientosBancarios AS pmb ON pc.IdMovimientoBancario = pmb.IdMovimientoBancario
	--			where pmb.IdMovimientoBancario = @IdMovimientoBancario and pcrc.CanceladoEl is null and pmb.CanceladoEl is null)				
	--BEGIN
	--	RAISERROR(N'El abono no puede ser cancelado, ya que corresponde a una factura que esta ligada a un contra recibo.',
	--		16,
	--		1
	--		)
	--END		
	
	-- 8553, validar fecha de cancelación no esté dentro de un ejercicio futuro (no existente)
	IF NOT EXISTS(SELECT Ejercicio FROM ProEjerciciosPeriodos WHERE Ejercicio = YEAR(@CanceladoEl)) AND (Select isnull(Valor,0) From SisParametrosValores where Parametro = 'DeshabiltarContabilidadIntegrada')<> 1
		RAISERROR(N'El ejercicio contable no está abierto y por lo tanto no se puede registrar la información, contacte a su contador o al personal encargado de abrir el ejercicio contable',
			16,
			1
			)
	--Se cambia por un cursor debido al pago consolidado ya que se maneja el saldo de varios clientes SOLICITUD 10707
	--SET @IdCliente = (SELECT TOP 1 IdCliente FROM ProCobranza WHERE IdMovimientoBancario = @IdMovimientoBancario)				
			
	UPDATE ProCobranzaNoBancarizado SET 
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		MotivoCancelacion = @MotivoCancelacion --Se agregó el motivo de cancelación dentro del Movimineto Bancario
	WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado	
	
	UPDATE ProCobranza SET
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		CanceladoElSistema = @CanceladoElSistema,
		MotivoCancelacion = @MotivoCancelacion
	WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado	

	IF EXISTS(SELECT FacturaExterna FROM ProFacturas
		INNER JOIN ProCobranza ON ProFacturas.IdFactura = ProCobranza.IdFactura
		WHERE ProCobranza.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND  FacturaExterna= 1 ) AND @CancelacionExterna <> 1
		RAISERROR(N'No se puede Cancelar este pago por que tiene que cancelar una factura externa',
		16,
		1
		)
	
	--Se valida si el movimiento es de un complemento de pago timbrado y si este no tiene fecha de cancelación SAT
	DECLARE @banderaSAT bit = 1
	IF (SELECT FolioFiscalUUID FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado) IS NOT NULL
	BEGIN
		IF (SELECT FechaCancelacionSAT FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado) IS NULL
			SET @banderaSAT = 0
	END	
	
	-- hace el retroceso de saldos tanto en facturas y clientes sólo si es un pago timbrado y cancelado en SAT o si el pago es normal (no 3.3)
	IF @banderaSAT = 1
	BEGIN		
		UPDATE ProFacturas SET
			ProFacturas.Abonos = ISNULL(ProFacturas.Abonos,0) - ProCobranza.Importe - ISNULL((SELECT PC.Importe FROM ProCobranza AS PC WHERE PC.IdFactura = ProCobranza.IdFactura and PC.IdCobranzaOrigen is not null AND PC.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado),0),
			ProFacturas.Estatus = CASE WHEN (ISNULL(ProFacturas.Abonos,0)- ProCobranza.Importe) < ProFacturas.Total THEN 0 ELSE ProFacturas.Estatus END,
			ProFacturas.ModificadoEl = @CanceladoElSistema,
			ProFacturas.ModificadoPor = @CanceladoPor
		FROM ProFacturas
		INNER JOIN ProCobranza ON ProFacturas.IdFactura = ProCobranza.IdFactura
		WHERE ProCobranza.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado

		----Facturas por factoraje
		--DECLARE ProFacturasCursorFactoraje CURSOR FOR
		--SELECT pf.IdFactura FROM ProFacturas pf
		--INNER JOIN ProCobranza pc ON pf.IdFactura = pc.IdFactura
		--INNER JOIN ProCobranzaNoBancarizado pmb ON pc.IdCobranzaNoBancarizado = pmb.IdCobranzaNoBancarizado
		--WHERE pmb.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado	
			
		--OPEN ProFacturasCursorFactoraje
		--FETCH NEXT FROM ProFacturasCursorFactoraje
		--INTO @IdFactura
		--WHILE @@FETCH_STATUS = 0
		--	BEGIN

		--	IF (SELECT Count(pcc.IdFactura) FROM ProCobranza pcc WHERE pcc.CanceladoEl IS NULL 
		--	AND
		--	(pcc.IdConceptoCobranza = (SELECT IdConceptoCobranza FROM CatConceptosCobranza WHERE ConceptoCobranza = 'HONORARIOS' AND DefinidoPorSistema = 1)
		--	OR pcc.IdConceptoCobranza = (SELECT IdConceptoCobranza FROM CatConceptosCobranza WHERE ConceptoCobranza = 'INTERESES' AND DefinidoPorSistema = 1) )
		--	AND pcc.IdFactura = @IdFactura) = 0 
		--	BEGIN
		--		UPDATE
		--		ProFacturas
		--		SET
		--		EsFactoraje = 0
		--		WHERE IdFactura = @IdFactura
		--	END

			
		--FETCH NEXT FROM ProFacturasCursorFactoraje
		--	INTO @IdFactura
		--	END
		--CLOSE ProFacturasCursorFactoraje
		--DEALLOCATE ProFacturasCursorFactoraje
	
	 ------ FIN FACTOJARE

		UPDATE ProFacturasConceptosFacturacion SET
			ProFacturasConceptosFacturacion.Abonos = ISNULL(ProFacturasConceptosFacturacion.Abonos,0) - ProCobranzaFacturaConceptosFacturacion.Importe
		FROM ProFacturasConceptosFacturacion
		INNER JOIN ProCobranzaFacturaConceptosFacturacion ON ProFacturasConceptosFacturacion.IdFacturaConceptoFacturacion = ProCobranzaFacturaConceptosFacturacion.IdFacturaConceptoFacturacion
		INNER JOIN ProCobranza ON ProCobranzaFacturaConceptosFacturacion.IdCobranza = ProCobranza.IdCobranza
		WHERE ProCobranza.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado	
		
		--OBTIENE LOS IMPORTES DE LA FACTURAS PAGADAS PARA ACTULIAZAR SALDO DE CLIENTYE
		
		DECLARE ProFacturasClientesSaldos CURSOR FOR
		SELECT DISTINCT IdCliente FROM ProCobranza WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado
			
		OPEN ProFacturasClientesSaldos
		FETCH NEXT FROM ProFacturasClientesSaldos INTO @IdCliente
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @ImporteClienteDLLS = (SELECT ISNULL(SUM(Importe),0) FROM ProCobranza WHERE IdMoneda = 2 AND IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND IdFactura IS NOT NULL)
			SET @ImporteClientePESOS = (SELECT ISNULL(SUM(Importe),0) FROM ProCobranza WHERE IdMoneda != 2 AND IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND IdFactura IS NOT NULL)	

			UPDATE CatClientes SET 
				SaldoCredito = SaldoCredito + @ImporteClientePESOS,
				SaldoCreditoDLLS = SaldoCreditoDLLS + @ImporteClienteDLLS
			WHERE IdCliente = @IdCliente
			FETCH NEXT FROM ProFacturasClientesSaldos INTO @IdCliente
		END
			
		CLOSE ProFacturasClientesSaldos
		DEALLOCATE ProFacturasClientesSaldos
		
---------inicia seccion para actualizar la informacion de los contrarecibos solicitud 10118
		IF EXISTS(SELECT pcrcf.IdFactura  FROM ProContraRecibosClienteFacturas AS pcrcf INNER JOIN ProContraRecibosCliente AS pcrc ON pcrc.IdContraReciboCliente = pcrcf.IdContraReciboCliente
			INNER JOIN ProCobranza AS pc ON pcrcf.IdCobranza = pc.IdCobranza
			where (pc.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado) and pcrc.CanceladoEl is null)				
		BEGIN
	--Ajustar saldos de los contrarecibos que tienen facturas que ya estaban en un pago/abono antes de ligarse a un contrarecibo solicitud 9304
			DECLARE ProFacturasCursorCR CURSOR LOCAL FOR
				SELECT pcrcf.IdFactura,pc.IdMoneda,pcrc.IdContraReciboCliente FROM ProContraRecibosClienteFacturas AS pcrcf INNER JOIN ProContraRecibosCliente AS pcrc ON pcrc.IdContraReciboCliente = pcrcf.IdContraReciboCliente
				INNER JOIN ProCobranza AS pc ON pcrcf.IdCobranza = pc.IdCobranza
				WHERE (pc.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado)
				and pcrc.CanceladoEl is null 
			OPEN ProFacturasCursorCR
			FETCH NEXT FROM ProFacturasCursorCR INTO @IdFactura,@IdMoneda,@IdContraReciboClienteCursor
			WHILE @@FETCH_STATUS = 0
				BEGIN

				SET @ImporteCursor = (SELECT pc.Importe FROM ProCobranza as pc
									inner join ProFacturas as pf on pc.IdFactura = pf.IdFactura  
									where pf.IdFactura = @IdFactura AND pc.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado)
					
					IF @IdMoneda = 2
					BEGIN
						--UPDATE ProContraRecibosCliente SET TotalDolares = TotalDolares + @ImporteCursor WHERE IdContraReciboCliente = @IdContraReciboClienteCursor
						--UPDATE ProContraRecibosCliente SET TotalSaldoDolares = TotalDolares-TotalAbonoDolares WHERE IdContraReciboCliente = @IdContraReciboClienteCursor
						UPDATE ProContraRecibosCliente SET TotalSaldoDolares = TotalSaldoDolares+@ImporteCursor WHERE IdContraReciboCliente = @IdContraReciboClienteCursor
						--UPDATE ProContraRecibosClienteFacturas SET Importe = Importe + @ImporteCursor WHERE IdContraReciboCliente = @IdContraReciboClienteCursor AND IdFactura = @IdFactura
					END
					ELSE
					BEGIN
						--UPDATE ProContraRecibosCliente SET TotalPesos = TotalPesos + @ImporteCursor WHERE IdContraReciboCliente = @IdContraReciboClienteCursor
						--UPDATE ProContraRecibosCliente SET TotalSaldoPesos = TotalPesos-TotalAbonoPesos WHERE IdContraReciboCliente = @IdContraReciboClienteCursor
						UPDATE ProContraRecibosCliente SET TotalSaldoPesos = TotalSaldoPesos+@ImporteCursor WHERE IdContraReciboCliente = @IdContraReciboClienteCursor
						--UPDATE ProContraRecibosClienteFacturas SET Importe = Importe + @ImporteCursor WHERE IdContraReciboCliente = @IdContraReciboClienteCursor AND IdFactura = @IdFactura
					END
				FETCH NEXT FROM ProFacturasCursorCR INTO @IdFactura,@IdMoneda,@IdContraReciboClienteCursor
				END
			CLOSE ProFacturasCursorCR
			DEALLOCATE ProFacturasCursorCR
		END
--------------Fin de ajuste de contrarecibos que estaban dentro de un pago/abono
		
		
		-- Sección de actualización cancelacion de contra recibo de cliente
		IF @CancelaConContraRecibo = 1
		BEGIN
			DECLARE ProFacturasCursor CURSOR LOCAL FOR
			SELECT ProFacturas.IdFactura, ProFacturas.IdMoneda,ProCobranza.Importe,ProContraRecibosClienteFacturas.IdContraReciboCliente
			FROM  ProCobranza INNER JOIN
							ProContraRecibosClienteFacturas ON ProCobranza.IdCobranza = ProContraRecibosClienteFacturas.IdCobranza INNER JOIN
							ProContraRecibosCliente ON ProContraRecibosClienteFacturas.IdContraReciboCliente = ProContraRecibosCliente.IdContraReciboCliente INNER JOIN
							ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
			WHERE (ProCobranza.IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado) AND (ProContraRecibosCliente.CanceladoEl IS NULL)

			OPEN ProFacturasCursor
			FETCH NEXT FROM ProFacturasCursor
			INTO @IdFacturaCursor,@IdMonedaCursor,@AbonoCursor,@IdContraReciboClienteCursor
			WHILE @@FETCH_STATUS = 0
				BEGIN
				---
					SET @ImporteClienteDLLSContraRecibo = 0
					SET @ImporteClientePESOSContraRecibo = 0  
			       
				    IF @IdMonedaCursor = 2
						SET @ImporteClienteDLLSContraRecibo   = @AbonoCursor
					ELSE
						SET @ImporteClientePESOSContraRecibo  = @AbonoCursor
					
					-- Libera cobranza
					--Se descomento la siguiente linea ya que estaba arrojando un error de Foreign key ,Esto debido a que se estaba tratando de eliminar
					--de la tabla principal ProCobranza el registro ligado con el IdCobranza a la tabla puente ProContraRecibosClienteFacturas
					--Solicitud 008977
					--se comenta linea de codigo, ahora la cobranza se libera al eliminar el movimiento bancario SOLICITUD 010143
					--UPDATE ProContraRecibosClienteFacturas SET IdCobranza = null where IdFactura = @IdFacturaCursor
						
					UPDATE ProContraRecibosCliente 
							SET TotalAbonoDolares = TotalAbonoDolares - @ImporteClienteDLLSContraRecibo 
								,TotalAbonoPesos   = TotalAbonoPesos   - @ImporteClientePESOSContraRecibo
					WHERE ProContraRecibosCliente.IdContraReciboCliente =  	@IdContraReciboClienteCursor
						
					-- Actualizar estatus		
					DECLARE @CantidadFacturas int, @CantidadFacturasPagadas int 
							SET @CantidadFacturas = (Select Count(ProContraRecibosClienteFacturas.IdContraReciboCliente) From ProContraRecibosClienteFacturas
														where IdContraReciboCliente = @IdContraReciboClienteCursor)

							SET @CantidadFacturasPagadas =(SELECT  count(ProFacturas.Estatus)
																FROM  ProContraRecibosClienteFacturas INNER JOIN
																				ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
																WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente =@IdContraReciboClienteCursor and ProFacturas.Estatus = 1))

					IF @CantidadFacturasPagadas > 0 
					IF @CantidadFacturas = @CantidadFacturasPagadas
					BEGIN
						UPDATE ProContraRecibosCliente SET Estatus = 2, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
						WHERE IdContraReciboCliente = @IdContraReciboClienteCursor  -- Pagada
					END
					ELSE
					BEGIN
						UPDATE ProContraRecibosCliente SET Estatus = 1, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
						WHERE IdContraReciboCliente = @IdContraReciboClienteCursor   -- Parcialmente pagada
					--Se agrega seccion para actualizar los saldos del contrarecibo SOLICITUD 10087
					END
					ELSE
					BEGIN
						UPDATE ProContraRecibosCliente SET Estatus = 0, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
						WHERE IdContraReciboCliente = @IdContraReciboClienteCursor    -- Pendiente de pagar
					END
					--Termina actualizar estatus de contrarecibos
					IF @CantidadFacturas  = 0
					begin
						UPDATE ProContraRecibosCliente SET Estatus = 0, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
						WHERE IdContraReciboCliente = @IdContraReciboClienteCursor  -- Pendiente de pagar
					end		
					/*FACTURAS PARCIALES*/
					IF (SELECT  count(ProFacturas.Estatus) FROM  ProContraRecibosClienteFacturas 
						INNER JOIN ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
						WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @IdContraReciboClienteCursor 
						AND EXISTS(SElECT pc.IdCobranza fROM ProCobranza pc WHERE pc.IdCobranza = ProContraRecibosClienteFacturas.IdCobranza 
						And pc.CanceladoEl is null)
						AND ProFacturas.Estatus = 0 AND ProFacturas.Estatus<> 2 )) > 0 
					BEGIN
						UPDATE ProContraRecibosCliente SET Estatus = 1, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
						WHERE IdContraReciboCliente = @IdContraReciboClienteCursor -- Parcialmente pagada
					END		
				-- Fin actualizar estatus de contra recibo de cliente
				---
				FETCH NEXT FROM ProFacturasCursor
				INTO @IdFacturaCursor,@IdMonedaCursor,@AbonoCursor,@IdContraReciboClienteCursor
				END
			CLOSE ProFacturasCursor
			DEALLOCATE ProFacturasCursor	
				
		END
		-- Fin de Sección de actualización cancelacion de contra recibo de cliente		
	END
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

