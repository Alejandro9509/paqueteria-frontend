create PROCEDURE [dbo].[usp_CatTiposIncidenciasEliminar]
@IdTipoIndencia int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdTipoIndencia,0)= 0
	RAISERROR(N'El identificador es un campo requerido',
			16,
			1
			)
			
		DELETE CatTiposIncidencias
		WHERE 	IdTipoIncidencia=@IdTipoIndencia
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

