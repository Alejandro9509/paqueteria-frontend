/* *************************************************************************************************
Script de eliminar naviera para el catálogo de Navieras

Parámetros: 
	@IdNaviera int,	(entrada, entero). Id de Naviera a eliminar
	@IdPeticion varchar(100)	(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento elimina una naviera para el Catálogo de Navieras del módulo Operación Portuaria.

Implementada por: David Rivera Navarro
Fecha de implementación: 09/07/2019
Versión: Versión 8.0.44.15

Modificada por: David Rivera Navarro
Fecha de mofidicación: 08/08/2019
Versión: 8.0.45.08

Invocada desde: PAGE_CatNavierasListado (Solicitud 12874)

Valor de retorno: NA.

Ejemplo de Uso: NA.

***************************************************************************************************** */

CREATE PROCEDURE [dbo].[usp_CatNavierasEliminar]
	@IdNaviera int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	-- Si no se tiene un Id de naviera a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF @IdNaviera = 0
		RAISERROR(N'El identificador de naviera es un campo requerido',
			16,
			1
			)

	/* Se verifica que la naviera se encuentre ligada con algun contenedor, ya que que si se encuentra ligada esta no
	   se eliminará. */
	   IF EXISTS(SELECT TOP 1 * FROM ProDetalleEntregaContenedores WHERE IdNaviera = @IdNaviera)
		RAISERROR(N'Esta Naviera no puede eliminarse porque tiene contenedores asignados. Favor de revisar',
			16,
			1
			)

	-- Se verifica que el registro se encuentre en existencia para control de concurrencia
	IF NOT EXISTS (SELECT Descripcion FROM CatNavieras WHERE IdNaviera = @IdNaviera)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)
				
	DELETE FROM CatNavieras
	WHERE IdNaviera = @IdNaviera
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

