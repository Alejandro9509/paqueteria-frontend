CREATE PROCEDURE [dbo].[usp_ProRecoleccionAgregarPQ](
	@IdSucursal int,
	@IdEmbarque int,
	@IdInforme int,
	@IdGuia int,
	@Fecha varchar(2),
	@Hora varchar(2),
	@FechaRegistro  varchar(80),
	@HoraRegistro  varchar(80),
	@IdEstatusRecoleccion int,
	@Moneda int,
	@TipoCambio float,
	@IdTipoCobro int,

	@NombreRemitente varchar(80),
	@NombreDestinatario varchar(80),
	@RFCRemitente varchar(13),
	@RFCDestinatario varchar(13),
	@DomicilioRemitente varchar(80),

	@DomicilioDestinatario varchar(80),
	@IdCodigoPostalRemitente int,
	@IdCodigoPostalDestinatario int,
	@IdCiudadRemitente int,

	@IdCiudadDestinatario int,
	@CorreoRemitente varchar(80),
	@CorreoDestinatario varchar(80),
	@TelefonoRemitente varchar(13),

	@TelefonoDestinatario varchar(13),
	@ContactoRemitente varchar(80),
	@ContactoDestinatario varchar(80),
	@IdCiudadOrigen int,
	@IdCiudadDestino int,

	@NoPaquetes int,
	@NoSobres int,
	@IdOperador int,
	@IdUnidad int,
	@IdRemolque int,
	@FechaSalida varchar(80),
	@FechaLlegada varchar(80),

	@HoraSalida varchar(80),
	@HoraLlegada varchar(80),
	------- detalle recoleccion---------
	@FechaDetalleRecoleccion varchar(80),
	@HoraDetalleRecoleccion varchar(80),
	@IdCPDetalleRecoleccion int,
	@IdCiudadDetalleRecoleccion int,
	@IdZonaDetalleRecoleccion int,
	@DomicilioDetalleRecoleccion varchar(80),
	@RecogerEnDetalleRecoleccion varchar(80),
	@DatosAdicionalesDetalleRecoleccion varchar(400),
	---------detalle entrega------------
	@IdCPDetalleEntrega int,
	@IdCiudadDetalleEntrega int,
	@IdZonaDetalleEntrega int,
	@DomicilioDetalleEntrega varchar(80),
	@EntregarEnDetalleEntrega varchar(80),
	@DatosAdicionalesDetalleEntrega varchar(400),
	@IdCliente int,
	@RecoleccionDiferenteDomicilio bit,
	@EntregaDiferenteDomicilio bit,
	@IdZonaRemitente int,
	@IdZonaDestinatario int,
	@IdRemitente int,
	@IdDestinatario int,
	@AliasRemitente varchar(100),
	@AliasDestinatario varchar(100),
	@RecoleccionConCita bit,
	@FechaCita varchar(50),
	@HoraCitaMinima varchar(50),
	@HoraCitaMaxima varchar(50),

	@CalleRemitente varchar(100),
	@NoIntRemitente varchar(20),
	@NoExtRemitente varchar(20),
	@ColoniaRemitente varchar(100),
	@CalleDestinatario varchar(100),
	@NoIntDestinatario varchar(20),
	@NoExtDestinatario varchar(20),
	@ColoniaDestinatario varchar(100),
	@Latitud text,
	@Longitud text,
	@IdZonaOperativa int,
	@IdZonaTarifa int,
	@IdEstadoRemitente int,
	@IdEstadoDestinatario int,
	@MunicipioRemitente varchar(50),
	@MunicipioDestinatario varchar(50),
	@IdZonaOperativaEntrega int,
	@IdZonaTarifaEntrega int,
	@IdEstadoRecoleccion int,
	@CodigoMunicipioRecoleccion varchar(100),
	@IdEstadoEntrega int,
	@CodigoMunicipioEntrega varchar(100),
	@ValorDeclarado float,
	@IdSucursalEntrega int,
	@EntregaSucursal bit
	)
	
AS
BEGIN
	BEGIN TRANSACTION
    DECLARE @IdRecoleccion int;
	DECLARE @FOLIO int;
	DECLARE @FOLIOSTR varchar(10);
	DECLARE @FechaDetalleRecoleccionDate date;
	DECLARE @HoraDetalleRecoleccionTime time;
	DECLARE @FechaRegistroDate date;
	DECLARE @HoraRegistroTime time;
	DECLARE @FechaSalidaDate date;
	DECLARE @FechaLlegadaDate date;

	DECLARE @HoraSalidaTime time;
	DECLARE @HoraLlegadaTime time;

	DECLARE @FechaCitaDate date;
	DECLARE @HoraCitaMinimaTime time;
	DECLARE @HoraCitaMaximaTime time;

		IF ISNULL(@NombreRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre de remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NombreDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre de destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdSucursal, 0) <= 0 begin
			RAISERROR(N'*INICIO*El identificador de sucursal es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Fecha, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Hora, '') = '' begin
			RAISERROR(N'*INICIO*La hora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@FechaRegistro, '') = '' begin
			RAISERROR(N'*INICIO*La fecha de registro es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@HoraRegistro, '') = '' begin
			RAISERROR(N'*INICIO*La Hora de registro es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		IF ISNULL(@Moneda, 0) < 0 begin
			RAISERROR(N'*INICIO*El Moneda de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@TipoCambio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdTipoCobro, 0) < 0 begin
			RAISERROR(N'*INICIO*El Identificador de tipo de cobro es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NombreRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@RFCRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El RFC del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@DomicilioRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El Domicilio del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCodigoPostalRemitente, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Codigo del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		/*IF ISNULL(@IdCiudadRemitente, 0) <= 0 begin
			RAISERROR(N'*INICIO*La ciudad del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
		IF ISNULL(@ContactoRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El contacto del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCiudadOrigen, 0) <= 0 begin
			RAISERROR(N'*INICIO*La ciudad origen es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NombreDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El nombre del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@DomicilioDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El domicilio del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCodigoPostalDestinatario, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Codigo postal destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		/*IF ISNULL(@IdCiudadDestinatario, 0) <= 0 begin
			RAISERROR(N'*INICIO*La Ciudad del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
		IF ISNULL(@CorreoDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El correo del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@TelefonoDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El telefono del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@ContactoDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El contacto del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCiudadDestino, 0) <= 0 begin
			RAISERROR(N'*INICIO*La ciudad destino es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoPaquetes, 0) < 0 begin
			RAISERROR(N'*INICIO*El numero de paquetes es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoSobres, 0) < 0 begin
			RAISERROR(N'*INICIO*El numero de sobres es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdOperador, 0) < 0 begin
			RAISERROR(N'*INICIO*El Id de operador es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdUnidad, 0) < 0 begin
			RAISERROR(N'*INICIO*El Id de unidad es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end;
		IF ISNULL(@IdCliente, 0) < 0 begin
			RAISERROR(N'*INICIO*El Responsable de pago es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end;
		EXEC @FOLIO = GenerarSecuenciaPQ @proceso=1;
		select @FOLIOSTR = [dbo].[GeneraFolioPQ](1, @FOLIO);
	
	IF @FechaDetalleRecoleccion IS NOT NULL AND LEN(@FechaDetalleRecoleccion) > 1 begin
	set @FechaDetalleRecoleccionDate = CAST(@FechaDetalleRecoleccion as date)
	set @HoraDetalleRecoleccionTime = CAST(@HoraDetalleRecoleccion as time)
	end

	IF @FechaRegistro IS NOT NULL AND LEN(@FechaRegistro) > 1 begin
	set @FechaRegistroDate = CAST(@FechaRegistro as date)
	set @HoraRegistroTime= CAST(@HoraRegistro as time)
	end

	IF @FechaSalida IS NOT NULL AND LEN(@FechaSalida) > 1 begin
	set @FechaSalidaDate = CAST(@FechaSalida as date)
	set @HoraSalidaTime= CAST(@HoraSalida as time)
	end


	IF @FechaLlegada IS NOT NULL AND LEN(@FechaLlegada) > 1 begin
	set @FechaLlegadaDate= CAST(@FechaLlegada as date)
	set @HoraLlegadaTime= CAST(@HoraLlegada as time)
	end

	IF @FechaCita IS NOT NULL AND LEN(@FechaCita) > 1 begin
		set @FechaCitaDate= CAST(@FechaCita as date)
		set @HoraCitaMinimaTime= CAST(@HoraCitaMinima as time)
		set @HoraCitaMaximaTime= CAST(@HoraCitaMaxima as time)
	end



	

		insert into ProRecoleccionPQ(IdSucursal,FolioRecoleccion,IdEmbarque,IdInforme,IdGuia,Fecha,Hora,IdEstatusRecoleccion,
	Moneda,TipoCambio,IdTipoDecobro,NombreRemitente,NombreDestinatario,RFCRemitente,RFCDestinatario,DomicilioRemitente,
	DomicilioDestinatario,IdCodigoPostalRemitente,IdCodigoPostalDestinatario,IdCiudadRemitente,IdCiudadDestinatario,
	CorreoRemitente,CorreoDestinatario,TelefonoRemitente,TelefonoDestinatario,ContactoRemitente,ContactoDestinatario,
	IdCiudadOrigen,IdCiudadDestino,NoPaquetes,NoSobres,IdOperador,IdUnidad,IdRemolque,FechaSalida,FechaLlegada,HoraSalida, 
	HoraLlegada,FechaDetalleRecoleccion,HoraDetalleRecoleccion,IdCPDetalleRecoleccion,IdCiudadDetalleRecoleccion,IdZonaDetalleRecoleccion,
	DomicilioDetalleRecoleccion,RecogerEnDetalleRecoleccion,DatosAdicionalesDetalleRecoleccion,IdCPDetalleEntrega,IdCiudadDetalleEntrega,
	IdZonaDetalleEntrega,DomicilioDetalleEntrega,EntregarEnDetalleEntrega,DatosAdicionalesDetalleEntrega,FechaRegistro,HoraRegistro, IdCliente, 
	RecoleccionDiferenteDomicilio, EntregaDiferenteDomicilio,IdZonaRemitente, IdZonaDestinatario, IdRemitente, IdDestinatario, AliasRemitente, AliasDestinatario,
	RecoleccionConCita,FechaCita,HoraCitaMinima,HoraCitaMaxima,
	CalleRemitente,NoIntRemitente,NoExtRemitente,ColoniaRemitente,
	CalleDestinatario,NoIntDestinatario,NoExtDestinatario,ColoniaDestinatario, Latitud, Longitud,
			IdZonaOperativa, IdZonaTarifa,IdEstadoRemitente,IdEstadoDestinatario,MunicipioRemitente,MunicipioDestinatario,IdZonaOperativaEntrega,IdZonaTarifaEntrega,IdEstadoRecoleccion,CodigoMunicipioRecoleccion,IdEstadoEntrega,CodigoMunicipioEntrega,ValorDeclarado,IdSucursalEntrega,EntregaSucursal)    
	  VALUES
	  (
	 @IdSucursal,@FOLIOSTR,@IdEmbarque,@IdInforme,@IdGuia,getdate(),CONVERT(TIME, GETDATE()),@IdEstatusRecoleccion,
	@Moneda,@TipoCambio,@IdTipoCobro,@NombreRemitente,@NombreDestinatario,@RFCRemitente,@RFCDestinatario,@DomicilioRemitente,
	@DomicilioDestinatario,@IdCodigoPostalRemitente,@IdCodigoPostalDestinatario,@IdCiudadRemitente,@IdCiudadDestinatario,
	@CorreoRemitente,@CorreoDestinatario,@TelefonoRemitente,@TelefonoDestinatario,@ContactoRemitente,@ContactoDestinatario,
	@IdCiudadOrigen,@IdCiudadDestino,@NoPaquetes,@NoSobres,@IdOperador,@IdUnidad,@IdRemolque,@FechaSalidaDate,@FechaLlegadaDate,@HoraSalidaTime, 
	@HoraLlegadaTime,@FechaDetalleRecoleccionDate,@HoraDetalleRecoleccionTime,@IdCPDetalleRecoleccion,@IdCiudadDetalleRecoleccion,@IdZonaDetalleRecoleccion,
	@DomicilioDetalleRecoleccion,@RecogerEnDetalleRecoleccion,@DatosAdicionalesDetalleRecoleccion,@IdCPDetalleEntrega,@IdCiudadDetalleEntrega,@IdZonaDetalleEntrega,
	@DomicilioDetalleEntrega,@EntregarEnDetalleEntrega,@DatosAdicionalesDetalleEntrega,@FechaRegistroDate,@HoraRegistroTime, @IdCliente, @RecoleccionDiferenteDomicilio, @EntregaDiferenteDomicilio,
	@IdZonaRemitente, @IdZonaDestinatario, @IdRemitente, @IdDestinatario, @AliasRemitente, @AliasDestinatario,
	@RecoleccionConCita,@FechaCitaDate,@HoraCitaMinimaTime,@HoraCitaMaximaTime,
	@CalleRemitente,@NoIntRemitente,@NoExtRemitente,@ColoniaRemitente,
	@CalleDestinatario,@NoIntDestinatario,@NoExtDestinatario,@ColoniaDestinatario,
	 @Latitud, @Longitud,
		 @IdZonaOperativa, @IdZonaTarifa,@IdEstadoRemitente,@IdEstadoDestinatario,@MunicipioRemitente,@MunicipioDestinatario,@IdZonaOperativaEntrega,@IdZonaTarifaEntrega,@IdEstadoRecoleccion,@CodigoMunicipioRecoleccion,@IdEstadoEntrega,@IdEstadoEntrega,@ValorDeclarado,@IdSucursalEntrega,@EntregaSucursal
	  );
	  IF @RecoleccionDiferenteDomicilio = 0 BEGIN
	update CatRemitentesDestinatarios SET Latitud = @Latitud, Longitud = @Longitud Where IdRemitenteDestinatario = @IdRemitente
	END
		--
		--
		IF @@TRANCOUNT > 0
			BEGIN
                SELECT @IdRecoleccion = @@identity;
                UPDATE ProRecoleccionPQ SET Tracking = (SELECT CONCAT('R',ABS(CAST(CAST(NEWID() AS VARBINARY) AS INT)), @IdRecoleccion)) Where IdRecoleccion = @IdRecoleccion;
				COMMIT TRANSACTION
				--SET @id = SCOPE_IDENTITY() ;
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
		--RETURN @id;
end
go

