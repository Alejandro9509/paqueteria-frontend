CREATE TRIGGER [dbo].[trg_SisParametrosRFC]
   ON  dbo.SisParametros
   AFTER UPDATE
AS 
BEGIN
	IF UPDATE(RFC)
			RAISERROR(N'El Campo RFC o RUC no puede ser modificado',
			16,
			1
			)

END
go

