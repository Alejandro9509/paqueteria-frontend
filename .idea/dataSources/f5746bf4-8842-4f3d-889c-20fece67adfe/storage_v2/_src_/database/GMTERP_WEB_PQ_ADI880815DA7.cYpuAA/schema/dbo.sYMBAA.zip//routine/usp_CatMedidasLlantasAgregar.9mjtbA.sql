create PROCEDURE [dbo].[usp_CatMedidasLlantasAgregar]
@Codigo	int,	
@DescripcionMedida	varchar(50),	
@Activo bit,    
@CreadoEl    datetime,    
@CreadoPor    int,    
@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION
 
   	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de medida de llanta es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatMedidasLlantas WHERE Codigo = @Codigo )
		RAISERROR(N'El código de medida de llanta ya existe',
			16,
			1
			)	
				
	IF ISNULL(@DescripcionMedida,'')= ''
		RAISERROR(N'El descripción de medida de llanta es un campo requerido',
			16,
			1
			)
			
	-- agrega un nuevo motivo de desechar llanta		
    INSERT INTO CatMedidasLlantas (Codigo,DescripcionMedida,Activo,CreadoEl,CreadoPor)
    VALUES(@Codigo,@DescripcionMedida,@Activo,@CreadoEl,@CreadoPor)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

