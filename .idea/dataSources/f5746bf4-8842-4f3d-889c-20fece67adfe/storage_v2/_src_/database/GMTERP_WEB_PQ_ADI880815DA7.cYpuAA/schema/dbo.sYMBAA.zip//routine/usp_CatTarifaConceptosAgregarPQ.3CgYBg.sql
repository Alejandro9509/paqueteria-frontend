	CREATE PROCEDURE [dbo].[usp_CatTarifaConceptosAgregarPQ](
	@IdTarifa int,
	@IdConceptoFacturacion int,
	@Importe money,
    @IdImpuestoTraslada int,
    @ImporteIva money,
    @IdImpuestoRetiene int,
    @ImporteRetiene money,
	@IdTipoCalculo int,
	@RangoMinimo float,
	@RangoMaximo float,
	@IdAgregadoDesde int,
	@IdTipoMedida int)
	 
AS
BEGIN
	
	BEGIN TRANSACTION
--BEGIN TRY
		IF ISNULL(@IdTarifa, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tarifa es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdConceptoFacturacion, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Concepto de Facturacion es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@Importe, 0) < 0 begin
			RAISERROR(N'*INICIO*El Importe es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@ImporteIva, 0) < 0 begin
			RAISERROR(N'*INICIO*El Importe de IVA es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@ImporteRetiene, 0) < 0 begin
			RAISERROR(N'*INICIO*El Importe de Retencion es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdImpuestoTraslada, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de impuesto de traslado es un campo requerido*FIN*', 16, 1);
			return;
			end
		 IF ISNULL(@IdImpuestoRetiene, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de impuesto de retencion es un campo requerido*FIN*', 16, 1);
			return;
			end
 			
		INSERT INTO CatTarifaConceptosPQ(
		IdTarifa ,
		IdConceptoFacturacion,
		Importe,
		IdImpuestoTraslada,
		ImporteIva,
		IdImpuestoRetiene,
		ImporteRetiene,
		IdTipoCalculo,
		RangoMinimo,
		RangoMaximo,
		IdAgregadoDesde,
		IdTipoMedida)
		VALUES (
		@IdTarifa ,
		@IdConceptoFacturacion,
		@Importe,
		@IdImpuestoTraslada,
		@ImporteIva,
		@IdImpuestoRetiene,
		@ImporteRetiene,
		@IdTipoCalculo,
		@RangoMinimo,
		@RangoMaximo,
		@IdAgregadoDesde,
		@IdTipoMedida)
	
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

