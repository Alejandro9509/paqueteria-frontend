
CREATE PROCEDURE [dbo].[usp_CatTipoServicioModificarPQ](
	@IdTipoServicio int,
	@Descripcion varchar(50),
	@Costo Money,
	@DiasHabiles int,	
	@Activo bit,
	
	@ModificadoEl Datetime,
	@ModificadoPor int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'La Descripción es un campo requerido', 16, 1)
			return;
		end
		IF ISNULL(@Costo, 0) <= 0 begin
			RAISERROR(N'El costo es un campo requerido', 16, 1);
			return;
		end
		
		IF ISNULL(@DiasHabiles, 0) <= 0 begin
			RAISERROR(N'La cantidad de dias habiles es un campo requerido', 16, 1);
			return;
		end
		
		update CatTipoServicio set Descripcion = @Descripcion,
		Costo = @Costo,
		DiasHabiles = @DiasHabiles,
		Activo = @Activo,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
		where IdTipoServicio = @IdTipoServicio;
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
end
go

