CREATE PROCEDURE [dbo].[usp_ProFacturasAsignarFechaProgramadaDePago]
	@IdFactura int,	
	@FechaProgPago datetime,	
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,	
	@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION		

	IF @IdFactura = 0
		RAISERROR(N'El identificador de la factura es un campo requerido',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM ProFacturas WHERE IdFactura = @IdFactura) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
	IF ISDATE(@FechaProgPago) = 0			
		RAISERROR(N'La fecha programada de pago es un campo requerido',
			16,
			1
			)
			
	--IF (SELECT ISNULL(Abonos,0) FROM ProFacturas WHERE IdFactura = @IdFactura) <> 0
	--	RAISERROR(N'No puede ser modificada esta factura porque tiene abonos',
	--		16,
	--		1
	--		)

	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 1--pagada
		RAISERROR(N'No puede ser modificada esta factura porque está pagada',
			16,
			1
			)
			
	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 2--cancelada
		RAISERROR(N'No puede ser modificada esta factura porque está cancelada',
			16,
			1
			)
	IF @FechaProgPago < (SELECT Isnull(DATEADD(dd, 0, DATEDIFF(dd, 0, FechaHora)),0) FROM ProFacturas Where IdFactura = @IdFactura)
		RAISERROR(N'La fecha programada de pago no puede ser menor a la de la factura',
			16,
			1
			)
	IF (SELECT FacturaExterna FROM ProFacturas WHERE IdFactura = @IdFactura) = 1 
			RAISERROR(N'No se puede ser modificada esta facura por que es externa',
			16,
			1
			)							
	
	--If @IdFormatoImpresion = 0
	--	SET @IdFormatoImpresion = NULL
	
	UPDATE ProFacturas SET		
		FechaProgPago = @FechaProgPago,		
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdFactura = @IdFactura		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

