CREATE PROCEDURE [dbo].[usp_ProRecoleccionAgregarPaquetePQ](
	@IdRecolccion int,
	@Cantidad int,
	@Descripcion varchar(500) ,
	@Peso float,
	@Largo float,
	@Ancho float,
	@Alto float,
	@Volumen float,
	@IdTipoEmbalaje int,
	@ValorDeclarado money,
	@Observaciones varchar(500),
	@IdProducto int,
	@IdTipo int,
	@ClaveSATProducto text,
	@ClaveSATUnidad text,
    @ClaveEmbalaje text
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdRecolccion, 0) = 0 begin
			RAISERROR(N'El Identificaodr de Recoleccion es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		/*IF ISNULL(@Cantidad, 0) = 0 begin
			RAISERROR(N'El Tipo es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'La descripcion es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
	
		IF ISNULL(@Peso, 0) = 0 begin
			RAISERROR(N'El Peso es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Largo, 0) = 0 begin
			RAISERROR(N'El Largo es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Ancho, 0) = 0 begin
			RAISERROR(N'El Ancho es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Alto, 0) = 0 begin
			RAISERROR(N'*INICIO*El Ancho es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Volumen, 0) = 0 begin
			RAISERROR(N'*INICIO*El Volumen es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdTipoEmbalaje, 0) = 0 begin
			RAISERROR(N'El Tipo de Embalaje es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
		/*IF ISNULL(@ValorDeclarado, 0) = 0 begin
			RAISERROR(N'El Valor declarado es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
	end
		
		Insert into dbo.ProRecoleccionPaquetePQ(IdRecoleccion,Cantidad,Descripcion,Peso,
			Largo,Ancho,Alto,Volumen,IdTipoEmbalaje,ValorDeclarado,Observaciones,IdProducto, IdTipo,ClaveSATProducto,ClaveSATUnidad, ClaveEmbalaje)
		
		Values (@IdRecolccion,@Cantidad,@Descripcion,@Peso,
			@Largo,@Ancho,@Alto,@Volumen,@IdTipoEmbalaje,@ValorDeclarado,@Observaciones, @IdProducto, @IdTipo,@ClaveSATProducto,@ClaveSATUnidad, @ClaveEmbalaje);
		
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
go

