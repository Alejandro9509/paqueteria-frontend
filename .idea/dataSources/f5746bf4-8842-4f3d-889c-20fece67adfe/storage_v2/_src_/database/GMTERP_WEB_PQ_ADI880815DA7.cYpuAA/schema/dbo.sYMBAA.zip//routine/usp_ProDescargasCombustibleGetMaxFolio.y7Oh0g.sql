CREATE PROCEDURE [dbo].[usp_ProDescargasCombustibleGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProDescargasCombustible
go

