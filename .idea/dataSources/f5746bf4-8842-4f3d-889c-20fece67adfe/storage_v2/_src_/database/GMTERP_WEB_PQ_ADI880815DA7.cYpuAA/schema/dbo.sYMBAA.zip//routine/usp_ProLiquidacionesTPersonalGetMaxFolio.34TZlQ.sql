
CREATE PROCEDURE [dbo].[usp_ProLiquidacionesTPersonalGetMaxFolio]
AS
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProLiquidacionesTPersonal
go

