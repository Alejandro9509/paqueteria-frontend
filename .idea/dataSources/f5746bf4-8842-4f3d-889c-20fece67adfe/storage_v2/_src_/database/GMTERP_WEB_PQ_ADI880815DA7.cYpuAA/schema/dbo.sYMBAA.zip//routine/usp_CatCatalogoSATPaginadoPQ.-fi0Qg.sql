CREATE PROCEDURE [dbo].[usp_CatCatalogoSATPaginadoPQ]
    @busqueda varchar(max),
    @catalogo varchar(max),
    @pagina int,
    @cantidadRegistros int
AS
BEGIN
    DECLARE @skipReg int = @pagina * @cantidadRegistros

    select ClaveSAT as m_sClaveSAT, Descripcion as m_sDescripcion, CatalogoSAT as m_sCatalogoSAT, MaterialPeligroso as m_bMaterialPeligroso from CatGeneralesSAT where CatalogoSAT = @catalogo and (@busqueda is NULL OR  (ClaveSAT LIKE '%' + UPPER(@busqueda)  + '%' or Descripcion LIKE '%' +  UPPER(@busqueda)  + '%'))
       ORDER BY ClaveSAT
    OFFSET @skipReg ROWS
        FETCH NEXT @cantidadRegistros ROWS ONLY

END
go

