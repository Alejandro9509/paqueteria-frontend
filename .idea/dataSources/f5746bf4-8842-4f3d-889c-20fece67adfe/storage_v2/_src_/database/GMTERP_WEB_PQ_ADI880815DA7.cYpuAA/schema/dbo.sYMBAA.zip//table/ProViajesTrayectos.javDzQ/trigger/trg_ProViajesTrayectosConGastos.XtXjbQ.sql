CREATE TRIGGER [dbo].[trg_ProViajesTrayectosConGastos]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE
AS
BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
		WHERE (upper(I.CodigoUnidadCamion) <> upper(D.CodigoUnidadCamion) OR 
		I.IdDestino <> D.IdDestino OR 
		I.IdOperador <> D.IdOperador OR 
		I.IdOrigen <> D.IdOrigen OR 
		I.IdUnidadCamion <> D.IdUnidadCamion OR 
		I.NombreOperador <> D.NombreOperador OR 
		UPPER(I.PlacasUnidadCamion) <> UPPER(D.PlacasUnidadCamion)) AND EXISTS(SELECT IdGastoViaje FROM ProGastosViaje WHERE IdViajeTrayecto = I.IdViajeTrayecto And IdUnidad = D.IdUnidadCamion))
		RAISERROR(N'No puede modificarse el viaje trayecto porque ya tiene gastos registrados',
			16,
			1
			)
END
go

