

CREATE PROCEDURE [dbo].[usp_ProInformeAgregarPQ](	
	@FolioInforme varchar(10) ,
	@Fecha date,
	@Hora time,
	@IdEstatusInforme int,	
	@IdViaje int,
	@IdSucursalEmisora int,
	@IdSucursalReceptora int,
	@IdOperador int,
	@IdDolly int,
	@IdRemolque1 int,
	@IdRemolque2 int,
	@PlacasRemolque1 varchar(15),
	@PlacasRemolque2 varchar(15),
	@PlacasDolly varchar(15),
	@IdCiudadOrigen int,
	@IdCiudadDestino int,
	@IdRuta int,
	@FechaCancelacion datetime,	
	@TotalxCDestinatario money,
	@TotalxCRemitente money,
	@TotalPagoMostrador money,
	@TotalUnidadCompleta money,
	@TotalGeneral money,
	@IdUnidad int
	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @IdGuia int;
		declare @FOLIO int;
		declare @FOLIOSTR varchar(10);

		IF ISNULL(@Fecha, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Hora, '') = '' begin
			RAISERROR(N'*INICIO*La hora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdEstatusInforme, '') = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus del Informe es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdSucursalEmisora, 0) = 0 begin
			RAISERROR(N'*INICIO*La sucursal emisora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdSucursalReceptora, 0) = 0 begin
			RAISERROR(N'*INICIO*La sucursal receptora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
	
		IF ISNULL(@IdRemolque1, 0) = 0 begin
			RAISERROR(N'*INICIO*El remolque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		IF ISNULL(@IdCiudadOrigen, 0) = 0 begin
			RAISERROR(N'*INICIO*La ciudad origen es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCiudadDestino, 0) = 0 begin
			RAISERROR(N'*INICIO*La ciudad destino es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
	
		/*IF ISNULL(@IdRuta, 0) = 0 begin
			RAISERROR(N'*INICIO*La ruta es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/


		EXEC @FOLIO = GenerarSecuenciaPQ @proceso=4;
		--	RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*' ,  -1, 1,@FOLIO )
		
		select @FOLIOSTR = [dbo].[GeneraFolioPQ](2, @FOLIO);

		insert into dbo.ProInformePQ(FolioInforme,Fecha,Hora,IdEstatusInforme,
		IdViaje,IdSucursalEmisora,IdSucursalReceptora,IdOperador,IdDolly,IdRemolque1,IdRemolque2,PlacasDolly,PlacasRemolque1,PlacasRemolque2,IdCiudadDestino,
		IdCiudadOrigen,FechaCancelacion,IdUnidad)

	  VALUES 
	  (@FOLIOSTR,@Fecha,@Hora,@IdEstatusInforme,
	  @IdViaje,@IdSucursalEmisora,@IdSucursalReceptora,@IdOperador,@IdDolly,@IdRemolque1,@IdRemolque2 ,@PlacasDolly,@PlacasRemolque1,@PlacasRemolque2,@IdCiudadDestino,
	@IdCiudadOrigen,@FechaCancelacion,@IdUnidad);

	insert into dbo.ProInformeDetallePQ (TotalxCDestinatario,TotalxCRemitente,TotalPagoMostrador,TotalUnidadCom,TotalGeneral,IdInforme)
	VALUES(@TotalxCDestinatario,@TotalxCRemitente,@TotalPagoMostrador,@TotalUnidadCompleta,@TotalGeneral,@@IDENTITY)

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

