CREATE PROCEDURE [dbo].[usp_CatTiposAcumuladosAgregar]	  
	@Nombre varchar(40),
	@TipoMovtoAcumulado int,
	@CreadoEl    datetime,    
	@CreadoPor    int,    
	@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION
        
	IF RTRIM(LTRIM(@Nombre)) = ''
		RAISERROR(N'El Nombre es un campo requerido',
			16,
			1
			)	        
    
  	IF EXISTS(SELECT Nombre FROM CatTiposAcumulados WHERE Nombre = @Nombre)
		RAISERROR(N'El Nombre ya existe',
			16,
			1
			)                            
   
	INSERT INTO CatTiposAcumulados(Nombre,TipoMovtoAcumulado,CreadoEl,CreadoPor)
	     VALUES(@Nombre,@TipoMovtoAcumulado,@CreadoEl,@CreadoPor)
  
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

