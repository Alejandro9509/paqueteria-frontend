CREATE PROCEDURE [dbo].[usp_CatRemitentesDestinatariosPaginadoPQ]
@pagina int,
@cantidadRegistros int,
@busqueda varchar(max)
AS
BEGIN
DECLARE @skipReg int = @pagina * @cantidadRegistros

SELECT
crd.IdRemitenteDestinatario as m_nIdRemitenteDestinatario,
crd.Numero as m_nNumero,
crd.RFC as m_sRFC,
crd.Nombre as m_sNombre,
crd.CorreoElectronico as m_sCorreoElectronico,
crd.Telefono as m_sTelefono,
crd.Contacto as m_sContacto,
(select top 1 cp.IdCodigoPostal from CatCodigosPostales cp where cp.CodigoPostal = crd.CodigoPostal and cp.IdEstado = crd.IdEstado) as m_nIdCP,
(SELECT DISTINCT top 1  CodigoMunicipio FROM CatCodigosPostales WHERE IdEstado = crd.IdEstado and (UPPER(Municipio) = crd.Municipio COLLATE Latin1_general_CI_AI or cast(    replace((        replace(UPPER(Municipio) collate Latin1_General_CS_AS, 'Œ' collate Latin1_General_CS_AS, 'OE' collate Latin1_General_CS_AS)     ) collate Latin1_General_CS_AS, 'œ' collate Latin1_General_CS_AS, 'oe' collate Latin1_General_CS_AS) as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS = cast(    replace((        replace(crd.Municipio collate Latin1_General_CS_AS, 'Œ' collate Latin1_General_CS_AS, 'OE' collate Latin1_General_CS_AS)     ) collate Latin1_General_CS_AS, 'œ' collate Latin1_General_CS_AS, 'oe' collate Latin1_General_CS_AS) as varchar(max)) collate SQL_Latin1_General_Cp1251_CS_AS )) AS m_nIdMunicipio,
crd.Municipio as m_sMunicipio,
crd.Localidad as m_sLocalidad,
crd.Colonia as m_sColonia,
crd.Calle as m_sCalle,
crd.NoExterior as m_sNoExterior,
crd.NoInterior as m_sNoInterior,
cc.NumeroCliente as m_nNumeroCliente,
cc.NombreFiscal as m_sNombreFiscal,
crd.Activo as m_bActivo,
crd.IdEstado as m_nIdEstado,
COALESCE(crd.Alias, '') as m_sAlias,
ce.Estado as m_sEstado,
COALESCE(crd.Latitud, '') as m_sLatitud,
COALESCE(crd.Longitud, '') as m_sLongitud,
crd.CodigoPostal as m_sCodigoPostal,
(crd.Calle + '' + crd.NoExterior + ', ' + crd.Colonia) as m_sDomicilio
FROM CatRemitentesDestinatarios crd left join CatClientes cc on crd.IdCliente= cc.IdCliente inner join CatEstados ce on ce.IdEstado= crd.IdEstado
where (@busqueda is NULL OR  (crd.Nombre LIKE '%' + UPPER(@busqueda)  + '%' or crd.Calle LIKE '%' +  UPPER(@busqueda)  + '%'))
ORDER BY crd.IdRemitenteDestinatario
OFFSET @skipReg ROWS
FETCH NEXT @cantidadRegistros ROWS ONLY

END
go

