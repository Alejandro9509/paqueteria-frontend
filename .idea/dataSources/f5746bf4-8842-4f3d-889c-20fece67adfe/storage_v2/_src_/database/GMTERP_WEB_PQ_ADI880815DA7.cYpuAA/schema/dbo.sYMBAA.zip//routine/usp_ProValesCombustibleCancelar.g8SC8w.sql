CREATE PROCEDURE [dbo].[usp_ProValesCombustibleCancelar]
	@IdValeCombustible int,
	@MotivoCancelacion varchar(500),
	@CanceladoEl datetime,
	@CanceladoPor int,
	@IdPeticion varchar(100)
AS
/* *************************************************************************************************
Modificada por: Ricardo Sinai Miranda Pantoja 
Fecha de modificacion: 16/06/2020
Solicitud: 2,438
Descripción: Se modificó la validación de los vales agregándole como condición extra que el vale
	no haya sido generado desde viajes y se actualiza el campo GeneradoDesdeViaje a 0.
Invocado desde: usp_ProViajesAgregar, usp_ProViajesModificar
************************************************************************************************ */
DECLARE
@IdViajeTrayecto int
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdValeCombustible = 0
		RAISERROR(N'El identificador del vale de combustible es un campo requerido',
			16,
			1
			)

	IF (SELECT Fecha FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible) > @CanceladoEl
		RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de elaboración',
			16,
			1
			)
					
	IF (SELECT CanceladoEl FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible) IS NOT NULL --cancelado
		RAISERROR(N'No puede cancelar este vale porque está cancelado',
			16,
			1
			)			

	IF (SELECT IdGastoViaje FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible) IS NOT NULL --se referencio a un gasto de viaje
		RAISERROR(N'No puede cancelar este vale porque está ligado a un gasto de viaje',
			16,
			1
			)			

	IF LTRIM(RTRIM(@MotivoCancelacion)) = ''
		RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)
		
	IF ISDATE(@CanceladoEl) = 0
		RAISERROR(N'La fecha de cancelación es un campo requerido',
			16,
			1
			)

	SET @IdViajeTrayecto = (SELECT IdViajeTrayecto FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible)

	--si la liquidacion tiene fecha de cierre se genera un error
	-- SOL. 9103, se agrega validación para NO cancelar vales si el viaje ligado está liquidado (cerrado) y el vale no esté ligado a un gasto	
	IF EXISTS(SELECT pl.IdLiquidacion FROM ProLiquidaciones AS pl INNER JOIN ProViajesTrayectos AS pvt ON pl.IdLiquidacion = pvt.IdLiquidacion WHERE pvt.IdViajeTrayecto = @IdViajeTrayecto AND pl.CerradaEl IS NOT NULL) AND (SELECT IdGastoViaje FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible) IS NOT NULL
		RAISERROR(N'No es posible cancelar el vale de combustible porque la liquidación del viaje está cerrada',
			16,
			1
			)
								
	UPDATE ProValesCombustible SET
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		MotivoCancelacion = @MotivoCancelacion,
		CanceladoElSistema = GETDATE(),
		IdViajeTrayecto = NULL,
		GeneradoDesdeViaje = 0
	WHERE IdValeCombustible = @IdValeCombustible
	
	Update ProViajesTrayectos Set AplicarValeDeCombustible = NULL,
			LitrosAutorizados = NULL
	Where IdViajeTrayecto = @IdViajeTrayecto
																	
	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

