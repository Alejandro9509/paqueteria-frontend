

CREATE PROCEDURE [dbo].[usp_CatTipoServicioAgregarPQ](
	@Descripcion varchar(50),
	@Costo Money,
	@DiasHabiles int,	
	@Activo bit,
	@CreadoEl Datetime,
	@CreadoPor int, 
	@ModificadoEl Datetime,
	@ModificadoPor int)
AS
BEGIN
	SET XACT_ABORT ON;
	BEGIN TRANSACTION
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La Descripción es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Costo, 0) <= 0 begin
			RAISERROR(N'*INICIO*El costo es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION

			return;
		end
		
		IF ISNULL(@DiasHabiles, 0) <= 0 begin
			RAISERROR(N'*INICIO*La cantidad de dias habiles es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION

			return;
		end
		
		INSERT INTO CatTipoServicio (Descripcion,Costo,Diashabiles,CreadoEl,CreadoPor,ModificadoEl,ModificadoPor,Activo)
		VALUES (@Descripcion, @Costo,@DiasHabiles,@CreadoEl, @CreadoPor,@ModificadoEl,@ModificadoPor,@Activo);
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN
			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN

			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END

end

SELECT * FROM DBO.CATTIPOSERVICIO
go

