create PROCEDURE [dbo].[usp_ProPasivosContraRecibosGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProPasivosContraRecibos
go

