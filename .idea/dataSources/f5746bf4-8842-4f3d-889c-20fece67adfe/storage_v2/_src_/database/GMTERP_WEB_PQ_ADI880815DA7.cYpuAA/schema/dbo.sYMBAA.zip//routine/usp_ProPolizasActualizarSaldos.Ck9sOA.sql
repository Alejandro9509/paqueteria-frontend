
create PROCEDURE [dbo].[usp_ProPolizasActualizarSaldos]
@IdPeticion varchar(100),
@IdPoliza int,
@Condicionquery nvarchar(max) = '',
@Proceso int = 0
AS
DECLARE 
@IdCuentaContableCursor int, 
@ImporteCursor money,
@ImporteMonedaExtranjeraCursor money,
@TipoMovimientoCursor int,
@Ejercicio int,
@Periodo int,
@DeclaracionDinamica nvarchar(max) = ''

/*
Este procedure se hizo ya que no se pudo implementar un trigger para actualizar los saldos de las cuentas contables al eliminar una poliza
ya que ProPolizas elimina en cascada y las eliminaciones en cascada ocurren primero 
y solo luego se ejecutan los trigger, pero las tablas inserted/deleted se sobrescriben y ya no son accesibles.
PARÁMETROS:
	@IdPeticion:					Sesion del usuario
	@IdPoliza:						Poliza
	@Condicionquery:				Condicion para obtener la poliza y los asientos contables relacionados 
	@Proceso:						Proceso para CatCuentasContablesActualizarSaldos 1:Registrar 0:Retirar

	@IdCuentaContableCursor:		Asiento contable (Cuenta contable)
	@ImporteCursor:					Importe del asiento contable
	@ImporteMonedaExtranjeraCursor: Importe del asiento contable moneda extranjera
	@TipoMovimientoCursor:			Tipo de movimiento
	@Ejercicio:						Año
	@Periodo:						Mes
	@DeclaracionDinamica:			Genera el cursor y su contenido.
IMPLEMENTADA POR:
	Abril CG
FECHA DE IMPLEMENTACIÓN:
	2019-09-20
VERSIÓN:
	
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-20
INVOCADA DESDE:
	usp_ProPolizasEliminar
	usp_ProFacturasEliminar
	usp_ProMovimientosBancariosEliminar
	usp_ProChequesEliminar
	usp_ProMovimientosBancariosTraspasosEliminar
	usp_ProPasivosDescancelar
	usp_ProReposicionesEliminar
	usp_ProPagosProveedoresDocumentosEliminar
	usp_ProChequesCancelar
	usp_ProMovimientosBancariosCancelar
	usp_ProLiquidacionesAbrir
	usp_ProPolizasTraspasosAuxiliar
SOLICITUD: 
	SOLICITUD 000266
*/
BEGIN TRY
	/*CCCS: ProPolizas*/
	SAVE TRAN Tran_PPActualizarSaldos

	SET @DeclaracionDinamica = '
	DECLARE CursorProPolizasActualizarSaldos CURSOR FOR 
	SELECT
	ppcc.IdCuentaContable,ppcc.Importe,ppcc.ImporteMonedaExtranjera,ppcc.TipoMovimiento,pp.Ejercicio,pp.Periodo,ppcc.IdPoliza
	FROM 
	ProPolizas pp
	INNER JOIN ProPolizasCuentasContables ppcc ON pp.IdPoliza = ppcc.IdPoliza
	WHERE '+@Condicionquery
		/*Cursor*/
		
	EXEC sp_executesql @DeclaracionDinamica

	OPEN CursorProPolizasActualizarSaldos
	FETCH NEXT FROM CursorProPolizasActualizarSaldos 
	INTO 
		@IdCuentaContableCursor, @ImporteCursor,@ImporteMonedaExtranjeraCursor,@TipoMovimientoCursor,@Ejercicio,@Periodo,@IdPoliza
	WHILE @@fetch_status = 0
	BEGIN

		EXEC usp_CatCuentasContablesSaldosActualizarSaldos @IdPeticion,@IdPoliza,@IdCuentaContableCursor,@ImporteCursor,@ImporteMonedaExtranjeraCursor,@Ejercicio,@Periodo,@TipoMovimientoCursor,@Proceso
		
		FETCH NEXT FROM CursorProPolizasActualizarSaldos 
		INTO 
		@IdCuentaContableCursor, @ImporteCursor,@ImporteMonedaExtranjeraCursor,@TipoMovimientoCursor,@Ejercicio,@Periodo,@IdPoliza
	END
	CLOSE CursorProPolizasActualizarSaldos
	DEALLOCATE CursorProPolizasActualizarSaldos

END TRY
BEGIN CATCH
	IF (XACT_STATE()) = -1
	BEGIN
		 IF (SELECT CURSOR_STATUS('global','CursorProPolizasActualizarSaldos')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('global','CursorProPolizasActualizarSaldos')) > -1
			BEGIN
				CLOSE CursorProPolizasActualizarSaldos
			END
		DEALLOCATE CursorProPolizasActualizarSaldos
		END

		ROLLBACK TRAN Tran_PPActualizarSaldos
		/*Se guarda el error En SisErrors, pero sin unsar el usp_SisErrorsGrabar, ya que no es necesario que el usuario se entere de un error interno 
		para actualizar saldos. Si no cuadran los saldos, se va a aplicar la utileria de auditoria*/
		--EXECUTE usp_SisErrorsGrabar @IdPeticion
		DECLARE 
		@ErrorNumber int = ERROR_NUMBER(),
		@ErrorSeverity int = ERROR_SEVERITY(),
		@ErrorState int = ERROR_STATE(),
		@ErrorLine int = ERROR_LINE(),
		@ErrorProcedure nvarchar(4000) = ERROR_PROCEDURE(),
		@ErrorMessage nvarchar(4000) = ERROR_MESSAGE()
		INSERT INTO SisErrors(ErrorNumber,ErrorSeverity,ErrorState,ErrorLine,ErrorProcedure,ErrorMessage,IdPeticion,FechaHora)
		VALUES(@ErrorNumber,@ErrorSeverity,@ErrorState,@ErrorLine,@ErrorProcedure,@ErrorMessage,@IdPeticion,GETDATE())
	END
END CATCH
go

