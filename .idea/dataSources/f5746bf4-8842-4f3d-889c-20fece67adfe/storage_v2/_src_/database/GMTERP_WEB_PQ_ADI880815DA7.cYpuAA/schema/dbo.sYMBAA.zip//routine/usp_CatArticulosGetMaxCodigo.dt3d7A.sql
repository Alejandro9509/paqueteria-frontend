
CREATE PROCEDURE [dbo].[usp_CatArticulosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatArticulos
go

