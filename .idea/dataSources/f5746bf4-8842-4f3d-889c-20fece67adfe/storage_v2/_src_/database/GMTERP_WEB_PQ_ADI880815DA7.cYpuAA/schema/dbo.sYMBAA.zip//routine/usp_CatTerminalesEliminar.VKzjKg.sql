/* *************************************************************************************************
Script de eliminar terminal para el catálogo de Terminales

Parámetros: 
	@IdTerminal int,			(entrada, entero). Id de Terminal a eliminar
	@IdPeticion varchar(100)	(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento elimina un estatus para el Catálogo de Terminales del módulo Operación Portuaria.

02/01/2020 - Se agrego validación para que no permita borrar la terminal si cuenta con una orden de entrega ligada

Implementada por: David Rivera Navarro
Fecha de implementación: 10/07/2019
Versión: Versión 8.0.44.22

Modificada por: Jesús Humberto Morales Mojica
Fecha de mofidicación: 02/01/2020
Versión: 8.0.48.58

Invocada desde: PAGE_CatTerminalesListado (Solicitud 12815)

***************************************************************************************************** */

CREATE PROCEDURE [dbo].[usp_CatTerminalesEliminar]
	@IdTerminal int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	-- Si no se tiene un Id de terminal a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF @IdTerminal = 0
		RAISERROR(N'El identificador de terminal es un campo requerido', 16, 1)	

	-- Si la terminal ya esta ligada una Orden de Entrega no dejara eliminarla
	IF EXISTS (SELECT TOP 1 * FROM ProOrdenEntregaContenedor WHERE IdTerminal = @IdTerminal)
		RAISERROR(N'La Terminal Portuaria tiene Ordenes de Entrega ligada, no es posible eliminarla.', 16, 1)	
				
	DELETE FROM CatTerminales
	WHERE IdTerminal = @IdTerminal
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

