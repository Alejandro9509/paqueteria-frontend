CREATE PROCEDURE [dbo].[usp_ProModificacionVariables]
	@IdEmpleado INT,
	@FechaInicio DATE,
	@FechaFinal DATE,
	@ConceptosPDO NVARCHAR(MAX),
	@HeadersPeriodo NVARCHAR(MAX),
	@IdTipoPeriodo INT

/* *************************************************************************************************
Procedimiento usp_ProModificacionVariables

Parámetros: 
    @IdEmpleado			            (entrada, entero)  Identificador del empleado
    @FechaInicio					(entrada, date)	   Identificador de la fecha de inicio del periodo de busqueda
    @FechaFinal						(entrada, date)    Identificador de la fecha final del periodo de busqueda
    @conceptosPDO					(entrada, varchar) Identificador de las clave PDO del empleado
	@IdTipoPeriodo					(entrada, entero)  Identificador del Tipo de Periodo del Recibo de Nomina	
    

Descripción: El procedimiento regresa la coleccion de IdconceptosPDO del emlpleado en los periodos del bimestre

26/09/2019   Se realizo optimizacion del query para poder obtener toda la informacion en una sola consulta	 

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 27/09/2019
Versión ERP: 8.0.41.08

Modificada por: Raymundo Espinoza Garcia
Fecha de mofidicacion: 25/11/2019
Versión ERP: 

Invocada desde: PAGE_ProModificacionVariables (Solicitud 165)
Invocada desde: PAGE_ProModificacionVariables (Solicitud 703)
***************************************************************************************************** */
AS

DECLARE @cols AS NVARCHAR(MAX),
        @query  AS NVARCHAR(MAX)

BEGIN
	SELECT  @cols = STUFF((SELECT DISTINCT '],[' +CONVERT(VARCHAR,CAST(FechaInicio as date) )
	FROM CatPeriodos
	WHERE FechaInicio >= @FechaInicio and
	FechaInicio <= @FechaFinal and 
	IdTipoPeriodo = @IdTipoPeriodo
	ORDER BY '],[' +CONVERT(VARCHAR,CAST(FechaInicio as date) )
	 FOR XML PATH('')),1,2,'' ) + ']'
END 


BEGIN
set @query = 'SELECT IdEmpleado,IdConceptoPDO,NumeroConcepto,Descripcion, ' + @HeadersPeriodo + ' FROM 
            (
                SELECT pnrc.IdConceptoPDO,ccp.NumeroConcepto,ccp.Descripcion, 
				CASE WHEN pnrc.ImporteGravadoIMSS = 0 THEN NULL else pnrc.ImporteGravadoIMSS end as ImporteGravadoIMSS  , 
				pnr.IdEmpleado, CAST(cp.FechaInicio as date) as Fecha
				FROM ProNominasReciboConceptos as pnrc
				Inner join ProNominasRecibo AS pnr ON pnr.IdNominaRecibo = pnrc.IdNominaRecibo
				Inner join CatPeriodos AS cp ON cp.IdPeriodo = pnr.IdPeriodo
				Inner join CatConceptosPDO AS ccp ON ccp.IdConceptoPDO = pnrc.IdConceptoPDO
				WHERE cp.FechaInicio>= ''' + CONVERT(VARCHAR, @FechaInicio) + ''' 
				  AND cp.FechaInicio<= ''' + CONVERT(VARCHAR,@FechaFinal) + ''' 					  
				AND pnrc.IdConceptoPDO IN ( ' + @ConceptosPDO + ')
				AND pnr.IdTipoPeriodo = ' + CONVERT(VARCHAR,@IdTipoPeriodo) + '
           ) x
            pivot 
            (
                 SUM(x.ImporteGravadoIMSS)
                FOR Fecha IN (' + @cols + ')
            ) p '

EXECUTE (@query)

END
go

