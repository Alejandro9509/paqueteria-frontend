CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosCXPAgregar]
@Codigo int,	  
@TipoMovimiento	varchar(50),	  
@DesminuirSaldoProveedor bit,	
@AfectaSaldoBanco bit,	
@CreadoEl	datetime,	
@CreadoPor	int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de tipo de movimiento cuentas por pagar es un campo requerido',
			16,
			1
			)
				
	IF ISNULL(@TipoMovimiento,'')= ''
		RAISERROR(N'La descripción de movimiento cuentas por pagar es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Codigo FROM CatTiposMovimientosCXP WHERE Codigo = @Codigo)
		RAISERROR(N'El código ingresado ya existe, favor de validar la información.',
			16,
			1
			)	
			
	INSERT INTO CatTiposMovimientosCXP(Codigo,TipoMovimiento,DesminuirSaldoProveedor,AfectaSaldoBanco,CreadoEl,CreadoPor)
	VALUES (@Codigo,@TipoMovimiento,@DesminuirSaldoProveedor,@AfectaSaldoBanco,@CreadoEl,@CreadoPor)

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

