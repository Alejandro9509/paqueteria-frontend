CREATE PROCEDURE [dbo].[usp_ProNominasReciboVacacionesModificar]
	@IdNominaReciboVacaciones int,
	@IdEmpleado int,
	@TipoCaptura int,
	@FechaInicial datetime,
	@FechaFinal datetime,
	@FechaPago datetime,
	@DiasDescansoOSeptimos int,
	@DiasVacaciones int,
	@PrimaVacacionalDias decimal(15,2),
	@VacacionesAcumuladas int,
	@DiasPrimaAcumulados decimal(15,2),
	@VacacionesPendientes int,
	@DiasPrimaPendientes decimal(15,2),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@xmlIncidenciaValor ntext,
	@TipoIncidencia int,
	@IdPeriodo int,
	@ModificadoManual bit,
	@dsXmlSeptimos ntext,
	@IdConceptoPDOVacaciones int,
	@IdConceptoPDOPrimaVacacional int
AS
DECLARE
	@docHandle int

/****************************************************************************************************** 
Descripción: El procedimiento Modifica los registros de vacaciones de cada empleado.

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 17/08/2021
Versión ERP: 8.0.64.01

Invocada desde: PAGE_ProNominasReciboVacacionesAM (Solicitud 4712)
***************************************************************************************************** */
	
BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
		IF @IdNominaReciboVacaciones = 0
			RAISERROR(N'El IdNominaReciboVacaciones es un campo requerido',
				16,
				1
				)
		IF ISNULL(@IdEmpleado,0) = 0
			RAISERROR(N'El empleado es un campo requerido',
				16,
				1
				)
		IF @TipoCaptura = 0
			RAISERROR(N'El tipo de captura es un campo requerido',
				16,
				1
				)
		IF isnull(@FechaInicial,'') = ''			
			RAISERROR(N'La fecha inicial es un campo requerido',
				16,
				1
				)	
		IF isnull(@FechaFinal,'') = ''			
			RAISERROR(N'La fecha final es un campo requerido',
				16,
				1
				)	
		IF isnull(@FechaPago,'') = ''			
			RAISERROR(N'La fecha de pago es un campo requerido',
				16,
				1
				)	
		IF @FechaPago < (SELECT FechaInicio FROM CatPeriodos WHERE IdPeriodo = @IdPeriodo)
			RAISERROR(N'La fecha de pago debe ser mayor o igual a la fecha de inicio del periodo',
				16,
				1
				)
				
	--Sección para validar si alguno de los dos IdConceptosPDOVacacions-PrimaVacacional viene en 0 ponerlo en null
	IF @IdConceptoPDOVacaciones = 0
	BEGIN
		SET @IdConceptoPDOVacaciones = NULL
	END
	
	IF @IdConceptoPDOPrimaVacacional = 0
	BEGIN 
		SET @IdConceptoPDOPrimaVacacional = NULL
	END							
	
	--UPDATE A LA TABLA ProNominasReciboVacaciones CON LA INFORMACION PROPORCIONADA		
	UPDATE ProNominasReciboVacaciones SET
	IdEmpleado = @IdEmpleado,
	IdPeriodo = @IdPeriodo,
	TipoCaptura = @TipoCaptura,
	FechaInicial = @FechaInicial,
	FechaFinal = @FechaFinal,
	FechaPago = @FechaPago,
	DiasDescansoOSeptimos = @DiasDescansoOSeptimos,
	DiasVacaciones = @DiasVacaciones,
	PrimaVacacionalDias = @PrimaVacacionalDias,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	IdConceptoPDOVacaciones = @IdConceptoPDOVacaciones,
	IdConceptoPDOPrimaVacacional = @IdConceptoPDOPrimaVacacional 
	WHERE IdNominaReciboVacaciones = @IdNominaReciboVacaciones
	
	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	--seccion que actualiza todos los registros de acumulados del empleado
	UPDATE ProNominasReciboVacaciones 
	SET VacacionesAcumuladas = @VacacionesAcumuladas,
		DiasPrimaAcumulados = @DiasPrimaAcumulados,
		VacacionesPendientes = @VacacionesPendientes,
		DiasPrimaPendientes = @DiasPrimaPendientes
	WHERE  IdEmpleado = @IdEmpleado
	AND IdNominaReciboVacaciones = @IdNominaReciboVacaciones
	
	IF @ModificadoManual = 1 
	BEGIN 
		DELETE FROM ProNominasReciboVacacionesSeptimosDias WHERE IdNominaReciboVacaciones = @IdNominaReciboVacaciones
		IF @dsXmlSeptimos IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsXmlSeptimos	
			SELECT ATT_S_FechaSeptimoDia
			INTO #TempSeptimos
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_SeptimosDias',2) 
			WITH(ATT_S_FechaSeptimoDia date)
			
			EXEC sp_xml_removedocument @docHandle	
			
			INSERT INTO ProNominasReciboVacacionesSeptimosDias(IdNominaReciboVacaciones,FechaSeptimoDia,CreadoEl,CreadoPor)
			SELECT @IdNominaReciboVacaciones,ATT_S_FechaSeptimoDia,@ModificadoEl,@ModificadoPor
			FROM #TempSeptimos			
			DROP TABLE #TempSeptimos	
		END		
	END 
	
	EXEC  usp_ProNominasDiasHorasModificar
	@IdPeticion,
	@IdEmpleado,
	@xmlIncidenciaValor,
	@FechaInicial,
	@ModificadoPor,
	@ModificadoEl,
	@TipoIncidencia,
	NULL,
	@IdPeriodo,
	@IdNominaReciboVacaciones

	COMMIT
END TRY
BEGIN CATCH	
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

