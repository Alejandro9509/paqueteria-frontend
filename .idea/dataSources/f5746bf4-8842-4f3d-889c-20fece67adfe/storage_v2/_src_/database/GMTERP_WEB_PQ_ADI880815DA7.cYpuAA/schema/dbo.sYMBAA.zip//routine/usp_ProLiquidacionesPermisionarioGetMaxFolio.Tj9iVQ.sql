CREATE PROCEDURE [dbo].[usp_ProLiquidacionesPermisionarioGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProLiquidaciones WHERE LiquidacionPermisionario = 1
go

