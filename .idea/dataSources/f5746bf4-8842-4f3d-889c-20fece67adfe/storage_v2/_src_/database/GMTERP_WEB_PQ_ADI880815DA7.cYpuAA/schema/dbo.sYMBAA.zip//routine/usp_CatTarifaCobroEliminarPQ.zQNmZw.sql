

CREATE PROCEDURE [dbo].[usp_CatTarifaCobroEliminarPQ]
	@IdTarifaCobro INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdTarifaCobro,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de Servicio de la Tarifa es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		DELETE FROM CatTarifaCobroPQ
		WHERE IdTarifaCobro = @IdTarifaCobro
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END


go

