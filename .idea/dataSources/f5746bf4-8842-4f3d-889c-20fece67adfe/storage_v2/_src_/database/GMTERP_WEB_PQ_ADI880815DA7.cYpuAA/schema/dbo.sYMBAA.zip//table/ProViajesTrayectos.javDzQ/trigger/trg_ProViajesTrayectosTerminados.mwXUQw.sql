CREATE TRIGGER [dbo].[trg_ProViajesTrayectosTerminados]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE,INSERT
AS
BEGIN
	DECLARE @ViajeTerminado int
	SET @ViajeTerminado = (SELECT TOP 1 ViajeTerminado FROM ProViajes WHERE IdViaje IN(SELECT IdViaje FROM deleted))
	
	IF @ViajeTerminado = 1
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
		WHERE I.CodigoUnidadCamion <> D.CodigoUnidadCamion OR I.IdDestino <> D.IdDestino
		OR I.IdOperador <> D.IdOperador OR I.IdOrigen <> D.IdOrigen OR I.IdUnidadCamion <> D.IdUnidadCamion
		OR I.NombreOperador <> D.NombreOperador OR I.PlacasUnidadCamion <> D.PlacasUnidadCamion)
        RAISERROR(N'No puede modificarse el viaje/trayectos porque esta terminado',
            16,
            1
            )                
	END
END
go

