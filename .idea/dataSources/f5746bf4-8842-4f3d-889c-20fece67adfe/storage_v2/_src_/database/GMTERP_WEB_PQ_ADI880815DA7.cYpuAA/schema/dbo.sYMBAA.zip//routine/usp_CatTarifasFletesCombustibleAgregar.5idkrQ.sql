CREATE  PROCEDURE [dbo].[usp_CatTarifasFletesCombustibleAgregar] 

@Tarifa decimal(15,4),
@KM int,
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100)
	
AS
DECLARE @Folio INT
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Tarifa,0)= 0
		RAISERROR(N'La Tarifa es un campo requerido',
			16,
			1
			)
						
	IF ISNULL(@KM,0)= 0
		RAISERROR(N'KMs es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT TOP 1 KM  FROM CatTarifasFletesCombustible WHERE KM = @KM)
			RAISERROR(N'Ya existe una tarifa para esos kilómetros.',
			16,
			1
			)


	SET @Folio = (SELECT ISNULL(MAX(Folio),0)+1 FROM CatTarifasFletesCombustible)

	INSERT INTO CatTarifasFletesCombustible(Folio,Tarifa,KM,CreadoEl,CreadoPor)
	VALUES(@Folio,@Tarifa,@KM,@CreadoEl,@CreadoPor)
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

