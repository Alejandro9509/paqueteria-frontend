
create PROCEDURE [dbo].[usp_CatCuentasContablesSaldosInicializar]
@ActivaMonedaExtrangera int = 0, /*Si es diferente de cero , activo el parametro [Manejar moneda extranjera] */
@IdPeticion varchar(100)
AS
DECLARE 
@Ejercicio int = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EjercicioActual'), /*Año con el cual inicial la contabilidad integrada*/
@IdCuentaContable int, @IdMoneda int,@CuentaMayor int
/*
PARÁMETROS:
	@IdPeticion:		Sesion con la cual se inicializo el catalogo CatCuentasContablesSaldos.
	@Ejercicio:			Obtiene el Ejercicio con el cual inicio la contabilidad
	@IdCuentaContable:	Se utiliza cuando activan el parametro [Manejar moneda extranjera], para tomar el valor en el cursor
	@IdMoneda:			Se utiliza cuando activan el parametro [Manejar moneda extranjera], para tomar el valor en el cursor
	@CuentaMayor:		Se utiliza cuando activan el parametro [Manejar moneda extranjera], para tomar el valor en el cursor
DESCRIPCIÓN:
	 Este usp se encarga de inicializar el sub catalogo CatCuentasContablesSaldos. Y se utiliza cuando el usuario activa
	 el parametro [Manejar moneda extranjera], ya que tambien es una inicializacion del catalogo CatCuentasContablesSaldos unicamente
	 se generan Saldo inicial[4], Cargos[5], Abonos[6] cuando el IdMoneda es 2.
IMPLEMENTADA POR:
	Abril CG
FECHA DE IMPLEMENTACIÓN:
	2019-09-03
VERSIÓN:

MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-03
INVOCADA DESDE:
		usp_CatCuentasContablesInicializar
		ClsCatCuentasContables::InicializarCatalogoMonedaExtranjera()
SOLICITUD: 
	SOLCITUD 000266
*/
BEGIN TRY
	BEGIN TRANSACTION

	IF @ActivaMonedaExtrangera = 0 /*Inicia la contabilidad integrada*/
	BEGIN
		/*Se declararon las columnas SaldoInicial,Abonos y Cargos con el numero constante que se va a manejar. Esto para aplicar
		un UNPIVOT y poder insertar las cuentas contables del catalogo CatCuentasContables en el catalogo CatCuentasContablesSaldos con 
		el tipo de movimiento [SaldoInicial:1,	Abonos:2,	Cargos:3] definido.*/	
		INSERT INTO CatCuentasContablesSaldos(IdCuentaContable,Tipo,Ejercicio)
		SELECT
		IdCuentaContable,Tipo,@Ejercicio
		FROM(
			SELECT
			*
			FROM (
				SELECT
				IdCuentaContable,
				'1' AS SaldoInicial,
				'2' AS Abonos,
				'3' AS Cargos
				FROM CatCuentasContables
			) AS TablaCatCuentasContables
			UNPIVOT (
				Tipo FOR Descripcion IN ([SaldoInicial],[Abonos],[Cargos])
			) AS UnPvt
		) CatCuentasContablesTipo
	END
	ELSE /*activo el parametro [Manejar moneda extranjera]*/
	BEGIN
		DECLARE CatCuentasContablesCursor CURSOR LOCAL FOR 
			/*Cursor: Se inicializa con las cuentas contables con moneda extrangera*/
			SELECT cc.IdCuentaContable,cc.IdMoneda,cc.CuentaMayor
			FROM CatCuentasContables cc WHERE cc.IdMoneda = 2 
		OPEN CatCuentasContablesCursor
		FETCH NEXT FROM CatCuentasContablesCursor INTO @IdCuentaContable,@IdMoneda,@CuentaMayor 
		WHILE @@fetch_status = 0
		BEGIN
			/* Se valida que la cuenta contable no este registrada en el mismo Ejercicio y 
			que no tenga algun tipo de moneda extrangera Saldo inicial[4], Cargos[5], Abonos[6]
			esto para evitar duplicidad de registros */
			IF NOT EXISTS (SELECT IdCuentaContable FROM CatCuentasContablesSaldos WHERE IdCuentaContable = @IdCuentaContable AND Ejercicio = year(getdate()) AND Tipo IN (4,5,6)) 
			BEGIN
				INSERT INTO CatCuentasContablesSaldos(IdCuentaContable,Tipo,Ejercicio)
				VALUES
				(@IdCuentaContable,4,year(getdate())),	/*Saldo Inicial moneda extrangera*/
				(@IdCuentaContable,5,year(getdate())),	/*Cargos moneda extrangera*/
				(@IdCuentaContable,6,year(getdate()))	/*Abonos moneda extrangera*/ 
			END

			FETCH NEXT FROM CatCuentasContablesCursor INTO @IdCuentaContable,@IdMoneda,@CuentaMayor 
		END
		CLOSE CatCuentasContablesCursor
		DEALLOCATE CatCuentasContablesCursor
	END

COMMIT
END TRY
BEGIN CATCH 
		IF (SELECT CURSOR_STATUS('global','CatCuentasContablesCursor')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('global','CatCuentasContablesCursor')) > -1
			BEGIN
				CLOSE CatCuentasContablesCursor
			END
		DEALLOCATE CatCuentasContablesCursor
		END
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

