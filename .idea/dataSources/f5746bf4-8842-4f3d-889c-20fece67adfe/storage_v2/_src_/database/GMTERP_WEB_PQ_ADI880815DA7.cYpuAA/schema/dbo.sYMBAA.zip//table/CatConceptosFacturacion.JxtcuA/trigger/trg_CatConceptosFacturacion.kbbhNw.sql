CREATE TRIGGER [dbo].[trg_CatConceptosFacturacion]
   ON  [dbo].[CatConceptosFacturacion]
   AFTER UPDATE
AS 
BEGIN	
	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.ConceptoFacturacion <> D.ConceptoFacturacion OR I.Codigo <> D.Codigo)
			RAISERROR(N'El Campo concepto de facturación y código no puede ser modificado porque esta definido por sistema',
				16,
				1
				)
	END

	IF EXISTS(Select Top 1 IdFacturaConceptoFacturacion from ProFacturasConceptosFacturacion Where IdConceptoFacturacion = (SELECT IdConceptoFacturacion FROM deleted)) 
	OR EXISTS(Select Top 1 IdViajeConceptoFacturacion from ProViajesConceptosFacturacion Where IdConceptoFacturacion = (SELECT IdConceptoFacturacion FROM deleted)) 
	OR EXISTS(Select Top 1 IdRutaConceptoFacturacion from CatRutasConceptosFacturacion Where IdConceptoFacturacion = (SELECT IdConceptoFacturacion FROM deleted))	
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.ConceptoFacturacion <> D.ConceptoFacturacion)
		RAISERROR(N'El concepto no se puede modificar porque ya cuenta con movimientos de facturación o viajes',
			16,
			1
			)
	END	
END
go

