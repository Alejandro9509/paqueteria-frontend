CREATE PROCEDURE [dbo].[usp_CatTiposPeriodosModificar]
@IdTipoPeriodo Int,
@Codigo int,
@Nombre Varchar(40),
@DiasdelPeriodo int,
@DiasdePago Decimal(15,2),
@PeriodoTrabajo int,
@AjustarPeriodo bit,
@NumerosSeptimos int,
@PosicionSeptimos datetime,
@PosicionPagoNomina datetime,
@FechaInicioEjercicio datetime,
@Ejercicio int,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100),
@ClavePeriodicidadPago varchar(5),
@GeneraPoliza bit
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdTipoPeriodo,0)= 0
	RAISERROR(N'El identificador del Tipo de período es un campo requerido',
			16,
			1
			)

	IF @Codigo <= 0
        RAISERROR(N'El Código es un campo requerido',
            16,
            1
            )
            
    IF ISNULL(@Nombre,'')= ''
        RAISERROR(N'El nombre es un campo requerido',
            16,
            1
            )
           
	 IF @DiasdelPeriodo  <= 0
	 RAISERROR(N'Los días del período campo requerido',
            16,
            1
            )
     IF @DiasdePago  <= 0
     RAISERROR(N'Los dias de pago son campo requerido',
            16,
            1
            )
     IF @PeriodoTrabajo <= 0
     RAISERROR(N'El Periodo de trabajo es un campo requerido',
            16,
            1
            )
     
     --IF @NumerosSeptimos <= 0
     --RAISERROR(N'El Código es un campo requerido',
     --       16,
     --       1
     --       )
     --IF @PosicionSeptimos <= 0
     --RAISERROR(N'El Código es un campo requerido',
     --       16,
     --       1
     --       )
IF Isnull(@PosicionPagoNomina,0) <= 0
     RAISERROR(N'Posición del día de pago es un campo requerido',
            16,
            1
            )
     IF Isnull(@FechaInicioEjercicio,0) <= 0
     RAISERROR(N'Fecha de inicio del ejercicio es campo requerido',
            16,
            1
            )
     IF @Ejercicio <= 0  
     RAISERROR(N'El Ejercicio es un campo requerido',
            16,
            1
            )
            
	--IF EXISTS(SELECT Codigo FROM CatTiposPeriodos WHERE Codigo = @Codigo)
	--	RAISERROR(N'El Código del tipo de periodo ya existe',
	--		16,
	--		1
	--		)                        
			
   IF EXISTS(SELECT Nombre FROM CatTiposPeriodos  WHERE Nombre = @Nombre And IdTipoPeriodo <> @IdTipoPeriodo)
		RAISERROR(N'El nombre del tipo de periodo ya existe',
			16,
			1
			) 	
	
		UPDATE CatTiposPeriodos SET			
		Codigo = @Codigo,
		Nombre = @Nombre,
		DiasdelPeriodo = @DiasdelPeriodo ,
		DiasdePago = @DiasdePago,
		PeriodoTrabajo = @PeriodoTrabajo,
		AjustarPeriodo = @AjustarPeriodo,
		NumerosSeptimos = @NumerosSeptimos,
		PosicionSeptimos = @PosicionSeptimos,
		PosicionPagoNomina = @PosicionPagoNomina,
		FechaInicioEjercicio =@FechaInicioEjercicio, 
		Ejercicio = @Ejercicio,				
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		ClavePeriodicidadPago= @ClavePeriodicidadPago,
		GeneraPoliza = @GeneraPoliza
		WHERE 	IdTipoPeriodo=@IdTipoPeriodo
		
		---------Modificar Operadores----------------------
		Update CatOperadores set PeriodicidadPago = @Nombre where IdOperador in(select IdOperador from CatEmpleados where IdTipoPeriodo = @IdTipoPeriodo)	
		Update CatOperadores set ClavePeriodicidadPago = @ClavePeriodicidadPago where IdOperador in(select IdOperador from CatEmpleados where IdTipoPeriodo = @IdTipoPeriodo)	
		---------Fin de Modificar Operadores---------------
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

