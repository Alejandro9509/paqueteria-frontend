
CREATE PROCEDURE [dbo].[usp_CatZonasOperativasGetByIdCPPQ](
	@CP varchar(50)
)
AS
BEGIN
	BEGIN TRANSACTION
		SELECT DISTINCT
		z.IdZona
		,CodigoZona
		,IdSucursal
		,z.IdEstado
		,Estado
		,z.CodigoMunicipio
		,z.Municipio
		FROM CatZonasOperativasCPPQ zcp 
		join CatZonasOperativasPQ z on zcp.IdZona = z.IdZona 
		join CatCodigosPostales cp on cp.IdCodigoPostal = zcp.IdCP
		WHERE cp.CodigoPostal = @CP

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

