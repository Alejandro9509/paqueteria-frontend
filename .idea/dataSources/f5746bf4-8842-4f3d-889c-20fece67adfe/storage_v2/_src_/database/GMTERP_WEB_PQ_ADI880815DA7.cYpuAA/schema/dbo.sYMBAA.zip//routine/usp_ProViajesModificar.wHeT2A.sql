CREATE PROCEDURE [dbo].[usp_ProViajesModificar]
	@IdViaje int,
	@IdViajeCartaPorte int,
	@TipoCobroPorViaje tinyint,
	@FechaHora datetime,	
	@NoViajeCliente varchar(30),
	@IdCliente int,
	@IdUnidadCarga1 int,
	@IdUnidadDolly int,
	@IdUnidadCarga2 int,
	@IdUnidadContenedor1 int,
	@IdUnidadContenedor2 int,
	@CodigoUnidadCarga1 varchar(16),
	@CodigoUnidadDolly varchar(16),
	@CodigoUnidadCarga2 varchar(16),
	@CodigoUnidadContenedor1 varchar(16),
	@CodigoUnidadContenedor2 varchar(16),
	@PlacasUnidadCarga1 varchar(16),
	@PlacasUnidadCarga2 varchar(16),
	@IdRuta int,
	@Item varchar(50),
	@Planta varchar(50),
	@Convenio varchar(50),
	@IdRemitente int,
	@DatosRemitente varchar(512),
	@SeRecogeraEn varchar(100),
	@FechaCarga datetime,
	@IdDestinatario int,
	@DatosDestinatario varchar(512),
	@SeEntregaraEn varchar(100),
	@FechaEntrega datetime,
	@ValorDeclarado money,
	@IdMonedaValorDeclarado int,
	@CuotaConvenida varchar(20),
	@Observaciones varchar(512),
	@Peso decimal(15,4),
	@IdUnidadPeso int,
	@SubTotal money,
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Facturable bit,
	@Kilometros	int,	
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),
	@IdFormatoImpresion int,	
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@dsProViajesConceptosFacturacion ntext,
	@dsProViajesDescripcionesCarga ntext,
	@dsProViajesImagenes ntext,
	@dsProViajesImpuestos ntext,
	@dsProViajesPedimentos ntext,
	@dsProViajesTrayectos ntext,
	@IdPeticion varchar(100),
	@Convertir bit,
	@IdFolio int,
	@IdSucursal int,
	@EstatusImpresoEnviadoCliente bit,
	@IdCertificado int,
	@PermitirDocumentarRebaseCredito bit,
	@IdViajeCompuestoPadre int,
	@CandadoOficial varchar(60),
	@IdTipoViaje int,
	@IdClasificacionViaje int,
	@IdTipoUnidad int,
	@CantidadMovimientos decimal(15,2),
	@dsProViajesContenedoresEquipos ntext,
	@ClaveMetodoPago varchar(5),
	@IdViajeTrayectoCompuestoPadre int,
	@dsProViajesCartasPorteReferencias ntext,
	@CreadaParaCFDI33 bit,
	@Millas decimal(15,2),
	@dsProViajesTrayectosAutorizaMasGastosVales ntext = NULL,
	@LitrosCombustible decimal(15,4)=0,
	@IdCombustible int=0,
	@IdSucursalAReportar int=0,
	@IncluirFlete bit=0,
	@IdCombustibleTarifaFlete int=0,
	@TieneIEPS bit=0,
	@IEPS money = 0,
	@PermitirModificarImportesLiquidacion1 bit = 0,
	@IdentificadorConvoy varchar(16)=NULL,
	@CreadoElVale datetime = NULL,
	@PTVContratado bit = 0,--para identificar si el cliente contrato el modulo de ptv
	@Identificador VARCHAR(50) = NULL,
	@Contenedores VARCHAR(1000) = NULL,
	@dsProViajesCartaPorteConocimientoEmbarque ntext = NULL,
    @FechaEntregaModificada bit = 0,
	@JsonShipment VARCHAR(MAX) = NULL,
	@ShipmentAPI VARCHAR(50) = NULL,
	@dsProViajesTrayectosDistribucionConceptosFacturacion XML = NULL,
	@GeneradoDistribucionIngresos bit = NULL,
	@ViajeInternacional bit = NULL,
	@ImportacionExportacion tinyint = NULL,
	@CreadaParaComplemento bit = NULL,
	@dsProViajesTrayectosMateriales ntext = NULL,
	@DocumentoConfiguracionTimbrado int = 0,
	@dsProViajesCartaPorteSeguros ntext = NULL
/*************************************************************************************************************************************
Procedimiento almacenado usp_ProViajesModificar

Parámetros: 
 @IdViaje int,
	@IdViajeCartaPorte int,
	@TipoCobroPorViaje tinyint,
	@FechaHora datetime,	
	@NoViajeCliente varchar(30),
	@IdCliente int,
	@IdUnidadCarga1 int,
	@IdUnidadDolly int,
	@IdUnidadCarga2 int,
	@IdUnidadContenedor1 int,
	@IdUnidadContenedor2 int,
	@CodigoUnidadCarga1 varchar(16),
	@CodigoUnidadDolly varchar(16),
	@CodigoUnidadCarga2 varchar(16),
	@CodigoUnidadContenedor1 varchar(16),
	@CodigoUnidadContenedor2 varchar(16),
	@PlacasUnidadCarga1 varchar(16),
	@PlacasUnidadCarga2 varchar(16),
	@IdRuta int,
	@Item varchar(50),
	@Planta varchar(50),
	@Convenio varchar(50),
	@IdRemitente int,
	@DatosRemitente varchar(512),
	@SeRecogeraEn varchar(100),
	@FechaCarga datetime,
	@IdDestinatario int,
	@DatosDestinatario varchar(512),
	@SeEntregaraEn varchar(100),
	@FechaEntrega datetime,
	@ValorDeclarado money,
	@IdMonedaValorDeclarado int,
	@CuotaConvenida varchar(20),
	@Observaciones varchar(512),
	@Peso decimal(15,4),
	@IdUnidadPeso int,
	@SubTotal money,
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Facturable bit,
	@Kilometros	int,	
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),
	@IdFormatoImpresion int,	
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@dsProViajesConceptosFacturacion ntext,
	@dsProViajesDescripcionesCarga ntext,
	@dsProViajesImagenes ntext,
	@dsProViajesImpuestos ntext,
	@dsProViajesPedimentos ntext,
	@dsProViajesTrayectos ntext,
	@IdPeticion varchar(100),
	@Convertir bit,
	@IdFolio int,
	@IdSucursal int,
	@EstatusImpresoEnviadoCliente bit,
	@IdCertificado int,
	@PermitirDocumentarRebaseCredito bit,
	@IdViajeCompuestoPadre int,
	@CandadoOficial varchar(60),
	@IdTipoViaje int,
	@IdClasificacionViaje int,
	@IdTipoUnidad int,
	@CantidadMovimientos decimal(15,2),
	@dsProViajesContenedoresEquipos ntext,
	@ClaveMetodoPago varchar(5),
	@IdViajeTrayectoCompuestoPadre int,
	@dsProViajesCartasPorteReferencias ntext,
	@CreadaParaCFDI33 bit,
	@Millas decimal(15,2),
	@dsProViajesTrayectosAutorizaMasGastosVales ntext = NULL,
	@LitrosCombustible decimal(15,4)=0,
	@IdCombustible int=0,
	@IdSucursalAReportar int=0,
	@IncluirFlete bit=0,
	@IdCombustibleTarifaFlete int=0,
	@TieneIEPS bit=0,
	@IEPS money = 0,
	@PermitirModificarImportesLiquidacion1 bit = 0,
	@IdentificadorConvoy varchar(16)=NULL,
	@CreadoElVale datetime = NULL,
	@PTVContratado bit = 0,--para identificar si el cliente contrato el modulo de ptv
	@Identificador VARCHAR(50) = NULL,
	@dsProViajesCartaPorteConocimientoEmbarque ntext,
    @FechaEntregaModificada bit = 0
	@JsonShipment VARCHAR(MAX) = NULL,
	@ShipmentAPI VARCHAR(50) = NULL,
	@dsProViajesTrayectosDistribucionConceptosFacturacion XML = NULL,
	@GeneradoDistribucionIngresos bit = NULL,
	@ViajeInternacional bit = NULL,
	@ImportacionExportacion tinyint = NULL,
	@CreadaParaComplemento bit = NULL

Descripción: Agrega Viajes con los campos e informacion correspondiente

Invocada desde: ClsProViajes
    Solicitud 12236

Modificada por: Edgar Ramos
Fecha de modificación: 21/06/2021
Versión: 8.0.62.15
Solicitud: 4451
Descripción: Se agrego la funcionalidad de agregar remitentes y destinatarios por trayecto siempre y cuando la ruta sea por reparto/recolecta, para asi pooder cumplir con el complemento de la carta porte.

Modificada por: Edgar Ramos
Fecha de modificación: 01/07/2021
Versión 8.0.62.25
Solicitud: 4454
Descripción: Se agrego en la tabla de distribuciones por trayecto el campo tipo trayecto.

Modificada por: Edgar Ramos
Fecha de modificación: 16/08/2021
Versión: 8.0.63.21
Solicitud: 4720
Descripción: Se agrego el collation a la tabla #TempProViajesDescripcionesCargaClavesSAT para evitar errores de comparacion.


Modificada por: Yarazeth Lemus
Fecha de modificación: 19/08/2021
Versión: 8.0.64.02
Solicitud: 4669
Descripción: Se agrego para aggregar en la nueva tabla de ChoferPermisionario y UnidadPermisionaria  relacion 1:1 con viajes trayectos
Esto se encuentra en el cursor de ViajesTrayectos

Modificada por: Jesús Humberto Morales Mojica
Fecha de modificación: 27/08/2021
Versión: 8.0.64.02
Solicitud: 4527
Descripción: Se cambio el tipo de dato del Importe Base a liquidar de la descripcion de materiales

Modificada por: Yarazeth Lemus
Fecha de modificación: 07/09/2021
Versión: 8.0.64.02
Solicitud: 4788
Descripción: Se cambio el varchar de licencia a 19 

Modificada por: Yarazeth Lemus
Fecha de modificación: 23/09/2021
Versión: 8.0.64.02
Solicitud: 4750
Descripción: se agrego la secuencia a los materiales y xml para agregar materiales por trayectos

Modificada por: Yarazeth Lemus
Fecha de modificación: 05/10/2021
Versión: 8.0.64.13
Solicitud: 4888
Descripción: se agrego el campo de creadodesde para la tabla de viajespedimentos
******************************************************************************************************************* */
AS
DECLARE
	@docHandle int,
	@ViajeConCP bit,
	@IdMonedaAnt int,
	@TotalAnt money,
	@FacturableAnt bit,
	@IdClienteAnt int,
	@IdOperador int,
	@CursorT_ETA decimal(15,2),
	@CursorT_Secuencia int,
	@CursorT_IdOrigen int,
	@CursorT_IdDestino int,
	@CursorT_IdUnidadCamion int,
	@CursorT_CodigoUnidadCamion varchar(16),
	@CursorT_PlacasUnidadCamion varchar(9),
	@CursorT_IdOperador int,
	@CursorT_NombreOperador varchar(100),
	@CursorT_Kilometros int,
    @CursorT_Horas decimal(15,2),
	@CursorT_NombreOperadorPermisionario varchar(100),
	@CursorT_NoCartaPortePermisionario varchar(15),
	@CursorT_NoFacturaPermisionario varchar(15),
	@CursorT_IdMonedaPermisionario int,
	@CursorT_FechaFacturaPermisionario datetime,
	@CursorT_FechaRecepcionFacturaPermisionario datetime,
	@CursorT_ConceptoPermisionario varchar(50),
	@CursorT_AplicarAnticipo bit,
	@CursorT_Anticipo money,
	@CursorT_MonedaAnticipo varchar(7),
	@CursorT_AplicarValeDeCombustible bit,
	@CursorT_LitrosAutorizados decimal(15,2),
	@CursorT_IdViajeTrayecto INt,
	@CursorT_IdProveedor int,
	@NumeroViaje varchar(20),
	@num int,
	@ViajeCompleto varchar(50),
	@Mensaje varchar(100),
	@NumeroCompleto varchar(20),
	@IdViajeTrayecto int,
	@FolioConsecutivo int,
	@PermitirRegistrarAnticiposMayores bit,
	@IdMonedaAnticipo int,
	@return_valueAnt int,
	@FolioValesConsecutivo int,
	@Autorizo Varchar(20),
	@PermitirRegistrarLitrosMayores bit,
	@return_valueVal int,
	@ATT_GeneradoAnticipo bit,
	@ATT_GeneradoVale bit,
	@FechaTemp datetime, --FechaTemporal para convertir a date la fecha de los anticipos y de los vales para que no marque error de La fecha de cancelación no puede ser menor a la fecha de elaboración
	@CursorT__EsCompuesto int,
	@IdTrayectoCompuesto int,
	@IdViajeCompuestoPadreAnterior int,
	@IdViajeTrayectoCompuestoPadreAnterior int,
	@ContadorDeCompuestos int,
	@IdViajePadreNuevo int,
	@CursorT_Tienda varchar (50),
	@CursorT_NumeroOrden int,
	@CursorT_Monto money,
	@CursorT_CargadoVacioRemolque1 bit,
	@CursorT_CargadoVacioRemolque2 bit,
	@CursorT_FechaPagoFactura datetime,
	@ConceptosFactuacionCero bit,
	@CursorT_Millas decimal(15,2),
	@CursorT_GalonesAutorizados decimal(15,2),
	@CursorT_IdViajeTrayectoCompuesto int,
	@CursorT_Referencia varchar(20),
	@CursorT_EnvioNotificacionMovil bit,
	-- Solcitud 675
	@CursorT_FechaHoraCarga datetime,
	@CursorT_FechaHoraEstimadaCarga datetime,
	@CursorT_FechaHoraDescarga datetime,
	@CursorT_FechaHoraEstimadaDescarga datetime,
	-- Solicitud 866
	@CursorT_CamionPer varchar (50),
	@TieneLiquidacionCerrada bit = 0,
	@Viaje int,
	@IdSesion varchar(100),
	@FechaLocal datetime,
	@IdUnidadHijo int,
	@IdViajeTrayectoPadre int,
	@IdUnidadPadre int,
	--Solicitud 001487
	@CursorIdConceptoFacturacion int,
	@CursorUnidadMedida varchar(30),
	@CursorTrasladaImpuesto bit,
	@CursorRetieneImpuesto bit,
	@CursorImporteConceptoFacturacion money,
	@CursorIncluirCalculoIngresosLiquidacion bit,
	@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete bit,
	@CursorObservaciones varchar(8000),
	@CursorClaveSATProducto varchar(8),
	@CursorClaveSATUnidad varchar(8),
	@CursorIdImpuestoTrasladado int,
	@CursorIdImpuestoRetenido int,
	@CursorImporteTrasladado money,
	@CursorImporteRetenido money,
	@IdViajeConceptoFacturacion int,
	@CursorIdViajeConceptoFacturacion int,
	-- Solicitud 1,415
	@ExisteAnticipo INT,
	@IdAnticipo INT,
	@ExisteValeCombustible INT,
	@IdValeCombustible INT,
	@UltimaModificacionAnticipo datetime,/*Solicitud 2464*/
	@FolioAnticipo int,/*Solicitud 2464*/
	@FolioValeCombustible int,/*Solicitud 2464*/
	@CursorT_IdViajeDescripcionCarga int,
	@CursorT_Cantidad decimal(15,4),
	@CursorT_IdUnidadEmbalaje int,
	@CursorT_Descripcion varchar(1024),
	@CursorT_Peso decimal(15,4),
	@CursorT_IdUnidadPeso int,
	@CursorT_Tarifa float,
	@CursorT_Importe money,
	@CursorT_AplicarTarifaPor tinyint,
	@CursorT_ImporteBaseLiquidacion float,
	@CursorT_ImporteLiquidar money,
	@CursorT_ClavesSATXML varchar(max),
	@CursorT_Consecutivo int,
	@CursorT_EstaSiendoImportado TINYINT,
	@CursorT_UbicacionesXML varchar(max),
	@CursorT_PermisionarioXML varchar(max),
	@IdViajeDescripcionCarga int,
	@CursorT_IdOperadorAux int,
	@CursorT_NombreOperadorAux varchar(100)
	/*SOLICITUD 4208*/
	DECLARE @TempProViajesTrayectosDistribucionConceptosFacturacion AS TABLE 
		(
		 COL_IdViajeTrayectoDistribucionConceptoFacturacion int
		,COL_IdViajeTrayecto int
		,COL_IdRutaTrayecto int
		,COL_Secuencia int
		,COL_TipoTrayecto tinyint
		,COL_IdConceptoFacturacion int
		,COL_Importe money)
SET XACT_ABORT ON 	
	
BEGIN TRY
	BEGIN TRANSACTION
	
	SET @FechaTemp = cast(@FechaHora as date)
    SET @ConceptosFactuacionCero = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'PodreAgregarConceptoFacturacionEnCeros')
    
	IF @IdViaje = 0
		RAISERROR(N'El identificador del viaje es un campo requerido',
			16,
			1
			)
			
	IF (SELECT ModificadoEl FROM ProViajes WHERE IdViaje = @IdViaje) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)	

	IF EXISTS(SELECT CanceladoEl FROM ProViajes WHERE IdViaje = @IdViaje AND CanceladoEl IS NOT NULL)
		RAISERROR(N'No puede ser modificado este viaje porque está cancelado',
			16,
			1
			)
	IF @NoViajeCliente <>''	AND (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'ActivarNoViajeClienteNoSeRepita')= 1		
		IF EXISTS(SELECT NoViajeCliente FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente and  IdViaje <> @IdViaje)
			begin
				set @NumeroViaje = ''
				set @num = (SELECT TOP 1 pv.Viaje  from ProViajes as pv where NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente and  IdViaje <> @IdViaje)
				set @NumeroCompleto = (select TOP 1  SUBSTRING('000000',1,6-len(CAST(@num as varchar)))+CAST(@num as varchar))
						
				set @ViajeCompleto = (SELECT TOP 1  cs.Abreviacion  + '-' + CAST (@NumeroCompleto AS VARCHAR(20))  from ProViajes as pv 
				inner join CatSucursales as cs on pv.IdSucursal = cs.IdSucursal  where NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente and  IdViaje <> @IdViaje)
				set @Mensaje = 'El número de viaje del cliente ingresado se encuentra registrado previamente '+@ViajeCompleto 
				RAISERROR(@Mensaje,
					16,
					1
					)  						
			end						

	IF @TipoCobroPorViaje = 0
		RAISERROR(N'El tipo de cobro es un campo requerido',
			16,
			1
			)

	IF @FechaHora = ''			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)
			
	IF @CantidadMovimientos = 0
		RAISERROR(N'El campo Cantidad de Movimientos es un campo requerido',
			16,
			1
			)							

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF @IdRuta = 0
		RAISERROR(N'La ruta es un campo requerido',
			16,
			1
			)
		
	IF @SubTotal = 0 
	BEGIN
		IF @Facturable = 1 OR ISNULL(@ConceptosFactuacionCero,0) = 0
		RAISERROR(N'El subtotal es un campo requerido',
			16,
			1
			)
	END			

	IF @IdMoneda = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)
			
	--Solicitud 11037 Viajes/Cartar Porte - Facturados Parcialmente, Se agrego la condicion de que no tiene que estar facturado parcialmente para saltar el error al estar pendiente de facturar 
	--IF @dsProViajesConceptosFacturacion IS NULL AND ((SELECT PendienteFacturar FROM ProViajes WHERE IdViaje = @IdViaje) = 1 AND (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = @IdViaje) = 0) AND ISNULL((SELECT TimbrePruebas FROM ProViajesCartasPorte WHERE IdViaje = @IdViaje),1) = 1
	-- se elimina la validacion SOLICITUD 004015 , SOLO se dejara que valide unicamente si el xml de los conceptos de facturacion viene vacio.
	IF @dsProViajesConceptosFacturacion IS NULL 
		RAISERROR(N'Los conceptos de facturacion son requeridos',
			16,
			1
			)

	--IF @dsProViajesConceptosFacturacion IS NULL AND (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = @IdViaje) = 1 AND ISNULL((SELECT TimbrePruebas FROM ProViajesCartasPorte WHERE IdViaje = @IdViaje),1) = 0
	--	RAISERROR(N'Los conceptos de facturacion son requeridos',
	--		16,
	--		1
	--		)			
		
	SET @ViajeConCP = (SELECT ViajeConCP FROM ProViajes WHERE IdViaje = @IdViaje)

	IF @Convertir = 1 AND @ViajeConCP = 1
		RAISERROR(N'No se puede convertir un viaje con carta porte',
			16,
			1
			)

	--se le disminuye el saldo al cliente 
	IF @ViajeConCP = 0
		SET @TotalAnt = (SELECT SubTotal FROM ProViajes WHERE IdViaje = @IdViaje)
	ELSE	
		SET @TotalAnt = (SELECT Total FROM ProViajesCartasPorte WHERE IdViajeCartaPorte = @IdViajeCartaPorte)	
	
	SET @IdMonedaAnt = (SELECT IdMoneda FROM ProViajes WHERE IdViaje = @IdViaje)
	SET @FacturableAnt = (SELECT Facturable FROM ProViajes WHERE IdViaje = @IdViaje)
	SET @IdClienteAnt = (SELECT IdCliente FROM ProViajes WHERE IdViaje = @IdViaje)
	
	IF @IdCombustible = 0
		SET @IdCombustible = NULL
		
	IF @IdCombustibleTarifaFlete = 0
		SET @IdCombustibleTarifaFlete = NULL
	
	IF @FacturableAnt = 1 	
	BEGIN
		IF @IdMonedaAnt = 1 OR @IdMonedaAnt = 3
			UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0)  - @TotalAnt WHERE IdCliente = @IdClienteAnt
		ELSE
			UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) - @TotalAnt WHERE IdCliente = @IdClienteAnt
	END		
			
	IF @Convertir = 1 AND @ViajeConCP = 0
		SET @ViajeConCP = 1
		
	IF @ViajeConCP = 1
	BEGIN
		IF @IdRemitente = 0
			RAISERROR(N'El remitente es un campo requerido',
				16,
				1
				)

		IF @IdDestinatario = 0
			RAISERROR(N'El Destinatario es un campo requerido',
				16,
				1
				)
				
		IF @dsProViajesImpuestos IS NULL
			RAISERROR(N'Los impuestos son requeridos',
				16,
				1
				)
		IF 	@NoViajeCliente <> '' AND (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'ActivarNoViajeClienteNoSeRepita')= 1
			IF EXISTS(SELECT NoViajeCliente FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente and  IdViaje <> @IdViaje)
				 begin
					set @NumeroViaje = ''
					set @num = (SELECT TOP 1 pv.Viaje  from ProViajes as pv where NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente and  IdViaje <> @IdViaje)
					set @NumeroCompleto = (select TOP 1 SUBSTRING('000000',1,6-len(CAST(@num as varchar)))+CAST(@num as varchar))
							
					set @ViajeCompleto = (SELECT TOP 1 cs.Abreviacion  + '-' + CAST (@NumeroCompleto AS VARCHAR(20))  from ProViajes as pv 
					inner join CatSucursales as cs on pv.IdSucursal = cs.IdSucursal  where NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente and  IdViaje <> @IdViaje)
					set @Mensaje = 'El número de viaje del cliente ingresado se encuentra registrado previamente '+@ViajeCompleto 
					RAISERROR(@Mensaje,
						16,
						1
						)  						
			   end

		IF @Convertir = 1 	
		BEGIN
			IF @IdSucursal = 0
				RAISERROR(N'La sucursal es un campo requerido',
					16,
					1
					)

			IF @IdFolio = 0
				RAISERROR(N'El folio del documento es un campo requerido',
					16,
					1
					)			
		END							
	END

	IF @dsProViajesTrayectos IS NULL
		RAISERROR(N'Los trayectos son requeridos',
			16,
			1
			)

	IF @IdUnidadCarga1 = @IdUnidadCarga2 AND @IdUnidadCarga1 <> 0
		RAISERROR(N'La unidad del segundo remolque es la misma que el primer remolque',
			16,
			1
			)
	----SE HACE LA VALIDACION DE PODER MODIFICAR LOS REMOLQUES Y PORTA CONTENEDORES CUANDO EL VIAJE YA ESTE FACTURADO, LIQUIDADO, TERMINADO DEPENDIENDO EL DERECHO DE USUARIOS
	IF (SELECT Derecho FROM CatUsuariosDerechos WHERE IdUsuario = @ModificadoPor  AND IdProceso = 502103)= 1 
	BEGIN
		IF @IdUnidadCarga1 <> (SELECT IdUnidadCarga1 from ProViajes where IdViaje  = @IdViaje)
		BEGIN
			IF EXISTS(SELECT pgv.IdGastoViaje FROM ProGastosViaje  as pgv LEFT JOIN ProViajesTrayectos as pvt on pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadCarga1= @IdUnidadCarga1 and pv.IdViaje = @IdViaje and pgv.IdUnidad = @IdUnidadCarga1) 
				RAISERROR(N'Gastos asociados al primer remolque no es posible modificar.',
				16,
				1
				)
			IF EXISTS(SELECT pvc.IdValeCombustible FROM ProValesCombustible  as pvc	LEFT JOIN ProViajesTrayectos as pvt on pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadCarga1= @IdUnidadCarga1 and pv.IdViaje = @IdViaje AND pvc.CanceladoEl is null AND pvc.IdUnidad = @IdUnidadCarga1) 
				RAISERROR(N'Vales de Combustible asociados al primer remolque no es posible modificar.',
				16,
				1
				)
			UPDATE ProInventarioUnidadesHistorico set IdInventarioUnidad = @IdUnidadCarga1
			where IdInventarioUnidad = (SELECT IdUnidadCarga1 from ProViajes where IdViaje  = @IdViaje) AND IdViaje =@IdViaje 

		END

		IF @IdUnidadDolly <> (SELECT IdUnidadDolly from ProViajes where IdViaje  = @IdViaje)
		BEGIN
			IF EXISTS(SELECT pgv.IdGastoViaje FROM ProGastosViaje  as pgv LEFT JOIN ProViajesTrayectos as pvt on pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadDolly = @IdUnidadDolly and pv.IdViaje = @IdViaje and pgv.IdUnidad = @IdUnidadDolly) 
				RAISERROR(N'Gastos asociados al dolly no es posible modificar.',
				16,
				1
				)
			IF EXISTS(SELECT pvc.IdValeCombustible FROM ProValesCombustible  as pvc	LEFT JOIN ProViajesTrayectos as pvt on pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadDolly = @IdUnidadDolly and pv.IdViaje = @IdViaje AND pvc.CanceladoEl is null AND pvc.IdUnidad = @IdUnidadDolly) 
				RAISERROR(N'Vales de Combustible asociados al dolly remolque no es posible modificar.',
				16,
				1
				)
			UPDATE ProInventarioUnidadesHistorico set IdInventarioUnidad = @IdUnidadDolly
			where IdInventarioUnidad = (SELECT IdUnidadDolly from ProViajes where IdViaje  = @IdViaje) AND IdViaje =@IdViaje 
		END


		IF @IdUnidadCarga2 <> (SELECT IdUnidadCarga2 from ProViajes where IdViaje  = @IdViaje)
		BEGIN
			IF EXISTS(SELECT pgv.IdGastoViaje FROM ProGastosViaje  as pgv LEFT JOIN ProViajesTrayectos as pvt on pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadCarga2= @IdUnidadCarga2 and pv.IdViaje = @IdViaje and pgv.IdUnidad = @IdUnidadCarga2) 
				RAISERROR(N'Gastos asociados al segundo remolque no es posible modificar.',
				16,
				1
				)
			IF EXISTS(SELECT pvc.IdValeCombustible FROM ProValesCombustible  as pvc	LEFT JOIN ProViajesTrayectos as pvt on pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadCarga2= @IdUnidadCarga2 and pv.IdViaje = @IdViaje AND pvc.CanceladoEl is null AND pvc.IdUnidad = @IdUnidadCarga2) 
				RAISERROR(N'Vales de Combustible asociados al segundo remolque no es posible modificar.',
				16,
				1
				)
			UPDATE ProInventarioUnidadesHistorico set IdInventarioUnidad = @IdUnidadCarga2
			where IdInventarioUnidad = (SELECT IdUnidadCarga2 from ProViajes where IdViaje  = @IdViaje) AND IdViaje =@IdViaje 
		END

		----- LA VALIDACION DE CONTENDORES---
		IF @IdUnidadContenedor1 <> (SELECT IdUnidadContenedor1 from ProViajes where IdViaje  = @IdViaje)
		BEGIN
			IF EXISTS(SELECT pgv.IdGastoViaje FROM ProGastosViaje  as pgv LEFT JOIN ProViajesTrayectos as pvt on pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadContenedor1= @IdUnidadContenedor1 and pv.IdViaje = @IdViaje and pgv.IdUnidad = @IdUnidadContenedor1) 
				RAISERROR(N'Gastos asociados al primer contenedor no es posible modificar.',
				16,
				1
				)
			IF EXISTS(SELECT pvc.IdValeCombustible FROM ProValesCombustible  as pvc	LEFT JOIN ProViajesTrayectos as pvt on pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadCarga1= @IdUnidadContenedor1 and pv.IdViaje = @IdViaje AND pvc.CanceladoEl is null AND pvc.IdUnidad = @IdUnidadContenedor1) 
				RAISERROR(N'Vales de Combustible asociados al segundo contenedor no es posible modificar.',
				16,
				1
				)
			UPDATE ProInventarioUnidadesHistorico set IdInventarioUnidad = @IdUnidadContenedor1
			where IdInventarioUnidad = (SELECT IdUnidadContenedor1 from ProViajes where IdViaje  = @IdViaje) AND IdViaje =@IdViaje 
		END


		IF @IdUnidadContenedor2 <> (SELECT IdUnidadContenedor2 from ProViajes where IdViaje  = @IdViaje)
		BEGIN
			IF EXISTS(SELECT pgv.IdGastoViaje FROM ProGastosViaje  as pgv LEFT JOIN ProViajesTrayectos as pvt on pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadContenedor2= @IdUnidadContenedor2 and pv.IdViaje = @IdViaje and pgv.IdUnidad = @IdUnidadContenedor2) 
				RAISERROR(N'Gastos asociados al segundo remolque no es posible modificar.',
				16,
				1
				)
			IF EXISTS(SELECT pvc.IdValeCombustible FROM ProValesCombustible  as pvc	LEFT JOIN ProViajesTrayectos as pvt on pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
						INNER JOIN ProViajes  as pv on pvt.IdViaje = pv.IdViaje where pv.IdUnidadContenedor2= @IdUnidadContenedor2 and pv.IdViaje = @IdViaje AND pvc.CanceladoEl is null AND pvc.IdUnidad = @IdUnidadContenedor2) 
				RAISERROR(N'Vales de Combustible asociados al segundo remolque no es posible modificar.',
				16,
				1
				)
			UPDATE ProInventarioUnidadesHistorico set IdInventarioUnidad = @IdUnidadContenedor2
			where IdInventarioUnidad = (SELECT IdUnidadContenedor2 from ProViajes where IdViaje  = @IdViaje) AND IdViaje =@IdViaje 
		END
		-----
	END
	----Fin de la evaluacion para modificar el convoy 

	If @IdCertificado = 0
		SET @IdCertificado = NULL			

	If @IdFormatoImpresion = 0
		SET @IdFormatoImpresion = NULL

	If @IdUnidadCarga1 = 0
		SET @IdUnidadCarga1 = NULL

	If @IdUnidadCarga2 = 0
		SET @IdUnidadCarga2 = NULL

	If @IdUnidadContenedor1 = 0
		SET @IdUnidadContenedor1 = NULL

	If @IdUnidadContenedor2 = 0
		SET @IdUnidadContenedor2 = NULL
		
	If @IdUnidadDolly = 0
		SET @IdUnidadDolly = NULL
		
    If @IdMonedaValorDeclarado = 0
        SET @IdMonedaValorDeclarado = NULL
        
    If @IdRemitente = 0
        SET @IdRemitente = NULL

    If @IdDestinatario = 0
        SET @IdDestinatario = NULL	

	If @IdTipoViaje = 0
		SET @IdTipoViaje = NULL

	If @IdClasificacionViaje = 0
		SET @IdClasificacionViaje = NULL   

	If @IdTipoUnidad = 0
		SET @IdTipoUnidad = NULL		     	

	IF @IdViajeCompuestoPadre = 0
	BEGIN
		SET @IdViajeCompuestoPadre = NULL  
		SET @IdViajeTrayectoCompuestoPadre = NULL      			
	END	
	ELSE
	BEGIN
		--se valida que el viaje compuesto padre no este cancelado
		IF EXISTS(SELECT CanceladoEl FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre AND CanceladoEl IS NOT NULL)
			RAISERROR(N'El viaje compuesto padre al que se intenta ligar está cancelado',
				16,
				1
				)
		
		----se valida que el viaje compuesto padre no este facturado
		--IF (SELECT PendienteFacturar FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre) = 0
		--	RAISERROR(N'El viaje compuesto padre al que se intenta ligar está facturado',
		--		16,
		--		1
		--		)

		----se valida que el viaje compuesto padre no este facturado
		--IF (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre) = 1
		--	RAISERROR(N'El viaje compuesto padre al que se intenta ligar está facturado',
		--		16,
		--		1
		--		)				
		
		--se valida que el viaje compuesto padre no tenga mas de un trayecto <***No aplica
		--IF (SELECT COUNT(*) FROM ProViajesTrayectos WHERE IdViaje = @IdViajeCompuestoPadre) != 1
		--	RAISERROR(N'El viaje compuesto padre al que se intenta ligar tiene más de un trayecto',
		--		16,
		--		1
		--		)
		
		
		--If EXISTS(Select IdViajeTrayecto from ProViajesTrayectos Where IdViaje = @IdViaje And Isnull(Salida,0) > 0)
		--	RAISERROR(N'Alguno de los trayectos del viaje tienen salida, por lo que no se puede Asignar a un viaje compuesto.',
		--			16,
		--			1
		--			)

		----se valida que el viaje compuesto padre no tenga referenciado un viaje compuesto padre es decir que sea hijo
		--IF EXISTS(SELECT IdViajeCompuestoPadre FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre AND IdViajeCompuestoPadre IS NOT NULL)
		--	RAISERROR(N'El viaje compuesto padre al que se intenta ligar ya está ligado a un viaje compuesto',
		--		16,
		--		1
		--		)

		--se valida que el viaje compuesto padre no tenga hijos
		--IF EXISTS(SELECT IdViaje FROM ProViajes WHERE IdViajeCompuestoPadre = @IdViajeCompuestoPadre AND IdViaje <> @IdViaje)
		--	RAISERROR(N'El viaje compuesto padre al que se intenta ligar ya tiene ligado a otro viaje',
		--		16,
		--		1
		--		)				
	END
	
	--Consultar anticipos autorizados por login
	IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesTrayectosAutorizaMasGastosVales
	
		SELECT ATT_Secuencia,ATT_NoViajeCliente,ATT_IdProceso,ATT_IdUsuarioAutorizaGasto,ATT_IdUsuarioAutorizaVales
		INTO #TempProViajesTrayectosAutorizaMasGastosVales
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosAutorizaMasGastosVales',2) 
		WITH (ATT_Secuencia int,ATT_NoViajeCliente varchar(30),ATT_IdProceso int,ATT_IdUsuarioAutorizaGasto int,ATT_IdUsuarioAutorizaVales int)
		
		EXEC sp_xml_removedocument @docHandle
	END	

	/*SOLICITUD 4208 SECCION PARA AGREGAR LA DISTRIBUCION DE LOS CONCEPTOS EN UNA VARIABLE TABLA*/
	IF @dsProViajesTrayectosDistribucionConceptosFacturacion IS NOT NULL
	BEGIN
		
		INSERT INTO @TempProViajesTrayectosDistribucionConceptosFacturacion(COL_IdViajeTrayecto,COL_IdRutaTrayecto,COL_Secuencia,COL_IdConceptoFacturacion,COL_Importe,COL_IdViajeTrayectoDistribucionConceptoFacturacion,COL_TipoTrayecto)
		SELECT  COL_IdViajeTrayecto = T.Item.value('COL_IdViajeTrayecto[1]', 'int')
			   ,COL_IdRutaTrayecto = T.Item.value('COL_IdRutaTrayecto[1]', 'int')
			   ,COL_Secuencia = T.Item.value('COL_Secuencia[1]', 'int')
			   ,COL_IdConceptoFacturacion = T.Item.value('COL_IdConceptoFacturacion[1]', 'int')
			   ,COL_Importe = T.Item.value('COL_Importe[1]', 'money')
			   ,COL_IdViajeTrayectoDistribucionConceptoFacturacion = T.Item.value('COL_IdViajeTrayectoDistribucionConceptoFacturacion[1]', 'int')
			   ,COL_TipoTrayecto =  T.Item.value('COL_TipoTrayecto[1]', 'tinyint')
		FROM   @dsProViajesTrayectosDistribucionConceptosFacturacion.nodes('WINDEV_TABLE/ProViajesTrayectosDistribucionConceptosFacturacion') AS T(Item);

	END
	/*FIN SOLICITUD 4208*/

	--SECCION PARA AGREGAR Las descripcion/materiales		
	IF @dsProViajesDescripcionesCarga IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesDescripcionesCarga
			
		SELECT ATT_IdViajeDescripcionCarga,ATT_Cantidad,ATT_IdUnidadEmbalaje,ATT_Descripcion,ATT_Peso,ATT_IdUnidadPeso,ATT_Tarifa,ATT_Importe,
		ATT_AplicarTarifaPor,ATT_ImporteBaseLiquidacion,ATT_ImporteLiquidar,ATT_ClavesSATXML ,ATT_Consecutivo, ATT_EstaSiendoImportado
		INTO #TempProViajesDescripcionesCarga
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesDescripcionesCarga',2) 
		WITH (ATT_IdViajeDescripcionCarga int,ATT_Cantidad decimal(15,4),ATT_IdUnidadEmbalaje int,ATT_Descripcion varchar(1024),ATT_Peso decimal(15,4),
		ATT_IdUnidadPeso int,ATT_Tarifa float,ATT_Importe money,ATT_AplicarTarifaPor tinyint,ATT_ImporteBaseLiquidacion float,ATT_ImporteLiquidar money,ATT_ClavesSATXML varchar(max),ATT_Consecutivo int, ATT_EstaSiendoImportado TINYINT)

		EXEC sp_xml_removedocument @docHandle
		
		IF EXISTS(SELECT pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt INNER JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion WHERE pvt.IdViaje = @IdViaje AND pl.CerradaEl IS NOT NULL AND pl.TipoLiquidacion = 7)
		BEGIN
			IF EXISTS(SELECT * FROM #TempProViajesDescripcionesCarga WHERE ATT_IdViajeDescripcionCarga = 0)
				RAISERROR(N'No se puede agregar más descripciones de carga porque hay un viaje/trayecto que tiene la liquidación cerrada tipo 7)porcentaje sobre el importe base de la tarifa del material transportado',
					16,
					1
					)	
		END

		DECLARE CursorProViajesDescripcionesCarga CURSOR LOCAL FOR
		SELECT * FROM #TempProViajesDescripcionesCarga
		
		OPEN CursorProViajesDescripcionesCarga
		FETCH NEXT FROM CursorProViajesDescripcionesCarga
		INTO @CursorT_IdViajeDescripcionCarga,@CursorT_Cantidad,@CursorT_IdUnidadEmbalaje,@CursorT_Descripcion,@CursorT_Peso,@CursorT_IdUnidadPeso,@CursorT_Tarifa,@CursorT_Importe,@CursorT_AplicarTarifaPor,@CursorT_ImporteBaseLiquidacion,@CursorT_ImporteLiquidar,@CursorT_ClavesSATXML,@CursorT_Consecutivo, @CursorT_EstaSiendoImportado
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @IdViajeDescripcionCarga = @CursorT_IdViajeDescripcionCarga
			
			IF @CursorT_IdViajeDescripcionCarga <> 0 
			BEGIN
				UPDATE ProViajesDescripcionesCarga 
					SET
						  ProViajesDescripcionesCarga.Cantidad			        = @CursorT_Cantidad
						, ProViajesDescripcionesCarga.DescripcionCarga	        = @CursorT_Descripcion
						, ProViajesDescripcionesCarga.Importe			        = @CursorT_Importe
						, ProViajesDescripcionesCarga.Peso				        = @CursorT_Peso
						, ProViajesDescripcionesCarga.Tarifa			        = @CursorT_Tarifa
						, ProViajesDescripcionesCarga.ModificadoPor		        = @ModificadoPor
						, ProViajesDescripcionesCarga.ModificadoEl		        = @ModificadoEl
						, ProViajesDescripcionesCarga.ImporteBaseLiquidacion    = @CursorT_ImporteBaseLiquidacion
						, ProViajesDescripcionesCarga.ImporteLiquidar	        = @CursorT_ImporteLiquidar
						, ProViajesDescripcionesCarga.Consecutivo		        = @CursorT_Consecutivo
				FROM ProViajesDescripcionesCarga
				WHERE ProViajesDescripcionesCarga.IdViajeDescripcionCarga = @CursorT_IdViajeDescripcionCarga
			END
			ELSE
			BEGIN
				INSERT INTO ProViajesDescripcionesCarga(CreadoEl,CreadoPor,Cantidad,IdUnidadMedidaEmbalaje,DescripcionCarga,IdUnidadMedidaPeso,IdViaje,Importe,Peso,Tarifa,TarifaAplicadaPor,ImporteBaseLiquidacion,ImporteLiquidar,Consecutivo, CreadoDesde)
				VALUES(@ModificadoEl,@ModificadoPor,@CursorT_Cantidad,@CursorT_IdUnidadEmbalaje,@CursorT_Descripcion,@CursorT_IdUnidadPeso,@IdViaje,@CursorT_Importe,@CursorT_Peso,@CursorT_Tarifa,@CursorT_AplicarTarifaPor,@CursorT_ImporteBaseLiquidacion,@CursorT_ImporteLiquidar,@CursorT_Consecutivo, @CursorT_EstaSiendoImportado)
				
				SET @IdViajeDescripcionCarga = (SELECT IDENT_CURRENT('ProViajesDescripcionesCarga'))
			END
			
			
			--Seccion para las claves del sat de los materiales 
			---se movio el bloque para la solicitud 4750 sprint 2021-08
			IF ISNULL(@CursorT_ClavesSATXML,'') <> ''
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @CursorT_ClavesSATXML
					SELECT
						 @IdViajeDescripcionCarga AS ATT_IdViajeDescripcionCarga
						,ATT_ClaveSAT
						,ATT_DescripcionSAT
						,ATT_CatalogoSAT
						,ATT_Opcional
					INTO #TempProViajesDescripcionesCargaClavesSAT
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasDescripcionesCargaTarifasClavesSAT',2) 
					WITH (
						 ATT_IdViajeDescripcionCarga int
						,ATT_ClaveSAT varchar(10) COLLATE Modern_Spanish_CS_AS
						,ATT_DescripcionSAT varchar(max) COLLATE Modern_Spanish_CS_AS
						,ATT_CatalogoSAT varchar(50) COLLATE Modern_Spanish_CS_AS
						,ATT_Opcional nvarchar(100) COLLATE Modern_Spanish_CS_AS)

			
					EXEC sp_xml_removedocument @docHandle

					UPDATE PVD SET
					PVD.ClaveSAT = T.ATT_ClaveSAT,
					PVD.Opcional = T.ATT_Opcional,
					PVD.UltimaModificacion = @ModificadoEl
					FROM
					ProViajesDescripcionesCargaClavesSAT AS PVD
					INNER JOIN #TempProViajesDescripcionesCargaClavesSAT AS T ON T.ATT_IdViajeDescripcionCarga = PVD.IdViajeDescripcionCarga
					WHERE T.ATT_CatalogoSAT = PVD.CatalogoSAT

					INSERT INTO ProViajesDescripcionesCargaClavesSAT(IdViajeDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					SELECT 
					ATT_IdViajeDescripcionCarga
				   ,ATT_ClaveSAT 
				   ,ATT_CatalogoSAT 
				   ,ATT_Opcional 
				   ,@ModificadoEl
					FROM #TempProViajesDescripcionesCargaClavesSAT
					WHERE
					ATT_IdViajeDescripcionCarga NOT IN (
					SELECT SUB.IdViajeDescripcionCarga FROM ProViajesDescripcionesCargaClavesSAT AS SUB 
					WHERE 
					SUB.ClaveSAT = ATT_ClaveSAT
					AND SUB.CatalogoSAT = ATT_CatalogoSAT)

					DROP TABLE #TempProViajesDescripcionesCargaClavesSAT
				END
		DELETE FROM ProViajesDescripcionesCargaClavesSAT WHERE IdViajeDescripcionCarga = @CursorT_IdViajeDescripcionCarga AND UltimaModificacion <> @ModificadoEl
		FETCH NEXT FROM CursorProViajesDescripcionesCarga
		INTO @CursorT_IdViajeDescripcionCarga,@CursorT_Cantidad,@CursorT_IdUnidadEmbalaje,@CursorT_Descripcion,@CursorT_Peso,@CursorT_IdUnidadPeso,@CursorT_Tarifa,@CursorT_Importe,@CursorT_AplicarTarifaPor,@CursorT_ImporteBaseLiquidacion,@CursorT_ImporteLiquidar,@CursorT_ClavesSATXML,@CursorT_Consecutivo,@CursorT_EstaSiendoImportado
		END

		CLOSE CursorProViajesDescripcionesCarga
		DEALLOCATE CursorProViajesDescripcionesCarga
		
		
	END

	IF EXISTS(SELECT pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt INNER JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion WHERE pvt.IdViaje = @IdViaje AND pl.CerradaEl IS NOT NULL AND pl.TipoLiquidacion = 7)
	BEGIN
		IF EXISTS(SELECT * FROM ProViajesDescripcionesCarga WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl)
			RAISERROR(N'No se puede eliminar descripciones de carga porque hay un viaje/trayecto que tiene la liquidación cerrada tipo 7)porcentaje sobre el importe base de la tarifa del material transportado',
				16,
				1
				)	
	END

	DELETE FROM ProViajesDescripcionesCarga WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	--agrega trayectos del viaje	
	--Se agregó un nuevo campo en el xml de trayctos y como cursor el campo de "EnvioNotificacionMovil", para que se actualize junto con el trayecto (Solicitud 000013)
	IF @dsProViajesTrayectos IS NOT NULL
	BEGIN
		-----------------------------------------Cursor trayectos del viaje---------------------------------------------------------@CursorT_IdProveedor
		--Set @ContadorDeCompuestos = 0
		-----------------Se pregunta si el id IdViajeTrayecto Padre cambio----------------------------------------------- 
		Set @IdViajeCompuestoPadreAnterior = (Select IdViajeCompuestoPadre from ProViajes where IdViaje = @IdViaje)
		--Set @IdViajeTrayectoCompuestoPadreAnterior = (Select Top 1 IdViajeTrayecto from ProViajesTrayectos Where EsCompuesto = 1 and IdViaje = @IdViajeCompuestoPadreAnterior)
		Set @IdViajePadreNuevo = (Select Top 1 IdViaje From ProViajesTrayectos Where IdViajeTrayecto = @IdViajeTrayectoCompuestoPadre)
		
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesTrayectos	
		SELECT ATT_IdViajeTrayecto,ATT_CodigoUnidadCamion,ATT_IdOperador,ATT_IdUnidadCamion,ATT_Kilometros,ATT_Horas,ATT_NombreOperador,ATT_PlacasUnidadCamion,
		ATT_Secuencia,ATT_IdOrigen,ATT_IdDestino,ATT_NombreOperadorPermisionario,ATT_NoCartaPortePermisionario,ATT_NoFacturaPermisionario,ATT_IdMonedaPermisionario,
		ATT_FechaFacturaPermisionario,ATT_FechaRecepcionFacturaPermisionario,ATT_ConceptoPermisionario,
		ATT_AplicarAnticipo,ATT_Anticipo,ATT_MonedaAnticipo,ATT_AplicarValeDeCombustible,ATT_LitrosAutorizados,ATT_IdProveedor,
		ATT_GeneradoAnticipo,ATT_GeneradoVale,ATT_EsCompuesto,ATT_Tienda,ATT_NumeroOrden,ATT_Monto,ATT_CargadoVacioRemolque1,ATT_CargadoVacioRemolque2,ATT_FechaPagoFactura,
		ATT_Millas,ATT_GalonesAutorizados,ATT_IdViajeTrayectoCompuesto,ATT_ETA,ATT_Referencia,ATT_EnvioNotificacionMovil
		-- Solicitud 675
		,ATT_FechaHoraCarga
		,ATT_FechaHoraEstimadaCarga
		,ATT_FechaHoraDescarga
		,ATT_FechaHoraEstimadaDescarga
		-- Solicitud 866
		,ATT_CamionPer
		,ATT_UbicacionesXML
		--SOLICITUD 4669
		,ATT_PermisionarioXML
		,ATT_IdOperadorAuxiliar
		,ATT_NombreOperadorAuxiliar
		INTO #TempProViajesTrayectos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectos',2) 
		WITH (ATT_IdViajeTrayecto int,ATT_Secuencia int,ATT_IdUnidadCamion int,ATT_CodigoUnidadCamion varchar(16),ATT_PlacasUnidadCamion varchar(9),
		ATT_IdOperador int,ATT_NombreOperador varchar(100),ATT_Kilometros int,ATT_Horas decimal(15,2),ATT_IdOrigen int, ATT_IdDestino int,ATT_NombreOperadorPermisionario varchar(100)
		,ATT_NoCartaPortePermisionario varchar(15),ATT_NoFacturaPermisionario varchar(15),ATT_IdMonedaPermisionario int,
		ATT_FechaFacturaPermisionario datetime,ATT_FechaRecepcionFacturaPermisionario datetime,ATT_ConceptoPermisionario varchar(50),
		ATT_AplicarAnticipo bit,ATT_Anticipo money,ATT_MonedaAnticipo varchar(7),ATT_AplicarValeDeCombustible bit,ATT_LitrosAutorizados decimal(15,2),ATT_IdProveedor int,
		ATT_GeneradoAnticipo bit,ATT_GeneradoVale bit, ATT_EsCompuesto int, ATT_Tienda varchar(50),ATT_NumeroOrden int,ATT_Monto money,ATT_CargadoVacioRemolque1 bit,ATT_CargadoVacioRemolque2 bit,
		ATT_FechaPagoFactura datetime,ATT_Millas decimal(15,2),ATT_GalonesAutorizados decimal(15,2),ATT_IdViajeTrayectoCompuesto int,ATT_ETA decimal(15,2),ATT_Referencia varchar(20),ATT_EnvioNotificacionMovil bit
		-- Solicitud 675
		,ATT_FechaHoraCarga datetime
		,ATT_FechaHoraEstimadaCarga datetime
		,ATT_FechaHoraDescarga datetime
		,ATT_FechaHoraEstimadaDescarga datetime
		-- Solicitud 866
		,ATT_CamionPer varchar(50)
		,ATT_UbicacionesXML varchar(max)
		,ATT_PermisionarioXML varchar(max)
		,ATT_IdOperadorAuxiliar int
		,ATT_NombreOperadorAuxiliar varchar(100))

		EXEC sp_xml_removedocument @docHandle
		
		-----SE COMENTO POR LA SOLICITUD 12067 DE VIAJES TERMINADOS Y CON ALGUN TRAYECTO LIQUIDADO
		--- Validar agregar trayectos cuando el viaje esta terminado y con el parametro activo
		--DECLARE @ViajeTerminado int
		--SET @ViajeTerminado = (SELECT TOP 1 ViajeTerminado FROM ProViajes WHERE IdViaje = @IdViaje)	
		--IF @ViajeTerminado = 1 AND EXISTS(SELECT Valor FROM SisParametrosValores WHERE Parametro ='PoderAgregarTrayectosEnViajeTerminado' and Valor = 1)
		
		--   IF (SELECT COUNT(*) from #TempProViajesTrayectos) <> (select COUNT(*) from ProViajesTrayectos where IdViaje = @IdViaje)
		--    BEGIN 
		--	   IF EXISTS(SELECT top 1 pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt
		--												  inner join ProLiquidaciones AS pl on pvt.IdLiquidacion = pl.IdLiquidacion
		--												  WHERE pvt.IdViaje = @IdViaje
		--												  AND pl.CerradaEl IS NOT NULL)			  
		--		  RAISERROR(N'No es posible agregar mas trayectos al viaje, los trayectos asignados viaje han sido liquidados',
		--			  16,
		--			  1)
					  
		--	END
		-----

		DECLARE ProViajesTrayectosCursor CURSOR LOCAL FOR
		SELECT * FROM #TempProViajesTrayectos
		


		OPEN ProViajesTrayectosCursor
		FETCH NEXT FROM ProViajesTrayectosCursor
		INTO @CursorT_IdViajeTrayecto,@CursorT_CodigoUnidadCamion,@CursorT_IdOperador,@CursorT_IdUnidadCamion,@CursorT_Kilometros,@CursorT_Horas,@CursorT_NombreOperador,
			@CursorT_PlacasUnidadCamion,@CursorT_Secuencia,@CursorT_IdOrigen,@CursorT_IdDestino,@CursorT_NombreOperadorPermisionario,						
			 @CursorT_NoCartaPortePermisionario,@CursorT_NoFacturaPermisionario,@CursorT_IdMonedaPermisionario,@CursorT_FechaFacturaPermisionario,			 
			 @CursorT_FechaRecepcionFacturaPermisionario,@CursorT_ConceptoPermisionario,			 
			 @CursorT_AplicarAnticipo,@CursorT_Anticipo,@CursorT_MonedaAnticipo,@CursorT_AplicarValeDeCombustible,@CursorT_LitrosAutorizados,@CursorT_IdProveedor,
			 @ATT_GeneradoAnticipo,@ATT_GeneradoVale,@CursorT__EsCompuesto,@CursorT_Tienda,@CursorT_NumeroOrden,@CursorT_Monto,@CursorT_CargadoVacioRemolque1,@CursorT_CargadoVacioRemolque2,
			 @CursorT_FechaPagoFactura,@CursorT_Millas,@CursorT_GalonesAutorizados,@CursorT_IdViajeTrayectoCompuesto,@CursorT_ETA,@CursorT_Referencia,@CursorT_EnvioNotificacionMovil
			 -- Solicitud 675
			 ,@CursorT_FechaHoraCarga
			 ,@CursorT_FechaHoraEstimadaCarga
			 ,@CursorT_FechaHoraDescarga
			 ,@CursorT_FechaHoraEstimadaDescarga
			 -- Solicitud 866
			 ,@CursorT_CamionPer
			 ,@CursorT_UbicacionesXML
			 ,@CursorT_PermisionarioXML
			 ,@CursorT_IdOperadorAux
			 ,@CursorT_NombreOperadorAux
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @CursorT_IdViajeTrayecto = 0			
			BEGIN
			SET @IdViajeTrayectoCompuestoPadreAnterior = (Select IdViajeTrayectoCompuestoPadre from ProViajesTrayectos Where EsCompuesto = 1 and IdViajeTrayecto = @CursorT_IdViajeTrayecto)
				INSERT INTO ProViajesTrayectos(CreadoEl,CreadoPor,CodigoUnidadCamion,IdOperador,IdUnidadCamion,IdViaje,Kilometros,NombreOperador,PlacasUnidadCamion,
				Secuencia,IdOrigen,IdDestino,CargadoVacioUnidadCarga1,CargadoVacioUnidadCarga2,NombreOperadorPermisionario,CartaPortePermisionario,FacturaPermisionario,IdMonedaPermisionario,FechaFacturaPermisionario,FechaRecepcionFacturaPermisionario,ConceptoPermisionario,
				AplicarAnticipo,AnticipoAutorizado,AnticipoAutorizadoMoneda,AplicarValeDeCombustible,LitrosAutorizados,EsCompuesto,Tienda,NumeroOrden,Monto,FechaPagoFactura,Millas,GalonesAutorizados,IdViajeTrayectoCompuestoPadre,ETA,Referencia,EnvioNotificacionMovil
				-- Solicidut 675
				,FechaHoraCarga
				,FechaHoraEstimadaCarga
				,FechaHoraDescarga
				,FechaHoraEstimadaDescarga
				-- Solicitud 866
				,CamionPer
				-- Solicitud 1005
				,IdProveedor
				,IdOperadorAuxiliar
				,NombreOperadorAuxiliar)
				VALUES(@ModificadoEl,@ModificadoPor,@CursorT_CodigoUnidadCamion,CASE @CursorT_IdOperador WHEN 0 THEN NULL ELSE @CursorT_IdOperador END,CASE @CursorT_IdUnidadCamion WHEN 0 THEN NULL ELSE @CursorT_IdUnidadCamion END,@IdViaje,@CursorT_Kilometros,@CursorT_NombreOperador,@CursorT_PlacasUnidadCamion,
						@CursorT_Secuencia,@CursorT_IdOrigen,@CursorT_IdDestino,@CursorT_CargadoVacioRemolque1,@CursorT_CargadoVacioRemolque2,@CursorT_NombreOperadorPermisionario,@CursorT_NoCartaPortePermisionario,@CursorT_NoFacturaPermisionario,
						CASE @CursorT_IdMonedaPermisionario WHEN 0 THEN NULL ELSE @CursorT_IdMonedaPermisionario END,@CursorT_FechaFacturaPermisionario,@CursorT_FechaRecepcionFacturaPermisionario,@CursorT_ConceptoPermisionario,
						CASE @CursorT_AplicarAnticipo WHEN 0 THEN NULL ELSE @CursorT_AplicarAnticipo END,
						CASE @CursorT_Anticipo WHEN 0 THEN NULL ELSE @CursorT_Anticipo END,
						CASE @CursorT_MonedaAnticipo WHEN '' THEN NULL ELSE @CursorT_MonedaAnticipo END,
						CASE @CursorT_AplicarValeDeCombustible WHEN 0 THEN NULL ELSE @CursorT_AplicarValeDeCombustible END,
						CASE @CursorT_LitrosAutorizados WHEN 0 THEN NULL ELSE @CursorT_LitrosAutorizados END, 
						CASE @CursorT__EsCompuesto WHEN 0 THEN NULL ELSE @CursorT__EsCompuesto END,
						@CursorT_Tienda,@CursorT_NumeroOrden,@CursorT_Monto,@CursorT_FechaPagoFactura,@CursorT_Millas,@CursorT_GalonesAutorizados,@CursorT_IdViajeTrayectoCompuesto,@CursorT_ETA,@CursorT_Referencia,@CursorT_EnvioNotificacionMovil
						-- Solicitud 675
						,@CursorT_FechaHoraCarga
						,@CursorT_FechaHoraEstimadaCarga
						,@CursorT_FechaHoraDescarga
						,@CursorT_FechaHoraEstimadaDescarga
						-- Solicitud 866
						,@CursorT_CamionPer
						-- Solcitud 1005
						,@CursorT_IdProveedor
						,CASE @CursorT_IdOperadorAux WHEN 0 THEN NULL ELSE @CursorT_IdOperadorAux END
						,@CursorT_NombreOperadorAux)
				SET @IdViajeTrayecto = (SELECT IDENT_CURRENT('ProViajesTrayectos'))	
				/*SOLICITUD 4669 */
				/**Permisionarios*/
				IF @CursorT_PermisionarioXML <> '' 
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @CursorT_PermisionarioXML
			
					SELECT  ATT_RFC,ATT_Licencia,ATT_IdPais,ATT_CodigoPostal,ATT_NoRegistroIdentidadFiscal,ATT_IdEstado,ATT_Municipio
							,ATT_Localidad,ATT_Colonia,ATT_Calle,ATT_NoInterior,ATT_NoExterior,ATT_Modelo,ATT_TiporemolqueSAT,ATT_Placas,ATT_PermisoSCTSAT
							,ATT_CompaniaSeguros,ATT_NumeroSeguro,ATT_PermisoSCT 
					INTO #TempProViajesTrayectosPermisionarios
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosPermisionarios',2) 
					WITH(ATT_RFC varchar(13),ATT_Licencia varchar(19),ATT_IdPais int,ATT_CodigoPostal varchar(10),ATT_NoRegistroIdentidadFiscal varchar(20),ATT_IdEstado varchar(5),ATT_Municipio varchar(120)
						,ATT_Localidad varchar(120),ATT_Colonia varchar(120),ATT_Calle varchar(100),ATT_NoInterior varchar(10),ATT_NoExterior varchar(10),ATT_Modelo smallint,ATT_TiporemolqueSAT varchar(20),ATT_Placas varchar(9),ATT_PermisoSCTSAT varchar(20)
						,ATT_CompaniaSeguros varchar(50),ATT_NumeroSeguro varchar(30),ATT_PermisoSCT varchar(30))
			
					EXEC sp_xml_removedocument @docHandle
						IF (SELECT ISNULL(ATT_RFC,'') FROM #TempProViajesTrayectosPermisionarios)<>'' OR (SELECT ISNULL(ATT_NoRegistroIdentidadFiscal,'') FROM #TempProViajesTrayectosPermisionarios)<>'' BEGIN
						--CHOFER PERMISIONARIO
							INSERT INTO ProViajesTrayectosChoferPermisionario(IdViajeTrayecto,RFC,Licencia,IdPais,CodigoPostal,NoRegistroIdentidadFiscal,IdEstado,Municipio,Localidad,Colonia,Calle,NoInterior,NoExterior)
							SELECT @IdViajeTrayecto,ATT_RFC ,ATT_Licencia ,ATT_IdPais,ATT_CodigoPostal,ATT_NoRegistroIdentidadFiscal ,ATT_IdEstado
								,ATT_Municipio,ATT_Localidad ,ATT_Colonia ,ATT_Calle ,ATT_NoInterior,ATT_NoExterior
							FROM #TempProViajesTrayectosPermisionarios
						END
						--UNIDAD PERMISIONARIO
						 IF (SELECT ISNULL(ATT_Modelo,0) FROM #TempProViajesTrayectosPermisionarios )<>0 BEGIN
							INSERT INTO ProViajesTrayectosUnidadPermisionario(IdViajeTrayecto,Modelo,TiporemolqueSAT,Placas,PermisoSCTSAT,PermisoSCT,CompaniaSeguros,NumeroSeguro)
							SELECT @IdViajeTrayecto,ATT_Modelo,ATT_TiporemolqueSAT,ATT_Placas,ATT_PermisoSCTSAT,ATT_PermisoSCT,ATT_CompaniaSeguros,ATT_NumeroSeguro 
							FROM #TempProViajesTrayectosPermisionarios
						 END
			
					DROP TABLE #TempProViajesTrayectosPermisionarios
				END
				/*SOLICITUD 4208*/
				INSERT INTO ProViajesTrayectosDistribucionConceptosFacturacion(IdViajeTrayecto,IdRutaTrayecto,IdConceptoFacturacion,Secuencia,Importe,UltimaModificacion,TipoTrayecto)
				SELECT 
				 @IdViajeTrayecto
				,COL_IdRutaTrayecto
				,COL_IdConceptoFacturacion
				,COL_Secuencia
				,COL_Importe
				,@ModificadoEl
				,COL_TipoTrayecto
				FROM @TempProViajesTrayectosDistribucionConceptosFacturacion
				WHERE COL_Secuencia = @CursorT_Secuencia
				/*FIN SOLICITUD 4208*/
			END
			ELSE
			BEGIN
				SET @IdViajeTrayectoCompuestoPadreAnterior = (Select IdViajeTrayectoCompuestoPadre from ProViajesTrayectos Where EsCompuesto = 1 and IdViajeTrayecto = @CursorT_IdViajeTrayecto)
				-- Seccion para validar viajes compuestos que no tienen referencia directa de a que trayectos estan ligados--
				IF @IdViajeTrayectoCompuestoPadreAnterior = 0 OR @IdViajeTrayectoCompuestoPadreAnterior IS NULL	
				BEGIN
					IF ( SELECT COUNT(*) FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND EsCompuesto = 1 ) = 1 AND NOT EXISTS ( SELECT IdViajeTrayectoCompuestoPadre FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND EsCompuesto = 1 AND IdViajeTrayectoCompuestoPadre IS NOT NULL )
					BEGIN 
						SET @IdViajeTrayectoCompuestoPadreAnterior = ( SELECT pvt.IdViajeTrayecto FROM ProViajes AS pv INNER JOIN ProViajesTrayectos AS pvt On pv.IdViaje = pvt.IdViaje WHERE pv.IdViaje = @IdViajeCompuestoPadreAnterior And pvt.EsCompuesto = 1  )
					END
				END
				UPDATE ProViajesTrayectos SET
					ProViajesTrayectos.CodigoUnidadCamion = @CursorT_CodigoUnidadCamion,
					ProViajesTrayectos.IdOperador = CASE @CursorT_IdOperador WHEN 0 THEN NULL ELSE @CursorT_IdOperador END,
					ProViajesTrayectos.IdUnidadCamion = CASE @CursorT_IdUnidadCamion WHEN 0 THEN NULL ELSE @CursorT_IdUnidadCamion END,
					ProViajesTrayectos.Kilometros = @CursorT_Kilometros,
                    ProViajesTrayectos.Horas = @CursorT_Horas,
					ProViajesTrayectos.NombreOperador = @CursorT_NombreOperador,
					ProViajesTrayectos.IdOrigen = @CursorT_IdOrigen,
					ProViajesTrayectos.IdDestino = @CursorT_IdDestino,
					ProViajesTrayectos.PlacasUnidadCamion = @CursorT_PlacasUnidadCamion,
					ProViajesTrayectos.Secuencia = @CursorT_Secuencia,
					ProViajesTrayectos.ModificadoEl = @ModificadoEl,
					ProViajesTrayectos.ModificadoPor = @ModificadoPor,
					ProViajesTrayectos.NombreOperadorPermisionario = @CursorT_NombreOperadorPermisionario,
					ProViajesTrayectos.CartaPortePermisionario	   = @CursorT_NoCartaPortePermisionario,
					ProViajesTrayectos.FacturaPermisionario        = @CursorT_NoFacturaPermisionario,
					ProViajesTrayectos.IdMonedaPermisionario       = CASE @CursorT_IdMonedaPermisionario WHEN 0 THEN NULL ELSE @CursorT_IdMonedaPermisionario END,
					ProViajesTrayectos.FechaFacturaPermisionario   = @CursorT_FechaFacturaPermisionario,
					ProViajesTrayectos.FechaRecepcionFacturaPermisionario   = @CursorT_FechaRecepcionFacturaPermisionario,
					ProViajesTrayectos.ConceptoPermisionario       = @CursorT_ConceptoPermisionario,					
					ProViajesTrayectos.AplicarAnticipo = CASE @CursorT_AplicarAnticipo WHEN 0 THEN NULL ELSE @CursorT_AplicarAnticipo END,
					ProViajesTrayectos.AnticipoAutorizado = CASE @CursorT_Anticipo WHEN 0 THEN NULL ELSE @CursorT_Anticipo END,
					ProViajesTrayectos.AnticipoAutorizadoMoneda=CASE @CursorT_MonedaAnticipo WHEN '' THEN NULL ELSE @CursorT_MonedaAnticipo END,
					ProViajesTrayectos.AplicarValeDeCombustible=CASE @CursorT_AplicarValeDeCombustible WHEN 0 THEN NULL ELSE @CursorT_AplicarValeDeCombustible END,
					ProViajesTrayectos.LitrosAutorizados =CASE @CursorT_LitrosAutorizados WHEN 0 THEN NULL ELSE @CursorT_LitrosAutorizados END,
					ProViajesTrayectos.EsCompuesto =CASE @CursorT__EsCompuesto WHEN 0 THEN NULL ELSE @CursorT__EsCompuesto END,
					ProViajesTrayectos.Tienda =@CursorT_Tienda,
					ProViajesTrayectos.NumeroOrden =@CursorT_NumeroOrden,
					ProViajesTrayectos.Monto =@CursorT_Monto, 
					ProViajesTrayectos.CargadoVacioUnidadCarga1 = @CursorT_CargadoVacioRemolque1,
					ProViajesTrayectos.CargadoVacioUnidadCarga2 = @CursorT_CargadoVacioRemolque2,
					ProViajesTrayectos.FechaPagoFactura = @CursorT_FechaPagoFactura,
					ProViajesTrayectos.Millas = @CursorT_Millas,
					ProViajesTrayectos.GalonesAutorizados = @CursorT_GalonesAutorizados,
					ProViajesTrayectos.IdViajeTrayectoCompuestoPadre = @CursorT_IdViajeTrayectoCompuesto,
					ProViajesTrayectos.ETA = @CursorT_ETA,
					ProViajesTrayectos.Referencia = @CursorT_Referencia,
					ProViajesTrayectos.EnvioNotificacionMovil = @CursorT_EnvioNotificacionMovil
					-- Solicitud 675
					,ProViajesTrayectos.FechaHoraCarga = @CursorT_FechaHoraCarga
					,ProViajesTrayectos.FechaHoraEstimadaCarga = @CursorT_FechaHoraEstimadaCarga
					,ProViajesTrayectos.FechaHoraDescarga = @CursorT_FechaHoraDescarga
					,ProViajesTrayectos.FechaHoraEstimadaDescarga = @CursorT_FechaHoraEstimadaDescarga
					-- Solicitud 866
					,ProViajesTrayectos.CamionPer = @CursorT_CamionPer
					-- Solicitud 1005
					,ProViajesTrayectos.IdProveedor = @CursorT_IdProveedor
					,ProViajesTrayectos.IdOperadorAuxiliar = CASE @CursorT_IdOperadorAux WHEN 0 THEN NULL ELSE @CursorT_IdOperadorAux END
					,ProViajesTrayectos.NombreOperadorAuxiliar = @CursorT_NombreOperadorAux
				FROM ProViajesTrayectos 
				WHERE IdViajeTrayecto = @CursorT_IdViajeTrayecto
				SET @IdViajeTrayecto = @CursorT_IdViajeTrayecto
				/*SOLICITUD 4669 */
				----BUSCA SI EXISTE EL ID PRIMARIO EN LA TABLA -----
				---CHOFER PERMISIONARIO---
				IF @CursorT_PermisionarioXML <> '' 
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @CursorT_PermisionarioXML
			
					SELECT  ATT_RFC,ATT_Licencia,ATT_IdPais,ATT_CodigoPostal,ATT_NoRegistroIdentidadFiscal,ATT_IdEstado,ATT_Municipio
							,ATT_Localidad,ATT_Colonia,ATT_Calle,ATT_NoInterior,ATT_NoExterior,ATT_Modelo,ATT_TiporemolqueSAT,ATT_Placas,ATT_PermisoSCTSAT
							,ATT_CompaniaSeguros,ATT_NumeroSeguro,ATT_PermisoSCT,ATT_IdViajesTrayectosChoferPermisionario,ATT_IdViajesTrayectosUnidadPermisionario
					INTO #TempProViajesTrayectosPermisionariosUpdate
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosPermisionarios',2) 
					WITH(ATT_RFC varchar(13),ATT_Licencia varchar(19),ATT_IdPais int,ATT_CodigoPostal varchar(10),ATT_NoRegistroIdentidadFiscal varchar(20),ATT_IdEstado varchar(5),ATT_Municipio varchar(120)
						,ATT_Localidad varchar(120),ATT_Colonia varchar(120),ATT_Calle varchar(100),ATT_NoInterior varchar(10),ATT_NoExterior varchar(10),ATT_Modelo smallint,ATT_TiporemolqueSAT varchar(20),ATT_Placas varchar(9),ATT_PermisoSCTSAT varchar(20)
						,ATT_CompaniaSeguros varchar(50),ATT_NumeroSeguro varchar(30),ATT_PermisoSCT varchar(30),ATT_IdViajesTrayectosChoferPermisionario int,ATT_IdViajesTrayectosUnidadPermisionario int)
			
					EXEC sp_xml_removedocument @docHandle
						IF EXISTS(SELECT IdViajesTrayectosChoferPermisionario FROM ProViajesTrayectosChoferPermisionario WHERE IdViajesTrayectosChoferPermisionario= (SELECT ATT_IdViajesTrayectosChoferPermisionario FROM #TempProViajesTrayectosPermisionariosUpdate) AND IdViajeTrayecto = @IdViajeTrayecto) BEGIN
							
								UPDATE ProViajesTrayectosChoferPermisionario SET
								RFC=#TempProViajesTrayectosPermisionariosUpdate.ATT_RFC,
								Licencia=#TempProViajesTrayectosPermisionariosUpdate.ATT_Licencia,
								IdPais=#TempProViajesTrayectosPermisionariosUpdate.ATT_IdPais,
								CodigoPostal=#TempProViajesTrayectosPermisionariosUpdate.ATT_CodigoPostal,
								NoRegistroIdentidadFiscal=#TempProViajesTrayectosPermisionariosUpdate.ATT_NoRegistroIdentidadFiscal,
								IdEstado=#TempProViajesTrayectosPermisionariosUpdate.ATT_IdEstado,
								Municipio=#TempProViajesTrayectosPermisionariosUpdate.ATT_Municipio,
								Localidad=#TempProViajesTrayectosPermisionariosUpdate.ATT_Localidad,
								Colonia=#TempProViajesTrayectosPermisionariosUpdate.ATT_Colonia,
								Calle=#TempProViajesTrayectosPermisionariosUpdate.ATT_Calle,
								NoInterior=#TempProViajesTrayectosPermisionariosUpdate.ATT_NoInterior,
								NoExterior=#TempProViajesTrayectosPermisionariosUpdate.ATT_NoExterior
								FROM ProViajesTrayectosChoferPermisionario 
								INNER JOIN #TempProViajesTrayectosPermisionariosUpdate 
								ON ProViajesTrayectosChoferPermisionario.IdViajesTrayectosChoferPermisionario= #TempProViajesTrayectosPermisionariosUpdate.ATT_IdViajesTrayectosChoferPermisionario
								AND ProViajesTrayectosChoferPermisionario.IdViajeTrayecto = @IdViajeTrayecto
							
						END
						ELSE /*SI NO EXISTE INSERTA NUEVO REGISTRO DE PERMISIONARIOS*/
						BEGIN
							IF (SELECT ISNULL(ATT_RFC,'') FROM #TempProViajesTrayectosPermisionariosUpdate)<>'' OR (SELECT ISNULL(ATT_NoRegistroIdentidadFiscal,'') FROM #TempProViajesTrayectosPermisionariosUpdate)<>'' BEGIN
							--CHOFER PERMISIONARIO
								INSERT INTO ProViajesTrayectosChoferPermisionario(IdViajeTrayecto,RFC,Licencia,IdPais,CodigoPostal,NoRegistroIdentidadFiscal,IdEstado,Municipio,Localidad,Colonia,Calle,NoInterior,NoExterior)
								SELECT @IdViajeTrayecto,ATT_RFC ,ATT_Licencia ,ATT_IdPais,ATT_CodigoPostal,ATT_NoRegistroIdentidadFiscal ,ATT_IdEstado
									,ATT_Municipio,ATT_Localidad ,ATT_Colonia ,ATT_Calle ,ATT_NoInterior,ATT_NoExterior
								FROM #TempProViajesTrayectosPermisionariosUpdate
							END
						END
				----UNIDAD PERMISIONARIA----
						IF EXISTS(SELECT IdViajesTrayectosUnidadPermisionario FROM ProViajesTrayectosUnidadPermisionario WHERE IdViajesTrayectosUnidadPermisionario= (SELECT ATT_IdViajesTrayectosUnidadPermisionario FROM #TempProViajesTrayectosPermisionariosUpdate) AND IdViajeTrayecto = @IdViajeTrayecto) BEGIN
							 IF (SELECT ISNULL(ATT_Modelo,0) FROM #TempProViajesTrayectosPermisionariosUpdate )<>0 BEGIN 
								UPDATE ProViajesTrayectosUnidadPermisionario SET
								Modelo=#TempProViajesTrayectosPermisionariosUpdate.ATT_Modelo,
								TiporemolqueSAT=#TempProViajesTrayectosPermisionariosUpdate.ATT_TiporemolqueSAT,
								Placas=#TempProViajesTrayectosPermisionariosUpdate.ATT_Placas,
								PermisoSCTSAT=#TempProViajesTrayectosPermisionariosUpdate.ATT_PermisoSCTSAT,
								PermisoSCT= #TempProViajesTrayectosPermisionariosUpdate.ATT_PermisoSCT,
								CompaniaSeguros=#TempProViajesTrayectosPermisionariosUpdate.ATT_CompaniaSeguros,
								NumeroSeguro=#TempProViajesTrayectosPermisionariosUpdate.ATT_NumeroSeguro
								FROM ProViajesTrayectosUnidadPermisionario 
								INNER JOIN #TempProViajesTrayectosPermisionariosUpdate 
								ON ProViajesTrayectosUnidadPermisionario.IdViajesTrayectosUnidadPermisionario= #TempProViajesTrayectosPermisionariosUpdate.ATT_IdViajesTrayectosUnidadPermisionario
								AND ProViajesTrayectosUnidadPermisionario.IdViajeTrayecto = @IdViajeTrayecto
							END
						END
						ELSE BEGIN
							--UNIDAD PERMISIONARIO
							 IF (SELECT ISNULL(ATT_Modelo,0) FROM #TempProViajesTrayectosPermisionariosUpdate )<>0 BEGIN
								INSERT INTO ProViajesTrayectosUnidadPermisionario(IdViajeTrayecto,Modelo,TiporemolqueSAT,Placas,PermisoSCTSAT,PermisoSCT,CompaniaSeguros,NumeroSeguro)
								SELECT @IdViajeTrayecto,ATT_Modelo,ATT_TiporemolqueSAT,ATT_Placas,ATT_PermisoSCTSAT,ATT_PermisoSCT,ATT_CompaniaSeguros,ATT_NumeroSeguro 
								FROM #TempProViajesTrayectosPermisionariosUpdate
							 END
						END
				DROP TABLE #TempProViajesTrayectosPermisionariosUpdate
				END
				
				/*SOLICITUD 4208*/
				INSERT INTO ProViajesTrayectosDistribucionConceptosFacturacion(IdViajeTrayecto,IdRutaTrayecto,IdConceptoFacturacion,Secuencia,Importe,UltimaModificacion)
				SELECT
				 COL_IdViajeTrayecto
				,COL_IdRutaTrayecto
				,COL_IdConceptoFacturacion
				,COL_Secuencia
				,COL_Importe
				,@ModificadoEl
				FROM @TempProViajesTrayectosDistribucionConceptosFacturacion
				WHERE COL_IdViajeTrayecto = @IdViajeTrayecto AND ISNULL(COL_IdViajeTrayectoDistribucionConceptoFacturacion,0) = 0

				UPDATE PVTDCF SET
				PVTDCF.IdRutaTrayecto = Temp.COL_IdRutaTrayecto,
				PVTDCF.Secuencia = Temp.COL_Secuencia,
				PVTDCF.IdConceptoFacturacion = Temp.COL_IdConceptoFacturacion,
				PVTDCF.Importe = Temp.COL_Importe,
				PVTDCF.UltimaModificacion = @ModificadoEl,
				PVTDCF.TipoTrayecto = Temp.COL_TipoTrayecto
				FROM ProViajesTrayectosDistribucionConceptosFacturacion AS PVTDCF
				INNER JOIN @TempProViajesTrayectosDistribucionConceptosFacturacion AS Temp on PVTDCF.IdViajeTrayectoDistribucionConceptoFacturacion = ISNULL(Temp.COL_IdViajeTrayectoDistribucionConceptoFacturacion,0)
				/*SOLICITUD 4208*/
			END

			IF @CursorT__EsCompuesto != 0 
			BEGIN
				SET @IdUnidadHijo = (SELECT IdUnidadCamion FROM ProViajesTrayectos WHERE IdViajeTrayecto = @IdViajeTrayecto)
				SET @IdViajeTrayectoPadre = (SELECT IdViajeTrayectoCompuestoPadre FROM ProViajesTrayectos WHERE IdViajeTrayecto = @IdViajeTrayecto)
				SET @IdUnidadPadre = (SELECT IdUnidadCamion FROM ProViajesTrayectos WHERE IdViajeTrayecto = @IdViajeTrayectoPadre)
				IF @IdUnidadHijo <> @IdUnidadPadre 
					RAISERROR(N'Los trayectos del viaje hijo deben tener la misma unidad que el viaje padre',
								16,
								1
								)	
			END
			
			-----Verifica si se insertó un nuevo trayecto para cambiar el estatus del viaje de Terminado a No terminado-----
			IF EXISTS(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND Llegada IS NULL) 
			BEGIN
				UPDATE ProViajes SET
				ViajeTerminado = 0,
				TerminadoEl = NULL,
				TerminadoPor = NULL
			WHERE IdViaje = @IdViaje AND TerminadoEl IS NOT NULL
			END
			------------------------------------------------------------------------------------------------------------------
			
			if (@CursorT__EsCompuesto =1) AND (ISNULL(@CursorT_IdViajeTrayectoCompuesto,0) <> ISNULL(@IdViajeTrayectoCompuestoPadreAnterior,0))     
			begin
			
				IF NOT EXISTS(SELECT pvt.IdViaje FROM ProViajesTrayectos AS pvt LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion WHERE pvt.IdViaje = @IdViajeCompuestoPadre AND pvt.IdOperador = @CursorT_IdOperador AND pvt.Salida IS NULL AND pvt.Llegada IS NULL AND (pvt.IdLiquidacion IS NULL OR (pvt.IdLiquidacion IS NOT NULL AND pl.CerradaEl IS NULL)))
				RAISERROR(N'El viaje compuesto padre al que se intenta ligar no cumple con los requerimientos de no estar liquidado o que la liquidacion este cerrada, sea del mismo operador, no tenga salida ni llegada.',
				16,
				1
				)
				
			end			
						
			--Se crea el anticipo y el Vale
			IF @CursorT_AplicarAnticipo = 1 AND @CursorT_Anticipo <> 0 -- SI EL ANTICIPO ESTÁ MARCADO ENTRA | ANTICIPO NO MARCADO, CANCELAR
			BEGIN
				IF @ATT_GeneradoAnticipo = 0 -- 0 AGREGAR | 1 MODIFICAR
				begin
					SET @PermitirRegistrarAnticiposMayores = 0
					SET @FolioConsecutivo = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProAnticipos)
					
					IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL	
					BEGIN
						IF EXISTS(SELECT ATT_Secuencia FROM #TempProViajesTrayectosAutorizaMasGastosVales WHERE ATT_Secuencia = @CursorT_Secuencia AND isnull(ATT_IdUsuarioAutorizaGasto,0) <> 0)
						BEGIN
						IF EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CUD.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto AND CUD.IdProceso = TPVTA.ATT_IdProceso) OR (SELECT CU.TipoUsuario FROM CatUsuarios AS CU INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CU.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto) = 1
							BEGIN
								SET @PermitirRegistrarAnticiposMayores = 1
							END
						END
					END
					IF (SELECT CU.TipoUsuario FROM CatUsuarios AS CU WHERE CU.IdUsuario = @ModificadoPor) = 1 OR EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD WHERE CUD.IdUsuario = @ModificadoPor)
					BEGIN
						SET @PermitirRegistrarAnticiposMayores = 1
					END
					IF ISNULL (@PermitirRegistrarAnticiposMayores,0) = 0
					BEGIN
						SET @PermitirRegistrarAnticiposMayores = (SELECT ISNULL(Valor,0) FROM SisParametrosValores WHERE Parametro = 'PermitirRegistrarAnticiposMayores')
					END
					
					IF @CursorT_MonedaAnticipo = 'PESOS' 
					BEGIN
						SET @IdMonedaAnticipo = 1
					END
					ELSE
					BEGIN
						SET @IdMonedaAnticipo = 2
					END

					EXEC @return_valueAnt = usp_ProAnticiposRegistrar	@FechaTemp,@IdViajeTrayecto,@CursorT_Anticipo,'',@ModificadoEl,@ModificadoPor,@IdPeticion,@FolioConsecutivo,'Anticipo generado desde Viajes',@PermitirRegistrarAnticiposMayores,@CursorT_IdOperador,@IdMonedaAnticipo,@TipoCambio,@PTVContratado,NULL,NULL,1
						
					IF @return_valueAnt <> 0
					BEGIN
						RAISERROR(N'Ocurrió un error al agregar los Anticipos',
							16,
							1
							)	

					END	
					ELSE
					BEGIN
						SET @IdSesion = (SELECT TOP 1 CAST(IdSesion as varchar(36)) AS IdSesion FROM SisSesiones WHERE IdUsuario = @ModificadoPor AND Fin IS NULL ORDER BY Inicio DESC)
						SET @Viaje = (SELECT Viaje FROM dbo.ProViajes WHERE IdViaje= @IdViaje)
						SET @Mensaje = 'ANTICIPO GENERADO DESDE VIAJES(MODIFICAR) VIAJE: '+cast(@Viaje as varchar)+',IMPORTE: $'+cast(@CursorT_Anticipo as varchar)+',FOLIO ANTICIPO: '+cast(@FolioConsecutivo as varchar)
						set @FechaLocal = (SELECT GETUTCDATE())
						
						EXEC @return_valueAnt = usp_SisBitacorasRegistrar @ModificadoPor,@IdSesion,500204,@FechaLocal,@Mensaje,''
					
					
						IF @return_valueAnt <> 0
						RAISERROR(N'Ocurrió un error al agregar los Anticipos',
							16,
							1
							)

					END
				end
				ELSE -- Modificación de un anticipo
				BEGIN
				-- Verifica si existe un anticipo ligado al trayecto del viaje | Si es cero significa que no existe un anticipo ligado al trayecto
				SET @ExisteAnticipo = (SELECT COUNT(IdViajeTrayecto) FROM ProAnticipos WHERE IdViajeTrayecto = @IdViajeTrayecto AND GeneradoDesdeViaje = 1)
				IF @ExisteAnticipo <> 0
				BEGIN
						SET @PermitirRegistrarAnticiposMayores = 0
						SET @FolioConsecutivo = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProAnticipos)
					
						IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL	
						BEGIN
							IF EXISTS(SELECT ATT_Secuencia FROM #TempProViajesTrayectosAutorizaMasGastosVales WHERE ATT_Secuencia = @CursorT_Secuencia AND isnull(ATT_IdUsuarioAutorizaGasto,0) <> 0)
							BEGIN
							IF EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CUD.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto AND CUD.IdProceso = TPVTA.ATT_IdProceso) OR (SELECT CU.TipoUsuario FROM CatUsuarios AS CU INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CU.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto) = 1
								BEGIN
									SET @PermitirRegistrarAnticiposMayores = 1
								END
							END
						END
						IF (SELECT CU.TipoUsuario FROM CatUsuarios AS CU WHERE CU.IdUsuario = @ModificadoPor) = 1 OR EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD WHERE CUD.IdUsuario = @ModificadoPor)
						BEGIN
							SET @PermitirRegistrarAnticiposMayores = 1
						END
						IF ISNULL (@PermitirRegistrarAnticiposMayores,0) = 0
						BEGIN
							SET @PermitirRegistrarAnticiposMayores = (SELECT ISNULL(Valor,0) FROM SisParametrosValores WHERE Parametro = 'PermitirRegistrarAnticiposMayores')
						END
					
						IF @CursorT_MonedaAnticipo = 'PESOS' 
						BEGIN
							SET @IdMonedaAnticipo = 1
						END
						ELSE
						BEGIN
							SET @IdMonedaAnticipo = 2
						END

						-- Se obtiene el Id del Anticipo para ejecutar su stored procedure de Modificar
						SET @IdAnticipo = (SELECT IdAnticipo FROM ProAnticipos WHERE IdViajeTrayecto = @IdViajeTrayecto AND GeneradoDesdeViaje = 1)
						/*Solicitud 2464*/
						SELECT 
						@UltimaModificacionAnticipo = ModificadoEl, 
						@FolioAnticipo = Folio
						FROM ProAnticipos WHERE IdViajeTrayecto = @IdViajeTrayecto AND GeneradoDesdeViaje = 1

						EXEC @return_valueAnt = usp_ProAnticiposModificar @IdAnticipo, @FechaTemp, @CursorT_Anticipo, '', @ModificadoPor, @ModificadoEl, @UltimaModificacionAnticipo, @IdPeticion, @FolioAnticipo,'Anticipo modificado desde Viajes', @PermitirRegistrarAnticiposMayores, @IdMonedaAnticipo, @TipoCambio, @PTVContratado,1
						
						IF @return_valueAnt <> 0
						BEGIN
							RAISERROR(N'Ocurrió un error al modificar los Anticipos', 16, 1)
						END	
						ELSE
						BEGIN
							SET @IdSesion = (SELECT TOP 1 CAST(IdSesion as varchar(36)) AS IdSesion FROM SisSesiones WHERE IdUsuario = @ModificadoPor AND Fin IS NULL ORDER BY Inicio DESC)
							SET @Viaje = (SELECT Viaje FROM dbo.ProViajes WHERE IdViaje= @IdViaje)
							SET @Mensaje = 'ANTICIPO MODIFICADO DESDE VIAJES(MODIFICAR) VIAJE: '+cast(@Viaje as varchar)+',IMPORTE: $'+cast(@CursorT_Anticipo as varchar)+',FOLIO ANTICIPO: '+cast(@FolioAnticipo as varchar)
							set @FechaLocal = (SELECT GETUTCDATE())
							EXEC @return_valueAnt = usp_SisBitacorasRegistrar @ModificadoPor,@IdSesion,500204,@FechaLocal,@Mensaje,''
					
							IF @return_valueAnt <> 0
								RAISERROR(N'Ocurrió un error al modificar los Anticipos', 16, 1)
						END
					END -- FIN VALIDACION EXISTE ANTICIPO LIGADO AL TRAYECTO
				END -- FIN | Modificar Anticipos
			END
			ELSE -- INICIO | DESLIGAR ANTICIPOS
			BEGIN
					-- Verifica si existe un anticipo ligado al trayecto del viaje | Si es cero significa que no existe un anticipo ligado al trayecto
					SET @ExisteAnticipo = (SELECT COUNT(IdViajeTrayecto) FROM ProAnticipos WHERE IdViajeTrayecto = @IdViajeTrayecto AND GeneradoDesdeViaje = 1)
					IF @ExisteAnticipo <> 0
					BEGIN
						/*Se desliga del trayecto el anticipo que se genero desde viajes SOL 3001*/
						UPDATE ProViajesTrayectos SET
						AplicarAnticipo = NULL,
						AnticipoAutorizadoMoneda = NULL,
						AnticipoAutorizado = NULL
						WHERE IdViajeTrayecto = @IdViajeTrayecto

						UPDATE ProAnticipos SET
						Concepto = 'ANTICIPO MODIFICADO DESDE VIAJES',
						GeneradoDesdeViaje = NULL
						WHERE IdViajeTrayecto = @IdViajeTrayecto
					
					END---FIN | ANTICIPO GENERADO DESDE VIAJES
			END -- FIN | DESLIGAR ANTICIPOS
			
			IF @CursorT_AplicarValeDeCombustible = 1 AND @CursorT_LitrosAutorizados <> 0 -- SI EL VALE ESTÁ MARCADO ENTRA | VALE NO MARCADO, CANCELAR
			BEGIN
				If @ATT_GeneradoVale = 0 -- 0 AGREGAR | 1 MODIFICAR
				Begin
					SET @PermitirRegistrarLitrosMayores = 0
					SET @FolioValesConsecutivo = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProValesCombustible)
					SET @Autorizo = (Select Nombre from CatUsuarios where IdUsuario = @ModificadoPor)
					
					IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL	
					BEGIN
						IF EXISTS(SELECT ATT_Secuencia FROM #TempProViajesTrayectosAutorizaMasGastosVales WHERE ATT_Secuencia = @CursorT_Secuencia AND isnull(ATT_IdUsuarioAutorizaVales,0) <> 0)
						BEGIN
							IF EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CUD.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaVales AND CUD.IdProceso = TPVTA.ATT_IdProceso) OR (SELECT CU.TipoUsuario FROM CatUsuarios AS CU INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CU.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto) = 1
							BEGIN
								SET @PermitirRegistrarLitrosMayores = 1
							END
						END
					END
					IF (SELECT CU.TipoUsuario FROM CatUsuarios AS CU WHERE CU.IdUsuario = @ModificadoPor) = 1 OR EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD WHERE CUD.IdUsuario = @ModificadoPor)
					BEGIN
						SET @PermitirRegistrarLitrosMayores = 1
					END
					IF ISNULL (@PermitirRegistrarLitrosMayores,0) = 0
					BEGIN
						SET @PermitirRegistrarLitrosMayores = (SELECT ISNULL(Valor,0) FROM SisParametrosValores WHERE Parametro = 'PermitirRegistrarLitrosMayores')
					END
						
					EXEC @return_valueVal = usp_ProValesCombustibleRegistrar	@FechaTemp,@FolioValesConsecutivo,@CursorT_IdProveedor,@CursorT_IdUnidadCamion,@IdViajeTrayecto,@CursorT_IdOperador,@Autorizo,@CursorT_LitrosAutorizados,0,'Vale generado desde Viajes',@PermitirRegistrarLitrosMayores,@ModificadoPor,@CreadoElVale,@IdPeticion,0,@CursorT_GalonesAutorizados,@CursorT_Millas,1
					IF @return_valueVal <> 0
						RAISERROR(N'Ocurrió un error al agregar los vales de combustible',
							16,
							1
							)
					ELSE
					BEGIN
						SET @IdSesion = (SELECT TOP 1 CAST(IdSesion as varchar(36)) AS IdSesion FROM SisSesiones WHERE IdUsuario = @ModificadoPor AND Fin IS NULL ORDER BY Inicio DESC)
					
						SET @Mensaje = 'VALE DE COMBUSTIBLE DESDE VIAJES(REGISTRAR) VIAJE: '+cast(@Viaje as varchar)+', LITROS: '+cast(@CursorT_LitrosAutorizados as varchar)+', FOLIO VALE: '+cast(@FolioValesConsecutivo as varchar)
						set @FechaLocal = (SELECT GETUTCDATE())

						EXEC @return_valueVal = usp_SisBitacorasRegistrar @ModificadoPor,@IdSesion,500301,@FechaLocal,@Mensaje,''
					
						IF @return_valueVal <> 0
						RAISERROR(N'Ocurrió un error al agregar los Vales de combustible',
							16,
							1
							)
					END	
				end
				ELSE -- INICIO | MODIFICAR VALES COMBUSTIBLE
				BEGIN
					/*VALIDACION SOLICITUD 2500*/
					SET @ExisteValeCombustible = (SELECT COUNT(IdViajeTrayecto) FROM ProValesCombustible WHERE IdViajeTrayecto = @IdViajeTrayecto AND GeneradoDesdeViaje = 1)
					IF @ExisteValeCombustible <> 0
					BEGIN
						SET @PermitirRegistrarLitrosMayores = 0
						SET @FolioValesConsecutivo = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProValesCombustible)
						SET @Autorizo = (Select Nombre from CatUsuarios where IdUsuario = @ModificadoPor)
					
						IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL	
						BEGIN
							IF EXISTS(SELECT ATT_Secuencia FROM #TempProViajesTrayectosAutorizaMasGastosVales WHERE ATT_Secuencia = @CursorT_Secuencia AND isnull(ATT_IdUsuarioAutorizaVales,0) <> 0)
							BEGIN
								IF EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CUD.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaVales AND CUD.IdProceso = TPVTA.ATT_IdProceso) OR (SELECT CU.TipoUsuario FROM CatUsuarios AS CU INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CU.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto) = 1
								BEGIN
									SET @PermitirRegistrarLitrosMayores = 1
								END
							END
						END
						IF (SELECT CU.TipoUsuario FROM CatUsuarios AS CU WHERE CU.IdUsuario = @ModificadoPor) = 1 OR EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD WHERE CUD.IdUsuario = @ModificadoPor)
						BEGIN
							SET @PermitirRegistrarLitrosMayores = 1
						END
						IF ISNULL (@PermitirRegistrarLitrosMayores,0) = 0
						BEGIN
							SET @PermitirRegistrarLitrosMayores = (SELECT ISNULL(Valor,0) FROM SisParametrosValores WHERE Parametro = 'PermitirRegistrarLitrosMayores')
						END

						-- Se ejecuta el proceso de modificar
						/*SOLICITUD 2464*/
						SELECT  
						@IdValeCombustible = IdValeCombustible,
						@FolioValeCombustible = Folio 
						FROM ProValesCombustible WHERE IdViajeTrayecto = @IdViajeTrayecto AND GeneradoDesdeViaje = 1

						EXEC @return_valueVal = usp_ProValesCombustibleModificar @FechaTemp, @FolioValeCombustible, @CursorT_IdProveedor, @CursorT_IdUnidadCamion, @IdViajeTrayecto, @CursorT_IdOperador, @Autorizo, @CursorT_LitrosAutorizados, 0, 'Vale modificado desde Viajes', @PermitirRegistrarLitrosMayores, @IdPeticion, @ModificadoPor, @CreadoElVale, @IdValeCombustible, 0, @CursorT_GalonesAutorizados, @CursorT_Millas,1
					
						IF @return_valueVal <> 0
							RAISERROR(N'Ocurrió un error al modificar los vales de combustible', 16, 1)
					END--FIN DE VALIDACION DE SI EXISTE UN VALE DE COMBUSTIBLE LIGADO AL TRAYECTO CON EL CHECK DE GENERADO DESDE EL VIAJE
				END -- FIN | MODIFICAR VALES COMBUSTIBLE
			END
			ELSE -- INICIO | DESLIGAR VALE DE COMBUSTIBLE
			BEGIN
				/*SE AGREGO A VALIDACION QUE SEA GENERADO DESDE VIAJES SOlICITUD 2500*/
				SET @ExisteValeCombustible = (SELECT COUNT(IdViajeTrayecto) FROM ProValesCombustible WHERE IdViajeTrayecto = @IdViajeTrayecto AND GeneradoDesdeViaje = 1)
				IF @ExisteValeCombustible <> 0
				BEGIN
					/*Se desliga del trayecto el vale que se genero desde viajes SOL 3001*/
						UPDATE ProViajesTrayectos SET
						AplicarValeDeCombustible = NULL,
						LitrosAutorizados = NULL,
						GalonesAutorizados= NULL,
						IdProveedor = NULL
						WHERE IdViajeTrayecto = @IdViajeTrayecto

						UPDATE ProValesCombustible SET
						Concepto = 'VALE MODIFICADO DESDE VIAJES',
						GeneradoDesdeViaje = NULL
						WHERE IdViajeTrayecto = @IdViajeTrayecto
				END
			END -- FIN | DESLIGAR VALE DE COMBUSTIBLE

			IF ISNULL(@CursorT_IdViajeTrayectoCompuesto,0) <> ISNULL(@IdViajeTrayectoCompuestoPadreAnterior,0)
			BEGIN
				IF @CursorT_IdViajeTrayectoCompuesto = 0
				BEGIN
					--En esta parte se consulta si no existe otro viaje trayecto hijo ligado al viaje trayecto padre que no sea el viaje trayecto que se esta modificando, esto para poder quitar el chek de si es compuesto el trayecto padre en caso de que se quite
					IF NOT EXISTS(Select * from ProViajes AS pv inner join ProViajesTrayectos pvt On pv.IdViaje = pvt.IdViaje Where pvt.EsCompuesto = 1 And  pv.IdViajeCompuestoPadre = @IdViajeCompuestoPadreAnterior And pvt.IdViajeTrayecto <> @CursorT_IdViajeTrayecto)
					BEGIN
						UPDATE ProViajesTrayectos Set EsCompuesto = NULL Where IdViajeTrayecto = @IdViajeTrayectoCompuestoPadreAnterior
					END
				END
				ELSE
				BEGIN
					--En esta parte se consulta si no existe otro viaje trayecto hijo ligado al viaje trayecto padre que no sea el viaje trayecto que se esta modificando, esto para poder quitar el chek de si es compuesto el trayecto padre en caso de que se quite
					If Not EXISTS(Select * from ProViajes AS pv inner join ProViajesTrayectos pvt On pv.IdViaje = pvt.IdViaje Where pvt.EsCompuesto = 1 And  pv.IdViajeCompuestoPadre = @IdViajeCompuestoPadreAnterior And pvt.IdViajeTrayecto <> @CursorT_IdViajeTrayecto)
					BEGIN
						Update ProViajesTrayectos Set EsCompuesto = NULL Where IdViajeTrayecto = @IdViajeTrayectoCompuestoPadreAnterior
					END 

					--El Viaje en el que estoy no puede ser padre para hacerlo hijo
					If EXISTS(Select * from ProViajes Where IdViajeCompuestoPadre = @IdViaje)
						RAISERROR(N'Alguno de los trayectos del viaje ya es padre, por lo que no se puede hacer compuesto como hijo.',
						16,
						1
					)
					UPDATE ProViajesTrayectos Set EsCompuesto = 1 Where IdViajeTrayecto = @CursorT_IdViajeTrayectoCompuesto --Se actualiza el nuevo trayecto padre compuesto
				END
			END
			DELETE FROM ProViajesTrayectosDistribucionConceptosFacturacion WHERE IdViajeTrayecto = @IdViajeTrayecto AND UltimaModificacion <> @ModificadoEl

			/*Recolectas/Repartos(Ubicaciones)*/
			IF @CursorT_UbicacionesXML <> '' 
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @CursorT_UbicacionesXML
			
				SELECT ATT_IdViajeTrayectoUbicacion,ATT_IdRemitente,ATT_FechaCarga,ATT_DatosRemitente,ATT_IdDestinatario,ATT_FechaEntrega,ATT_DatosDestinatario
				INTO #TempProViajesTrayectosUbicaciones
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosUbicaciones',2) 
				WITH(ATT_IdViajeTrayectoUbicacion int,ATT_IdRemitente int,ATT_FechaCarga datetime,ATT_DatosRemitente nvarchar(max),ATT_IdDestinatario int,ATT_FechaEntrega datetime,ATT_DatosDestinatario nvarchar(max))
			
				EXEC sp_xml_removedocument @docHandle
			
				INSERT INTO ProViajesTrayectosUbicaciones(IdViajeTrayecto,IdRemitente,FechaCarga,DatosRemitente,IdDestinatario,FechaEntrega,DatosDestinatario,UltimaFechaModificacion)
				SELECT @IdViajeTrayecto,ATT_IdRemitente,CASE WHEN ATT_FechaCarga = '' THEN NULL ELSE ATT_FechaCarga END,ATT_DatosRemitente,ATT_IdDestinatario,CASE WHEN ATT_FechaEntrega = '' THEN NULL ELSE ATT_FechaEntrega END,ATT_DatosDestinatario,@ModificadoEl
				FROM #TempProViajesTrayectosUbicaciones
				WHERE 
				ATT_IdViajeTrayectoUbicacion = 0

				UPDATE ProViajesTrayectosUbicaciones SET
				 IdRemitente = #TempProViajesTrayectosUbicaciones.ATT_IdRemitente
				,FechaCarga = CASE WHEN #TempProViajesTrayectosUbicaciones.ATT_FechaCarga = '' THEN NULL ELSE #TempProViajesTrayectosUbicaciones.ATT_FechaCarga END 
				,DatosRemitente = #TempProViajesTrayectosUbicaciones.ATT_DatosRemitente
				,IdDestinatario = #TempProViajesTrayectosUbicaciones.ATT_IdDestinatario
				,FechaEntrega =  CASE WHEN #TempProViajesTrayectosUbicaciones.ATT_FechaEntrega = '' THEN NULL ELSE #TempProViajesTrayectosUbicaciones.ATT_FechaEntrega END
				,DatosDestinatario = #TempProViajesTrayectosUbicaciones.ATT_DatosDestinatario
				,UltimaFechaModificacion = @ModificadoEl
				FROM ProViajesTrayectosUbicaciones 
				INNER JOIN #TempProViajesTrayectosUbicaciones ON ProViajesTrayectosUbicaciones.IdViajeTrayectoUbicacion = #TempProViajesTrayectosUbicaciones.ATT_IdViajeTrayectoUbicacion

			
				DROP TABLE #TempProViajesTrayectosUbicaciones
			END
			DELETE ProViajesTrayectosUbicaciones WHERE IdViajeTrayecto = @IdViajeTrayecto AND UltimaFechaModificacion <> @ModificadoEl
			--------------------MATERIALES POR TRAYECTO-------------------------------------	
			IF @dsProViajesTrayectosMateriales IS NOT NULL
			BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesTrayectosMateriales
			
					SELECT ATT_Consecutivo,ATT_Cantidad,ATT_IdRutaTrayecto
					INTO #TempProViajesTrayectosMateriales
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosMateriales',2) 
					WITH (ATT_Consecutivo int,ATT_Cantidad decimal(15,4),ATT_IdRutaTrayecto int)
					EXEC sp_xml_removedocument @docHandle

					DELETE ProViajesTrayectosMateriales WHERE IdViajeTrayecto = @IdViajeTrayecto
			
					INSERT INTO ProViajesTrayectosMateriales(Consecutivo,IdViajeDescripcionCarga,IdViajeTrayecto,Cantidad)
					SELECT ATT_Consecutivo,PVDC.IdViajeDescripcionCarga,@IdViajeTrayecto,ATT_Cantidad
					FROM #TempProViajesTrayectosMateriales MTemp
					INNER JOIN ProViajesTrayectos PVT ON PVT.IdViajeTrayecto = @IdViajeTrayecto
					INNER JOIN ProViajesDescripcionesCarga PVDC ON PVDC.Consecutivo=MTemp.ATT_Consecutivo AND PVT.IdViaje = PVDC.IdViaje
					INNER JOIN ProViajes AS PV  ON PVT.IdViaje = PV.IdViaje
					INNER JOIN CatRutasTrayectos AS CRT ON PV.IdRuta = CRT.IdRuta AND PVT.Secuencia = CRT.Secuencia
					WHERE PVDC.IdViaje=@IdViaje AND  CRT.IdRutaTrayecto=ATT_IdRutaTrayecto

				DROP TABLE #TempProViajesTrayectosMateriales
			END
			-----------------------------------------------------------------------------------
			FETCH NEXT FROM ProViajesTrayectosCursor
			INTO @CursorT_IdViajeTrayecto,@CursorT_CodigoUnidadCamion,@CursorT_IdOperador,@CursorT_IdUnidadCamion,@CursorT_Kilometros,@CursorT_Horas,@CursorT_NombreOperador,
			@CursorT_PlacasUnidadCamion,@CursorT_Secuencia,@CursorT_IdOrigen,@CursorT_IdDestino,@CursorT_NombreOperadorPermisionario,						
			 @CursorT_NoCartaPortePermisionario,@CursorT_NoFacturaPermisionario,@CursorT_IdMonedaPermisionario,@CursorT_FechaFacturaPermisionario,			 
			 @CursorT_FechaRecepcionFacturaPermisionario,@CursorT_ConceptoPermisionario,			 
			 @CursorT_AplicarAnticipo,@CursorT_Anticipo,@CursorT_MonedaAnticipo,@CursorT_AplicarValeDeCombustible,@CursorT_LitrosAutorizados,@CursorT_IdProveedor,
			 @ATT_GeneradoAnticipo,@ATT_GeneradoVale,@CursorT__EsCompuesto,@CursorT_Tienda,@CursorT_NumeroOrden,@CursorT_Monto,@CursorT_CargadoVacioRemolque1,@CursorT_CargadoVacioRemolque2,
			 @CursorT_FechaPagoFactura,@CursorT_Millas,@CursorT_GalonesAutorizados,@CursorT_IdViajeTrayectoCompuesto,@CursorT_ETA,@CursorT_Referencia,@CursorT_EnvioNotificacionMovil
			 -- Solcitud 675
			 ,@CursorT_FechaHoraCarga
			 ,@CursorT_FechaHoraEstimadaCarga
			 ,@CursorT_FechaHoraDescarga
			 ,@CursorT_FechaHoraEstimadaDescarga
			 -- Solicitud 866
			 ,@CursorT_CamionPer
			 ,@CursorT_UbicacionesXML
			 --SOLICITUD 4669
			 ,@CursorT_PermisionarioXML
			 ,@CursorT_IdOperadorAux
			 ,@CursorT_NombreOperadorAux
		END
		-----------------------------------------------------------------------------------------------------
		CLOSE ProViajesTrayectosCursor
		DEALLOCATE ProViajesTrayectosCursor
	END	
	
		
	IF EXISTS(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl AND Salida IS NOT NULL)
		RAISERROR(N'No se puede eliminar los trayectos porque tiene salida',
			16,
			1
			)

	IF EXISTS(SELECT IdViajeTrayecto FROM ProValesCombustible WHERE IdViajeTrayecto IN(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl))
		RAISERROR(N'No se puede eliminar los trayectos porque tienen vales de combustible registrados',
			16,
			1
			)

	IF EXISTS(SELECT IdViajeTrayecto FROM ProAnticipos WHERE IdViajeTrayecto IN(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl))
		RAISERROR(N'No se puede eliminar los trayectos porque tienen anticipos registrados',
			16,
			1
			)

	IF EXISTS(SELECT IdViajeTrayecto FROM ProCargasAutopistas WHERE IdViajeTrayecto IN(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl))
		RAISERROR(N'No se puede eliminar los trayectos porque tienen autopistas registrados',
			16,
			1
			)	

	IF EXISTS(SELECT IdViajeTrayecto FROM ProConsumosCombustible WHERE IdViajeTrayecto IN(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl))
		RAISERROR(N'No se puede eliminar los trayectos porque tienen consumos de combustibles registrados',
			16,
			1
			)				

	IF EXISTS(SELECT IdViajeTrayecto FROM ProGastosViaje WHERE IdViajeTrayecto IN(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl))
		RAISERROR(N'No se puede eliminar los trayectos porque tienen gastos registrados',
			16,
			1
			)

	IF EXISTS(SELECT pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt INNER JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion WHERE pvt.IdViaje = @IdViaje AND (pvt.ModificadoEl <> @ModificadoEl OR pvt.ModificadoEl IS NULL) AND pvt.CreadoEl <> @ModificadoEl AND pl.CerradaEl IS NOT NULL)
		RAISERROR(N'No se puede eliminar los trayectos porque tiene una liquidación cerrada',
			16,
			1
			)				
												
	DELETE FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	

	--cuando es un viaje compuesto hijo se valida que tengan el mismo operador el viaje
	--que la liquidacion del viaje padre no este cerrada, no tenga salida, ni llegada
	IF @IdViajeCompuestoPadre != 0
	BEGIN
		SET @IdOperador = (SELECT TOP 1 IdOperador FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND EsCompuesto = 1 )
			
		IF EXISTS(SELECT IdAnticipo FROM ProAnticipos AS pa INNER JOIN ProViajesTrayectos AS pvt ON pa.IdViajeTrayecto = pvt.IdViajeTrayecto AND pvt.IdViaje = @IdViaje AND EsCompuesto = 1)--Revisar segun consultar con el trayecto hijo
			RAISERROR(N'El viaje que esta modificando tiene anticipos y no puede ser un viaje compuesto hijo',
			16,
			1
			)

		IF EXISTS(SELECT IdGastoViaje FROM ProGastosViaje AS pa INNER JOIN ProViajesTrayectos AS pvt ON pa.IdViajeTrayecto = pvt.IdViajeTrayecto AND pvt.IdViaje = @IdViaje AND pvt.EsCompuesto = 1)--Revisar segun consultar con el trayecto hijo ***Preguntar
			RAISERROR(N'El viaje que esta modificando tiene gastos de viaje y no puede ser un viaje compuesto hijo',
			16,
			1
			)

		IF EXISTS(SELECT IdValeCombustible FROM ProValesCombustible AS pa INNER JOIN ProViajesTrayectos AS pvt ON pa.IdViajeTrayecto = pvt.IdViajeTrayecto AND pvt.IdViaje = @IdViaje AND pvt.EsCompuesto = 1)--Revisar segun consultar con el trayecto hijo
			RAISERROR(N'El viaje que esta modificando tiene vales de combustible y no puede ser un viaje compuesto hijo',
			16,
			1
			)
			
		IF EXISTS(SELECT IdConsumoCombustible FROM ProConsumosCombustible AS pa INNER JOIN ProViajesTrayectos AS pvt ON pa.IdViajeTrayecto = pvt.IdViajeTrayecto AND pvt.IdViaje = @IdViaje AND pvt.EsCompuesto = 1)--Revisar segun consultar con el trayecto hijo
			RAISERROR(N'El viaje que esta modificando tiene consumos de combustibles cargados/referenciados y no puede ser un viaje compuesto hijo',
			16,
			1
			)

		IF EXISTS(SELECT IdCargaAutopista FROM ProCargasAutopistas AS pa INNER JOIN ProViajesTrayectos AS pvt ON pa.IdViajeTrayecto = pvt.IdViajeTrayecto AND pvt.IdViaje = @IdViaje AND pvt.EsCompuesto = 1)--Revisar segun consultar con el trayecto hijo
			RAISERROR(N'El viaje que esta modificando tiene autopistas cargados/referenciados y no puede ser un viaje compuesto hijo',
			16,
			1
			)
			
		--se deshabilito seccion a peticion de la solicitud 006177			
		--IF NOT EXISTS(SELECT pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion WHERE pvt.IdViaje = @IdViaje AND (pvt.IdLiquidacion IS NULL OR (pvt.IdLiquidacion IS NOT NULL AND pl.CerradaEl IS NULL)) AND pvt.EsCompuesto = 1)--Revisar segun consultar con el trayecto hijo
		--	RAISERROR(N'No se puede convertir a viaje compuesto porque el trayecto ya se encuentra con liquidación cerrada',
		--	16,
		--	1
		--	)		
	END
		IF NOT EXISTS (SELECT IdSucursal from dbo.ProViajes where IdViaje=@IdViaje and IdSucursal=@IdSucursal) 
		BEGIN 
		SET @Viaje = (SELECT ISNULL(MAX(Viaje),0)+1 FROM ProViajes WHERE IdSucursal = @IdSucursal)
		END
		ELSE 
		BEGIN 
		SET @Viaje = (SELECT Viaje FROM dbo.ProViajes WHERE IdViaje= @IdViaje)
		END
	UPDATE ProViajes SET
		CodigoUnidadCarga1 = @CodigoUnidadCarga1,
		CodigoUnidadCarga2 = @CodigoUnidadCarga2,
		CodigoUnidadContenedor1 = @CodigoUnidadContenedor1,
		CodigoUnidadContenedor2 = @CodigoUnidadContenedor2,
		CodigoUnidadDolly = @CodigoUnidadDolly,
		Convenio = @Convenio,
		CuotaConvenida = @CuotaConvenida,
		DatosDestinatario = @DatosDestinatario,
		DatosRemitente = @DatosRemitente,
		Facturable = @Facturable,
		FechaCarga = @FechaCarga,
		FechaEntrega = @FechaEntrega,
		FechaHora = @FechaHora,
		IdCliente = @IdCliente,
		IdDestinatario = @IdDestinatario,
		IdMoneda = @IdMoneda,
		IdMonedaValorDeclarado = @IdMonedaValorDeclarado,
		IdRemitente = @IdRemitente,
		IdRuta = @IdRuta,
		IdUnidadCarga1 = @IdUnidadCarga1,
		IdUnidadCarga2 = @IdUnidadCarga2,
		IdUnidadContenedor1 = @IdUnidadContenedor1,
		IdUnidadContenedor2 = @IdUnidadContenedor2,
		IdUnidadDolly = @IdUnidadDolly,
		IdUnidadPeso = @IdUnidadPeso,
		Item = @Item,
		Kilometros = @Kilometros,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		NoViajeCliente = @NoViajeCliente,
		Observaciones = @Observaciones,
		Peso = @Peso,
		PlacasUnidadCarga1 = @PlacasUnidadCarga1,
		PlacasUnidadCarga2 = @PlacasUnidadCarga2,
		Planta = @Planta,
		SeEntregaraEn = @SeEntregaraEn,
		SeRecogeraEn = @SeRecogeraEn,
		SubTotal = @SubTotal,
		TipoCambio = @TipoCambio,
		TipoCobroPorViaje = @TipoCobroPorViaje,
		ValorDeclarado = @ValorDeclarado,
		ViajeConCP = @ViajeConCP,
		IdViajeCompuestoPadre = @IdViajeCompuestoPadre,
		CandadoOficial = @CandadoOficial,
		IdTipoViaje = @IdTipoViaje,
		IdClasificacionViaje = @IdClasificacionViaje,
		IdTipoUnidad = @IdTipoUnidad,
		CantidadMovimientos = @CantidadMovimientos,
		Millas = @Millas,
		LitrosCombustible = @LitrosCombustible,
		IdCombustible = @IdCombustible,
		IdSucursalAReportar = @IdSucursalAReportar,
		IncluirFlete = @IncluirFlete,
		IdCombustibleTarifaFlete = @IdCombustibleTarifaFlete,
		TieneIEPS = @TieneIEPS,
		IEPS = @IEPS,
		IdSucursal = @IdSucursal,
		Viaje = @Viaje,
		IdentificadorConvoy = @IdentificadorConvoy,
		Identificador = @Identificador,
        FechaEntregaModificada = @FechaEntregaModificada,
		EstructuraJSONShipment = @JsonShipment,
		ShipmentAPI = @ShipmentAPI,
		GeneradoDistribucionIngresos = @GeneradoDistribucionIngresos,
		ViajeInternacional = @ViajeInternacional,
		ImportacionExportacion = @ImportacionExportacion
	WHERE IdViaje = @IdViaje

	IF ISNULL(@Contenedores,'') != ''
	BEGIN
		--El separador de nuestros parametros deberá ser una coma ","
			DECLARE @Posicion int
			--@Posicion es la posicion de cada uno de nuestros separadores
			DECLARE @Contenedor varchar(1000)
			--@Contenedor es cada una de los contenedores (token) de los valores en @Contenedores
			SET @Contenedores = @Contenedores + ','
			--Colocamos un separador al final de los parametros para un funcionamiento correcto
			--Hacemos un Ciclo que se repite mientras haya separadores
			WHILE patindex('%,%' , @Contenedores) <> 0
			--patindex busca un patron en una cadena y nos devuelve su posicion
			BEGIN
			   SELECT @Posicion =  patindex('%,%' , @Contenedores)
			   --Buscamos la posicion de la primera ,
			   SELECT @Contenedor = left(@Contenedores, @Posicion - 1)
			   --Y obtenemos una subcadena hasta la posicion de la coma
			   
			   UPDATE ProDetalleEntregaContenedores SET IdViaje = @IdViaje WHERE IdDetalleEntregaContenedores = @Contenedor
			  
			   -- Reemplazamos la cadena extraida con nada mediante la funcion stuff
			   -- es equivalente a borrar o retirar la subcadena de la cadena
			   SELECT @Contenedores = stuff(@Contenedores, 1, @Posicion, '')
			   -- Retornamos al inicio del ciclo
			END
			--Y cuando se han recorrido todos los parametros terminamos la tranacción exitosa
	END
	
	IF NOT EXISTS(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND Llegada IS NULL)	
	BEGIN
		UPDATE ProViajes SET
			ViajeTerminado = 1,
			TerminadoEl = @ModificadoEl,
			TerminadoPor = @ModificadoPor
		WHERE IdViaje = @IdViaje AND TerminadoEl IS NULL
	END
	
	IF @Convertir = 1
	BEGIN
	IF EXISTS(SELECT IdFolio FROM ProViajesCartasPorte WHERE IdFolio = @IdFolio)
		--Solicitud 12089 se agrega validacion de concurrencia 
		BEGIN
			RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar.',
				16,
				1
				)
		END
		--Solicitud 632
		--Validacion de concurrencia para cartas porte
		IF EXISTS(SELECT IdViaje FROM ProViajesCartasPorte WHERE IdViaje = @IdViaje)
		BEGIN
			RAISERROR(N'El viaje actual ya cuenta con una carta porte registrada, favor de validar.',
				16,
				1
				)
		END

		INSERT INTO ProViajesCartasPorte(CreadoEl,CreadoPor,EstatusImpresoEnviadoCliente,IdCertificado,
		IdFolio,IdFormatoImpresion,IdViaje,ImpuestosRetenidosFederales,ImpuestosRetenidosLocales,ImpuestosTrasladadosFederales,ImpuestosTrasladadosLocales,
		MetodoPago,NroCuentaPago,Observaciones,SubTotal,Total,ClaveMetodoPago,CreadaParaCFDI33,CreadaParaComplemento,DocumentoConfiguracionTimbrado)
		VALUES(@ModificadoEl,@ModificadoPor,@EstatusImpresoEnviadoCliente,@IdCertificado,
		@IdFolio,@IdFormatoImpresion,@IdViaje,@ImpuestosRetenidosFederales,@ImpuestosRetenidosLocales,@ImpuestosTrasladadosFederales,@ImpuestosTrasladadosLocales,
		@MetodoPago,@NroCuentaPago,@Observaciones,@SubTotal,@Total,@ClaveMetodoPago,@CreadaParaCFDI33,@CreadaParaComplemento,@DocumentoConfiguracionTimbrado)		
		
		SET @IdViajeCartaPorte = (SELECT IDENT_CURRENT('ProViajesCartasPorte'))		
		
		-- actualiza el estatus del folio
		UPDATE CatFolios SET Estatus = 2 WHERE IdFolio = @IdFolio		
	END
	ELSE
	BEGIN	
		UPDATE ProViajesCartasPorte SET
			IdFormatoImpresion = @IdFormatoImpresion,
			ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales,
			ImpuestosRetenidosLocales = @ImpuestosRetenidosLocales,
			ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales,
			ImpuestosTrasladadosLocales = @ImpuestosTrasladadosLocales,
			MetodoPago = @MetodoPago,
			NroCuentaPago = @NroCuentaPago,
			Total = @Total,
			SubTotal = @SubTotal,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor,
			ClaveMetodoPago	= @ClaveMetodoPago,
			CreadaParaComplemento = @CreadaParaComplemento,
			DocumentoConfiguracionTimbrado = @DocumentoConfiguracionTimbrado
		WHERE IdViaje = @IdViaje AND IdViajeCartaPorte = @IdViajeCartaPorte		
	END
	
	
	--Se agregan las referencias a la tabla
	IF @dsProViajesCartasPorteReferencias IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesCartasPorteReferencias
		
		SELECT ATT_NombreReferencia,ATT_ValorReferencia,ATT_IdViajeCartaPorteReferencia
		INTO #TempProViajesCartasPorteReferencias
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesCartasPorteReferencias',2) 
		WITH (ATT_NombreReferencia varchar(100),ATT_ValorReferencia varchar(100),ATT_IdViajeCartaPorteReferencia int)
		
		EXEC sp_xml_removedocument @docHandle
		UPDATE ProViajesCartasPorteReferencias
		SET	ProViajesCartasPorteReferencias.IdViaje = @IdViaje,
				ProViajesCartasPorteReferencias.NombreReferencia = #TempProViajesCartasPorteReferencias.ATT_NombreReferencia,
				ProViajesCartasPorteReferencias.ValorReferencia = #TempProViajesCartasPorteReferencias.ATT_ValorReferencia
		FROM ProViajesCartasPorteReferencias INNER JOIN #TempProViajesCartasPorteReferencias
		ON   ProViajesCartasPorteReferencias.IdViajeCartaPorteReferencia = #TempProViajesCartasPorteReferencias.ATT_IdViajeCartaPorteReferencia 
		
		DELETE FROM ProViajesCartasPorteReferencias WHERE IdViaje = @IdViaje AND IdViajeCartaPorteReferencia NOT IN(SELECT ATT_IdViajeCartaPorteReferencia FROM #TempProViajesCartasPorteReferencias WHERE ATT_IdViajeCartaPorteReferencia <> 0)
		
		INSERT INTO ProViajesCartasPorteReferencias(IdViaje,NombreReferencia,ValorReferencia)
		SELECT @IdViaje,ATT_NombreReferencia,ATT_ValorReferencia FROM #TempProViajesCartasPorteReferencias WHERE ATT_IdViajeCartaPorteReferencia = 0
	END
	ELSE
	BEGIN
		DELETE FROM ProViajesCartasPorteReferencias WHERE IdViaje = @IdViaje
	END
	
	
	
	IF @dsProViajesConceptosFacturacion IS NOT NULL 
	BEGIN
		--SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesConceptosFacturacion
			
		SELECT ATT_IdViajeConceptoFacturacion,ATT_IdConceptoFacturacion,ATT_UnidadMedida,ATT_TrasladaImpuesto,ATT_RetieneImpuesto,ATT_ImporteConceptoFacturacion,ATT_IncluirCalculoIngresosLiquidacion,ATT_IncluirCalculoLiquidacionPorcentajeSobreImpFlete,ATT_Observaciones,ATT_ClaveSATProducto,ATT_ClaveSATUnidad,ATT_IdImpuestoTrasladado,ATT_IdImpuestoRetenido,ATT_ImporteTrasladado,ATT_ImporteRetenido
		INTO #TempProViajesConceptosFacturacion
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesConceptosFacturacion',2) 
		WITH (ATT_IdViajeConceptoFacturacion int,ATT_IdConceptoFacturacion int,ATT_UnidadMedida varchar(30),ATT_TrasladaImpuesto bit,ATT_RetieneImpuesto bit,ATT_ImporteConceptoFacturacion money,ATT_IncluirCalculoIngresosLiquidacion bit,ATT_IncluirCalculoLiquidacionPorcentajeSobreImpFlete bit,ATT_Observaciones varchar(8000),ATT_ClaveSATProducto varchar(8),ATT_ClaveSATUnidad varchar(8),ATT_IdImpuestoTrasladado int,ATT_IdImpuestoRetenido int,ATT_ImporteTrasladado money,ATT_ImporteRetenido money)

		EXEC sp_xml_removedocument @docHandle

		UPDATE ProViajesConceptosFacturacion SET 
			ProViajesConceptosFacturacion.Importe = #TempProViajesConceptosFacturacion.ATT_ImporteConceptoFacturacion,
			ProViajesConceptosFacturacion.TrasladaImpuesto = #TempProViajesConceptosFacturacion.ATT_TrasladaImpuesto,
			ProViajesConceptosFacturacion.RetieneImpuesto = #TempProViajesConceptosFacturacion.ATT_RetieneImpuesto,
			ProViajesConceptosFacturacion.UnidadMedida = #TempProViajesConceptosFacturacion.ATT_UnidadMedida,
			ProViajesConceptosFacturacion.IncluirCalculoIngresosLiquidacion = #TempProViajesConceptosFacturacion.ATT_IncluirCalculoIngresosLiquidacion,
			ProViajesConceptosFacturacion.IncluirCalculoLiquidacionPorcentajeSobreImpFlete = #TempProViajesConceptosFacturacion.ATT_IncluirCalculoLiquidacionPorcentajeSobreImpFlete,
			ProViajesConceptosFacturacion.ModificadoEl = @ModificadoEl,
			ProViajesConceptosFacturacion.ModificadoPor = @ModificadoPor,
			ProViajesConceptosFacturacion.Observacion = ATT_Observaciones,
			ProViajesConceptosFacturacion.ClaveSATProducto = #TempProViajesConceptosFacturacion.ATT_ClaveSATProducto,
			ProViajesConceptosFacturacion.ClaveSATUnidad = #TempProViajesConceptosFacturacion.ATT_ClaveSATUnidad
		FROM ProViajesConceptosFacturacion 
		INNER JOIN #TempProViajesConceptosFacturacion ON ProViajesConceptosFacturacion.IdViajeConceptoFacturacion = #TempProViajesConceptosFacturacion.ATT_IdViajeConceptoFacturacion OR (ProViajesConceptosFacturacion.IdConceptoFacturacion = #TempProViajesConceptosFacturacion.ATT_IdConceptoFacturacion AND ProViajesConceptosFacturacion.IdViaje = @IdViaje)

		DELETE FROM ProViajesConceptosFacturacionImpuestos 
		WHERE IdViajeConceptoFacturacion IN( SELECT IdViajeConceptoFacturacion FROM ProViajesConceptosFacturacion WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl)

		DELETE FROM ProViajesConceptosFacturacion WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		
		--Se agregó seccion para los impuestos por concepto Solicitud 001487
		DECLARE CursorViajesConceptosFacturacion CURSOR LOCAL FOR
		SELECT * FROM #TempProViajesConceptosFacturacion

		OPEN CursorViajesConceptosFacturacion
		FETCH NEXT FROM CursorViajesConceptosFacturacion
		INTO @CursorIdViajeConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorUnidadMedida,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorImporteConceptoFacturacion,@CursorIncluirCalculoIngresosLiquidacion,@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete,@CursorObservaciones,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorIdImpuestoTrasladado,@CursorIdImpuestoRetenido,@CursorImporteTrasladado,@CursorImporteRetenido

		WHILE @@FETCH_STATUS = 0
		BEGIN					
			IF @CursorIdViajeConceptoFacturacion = 0 AND NOT EXISTS( SELECT IdViajeConceptoFacturacion FROM ProViajesConceptosFacturacion WHERE IdViaje = @IdViaje AND IdConceptoFacturacion = @CursorIdConceptoFacturacion )
			BEGIN
				INSERT INTO ProViajesConceptosFacturacion(CreadoEl,CreadoPor,IdConceptoFacturacion,IdViaje,Importe,RetieneImpuesto,TrasladaImpuesto,UnidadMedida,IncluirCalculoIngresosLiquidacion,IncluirCalculoLiquidacionPorcentajeSobreImpFlete,Observacion,ClaveSATProducto,ClaveSATUnidad)
				VALUES(@ModificadoEl,@ModificadoPor,@CursorIdConceptoFacturacion,@IdViaje,@CursorImporteConceptoFacturacion,@CursorRetieneImpuesto,@CursorTrasladaImpuesto,@CursorUnidadMedida,@CursorIncluirCalculoIngresosLiquidacion,@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete,@CursorObservaciones,@CursorClaveSATProducto,@CursorClaveSATUnidad)

				SET @IdViajeConceptoFacturacion = (SELECT IDENT_CURRENT('ProViajesConceptosFacturacion'))

				IF @CursorIdImpuestoTrasladado != 0 
				BEGIN
					INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
					VALUES( @IdViajeConceptoFacturacion,@CursorIdImpuestoTrasladado,@CursorImporteTrasladado )
				END

				IF @CursorIdImpuestoRetenido != 0
				BEGIN
					INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
					VALUES( @IdViajeConceptoFacturacion,@CursorIdImpuestoRetenido,@CursorImporteRetenido )
				END
			END
			ELSE
			BEGIN
				DECLARE @nIdViajeConceptoFacturacion int
				SET @nIdViajeConceptoFacturacion = (SELECT IdViajeConceptoFacturacion FROM ProViajesConceptosFacturacion WHERE IdViaje = @IdViaje AND IdConceptoFacturacion = @CursorIdConceptoFacturacion)
				IF @nIdViajeConceptoFacturacion != 0
				BEGIN
					DELETE FROM ProViajesConceptosFacturacionImpuestos WHERE IdViajeConceptoFacturacion = @nIdViajeConceptoFacturacion

					IF @CursorIdImpuestoTrasladado != 0 
					BEGIN
						INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
						VALUES( @nIdViajeConceptoFacturacion,@CursorIdImpuestoTrasladado,@CursorImporteTrasladado )
					END

					IF @CursorIdImpuestoRetenido != 0
					BEGIN
						INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
						VALUES( @nIdViajeConceptoFacturacion,@CursorIdImpuestoRetenido,@CursorImporteRetenido )
					END
				END
			END
			FETCH NEXT FROM CursorViajesConceptosFacturacion
			INTO @CursorIdViajeConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorUnidadMedida,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorImporteConceptoFacturacion,@CursorIncluirCalculoIngresosLiquidacion,@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete,@CursorObservaciones,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorIdImpuestoTrasladado,@CursorIdImpuestoRetenido,@CursorImporteTrasladado,@CursorImporteRetenido
		END

		CLOSE CursorViajesConceptosFacturacion
		DEALLOCATE CursorViajesConceptosFacturacion	
	END
		
	IF (SELECT ISNULL(SUM(ROUND(Importe,2)),0) FROM ProViajesConceptosFacturacion WHERE IdViaje = @IdViaje) <> @SubTotal
		RAISERROR(N'La suma de los importes de los conceptos de facturación no son iguales al subtotal',
			16,
			1
			)


	--agrega IMPUESTOS del viaje	
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesImpuestos
	
	SELECT ATT_IdViajeCartaPorteImpuesto,ATT_IdImpuesto,ATT_Importe
	INTO #TempProViajesImpuestos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesImpuestos',2) 
	WITH (ATT_IdViajeCartaPorteImpuesto int,ATT_IdImpuesto int,ATT_Importe money)
	
	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO ProViajesCartasPorteImpuestos(CreadoEl,CreadoPor,IdImpuesto,IdViajeCartaPorte,Importe)
	SELECT @ModificadoEl,@ModificadoPor,ATT_IdImpuesto,@IdViajeCartaPorte,ATT_Importe
	FROM #TempProViajesImpuestos
	WHERE ATT_IdViajeCartaPorteImpuesto = 0
	
	UPDATE ProViajesCartasPorteImpuestos SET
		ProViajesCartasPorteImpuestos.Importe = #TempProViajesImpuestos.ATT_Importe,
		ProViajesCartasPorteImpuestos.ModificadoEl = @ModificadoEl,
		ProViajesCartasPorteImpuestos.ModificadoPor = @ModificadoPor
	FROM ProViajesCartasPorteImpuestos 
	INNER JOIN #TempProViajesImpuestos ON ProViajesCartasPorteImpuestos.IdViajeCartaPorteImpuesto = #TempProViajesImpuestos.ATT_IdViajeCartaPorteImpuesto

	DELETE FROM ProViajesCartasPorteImpuestos WHERE IdViajeCartaPorte = @IdViajeCartaPorte AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	--agrega Pedimentos del viaje	
	IF @dsProViajesPedimentos IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesPedimentos
		
		SELECT ATT_IdViajePedimento,ATT_NumeroPedimento,ATT_FechaPedimento,ATT_AduanaPedimento,ATT_CreadoDesde
		INTO #TempProViajesPedimentos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesPedimentos',2) 
		WITH (ATT_IdViajePedimento int,ATT_NumeroPedimento varchar(25),ATT_FechaPedimento datetime,ATT_AduanaPedimento varchar(25),ATT_CreadoDesde tinyint)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProViajesPedimentos(CreadoEl,CreadoPor,Aduana,Fecha,IdViaje,NumeroPedimento,CreadoDesde)
		SELECT @ModificadoEl,@ModificadoPor,ATT_AduanaPedimento,ATT_FechaPedimento,@IdViaje,ATT_NumeroPedimento,ATT_CreadoDesde
		FROM #TempProViajesPedimentos
		WHERE ATT_IdViajePedimento = 0
		
		UPDATE ProViajesPedimentos SET
			ProViajesPedimentos.Aduana = #TempProViajesPedimentos.ATT_AduanaPedimento,
			ProViajesPedimentos.Fecha = #TempProViajesPedimentos.ATT_FechaPedimento,
			ProViajesPedimentos.NumeroPedimento = #TempProViajesPedimentos.ATT_NumeroPedimento,
			ProViajesPedimentos.ModificadoEl = @ModificadoEl,
			ProViajesPedimentos.ModificadoPor = @ModificadoPor	
		FROM ProViajesPedimentos 
		INNER JOIN #TempProViajesPedimentos ON ProViajesPedimentos.IdViajePedimento = #TempProViajesPedimentos.ATT_IdViajePedimento
	END	

	DELETE FROM ProViajesPedimentos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	--agrega Pedimentos de internacion/fianzas
	IF @dsProViajesContenedoresEquipos IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesContenedoresEquipos
		
		SELECT ATT_ContenedorEquipo,ATT_Booking,ATT_NumeroPedimento,ATT_Aduana,ATT_FechaPedimento,
		ATT_FechaRegreso,ATT_Naviera,ATT_IdUnidad,ATT_IdViajeContenedorEquipo,ATT_OrdenCompra,ATT_OrdenDeTrabajo,ATT_NumeroLinea,
		ATT_Unidades,ATT_DescripcionMaterial,ATT_Comentario,ATT_NumMaterial,ATT_Tipo,ATT_Tamano,ATT_Sellos,
		ATT_SecuenciaTrayecto, ATT_Cargado, ATT_IdUnidadCarga, ATT_IdDetalleEntregaContenedor
		INTO #TempProViajesContenedoresEquipos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesContenedoresEquipos',2) 
		WITH (ATT_ContenedorEquipo varchar(16),ATT_Booking varchar(30),ATT_NumeroPedimento varchar(25),
		ATT_Aduana varchar(25),ATT_FechaPedimento varchar(10),ATT_FechaRegreso varchar(10),ATT_Naviera varchar(80),
		ATT_IdUnidad int,ATT_IdViajeContenedorEquipo int,ATT_OrdenCompra varchar(50),ATT_OrdenDeTrabajo varchar(50),ATT_NumeroLinea Int,
		ATT_Unidades decimal(18,2),ATT_DescripcionMaterial varchar(50),ATT_Comentario varchar(100),ATT_NumMaterial varchar(50),ATT_Tipo varchar(80),ATT_Tamano varchar(80),ATT_Sellos varchar(60),
		ATT_SecuenciaTrayecto int, ATT_Cargado bit, ATT_IdUnidadCarga int, ATT_IdDetalleEntregaContenedor int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProViajesContenedoresEquipos(IdViaje,ContenedorEquipo,Booking,NumeroPedimento,Aduana,FechaPedimento,
		FechaRegreso,CreadoPor,CreadoEl,Naviera,IdUnidad,OrdenCompra,OrdenDeTrabajo,NumeroLinea,
		Unidades,DescripcionMaterial,Comentario,NumMaterial,Tipo,Tamano,Sellos,SecuenciaTrayecto,Cargado,IdUnidadCarga,IdDetalleEntregaContenedor)
		SELECT @IdViaje,ATT_ContenedorEquipo,ATT_Booking,ATT_NumeroPedimento,ATT_Aduana,ATT_FechaPedimento,
		ATT_FechaRegreso,@ModificadoPor,@ModificadoEl,ATT_Naviera,CASE ATT_IdUnidad WHEN 0 THEN NULL ELSE ATT_IdUnidad END,ATT_OrdenCompra,ATT_OrdenDeTrabajo,ATT_NumeroLinea,
		ATT_Unidades,ATT_DescripcionMaterial,ATT_Comentario,ATT_NumMaterial,ATT_Tipo,ATT_Tamano,ATT_Sellos,
		ATT_SecuenciaTrayecto, ATT_Cargado, CASE ATT_IdUnidadCarga WHEN 0 THEN NULL ELSE ATT_IdUnidadCarga END,
		CASE ATT_IdDetalleEntregaContenedor WHEN 0 THEN NULL ELSE ATT_IdDetalleEntregaContenedor END
		FROM #TempProViajesContenedoresEquipos
		WHERE ATT_IdViajeContenedorEquipo = 0

		UPDATE ProViajesContenedoresEquipos SET
			ProViajesContenedoresEquipos.ContenedorEquipo = #TempProViajesContenedoresEquipos.ATT_ContenedorEquipo,
			ProViajesContenedoresEquipos.Booking = #TempProViajesContenedoresEquipos.ATT_Booking,
			ProViajesContenedoresEquipos.NumeroPedimento = #TempProViajesContenedoresEquipos.ATT_NumeroPedimento,
			ProViajesContenedoresEquipos.Aduana = #TempProViajesContenedoresEquipos.ATT_Aduana,
			ProViajesContenedoresEquipos.FechaPedimento = #TempProViajesContenedoresEquipos.ATT_FechaPedimento,
			ProViajesContenedoresEquipos.FechaRegreso = #TempProViajesContenedoresEquipos.ATT_FechaRegreso,
			ProViajesContenedoresEquipos.Naviera = #TempProViajesContenedoresEquipos.ATT_Naviera,
			ProViajesContenedoresEquipos.IdUnidad = CASE #TempProViajesContenedoresEquipos.ATT_IdUnidad WHEN 0 THEN NULL ELSE #TempProViajesContenedoresEquipos.ATT_IdUnidad END,
			ProViajesContenedoresEquipos.ModificadoEl = @ModificadoEl,
			ProViajesContenedoresEquipos.ModificadoPor = @ModificadoPor,			
			ProViajesContenedoresEquipos.OrdenCompra = #TempProViajesContenedoresEquipos.ATT_OrdenCompra,
			ProViajesContenedoresEquipos.OrdenDeTrabajo = #TempProViajesContenedoresEquipos.ATT_OrdenDeTrabajo,
			ProViajesContenedoresEquipos.NumeroLinea = #TempProViajesContenedoresEquipos.ATT_NumeroLinea,
			ProViajesContenedoresEquipos.Unidades = #TempProViajesContenedoresEquipos.ATT_Unidades,
			ProViajesContenedoresEquipos.DescripcionMaterial = #TempProViajesContenedoresEquipos.ATT_DescripcionMaterial,
			ProViajesContenedoresEquipos.Comentario = #TempProViajesContenedoresEquipos.ATT_Comentario,
			ProViajesContenedoresEquipos.NumMaterial = #TempProViajesContenedoresEquipos.ATT_NumMaterial,	
			ProViajesContenedoresEquipos.Tipo = #TempProViajesContenedoresEquipos.ATT_Tipo,
			ProViajesContenedoresEquipos.Tamano = #TempProViajesContenedoresEquipos.ATT_Tamano,
			ProViajesContenedoresEquipos.Sellos = #TempProViajesContenedoresEquipos.ATT_Sellos,
			ProViajesContenedoresEquipos.SecuenciaTrayecto = #TempProViajesContenedoresEquipos.ATT_SecuenciaTrayecto,
			ProViajesContenedoresEquipos.Cargado = #TempProViajesContenedoresEquipos.ATT_Cargado,
			ProViajesContenedoresEquipos.IdUnidadCarga = CASE #TempProViajesContenedoresEquipos.ATT_IdUnidadCarga WHEN 0 THEN NULL ELSE #TempProViajesContenedoresEquipos.ATT_IdUnidadCarga END,
			ProViajesContenedoresEquipos.IdDetalleEntregaContenedor = CASE #TempProViajesContenedoresEquipos.ATT_IdDetalleEntregaContenedor WHEN 0 THEN NULL ELSE #TempProViajesContenedoresEquipos.ATT_IdDetalleEntregaContenedor END
		FROM ProViajesContenedoresEquipos 
		INNER JOIN #TempProViajesContenedoresEquipos ON ProViajesContenedoresEquipos.IdViajeContenedorEquipo = #TempProViajesContenedoresEquipos.ATT_IdViajeContenedorEquipo

	END	

	--Se desligan del viaje los contenedores que ya no estan asignados a ningun trayecto
	
	DELETE FROM ProViajesContenedoresEquipos WHERE IdViaje = @IdViaje AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	UPDATE ProDetalleEntregaContenedores SET IdViaje = NULL WHERE IdViaje = @IdViaje AND IdDetalleEntregaContenedores NOT IN  (Select PVCEC.IdDetalleEntregaContenedor From ProViajesContenedoresEquipos AS PVCEC WHERE PVCEC.IdViaje = @IdViaje)	

	--Agregar conocimiento de embarque - Solicitud 908
	IF @dsProViajesCartaPorteConocimientoEmbarque iS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesCartaPorteConocimientoEmbarque

		SELECT ATT_IdViajeCartaPorteConocimientoEmbarque,ATT_IdMaterialPemex,ATT_PrecioUnitario,ATT_TipoConocimientoEmbarque,ATT_NumeroEmbarque1,ATT_FechaSalidaEmbarque1,
		ATT_VolumenSalidaEmbarque1,ATT_TemperaturaSalidaEmbarque1,ATT_VolumenCorregidoSalidaEmbarque1,ATT_FechaLlegadaEmbarque1,
		ATT_VolumenLlegadaEmbarque1,ATT_TemperaturaLlegadaEmbarque1,ATT_VolumenCorregidoLlegadaEmbarque1,ATT_NumeroEmbarque2,
		ATT_FechaSalidaEmbarque2,ATT_VolumenSalidaEmbarque2,ATT_TemperaturaSalidaEmbarque2,ATT_VolumenCorregidoSalidaEmbarque2,ATT_FechaLlegadaEmbarque2,
		ATT_VolumenLlegadaEmbarque2,ATT_TemperaturaLlegadaEmbarque2,ATT_VolumenCorregidoLlegadaEmbarque2
		INTO #TempProViajesCartasPorteConocimientoEmbarque
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesCartasPorteConocimientoEmbarque',2) 
		WITH (ATT_IdViajeCartaPorteConocimientoEmbarque INT,ATT_IdMaterialPemex INT,ATT_PrecioUnitario DECIMAL(12,6),ATT_TipoConocimientoEmbarque INT,ATT_NumeroEmbarque1 INT,ATT_FechaSalidaEmbarque1 VARCHAR(30),
		ATT_VolumenSalidaEmbarque1 DECIMAL(12,3),ATT_TemperaturaSalidaEmbarque1 DECIMAL(12,2),ATT_VolumenCorregidoSalidaEmbarque1 DECIMAL(12,3),ATT_FechaLlegadaEmbarque1 VARCHAR(30),
		ATT_VolumenLlegadaEmbarque1 DECIMAL(12,3),ATT_TemperaturaLlegadaEmbarque1 DECIMAL(12,2),ATT_VolumenCorregidoLlegadaEmbarque1 DECIMAL(12,3),ATT_NumeroEmbarque2 INT,
		ATT_FechaSalidaEmbarque2 VARCHAR(30),ATT_VolumenSalidaEmbarque2 DECIMAL(12,3),ATT_TemperaturaSalidaEmbarque2 DECIMAL(12,2),ATT_VolumenCorregidoSalidaEmbarque2 DECIMAL(12,3),ATT_FechaLlegadaEmbarque2 VARCHAR(30),
		ATT_VolumenLlegadaEmbarque2 DECIMAL(12,3),ATT_TemperaturaLlegadaEmbarque2 DECIMAL(12,2),ATT_VolumenCorregidoLlegadaEmbarque2 DECIMAL(12,3))

		EXEC sp_xml_removedocument @docHandle

		--SI no existe el conocimiento de embarque se crea
		IF NOT EXISTS(SELECT * FROM ProViajesCartasPorteConocimientoEmbarque WHERE IdViajeCartaPorte = @IdViajeCartaPorte) 
			BEGIN
				INSERT INTO ProViajesCartasPorteConocimientoEmbarque(IdViajeCartaPorte,IdMaterialPemex,PrecioUnitario,CreadoPor,CreadoEl,TipoConocimientoEmbarque,NumeroEmbarque1,FechaSalidaEmbarque1,
				VolumenSalidaEmbarque1,TemperaturaSalidaEmbarque1,VolumenCorregidoSalidaEmbarque1,FechaLlegadaEmbarque1,VolumenLlegadaEmbarque1,TemperaturaLlegadaEmbarque1,VolumenCorregidoLlegadaEmbarque1,
				NumeroEmbarque2,FechaSalidaEmbarque2,VolumenSalidaEmbarque2,TemperaturaSalidaEmbarque2,VolumenCorregidoSalidaEmbarque2,FechaLlegadaEmbarque2,VolumenLlegadaEmbarque2,TemperaturaLlegadaEmbarque2,VolumenCorregidoLlegadaEmbarque2)
				SELECT @IdViajeCartaPorte,ATT_IdMaterialPemex,ATT_PrecioUnitario,@ModificadoPor,@ModificadoEl,ATT_TipoConocimientoEmbarque,ATT_NumeroEmbarque1,
				CASE ATT_FechaSalidaEmbarque1 WHEN 'NULL' THEN NULL ELSE ATT_FechaSalidaEmbarque1 END,ATT_VolumenSalidaEmbarque1,ATT_TemperaturaSalidaEmbarque1,ATT_VolumenCorregidoSalidaEmbarque1,
				CASE ATT_FechaLlegadaEmbarque1 WHEN 'NULL' THEN NULL ELSE ATT_FechaLlegadaEmbarque1 END,ATT_VolumenLlegadaEmbarque1,ATT_TemperaturaLlegadaEmbarque1,ATT_VolumenCorregidoLlegadaEmbarque1,
				ATT_NumeroEmbarque2,CASE ATT_FechaSalidaEmbarque2  WHEN 'NULL' THEN NULL ELSE ATT_FechaSalidaEmbarque2 END,ATT_VolumenSalidaEmbarque2,ATT_TemperaturaSalidaEmbarque2,ATT_VolumenCorregidoSalidaEmbarque2,
				CASE ATT_FechaLlegadaEmbarque2 WHEN 'NULL' THEN NULL ELSE ATT_FechaLlegadaEmbarque2 END,ATT_VolumenLlegadaEmbarque2,ATT_TemperaturaLlegadaEmbarque2,ATT_VolumenCorregidoLlegadaEmbarque2
				FROM #TempProViajesCartasPorteConocimientoEmbarque
			END
		ELSE
			BEGIN
				UPDATE ProViajesCartasPorteConocimientoEmbarque SET 
						ProViajesCartasPorteConocimientoEmbarque.IdMaterialPemex = #TempProViajesCartasPorteConocimientoEmbarque.ATT_IdMaterialPemex,
						ProViajesCartasPorteConocimientoEmbarque.PrecioUnitario = #TempProViajesCartasPorteConocimientoEmbarque.ATT_PrecioUnitario,
						ProViajesCartasPorteConocimientoEmbarque.ModificadoPor = @ModificadoPor,
						ProViajesCartasPorteConocimientoEmbarque.ModificadoEl = @ModificadoEl,
						ProViajesCartasPorteConocimientoEmbarque.TipoConocimientoEmbarque = #TempProViajesCartasPorteConocimientoEmbarque.ATT_TipoConocimientoEmbarque,
						ProViajesCartasPorteConocimientoEmbarque.NumeroEmbarque1 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_NumeroEmbarque1,
						ProViajesCartasPorteConocimientoEmbarque.FechaSalidaEmbarque1 = CASE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaSalidaEmbarque1 WHEN 'NULL' THEN NULL ELSE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaSalidaEmbarque1 END,
						ProViajesCartasPorteConocimientoEmbarque.VolumenSalidaEmbarque1 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenSalidaEmbarque1,
						ProViajesCartasPorteConocimientoEmbarque.TemperaturaSalidaEmbarque1 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_TemperaturaSalidaEmbarque1,
						ProViajesCartasPorteConocimientoEmbarque.VolumenCorregidoSalidaEmbarque1 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenCorregidoSalidaEmbarque1,
						ProViajesCartasPorteConocimientoEmbarque.FechaLlegadaEmbarque1 = CASE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaLlegadaEmbarque1 WHEN 'NULL' THEN NULL ELSE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaLlegadaEmbarque1 END,
						ProViajesCartasPorteConocimientoEmbarque.VolumenLlegadaEmbarque1 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenLlegadaEmbarque1,
						ProViajesCartasPorteConocimientoEmbarque.TemperaturaLlegadaEmbarque1 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_TemperaturaLlegadaEmbarque1,
						ProViajesCartasPorteConocimientoEmbarque.VolumenCorregidoLlegadaEmbarque1 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenCorregidoLlegadaEmbarque1,
						ProViajesCartasPorteConocimientoEmbarque.NumeroEmbarque2 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_NumeroEmbarque2,
						ProViajesCartasPorteConocimientoEmbarque.FechaSalidaEmbarque2 = CASE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaSalidaEmbarque2 WHEN 'NULL' THEN NULL ELSE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaSalidaEmbarque2 END,
						ProViajesCartasPorteConocimientoEmbarque.VolumenSalidaEmbarque2 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenSalidaEmbarque2,
						ProViajesCartasPorteConocimientoEmbarque.TemperaturaSalidaEmbarque2 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_TemperaturaSalidaEmbarque2,
						ProViajesCartasPorteConocimientoEmbarque.VolumenCorregidoSalidaEmbarque2 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenCorregidoSalidaEmbarque2,
						ProViajesCartasPorteConocimientoEmbarque.FechaLlegadaEmbarque2 = CASE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaLlegadaEmbarque2 WHEN 'NULL' THEN NULL ELSE #TempProViajesCartasPorteConocimientoEmbarque.ATT_FechaLlegadaEmbarque2 END,
						ProViajesCartasPorteConocimientoEmbarque.VolumenLlegadaEmbarque2 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenLlegadaEmbarque2,
						ProViajesCartasPorteConocimientoEmbarque.TemperaturaLlegadaEmbarque2 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_TemperaturaLlegadaEmbarque2,
						ProViajesCartasPorteConocimientoEmbarque.VolumenCorregidoLlegadaEmbarque2 = #TempProViajesCartasPorteConocimientoEmbarque.ATT_VolumenCorregidoLlegadaEmbarque2
					FROM ProViajesCartasPorteConocimientoEmbarque
					INNER JOIN #TempProViajesCartasPorteConocimientoEmbarque ON ProViajesCartasPorteConocimientoEmbarque.IdViajeCartaPorteConocimientoEmbarque = #TempProViajesCartasPorteConocimientoEmbarque.ATT_IdViajeCartaPorteConocimientoEmbarque
			END
	END

	--Se agrego el seguro
	IF @dsProViajesCartaPorteSeguros iS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesCartaPorteSeguros

		SELECT
		  ATT_IdViajeCartaPorteSeguro
		, ATT_AseguradoraMedioAmbiente
		, ATT_AseguradoraMedioAmbientePoliza
		, ATT_AseguradoraCarga
		, ATT_AseguradoraCargaPoliza
		, ATT_PrimaSeguroCarga
		INTO #TempProViajesCartasPorteSeguros
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesCartasPorteSeguros', 2) 
		WITH (ATT_IdViajeCartaPorteSeguro INT
			, ATT_AseguradoraMedioAmbiente VARCHAR(50)
		    , ATT_AseguradoraMedioAmbientePoliza VARCHAR(30)
			, ATT_AseguradoraCarga VARCHAR(50)
			, ATT_AseguradoraCargaPoliza VARCHAR(30)
			, ATT_PrimaSeguroCarga MONEY)

		EXEC sp_xml_removedocument @docHandle

		--SI no existe el conocimiento de embarque se crea
		IF NOT EXISTS(SELECT IdViajeCartaPorteSeguro FROM ProViajesCartasPorteSeguros WHERE IdViajeCartaPorte = @IdViajeCartaPorte) 
			BEGIN
				INSERT INTO ProViajesCartasPorteSeguros (IdViajeCartaPorte, AseguradoraMedioAmbiente, PolizaMedioAmbiente, AseguradoraCarga, PolizaCarga, PrimaSeguro, CreadoPor, CreadoEl)
				SELECT 
				  @IdViajeCartaPorte
				, ATT_AseguradoraMedioAmbiente
				, ATT_AseguradoraMedioAmbientePoliza
				, ATT_AseguradoraCarga
				, ATT_AseguradoraCargaPoliza
				, ATT_PrimaSeguroCarga
				, @ModificadoPor
				, @ModificadoEl
				FROM #TempProViajesCartasPorteSeguros
			END
		ELSE
			BEGIN
				UPDATE ProViajesCartasPorteSeguros SET
					ProViajesCartasPorteSeguros.AseguradoraMedioAmbiente = #TempProViajesCartasPorteSeguros.ATT_AseguradoraMedioAmbiente,
					ProViajesCartasPorteSeguros.PolizaMedioAmbiente = #TempProViajesCartasPorteSeguros.ATT_AseguradoraMedioAmbientePoliza,
					ProViajesCartasPorteSeguros.AseguradoraCarga = #TempProViajesCartasPorteSeguros.ATT_AseguradoraCarga,
					ProViajesCartasPorteSeguros.PolizaCarga = #TempProViajesCartasPorteSeguros.ATT_AseguradoraCargaPoliza,
					ProViajesCartasPorteSeguros.PrimaSeguro = #TempProViajesCartasPorteSeguros.ATT_PrimaSeguroCarga,
					ProViajesCartasPorteSeguros.ModificadoPor = @ModificadoPor,
					ProViajesCartasPorteSeguros.ModificadoEl = @ModificadoEl
				FROM ProViajesCartasPorteSeguros
				INNER JOIN #TempProViajesCartasPorteSeguros ON ProViajesCartasPorteSeguros.IdViajeCartaPorteSeguro = #TempProViajesCartasPorteSeguros.ATT_IdViajeCartaPorteSeguro
			END
	END

	--actualiza el saldo del cliente 
	IF @Facturable = 1
	BEGIN
		IF @ViajeConCP = 1
		BEGIN
			IF @IdMoneda = 1 OR @IdMoneda = 3
				UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0) + @Total WHERE IdCliente = @IdCliente
			ELSE
				UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) + @Total WHERE IdCliente = @IdCliente	
		END
		ELSE
		BEGIN
			IF @IdMoneda = 1 OR @IdMoneda = 3
				UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0) + @SubTotal WHERE IdCliente = @IdCliente
			ELSE
				UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) + @SubTotal WHERE IdCliente = @IdCliente	
		END		
	END

	IF @PermitirDocumentarRebaseCredito = 0
	BEGIN
		IF @IdMoneda = 1 OR @IdMoneda = 3
		BEGIN
			IF (SELECT ISNULL(PendFacturar,0)+ISNULL(SaldoCredito,0) FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT Credito FROM CatClientes WHERE IdCliente = @IdCliente)
				RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
					16,
					1
					)
		END
		ELSE
		BEGIN
			IF (SELECT ISNULL(PendFacturarDLLS,0)+ISNULL(SaldoCreditoDLLS,0) FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT CreditoDLLS FROM CatClientes WHERE IdCliente = @IdCliente)
				RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
					16,
					1
					)	
		END
	END	
	
	COMMIT
END TRY
BEGIN CATCH
	SET @IdViaje = -1
	IF(@@TRANCOUNT>0)
	BEGIN

	IF (SELECT CURSOR_STATUS('LOCAL','ProViajesTrayectosCursor')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','ProViajesTrayectosCursor')) > -1
		BEGIN
			CLOSE ProViajesTrayectosCursor
		END
	  DEALLOCATE ProViajesTrayectosCursor
	  END

	  IF (SELECT CURSOR_STATUS('LOCAL','CursorViajesConceptosFacturacion')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorViajesConceptosFacturacion')) > -1
		BEGIN
			CLOSE CursorViajesConceptosFacturacion
		END
	  DEALLOCATE CursorViajesConceptosFacturacion
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorProViajesDescripcionesCarga')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorProViajesDescripcionesCarga')) > -1
		BEGIN
			CLOSE CursorProViajesDescripcionesCarga
		END
	  DEALLOCATE CursorProViajesDescripcionesCarga
	  END

	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH

RETURN @IdViaje
go

