
CREATE PROCEDURE [dbo].[usp_CatTarifaEliminarArregloPQ](
	@IdTarifa INT)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdTarifa,0) <= 0 begin
			RAISERROR(N'*INICIO*El Identidicador de Tarifaes un campo requerido*FIN*', 16, 1);
			return 
		end;

		DELETE FROM CatTarifaCobroPQ
		WHERE IdTarifa= @IdTarifa

		DELETE FROM CatTarifaConceptosPQ
		WHERE IdTarifa= @IdTarifa

		DELETE FROM CatTarifaServicioPQ
		WHERE IdTarifa= @IdTarifa

		DELETE FROM CatProductosTarifaPQ
		WHERE IdTarifa = @IdTarifa

		DELETE FROM CatTarifaDestinosPQ
		WHERE IdTarifa = @IdTarifa

	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

