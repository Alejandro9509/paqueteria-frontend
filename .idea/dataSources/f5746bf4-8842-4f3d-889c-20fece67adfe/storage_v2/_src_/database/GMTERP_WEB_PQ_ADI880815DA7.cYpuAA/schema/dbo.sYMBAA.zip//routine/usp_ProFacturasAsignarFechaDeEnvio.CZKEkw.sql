
CREATE PROCEDURE [dbo].[usp_ProFacturasAsignarFechaDeEnvio]
	@IdFactura int,	
	@FechaDeEnvio datetime,	
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,	
	@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION		

	IF @IdFactura = 0
		RAISERROR(N'El identificador de la factura es un campo requerido',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM ProFacturas WHERE IdFactura = @IdFactura) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
	IF ISDATE(@FechaDeEnvio) = 0			
		RAISERROR(N'La fecha de envío es un campo requerido',
			16,
			1
			)

	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 1--pagada
		RAISERROR(N'No puede ser modificada esta factura porque está pagada',
			16,
			1
			)
			
	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 2--cancelada
		RAISERROR(N'No puede ser modificada esta factura porque está cancelada',
			16,
			1
			)
	IF @FechaDeEnvio < (SELECT Isnull(FechaHora,0) FROM ProFacturas Where IdFactura = @IdFactura)
		RAISERROR(N'La fecha de envío no puede ser menor a la de la factura',
			16,
			1
			)
	IF (SELECT FacturaExterna FROM ProFacturas WHERE IdFactura = @IdFactura) = 1 
			RAISERROR(N'No se puede ser modificada esta facura por que es externa',
			16,
			1
			)
							
	
	UPDATE ProFacturas SET		
		FechaDeEnvio = @FechaDeEnvio,		
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdFactura = @IdFactura		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

