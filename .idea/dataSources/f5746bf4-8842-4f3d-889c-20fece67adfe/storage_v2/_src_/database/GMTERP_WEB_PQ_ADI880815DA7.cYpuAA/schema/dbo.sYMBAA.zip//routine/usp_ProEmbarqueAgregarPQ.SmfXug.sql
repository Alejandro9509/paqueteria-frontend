CREATE PROCEDURE [dbo].[usp_ProEmbarqueAgregarPQ](
	@FolioEmbarque int ,
	@IdRecoleccion int ,
	@FolioGuia int ,
	@FolioInforme int ,
	@Fecha varchar(2),--no se usa
	@Hora varchar(2) ,--no se usa
	@FechaRegistro  varchar(80),
	@HoraRegistro  varchar(80),
	@IdEstatusEmbarque int ,
	@IdMoneda int ,
	@TipoCambio money ,
	@IdTipoCobro int ,
	@NombreRemitente varchar(150) ,
	@RFCRemitente varchar(13) ,
	@DomicilioRemitente varchar(250) ,
	@IdCodigoPostalRemitente int ,
	@IdCiudadRemitente int ,
	@CorreoRemitente varchar(150) ,
	@TelefonoRemitente varchar(20) ,
	@ContactoRemitente varchar(80) ,
	@IdCiudadOrigen int ,
	@NombreDestinatario varchar(150) ,
	@RFCDestinatario varchar(13) ,
	@DomicilioDestinatario varchar(250) ,
	@IdCodigoPostalDestinatario int ,
	@IdCiudadDestinatario int ,
	@CorreoDestinatario varchar(150) ,
	@TelefonoDestinatario varchar(20) ,
	@ContactoDestinatario varchar(80) ,
	@IdCiudadDestino int ,
	@FechaEntrega date,
	@HoraEntrega time(7),
	@NoPaquetes int ,
	@NoSobres int,
	@IdOperador int,
	@IdUnidad int,
	@EntregarMismoDomicilio bit,
	@FechaLlegada date,
	@HoraLlegada time(7),
	@CodigoPostalEntrega int,
	@IdCiudadEntrega int,
	@IdZonaEntrega int,
	@DomicilioEntrega varchar(200),
	@EntregarEn varchar(200),
	@DatosAdicionales varchar(500),
	@IdSucursal int,
	@EntregaEnSucursal bit,
	@IdSucursalEntrega int,
	@IdCliente int,
	@IdZonaRemitente int,
	@IdZonaDestinatario int,
	@IdRemitente int,
	@IdDestinatario int,
	@AliasRemitente varchar(100),
	@AliasDestinatario varchar(100),

	@CalleRemitente varchar(100),
	@NoIntRemitente varchar(20),
	@NoExtRemitente varchar(20),
	@ColoniaRemitente varchar(100),
	@CalleDestinatario varchar(100),
	@NoIntDestinatario varchar(20),
	@NoExtDestinatario varchar(20),
	@ColoniaDestinatario varchar(100),
	@EmbarqueConCita bit,
	@FechaCita varchar(50),
	@HoraCitaMinima varchar(50),
	@HoraCitaMaxima varchar(50),

	@IdEmbarqueRelacionado int,
		@Latitud text,
	@Longitud text,
	@IdZonaOperativa int,
	@IdZonaTarifa int,
	@IdEstadoRemitente int,
	@IdEstadoDestinatario int,
	@MunicipioRemitente varchar(100),
	@MunicipioDestinatario varchar(100),

	@IdZonaOperativaRecoleccion int,
	@IdZonaTarifaRecoleccion int,
	@IdEstadoEntrega int,
	@CodigoMunicipioEntrega varchar(100),
	@ValorDeclarado float,
    @IdTipoSeguro int,
	@PorcentajeSeguro float,
	@AplicaSeguro bit
	)
AS
BEGIN
	BEGIN TRANSACTION
		declare @FOLIO int;
		declare @FOLIOSTR varchar(10);
		DECLARE @FechaRegistroDate date;
	DECLARE @HoraRegistroTime time;

	DECLARE @FechaCitaDate date;
	DECLARE @HoraCitaMinimaTime time;
	DECLARE @HoraCitaMaximaTime time;

		IF ISNULL(@IdSucursal, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@FechaRegistro, '') = '' begin
			RAISERROR(N'*INICIO*La fecha de registro es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@HoraRegistro, '') = '' begin
			RAISERROR(N'*INICIO*La Hora de registro es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdEstatusEmbarque, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdMoneda, 0) = 0 begin
			RAISERROR(N'*INICIO*El Moneda de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@TipoCambio, 0) = 0 begin
			RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdTipoCobro, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de tipo de cobro es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoPaquetes, 0) < 0 begin
			RAISERROR(N'*INICIO*El numero de paquetes es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoSobres, 0) < 0 begin
			RAISERROR(N'*INICIO*El numero de sobres es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCliente, 0) = 0 begin
			RAISERROR(N'*INICIO*El responsable de pago es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
	
	EXEC @FOLIO = GenerarSecuenciaPQ @proceso=2;
		--	RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*' ,  -1, 1,@FOLIO )
	
	IF @FechaCita IS NOT NULL AND LEN(@FechaCita) > 1 begin
		set @FechaCitaDate= CAST(@FechaCita as date)
	end

	IF @HoraCitaMinima IS NOT NULL AND LEN(@HoraCitaMinima) > 1 begin
		set @HoraCitaMinimaTime= CAST(@HoraCitaMinima as time)
	end

	IF @HoraCitaMaxima IS NOT NULL AND LEN(@HoraCitaMaxima) > 1 begin
		set @HoraCitaMaximaTime= CAST(@HoraCitaMaxima as time)
	end

	IF @FechaRegistro IS NOT NULL AND LEN(@FechaRegistro) > 1 begin
	set @FechaRegistroDate = CAST(@FechaRegistro as date)
	set @HoraRegistroTime= CAST(@HoraRegistro as time)
	end
		select @FOLIOSTR = [dbo].[GeneraFolioPQ](2, @FOLIO);
		
		INSERT INTO dbo.ProEmbarquePQ(
			FolioEmbarque,
			IdRecoleccion
			,Fecha
			,Hora
			,IdEstatusEmbarque
			,IdMoneda
			,TipoCambio
			,IdTipoCobro
			,NombreRemitente
			,RFCRemitente
			,DomicilioRemitente
			,IdCodigoPostalRemitente
			,IdCiudadRemitente
			,CorreoRemitente
			,TelefonoRemitente
			,ContactoRemitente
			,IdCiudadOrigen
			,NombreDestinatario
			,RFCDestinatario
			,DomicilioDestinatario
			,IdCodigoPostalDestinatario
			,IdCiudadDestinatario
			,CorreoDestinatario
			,TelefonoDestinatario
			,ContactoDestinatario
			,IdCiudadDestino
			,FechaEntrega
			,HoraEntrega
			,NoPaquetes
			,NoSobres
			,IdOperador
			,IdUnidad,
			EntregarMismoDomicilio,
			FechaLlegada,
			HoraLlegada ,
			CodigoPostalEntrega ,
			IdCiudadEntrega ,
			IdZonaEntrega ,
			DomicilioEntrega ,
			EntregarEn ,
			DatosAdicionales,
			IdSucursal,
			FechaRegistro,
			HoraRegistro,
			EntregaEnSucursal,
			IdSucursalEntrega,
			IdCliente,
			IdZonaRemitente,
			IdZonaDestinatario,
			IdRemitente,
			IdDestinatario,
			AliasRemitente,
			AliasDestinatario,
			CalleRemitente,
			NoIntRemitente,
			NoExtRemitente,
			ColoniaRemitente,
			CalleDestinatario,
			NoIntDestinatario,
			NoExtDestinatario,
			ColoniaDestinatario,
			EmbarqueConCita,FechaCita,HoraCitaMinima,HoraCitaMaxima, IdEmbarqueRelacionado,
			Latitud, Longitud,
			IdZonaOperativa, IdZonaTarifa
			,IdEstadoRemitente,IdEstadoDestinatario,MunicipioRemitente,MunicipioDestinatario,IdZonaOperativaRecoleccion,IdZonaTarifaRecoleccion,IdEstadoEntrega,CodigoMunicipioEntrega, ValorDeclarado,
		    IdTipoSeguro,PorcentajeSeguro,AplicaSeguro
	  )    
	  VALUES
	  (
		@FOLIOSTR,@IdRecoleccion
		,@FechaRegistroDate,@HoraRegistroTime,@IdEstatusEmbarque,@IdMoneda,@TipoCambio
		,@IdTipoCobro,@NombreRemitente,@RFCRemitente,@DomicilioRemitente
		,@IdCodigoPostalRemitente,@IdCiudadRemitente,@CorreoRemitente
		,@TelefonoRemitente,@ContactoRemitente,@IdCiudadOrigen
		,@NombreDestinatario,@RFCDestinatario,@DomicilioDestinatario
		,@IdCodigoPostalDestinatario,@IdCiudadDestinatario,@CorreoDestinatario
		,@TelefonoDestinatario,@ContactoDestinatario,@IdCiudadDestino
		,@FechaEntrega,@HoraEntrega,@NoPaquetes,@NoSobres
		,@IdOperador,@IdUnidad,
		@EntregarMismoDomicilio,
		@FechaLlegada ,
		@HoraLlegada ,
		@CodigoPostalEntrega ,
		@IdCiudadEntrega ,
		@IdZonaEntrega ,
		@DomicilioEntrega ,
		@EntregarEn ,
		@DatosAdicionales,
		@IdSucursal,
		@FechaRegistroDate,
		@HoraRegistroTime,
		@EntregaEnSucursal,
		@IdSucursalEntrega,
		@IdCliente,
		@IdZonaRemitente,
		@IdZonaDestinatario,
		@IdRemitente,
		@IdDestinatario,
		@AliasRemitente,
		@AliasDestinatario,
		@CalleRemitente,
		@NoIntRemitente,
		@NoExtRemitente,
		@ColoniaRemitente,
		@CalleDestinatario,
		@NoIntDestinatario,
		@NoExtDestinatario,
		@ColoniaDestinatario, @EmbarqueConCita,@FechaCitaDate,@HoraCitaMinimaTime,@HoraCitaMaximaTime, @IdEmbarqueRelacionado,
		 @Latitud, @Longitud,
		 @IdZonaOperativa, @IdZonaTarifa
		 
		 ,@IdEstadoRemitente,
		 @IdEstadoDestinatario,
		 @MunicipioRemitente,
		 @MunicipioDestinatario,
		 @IdZonaOperativaRecoleccion,
		 @IdZonaTarifaRecoleccion,
		 @IdEstadoEntrega,
		 @CodigoMunicipioEntrega,
		 @ValorDeclarado,
	    @IdTipoSeguro,
	   @PorcentajeSeguro,
	   @AplicaSeguro
	  );
	  IF @EntregarMismoDomicilio = 0 and @EntregaEnSucursal = 0 BEGIN
	update CatRemitentesDestinatarios SET Latitud = @Latitud, Longitud = @Longitud Where IdRemitenteDestinatario = @IdDestinatario
	END
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION




		if @IdRecoleccion > 0 begin
			update ProRecoleccionPQ set IdEmbarque =@@IDENTITY where IdRecoleccion=@IdRecoleccion
		end






				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

