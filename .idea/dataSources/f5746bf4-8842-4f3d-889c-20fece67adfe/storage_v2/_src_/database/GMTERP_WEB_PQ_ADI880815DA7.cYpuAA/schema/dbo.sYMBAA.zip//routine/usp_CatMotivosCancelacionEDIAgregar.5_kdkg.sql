Create  PROCEDURE [dbo].[usp_CatMotivosCancelacionEDIAgregar]
@Codigo int,    
@Descripcion varchar(100),
@TextoLibre varchar(2000),
@CreadoEl    datetime,    
@CreadoPor    int,
@IdPeticion varchar(100)        
AS
BEGIN TRY
    BEGIN TRANSACTION
    IF ISNULL(@Codigo,0)= 0
        RAISERROR(N'El código de motivo de cancelación EDI es un campo requerido',
            16,
            1
            )
            
   	IF EXISTS(SELECT Codigo FROM CatMotivosCancelacionEDI WHERE Codigo = @Codigo)
		RAISERROR(N'El código de motivo de cancelación EDI ya existe',
			16,
			1
			)         
            
    IF ISNULL(@Descripcion,'')= ''
        RAISERROR(N'La descripcion de motivo de cancelación EDI es un campo requerido',
            16,
            1
            )
    INSERT INTO CatMotivosCancelacionEDI(Codigo,Descripcion,TextoLibre,CreadoEl,CreadoPor)
    VALUES(@Codigo,@Descripcion,@TextoLibre,@CreadoEl,@CreadoPor)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

