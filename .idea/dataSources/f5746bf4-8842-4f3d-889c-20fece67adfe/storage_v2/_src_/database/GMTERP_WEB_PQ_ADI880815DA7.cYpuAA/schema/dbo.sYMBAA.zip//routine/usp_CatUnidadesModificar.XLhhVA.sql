CREATE PROCEDURE [dbo].[usp_CatUnidadesModificar]
	@IdUnidad int,
	@IdTipoUnidad int,
	@Codigo varchar(16),
	@IdSucursal int,
	@IdOperador int,
	@Descripcion varchar(50),
	@Modelo smallint,
	@Activa bit,
	@SerieUnidad varchar(26),
	@SerieMotor varchar(26),
	@Placas varchar(9),
	@PlacasVencimiento datetime,
	@PlacasExtranjeras varchar(9),
	@PlacasExtranjerasVencimiento datetime,
	@Observaciones varchar(100),
	@Largo decimal(15,2),
	@Ancho decimal(15,2),
	@Alto decimal(15,2),
	@CantidadLlantas tinyint,
	@CapacidadTanqueCombustible int,
	@TipoCombustible tinyint,
	@RendimientoCargado decimal(15,2),
	@RendimientoVacio decimal(15,2),
	@Capacidad int,
	@TipoTransmision varchar(41),
	@TipoMotor varchar(41),
	@NumeroEjes tinyint,
	@CompaniaSeguros varchar(51),
	@TelefonosCompaniaSeguros varchar(21),
	@NumeroSeguro varchar(26),
	@VencimientoSeguro datetime,
	@TipoCoberturaSeguro tinyint,
	@PermisoSCT varchar(35),
	@VerificacionVehicular varchar(21),
	@VerificacionVehicularVencimiento datetime,
	@IdentificadorSatelital varchar(26),
	@Odometro int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@dsCatUnidadesImagenes ntext,
	@IdPeticion varchar(100),
	@CompaniaSeguros1 varchar(51),
	@TelefonosCompaniaSeguros1 varchar(21),
	@NumeroSeguro1 varchar(26),
	@VencimientoSeguro1 datetime,
	@TipoCoberturaSeguro1 tinyint,
	@TarjetaIAVE varchar(21),
	@TarjetaIAVE2 varchar(21),
	@PorcentajeRepIngresos decimal(15,2),
	@Rentada bit,
	@PlacasDefault tinyint,
	@dsCatUnidadesDocumentos ntext,
	@IdGrupoUnidad int,
	@TarjetaDiesel varchar(26),
	@TarjetaDiesel2 varchar(26),
	@EsUnidadPermisionario bit,
	@NumeroLlanta int,
	@LlantasRefaccion int,
	@IdTipoLlanta int,
	@IdMarcaLlanta int,
	@IdModeloLlanta int,
	@IdMedidaLlanta int,
	@IdPropietarioEquipo int,
	@AccesorioTV bit,
	@AccesorioAC bit,
	@AccesorioWIFI bit,
	@AccesorioDiscapacitados bit,
	@ColorUnidad varchar(20),
	@Horometro int,
	@CapacidadTanqueCombustibleGalones decimal(15,2),
	@OdometroMillas decimal (15,2),
	@RendimientoCargadoMillasGalones decimal(15,2),
	@RendimientoVacioMillasGalones decimal(15,2),
	@IdentificadorConvoy varchar(16),	
	@VelocidadPromedio decimal (15,2),
	@Neutralizaciones decimal (15,2),
	@FrenadosBrusco decimal (15,2),
	@CargaDeAceleracion decimal (15,2),
	@AccionamientoPedalDeFreno decimal (15,2),
	@VelocidadMaximaMotor decimal (15,2),
	@PorcUltimoCambio decimal (15,2),
	@VelocidadPromedioUM Varchar(20),
	@NeutralizacionesUM Varchar(20),
	@FrenadosBruscoUM Varchar(20),
	@CargaDeAceleracionUM Varchar(20),
	@AccionamientoPedalDeFrenoUM Varchar(20),
	@VelocidadMaximaMotorUM Varchar(20),
	@PorcUltimoCambioUM Varchar(20),
	@TarjetaDiesel3 Varchar(26),
	@HorasTrabajadasMotorNoGPS int = NULL,
	@TipoRemolqueSAT varchar(20) = NULL,
	@PermisoSCTSAT varchar(20) = NULL,
	@PesoTara decimal(15,3) = NULL,
	@TransporteRentadaOPrestadaSAT varchar(20) = NULL
AS
	/* *************************************************************************************************
	Procedimiento usp_CatUnidadesModificar

	Parámetros: 
	@IdUnidad int,
	@IdTipoUnidad int,
	@Codigo varchar(16),
	@IdSucursal int,
	@IdOperador int,
	@Descripcion varchar(50),
	@Modelo smallint,
	@Activa bit,
	@SerieUnidad varchar(26),
	@SerieMotor varchar(26),
	@Placas varchar(9),
	@PlacasVencimiento datetime,
	@PlacasExtranjeras varchar(9),
	@PlacasExtranjerasVencimiento datetime,
	@Observaciones varchar(100),
	@Largo decimal(15,2),
	@Ancho decimal(15,2),
	@Alto decimal(15,2),
	@CantidadLlantas tinyint,
	@CapacidadTanqueCombustible int,
	@TipoCombustible tinyint,
	@RendimientoCargado decimal(15,2),
	@RendimientoVacio decimal(15,2),
	@Capacidad int,
	@TipoTransmision varchar(41),
	@TipoMotor varchar(41),
	@NumeroEjes tinyint,
	@CompaniaSeguros varchar(51),
	@TelefonosCompaniaSeguros varchar(21),
	@NumeroSeguro varchar(26),
	@VencimientoSeguro datetime,
	@TipoCoberturaSeguro tinyint,
	@PermisoSCT varchar(35),
	@VerificacionVehicular varchar(21),
	@VerificacionVehicularVencimiento datetime,
	@IdentificadorSatelital varchar(26),
	@Odometro int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@dsCatUnidadesImagenes ntext,
	@IdPeticion varchar(100),
	@CompaniaSeguros1 varchar(51),
	@TelefonosCompaniaSeguros1 varchar(21),
	@NumeroSeguro1 varchar(26),
	@VencimientoSeguro1 datetime,
	@TipoCoberturaSeguro1 tinyint,
	@TarjetaIAVE varchar(21),
	@TarjetaIAVE2 varchar(21),
	@PorcentajeRepIngresos decimal(15,2),
	@Rentada bit,
	@PlacasDefault tinyint,
	@dsCatUnidadesDocumentos ntext,
	@IdGrupoUnidad int,
	@TarjetaDiesel varchar(26),
	@TarjetaDiesel2 varchar(26),
	@EsUnidadPermisionario bit,
	@NumeroLlanta int,
	@LlantasRefaccion int,
	@IdTipoLlanta int,
	@IdMarcaLlanta int,
	@IdModeloLlanta int,
	@IdMedidaLlanta int,
	@IdPropietarioEquipo int,
	@AccesorioTV bit,
	@AccesorioAC bit,
	@AccesorioWIFI bit,
	@AccesorioDiscapacitados bit,
	@ColorUnidad varchar(20),
	@Horometro int,
	@CapacidadTanqueCombustibleGalones decimal(15,2),
	@OdometroMillas decimal (15,2),
	@RendimientoCargadoMillasGalones decimal(15,2),
	@RendimientoVacioMillasGalones decimal(15,2),
	@IdentificadorConvoy varchar(16),	
	@VelocidadPromedio decimal (15,2),
	@Neutralizaciones decimal (15,2),
	@FrenadosBrusco decimal (15,2),
	@CargaDeAceleracion decimal (15,2),
	@AccionamientoPedalDeFreno decimal (15,2),
	@VelocidadMaximaMotor decimal (15,2),
	@PorcUltimoCambio decimal (15,2),
	@VelocidadPromedioUM Varchar(20),
	@NeutralizacionesUM Varchar(20),
	@FrenadosBruscoUM Varchar(20),
	@CargaDeAceleracionUM Varchar(20),
	@AccionamientoPedalDeFrenoUM Varchar(20),
	@VelocidadMaximaMotorUM Varchar(20),
	@PorcUltimoCambioUM Varchar(20),
	@TarjetaDiesel3 Varchar(26),
	@HorasTrabajadasMotorNoGPS = = NULL

	Descripción: Modifica datos de la unidad en la base de datos


	Modificado por: Enrique 
	Fecha de implementacion:  25/02/2020
	Versión: 8.0.50.14
	--Se elimino la actualizacion de las imagenes


	Invocada desde: CatUnidadesAM, ClsCatUnidades
	***************************************************************************************************** */
	/* *************************************************************************************************
	SOLICITUD 1178

	Descripcion: Se agrego el campo @HorasTrabajadasMotorNoGPS con el fin de utilizar el submodulo de mantenimiento "Servicios Programados"
	sin la necesidad de que la unidad tenga GPS.

	Modificada por:   Amado Navarro
	Fecha de mofidicacion: 27/02/2020
	Versión: Versión 8.0.50.18


	SOLICITUD 4143
	
	Descripcion: Se agregaron los campos @PesoTara, @PermisoSCTSAT y @TipoRemolqueSAT 

	Modificada por:   Gilberto Garcia
	Fecha de mofidicacion: 07/06/2021
	Versión: Versión 8.0.62.02

	Invocada desde: <CatUnidadesAM>
	************************************************************************************************ */

DECLARE
	@docHandle int,
	@CodigoUnidadTarjetaRegistrada varchar(16),
	@MensajeError varchar(200),
	@IdentificadorUnidad int
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdUnidad = 0
		RAISERROR(N'El identificador de la unidad es un campo requerido',
			16,
			1
			)
	
	--solicitud 11684 se cambio la evaluacion para que solo considera hasta los segundos porque en el cambio
	--que se hizo en unidades en el mapa al asignar imagen a la unidad se esta grabando con todo y milesimas de segundo
	IF (SELECT CONVERT(smalldatetime,ModificadoEl) FROM CatUnidades WHERE IdUnidad= @IdUnidad) <> CONVERT(smalldatetime,@UltimaModificacion)
		RAISERROR(N'Los datos de esta unidad fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)		
	
	IF LTRIM(RTRIM(@Codigo)) = ''
		RAISERROR(N'El código de la unidad es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Codigo FROM CatUnidades WHERE Codigo = @Codigo AND IdUnidad <> @IdUnidad)
		RAISERROR(N'El código de la unidad ya existe',
			16,
			1
			)

	IF @IdTipoUnidad = 0 
	RAISERROR(N'El tipo de unidad es un campo requerido',
		16,
		1
		)	

	IF @IdSucursal = 0 
	RAISERROR(N'La sucursal es un campo requerido',
		16,
		1
		)

	IF @IdGrupoUnidad = 0 
	RAISERROR(N'El grupo de unidades es un campo requerido',
		16,
		1
		)		
			
	IF LTRIM(RTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)

	--IF @NumeroEjes = 0 
	--RAISERROR(N'El número de ejes es un campo requerido',
	--	16,
	--	1
	--	)
	
	IF EXISTS(SELECT IdentificadorSatelital FROM CatUnidades WHERE IdentificadorSatelital = @IdentificadorSatelital AND IdUnidad <> @IdUnidad AND IdentificadorSatelital <> '')
	RAISERROR(N'El Identificador satelital de la unidad ya existe',
		16,
		1
		)	

	IF LTRIM(RTRIM(@TarjetaIAVE)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE (TarjetaIAVE = @TarjetaIAVE OR TarjetaIAVE2 = @TarjetaIAVE) AND IdUnidad <> @IdUnidad)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta iave/epass '+@TarjetaIAVE
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END	

	IF LTRIM(RTRIM(@TarjetaIAVE2)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE (TarjetaIAVE = @TarjetaIAVE2 OR TarjetaIAVE2 = @TarjetaIAVE2) AND IdUnidad <> @IdUnidad)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta iave/epass '+@TarjetaIAVE2
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END

	IF LTRIM(RTRIM(@TarjetaDiesel)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE (TarjetaDiesel = @TarjetaDiesel OR TarjetaDiesel2 = @TarjetaDiesel OR TarjetaDiesel3 = @TarjetaDiesel) AND IdUnidad <> @IdUnidad)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta combustible '+@TarjetaDiesel
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END	

	IF LTRIM(RTRIM(@TarjetaDiesel2)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE (TarjetaDiesel = @TarjetaDiesel2 OR TarjetaDiesel2 = @TarjetaDiesel2 OR TarjetaDiesel3 = @TarjetaDiesel2) AND IdUnidad <> @IdUnidad)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta combustible '+@TarjetaDiesel2
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END
	
	IF LTRIM(RTRIM(@TarjetaDiesel3)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE (TarjetaDiesel = @TarjetaDiesel3 OR TarjetaDiesel2 = @TarjetaDiesel3 OR TarjetaDiesel3 = @TarjetaDiesel3) AND IdUnidad <> @IdUnidad)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta combustible '+@TarjetaDiesel3
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END			
		
	IF @IdOperador = 0 
		SET @IdOperador = NULL
	ELSE
	BEGIN
		IF @EsUnidadPermisionario <> (SELECT EsPermisionario FROM CatOperadores WHERE IdOperador = @IdOperador)
		RAISERROR(N'La unidad y el operador deben tener el check de Permisionario activo para poder asignarse',
		16,
		1
		)
	END
	
	--SE CONVIERTEN LAS LLAVES FORANEAS A NULL SI VIENEN CERO
	
	IF @IdMarcaLlanta = 0
	BEGIN 
		SET @IdMarcaLlanta = NULL
	END
	
	IF @IdModeloLlanta = 0 
	BEGIN
		SET @IdModeloLlanta = NULL
	END
	
	IF @IdMedidaLlanta = 0
	BEGIN 
		SET @IdMedidaLlanta = NULL
	END
	
	IF @IdTipoLlanta = 0
	BEGIN 
		SET @IdTipoLlanta = NULL
	END		

	IF @IdPropietarioEquipo = 0
	BEGIN 
		SET @IdPropietarioEquipo = NULL
	END	
	
	IF @Horometro  = 0 
	BEGIN
		SET @Horometro = NULL
	END

		 --SE REALIZA LA VALIDACION PARA QUE NO SE REPITA EL Identificador del convoy en los vehiculos unitarios con tractocamiones, igual para los dollys mas 2 dollrs no podran tener el mismo identidicador
	 --de acuerdo con los semiremolques si se podra repetir pero no mas de 2 semiremolques podran tener el mismo identiciadaor
	 IF ISNULL(@IdentificadorConvoy,'') <>''
	 BEGIN
		SET @IdentificadorUnidad = (select Identificador from CatTiposUnidades where IdTipoUnidad = @IdTipoUnidad )
		--1 VEHICULI uNITARIO, 2 TRACTOCAMION
		IF @IdentificadorUnidad = 1 OR @IdentificadorUnidad = 2 
		BEGIN
			IF (SELECT count(cu.IdUnidad) as NumeroUnidades FROM CatUnidades AS cu INNER JOIN CatTiposUnidades AS ctp ON cu.IdTipoUnidad = ctp.IdTipoUnidad where  ctp.Identificador in (1,2) and cu.IdentificadorConvoy = @IdentificadorConvoy and cu.IdUnidad <> @IdUnidad  ) >= 1
				RAISERROR(N'El identificador ya existe',
					16,
					1
					)
		END
		--4 SEMIRREMOLQUE,
		IF  @IdentificadorUnidad = 4
		BEGIN
			IF (SELECT count(cu.IdUnidad) as NumeroUnidades FROM CatUnidades AS cu INNER JOIN CatTiposUnidades AS ctp ON cu.IdTipoUnidad = ctp.IdTipoUnidad where  ctp.Identificador = @IdentificadorUnidad and cu.IdentificadorConvoy = @IdentificadorConvoy and cu.IdUnidad <> @IdUnidad ) >= 2
				RAISERROR(N'El identificador ya existe',
					16,
					1
					)
		END

		--5 dolly,
		IF  @IdentificadorUnidad = 5
		BEGIN
			IF (SELECT count(cu.IdUnidad) as NumeroUnidades FROM CatUnidades AS cu INNER JOIN CatTiposUnidades AS ctp ON cu.IdTipoUnidad = ctp.IdTipoUnidad where  ctp.Identificador = @IdentificadorUnidad and cu.IdentificadorConvoy = @IdentificadorConvoy and cu.IdUnidad <> @IdUnidad ) >= 1
				RAISERROR(N'El identificador ya existe',
					16,
					1
					)
		END

	 END
		
	UPDATE CatUnidades SET 
	Activa = @Activa,
	Alto = @Alto,
	Ancho = @Ancho,
	CantidadLlantas = @CantidadLlantas,
	Capacidad = @Capacidad,
	CapacidadTanqueCombustible = @CapacidadTanqueCombustible,
	Codigo = @Codigo,
	CompaniaSeguros = @CompaniaSeguros,
	CompaniaSeguros1 = @CompaniaSeguros1,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor,
	Descripcion = @Descripcion,
	IdOperador = @IdOperador,
	IdSucursal = @IdSucursal,
	IdTipoUnidad = @IdTipoUnidad,
	IdentificadorSatelital = @IdentificadorSatelital,
	Largo = @Largo,
	Modelo = @Modelo,
	NumeroEjes = @NumeroEjes,
	NumeroSeguro = @NumeroSeguro,
	NumeroSeguro1 = @NumeroSeguro1,
	Observaciones = @Observaciones,
	Odometro = @Odometro,
	PermisoSCT = @PermisoSCT,
	Placas = @Placas,
	PlacasExtranjerasVencimiento = @PlacasExtranjerasVencimiento,
	PlacasExtranjeras = @PlacasExtranjeras,
	PlacasVencimiento = @PlacasVencimiento,
	RendimientoCargado = @RendimientoCargado,
	RendimientoVacio = @RendimientoVacio,
	SerieMotor = @SerieMotor,
	SerieUnidad = @SerieUnidad,
	TelefonosCompaniaSeguros = @TelefonosCompaniaSeguros,
	TelefonosCompaniaSeguros1 = @TelefonosCompaniaSeguros1,
	TipoCoberturaSeguro = @TipoCoberturaSeguro,
	TipoCoberturaSeguro1 = @TipoCoberturaSeguro1,
	TipoCombustible = @TipoCombustible,
	TipoMotor = @TipoMotor,
	TipoTransmision = @TipoTransmision,
	VencimientoSeguro = @VencimientoSeguro,
	VencimientoSeguro1 = @VencimientoSeguro1,
	VerificacionVehicular = @VerificacionVehicular,
	VerificacionVehicularVencimiento = @VerificacionVehicularVencimiento,
	TarjetaIAVE = @TarjetaIAVE,
	TarjetaIAVE2 = @TarjetaIAVE2,
	PorcentajeRepIngresos = @PorcentajeRepIngresos,
	Rentada = @Rentada,
	PlacasDefault = @PlacasDefault,
	IdGrupoUnidad = @IdGrupoUnidad,
	TarjetaDiesel = @TarjetaDiesel,
	TarjetaDiesel2 = @TarjetaDiesel2,
	EsUnidadPermisionario = @EsUnidadPermisionario,
	NumeroLlanta = @NumeroLlanta,
	LlantaRefaccion = @LlantasRefaccion,
	IdTipoLlanta = @IdTipoLlanta,
	IdMarcaLlanta = @IdMarcaLlanta,
	IdModeloLlanta = @IdModeloLlanta,
	IdMedidaLlanta = @IdMedidaLlanta,
	IdPropietarioEquipo = @IdPropietarioEquipo,
	AccesorioTV = @AccesorioTV, 
	AccesorioAC = @AccesorioAC,
	AccesorioWIFI = @AccesorioWIFI,
	AccesorioDiscapacitados = @AccesorioDiscapacitados,
	ColorUnidad = @ColorUnidad,
	Horometro = @Horometro,
	CapacidadTanqueCombustibleGalones = @CapacidadTanqueCombustibleGalones,
	OdometroMillas = @OdometroMillas,
	RendimientoCargadoMillasGalones = @RendimientoCargadoMillasGalones,
	RendimientoVacioMillasGalones = @RendimientoVacioMillasGalones,
	IdentificadorConvoy	= @IdentificadorConvoy,
	VelocidadPromedio=@VelocidadPromedio, 
	Neutralizaciones=@Neutralizaciones,
	FrenadosBrusco=@FrenadosBrusco, 
	CargaDeAceleracion=@CargaDeAceleracion, 
	AccionamientoPedalDeFreno=@AccionamientoPedalDeFreno,
	VelocidadMaximaMotor=@VelocidadMaximaMotor, 
	PorcUltimoCambio=@PorcUltimoCambio, 
	VelocidadPromedioUM=@VelocidadPromedioUM,
	NeutralizacionesUM=@NeutralizacionesUM, 
	FrenadosBruscoUM=@FrenadosBruscoUM,
	CargaDeAceleracionUM=@CargaDeAceleracionUM,
	AccionamientoPedalDeFrenoUM=@AccionamientoPedalDeFrenoUM, 
	VelocidadMaximaMotorUM=@VelocidadMaximaMotorUM,
	PorcUltimoCambioUM=@PorcUltimoCambioUM,
	TarjetaDiesel3=@TarjetaDiesel3,
	HorasTrabajadasMotorNoGPS = @HorasTrabajadasMotorNoGPS,
	TipoRemolqueSAT = @TipoRemolqueSAT,
	PermisoSCTSAT = @PermisoSCTSAT,
	PesoTara = @PesoTara,
	TransporteRentadaOPrestadaSAT = @TransporteRentadaOPrestadaSAT
	WHERE IdUnidad = @IdUnidad
		
	-- Fechas de vencimientos de documentos 
	IF @dsCatUnidadesDocumentos  IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUnidadesDocumentos 
		
		SELECT ATT_DescripcionDocumento,ATT_FechaVencimiento, ATT_IdUnidadDocumento,ATT_NumeroDocumento
		INTO #TempCatUnidadesDocumentos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatUnidadesDocumentos',2) 
		WITH (ATT_DescripcionDocumento Varchar(50),ATT_FechaVencimiento Datetime,ATT_IdUnidadDocumento Int,ATT_NumeroDocumento varchar(50))
		
		EXEC sp_xml_removedocument @docHandle
		
		UPDATE CatUnidadesDocumentos
		SET	CatUnidadesDocumentos.IdUnidad = @IdUnidad,
				CatUnidadesDocumentos.DescripcionDocumento = #TempCatUnidadesDocumentos.ATT_DescripcionDocumento,
				CatUnidadesDocumentos.FechaVencimiento = #TempCatUnidadesDocumentos.ATT_FechaVencimiento,
				CatUnidadesDocumentos.NumeroDocumento = #TempCatUnidadesDocumentos.ATT_NumeroDocumento
		FROM CatUnidadesDocumentos INNER JOIN #TempCatUnidadesDocumentos
		ON   CatUnidadesDocumentos.IdUnidadDocumento = #TempCatUnidadesDocumentos.ATT_IdUnidadDocumento 

		DELETE FROM CatUnidadesDocumentos WHERE IdUnidad = @IdUnidad AND IdUnidadDocumento    NOT IN(SELECT ATT_IdUnidadDocumento FROM #TempCatUnidadesDocumentos WHERE ATT_IdUnidadDocumento <> 0)
		
		INSERT INTO CatUnidadesDocumentos(IdUnidad,DescripcionDocumento,FechaVencimiento,NumeroDocumento)
		SELECT @IdUnidad,ATT_DescripcionDocumento,ATT_FechaVencimiento,ATT_NumeroDocumento
		FROM #TempCatUnidadesDocumentos
		WHERE ATT_IdUnidadDocumento = 0	
	END
	ELSE
	BEGIN
		DELETE FROM CatUnidadesDocumentos WHERE IdUnidad = @IdUnidad
	END
	
	
	INSERT INTO ProUnidadesOdometros(IdUnidad,Odometro,FechaLectura,Horometro,OdometroMillas)
	VALUES(@IdUnidad,@Odometro,@ModificadoEl,@Horometro,@OdometroMillas)	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

