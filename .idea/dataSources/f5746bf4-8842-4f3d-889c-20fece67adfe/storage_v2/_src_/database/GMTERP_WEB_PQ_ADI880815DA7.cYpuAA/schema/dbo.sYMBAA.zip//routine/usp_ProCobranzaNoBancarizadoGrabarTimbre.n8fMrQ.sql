
	create PROCEDURE [dbo].[usp_ProCobranzaNoBancarizadoGrabarTimbre]
		@IdCobranzaNoBancarizado int,
		@XMLArchivo ntext,
		@FolioFiscalUUID varchar(36),
		@FechaTimbrado datetime,
		@NoSerieCertificadoSAT varchar(20),
		@SelloSAT ntext,
		@CadenaOriginalTimbrado ntext,
		@TimbrePruebas bit,
		@IdPeticion varchar(100)
	AS
	BEGIN TRY
		BEGIN TRANSACTION
		--Se agrego validacion a peticion de la solicitud 009732
		IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado AND CanceladoEl IS NOT NULL )
			RAISERROR(N'No se puede timbrar este recibo de pago porque está cancelado',
				16,
				1
				)
							
		UPDATE ProCobranzaNoBancarizado
		SET FolioFiscalUUID = @FolioFiscalUUID,
			FechaTimbrado = @FechaTimbrado,
			NoSerieCertificadoSAT = @NoSerieCertificadoSAT,
			SelloSAT = @SelloSAT,
			CadenaOriginalTimbrado = @CadenaOriginalTimbrado,
			XMLArchivo = @XMLArchivo,
			TimbrePruebas = @TimbrePruebas
		WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado

		--El commit debe ser la ultima linea para garantizar que se grabe todo
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

