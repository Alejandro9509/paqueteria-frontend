
CREATE PROCEDURE [dbo].[usp_SisDerechoAgregarPQ](
	@IdUsuario int,
	@IdModulo int,
	@IdProceso int,
	@IdAccion int
	)
AS
--BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdUsuario, '') = '' begin
			RAISERROR(N'*INICIO*El IdUsuario es un campo requerido*FIN*', 16, 1)
			return
		end
		INSERT INTO SisDerechoPQ(IdUsuario, IdModulo, IdProceso, IdAccion)
		VALUES (@IdUsuario, @IdModulo, @IdProceso, @IdAccion)
	COMMIT TRANSACTION
--END TRY
--BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
--END CATCH
go

