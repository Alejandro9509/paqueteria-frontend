/* *************************************************************************************************
Script de agregar naviera para el catálogo de Navieras

Parámetros: 
	@IdNavieraTiempo				(entrada, int). Id del control de tiempos a modificar
	@IdNaviera int,					(entrada, int). Naviera asignada a control de tiempos
	@IdCliente int,					(entrada, int). Cliente asigado a control de tiempos
	@FreeDays int,					(entrada, int).
	@ChassisFreeDays int,			(entrada, int).
	@ContainerFreeDays int,			(entrada, int).
	@EffectiveDate datetime,		(entrada, fecha hora).
	@ServiceContract varchar(15),	(entrada, string).
	@ModificadoEl datetime,			(entrada, fecha hora). Fecha en la que se realiza la modificación
	@ModificadoPor int,				(entrada, entero). Quien solicita la modificación
	@UltimaModificacion datetime	(entrada, fecha hora). Fecha en la que se tiene registrada la última modificación del registro
	@IdPeticion varchar(100)		(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento actualiza la información de los tiempos de las navieras previamente creadas
			 para el Catálogo de Navieras del módulo Operación Portuaria.

Implementada por: David Rivera Navarro
Fecha de implementación: 23/07/2019
Versión: Versión 8.0.44.50

Modificada por:   David Rivera Navarro
Fecha de mofidicación: 25/07/2019
Versión: 8.0.45.13

Invocada desde: PAGE_CatNavierasTiemposPopUp (Solicitud 12874)

Valor de retorno: NA.

Ejemplo de Uso: NA.

***************************************************************************************************** */


CREATE PROCEDURE [dbo].[usp_CatNavierasTiemposModificar]
	@IdNavieraTiempo int,
	@IdNaviera int,
	@IdCliente int,
	@FreeDays int,
	@ChassisFreeDays int,
	@ContainerFreeDays int,
	@EffectiveDate datetime,
	@ServiceContract varchar(15),
	@ModificadoEl datetime,
	@ModificadoPor int,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	-- Se verifica que los valores contengan información antes de ser agregados
	IF ISNULL(@IdNavieraTiempo,0)= 0
		RAISERROR(N'El identificador de control de tiempos es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdNaviera,0)= 0
		RAISERROR(N'La naviera es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdCliente,0)= 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF ISNULL(@FreeDays,0)= 0
		RAISERROR(N'Free Days es un campo requerido',
			16,
			1
			)

	IF ISNULL(@ChassisFreeDays,0)= 0
		RAISERROR(N'Chassis Free Days es un campo requerido',
			16,
			1
			)

	IF ISNULL(@ContainerFreeDays,0)= 0
		RAISERROR(N'Container Free Days es un campo requerido',
			16,
			1
			)

	IF ISDATE(@EffectiveDate) = 0
		RAISERROR(N'Effective date es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@ServiceContract)) = ''
		RAISERROR(N'Service Contract es un campo requerido',
			16,
			1
			)

	/* Se verifica que la última fecha de modificación que se haya obtenido en la consulta se encuentre acorde a la Fecha que tenga
	   registrada en la base de datos para control de concurrencia */
	IF (SELECT ModificadoEl FROM CatNavierasTiempos WHERE IdNavieraTiempo = @IdNavieraTiempo) <> @UltimaModificacion
		RAISERROR(N'Los datos de este control de tiempos fuéron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)

	-- Se modifica un control de tiempos especifico
		UPDATE CatNavierasTiempos SET
		IdNaviera = @IdNaviera,
		IdCliente = @IdCliente,
		FreeDays = @FreeDays,
		ChassisFreeDays = @ChassisFreeDays,
		ContainerFreeDays = @ContainerFreeDays,
		EffectiveDate = @EffectiveDate,
		ServiceContract = @ServiceContract,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
		WHERE IdNavieraTiempo = @IdNavieraTiempo

		-- Si se realizó una modificación exitosa, se crea un historial para el registro de contol de tiempos 
		IF @@ROWCOUNT != 0
			INSERT INTO CatNavierasTiemposHistorial(CreadoEl, CreadoPor, IdNavieraTiempo, IdNaviera, IdCliente, FreeDays, ChassisFreeDays, ContainerFreeDays, EffectiveDate, ServiceContract)
			VALUES(@ModificadoEl, @ModificadoPor, @IdNavieraTiempo, @IdNaviera, @IdCliente, @FreeDays, @ChassisFreeDays, @ContainerFreeDays, @EffectiveDate, @ServiceContract)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

