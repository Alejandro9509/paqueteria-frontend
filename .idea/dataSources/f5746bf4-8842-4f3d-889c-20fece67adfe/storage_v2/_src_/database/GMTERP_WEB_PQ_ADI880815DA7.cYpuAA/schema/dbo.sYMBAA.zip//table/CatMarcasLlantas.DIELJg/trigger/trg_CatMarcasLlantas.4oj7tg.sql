

CREATE TRIGGER [dbo].[trg_CatMarcasLlantas]
    ON [dbo].[CatMarcasLlantas]
    AFTER UPDATE
AS
BEGIN               
    IF EXISTS(Select Top 1 IdMarcaLlanta 
				from CatModelosLlantas 
				Where IdMarcaLlanta = (SELECT IdMarcaLlanta FROM deleted d where  d.IdMarcaLlanta =IdMarcaLlanta)) 	
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.DescripcionMarca <> D.DescripcionMarca)
		RAISERROR(N'La Marca no se puede modificar porque ya cuenta con modelos ligados',
			16,
			1
			)
	END	                   
END
go

