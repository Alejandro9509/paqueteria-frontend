CREATE PROCEDURE [dbo].[usp_ProRecorridosModificar]
   	@IdRecorrido int,
    @FechaRecorrido datetime,
	@IdCliente int,
	@Ruta varchar(50),
	--@IdUnidad int,
	--@IdOperador int,
	--@HoraSalida datetime,
	@TiempoRuta decimal(15,2),
	@IdTurno int,
	@IdClasificacionViaje int,
	@IdTipoViaje int,
	@Facturable bit,
	@Observaciones varchar(512),
	@Kilometros int,
	@IdRutaPersonal int,
	@IdSucursal int,
	@FechaHoraRecorridoEstatus datetime,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdEstatuViaje int,
	@SubTotal money,
	@dsProRecorridosConceptosFacturacion ntext,
	@IdMoneda int,
	@TipoCambio money,
	@PendienteFacturar bit,
	@FacturadoParcialmente bit,
	@IdPeticion varchar(100),
	--@HoraReporte datetime,
	--@Referencia varchar(50),
	--@Placas varchar(9),
	@RutaGoogleMap ntext,
	--@CodigoUnidad varchar(16),
	--@NombreOperador varchar(100),
	@AccesorioTV bit,
	@AcesorioAC bit,
	@AccesorioWIFI bit,
	@AccesorioDiscapacitados bit,
	@IdOrigen int,
	@IdDestino int,
	--@IdTipoUnidad int,
	@IdSupervisorRutaPersonal int,
	--@IdPuesto int,
	@Puntos int, 
	--@Suben int,
	--@Bajan int, 
	--@Otros varchar (50) 
	@dsProRecorridosParadas ntext
/* 
Solicitud 001357
Procedimiento usp_ProRecorridosModificar
Descripción:	Se modififco el procedimiento de modificar para poder integrar las paradas en el recorrido
Modificada por: Gustavo Partida Nevarez 
Fecha de mofidicacion: 18/05/2020
*/
AS
DECLARE
	@docHandle int,
    @CursorIdConceptoFacturacion int,
	@CursorIdRecorridoConceptoFacturacion int , 
	@CursorTrasladaImpuesto bit,
	@CursorRetieneImpuesto bit,
	@CursorImporteConceptoFacturacion money, 
	@CursorObservaciones varchar(8000),
	@CursorUnidadMedida varchar(30), 
	@Recorrido int,
	@CursorIdOperador int,
	@CursorSecuencia int,
	@CursorIdUnidadCamion int,
	@CursorCodigoUnidadCamion varchar(6),
	@CursorPlacasUnidadCamion varchar(9),
	@CursorNombreOperador varchar(100),
	@CursorKilometros int,
	@CursorHoras decimal(15, 2),
	@CursorIdOrigen int,
	@CursorIdDestino int,
	@CursorPuntos int,
	@CursorSuben int,
	@CursorBajan int,
	@CursorOtros int,
	@CursorReferencia nvarchar(50),
	@CursorHoraReporte datetime,
	@CursorHoraSalida datetime,
	@CursorRutaGoogleMap varchar(max),
	@CursorIdRecorridoParada int,
	@CursorIdImpuestoTrasladado int,
	@CursorIdImpuestoRetenido int,
	@CursorImporteTrasladado money,
	@CursorImporteRetenido money,
	@IdRecorridoConceptoFacturacion int


BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdRecorrido,0) = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)
			
	IF (SELECT ModificadoEl FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)	

	IF EXISTS(SELECT CanceladoEl FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido AND CanceladoEl IS NOT NULL)
		RAISERROR(N'No puede ser modificado este recorrido porque está cancelado',
			16,
			1
			)
	

	IF @FechaRecorrido = ''			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaHoraRecorridoEstatus) = 0
		RAISERROR(N'La fecha y hora del estatus es un campo requerido',
			16,
			1
			)

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF @IdRutaPersonal = 0
		RAISERROR(N'La ruta es un campo requerido',
			16,
			1
			)
		
	IF @IdSucursal = 0
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)
	IF @IdEstatuViaje = 0
		RAISERROR(N'El estatus es un campo requerido',
			16,
			1
			)
	IF @dsProRecorridosConceptosFacturacion IS NULL
		RAISERROR(N'Los conceptos de facturacion son requeridos',
			16,
			1
			)	
	
	IF @dsProRecorridosParadas IS NULL
		RAISERROR(N'Las paradas son requeridas',
			16,
			1
			)
			
	IF @IdTipoViaje = 0
		SET @IdTipoViaje = NULL

	IF @IdClasificacionViaje = 0
		SET @IdClasificacionViaje = NULL  

	IF @IdSupervisorRutaPersonal = 0
		SET @IdSupervisorRutaPersonal = NULL
				
	/*SE ACTUALIZA EN LA TABLA PRORECORRIDOS*/
	UPDATE  ProRecorridos SET   
		FechaRecorrido=@FechaRecorrido,
		IdCliente=@IdCliente,
		Ruta=@Ruta,
		TiempoRuta=@TiempoRuta,
		IdTurno=@IdTurno,
		IdClasificacionViaje=@IdClasificacionViaje,
		IdTipoViaje=@IdTipoViaje,
		Facturable=@Facturable,
		ModificadoPor=@ModificadoPor,
		ModificadoEl=@ModificadoEl,
		Observaciones=@Observaciones,
		Kilometros=@Kilometros,
		IdRutaPersonal=@IdRutaPersonal,
		IdSucursal=@IdSucursal,
		IdEstatuViaje=@IdEstatuViaje,
		FechaHoraRecorridoEstatus=@FechaHoraRecorridoEstatus,
		SubTotal= @SubTotal,
		IdMoneda= @IdMoneda,
		TipoCambio= @TipoCambio,
		RutaGoogleMap= @RutaGoogleMap,
		AccesorioTV= @AccesorioTV,
		AccesorioAC= @AcesorioAC,
		AccesorioWIFI= @AccesorioWIFI,
		AccesorioDiscapacitados= @AccesorioDiscapacitados,
		IdOrigen= @IdOrigen,
		IdDestino= @IdDestino,
		IdSupervisorRutaPersonal=@IdSupervisorRutaPersonal,
		Puntos=@Puntos
	WHERE IdRecorrido = @IdRecorrido

	/*SE OBTIENEN LOS CONCEPTOS DE FACTURACION Y SE ACTUALIZA EN LA TABLA PRORECORRICOSCONCEPTOSFACTURACION*/
	IF @dsProRecorridosConceptosFacturacion IS NOT NULL 
	BEGIN
	
		DELETE FROM ProRecorridosConceptosFacturacionImpuestos 
		WHERE IdRecorridoConceptoFacturacion IN( SELECT IdRecorridoConceptoFacturacion FROM ProRecorridosConceptosFacturacion WHERE IdRecorrido = @IdRecorrido AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl)


		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProRecorridosConceptosFacturacion
			
		SELECT ATT_IdConceptoFacturacion,ATT_IdRecorridoConceptoFacturacion,ATT_TrasladaImpuesto,ATT_RetieneImpuesto,ATT_ImporteConceptoFacturacion,ATT_Observaciones,ATT_UnidadMedida,ATT_IdImpuestoTrasladado,ATT_IdImpuestoRetenido,ATT_ImporteTrasladado,ATT_ImporteRetenido
		INTO #TempProRecorridosConceptosFacturacion
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProRecorridosConceptosFacturacion',2) 
		WITH (ATT_IdConceptoFacturacion int,ATT_IdRecorridoConceptoFacturacion int,ATT_TrasladaImpuesto bit,ATT_RetieneImpuesto bit,ATT_ImporteConceptoFacturacion money,ATT_Observaciones varchar(8000),ATT_UnidadMedida varchar(30),ATT_IdImpuestoTrasladado int,ATT_IdImpuestoRetenido int,ATT_ImporteTrasladado money,ATT_ImporteRetenido money)

		EXEC sp_xml_removedocument @docHandle
		DECLARE CursorProRecorridosConceptosFacturacion CURSOR FOR
        SELECT * FROM #TempProRecorridosConceptosFacturacion
        
        OPEN CursorProRecorridosConceptosFacturacion
        FETCH NEXT FROM CursorProRecorridosConceptosFacturacion
        INTO @CursorIdConceptoFacturacion,@CursorIdRecorridoConceptoFacturacion,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorImporteConceptoFacturacion,@CursorObservaciones,@CursorUnidadMedida,@CursorIdImpuestoTrasladado,@CursorIdImpuestoRetenido,@CursorImporteTrasladado,@CursorImporteRetenido
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
			IF isnull(@CursorIdRecorridoConceptoFacturacion,0) = 0
			BEGIN
				INSERT INTO ProRecorridosConceptosFacturacion(IdRecorrido,IdConceptoFacturacion,TrasladaImpuesto,RetieneImpuesto,UnidadMedida,Importe,Observacion,CreadoPor,CreadoEl)
				VALUES(@IdRecorrido,@CursorIdConceptoFacturacion,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorUnidadMedida,@CursorImporteConceptoFacturacion,@CursorObservaciones,@ModificadoPor,@ModificadoEl)
				
				SET @IdRecorridoConceptoFacturacion = (SELECT IDENT_CURRENT('ProRecorridosConceptosFacturacion'))

				IF @CursorIdImpuestoTrasladado != 0 
				BEGIN
					INSERT INTO ProRecorridosConceptosFacturacionImpuestos(IdRecorridoConceptoFacturacion,IdImpuesto,Importe)
					VALUES( @IdRecorridoConceptoFacturacion,@CursorIdImpuestoTrasladado,@CursorImporteTrasladado )
				END

				IF @CursorIdImpuestoRetenido != 0
				BEGIN
					INSERT INTO ProRecorridosConceptosFacturacionImpuestos(IdRecorridoConceptoFacturacion,IdImpuesto,Importe)
					VALUES( @IdRecorridoConceptoFacturacion,@CursorIdImpuestoRetenido,@CursorImporteRetenido )
				END
  			END
  			ELSE
  			BEGIN
  				UPDATE ProRecorridosConceptosFacturacion 
  				SET
  				IdConceptoFacturacion =  @CursorIdConceptoFacturacion,
  				TrasladaImpuesto = @CursorTrasladaImpuesto,
  				RetieneImpuesto = @CursorRetieneImpuesto,
				Importe = @CursorImporteConceptoFacturacion,
				UnidadMedida = @CursorUnidadMedida,
				Observacion = @CursorObservaciones,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
				WHERE IdRecorridoConceptoFacturacion = @CursorIdRecorridoConceptoFacturacion
				
				
				DECLARE @nIdRecorridoConceptoFacturacion int
				SET @nIdRecorridoConceptoFacturacion = (SELECT IdRecorridoConceptoFacturacion FROM ProRecorridosConceptosFacturacion WHERE IdRecorrido = @IdRecorrido AND IdConceptoFacturacion = @CursorIdConceptoFacturacion)
				IF @nIdRecorridoConceptoFacturacion != 0
				BEGIN
					DELETE FROM ProRecorridosConceptosFacturacionImpuestos WHERE IdRecorridoConceptoFacturacion = @nIdRecorridoConceptoFacturacion

					IF @CursorIdImpuestoTrasladado != 0 
					BEGIN
						INSERT INTO ProRecorridosConceptosFacturacionImpuestos(IdRecorridoConceptoFacturacion,IdImpuesto,Importe)
						VALUES( @nIdRecorridoConceptoFacturacion,@CursorIdImpuestoTrasladado,@CursorImporteTrasladado )
					END

					IF @CursorIdImpuestoRetenido != 0
					BEGIN
						INSERT INTO ProRecorridosConceptosFacturacionImpuestos(IdRecorridoConceptoFacturacion,IdImpuesto,Importe)
						VALUES( @nIdRecorridoConceptoFacturacion,@CursorIdImpuestoRetenido,@CursorImporteRetenido )
					END
				END
				
  			END
			FETCH NEXT FROM CursorProRecorridosConceptosFacturacion
			INTO @CursorIdConceptoFacturacion,@CursorIdRecorridoConceptoFacturacion,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorImporteConceptoFacturacion,@CursorObservaciones,@CursorUnidadMedida,@CursorIdImpuestoTrasladado,@CursorIdImpuestoRetenido,@CursorImporteTrasladado,@CursorImporteRetenido

        END
        CLOSE CursorProRecorridosConceptosFacturacion
        DEALLOCATE CursorProRecorridosConceptosFacturacion      
    END
	DELETE FROM ProRecorridosConceptosFacturacion WHERE IdRecorrido = @IdRecorrido AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	/*SE OBTIENEN LAS PARADAS Y SE INSERTAN EN LA TABLA PRORECORRICOPARADAS*/
	IF @dsProRecorridosParadas IS NOT NULL
    BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProRecorridosParadas

		SELECT ATT_IdRecorridoParada,ATT_IdOperador,ATT_Secuencia,ATT_IdUnidadCamion,ATT_CodigoUnidadCamion,ATT_PlacasUnidadCamion,ATT_NombreOperador,ATT_Kilometros,ATT_Horas,ATT_IdOrigen,ATT_IdDestino,ATT_Puntos,ATT_Suben,ATT_Bajan,ATT_Otros,
		ATT_Referencia,ATT_HoraReporte,ATT_HoraSalida,ATT_RutaGoogleMap
		INTO #TempProRecorridosParadas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProRecorridosParadas',2) 
		WITH (ATT_IdRecorridoParada int,ATT_IdOperador int,ATT_Secuencia int,ATT_IdUnidadCamion int,ATT_CodigoUnidadCamion varchar(6),ATT_PlacasUnidadCamion varchar(9),ATT_NombreOperador varchar(100),ATT_Kilometros int,ATT_Horas decimal(15, 2),
		ATT_IdOrigen int,ATT_IdDestino int,ATT_Puntos int,ATT_Suben int,ATT_Bajan int,ATT_Otros int,ATT_Referencia nvarchar(50),ATT_HoraReporte datetime,ATT_HoraSalida datetime,ATT_RutaGoogleMap ntext)
		EXEC sp_xml_removedocument @docHandle
	    DECLARE CursorProRecorridosParadas CURSOR FOR
        SELECT * FROM #TempProRecorridosParadas
		
		OPEN CursorProRecorridosParadas
        FETCH NEXT FROM CursorProRecorridosParadas
        INTO 	@CursorIdRecorridoParada,@CursorIdOperador,@CursorSecuencia,@CursorIdUnidadCamion,@CursorCodigoUnidadCamion,@CursorPlacasUnidadCamion,@CursorNombreOperador,@CursorKilometros,@CursorHoras,@CursorIdOrigen,@CursorIdDestino,@CursorPuntos,
				@CursorSuben,@CursorBajan,@CursorOtros,@CursorReferencia,@CursorHoraReporte,@CursorHoraSalida,@CursorRutaGoogleMap
        
        WHILE @@FETCH_STATUS = 0
		BEGIN
			IF ISNULL(@CursorIdRecorridoParada,0) = 0
			BEGIN
				INSERT INTO ProRecorridoParadas(IdRecorrido,Secuencia,IdOrigen,IdDestino,IdUnidadCamion,CodigoUnidadCamion,PlacasUnidadCamion,IdOperador,NombreOperador,Kilometros,CreadoPor,CreadoEl,RutaGoogleMap,Otros,Bajan,Suben,Horas,Referencia,HoraSalida,HoraReporte,Puntos)
				VALUES(@IdRecorrido,@CursorSecuencia,@CursorIdOrigen,@CursorIdDestino,@CursorIdUnidadCamion,@CursorCodigoUnidadCamion,@CursorPlacasUnidadCamion,@CursorIdOperador,@CursorNombreOperador,@CursorKilometros,@ModificadoPor,@ModificadoEl,@CursorRutaGoogleMap,@CursorOtros,@CursorBajan,@CursorSuben,@CursorHoras,@CursorReferencia,@CursorHoraSalida,@CursorHoraReporte,@CursorPuntos)
			END
			ELSE
  			BEGIN
  				UPDATE ProRecorridoParadas 
  				SET
  					Secuencia =  @CursorSecuencia,
  					IdUnidadCamion = @CursorIdUnidadCamion,
					CodigoUnidadCamion = @CursorCodigoUnidadCamion,
					PlacasUnidadCamion = @CursorPlacasUnidadCamion,
					IdOperador = @CursorIdOperador,
					NombreOperador = @CursorNombreOperador,
					Kilometros = @CursorKilometros,
					Otros = @CursorOtros,
					Bajan = @CursorBajan,
					Suben = @CursorSuben,
					Horas = @CursorHoras,
					Referencia = @CursorReferencia,
					HoraSalida = @CursorHoraSalida,
					HoraReporte = @CursorHoraReporte,
					Puntos = @CursorPuntos,
					ModificadoEl = @ModificadoEl,
					ModificadoPor = @ModificadoPor
				WHERE IdRecorridoParada = @CursorIdRecorridoParada
  			END
			FETCH NEXT FROM CursorProRecorridosParadas
			INTO @CursorIdRecorridoParada,@CursorIdOperador,@CursorSecuencia,@CursorIdUnidadCamion,@CursorCodigoUnidadCamion,@CursorPlacasUnidadCamion,@CursorNombreOperador,@CursorKilometros,@CursorHoras,@CursorIdOrigen,@CursorIdDestino,@CursorPuntos,
				@CursorSuben,@CursorBajan,@CursorOtros,@CursorReferencia,@CursorHoraReporte,@CursorHoraSalida,@CursorRutaGoogleMap
		END
        CLOSE CursorProRecorridosParadas
        DEALLOCATE CursorProRecorridosParadas      
	END 

	DELETE FROM ProRecorridoParadas WHERE IdRecorrido = @IdRecorrido AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

