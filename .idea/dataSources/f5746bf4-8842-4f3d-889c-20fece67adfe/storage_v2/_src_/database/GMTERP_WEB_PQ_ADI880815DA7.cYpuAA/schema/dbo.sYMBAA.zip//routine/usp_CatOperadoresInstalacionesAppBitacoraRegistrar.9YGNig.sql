CREATE PROCEDURE [dbo].[usp_CatOperadoresInstalacionesAppBitacoraRegistrar]
	@IdOperador int,
	@NoTelefono varchar(10),
	@CreadoPor int,
	@IdPeticion varchar(100)
AS
	
SET XACT_ABORT ON	
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdOperador,0) = 0
		RAISERROR(N'El identificador del operador es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@NoTelefono,'') = ''
		RAISERROR(N'El número de teléfono es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT NoTelefono FROM CatOperadoresInstalacionesAppBitacora WHERE NoTelefono = @NoTelefono)
		RAISERROR(N'El número de teléfono ya esta registrado',
			16,
			1
			)

	IF EXISTS(SELECT NoTelefono FROM CatOperadoresInstalacionesAppBitacora WHERE NoTelefono = @NoTelefono AND IdOperador = @IdOperador)
		RAISERROR(N'El operador ya tiene registrado un teléfono',
			16,
			1
			)

	IF EXISTS(SELECT NoTelefono FROM CatOperadoresInstalacionesAppBitacora WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador ya tiene registrado un teléfono',
			16,
			1
			)

	INSERT INTO CatOperadoresInstalacionesAppBitacora(NoTelefono,IdOperador,CreadoPor,CreadoEl)
	VALUES(@NoTelefono,@IdOperador,@CreadoPor,GETDATE())
	
	COMMIT
END TRY

BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

