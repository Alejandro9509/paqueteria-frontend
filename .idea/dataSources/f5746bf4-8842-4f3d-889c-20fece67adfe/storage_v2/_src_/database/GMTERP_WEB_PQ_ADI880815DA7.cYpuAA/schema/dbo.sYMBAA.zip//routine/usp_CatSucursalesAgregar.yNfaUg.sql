
CREATE PROCEDURE [dbo].[usp_CatSucursalesAgregar]
	@Sucursal varchar(50),
	@Abreviacion varchar(12),
	@Calle varchar(100),
	@NoExterior varchar(20),
	@NoInterior varchar(20),
	@Colonia varchar(100),
	@Localidad varchar(100),
	@Municipio varchar(100),
	@IdEstado varchar(5),
	@CodigoPostal varchar(10),
	@IdImpuestoTraslado int,
	@Activa bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@ZonaHoraria decimal(5, 2),
	@DescripcionZonaHoraria	varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	IF LTRIM(RTRIM(@Sucursal)) = ''
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@Abreviacion)) = ''
		RAISERROR(N'La abreviacion es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@CodigoPostal)) = ''
		RAISERROR(N'El código postal es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@IdEstado)) = ''
		RAISERROR(N'El estado es un campo requerido',
			16,
			1
			)			

	IF LTRIM(RTRIM(@Municipio)) = ''
		RAISERROR(N'El municipio es un campo requerido',
			16,
			1
			)		
			
	IF LTRIM(RTRIM(@Calle)) = ''
		RAISERROR(N'La calle es un campo requerido',
			16,
			1
			)			
			
	IF @IdImpuestoTraslado = 0 
		RAISERROR(N'El impuesto es un campo requerido',
			16,
			1
			)
			
	INSERT INTO CatSucursales(Sucursal,Abreviacion,Calle,NoExterior,NoInterior,Colonia,Localidad,Municipio,IdEstado,CodigoPostal,IdImpuestoTraslado,Activa,CreadoPor,CreadoEl,ZonaHoraria,DescripcionZonaHoraria)
	VALUES(@Sucursal,@Abreviacion,@Calle,@NoExterior,@NoInterior,@Colonia,@Localidad,@Municipio,@IdEstado,@CodigoPostal,@IdImpuestoTraslado,@Activa,@CreadoPor,@CreadoEl,@ZonaHoraria,@DescripcionZonaHoraria)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

