
	CREATE PROCEDURE [dbo].[usp_CatTarifaCobroAgregarPQ](
	@IdTarifa int,
	@IdTipoCobro int)
AS
BEGIN
	
	BEGIN TRANSACTION
--BEGIN TRY
		IF ISNULL(@IdTarifa, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tarifa es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdTipoCobro, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tipo de Cobro es un campo requerido*FIN*', 16, 1);
			return;
			end
			
		INSERT INTO CatTarifaCobroPQ(
		IdTarifa ,
		IdTipoCobro)
		VALUES (
		@IdTarifa ,
		@IdTipoCobro)
	
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
    go

