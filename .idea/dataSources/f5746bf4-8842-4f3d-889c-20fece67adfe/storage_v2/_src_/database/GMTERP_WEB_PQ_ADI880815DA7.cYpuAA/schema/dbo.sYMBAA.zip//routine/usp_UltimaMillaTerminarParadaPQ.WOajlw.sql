

CREATE PROCEDURE [dbo].[usp_UltimaMillaTerminarParadaPQ](
	@IdGuia int,
	@EsRecoleccion bit,
	@IdEstatus int,
	@Motivo text,
	@MontoRecibido float,
	@QRValidado bit,
	@TipoPago int,
	@NombreReceptor varchar(100)
	)
AS
BEGIN
	BEGIN TRANSACTION
	

		IF ISNULL(@IdGuia, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador de la guía es un campo requerido*FIN*', 16, 1)
			return
		end

			IF @EsRecoleccion = 1 BEGIN
				UPDATE ProRecoleccionPQ SET IdEstatusUltimaMilla = @IdEstatus WHERE IdRecoleccion = @IdGuia
			END
			ELSE BEGIN
				UPDATE ProGuiaPQ SET IdEstatusUltimaMilla = @IdEstatus WHERE IdGuia = @IdGuia
			END
		IF @IdEstatus = 1 BEGIN
				IF @EsRecoleccion = 1 BEGIN
					UPDATE ProRecoleccionPQ SET IdEstatusRecoleccion = 1 WHERE IdRecoleccion = @IdGuia
				END
				ELSE BEGIN
					UPDATE ProGuiaPQ SET IdEstatusGuia = 14 WHERE IdGuia = @IdGuia
				END
			END
		IF @IdEstatus = 2 BEGIN
				IF @EsRecoleccion = 1 BEGIN
					UPDATE ProRecoleccionPQ SET IdEstatusRecoleccion = 3 WHERE IdRecoleccion = @IdGuia
				END
				ELSE BEGIN
					UPDATE ProGuiaPQ SET IdEstatusGuia = 17 WHERE IdGuia = @IdGuia
				END
			END
		IF @IdEstatus = 3 BEGIN
				IF @EsRecoleccion = 1 BEGIN
					UPDATE ProRecoleccionPQ SET IdEstatusRecoleccion = 4, MontoRecibidoOperador = @MontoRecibido, qrValidado = @QRValidado, Receptor = @NombreReceptor WHERE IdRecoleccion = @IdGuia
				END
				ELSE BEGIN
					UPDATE ProGuiaPQ SET IdEstatusGuia = 18, MontoRecibidoOperador = @MontoRecibido, qrValidado = @QRValidado, TipoPago = @TipoPago, Receptor = @NombreReceptor WHERE IdGuia = @IdGuia
				END
		END
		IF @IdEstatus = 4 BEGIN
				IF @EsRecoleccion = 1 BEGIN
					UPDATE ProRecoleccionPQ SET IdEstatusRecoleccion = 5, MotivoCancelacion = @Motivo, qrValidado = @QRValidado WHERE IdRecoleccion = @IdGuia
				END
				ELSE BEGIN
					UPDATE ProGuiaPQ SET IdEstatusGuia = 19, MotivoCancelacion = @Motivo, qrValidado = @QRValidado WHERE IdGuia = @IdGuia
				END
		END

		
	IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

