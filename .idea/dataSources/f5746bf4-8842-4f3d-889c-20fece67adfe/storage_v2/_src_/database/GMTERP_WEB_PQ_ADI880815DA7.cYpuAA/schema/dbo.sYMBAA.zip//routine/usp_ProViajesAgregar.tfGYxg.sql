CREATE PROCEDURE [dbo].[usp_ProViajesAgregar]
	@TipoCobroPorViaje tinyint,
	@FechaHora datetime,	
	@IdFolio int,
	@NoViajeCliente varchar(30),
	@IdCliente int,
	@IdSucursal int,
	@IdUnidadCarga1 int,
	@IdUnidadDolly int,
	@IdUnidadCarga2 int,
	@IdUnidadContenedor1 int,
	@IdUnidadContenedor2 int,
	@CodigoUnidadCarga1 varchar(16),
	@CodigoUnidadDolly varchar(16),
	@CodigoUnidadCarga2 varchar(16),
	@CodigoUnidadContenedor1 varchar(16),
	@CodigoUnidadContenedor2 varchar(16),
	@PlacasUnidadCarga1 varchar(16),
	@PlacasUnidadCarga2 varchar(16),	
	@IdRuta int,
	@Item varchar(50),
	@Planta varchar(50),
	@Convenio varchar(50),
	@IdRemitente int,
	@DatosRemitente varchar(512),
	@SeRecogeraEn varchar(100),
	@FechaCarga datetime,
	@IdDestinatario int,
	@DatosDestinatario varchar(512),
	@SeEntregaraEn varchar(100),
	@FechaEntrega datetime,
	@ValorDeclarado money,
	@IdMonedaValorDeclarado int,
	@CuotaConvenida varchar(20),
	@Observaciones varchar(512),
	@Peso decimal(15,4),
	@IdUnidadPeso int,
	@SubTotal money,
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Facturable bit,
	@Kilometros	int,	
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),	
	@IdCertificado int,	
	@IdFormatoImpresion int,
	@EstatusImpresoEnviadoCliente bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProViajesConceptosFacturacion ntext,
	@dsProViajesDescripcionesCarga ntext,
	@dsProViajesImagenes ntext,
	@dsProViajesImpuestos ntext,
	@dsProViajesPedimentos ntext,
	@dsProViajesTrayectos ntext,
	@IdPeticion varchar(100),
	@ViajeConCP bit,
	@IdEstatuViaje int,
	@PermitirDocumentarRebaseCredito bit,
	@IdViajeCompuestoPadre int,
	@FechaHoraEstatuViaje datetime,
	@CandadoOficial varchar(60),
	@IdTipoViaje int,
	@IdClasificacionViaje int,
	@IdTipoUnidad int,
	@IdSolicitudEDI int, -- Solo cuando es al aceptar solicitud EDI
	@CantidadMovimientos decimal(15,2),
	@dsProViajesContenedoresEquipos ntext,
	@IdSolicitudViaje int,
	@CantidadEntregada int,
	@ClaveMetodoPago varchar(5),
	@IdViajeTrayectoCompuestoPadre int,
	@dsProViajesCartasPorteReferencias ntext,
	@CreadaParaCFDI bit,
	@Millas decimal(15,2),
	@dsProViajesTrayectosAutorizaMasGastosVales ntext = NULL,
	@LitrosCombustible decimal(15,4)=0,
	@IdCombustible int=0,
	@IdSucursalAReportar int=0,
	@IncluirFlete bit=0,
	@IdCombustibleTarifaFlete int=0,
	@TieneIEPS bit=0,
	@IEPS money,
	@IdentificadorConvoy varchar(16) = NULL,
	@CreadoElVale datetime = NULL,
	@PTVContratado bit = 0,--para identificar si el cliente contrato el modulo de ptv
	@Identificador VARCHAR(50) = NULL,
	@EstructuraJSONShipment VARCHAR(MAX) = NULL,
	@ShipmentAPI VARCHAR(50) = NULL,
	@Contenedores VARCHAR(100) = NULL,
	@Portuario bit = 0, -- Identificador de viaje portuario
	@dsProViajesCartaPorteConocimientoEmbarque ntext = NULL,
	@FechaEntregaModificada bit = 0,
	@GeneradoDesde tinyint = 0,
	@dsProViajesTrayectosDistribucionConceptosFacturacion XML = NULL,
	@GeneradoDistribucionIngresos bit = NULL,
	@ViajeInternacional bit = NULL,
	@ImportacionExportacion tinyint = NULL,
	@CreadaParaComplemento bit = NULL,
	@dsProViajesTrayectosMateriales ntext = NULL,
	@DocumentoConfiguracionTimbrado int = 0,
	@dsProViajesCartaPorteSeguros ntext = NULL
	
	/*************************************************************************************************************************************
Procedimiento almacenado usp_ProViajesTrayectosAgregar

Parámetros: 
@TipoCobroPorViaje tinyint,
	@FechaHora datetime,	
	@IdFolio int,
	@NoViajeCliente varchar(30),
	@IdCliente int,
	@IdSucursal int,
	@IdUnidadCarga1 int,
	@IdUnidadDolly int,
	@IdUnidadCarga2 int,
	@IdUnidadContenedor1 int,
	@IdUnidadContenedor2 int,
	@CodigoUnidadCarga1 varchar(16),
	@CodigoUnidadDolly varchar(16),
	@CodigoUnidadCarga2 varchar(16),
	@CodigoUnidadContenedor1 varchar(16),
	@CodigoUnidadContenedor2 varchar(16),
	@PlacasUnidadCarga1 varchar(16),
	@PlacasUnidadCarga2 varchar(16),	
	@IdRuta int,
	@Item varchar(50),
	@Planta varchar(50),
	@Convenio varchar(50),
	@IdRemitente int,
	@DatosRemitente varchar(512),
	@SeRecogeraEn varchar(100),
	@FechaCarga datetime,
	@IdDestinatario int,
	@DatosDestinatario varchar(512),
	@SeEntregaraEn varchar(100),
	@FechaEntrega datetime,
	@ValorDeclarado money,
	@IdMonedaValorDeclarado int,
	@CuotaConvenida varchar(20),
	@Observaciones varchar(512),
	@Peso decimal(15,4),
	@IdUnidadPeso int,
	@SubTotal money,
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Facturable bit,
	@Kilometros	int,	
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),	
	@IdCertificado int,	
	@IdFormatoImpresion int,
	@EstatusImpresoEnviadoCliente bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProViajesConceptosFacturacion ntext,
	@dsProViajesDescripcionesCarga ntext,
	@dsProViajesImagenes ntext,
	@dsProViajesImpuestos ntext,
	@dsProViajesPedimentos ntext,
	@dsProViajesTrayectos ntext,
	@IdPeticion varchar(100),
	@ViajeConCP bit,
	@IdEstatuViaje int,
	@PermitirDocumentarRebaseCredito bit,
	@IdViajeCompuestoPadre int,
	@FechaHoraEstatuViaje datetime,
	@CandadoOficial varchar(60),
	@IdTipoViaje int,
	@IdClasificacionViaje int,
	@IdTipoUnidad int,
	@IdSolicitudEDI int, -- Solo cuando es al aceptar solicitud EDI
	@CantidadMovimientos decimal(15,2),
	@dsProViajesContenedoresEquipos ntext,
	@IdSolicitudViaje int,
	@CantidadEntregada int,
	@ClaveMetodoPago varchar(5),
	@IdViajeTrayectoCompuestoPadre int,
	@dsProViajesCartasPorteReferencias ntext,
	@CreadaParaCFDI bit,
	@Millas decimal(15,2),
	@dsProViajesTrayectosAutorizaMasGastosVales ntext = NULL,
	@LitrosCombustible decimal(15,4)=0,
	@IdCombustible int=0,
	@IdSucursalAReportar int=0,
	@IncluirFlete bit=0,
	@IdCombustibleTarifaFlete int=0,
	@TieneIEPS bit=0,
	@IEPS money,
	@IdentificadorConvoy varchar(16) = NULL,
	@CreadoElVale datetime = NULL,
	@PTVContratado bit = 0,--para identificar si el cliente contrato el modulo de ptv
	@Identificador VARCHAR(50) = NULL,
	@EstructuraJSONShipment VARCHAR(MAX) = NULL,
	@ShipmentAPI VARCHAR(50) = NULL,
	@Portuario bit = 0,
	@dsProViajesCartaPorteConocimientoEmbarque ntext
	@FechaEntregaModificada bit = 0
	@GeneradoDesde tinyint = 0,
	@dsProViajesTrayectosDistribucionConceptosFacturacion XML = NULL,
	@GeneradoDistribucionIngresos,
	@ViajeInternacional bit = NULL,
	@ImportacionExportacion tinyint = NULL,
	@CreadaParaComplemento bit = NULL

Descripción: Agrega Viajes con sus Campos y descripciones

Modificada por: Gilberto Garcia
Fecha de modificación: 14/06/2021
Versión: 8.0.62.11
Solicitud: 4066
Descripción: Se agregó inserción de bitácora de vales de combustible

Modificada por: Edgar Ramos
Fecha de modificación: 21/06/2021
Versión: 8.0.62.15
Solicitud: 4451
Descripción: Se agrego la funcionalidad de agregar remitentes y destinatarios por trayecto siempre y cuando la ruta sea por reparto/recolecta, para asi pooder cumplir con el complemento de la carta porte.

Modificada por: Edgar Ramos
Fecha de modificación: 01/07/2021
Versión 8.0.62.25
Solicitud: 4454
Descripción: Se agrego en la tabla de distribuciones por trayecto el campo tipo trayecto.

Invocada desde: ClsProViajes
    Solicitud 12236


Modificada por: Yarazeth Lemus
Fecha de modificación: 19/08/2021
Versión: 8.0.64.02
Solicitud: 4669
Descripción: Se agrego para aggregar en la nueva tabla de ChoferPermisionario y UnidadPermisionaria  relacion 1:1 con viajes trayectos
Esto se encuentra en el cursor de ViajesTrayectos

Modificada por: Jesús Humberto Morales Mojica
Fecha de modificación: 27/08/2021
Versión: 8.0.64.02
Solicitud: 4527
Descripción: Se cambio el tipo de dato del Importe Base a liquidar de la descripcion de materiales

Modificada por: Yarazeth Lemus
Fecha de modificación: 07/09/2021
Versión: 8.0.64.02
Solicitud: 4788
Descripción: Se cambio el varchar de licencia a 19 

Modificada por: Yarazeth Lemus
Fecha de modificación: 23/09/2021
Versión: 8.0.64.02
Solicitud: 4750
Descripción: se agrego la secuencia a los materiales y xml para agregar materiales por trayectos

Modificada por: Yarazeth Lemus
Fecha de modificación: 05/10/2021
Versión: 8.0.64.13
Solicitud: 4888
Descripción: se agrego el campo de creadodesde para la tabla de viajespedimentos
******************************************************************************************************************* */
AS
DECLARE
	@docHandle int,
	@IdViaje int = -1,--para saber del lado del web si hubo un error
	@IdViajeCartaPorte int,
	@Viaje int,	
	@IdOperador int,
	@CantidadPedida int,
	@CantidadEntregadaEnOtrosViajes int,
	@CursorT_Secuencia int,
	@CursorT_IdOrigen int,
	@CursorT_IdDestino int,
	@CursorT_IdUnidadCamion int,
	@CursorT_CodigoUnidadCamion varchar(16),
	@CursorT_PlacasUnidadCamion varchar(9),
	@CursorT_IdOperador int,
	@CursorT_NombreOperador varchar(100),
	@CursorT_Kilometros int,
	@CursorT_NombreOperadorPermisionario varchar(100),
	@CursorT_NoCartaPortePermisionario varchar(15),
	@CursorT_NoFacturaPermisionario varchar(15),
	@CursorT_IdMonedaPermisionario int,
	@CursorT_FechaFacturaPermisionario datetime,
	@CursorT_FechaRecepcionFacturaPermisionario datetime,
	@CursorT_ConceptoPermisionario varchar(50),
	@CursorT_AplicarAnticipo bit,
	@CursorT_Anticipo money,
	@CursorT_MonedaAnticipo varchar(7),
	@CursorT_AplicarValeDeCombustible bit,
	@CursorT_LitrosAutorizados decimal(15,2),
	@CursorT_IdViajeTrayectoCompuesto int,
	-- Solicitud 675
	@CursorT_FechaHoraCarga datetime,
	@CursorT_FechaHoraEstimadaCarga datetime,
	@CursorT_FechaHoraDescarga datetime,
	@CursorT_FechaHoraEstimadaDescarga datetime,
	--Solicitud 866
	@CursorT_CamionPer varchar(50),
	@IdViajeTrayecto int,
	@FolioConsecutivo int,
	@PermitirRegistrarAnticiposMayores bit ,
	@IdMonedaAnticipo int,
	@return_value int,
	@FolioValesConsecutivo int,
	@CursorT_IdProveedor int,
	@Autorizo varchar(100),
	@PermitirRegistrarLitrosMayores bit,
	@NumeroViaje varchar(20),
	@num int,
	@ViajeCompleto varchar(50),
	@Mensaje varchar(100),
	@NumeroCompleto varchar(20),
	@IdViaje2 int,
	@FechaTemp datetime, --FechaTemporal para convertir a date la fecha de los anticipos y de los vales para que no marque error de La fecha de cancelación no puede ser menor a la fecha de elaboración
	@CursorT__EsCompuesto int,
	@ContadorDeCompuestos int,
	@IdViajePadreNuevo int,
	@CursorT_Tienda varchar(50),
	@CursorT_NumeroOrden int,
	@CursorT_Monto money,
	@CursorT_CargadoVacioRemolque1 bit,
	@CursorT_CargadoVacioRemolque2 bit,
	@CursorT_FechaPagoFactura datetime,
	@CursorT_FechaSalida datetime,
	@CursorT_FechaLlegada datetime,
	@CursorT_Referencia varchar(20),
	@CursorT_EnvioNotificacionMovil bit,
	@OdometroInicial int,
	@OdometroFinal int,
	@TipoCambioTrayecto money,
	@PorcentajeLiquidar decimal(15, 2),
	@OdometroInicialIdUnidadCarga1 int,
	@OdometroFinalIdUnidadCarga1 int,
	@OdometroInicialIdUnidadCarga2 int,
	@OdometroFinalIdUnidadCarga2 int,
	@OdometroInicialIdUnidadDolly int,
	@OdometroFinalIdUnidadDolly int,
	@ConceptosFactuacionCero bit,
	@HorasTrayecto int,
	@RegistrarGastosAlConvoy bit,
	@HorometroInicial int,
	@HorometroFinal int,
	@HorometroInicialRemolque2 int,
	@HorometroFinalRemolque2 int,
	@PesoLiquidar decimal(15,4),
	@OdometroInicialMillas decimal(15,2),
	@OdometroFinalMillas decimal(15,2),
	@CursorT_Millas decimal(15,2),
	@CursorT_ETA decimal(15,2),
	@CursorT_GalonesAutorizados decimal(15,2),
	@OdometroInicialIdUnidadCarga1Millas decimal(15,2),
	@OdometroFinalIdUnidadCarga1Millas decimal(15,2),
	@OdometroInicialIdUnidadCarga2Millas decimal(15,2),
	@OdometroFinalIdUnidadCarga2Millas decimal(15,2),
	@OdometroInicialIdUnidadDollyMillas decimal(15,2),
	@OdometroFinalIdUnidadDollyMillas decimal(15,2),
	@IdSesion varchar(100),
	@FechaLocal datetime,
	@IdUnidadHijo int,
	@IdViajeTrayectoPadre int,
	@IdUnidadPadre int, 
	@CursorT_Horas  decimal(15, 2),-- Se agrega
	@SecuenciaTrayecto int,
	@IdContenedor1 int,
	@IdContenedor2 int,
	@IdContenedor3 int,
	@IdContenedor4 int,
	@NombreContenedor varchar(100),
	@EstatusParametros int,
	@MensajeValidacion varchar(100),
	@EsPortuario int,
	@EstatusTerminado int,
	@EstatusLlegada int,
	@ContenedorId int,
	@Llegada datetime,
	@CursorIdConceptoFacturacion int,
	@CursorUnidadMedida varchar(30),
	@CursorTrasladaImpuesto bit,
	@CursorRetieneImpuesto bit,
	@CursorImporteConceptoFacturacion money,
	@CursorIncluirCalculoIngresosLiquidacion bit,
	@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete bit,
	@CursorObservaciones varchar(8000),
	@CursorClaveSATProducto varchar(8),
	@CursorClaveSATUnidad varchar(8),
	@CursorIdImpuestoTrasladado int,
	@CursorIdImpuestoRetenido int,
	@CursorImporteTrasladado money,
	@CursorImporteRetenido money,
	@IdViajeConceptoFacturacion int,
	@CursorT_Cantidad decimal(15,4),
	@CursorT_IdUnidadEmbalaje int,
	@CursorT_Descripcion varchar(1024),
	@CursorT_Peso decimal(15,4),
	@CursorT_IdUnidadPeso int,
	@CursorT_Tarifa float,
	@CursorT_Importe money,
	@CursorT_AplicarTarifaPor tinyint,
	@CursorT_ImporteBaseLiquidacion float,
	@CursorT_ImporteLiquidar money,
	@CursorT_ClavesSATXML varchar(max),
	@CursorT_Consecutivo int,
	@CursorT_EstaSiendoImportado TINYINT,
	@CursorT_UbicacionesXML varchar(max),
	@CursorT_PermisionarioXML varchar(max),
	@IdViajeDescripcionCarga int,
	--Operador Aux
	@CursorT_IdOperadorAux int,
	@CursorT_NombreOperadorAux varchar(100)
	/*SOLICITUD 4208*/
	DECLARE @TempProViajesTrayectosDistribucionConceptosFacturacion AS TABLE 
		(
		 COL_IdViajeTrayectoDistribucionConceptoFacturacion int
		,COL_IdViajeTrayecto int
		,COL_IdRutaTrayecto int
		,COL_Secuencia int
		,COL_TipoTrayecto tinyint
		,COL_IdConceptoFacturacion int
		,COL_Importe money)



SET XACT_ABORT ON 		
BEGIN TRY		
	BEGIN TRANSACTION
	
	SET @FechaTemp = cast(@FechaHora as date)
	SET @ConceptosFactuacionCero = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'PodreAgregarConceptoFacturacionEnCeros')

	IF @TipoCobroPorViaje = 0
		RAISERROR(N'El tipo de cobro es un campo requerido',
			16,
			1
			)

	IF ISDATE(@FechaHora) = 0
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF ISDATE(@FechaHoraEstatuViaje) = 0
		RAISERROR(N'La fecha y hora del estatus es un campo requerido',
			16,
			1
			)
			
	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF @IdSucursal = 0 
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)

	IF @IdRuta = 0
		RAISERROR(N'La ruta es un campo requerido',
			16,
			1
			)

	IF @SubTotal = 0 
	BEGIN
		IF @Facturable = 1 OR ISNULL(@ConceptosFactuacionCero,0) = 0
			RAISERROR(N'El subtotal es un campo requerido',
				16,
				1
				)
	END		
			
	IF @CantidadMovimientos = 0
		RAISERROR(N'El campo Cantidad de Movimientos es un campo requerido',
			16,
			1
			)				

	IF @IdMoneda = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)
			
	IF @dsProViajesConceptosFacturacion IS NULL
		RAISERROR(N'Los conceptos de facturacion son requeridos',
			16,
			1
			)
	IF @NoViajeCliente <> '' AND (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'ActivarNoViajeClienteNoSeRepita')= 1		
		IF EXISTS(SELECT NoViajeCliente FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente)
			begin
				set @NumeroViaje = ''
				set @num = (SELECT TOP 1 Viaje FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente)
				set @IdViaje2 =(SELECT TOP 1 IdViaje FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente)
				set @NumeroCompleto = (select TOP 1 SUBSTRING('000000',1,6-len(CAST(@num as varchar)))+CAST(@num as varchar))
						
				set @ViajeCompleto = (SELECT TOP 1 cs.Abreviacion  + '-' + CAST (@NumeroCompleto AS VARCHAR(20))  from ProViajes as pv 
				inner join CatSucursales as cs on pv.IdSucursal = cs.IdSucursal  where pv.IdViaje = @IdViaje2)
				set @Mensaje = 'El número de viaje del cliente ingresado se encuentra registrado previamente '+@ViajeCompleto 
				RAISERROR(@Mensaje,
					16,
					1
					)   						
			end
	
	IF @IdCombustibleTarifaFlete = 0
		SET @IdCombustibleTarifaFlete = NULL
		
	IF @IdCombustible = 0
		SET @IdCombustible = NULL
	
	IF @ViajeConCP = 1
	BEGIN
		IF @IdFolio = 0
			RAISERROR(N'El folio del documento es un campo requerido',
				16,
				1
				)					

		IF @IdRemitente = 0
			RAISERROR(N'El remitente es un campo requerido',
				16,
				1
				)

		IF @IdDestinatario = 0
			RAISERROR(N'El Destinatario es un campo requerido',
				16,
				1
				)				

		IF @dsProViajesImpuestos IS NULL
			RAISERROR(N'Los impuestos son requeridos',
				16,
				1
				)
		IF 	@NoViajeCliente <>'' AND (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'ActivarNoViajeClienteNoSeRepita')= 1		
		IF EXISTS(SELECT NoViajeCliente FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente)
			begin
				set @NumeroViaje = ''
				set @num = (SELECT TOP 1 Viaje FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente)
				set @IdViaje2 =(SELECT TOP 1 IdViaje FROM ProViajes WHERE NoViajeCliente = @NoViajeCliente And IdCliente = @IdCliente)
				set @NumeroCompleto = (select TOP 1 SUBSTRING('000000',1,6-len(CAST(@num as varchar)))+CAST(@num as varchar))
						
				set @ViajeCompleto = (SELECT TOP 1 cs.Abreviacion  + '-' + CAST (@NumeroCompleto AS VARCHAR(20))  from ProViajes as pv 
				inner join CatSucursales as cs on pv.IdSucursal = cs.IdSucursal  where pv.IdViaje = @IdViaje2)
				set @Mensaje = 'El número de viaje del cliente ingresado se encuentra registrado previamente '+@ViajeCompleto 
				RAISERROR(@Mensaje,
					16,
					1
					)   						
			end			
	END

	IF @dsProViajesTrayectos IS NULL
		RAISERROR(N'Los trayectos son requeridos',
			16,
			1
			)

	IF @IdUnidadCarga1 = @IdUnidadCarga2 AND @IdUnidadCarga1 <> 0
		RAISERROR(N'La unidad del segundo remolque es la misma que el primer remolque',
			16,
			1
			)				

	If @IdCertificado = 0
		SET @IdCertificado = NULL			

	If @IdFormatoImpresion = 0
		SET @IdFormatoImpresion = NULL

	If @IdUnidadCarga1 = 0
		SET @IdUnidadCarga1 = NULL

	If @IdUnidadCarga2 = 0
		SET @IdUnidadCarga2 = NULL

	If @IdUnidadContenedor1 = 0
		SET @IdUnidadContenedor1 = NULL

	If @IdUnidadContenedor2 = 0
		SET @IdUnidadContenedor2 = NULL
		
	If @IdUnidadDolly = 0
		SET @IdUnidadDolly = NULL
		
	If @IdMonedaValorDeclarado = 0
		SET @IdMonedaValorDeclarado = NULL
		
	If @IdRemitente = 0
		SET @IdRemitente = NULL

	If @IdDestinatario = 0
		SET @IdDestinatario = NULL

	If @IdTipoViaje = 0
		SET @IdTipoViaje = NULL

	If @IdClasificacionViaje = 0
		SET @IdClasificacionViaje = NULL	

	If @IdTipoUnidad = 0
		SET @IdTipoUnidad = NULL			
		
	If @IdViajeCompuestoPadre = 0
	BEGIN
		SET @IdViajeCompuestoPadre = NULL
		SET @IdViajeTrayectoCompuestoPadre = NULL
	END
	ELSE
	BEGIN
		--se valida que el viaje compuesto padre no este cancelado
		IF EXISTS(SELECT CanceladoEl FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre AND CanceladoEl IS NOT NULL)
			RAISERROR(N'El viaje compuesto padre al que se intenta ligar está cancelado',
				16,
				1
				)
		-- << Solicitud 6538, permitir ligar viajes a viajes previamente facturados total o parcialmente >>
		--se valida que el viaje compuesto padre no este facturado
		/*IF (SELECT PendienteFacturar FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre) = 0
			RAISERROR(N'El viaje compuesto padre al que se intenta ligar está facturado',
				16,
				1
				)*/
				
		-- << Solicitud 6538, permitir ligar viajes a viajes previamente facturados total o parcialmente >>
		--se valida que el viaje compuesto padre no este facturado
		/*IF (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre) = 1
			RAISERROR(N'El viaje compuesto padre al que se intenta ligar está facturado',
				16,
				1
				)	*/				
		
		----se valida que el viaje compuesto padre no tenga mas de un trayecto   *********No aplica ya 
		--IF (SELECT COUNT(*) FROM ProViajesTrayectos WHERE IdViaje = @IdViajeCompuestoPadre) != 1
		--	RAISERROR(N'El viaje compuesto padre al que se intenta ligar tiene más de un trayecto',
		--		16,
		--		1
		--		)

		--se valida que el viaje compuesto padre no tenga referenciado un viaje compuesto padre es decir que sea hijo
		IF EXISTS(SELECT IdViajeCompuestoPadre FROM ProViajes WHERE IdViaje = @IdViajeCompuestoPadre AND IdViajeCompuestoPadre IS NOT NULL)
			RAISERROR(N'El viaje compuesto padre al que se intenta ligar ya está ligado a un viaje compuesto',
				16,
				1
				)

		--se valida que el viaje compuesto padre no tenga hijos
		--IF EXISTS(SELECT IdViaje FROM ProViajes WHERE IdViajeCompuestoPadre = @IdViajeCompuestoPadre)
		--	RAISERROR(N'El viaje compuesto padre al que se intenta ligar ya tiene ligado a otro viaje',
		--		16,
		--		1
		--		)				
	END
	
	IF @IdSolicitudViaje > 0
	BEGIN
		
		IF NOT EXISTS(Select IdSolicitudViaje From ProSolicitudesViajes Where IdSolicitudViaje = @IdSolicitudViaje)
			RAISERROR(N'El viaje no se puede Generar porque la Solicitud ha sido eliminada',
				16,
				1
				)
		IF EXISTS(Select IdSolicitudViaje From ProSolicitudesViajes Where IdSolicitudViaje = @IdSolicitudViaje And FechaHoraCancelado is not null)
			RAISERROR(N'El viaje no se puede Generar porque la Solicitud ha sido cancelada',
				16,
				1
				)
		--IF EXISTS(Select * From ProViajesSolicitudesViajes Where IdSolicitudViaje = @IdSolicitudViaje)
		--	RAISERROR(N'La solicitud ya tiene un viaje generado.',
		--		16,
		--		1
		--		)
		
		Set @CantidadPedida  = (Select isnull(CantidadPedida,0) From ProSolicitudesViajes Where IdSolicitudViaje = @IdSolicitudViaje)
		Set @CantidadEntregadaEnOtrosViajes  = (Select Isnull(CantidadEntregada,0) From ProSolicitudesViajes Where IdSolicitudViaje = @IdSolicitudViaje)
		IF (@CantidadEntregada+@CantidadEntregadaEnOtrosViajes) > @CantidadPedida 
			RAISERROR(N'Se esta sobrepasado de la cantidad solicitada.',
				16,
				1
				)						
	END
				
	SET @Viaje = (SELECT ISNULL(MAX(Viaje),0)+1 FROM ProViajes WHERE IdSucursal = @IdSucursal)
			
	INSERT INTO ProViajes(CodigoUnidadCarga1,CodigoUnidadCarga2,CodigoUnidadContenedor1,CodigoUnidadContenedor2,CodigoUnidadDolly,Convenio,CreadoEl,CreadoPor,
	CuotaConvenida,DatosDestinatario,DatosRemitente,Facturable,FechaCarga,FechaEntrega,FechaHora,IdCliente,
	IdDestinatario,IdMoneda,IdMonedaValorDeclarado,IdRemitente,IdRuta,IdSucursal,IdUnidadCarga1,IdUnidadCarga2,IdUnidadContenedor1,
	IdUnidadContenedor2,IdUnidadDolly,IdUnidadPeso,
	Item,Kilometros,NoViajeCliente,Observaciones,Peso,PlacasUnidadCarga1,PlacasUnidadCarga2,Planta,SeEntregaraEn,SeRecogeraEn,
	SubTotal,TipoCambio,TipoCobroPorViaje,ValorDeclarado,Viaje,IdEstatuViaje,FechaHoraEstatuViaje,ViajeConCP,PendienteFacturar,ViajeTerminado,
	IdViajeCompuestoPadre,CandadoOficial,FacturadoParcialmente,IdTipoViaje,IdClasificacionViaje,IdTipoUnidad,CantidadMovimientos,Millas,IdFormatoImpresion,
	LitrosCombustible,IdCombustible,IdSucursalAReportar,IncluirFlete,IdCombustibleTarifaFlete,TieneIEPS,IEPS,IdentificadorConvoy, Identificador,EstructuraJSONShipment,ShipmentAPI,Portuario,FechaEntregaModificada,GeneradoDesde,GeneradoDistribucionIngresos,ViajeInternacional,ImportacionExportacion)
	VALUES(@CodigoUnidadCarga1,@CodigoUnidadCarga2,@CodigoUnidadContenedor1,@CodigoUnidadContenedor2,@CodigoUnidadDolly,@Convenio,@CreadoEl,@CreadoPor,
	@CuotaConvenida,@DatosDestinatario,@DatosRemitente,@Facturable,@FechaCarga,@FechaEntrega,@FechaHora,@IdCliente,
	@IdDestinatario,@IdMoneda,@IdMonedaValorDeclarado,@IdRemitente,@IdRuta,@IdSucursal,@IdUnidadCarga1,@IdUnidadCarga2,@IdUnidadContenedor1,
	@IdUnidadContenedor2,@IdUnidadDolly,@IdUnidadPeso,
	@Item,@Kilometros,@NoViajeCliente,@Observaciones,@Peso,@PlacasUnidadCarga1,@PlacasUnidadCarga2,@Planta,@SeEntregaraEn,@SeRecogeraEn,
	@SubTotal,@TipoCambio,@TipoCobroPorViaje,@ValorDeclarado,@Viaje,@IdEstatuViaje,@FechaHoraEstatuViaje,@ViajeConCP,1,0,
	@IdViajeCompuestoPadre,@CandadoOficial,0,@IdTipoViaje,@IdClasificacionViaje,@IdTipoUnidad,@CantidadMovimientos,@Millas,@IdFormatoImpresion,
	@LitrosCombustible,@IdCombustible,@IdSucursalAReportar,@IncluirFlete,@IdCombustibleTarifaFlete,@TieneIEPS,@IEPS,@IdentificadorConvoy, @Identificador,@EstructuraJSONShipment,@ShipmentAPI,@Portuario,@FechaEntregaModificada, @GeneradoDesde,@GeneradoDistribucionIngresos,@ViajeInternacional,@ImportacionExportacion)

	SET @IdViaje = (SELECT IDENT_CURRENT('ProViajes'))

	IF ISNULL(@Contenedores,'') != ''
	BEGIN
		--El separador de nuestros parametros deberá ser una coma ","
			DECLARE @Posicion int
			--@Posicion es la posicion de cada uno de nuestros separadores
			DECLARE @Contenedor varchar(1000)
			--@Contenedor es cada una de los contenedores (token) de los valores en @Contenedores
			SET @Contenedores = @Contenedores + ','
			--Colocamos un separador al final de los parametros para un funcionamiento correcto
			--Hacemos un Ciclo que se repite mientras haya separadores
			WHILE patindex('%,%' , @Contenedores) <> 0
			--patindex busca un patron en una cadena y nos devuelve su posicion
			BEGIN
			   SELECT @Posicion =  patindex('%,%' , @Contenedores)
			   --Buscamos la posicion de la primera ,
			   SELECT @Contenedor = left(@Contenedores, @Posicion - 1)
			   --Y obtenemos una subcadena hasta la posicion de la coma
			   
			   UPDATE ProDetalleEntregaContenedores SET IdViaje = @IdViaje WHERE IdDetalleEntregaContenedores = @Contenedor
			  
			   -- Reemplazamos la cadena extraida con nada mediante la funcion stuff
			   -- es equivalente a borrar o retirar la subcadena de la cadena
			   SELECT @Contenedores = stuff(@Contenedores, 1, @Posicion, '')
			   -- Retornamos al inicio del ciclo
			END
			--Y cuando se han recorrido todos los parametros terminamos la tranacción exitosa
	END

	--seccion para agregar el idViaje a paremtros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdViaje' AND IdUsuario = @CreadoPor)
	INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdViaje',@IdViaje,@CreadoPor)
	ELSE
	UPDATE SisParametrosPagina SET Parametros = @IdViaje WHERE Pagina = 'IdViaje' AND IdUsuario = @CreadoPor
	
	--Seccion donde se agregan las referencias a la tabla ProViajesCartasPorteReferencias
	IF @dsProViajesCartasPorteReferencias IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesCartasPorteReferencias
		
		SELECT ATT_NombreReferencia,ATT_ValorReferencia
		INTO #TempProViajesCartasPorteReferencias
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesCartasPorteReferencias',2) 
		WITH (ATT_NombreReferencia varchar(100),ATT_ValorReferencia varchar(100))
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProViajesCartasPorteReferencias(IdViaje,NombreReferencia,ValorReferencia)
		SELECT @IdViaje,ATT_NombreReferencia,ATT_ValorReferencia FROM #TempProViajesCartasPorteReferencias
	END
	
	
	IF @IdSolicitudViaje > 0
	BEGIN
		
		Declare @EstatusSolicitudViaje int
		
		IF @CantidadPedida = (@CantidadEntregada+@CantidadEntregadaEnOtrosViajes)
		Begin
			Set @EstatusSolicitudViaje = 1
		End
		else
		Begin
			Set @EstatusSolicitudViaje = 4
		End
	
		INSERT INTO ProViajesSolicitudesViajes(IdViaje,IdSolicitudViaje)
		Values(@IdViaje,@IdSolicitudViaje)
		
		Update ProSolicitudesViajes 
		Set CantidadEntregada = isnull(CantidadEntregada,0)+@CantidadEntregada ,
		UsuarioAcepto = @CreadoPor,
		FechaHoraAceptado = @CreadoEl,
		Estatus = @EstatusSolicitudViaje		
		Where IdSolicitudViaje = @IdSolicitudViaje
	END
	
	INSERT INTO ProViajesEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatuViaje,IdViaje)
	VALUES(@CreadoEl,@CreadoPor,@FechaHoraEstatuViaje,@IdEstatuViaje,@IdViaje)
	
	--SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
	IF @dsProViajesConceptosFacturacion IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesConceptosFacturacion

		SELECT ATT_IdConceptoFacturacion,ATT_UnidadMedida,ATT_TrasladaImpuesto,ATT_RetieneImpuesto,ATT_ImporteConceptoFacturacion,ATT_IncluirCalculoIngresosLiquidacion,ATT_IncluirCalculoLiquidacionPorcentajeSobreImpFlete,ATT_Observaciones,ATT_ClaveSATProducto,ATT_ClaveSATUnidad,ATT_IdImpuestoTrasladado,ATT_IdImpuestoRetenido,ATT_ImporteTrasladado,ATT_ImporteRetenido
		INTO #TempProViajesConceptosFacturacion
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesConceptosFacturacion',2) 
		WITH (ATT_IdConceptoFacturacion int,ATT_UnidadMedida varchar(30),ATT_TrasladaImpuesto bit,ATT_RetieneImpuesto bit,ATT_ImporteConceptoFacturacion money,ATT_IncluirCalculoIngresosLiquidacion bit,ATT_IncluirCalculoLiquidacionPorcentajeSobreImpFlete bit,ATT_Observaciones varchar(8000),ATT_ClaveSATProducto varchar(8),ATT_ClaveSATUnidad varchar(8),ATT_IdImpuestoTrasladado int,ATT_IdImpuestoRetenido int,ATT_ImporteTrasladado money,ATT_ImporteRetenido money)

		EXEC sp_xml_removedocument @docHandle

		DECLARE CursorViajesConceptosFacturacion CURSOR LOCAL FOR
		SELECT * FROM #TempProViajesConceptosFacturacion

		OPEN CursorViajesConceptosFacturacion
		FETCH NEXT FROM CursorViajesConceptosFacturacion
		INTO @CursorIdConceptoFacturacion,@CursorUnidadMedida,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorImporteConceptoFacturacion,@CursorIncluirCalculoIngresosLiquidacion,@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete,@CursorObservaciones,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorIdImpuestoTrasladado,@CursorIdImpuestoRetenido,@CursorImporteTrasladado,@CursorImporteRetenido
		
		WHILE @@FETCH_STATUS = 0
		BEGIN					
			INSERT INTO ProViajesConceptosFacturacion(CreadoEl,CreadoPor,IdConceptoFacturacion,IdViaje,Importe,RetieneImpuesto,TrasladaImpuesto,UnidadMedida,IncluirCalculoIngresosLiquidacion,IncluirCalculoLiquidacionPorcentajeSobreImpFlete,Observacion,ClaveSATProducto,ClaveSATUnidad)
			VALUES(@CreadoEl,@CreadoPor,@CursorIdConceptoFacturacion,@IdViaje,@CursorImporteConceptoFacturacion,@CursorRetieneImpuesto,@CursorTrasladaImpuesto,@CursorUnidadMedida,@CursorIncluirCalculoIngresosLiquidacion,@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete,@CursorObservaciones,@CursorClaveSATProducto,@CursorClaveSATUnidad)

			SET @IdViajeConceptoFacturacion = (SELECT IDENT_CURRENT('ProViajesConceptosFacturacion'))

			IF @CursorIdImpuestoTrasladado > 0 
			BEGIN
				INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdViajeConceptoFacturacion,@CursorIdImpuestoTrasladado,@CursorImporteTrasladado )
			END

			IF @CursorIdImpuestoRetenido > 0 
			BEGIN
				INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdViajeConceptoFacturacion,@CursorIdImpuestoRetenido,@CursorImporteRetenido )
			END

			FETCH NEXT FROM CursorViajesConceptosFacturacion
			INTO @CursorIdConceptoFacturacion,@CursorUnidadMedida,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorImporteConceptoFacturacion,@CursorIncluirCalculoIngresosLiquidacion,@CursorIncluirCalculoLiquidacionPorcentajeSobreImpFlete,@CursorObservaciones,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorIdImpuestoTrasladado,@CursorIdImpuestoRetenido,@CursorImporteTrasladado,@CursorImporteRetenido
		END

		CLOSE CursorViajesConceptosFacturacion
		DEALLOCATE CursorViajesConceptosFacturacion	
	END
	
	IF (SELECT 
SUM(ISNULL(
		( 
		CASE pf.IdMoneda
		WHEN 1 THEN pvc.Importe
		ELSE
		(pvc.Importe* pf.TipoCambio) 
		END ),0))
 FROM ProViajesConceptosFacturacion pvc
inner join ProViajesFacturas pvf on pvc.IdViaje = pvf.IdViaje
inner join ProFacturas pf ON pvf.IdFactura = pf.IdFactura
WHERE pvc.IdViaje = @IdViaje
AND pvf.CanceladoEl is null) <> @SubTotal
	RAISERROR(N'La suma de los importes de los conceptos de facturación no son iguales al subtotal',
		16,
		1
		)					

	--SECCION PARA AGREGAR Las descripcion/materiales		
	IF @dsProViajesDescripcionesCarga IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesDescripcionesCarga
			
		SELECT ATT_Cantidad,ATT_IdUnidadEmbalaje,ATT_Descripcion,ATT_Peso,ATT_IdUnidadPeso,ATT_Tarifa,ATT_Importe,ATT_AplicarTarifaPor,
		ATT_ImporteBaseLiquidacion,ATT_ImporteLiquidar,ATT_ClavesSATXML,ATT_Consecutivo, ATT_EstaSiendoImportado
		INTO #TempProViajesDescripcionesCarga
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesDescripcionesCarga',2) 
		WITH (ATT_Cantidad decimal(15,4),ATT_IdUnidadEmbalaje int,ATT_Descripcion varchar(1024),ATT_Peso decimal(15,4),ATT_IdUnidadPeso int,ATT_Tarifa float,
		ATT_Importe money,ATT_AplicarTarifaPor tinyint,ATT_ImporteBaseLiquidacion float,ATT_ImporteLiquidar money,ATT_ClavesSATXML varchar(max),ATT_Consecutivo int, ATT_EstaSiendoImportado TINYINT)

		EXEC sp_xml_removedocument @docHandle

		DECLARE CursorProViajesDescripcionesCarga CURSOR LOCAL FOR
		SELECT * FROM #TempProViajesDescripcionesCarga
		
		OPEN CursorProViajesDescripcionesCarga
		FETCH NEXT FROM CursorProViajesDescripcionesCarga
		INTO @CursorT_Cantidad,@CursorT_IdUnidadEmbalaje,@CursorT_Descripcion,@CursorT_Peso,@CursorT_IdUnidadPeso,@CursorT_Tarifa,@CursorT_Importe,@CursorT_AplicarTarifaPor,@CursorT_ImporteBaseLiquidacion,@CursorT_ImporteLiquidar,@CursorT_ClavesSATXML,@CursorT_Consecutivo, @CursorT_EstaSiendoImportado
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
		
			INSERT INTO ProViajesDescripcionesCarga(CreadoEl,CreadoPor,Cantidad,IdUnidadMedidaEmbalaje,DescripcionCarga,IdUnidadMedidaPeso,IdViaje,Importe,Peso,Tarifa,TarifaAplicadaPor,ImporteBaseLiquidacion,ImporteLiquidar,Consecutivo,CreadoDesde)
			VALUES(@CreadoEl,@CreadoPor,@CursorT_Cantidad,@CursorT_IdUnidadEmbalaje,@CursorT_Descripcion,@CursorT_IdUnidadPeso,@IdViaje,@CursorT_Importe,@CursorT_Peso,@CursorT_Tarifa,@CursorT_AplicarTarifaPor,@CursorT_ImporteBaseLiquidacion,@CursorT_ImporteLiquidar,@CursorT_Consecutivo, @CursorT_EstaSiendoImportado)
			SET @IdViajeDescripcionCarga = (SELECT IDENT_CURRENT('ProViajesDescripcionesCarga'))

			--Seccion para las claves del sat de los materiales
			IF ISNULL(@CursorT_ClavesSATXML,'') <> ''
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @CursorT_ClavesSATXML
					SELECT
						 @IdViajeDescripcionCarga AS ATT_IdViajeDescripcionCarga
						,ATT_ClaveSAT
						,ATT_DescripcionSAT
						,ATT_CatalogoSAT
						,ATT_Opcional
					INTO #TempProViajesDescripcionesCargaClavesSAT
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasDescripcionesCargaTarifasClavesSAT',2) 
					WITH (
						 ATT_IdViajeDescripcionCarga int
						,ATT_ClaveSAT varchar(10)
						,ATT_DescripcionSAT varchar(max)
						,ATT_CatalogoSAT varchar(50)
						,ATT_Opcional nvarchar(100))

			
					EXEC sp_xml_removedocument @docHandle

					INSERT INTO ProViajesDescripcionesCargaClavesSAT(IdViajeDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					SELECT 
					ATT_IdViajeDescripcionCarga
				   ,ATT_ClaveSAT 
				   ,ATT_CatalogoSAT 
				   ,ATT_Opcional 
				   ,GETDATE()
					FROM #TempProViajesDescripcionesCargaClavesSAT

					DROP TABLE #TempProViajesDescripcionesCargaClavesSAT
				END

		FETCH NEXT FROM CursorProViajesDescripcionesCarga
		INTO @CursorT_Cantidad,@CursorT_IdUnidadEmbalaje,@CursorT_Descripcion,@CursorT_Peso,@CursorT_IdUnidadPeso,@CursorT_Tarifa,@CursorT_Importe,@CursorT_AplicarTarifaPor,@CursorT_ImporteBaseLiquidacion,@CursorT_ImporteLiquidar,@CursorT_ClavesSATXML,@CursorT_Consecutivo, @CursorT_EstaSiendoImportado
		END

		CLOSE CursorProViajesDescripcionesCarga
		DEALLOCATE CursorProViajesDescripcionesCarga

	END

	--agrega imagenes del viaje	
	IF @dsProViajesImagenes IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesImagenes
		
		SELECT ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes
		INTO #TempProViajesImagenes
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesImagenes',2) 
		WITH (ATT_Imagen ntext,ATT_ImagenNombreArchivo varchar(150),ATT_Descripcion varchar(50),ATT_PesoBytes int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProViajesImagenes(CreadoEl,CreadoPor,IdViaje,Imagen,ImagenNombreArchivo,Descripcion,PesoBytes)
		SELECT @CreadoEl,@CreadoPor,@IdViaje,ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes 
		FROM #TempProViajesImagenes
	END
	
	IF @ViajeConCP = 1
	BEGIN
		IF EXISTS(SELECT IdFolio FROM ProViajesCartasPorte WHERE IdFolio = @IdFolio)
		BEGIN
			RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar.',
				16,
				1
				)
		END
		--Solicitud 632
		--Validacion de concurrencia para cartas porte
		IF EXISTS(SELECT IdViaje FROM ProViajesCartasPorte WHERE IdViaje = @IdViaje)
		BEGIN
			RAISERROR(N'El viaje actual ya cuenta con una carta porte registrada, favor de validar.',
				16,
				1
				)
		END
			
		INSERT INTO ProViajesCartasPorte(CreadoEl,CreadoPor,EstatusImpresoEnviadoCliente,IdCertificado,
		IdFolio,IdFormatoImpresion,IdViaje,ImpuestosRetenidosFederales,ImpuestosRetenidosLocales,ImpuestosTrasladadosFederales,ImpuestosTrasladadosLocales,
		MetodoPago,NroCuentaPago,Observaciones,SubTotal,Total,ClaveMetodoPago,CreadaParaCFDI33,CreadaParaComplemento,DocumentoConfiguracionTimbrado)
		VALUES(@CreadoEl,@CreadoPor,@EstatusImpresoEnviadoCliente,@IdCertificado,
		@IdFolio,@IdFormatoImpresion,@IdViaje,@ImpuestosRetenidosFederales,@ImpuestosRetenidosLocales,@ImpuestosTrasladadosFederales,@ImpuestosTrasladadosLocales,
		@MetodoPago,@NroCuentaPago,@Observaciones,@SubTotal,@Total,@ClaveMetodoPago,@CreadaParaCFDI,@CreadaParaComplemento,@DocumentoConfiguracionTimbrado)

		SET @IdViajeCartaPorte = (SELECT IDENT_CURRENT('ProViajesCartasPorte'))		
		
		--agrega IMPUESTOS del viaje	
		IF @dsProViajesImpuestos IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesImpuestos
			
			SELECT ATT_IdImpuesto,ATT_Importe
			INTO #TempProViajesCartasPorteImpuestos
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesImpuestos',2) 
			WITH (ATT_IdImpuesto int,ATT_Importe money)
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO ProViajesCartasPorteImpuestos(CreadoEl,CreadoPor,IdImpuesto,IdViajeCartaPorte,Importe)
			SELECT @CreadoEl,@CreadoPor,ATT_IdImpuesto,@IdViajeCartaPorte,ATT_Importe
			FROM #TempProViajesCartasPorteImpuestos
		END
	END

	--agrega Pedimentos del viaje	
	IF @dsProViajesPedimentos IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesPedimentos
		
		SELECT ATT_NumeroPedimento,ATT_FechaPedimento,ATT_AduanaPedimento,ATT_CreadoDesde
		INTO #TempProViajesPedimentos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesPedimentos',2) 
		WITH (ATT_NumeroPedimento varchar(25),ATT_FechaPedimento datetime,ATT_AduanaPedimento varchar(25),ATT_CreadoDesde tinyint)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProViajesPedimentos(CreadoEl,CreadoPor,Aduana,Fecha,IdViaje,NumeroPedimento,CreadoDesde)
		SELECT @CreadoEl,@CreadoPor,ATT_AduanaPedimento,ATT_FechaPedimento,@IdViaje,ATT_NumeroPedimento,ATT_CreadoDesde
		FROM #TempProViajesPedimentos
	END	

	--agrega Pedimentos de internacion/fianzas
	IF @dsProViajesContenedoresEquipos IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesContenedoresEquipos
		
		SELECT ATT_ContenedorEquipo,ATT_Booking,ATT_NumeroPedimento,ATT_Aduana,ATT_FechaPedimento,
		ATT_FechaRegreso,ATT_Naviera,ATT_IdUnidad,ATT_OrdenCompra,ATT_OrdenDeTrabajo,ATT_NumeroLinea,
		ATT_Unidades,ATT_DescripcionMaterial,ATT_Comentario,ATT_NumMaterial,ATT_Tipo,ATT_Tamano,ATT_Sellos,
		ATT_SecuenciaTrayecto,ATT_Cargado,ATT_IdUnidadCarga,ATT_IdDetalleEntregaContenedor
		INTO #TempProViajesContenedoresEquipos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesContenedoresEquipos',2) 
		WITH (ATT_ContenedorEquipo varchar(16),ATT_Booking varchar(30),ATT_NumeroPedimento varchar(25),
		ATT_Aduana varchar(25),ATT_FechaPedimento varchar(10),ATT_FechaRegreso varchar(10),ATT_Naviera varchar(80),
		ATT_IdUnidad int,ATT_OrdenCompra varchar(50),ATT_OrdenDeTrabajo varchar(50),ATT_NumeroLinea Int,
		ATT_Unidades decimal(18,2),ATT_DescripcionMaterial varchar(50),ATT_Comentario varchar(100),ATT_NumMaterial varchar(50),ATT_Tipo varchar(80),ATT_Tamano varchar(80),ATT_Sellos varchar(60),
		ATT_SecuenciaTrayecto int,ATT_Cargado bit,ATT_IdUnidadCarga int,ATT_IdDetalleEntregaContenedor int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProViajesContenedoresEquipos(IdViaje,ContenedorEquipo,Booking,NumeroPedimento,Aduana,FechaPedimento,
		FechaRegreso,CreadoPor,CreadoEl,Naviera,IdUnidad,OrdenCompra,OrdenDeTrabajo,NumeroLinea,Unidades,DescripcionMaterial,Comentario,NumMaterial,Tipo,Tamano,Sellos,SecuenciaTrayecto,Cargado,IdUnidadCarga,IdDetalleEntregaContenedor)
		SELECT @IdViaje,ATT_ContenedorEquipo,ATT_Booking,ATT_NumeroPedimento,ATT_Aduana,ATT_FechaPedimento,
		ATT_FechaRegreso,@CreadoPor,@CreadoEl,ATT_Naviera,CASE ATT_IdUnidad WHEN 0 THEN NULL ELSE ATT_IdUnidad END,ATT_OrdenCompra,ATT_OrdenDeTrabajo,ATT_NumeroLinea,
		ATT_Unidades,ATT_DescripcionMaterial,ATT_Comentario,ATT_NumMaterial,ATT_Tipo,ATT_Tamano,ATT_Sellos,
		ATT_SecuenciaTrayecto,ATT_Cargado,CASE ATT_IdUnidadCarga WHEN 0 THEN NULL ELSE ATT_IdUnidadCarga END,
		CASE ATT_IdDetalleEntregaContenedor WHEN 0 THEN NULL ELSE ATT_IdDetalleEntregaContenedor END
		FROM #TempProViajesContenedoresEquipos
	END	
	
	--Agregar conocimiento de embarque - Solicitud 908
	IF @dsProViajesCartaPorteConocimientoEmbarque iS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesCartaPorteConocimientoEmbarque

		SELECT ATT_IdMaterialPemex,ATT_PrecioUnitario,ATT_TipoConocimientoEmbarque,ATT_NumeroEmbarque1,ATT_FechaSalidaEmbarque1,
		ATT_VolumenSalidaEmbarque1,ATT_TemperaturaSalidaEmbarque1,ATT_VolumenCorregidoSalidaEmbarque1,ATT_FechaLlegadaEmbarque1,
		ATT_VolumenLlegadaEmbarque1,ATT_TemperaturaLlegadaEmbarque1,ATT_VolumenCorregidoLlegadaEmbarque1,ATT_NumeroEmbarque2,
		ATT_FechaSalidaEmbarque2,ATT_VolumenSalidaEmbarque2,ATT_TemperaturaSalidaEmbarque2,ATT_VolumenCorregidoSalidaEmbarque2,ATT_FechaLlegadaEmbarque2,
		ATT_VolumenLlegadaEmbarque2,ATT_TemperaturaLlegadaEmbarque2,ATT_VolumenCorregidoLlegadaEmbarque2
		INTO #TempProViajesCartasPorteConocimientoEmbarque
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesCartasPorteConocimientoEmbarque',2) 
		WITH (ATT_IdMaterialPemex INT,ATT_PrecioUnitario DECIMAL(12,6),ATT_TipoConocimientoEmbarque INT,ATT_NumeroEmbarque1 INT,ATT_FechaSalidaEmbarque1 VARCHAR(30),
		ATT_VolumenSalidaEmbarque1 DECIMAL(12,3),ATT_TemperaturaSalidaEmbarque1 DECIMAL(12,2),ATT_VolumenCorregidoSalidaEmbarque1 DECIMAL(12,3),ATT_FechaLlegadaEmbarque1 VARCHAR(30),
		ATT_VolumenLlegadaEmbarque1 DECIMAL(12,3),ATT_TemperaturaLlegadaEmbarque1 DECIMAL(12,2),ATT_VolumenCorregidoLlegadaEmbarque1 DECIMAL(12,3),ATT_NumeroEmbarque2 INT,
		ATT_FechaSalidaEmbarque2 VARCHAR(30),ATT_VolumenSalidaEmbarque2 DECIMAL(12,3),ATT_TemperaturaSalidaEmbarque2 DECIMAL(12,2),ATT_VolumenCorregidoSalidaEmbarque2 DECIMAL(12,3),ATT_FechaLlegadaEmbarque2 VARCHAR(30),
		ATT_VolumenLlegadaEmbarque2 DECIMAL(12,3),ATT_TemperaturaLlegadaEmbarque2 DECIMAL(12,2),ATT_VolumenCorregidoLlegadaEmbarque2 DECIMAL(12,3))

		EXEC sp_xml_removedocument @docHandle

		INSERT INTO ProViajesCartasPorteConocimientoEmbarque(IdViajeCartaPorte,IdMaterialPemex,PrecioUnitario,CreadoPor,CreadoEl,TipoConocimientoEmbarque,NumeroEmbarque1,FechaSalidaEmbarque1,
		VolumenSalidaEmbarque1,TemperaturaSalidaEmbarque1,VolumenCorregidoSalidaEmbarque1,FechaLlegadaEmbarque1,VolumenLlegadaEmbarque1,TemperaturaLlegadaEmbarque1,VolumenCorregidoLlegadaEmbarque1,
		NumeroEmbarque2,FechaSalidaEmbarque2,VolumenSalidaEmbarque2,TemperaturaSalidaEmbarque2,VolumenCorregidoSalidaEmbarque2,FechaLlegadaEmbarque2,VolumenLlegadaEmbarque2,TemperaturaLlegadaEmbarque2,VolumenCorregidoLlegadaEmbarque2)
		SELECT @IdViajeCartaPorte,ATT_IdMaterialPemex,ATT_PrecioUnitario,@CreadoPor,@CreadoEl,ATT_TipoConocimientoEmbarque,ATT_NumeroEmbarque1,
		CASE ATT_FechaSalidaEmbarque1 WHEN 'NULL' THEN NULL ELSE ATT_FechaSalidaEmbarque1 END,ATT_VolumenSalidaEmbarque1,ATT_TemperaturaSalidaEmbarque1,ATT_VolumenCorregidoSalidaEmbarque1,
		CASE ATT_FechaLlegadaEmbarque1 WHEN 'NULL' THEN NULL ELSE ATT_FechaLlegadaEmbarque1 END,ATT_VolumenLlegadaEmbarque1,ATT_TemperaturaLlegadaEmbarque1,ATT_VolumenCorregidoLlegadaEmbarque1,
		ATT_NumeroEmbarque2,CASE ATT_FechaSalidaEmbarque2  WHEN 'NULL' THEN NULL ELSE ATT_FechaSalidaEmbarque2 END,ATT_VolumenSalidaEmbarque2,ATT_TemperaturaSalidaEmbarque2,ATT_VolumenCorregidoSalidaEmbarque2,
		CASE ATT_FechaLlegadaEmbarque2 WHEN 'NULL' THEN NULL ELSE ATT_FechaLlegadaEmbarque2 END,ATT_VolumenLlegadaEmbarque2,ATT_TemperaturaLlegadaEmbarque2,ATT_VolumenCorregidoLlegadaEmbarque2
		FROM #TempProViajesCartasPorteConocimientoEmbarque
	END

	--Se agrego el seguro
	IF @dsProViajesCartaPorteSeguros IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesCartaPorteSeguros

		SELECT
		  ATT_AseguradoraMedioAmbiente
		, ATT_AseguradoraMedioAmbientePoliza
		, ATT_AseguradoraCarga
		, ATT_AseguradoraCargaPoliza
		, ATT_PrimaSeguroCarga
		INTO #TempProViajesCartasPorteSeguros
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesCartasPorteSeguros', 2) 
		WITH (ATT_AseguradoraMedioAmbiente VARCHAR(50)
		    , ATT_AseguradoraMedioAmbientePoliza VARCHAR(30)
			, ATT_AseguradoraCarga VARCHAR(50)
			, ATT_AseguradoraCargaPoliza VARCHAR(30)
			, ATT_PrimaSeguroCarga MONEY)

		EXEC sp_xml_removedocument @docHandle

		INSERT INTO ProViajesCartasPorteSeguros (IdViajeCartaPorte, AseguradoraMedioAmbiente, PolizaMedioAmbiente, AseguradoraCarga, PolizaCarga, PrimaSeguro, CreadoPor, CreadoEl)
		SELECT 
			@IdViajeCartaPorte
		, ATT_AseguradoraMedioAmbiente
		, ATT_AseguradoraMedioAmbientePoliza
		, ATT_AseguradoraCarga
		, ATT_AseguradoraCargaPoliza
		, ATT_PrimaSeguroCarga
		, @CreadoPor
		, @CreadoEl
		FROM #TempProViajesCartasPorteSeguros
	END

	--Consultar anticipos autorizados por login
	IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesTrayectosAutorizaMasGastosVales
	
		SELECT ATT_Secuencia,ATT_NoViajeCliente,ATT_IdProceso,ATT_IdUsuarioAutorizaGasto,ATT_IdUsuarioAutorizaVales
		INTO #TempProViajesTrayectosAutorizaMasGastosVales
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosAutorizaMasGastosVales',2) 
		WITH (ATT_Secuencia int,ATT_NoViajeCliente varchar(30),ATT_IdProceso int,ATT_IdUsuarioAutorizaGasto int,ATT_IdUsuarioAutorizaVales int)
		
		EXEC sp_xml_removedocument @docHandle
	END	

	/*SOLICITUD 4208 SECCION PARA AGREGAR LA DISTRIBUCION DE LOS CONCEPTOS EN UNA VARIABLE TABLA*/
	IF @dsProViajesTrayectosDistribucionConceptosFacturacion IS NOT NULL
	BEGIN
		
		INSERT INTO @TempProViajesTrayectosDistribucionConceptosFacturacion(COL_IdViajeTrayecto,COL_IdRutaTrayecto,COL_Secuencia,COL_IdConceptoFacturacion,COL_Importe,COL_IdViajeTrayectoDistribucionConceptoFacturacion,COL_TipoTrayecto)
		SELECT  COL_IdViajeTrayecto = T.Item.value('COL_IdViajeTrayecto[1]', 'int')
			   ,COL_IdRutaTrayecto = T.Item.value('COL_IdRutaTrayecto[1]', 'int')
			   ,COL_Secuencia = T.Item.value('COL_Secuencia[1]', 'int')
			   ,COL_IdConceptoFacturacion = T.Item.value('COL_IdConceptoFacturacion[1]', 'int')
			   ,COL_Importe = T.Item.value('COL_Importe[1]', 'money')
			   ,COL_IdViajeTrayectoDistribucionConceptoFacturacion = T.Item.value('COL_IdViajeTrayectoDistribucionConceptoFacturacion[1]', 'int')
			   ,COL_TipoTrayecto =  T.Item.value('COL_TipoTrayecto[1]', 'tinyint')
		FROM   @dsProViajesTrayectosDistribucionConceptosFacturacion.nodes('WINDEV_TABLE/ProViajesTrayectosDistribucionConceptosFacturacion') AS T(Item);

	END
	/*FIN SOLICITUD 4208*/
	
	--agrega trayectos del viaje	
	--Se agregó un nuevo campo en el xml de trayctos y como cursor el campo de "EnvioNotificacionMovil", para que se actualize junto con el trayecto (Solicitud 000013)
	IF @dsProViajesTrayectos IS NOT NULL
	BEGIN

		
		-----------------------------------------Cursor trayectos del viaje---------------------------------------------------------@CursorT_IdProveedor
		Set @RegistrarGastosAlConvoy = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'RegistrarGastosAlConvoyDelViaje')

		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesTrayectos
		
		SELECT ATT_Secuencia,ATT_IdOrigen,ATT_IdDestino,ATT_IdUnidadCamion,ATT_CodigoUnidadCamion,ATT_PlacasUnidadCamion,ATT_IdOperador,ATT_NombreOperador,ATT_Kilometros,ATT_Horas,ATT_NombreOperadorPermisionario
		      ,ATT_NoCartaPortePermisionario,ATT_NoFacturaPermisionario,ATT_IdMonedaPermisionario,ATT_FechaFacturaPermisionario,ATT_FechaRecepcionFacturaPermisionario,ATT_ConceptoPermisionario,
		      ATT_AplicarAnticipo,ATT_Anticipo,ATT_MonedaAnticipo,ATT_AplicarValeDeCombustible,ATT_LitrosAutorizados,ATT_IdProveedor,ATT_EsCompuesto,ATT_Tienda,ATT_NumeroOrden,ATT_Monto,ATT_CargadoVacioRemolque1,ATT_CargadoVacioRemolque2
		      ,ATT_FechaPagoFactura,ATT_FechaSalida,ATT_FechaLlegada,ATT_Millas,ATT_GalonesAutorizados,ATT_IdViajeTrayectoCompuesto,ATT_ETA,ATT_Referencia,ATT_EnvioNotificacionMovil
			  -- Solicitud 675
			  ,ATT_FechaHoraCarga, ATT_FechaHoraEstimadaCarga
			  ,ATT_FechaHoraDescarga, ATT_FechaHoraEstimadaDescarga
			  --Solicitud 866
			  ,ATT_CamionPer
			  ,ATT_UbicacionesXML
			  --SOLICITUD 4669
			  ,ATT_PermisionarioXML
			  ,ATT_IdOperadorAuxiliar
			  ,ATT_NombreOperadorAuxiliar
		INTO #TempProViajesTrayectos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectos',2) 
		WITH (ATT_Secuencia int,ATT_IdOrigen int,ATT_IdDestino int,ATT_IdUnidadCamion int,ATT_CodigoUnidadCamion varchar(16),ATT_PlacasUnidadCamion varchar(9),ATT_IdOperador int,ATT_NombreOperador varchar(100),ATT_Kilometros int,ATT_Horas decimal(15, 2),ATT_NombreOperadorPermisionario varchar(100)
		      ,ATT_NoCartaPortePermisionario varchar(15),ATT_NoFacturaPermisionario varchar(15),ATT_IdMonedaPermisionario int,ATT_FechaFacturaPermisionario datetime,ATT_FechaRecepcionFacturaPermisionario datetime,ATT_ConceptoPermisionario varchar(50),
		      ATT_AplicarAnticipo bit,ATT_Anticipo money,ATT_MonedaAnticipo varchar(7),ATT_AplicarValeDeCombustible bit,ATT_LitrosAutorizados decimal(15,2),ATT_IdProveedor int, ATT_EsCompuesto int,ATT_Tienda varchar(50),ATT_NumeroOrden int,ATT_Monto money,ATT_CargadoVacioRemolque1 bit,ATT_CargadoVacioRemolque2 bit,
		      ATT_FechaPagoFactura datetime,ATT_FechaSalida datetime,ATT_FechaLlegada datetime,ATT_Millas decimal(15,2),ATT_GalonesAutorizados decimal(15,2),ATT_IdViajeTrayectoCompuesto int,ATT_ETA decimal(15,2), ATT_Referencia varchar(20),ATT_EnvioNotificacionMovil bit
			  -- Solicitud675
			  ,ATT_FechaHoraCarga datetime
			  ,ATT_FechaHoraEstimadaCarga datetime
			  ,ATT_FechaHoraDescarga datetime
			  ,ATT_FechaHoraEstimadaDescarga datetime
			  ---Solicitud 866
			  ,ATT_CamionPer varchar(50)
			  ,ATT_UbicacionesXML varchar(max)
			  --SOLICITUD 4669
			  ,ATT_PermisionarioXML varchar(max)
			  ,ATT_IdOperadorAuxiliar int
			  ,ATT_NombreOperadorAuxiliar varchar(100))

		
		EXEC sp_xml_removedocument @docHandle

		DECLARE ProViajesTrayectosCursor CURSOR LOCAL FOR
		SELECT * FROM #TempProViajesTrayectos

		OPEN ProViajesTrayectosCursor
		FETCH NEXT FROM ProViajesTrayectosCursor
		INTO @CursorT_Secuencia,@CursorT_IdOrigen,@CursorT_IdDestino,@CursorT_IdUnidadCamion,@CursorT_CodigoUnidadCamion,@CursorT_PlacasUnidadCamion,@CursorT_IdOperador,@CursorT_NombreOperador,@CursorT_Kilometros,@CursorT_Horas,@CursorT_NombreOperadorPermisionario,
			 @CursorT_NoCartaPortePermisionario,@CursorT_NoFacturaPermisionario,@CursorT_IdMonedaPermisionario,@CursorT_FechaFacturaPermisionario,@CursorT_FechaRecepcionFacturaPermisionario,@CursorT_ConceptoPermisionario,
			 @CursorT_AplicarAnticipo,@CursorT_Anticipo,@CursorT_MonedaAnticipo,@CursorT_AplicarValeDeCombustible,@CursorT_LitrosAutorizados,@CursorT_IdProveedor,@CursorT__EsCompuesto,@CursorT_Tienda,@CursorT_NumeroOrden,@CursorT_Monto,@CursorT_CargadoVacioRemolque1,@CursorT_CargadoVacioRemolque2,
			 @CursorT_FechaPagoFactura,@CursorT_FechaSalida,@CursorT_FechaLlegada,@CursorT_Millas,@CursorT_GalonesAutorizados,@CursorT_IdViajeTrayectoCompuesto,@CursorT_ETA, @CursorT_Referencia, @CursorT_EnvioNotificacionMovil
			 --Solicitud 675
			 ,@CursorT_FechaHoraCarga
			 ,@CursorT_FechaHoraEstimadaCarga
			 ,@CursorT_FechaHoraDescarga
			 ,@CursorT_FechaHoraEstimadaDescarga
			 -- solicitud 866
			 ,@CursorT_CamionPer
			 ,@CursorT_UbicacionesXML
			 --SOLICITUD 4669
			 ,@CursorT_PermisionarioXML
			 ,@CursorT_IdOperadorAux
			 ,@CursorT_NombreOperadorAux
		
		WHILE @@FETCH_STATUS = 0
		BEGIN

			IF @CursorT__EsCompuesto != 0 
			BEGIN
				set @CursorT_FechaSalida  =  NULL
				set @CursorT_FechaLlegada =  NULL
			END	
			
			SET @TipoCambioTrayecto = NULL
			set @PorcentajeLiquidar = NULL
			
			SET @HorasTrayecto = NULL
			SET @HorometroInicial = NULL
			SET @HorometroFinal = NULL
			SET @HorometroInicialRemolque2= NULL 
			SET @HorometroFinalRemolque2 = NULL
			SET @PesoLiquidar = NULL
			IF ISDATE(@CursorT_FechaSalida) <> 0 AND ISDATE(@CursorT_FechaLlegada) <> 0 AND isnull(@CursorT__EsCompuesto,0) = 0
			BEGIN
				IF @CursorT_FechaSalida > @CursorT_FechaLlegada
				BEGIN
					RAISERROR(N'La Fecha de Llegada no puede ser menor a la Fehca de Salida',
						16,
						1
						) 
				END
				
				SET @OdometroInicial =(SELECT Odometro FROM CatUnidades where IdUnidad = @CursorT_IdUnidadCamion)
				SET @OdometroFinal = @OdometroInicial + @CursorT_Kilometros
				SET @TipoCambioTrayecto = @TipoCambio
				SET @OdometroInicialMillas =(SELECT OdometroMillas FROM CatUnidades where IdUnidad = @CursorT_IdUnidadCamion)
				SET @OdometroFinalMillas = @OdometroInicialMillas + @CursorT_Millas
				
				UPDATE CatUnidades
				set Odometro = @OdometroFinal,
				OdometroMillas = @OdometroFinalMillas
				where IdUnidad = @CursorT_IdUnidadCamion

------------ INICIO SI ES PORTUARIO SE ASIGNARA EL ID UNIDADCARGA 1 DESDE LA TABLA ProViajesContenedoresEquipos 
				SET @SecuenciaTrayecto =  NULL
				SET @SecuenciaTrayecto = @CursorT_Secuencia
				
				SET @EsPortuario = 0
				SET @EsPortuario = (SELECT TOP 1 Portuario FROM ProViajes WHERE IdViaje = @IdViaje)

				IF @EsPortuario = 1
				BEGIN
					SET @IdUnidadCarga1 = (	SELECT TOP 1 IdUnidad
											FROM
											ProViajesContenedoresEquipos AS PVCE
											INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje 
											AND PVCE.SecuenciaTrayecto = PVT.Secuencia
											WHERE
											IdViajeTrayecto = @IdViajeTrayecto 
											AND SecuenciaTrayecto = @SecuenciaTrayecto
											AND IdUnidad IS NOT NULL)

					IF @IdUnidadCarga1 IS NOT NULL
					BEGIN
						SET @IdUnidadCarga2 = (	SELECT IdUnidad
												FROM
												ProViajesContenedoresEquipos AS PVCE
												INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje 
												AND PVCE.SecuenciaTrayecto = PVT.Secuencia
												WHERE
												IdViajeTrayecto = @IdViajeTrayecto 
												AND SecuenciaTrayecto = @SecuenciaTrayecto
												AND IdUnidad IS NOT NULL
												AND IdUnidad <> @IdUnidadCarga1)
					END
				END
------------------ FINAL ASIGNACION DE UNIDADES DE CARGA SI ES PORTUARIO
				
				IF @IdUnidadCarga1 <> 0 AND @IdUnidadCarga2 <> 0
				BEGIN
					IF @CursorT_CargadoVacioRemolque1 = 1 AND @CursorT_CargadoVacioRemolque2 =1
					BEGIN
						SET @PorcentajeLiquidar = (select PorcentajeFullCargado from CatOperadores WHERE IdOperador = @CursorT_IdOperador)
					END
					ELSE
					BEGIN
						IF 	@CursorT_CargadoVacioRemolque1 = 0 AND @CursorT_CargadoVacioRemolque2 =0
						BEGIN
							SET @PorcentajeLiquidar = (select PorcentajeFullVacio from CatOperadores WHERE IdOperador = @CursorT_IdOperador)
						END
						ELSE
						BEGIN
							SET @PorcentajeLiquidar = (select PorcentajeFullVacioCargado_CargadoVacio from CatOperadores WHERE IdOperador = @CursorT_IdOperador)
						END
					END
				END
				ELSE
				BEGIN
					IF @CursorT_CargadoVacioRemolque1 = 1 AND @CursorT_CargadoVacioRemolque2 =1
					BEGIN
						SET @PorcentajeLiquidar = (select PorcentajeSencilloCargado from CatOperadores WHERE IdOperador = @CursorT_IdOperador)
					END
					ELSE
					BEGIN
						IF @CursorT_CargadoVacioRemolque1 = 0 AND @CursorT_CargadoVacioRemolque2 = 0
						BEGIN
							SET @PorcentajeLiquidar = (select PorcentajeSencilloVacio from CatOperadores WHERE IdOperador = @CursorT_IdOperador)
						END
						ELSE
						BEGIN
							SET @PorcentajeLiquidar = (select PorcentajeSencilloCargado from CatOperadores WHERE IdOperador = @CursorT_IdOperador)
						END
					END
				END
				
				IF @IdUnidadCarga1 IS NOT NULL
				BEGIN 
					SET @OdometroInicialIdUnidadCarga1 = (SELECT Odometro FROM CatUnidades where IdUnidad = @IdUnidadCarga1)
					SET @OdometroFinalIdUnidadCarga1 = @OdometroInicialIdUnidadCarga1+ @CursorT_Kilometros
					SET @OdometroInicialIdUnidadCarga1Millas = (SELECT OdometroMillas FROM CatUnidades where IdUnidad = @IdUnidadCarga1)
					SET @OdometroFinalIdUnidadCarga1Millas = @OdometroInicialIdUnidadCarga1Millas+ @CursorT_Millas
					
					UPDATE CatUnidades
					set Odometro = @OdometroFinalIdUnidadCarga1,
					OdometroMillas = @OdometroFinalIdUnidadCarga1Millas
					where IdUnidad = @IdUnidadCarga1
				END 
				
				IF 	@IdUnidadDolly  IS NOT NULL
				BEGIN 
					SET @OdometroInicialIdUnidadDolly = (SELECT Odometro FROM CatUnidades where IdUnidad = @IdUnidadDolly)
					SET @OdometroFinalIdUnidadDolly = @OdometroInicialIdUnidadDolly+ @CursorT_Kilometros
					SET @OdometroInicialIdUnidadDollyMillas = (SELECT OdometroMillas FROM CatUnidades where IdUnidad = @IdUnidadDolly)
					SET @OdometroFinalIdUnidadDollyMillas = @OdometroInicialIdUnidadDollyMillas+ @CursorT_Millas
					
					UPDATE CatUnidades
					set Odometro = @OdometroFinalIdUnidadDolly,
					OdometroMillas = @OdometroFinalIdUnidadDollyMillas
					where IdUnidad = @IdUnidadDolly
				END
				
				IF 	@IdUnidadCarga2  IS NOT NULL
				BEGIN 
					SET @OdometroInicialIdUnidadCarga2 = (SELECT Odometro FROM CatUnidades where IdUnidad = @IdUnidadCarga2)
					SET @OdometroFinalIdUnidadCarga2 = @OdometroInicialIdUnidadCarga2+ @CursorT_Kilometros
					SET @OdometroInicialIdUnidadCarga2Millas = (SELECT OdometroMillas FROM CatUnidades where IdUnidad = @IdUnidadCarga2)
					SET @OdometroFinalIdUnidadCarga2Millas = @OdometroInicialIdUnidadCarga2Millas+ @CursorT_Millas
					
					UPDATE CatUnidades
					set Odometro = @OdometroFinalIdUnidadCarga2,
					OdometroMillas = @OdometroFinalIdUnidadCarga2Millas
					where IdUnidad = @IdUnidadCarga2
				END
				
				---------Horometros
				IF @RegistrarGastosAlConvoy = 1
				BEGIN
					SET @HorasTrayecto = ISNULL((Select TOP 1 Horas from CatRutasTrayectos where IdRuta = @IdRuta And Secuencia = @CursorT_Secuencia),0)
					
					IF 	(@IdUnidadCarga1  IS NOT NULL) AND ((Select ctu.TipoUnidad from CatUnidades AS cu Inner Join CatTiposUnidades as ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad Where cu.IdUnidad = @IdUnidadCarga1) = 'THERMOKING/CAJA REFRIGERADA')
					BEGIN
						SET @HorometroInicial = ISNULL((Select Horometro from CatUnidades where IdUnidad = @IdUnidadCarga1),0)
						SET @HorometroFinal = (@HorometroInicial + (@HorasTrayecto * 60)) 	

						UPDATE CatUnidades
						set Horometro = @HorometroFinal
						where IdUnidad = @IdUnidadCarga1				
					END
					 
					IF (@IdUnidadCarga2  IS NOT NULL) AND ((Select ctu.TipoUnidad from CatUnidades AS cu Inner Join CatTiposUnidades as ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad Where cu.IdUnidad = @IdUnidadCarga2) = 'THERMOKING/CAJA REFRIGERADA')
					Begin
						SET @HorometroInicialRemolque2 =  ISNULL((Select Horometro from CatUnidades where IdUnidad = @IdUnidadCarga2),0)
						SET @HorometroFinalRemolque2 = (@HorometroInicialRemolque2 + (@HorasTrayecto * 60))	
						
						UPDATE CatUnidades
						set Horometro = @HorometroFinalRemolque2
						where IdUnidad = @IdUnidadCarga2					
					END					
					
				END
				-------------------				

				SET @PesoLiquidar = (select Peso from ProViajes where IdViaje = @IdViaje)
			
			END
			--Sol 282 Se agrego la hora al trayecto 
			INSERT INTO ProViajesTrayectos(CreadoEl,CreadoPor,CodigoUnidadCamion,IdOperador,IdUnidadCamion,IdViaje,Kilometros,Horas,NombreOperador,PlacasUnidadCamion,
			Secuencia,IdOrigen,IdDestino,CargadoVacioUnidadCarga1,CargadoVacioUnidadCarga2,NombreOperadorPermisionario,CartaPortePermisionario,FacturaPermisionario,IdMonedaPermisionario,FechaFacturaPermisionario,FechaRecepcionFacturaPermisionario,ConceptoPermisionario,
			AplicarAnticipo,AnticipoAutorizado,AnticipoAutorizadoMoneda,AplicarValeDeCombustible,LitrosAutorizados,EsCompuesto,Tienda,NumeroOrden,Monto,FechaPagoFactura,Salida,Llegada,OdometroInicial,OdometroFinal,TipoCambio,PorcentajeLiquidar,HorometroInicial,HorometroFinal,HorometroInicialRemolque2,HorometroFinalRemolque2,PesoDescarga,PesoLiquidar,Millas,GalonesAutorizados,OdometroInicialMillas,OdometroFinalMillas,IdViajeTrayectoCompuestoPadre,ETA,Referencia, EnvioNotificacionMovil
			--Solicitud 675
			,FechaHoraCarga
			,FechaHoraEstimadaCarga
			,FechaHoraDescarga
			,FechaHoraEstimadaDescarga
			--Solicitud 866
			,CamionPer
			--Solicitud 1005
			,IdProveedor
			,IdOperadorAuxiliar
			,NombreOperadorAuxiliar)
			VALUES(@CreadoEl,@CreadoPor,@CursorT_CodigoUnidadCamion,CASE @CursorT_IdOperador WHEN 0 THEN NULL ELSE @CursorT_IdOperador END,CASE @CursorT_IdUnidadCamion WHEN 0 THEN NULL ELSE @CursorT_IdUnidadCamion END,@IdViaje,@CursorT_Kilometros,@CursorT_Horas,@CursorT_NombreOperador,@CursorT_PlacasUnidadCamion,
					@CursorT_Secuencia,@CursorT_IdOrigen,@CursorT_IdDestino,@CursorT_CargadoVacioRemolque1,@CursorT_CargadoVacioRemolque2,@CursorT_NombreOperadorPermisionario,@CursorT_NoCartaPortePermisionario,@CursorT_NoFacturaPermisionario,
					CASE @CursorT_IdMonedaPermisionario WHEN 0 THEN NULL ELSE @CursorT_IdMonedaPermisionario END,@CursorT_FechaFacturaPermisionario,@CursorT_FechaRecepcionFacturaPermisionario,@CursorT_ConceptoPermisionario,
					CASE @CursorT_AplicarAnticipo WHEN 0 THEN NULL ELSE @CursorT_AplicarAnticipo END,
					CASE @CursorT_Anticipo WHEN 0 THEN NULL ELSE @CursorT_Anticipo END,
					CASE @CursorT_MonedaAnticipo WHEN '' THEN NULL ELSE @CursorT_MonedaAnticipo END,
					CASE @CursorT_AplicarValeDeCombustible WHEN 0 THEN NULL ELSE @CursorT_AplicarValeDeCombustible END,
					CASE @CursorT_LitrosAutorizados WHEN 0 THEN NULL ELSE @CursorT_LitrosAutorizados END,
					CASE @CursorT__EsCompuesto WHEN 0 THEN NULL ELSE @CursorT__EsCompuesto END,
					@CursorT_Tienda,@CursorT_NumeroOrden,@CursorT_Monto,@CursorT_FechaPagoFactura,@CursorT_FechaSalida,@CursorT_FechaLlegada,@OdometroInicial,@OdometroFinal,@TipoCambioTrayecto,@PorcentajeLiquidar,@HorometroInicial,@HorometroFinal,@HorometroInicialRemolque2,@HorometroFinalRemolque2,@Peso,@PesoLiquidar,@CursorT_Millas,@CursorT_GalonesAutorizados,@OdometroInicialMillas,@OdometroFinalMillas,@CursorT_IdViajeTrayectoCompuesto,@CursorT_ETA,@CursorT_Referencia,@CursorT_EnvioNotificacionMovil
					-- Solicitud 675
					,@CursorT_FechaHoraCarga
					,@CursorT_FechaHoraEstimadaCarga
					,@CursorT_FechaHoraDescarga
					,@CursorT_FechaHoraEstimadaDescarga
					--Solicitud 866
					,@CursorT_CamionPer
					-- Solcitud 1005
					,@CursorT_IdProveedor
					,CASE @CursorT_IdOperadorAux WHEN 0 THEN NULL ELSE @CursorT_IdOperadorAux END
					,@CursorT_NombreOperadorAux)
					
			SET @IdViajeTrayecto = (SELECT IDENT_CURRENT('ProViajesTrayectos'))	
			
			/*SOLICITUD 4208*/
			INSERT INTO ProViajesTrayectosDistribucionConceptosFacturacion(IdViajeTrayecto,IdRutaTrayecto,IdConceptoFacturacion,Secuencia,Importe,UltimaModificacion,TipoTrayecto)
			SELECT 
			 @IdViajeTrayecto
			,COL_IdRutaTrayecto
			,COL_IdConceptoFacturacion
			,COL_Secuencia
			,COL_Importe
			,@CreadoEl
			,COL_TipoTrayecto
			FROM @TempProViajesTrayectosDistribucionConceptosFacturacion
			WHERE COL_Secuencia = @CursorT_Secuencia
			/*FIN SOLICITUD 4208*/

			IF ISDATE(@CursorT_FechaSalida) <> 0 AND ISDATE(@CursorT_FechaLlegada) <> 0 AND isnull(@CursorT__EsCompuesto,0) = 0
			BEGIN
			-----		-- INICIA  ACTUALIZAR ESTATUS SALIDA DE CONTENEDORES 
				SET @IdContenedor1 = NULL
				SET @IdContenedor2 = NULL
				SET @IdContenedor3 = NULL
				SET @IdContenedor4 = NULL
				SET @NombreContenedor = NULL
				SET @EstatusParametros = NULL
				SET @MensajeValidacion = NULL

				SET @IdContenedor1 = (	SELECT TOP 1
										IdDetalleEntregaContenedor
										FROM
										ProViajesContenedoresEquipos AS PVCE
										INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje AND PVCE.SecuenciaTrayecto = PVT.Secuencia
										WHERE
										IdViajeTrayecto = @IdViajeTrayecto 
										AND SecuenciaTrayecto = @SecuenciaTrayecto
										AND IdUnidad IS NULL)

				--SE OBTIENE EL PARAMETRO QUE HAY EN CONFIGURACION DE OPERACION PORTUARIA
				SET @EstatusParametros = (	SELECT TOP 1 Valor FROM SisParametrosValores WHERE Parametro = 'EstatusSalidaContenedor')

				--SI EL CONTENEDOR 1 NO ES NULL SE ACTUALIZA EL ESTATUS DE PARAMETROS
				IF @IdContenedor1 IS NOT NULL
				BEGIN
					--SI HAY CONTENEDOR 1 PUEDE HABER CONTENEDOR 2
					SET @IdContenedor2 = (	SELECT TOP 1
											IdDetalleEntregaContenedor
											FROM
											ProViajesContenedoresEquipos AS PVCE
											INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje AND PVCE.SecuenciaTrayecto = PVT.Secuencia
											WHERE
											IdViajeTrayecto = @IdViajeTrayecto 
											AND SecuenciaTrayecto = @SecuenciaTrayecto
											AND IdUnidad IS NULL
											AND IdDetalleEntregaContenedor <> @IdContenedor1)
					--SI HAY PARAMETRO SE ACTUALIZA
					IF @EstatusParametros IS NOT NULL
					BEGIN
						EXEC usp_ProHistorialEstatusContenedorAgregar @IdContenedor1, @EstatusParametros, @CursorT_FechaSalida, 'SALIDA DE TRAYECTO', @CreadoEl, @CreadoPor, @IdPeticion
					END
					ELSE
					BEGIN
						RAISERROR(N'Ocurrió un error al actualizar estatus del contenedor 1',16,1)
					END
				END	
				--SI EL CONTENEDOR 2 NO ES NULL SE ACTUALIZA EL ESTATUS DE PARAMETROS
				IF @IdContenedor2 IS NOT NULL
				BEGIN
					--SI HAY CONTENEDOR 2 PUEDE HABER CONTENEDOR 3
					SET @IdContenedor3 = (	SELECT TOP 1
											IdDetalleEntregaContenedor
											FROM
											ProViajesContenedoresEquipos AS PVCE
											INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje AND PVCE.SecuenciaTrayecto = PVT.Secuencia
											WHERE
											IdViajeTrayecto = @IdViajeTrayecto 
											AND SecuenciaTrayecto = @SecuenciaTrayecto
											AND IdUnidad IS NULL
											AND IdDetalleEntregaContenedor NOT IN(@IdContenedor1,@IdContenedor2))
					--SI HAY PARAMETRO SE ACTUALIZA
					IF @EstatusParametros IS NOT NULL
					BEGIN
						EXEC usp_ProHistorialEstatusContenedorAgregar @IdContenedor2, @EstatusParametros, @CursorT_FechaSalida, 'SALIDA DE TRAYECTO', @CreadoEl, @CreadoPor, @IdPeticion
					END
					ELSE
					BEGIN
						RAISERROR(N'Ocurrió un error al actualizar estatus del contenedor 2',16,1)
					END
				END	

				--SI EL CONTENEDOR 3 NO ES NULL SE ACTUALIZA EL ESTATUS DE PARAMETROS
				IF @IdContenedor3 IS NOT NULL
				BEGIN
					--SI HAY CONTENEDOR 3 PUEDE HABER CONTENEDOR 4
					SET @IdContenedor4 = (	SELECT TOP 1
											IdDetalleEntregaContenedor
											FROM
											ProViajesContenedoresEquipos AS PVCE
											INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje AND PVCE.SecuenciaTrayecto = PVT.Secuencia
											WHERE
											IdViajeTrayecto = @IdViajeTrayecto 
											AND SecuenciaTrayecto = @SecuenciaTrayecto
											AND IdUnidad IS NULL
											AND IdDetalleEntregaContenedor NOT IN(@IdContenedor1,@IdContenedor2,@IdContenedor3))
					--SI HAY PARAMETRO SE ACTUALIZA
					IF @EstatusParametros IS NOT NULL
					BEGIN
						EXEC usp_ProHistorialEstatusContenedorAgregar @IdContenedor3, @EstatusParametros, @CursorT_FechaSalida, 'SALIDA DE TRAYECTO', @CreadoEl, @CreadoPor, @IdPeticion
					END
					ELSE
					BEGIN
						RAISERROR(N'Ocurrió un error al actualizar estatus del contenedor 3',16,1)
					END
				END	
				--SI EL CONTENEDOR 4 NO ES NULL SE ACTUALIZA EL ESTATUS DE PARAMETROS
				IF @IdContenedor4 IS NOT NULL
				BEGIN
					--SI HAY PARAMETRO SE ACTUALIZA
					IF @EstatusParametros IS NOT NULL
					BEGIN
						EXEC usp_ProHistorialEstatusContenedorAgregar @IdContenedor4, @EstatusParametros, @CursorT_FechaSalida, 'SALIDA DE TRAYECTO', @CreadoEl, @CreadoPor, @IdPeticion
					END
					ELSE
					BEGIN
						RAISERROR(N'Ocurrió un error al actualizar estatus del contenedor 4',16,1)
					END
				END	

-----			-- FIN  ACTUALIZAR ESTATUS SALIDA DE CONTENEDORES		

-----		--	--OBTENEMOS EL ESTATUS DE LLEGADA DE CONTENEDORES
				SET @EstatusLlegada = (	SELECT TOP 1 Valor FROM SisParametrosValores WHERE Parametro = 'EstatusLlegadaContenedor')	
				SET @ContenedorId = 0
				--SE INICIA WHILE INFINITO PARA RECORRER TODOS LOS CONTENEDORES DEL VIAJE Y ACTUALIZAR EL ESTATUS
				WHILE(1 = 1)
				BEGIN
					--SE OBTIENE EL ID POR CONTENEDOR
					SELECT @ContenedorId = MIN(IdDetalleEntregaContenedor)
					FROM
					ProViajesContenedoresEquipos AS PVCE
					INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje AND PVCE.SecuenciaTrayecto = PVT.Secuencia
					WHERE 
					IdViajeTrayecto = @IdViajeTrayecto AND
					SecuenciaTrayecto = @SecuenciaTrayecto AND
					IdUnidad IS NULL AND
					IdDetalleEntregaContenedor > @ContenedorId
					--SI YA NO TRAE NINGUN REGISTRO TERMINAMOS SALIMOS DEL WHILE
					IF @ContenedorId IS NULL BREAK
			
						--VALIDAMOS QUE EL ESTATUS NO ESTE VACIO
					IF @EstatusLlegada IS NOT NULL
					BEGIN
						--AQUI ACTUALIZAMOS EL ESTATUS POR CONTENEDOR
						EXEC usp_ProHistorialEstatusContenedorAgregar @ContenedorId, @EstatusLlegada, @CursorT_FechaLlegada, 'LLEGADA DE TRAYECTO', @CreadoEl, @CreadoPor, @IdPeticion
						SET @Llegada = @CursorT_FechaLlegada
					END
					ELSE
					BEGIN
						--SI EL ESTATUS ESTA VACIO MANDAMOS MENSAJE DE ERROR
						RAISERROR(N'Ocurrió un error al actualizar un contenedor',16,1)
					END
				END
------------- FIN DE ESTATUS DE LLEGADA EN CONTENEDORES
			END

			IF @CursorT__EsCompuesto != 0 
			BEGIN
				SET @IdUnidadHijo = (SELECT IdUnidadCamion FROM ProViajesTrayectos WHERE IdViajeTrayecto = @IdViajeTrayecto)
				SET @IdViajeTrayectoPadre = (SELECT IdViajeTrayectoCompuestoPadre FROM ProViajesTrayectos WHERE IdViajeTrayecto = @IdViajeTrayecto)
				SET @IdUnidadPadre = (SELECT IdUnidadCamion FROM ProViajesTrayectos WHERE IdViajeTrayecto = @IdViajeTrayectoPadre)
				IF @IdUnidadHijo <> @IdUnidadPadre 
					RAISERROR(N'Los trayectos del viaje hijo deben tener la misma unidad que el viaje padre',
								16,
								1
								)	
			END
			IF @CursorT_AplicarAnticipo = 1 AND @CursorT_Anticipo <> 0
			BEGIN
				SET @PermitirRegistrarAnticiposMayores = 0
				SET @FolioConsecutivo = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProAnticipos)
				IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL	
				BEGIN
					IF EXISTS(SELECT ATT_Secuencia FROM #TempProViajesTrayectosAutorizaMasGastosVales WHERE ATT_Secuencia = @CursorT_Secuencia AND ISNULL(ATT_IdUsuarioAutorizaGasto,0) <> 0)
					BEGIN
						IF EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CUD.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto AND CUD.IdProceso = TPVTA.ATT_IdProceso) OR (SELECT CU.TipoUsuario FROM CatUsuarios AS CU INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CU.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto) = 1
						BEGIN	
							SET @PermitirRegistrarAnticiposMayores = 1
						END
					END
				END
				IF (SELECT CU.TipoUsuario FROM CatUsuarios AS CU WHERE CU.IdUsuario = @CreadoPor) = 1 OR EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD WHERE CUD.IdUsuario = @CreadoPor)
				BEGIN
					SET @PermitirRegistrarAnticiposMayores = 1
				END
				IF ISNULL (@PermitirRegistrarAnticiposMayores,0) = 0
				BEGIN
					SET @PermitirRegistrarAnticiposMayores = (SELECT ISNULL(Valor,0) FROM SisParametrosValores WHERE Parametro = 'PermitirRegistrarAnticiposMayores')
				END
	
				IF @CursorT_MonedaAnticipo = 'PESOS' 
				BEGIN
					SET @IdMonedaAnticipo = 1
				END
				ELSE
				BEGIN
					SET @IdMonedaAnticipo = 2					
				END
		
				EXEC @return_value = usp_ProAnticiposRegistrar	@FechaTemp,@IdViajeTrayecto,@CursorT_Anticipo,'',@CreadoEl,@CreadoPor,@IdPeticion,@FolioConsecutivo,'Anticipo generado desde Viajes',@PermitirRegistrarAnticiposMayores,@CursorT_IdOperador,@IdMonedaAnticipo,@TipoCambio,@PTVContratado,NULL,NULL,1
					
					IF @return_value <> 0
				BEGIN
					RAISERROR(N'Ocurrió un error al agregar los Anticipos',
						16,
						1
						)	
				END
				ELSE
				BEGIN
					SET @IdSesion = (SELECT TOP 1 CAST(IdSesion as varchar(36)) AS IdSesion FROM SisSesiones WHERE IdUsuario = @CreadoPor AND Fin IS NULL ORDER BY Inicio DESC)
					
					SET @Mensaje = 'ANTICIPO GENERADO DESDE VIAJES(REGISTRAR) VIAJE: '+cast(@Viaje as varchar)+',IMPORTE: $'+cast(@CursorT_Anticipo as varchar)+',FOLIO ANTICIPO: '+cast(@FolioConsecutivo as varchar)
					set @FechaLocal = (SELECT GETUTCDATE())

					EXEC @return_value = usp_SisBitacorasRegistrar @CreadoPor,@IdSesion,500204,@FechaLocal,@Mensaje,''
					
					IF @return_value <> 0
					RAISERROR(N'Ocurrió un error al agregar los Anticipos',
						16,
						1
						)
				END			
			END
			
			IF @CursorT_AplicarValeDeCombustible = 1 AND @CursorT_LitrosAutorizados <> 0
			BEGIN
				SET @PermitirRegistrarLitrosMayores = 0
				SET @FolioValesConsecutivo = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProValesCombustible)
				SET @Autorizo = (Select Nombre from CatUsuarios where IdUsuario = @CreadoPor)
				
				IF @dsProViajesTrayectosAutorizaMasGastosVales IS NOT NULL	
				BEGIN
					IF EXISTS(SELECT ATT_Secuencia FROM #TempProViajesTrayectosAutorizaMasGastosVales WHERE ATT_Secuencia = @CursorT_Secuencia AND isnull(ATT_IdUsuarioAutorizaVales,0) <> 0)
					BEGIN
						IF EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CUD.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaVales AND CUD.IdProceso = TPVTA.ATT_IdProceso) OR (SELECT CU.TipoUsuario FROM CatUsuarios AS CU INNER JOIN #TempProViajesTrayectosAutorizaMasGastosVales AS TPVTA ON  @CursorT_Secuencia = TPVTA.ATT_Secuencia WHERE CU.IdUsuario = TPVTA.ATT_IdUsuarioAutorizaGasto) = 1
						BEGIN
							SET @PermitirRegistrarLitrosMayores = 1
						END
					END
				END
				IF (SELECT CU.TipoUsuario FROM CatUsuarios AS CU WHERE CU.IdUsuario = @CreadoPor) = 1 OR EXISTS(SELECT CUD.Derecho FROM CatUsuariosDerechos AS CUD WHERE CUD.IdUsuario = @CreadoPor)
				BEGIN
					SET @PermitirRegistrarLitrosMayores = 1
				END
				IF ISNULL (@PermitirRegistrarLitrosMayores,0) = 0
				BEGIN
					SET @PermitirRegistrarLitrosMayores = (SELECT ISNULL(Valor,0) FROM SisParametrosValores WHERE Parametro = 'PermitirRegistrarLitrosMayores')
				END

				EXEC @return_value = usp_ProValesCombustibleRegistrar	@FechaTemp,@FolioValesConsecutivo,@CursorT_IdProveedor,@CursorT_IdUnidadCamion,@IdViajeTrayecto,@CursorT_IdOperador,@Autorizo,@CursorT_LitrosAutorizados,0,'Vale generado desde Viajes',@PermitirRegistrarLitrosMayores,@CreadoPor,@CreadoElVale,@IdPeticion,0,@CursorT_GalonesAutorizados,@CursorT_Millas,1
				IF @return_value <> 0
					RAISERROR(N'Ocurrió un error al agregar los vales de combustible',
						16,
						1
						)	
				ELSE
				BEGIN
					SET @IdSesion = (SELECT TOP 1 CAST(IdSesion as varchar(36)) AS IdSesion FROM SisSesiones WHERE IdUsuario = @CreadoPor AND Fin IS NULL ORDER BY Inicio DESC)
					
					SET @Mensaje = 'VALE DE COMBUSTIBLE DESDE VIAJES(REGISTRAR) VIAJE: '+cast(@Viaje as varchar)+', LITROS: '+cast(@CursorT_LitrosAutorizados as varchar)+', FOLIO VALE: '+cast(@FolioValesConsecutivo as varchar)
					set @FechaLocal = (SELECT GETUTCDATE())

					EXEC @return_value = usp_SisBitacorasRegistrar @CreadoPor,@IdSesion,500301,@FechaLocal,@Mensaje,''
					
					IF @return_value <> 0
					RAISERROR(N'Ocurrió un error al agregar los Vales de combustible',
						16,
						1
						)
				END			
			END
			
			---Se saca para la validacion siguiente que valida el operadopr con el trayecto
			IF @CursorT__EsCompuesto != 0
			BEGIN
				--cuando es un viaje compuesto hijo se valida que tengan el mismo operador el viaje
				--que la liquidacion del viaje padre no este cerrada, no tenga salida, ni llegada
				IF @IdViajeCompuestoPadre != 0
				BEGIN
					SET @IdOperador = (SELECT TOP 1 IdOperador FROM ProViajesTrayectos WHERE IdViaje = @IdViaje and IdViajeTrayecto = @IdViajeTrayecto)  --<-----********Modificado
					IF NOT EXISTS(SELECT pvt.IdViaje FROM ProViajesTrayectos AS pvt LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion WHERE pvt.IdViaje = @IdViajeCompuestoPadre AND pvt.IdOperador = @IdOperador AND pvt.Salida IS NULL AND pvt.Llegada IS NULL AND (pvt.IdLiquidacion IS NULL OR (pvt.IdLiquidacion IS NOT NULL AND pl.CerradaEl IS NULL)))
						RAISERROR(N'El viaje compuesto padre al que se intenta ligar no cumple con los requerimientos de no estar liquidado o que la liquidacion este cerrada, sea del mismo operador, no tenga salida ni llegada.',
						16,
						1
						)
				END 

				If @CursorT_IdViajeTrayectoCompuesto <> 0
				BEGIN
					UPDATE ProViajesTrayectos Set EsCompuesto = 1 Where IdViajeTrayecto = @CursorT_IdViajeTrayectoCompuesto
				END

			END	

			/*Recolectas/Repartos(Ubicaciones)*/
			IF @CursorT_UbicacionesXML <> '' 
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @CursorT_UbicacionesXML
			
				SELECT ATT_IdRemitente,ATT_FechaCarga,ATT_DatosRemitente,ATT_IdDestinatario,ATT_FechaEntrega,ATT_DatosDestinatario
				INTO #TempProViajesTrayectosUbicaciones
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosUbicaciones',2) 
				WITH(ATT_IdRemitente int,ATT_FechaCarga datetime,ATT_DatosRemitente nvarchar(max),ATT_IdDestinatario int,ATT_FechaEntrega datetime,ATT_DatosDestinatario nvarchar(max))
			
				EXEC sp_xml_removedocument @docHandle
			
				INSERT INTO ProViajesTrayectosUbicaciones(IdViajeTrayecto,IdRemitente,FechaCarga,DatosRemitente,IdDestinatario,FechaEntrega,DatosDestinatario,UltimaFechaModificacion)
				SELECT @IdViajeTrayecto,ATT_IdRemitente,CASE WHEN ATT_FechaCarga = '' THEN NULL ELSE ATT_FechaCarga END,ATT_DatosRemitente,ATT_IdDestinatario,CASE WHEN ATT_FechaEntrega = '' THEN NULL ELSE ATT_FechaEntrega END,ATT_DatosDestinatario,@CreadoEl
				FROM #TempProViajesTrayectosUbicaciones
			
				DROP TABLE #TempProViajesTrayectosUbicaciones
			END
			/**Permisionarios*/
			IF @CursorT_PermisionarioXML <> '' 
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @CursorT_PermisionarioXML
			
				SELECT  ATT_RFC,ATT_Licencia,ATT_IdPais,ATT_CodigoPostal,ATT_NoRegistroIdentidadFiscal,ATT_IdEstado,ATT_Municipio
						,ATT_Localidad,ATT_Colonia,ATT_Calle,ATT_NoInterior,ATT_NoExterior,ATT_Modelo,ATT_TiporemolqueSAT,ATT_Placas,ATT_PermisoSCTSAT
						,ATT_CompaniaSeguros,ATT_NumeroSeguro,ATT_PermisoSCT 
				INTO #TempProViajesTrayectosPermisionarios
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosPermisionarios',2) 
				WITH(ATT_RFC varchar(13),ATT_Licencia varchar(19),ATT_IdPais int,ATT_CodigoPostal varchar(10),ATT_NoRegistroIdentidadFiscal varchar(20),ATT_IdEstado varchar(5),ATT_Municipio varchar(120)
					,ATT_Localidad varchar(120),ATT_Colonia varchar(120),ATT_Calle varchar(100),ATT_NoInterior varchar(10),ATT_NoExterior varchar(10),ATT_Modelo smallint,ATT_TiporemolqueSAT varchar(20),ATT_Placas varchar(9),ATT_PermisoSCTSAT varchar(20)
					,ATT_CompaniaSeguros varchar(50),ATT_NumeroSeguro varchar(30),ATT_PermisoSCT varchar(30))
			
				EXEC sp_xml_removedocument @docHandle
					IF (SELECT ISNULL(ATT_RFC,'') FROM #TempProViajesTrayectosPermisionarios)<>'' OR (SELECT ISNULL(ATT_NoRegistroIdentidadFiscal,'') FROM #TempProViajesTrayectosPermisionarios)<>'' BEGIN
					--CHOFER PERMISIONARIO
						INSERT INTO ProViajesTrayectosChoferPermisionario(IdViajeTrayecto,RFC,Licencia,IdPais,CodigoPostal,NoRegistroIdentidadFiscal,IdEstado,Municipio,Localidad,Colonia,Calle,NoInterior,NoExterior)
						SELECT @IdViajeTrayecto,ATT_RFC ,ATT_Licencia ,ATT_IdPais,ATT_CodigoPostal,ATT_NoRegistroIdentidadFiscal ,ATT_IdEstado
							,ATT_Municipio,ATT_Localidad ,ATT_Colonia ,ATT_Calle ,ATT_NoInterior,ATT_NoExterior
						FROM #TempProViajesTrayectosPermisionarios
					END
					--UNIDAD PERMISIONARIO
					 IF (SELECT ISNULL(ATT_Modelo,0) FROM #TempProViajesTrayectosPermisionarios )<>0 BEGIN
						INSERT INTO ProViajesTrayectosUnidadPermisionario(IdViajeTrayecto,Modelo,TiporemolqueSAT,Placas,PermisoSCTSAT,PermisoSCT,CompaniaSeguros,NumeroSeguro)
						SELECT @IdViajeTrayecto,ATT_Modelo,ATT_TiporemolqueSAT,ATT_Placas,ATT_PermisoSCTSAT,ATT_PermisoSCT,ATT_CompaniaSeguros,ATT_NumeroSeguro 
						FROM #TempProViajesTrayectosPermisionarios
					 END
			
				DROP TABLE #TempProViajesTrayectosPermisionarios
			END
			--------------------MATERIALES POR TRAYECTO-------------------------------------	
			IF @dsProViajesTrayectosMateriales IS NOT NULL
			BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesTrayectosMateriales
			
					SELECT ATT_Consecutivo,ATT_Cantidad,ATT_IdRutaTrayecto
					INTO #TempProViajesTrayectosMateriales
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectosMateriales',2) 
					WITH (ATT_Consecutivo int,ATT_Cantidad decimal(15,4),ATT_IdRutaTrayecto int)
					EXEC sp_xml_removedocument @docHandle
					
					INSERT INTO ProViajesTrayectosMateriales(Consecutivo,IdViajeDescripcionCarga,IdViajeTrayecto,Cantidad)
					SELECT ATT_Consecutivo,PVDC.IdViajeDescripcionCarga,@IdViajeTrayecto,ATT_Cantidad
					FROM #TempProViajesTrayectosMateriales MTemp
					INNER JOIN ProViajesTrayectos PVT ON PVT.IdViajeTrayecto = @IdViajeTrayecto
					INNER JOIN ProViajesDescripcionesCarga PVDC ON PVDC.Consecutivo=MTemp.ATT_Consecutivo AND PVT.IdViaje = PVDC.IdViaje
					INNER JOIN ProViajes AS PV  ON PVT.IdViaje = PV.IdViaje
					INNER JOIN CatRutasTrayectos AS CRT ON PV.IdRuta = CRT.IdRuta AND PVT.Secuencia = CRT.Secuencia
					WHERE PVDC.IdViaje=@IdViaje AND  CRT.IdRutaTrayecto=ATT_IdRutaTrayecto
				
				DROP TABLE #TempProViajesTrayectosMateriales
			END
			--------------------------------------------------------
			FETCH NEXT FROM ProViajesTrayectosCursor
			INTO @CursorT_Secuencia,@CursorT_IdOrigen,@CursorT_IdDestino,@CursorT_IdUnidadCamion,@CursorT_CodigoUnidadCamion,@CursorT_PlacasUnidadCamion,@CursorT_IdOperador,@CursorT_NombreOperador,@CursorT_Kilometros,@CursorT_Horas,@CursorT_NombreOperadorPermisionario,
				 @CursorT_NoCartaPortePermisionario,@CursorT_NoFacturaPermisionario,@CursorT_IdMonedaPermisionario,@CursorT_FechaFacturaPermisionario,@CursorT_FechaRecepcionFacturaPermisionario,@CursorT_ConceptoPermisionario,
				 @CursorT_AplicarAnticipo,@CursorT_Anticipo,@CursorT_MonedaAnticipo,@CursorT_AplicarValeDeCombustible,@CursorT_LitrosAutorizados,@CursorT_IdProveedor,@CursorT__EsCompuesto,@CursorT_Tienda,@CursorT_NumeroOrden,@CursorT_Monto,@CursorT_CargadoVacioRemolque1,@CursorT_CargadoVacioRemolque2,@CursorT_FechaPagoFactura,
				 @CursorT_FechaSalida,@CursorT_FechaLlegada,@CursorT_Millas,@CursorT_GalonesAutorizados,@CursorT_IdViajeTrayectoCompuesto,@CursorT_ETA,@CursorT_Referencia,@CursorT_EnvioNotificacionMovil
				 -- Solicitud 675
				 ,@CursorT_FechaHoraCarga
				 ,@CursorT_FechaHoraEstimadaCarga
				 ,@CursorT_FechaHoraDescarga
				 ,@CursorT_FechaHoraEstimadaDescarga
				 --Solicitud 866
				 ,@CursorT_CamionPer
				 ,@CursorT_UbicacionesXML
				 --SOLICITUD 4669
			 ,@CursorT_PermisionarioXML
			 ,@CursorT_IdOperadorAux
			 ,@CursorT_NombreOperadorAux
		
		END
		CLOSE ProViajesTrayectosCursor
		DEALLOCATE ProViajesTrayectosCursor
		-----------------------------------------FIN Cursor trayectos del viaje-----------------------------------------------------
	END		
	
	-- actualiza el estatus del folio
	UPDATE CatFolios SET Estatus = 2 WHERE IdFolio = @IdFolio
	
	--actualiza el saldo del cliente 
	IF @Facturable = 1
	BEGIN
		IF @ViajeConCP = 1
		BEGIN
			IF @IdMoneda = 1 OR @IdMoneda = 3
				UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0) + @Total WHERE IdCliente = @IdCliente
			ELSE
				UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) + @Total WHERE IdCliente = @IdCliente	
		END
		ELSE
		BEGIN
			IF @IdMoneda = 1 OR @IdMoneda = 3
				UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0) + @SubTotal WHERE IdCliente = @IdCliente
			ELSE
				UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) + @SubTotal WHERE IdCliente = @IdCliente	
		END		
	END
	
	IF @PermitirDocumentarRebaseCredito = 0
	BEGIN
		IF @IdMoneda = 1 OR @IdMoneda = 3
		BEGIN
			IF (SELECT ISNULL(PendFacturar,0)+ISNULL(SaldoCredito,0) FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT Credito FROM CatClientes WHERE IdCliente = @IdCliente)
				RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
					16,
					1
					)
		END
		ELSE
		BEGIN
			IF (SELECT ISNULL(PendFacturarDLLS,0)+ISNULL(SaldoCreditoDLLS,0) FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT CreditoDLLS FROM CatClientes WHERE IdCliente = @IdCliente)
				RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
					16,
					1
					)	
		END
	END
	
	
	-- Registra en la tabla puente solicitudes EDI y el viaje
	IF ISNULL(@IdSolicitudEDI,0)!=0 
	BEGIN
		IF NOT EXISTS(SELECT IdSolicitudEDI FROM ProSolicitudesEDI WHERE IdSolicitudEDI = @IdSolicitudEDI)
			RAISERROR(N'La solicitud EDI fue eliminado por otro usuario',
				16,
				1
				)
				
		IF (SELECT CanceladoEl FROM ProSolicitudesEDI WHERE IdSolicitudEDI = @IdSolicitudEDI) IS NOT NULL --cancelado
			RAISERROR(N'No puede aceptar esta solicitud EDI porque está cancelada',
				16,
				1
				)
				
		--se valida que la solicitud no este aceptada por otro usuario.
		IF EXISTS(SELECT IdSolicitudEDI FROM ProSolicitudesEDIViaje  WHERE IdSolicitudEDI = @IdSolicitudEDI)
			RAISERROR(N'La solicitud EDI ya fue aceptada por otro usuario, verificar información',
				16,
				1
				)
		-- Se registra en la tabla puente.	
		UPDATE ProSolicitudesEDI SET AceptadoEl = @CreadoEl, AceptadoPor=@CreadoPor
		WHERE ProSolicitudesEDI.IdSolicitudEDI = @IdSolicitudEDI 	
		
		INSERT INTO ProSolicitudesEDIViaje (IdSolicitudEDI,IdViaje,CreadoPor,CreadoEL) VALUES (@IdSolicitudEDI,@IdViaje,@CreadoPor,@CreadoEl)
	END
	
		IF NOT EXISTS(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND Llegada IS NULL)	
	BEGIN
		UPDATE ProViajes SET
			ViajeTerminado = 1,
			TerminadoEl = @CreadoEl,
			TerminadoPor = @CreadoPor
		WHERE IdViaje = @IdViaje AND TerminadoEl IS NULL
			
		--SI TODOS LOS TRAYECTOS TIENEN LLEGADA ENTONCES EL VIAJE TERMINO
		--SE LE TIENE QUE PONER A TODOS LOS CONTENEDORES EL ESTATUS QUE SE PUSO EN PARAMETROS DE CONFIGURACION
		IF NOT EXISTS(SELECT IdViajeTrayecto FROM ProViajesTrayectos WHERE IdViaje = @IdViaje AND Llegada IS NULL)	
		BEGIN
			--SE OBTIENE EL ESTATUS QUE SE PUSO EN PARAMETROS DE OCNFIGURACION
			SET @EstatusTerminado = (	SELECT TOP 1 Valor FROM SisParametrosValores WHERE Parametro = 'EstatusTerminadoContenedor')
			--SET @EstatusLlegada = (	SELECT TOP 1 Valor FROM SisParametrosValores WHERE Parametro = 'EstatusLlegadaContenedor')	
			SET @ContenedorId = 0
			--SE INICIA WHILE INFINITO PARA RECORRER TODOS LOS CONTENEDORES DEL VIAJE Y ACTUALIZAR EL ESTATUS
			WHILE(1 = 1)
			BEGIN
				--SE OBTIENE EL ID POR CONTENEDOR
				SELECT @ContenedorId = MIN(IdDetalleEntregaContenedor)
				FROM
				ProViajesContenedoresEquipos AS PVCE
				INNER JOIN ProViajesTrayectos AS PVT ON  PVCE.IdViaje = PVT.IdViaje
				WHERE 
				PVCE.IdViaje = @IdViaje AND
				IdUnidad IS NULL AND
				IdDetalleEntregaContenedor > @ContenedorId
				--SI YA NO TRAE NINGUN REGISTRO TERMINAMOS SALIMOS DEL WHILE
				IF @ContenedorId IS NULL BREAK
				--VALIDAMOS QUE EL ESTATUS NO ESTE VACIO
				IF @EstatusTerminado IS NOT NULL
				BEGIN
					--AQUI ACTUALIZAMOS EL ESTATUS POR CONTENEDOR
					--LUEGO ESTATUS DE TERMINADO
					EXEC usp_ProHistorialEstatusContenedorAgregar @ContenedorId, @EstatusTerminado, @Llegada, 'TERMINO DE TRAYECTO', @CreadoEl, @CreadoPor, @IdPeticion
				END
				ELSE
				BEGIN
					--SI EL ESTATUS ESTA VACIO MANDAMOS MENSAJE DE ERROR
					RAISERROR(N'Ocurrió un error al actualizar estatus en un contenedor',16,1)
				END
			END
		END
		-- FIN  ACTUALIZAR ESTATUS CONTENEDORES SOLICITUD 528
	END
	 
	COMMIT
END TRY
BEGIN CATCH
	SET @IdViaje = -1
	IF(@@TRANCOUNT>0)
	BEGIN
	  IF (SELECT CURSOR_STATUS('LOCAL','ProViajesTrayectosCursor')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','ProViajesTrayectosCursor')) > -1
		BEGIN
			CLOSE ProViajesTrayectosCursor
		END
	  DEALLOCATE ProViajesTrayectosCursor
	  END

	  IF (SELECT CURSOR_STATUS('LOCAL','CursorViajesConceptosFacturacion')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorViajesConceptosFacturacion')) > -1
		BEGIN
			CLOSE CursorViajesConceptosFacturacion
		END
	  DEALLOCATE CursorViajesConceptosFacturacion
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorProViajesDescripcionesCarga')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorProViajesDescripcionesCarga')) > -1
		BEGIN
			CLOSE CursorProViajesDescripcionesCarga
		END
	  DEALLOCATE CursorProViajesDescripcionesCarga
	  END

	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH

RETURN @IdViaje
go

