CREATE PROCEDURE [dbo].[usp_Listado_UnidadesPickup_Paginado]
--DECLARE
@Xml XML,
@Pagina INT = 1,
@Elemento INT = 14,
@Activa  INT = 0,
@FiltroMantenimiento INT = 0,
@Rentadas INT = 0,
@FiltroSucursal INT = 0,
@Sucursal INT = 0,
@OrdenOrientacion INT = 0,
@Identificador1 INT = 0,
@Identificador2 INT = 0,
@Ordenamiento VARCHAR(MAX)= 'PlacasExtranjerasVencimiento',
@Busqueda VARCHAR(MAX) = '',
@FiltroBusqueda INT = 0 ,
@SoloPortacontenedoresYContenedores INT = 0,
@IdUsuario INT = 0,
@TipoUsuario INT = 1,
@FiltroUnidadPropias INT = 0
AS
DECLARE
@Sql NVARCHAR(MAX),
@Where NVARCHAR(MAX),
@Parametros NVARCHAR(MAX),
@AuxiliarBusqueda VARCHAR(MAX)='%',
@Identificador3  INT = 0,
@Identificador4  INT = 0,
@Identificador5  INT = 0,
@FiltroPortacontenedoresYContenedores NVARCHAR(MAX) = '',
@ValorEstatusMantenimiento INT =(Select IdEstatuUnidad from CatEstatusUnidades Where Abreviacion = 'MANTO' AND DefinidoPorSistema = 1);

SET @AuxiliarBusqueda = @AuxiliarBusqueda + @Busqueda +'%'
SET @Busqueda = upper(@AuxiliarBusqueda)

IF @OrdenOrientacion = 0
BEGIN
IF @Ordenamiento = 'IdUnidad'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.IdUnidad ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'TipoUnidad'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY ctu.TipoUnidad ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'Codigo'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Codigo ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'NumeroOperador'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY co.NumeroOperador ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'Operador'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY co.Nombre ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'PlacasExtranjerasVencimiento'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.PlacasExtranjerasVencimiento ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'PlacasVencimiento'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.PlacasVencimiento ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'VencimientoSeguro'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.VencimientoSeguro ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Sucursal'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cs.Sucursal ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Placas'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Placas ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Seguro'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.NumeroSeguro ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Placas_Ext'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.PlacasExtranjeras ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Descripcion'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Descripcion ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Estatus'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY pih.IdEstatuUnidad ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Activa'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Activa ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	
	IF @Ordenamiento = 'IdentificadorConvoy'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.IdentificadorConvoy ASC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END	
END

IF @OrdenOrientacion = 1
BEGIN
	IF @Ordenamiento = 'IdUnidad'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.IdUnidad DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'TipoUnidad'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY ctu.TipoUnidad DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'Codigo'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Codigo DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'NumeroOperador'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY co.NumeroOperador DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'Operador'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY co.Nombre DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'PlacasExtranjerasVencimiento'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.PlacasExtranjerasVencimiento DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'PlacasVencimiento'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.PlacasVencimiento DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
IF @Ordenamiento = 'VencimientoSeguro'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.VencimientoSeguro DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Sucursal'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cs.Sucursal DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Placas'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Placas DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Seguro'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.NumeroSeguro DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Placas_Ext'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.PlacasExtranjeras DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Descripcion'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Descripcion DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Estatus'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY pih.IdEstatuUnidad DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	IF @Ordenamiento = 'Activa'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.Activa DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END
	
	IF @Ordenamiento = 'IdentificadorConvoy'
	BEGIN
		SET @Sql = '
		;with Unidades as (SELECT ROW_NUMBER() OVER (ORDER BY cu.IdentificadorConvoy DESC  ) AS rownumber,cu.IdUnidad, ctu.TipoUnidad,cu.Codigo,cu.IdentificadorConvoy,cu.Descripcion,co.NumeroOperador,co.Nombre,cu.Placas,cu.PlacasVencimiento,cu.PlacasExtranjeras,cu.PlacasExtranjerasVencimiento,cs.Sucursal,cu.Activa,cu.NumeroSeguro,cu.VencimientoSeguro,cu.IdentificadorSatelital,cu.VencimientoSeguro1,ceu.Color,pih.IdEstatuUnidad,cu.NombreImagenUnidad,ceu.Abreviacion,ceu.ColorLetra
		
		FROM CatUnidades AS cu
			INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad
			INNER JOIN CatSucursales AS cs ON cu.IdSucursal = cs.IdSucursal
			LEFT JOIN CatOperadores AS co ON cu.IdOperador = co.IdOperador
			INNER JOIN ProInventarioUnidades AS pih on pih.IdUnidad = cu.IdUnidad
			INNER JOIN CatEstatusUnidades AS ceu ON pih.IdEstatuUnidad = ceu.IdEstatuUnidad
			LEFT JOIN ProViajes AS pv ON pih.IdViaje = pv.IdViaje '
	END	
END

IF @Activa = 1
BEGIN
	IF @FiltroSucursal = 1
	BEGIN
		IF @Rentadas = 1
		BEGIN
			IF @FiltroMantenimiento = 1
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal in (SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND cu.Rentada <> 1 AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END

				IF  (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal = @Sucursal AND cu.Rentada <> 1 AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END

			END
			ELSE
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal IN(SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND cu.Rentada <> 1 AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END

				IF  (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal = @Sucursal AND cu.Rentada <> 1 AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			END
		END
		ELSE
		BEGIN
		IF @FiltroMantenimiento = 1
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal in (SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END

				IF  (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal = @Sucursal AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			END
			ELSE
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal in (SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END

				IF  (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE  cu.Activa = 1 AND cu.IdSucursal = @Sucursal AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			END
		END
	END
	ELSE
	BEGIN
		IF @Rentadas = 1
		BEGIN
			IF @FiltroMantenimiento = 1
			BEGIN
				SET @Where = 'WHERE  cu.Activa = 1 AND cu.Rentada <> 1 AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
			ELSE
			BEGIN
				SET @Where = 'WHERE  cu.Activa = 1 AND cu.Rentada <> 1 AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
		END
		ELSE
		BEGIN
		IF @FiltroMantenimiento = 1
			BEGIN
				SET @Where = 'WHERE  cu.Activa = 1  AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
			ELSE
			BEGIN
				SET @Where = 'WHERE  cu.Activa = 1 AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
		END
	END
END
ELSE
BEGIN
	IF @FiltroSucursal = 1
	BEGIN
		IF @Rentadas = 1
		BEGIN
			IF @FiltroMantenimiento = 1
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal in (SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND cu.Rentada <> 1 AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			
				IF (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal = @Sucursal AND cu.Rentada <> 1 AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			END
			ELSE
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal in (SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND cu.Rentada <> 1 AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
		
				IF (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal = @Sucursal AND cu.Rentada <> 1 AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			END
		END
		ELSE
		BEGIN
		IF @FiltroMantenimiento = 1
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal IN(SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END

				IF (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal = @Sucursal AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			END
			ELSE
			BEGIN
				IF @TipoUsuario = 3 AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 1
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal IN( SELECT IdSucursal FROM CatSucursales WHERE IdSucursal = @Sucursal OR IdSucursal IN(SELECT IdSucursal FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND Proceso = 4 ) ) AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END

				IF (@TipoUsuario = 3 OR @TipoUsuario = 4 OR @TipoUsuario = 5) AND ( SELECT ISNULL( MostrarCatalogosOtrasSucursales,0 ) FROM CatUsuarios WHERE IdUsuario = @IdUsuario ) = 0
				BEGIN
					SET @Where = 'WHERE cu.IdSucursal = @Sucursal AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
				END
			END
		END
	END
	ELSE
	BEGIN
		IF @Rentadas = 1
		BEGIN
			IF @FiltroMantenimiento = 1
			BEGIN
				SET @Where = 'WHERE cu.Rentada <> 1 AND ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
			ELSE
			BEGIN
				SET @Where = 'WHERE cu.Rentada <> 1  AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
		END
		ELSE
		BEGIN
		IF @FiltroMantenimiento = 1
			BEGIN
				SET @Where = 'WHERE ceu.IdEstatuUnidad <> @ValorEstatusMantenimiento AND ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
			ELSE
			BEGIN
				SET @Where = 'WHERE ctu.Identificador IN(@Identificador1,@Identificador2,@Identificador3,@Identificador4,@Identificador5)'
			END
		END
	END
END
	
IF @FiltroBusqueda = 1
BEGIN 
	SET @Where = @Where + 'AND(cs.Sucursal LIKE @Busqueda OR ctu.TipoUnidad LIKE @Busqueda OR cu.Codigo LIKE @Busqueda OR cu.Descripcion LIKE @Busqueda OR co.NumeroOperador LIKE @Busqueda OR co.Nombre LIKE @Busqueda OR cu.Placas LIKE @Busqueda OR cu.PlacasVencimiento LIKE @Busqueda OR cu.PlacasExtranjeras LIKE @Busqueda OR cu.PlacasExtranjerasVencimiento LIKE @Busqueda OR cu.NumeroSeguro LIKE @Busqueda OR cu.VencimientoSeguro LIKE @Busqueda OR cu.IdentificadorSatelital LIKE @Busqueda )'
END 

IF @FiltroUnidadPropias = 1 
BEGIN
	SET @Where = @Where + ' AND cu.EsUnidadPermisionario = 0 '
END
--Filtro Buscar todo tipo de unidades
IF (@Identificador1 = 0)
BEGIN
	IF (@Identificador2 = 0)
	BEGIN
		SET @Identificador1  = 1
		SET @Identificador2  = 2
		SET @Identificador3  = 3
		SET @Identificador4  = 4 
		SET @Identificador5  = 5
	END
END

--ahora ejecutamos el query dinamico armado
SET @Parametros='@Activa INT, @FiltroMantenimiento INT,@Rentadas INT, @Sucursal INT, @FiltroSucursal INT,@OrdenOrientacion INT,@Identificador1 INT,@Identificador2 INT,@Identificador3 INT,@Identificador4 INT,@Identificador5 INT,  @Ordenamiento VARCHAR(max),
@Pagina INT, @Elemento INT,@Busqueda VARCHAR(MAX),@ValorEstatusMantenimiento INT,@IdUsuario INT';
--Filtro Buscar todo tipo de unidades
IF (@SoloPortacontenedoresYContenedores = 1)
BEGIN
	SET @FiltroPortacontenedoresYContenedores = ' AND ctu.TipoUnidad IN (''PORTACONTENEDOR'',''PLATAFORMA'') ' 
END

SET @Sql =@Sql + @Where +@FiltroPortacontenedoresYContenedores+' ),resultadofinal as
(
SELECT
ROW_NUMBER() OVER (ORDER BY  rownumber   ASC ) AS rownumber2,*
FROM Unidades)
,UnidadesPaginadas as (  
select  *  from resultadofinal A
WHERE
rownumber2 >= (CASE @Pagina   
WHEN 1 THEN 1 
ELSE (@Elemento*(@Pagina-1))+1   
END)AND rownumber2 <= (@Elemento*@Pagina)),ListadoPaginado as(select (SELECT MAX(rownumber2) FROM  resultadofinal) AS  TotalRows,*
from UnidadesPaginadas)
select * from ListadoPaginado
'

--SELECT @Sql AS ConsultaSQl
--SELECT @Activa 
--select @FiltroMantenimiento 
--SELECT @Rentadas
--SELECT @Sucursal
--SELECT @FiltroSucursal 
--SELECT @OrdenOrientacion
--SELECT @Identificador1
--SELECT @Identificador2
--SELECT @Identificador3
--SELECT @Identificador4
--SELECT @Identificador5
--SELECT @Ordenamiento
--SELECT @Pagina
--SELECT @Elemento
--SELECT @Busqueda
--SELECT @ValorEstatusMantenimiento
--SELECT @IdUsuario
--SELECT @TipoUsuario

DECLARE @TemporalUnidades TABLE
(	TotalRows INT,
rownumber2 INT,
rownumber INT,
IdUnidad INT,
TipoUnidad VARCHAR(max),
Codigo VARCHAR(max),
IdentificadorConvoy VARCHAR(max),
Descripcion VARCHAR(max),
NumeroOperador INT,
Nombre VARCHAR(max),
Placas VARCHAR(max),
PlacasVencimiento DATETIME,
PlacasExtranjeras VARCHAR(max),
PlacasExtranjerasVencimiento DATETIME,
Sucursal VARCHAR(max),
Activa INT,
NumeroSeguro VARCHAR(max),
VencimientoSeguro DATETIME,
IdentificadorSatelital VARCHAR(max),
VencimientoSeguro1 DATETIME,
Color VARCHAR(max),
IdEstatuUnidad INT,
NombreImagenUnidad VARCHAR(max),
Abreviacion VARCHAR(max),
ColorLetra VARCHAR(max)

)
INSERT INTO @TemporalUnidades exec sp_executesql @Sql, --Query dinamico
                @Parametros, --lista de parametros utilizado en el query dinamico
				@Activa , @FiltroMantenimiento ,@Rentadas, @Sucursal, @FiltroSucursal ,@OrdenOrientacion, @Identificador1, @Identificador2,@Identificador3, @Identificador4, @Identificador5,@Ordenamiento,@Pagina, @Elemento,@Busqueda,@ValorEstatusMantenimiento,@IdUsuario;


;WITH Ubicaciones AS( SELECT IdUnidad = Node.Data.value('(IdUnidad)[1]', 'INT')
, IdentificadorSatelital = Node.Data.value('(NoSerie)[1]', 'VARCHAR(MAX)')
, Pais = Node.Data.value('(Pais)[1]', 'VARCHAR(MAX)')
, Estado = Node.Data.value('(Estado)[1]', 'VARCHAR(MAX)')
, Ciudad = Node.Data.value('(Ciudad)[1]', 'VARCHAR(MAX)')
, Calle = Node.Data.value('(Calle)[1]', 'VARCHAR(MAX)')
, FechaHoraPaquete = Node.Data.value('(FechaHoraPaquete)[1]', 'VARCHAR(MAX)')
, TiempoEstimadoUltimoReporte = Node.Data.value('(TiempoEstimadoUltimoReporte)[1]', 'VARCHAR(MAX)')
, Latitud = Node.Data.value('(Latitud)[1]', 'NVARCHAR(MAX)')
, Longitud = Node.Data.value('(Longitud)[1]', 'NVARCHAR(MAX)')
, Evento = Node.Data.value('(Evento)[1]', 'VARCHAR(MAX)')
, OdometroGPS = Node.Data.value('(OdometroGPS)[1]', 'NVARCHAR(MAX)')
, Temperatura = Node.Data.value('(Temperatura)[1]', 'VARCHAR(MAX)')
, Posicion = Node.Data.value('(Posicion)[1]', 'VARCHAR(MAX)')
, Direccion = Node.Data.value('(Direccion)[1]', 'VARCHAR(MAX)')
, Velocidad = Node.Data.value('(Velocidad)[1]', 'VARCHAR(MAX)')
, CodigoEvento = Node.Data.value('(CodigoEvento)[1]', 'VARCHAR(MAX)')
, PorcentajeBateria = Node.Data.value('(PorcentajeBateria)[1]', 'VARCHAR(MAX)')
FROM    @Xml.nodes('/Ubicacion/ubicacion') Node(Data)),
UnidadesPaginadas as (SELECT * FROM @TemporalUnidades),
ListadoPaginado as(SELECT un.TotalRows,
un.rownumber,
un.IdUnidad, 
un.TipoUnidad,
un.Codigo as CodigoUnidad,
un.IdentificadorConvoy,
un.Descripcion,
un.NumeroOperador,
un.Nombre,un.Placas,
un.PlacasVencimiento,
un.PlacasExtranjeras,
un.PlacasExtranjerasVencimiento,
un.Sucursal,
un.Activa,
un.NumeroSeguro,
un.VencimientoSeguro,
un.VencimientoSeguro1,
un.Color,
un.IdEstatuUnidad,
un.NombreImagenUnidad,
un.Abreviacion,
un.ColorLetra,
ub.IdentificadorSatelital,
ub.Pais,
ub.Estado,
ub.Ciudad, 
ub.Calle,
ub. FechaHoraPaquete,
ub.TiempoEstimadoUltimoReporte,
ub.Latitud,
ub.Longitud, 
ub.Evento, 
ub.OdometroGPS, 
ub.Temperatura, 
ub.Posicion,
ub.PorcentajeBateria,
ub.Direccion,
ub.Velocidad,
ub.CodigoEvento
FROM UnidadesPaginadas AS un
LEFT JOIN Ubicaciones AS ub ON un.IdentificadorSatelital = ub.IdentificadorSatelital)

SELECT 
TotalRows,
rownumber,
IdUnidad, 
TipoUnidad,
CodigoUnidad,
IdentificadorConvoy,
Descripcion,
NumeroOperador,
Nombre,
Placas,
PlacasVencimiento,
PlacasExtranjeras,
PlacasExtranjerasVencimiento,
Sucursal,
Activa,
NumeroSeguro,
VencimientoSeguro,
VencimientoSeguro1,
Color,
IdEstatuUnidad,
NombreImagenUnidad,
Abreviacion,
ColorLetra,
IdentificadorSatelital,
Pais,
Estado,
Ciudad, 
Calle,
FechaHoraPaquete,
TiempoEstimadoUltimoReporte,
Latitud,
Longitud, 
Evento, 
OdometroGPS, 
Temperatura, 
Posicion,
PorcentajeBateria,
Direccion,
Velocidad,
CodigoEvento
FROM ListadoPaginado
go

