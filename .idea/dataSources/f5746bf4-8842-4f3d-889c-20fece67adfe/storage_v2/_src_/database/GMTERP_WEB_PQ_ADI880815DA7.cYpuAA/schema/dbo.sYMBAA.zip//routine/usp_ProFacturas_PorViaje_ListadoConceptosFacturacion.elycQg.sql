CREATE PROCEDURE [dbo].[usp_ProFacturas_PorViaje_ListadoConceptosFacturacion]
@IdUsuario int,
@bParametroMov bit,
@ImpuestosRetenidos int,
@ImpuestosNoObjetoIVA int
AS DECLARE @SQL nvarchar(max),
@Parametros nvarchar(max), 
@str VARCHAR(MAX) ,
@IdViaje NVARCHAR(255),
@pos INT
/*
CAMBIO:
	Se agregaron los porcentajes de los impuestos
VERSIÓN:
	
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-09-24
INVOCADA DESDE:
	Regostrar: 
		Facturacion por viaje
SOLICITUD: 
	SOLICITUD 002280

	Modificado por: Yarazeth Lemus
	Fecha de modificacion: 09/11/2020
	Versión 8.0.56.13
	Solicitud 003223
	se agrego el numero de identificacion para que lo traiga en la tabla

CAMBIO:
	Se cambio el query para que los conceptos de facturacion se agrupen desde sql y no desde portal.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2021-05-04
SOLICITUD: 
	SOLICITUD 002280

*/
--Se obtiene los id- de los viajes
SET @str= (SELECT Parametros FROM SisParametrosPagina WHERE Pagina = 'PAGE_ProFacturasPorViajeAM' AND IdUsuario = @IdUsuario)

--Se crea una tabla temporal donde se insertan los identificadores
CREATE TABLE #TempConceptosFacturacionFacturasPorViaje( IdViaje INT)

IF CHARINDEX(',', @str) > 0 
BEGIN

--ciclo para realizar un split e insertar los identificadores en la tabla temporal
	 WHILE CHARINDEX(',', @str) > 0
	 BEGIN
	  SELECT @pos  = CHARINDEX(',', @str)  
	  SELECT @IdViaje = SUBSTRING(@str, 1, @pos-1)
	 
	  INSERT INTO #TempConceptosFacturacionFacturasPorViaje
	  SELECT @IdViaje

	  SELECT @str = SUBSTRING(@str, @pos+1, LEN(@str)-@pos)
	 END
	  IF @str <> ''
	  BEGIN
		INSERT INTO #TempConceptosFacturacionFacturasPorViaje
		SELECT @str
	  END
END
 ELSE
 BEGIN
 INSERT INTO #TempConceptosFacturacionFacturasPorViaje
 SELECT @str
 END


SET @SQL =
'
	/*FACTURACON POR VIAJES CARGAR CONCEPTOS FACTURACION*/
/*FACTURACON POR VIAJES CARGAR CONCEPTOS FACTURACION*/
;WITH CTEViajesConceptosFacturacion AS (

	SELECT
			ViajesConceptosFacturacion.IdConceptoFacturacion
		,	ViajesConceptosFacturacion.Codigo
		,	ViajesConceptosFacturacion.ConceptoFacturacion
		,	ImporteOriginal = SUM(ViajesConceptosFacturacion.ImporteOriginal)
		,	Importe = SUM(ViajesConceptosFacturacion.Importe)
		,	ViajesConceptosFacturacion.UnidadMedida
		,	ViajesConceptosFacturacion.NoIdentificacion
		,	ViajesConceptosFacturacion.IncluirCalculoIngresosLiquidacion
		,	ViajesConceptosFacturacion.IncluirCalculoLiquidacionPorcentajeSobreImpFlete
		,	CantidadMovimientos = SUM(ViajesConceptosFacturacion.CantidadMovimientos)
		,	ViajesConceptosFacturacion.Observacion
		,	ViajesConceptosFacturacion.ClaveSATProducto
		,	ViajesConceptosFacturacion.ClaveSATUnidad
		,	ViajesConceptosFacturacion.TrasladaImpuesto
		,	ViajesConceptosFacturacion.IdImpuestoTraslado
		,	ViajesConceptosFacturacion.RetieneImpuesto
		,	ViajesConceptosFacturacion.IdImpuestoRetencion


	FROM(
		SELECT
			ViajesConceptosFacturacionRegistro.IdConceptoFacturacion
		,	ViajesConceptosFacturacionRegistro.Codigo
		,	ViajesConceptosFacturacionRegistro.ConceptoFacturacion
		,	ViajesConceptosFacturacionRegistro.ImporteOriginal
		,	ViajesConceptosFacturacionRegistro.Importe
		,	ViajesConceptosFacturacionRegistro.UnidadMedida
		,	ViajesConceptosFacturacionRegistro.NoIdentificacion
		,	ViajesConceptosFacturacionRegistro.IncluirCalculoIngresosLiquidacion
		,	ViajesConceptosFacturacionRegistro.IncluirCalculoLiquidacionPorcentajeSobreImpFlete
		,	CantidadMovimientos = 
			CASE /*gbAfectarLiqFacturaConCantidadViaje*/
			WHEN @Parametro = 1 AND ViajesConceptosFacturacionRegistro.Importe<>ViajesConceptosFacturacionRegistro.ImporteOriginal THEN
				ViajesConceptosFacturacionRegistro.CantidadMovimientos
			ELSE
				1
			END
		,	ViajesConceptosFacturacionRegistro.Observacion
		,	ViajesConceptosFacturacionRegistro.ClaveSATProducto
		,	ViajesConceptosFacturacionRegistro.ClaveSATUnidad
		,	ViajesConceptosFacturacionRegistro.TrasladaImpuesto
		,	ViajesConceptosFacturacionRegistro.IdImpuestoTraslado
		,	ViajesConceptosFacturacionRegistro.RetieneImpuesto
		,	ViajesConceptosFacturacionRegistro.IdImpuestoRetencion
		
		FROM (

			SELECT
		
				pvcf.IdConceptoFacturacion
			,ccf.Codigo
			,ccf.ConceptoFacturacion
			,ImporteOriginal = pvcf.Importe 
			,Importe = (case @Parametro  /*gbAfectarLiqFacturaConCantidadViaje*/
						when 1 then
							CASE isnull((SELECT 
								TOP 1
								pvcf2.IdConceptoFacturacion
								FROM ProViajesConceptosFacturacion pvcf2
								left join ( 
									SELECT 
									TOP 1 
									vc.IdConceptoFacturacion
									FROM
									ProViajesConceptosFacturacion vc 
									WHERE vc.IdViaje = pvcf.IdViaje 
								) as conceptos  ON pvcf2.IdConceptoFacturacion = conceptos.IdConceptoFacturacion 
								where
								conceptos.IdConceptoFacturacion = pvcf.IdConceptoFacturacion 
								),0)
								when 0 then
									pvcf.Importe 
								else
									pvcf.Importe * pv.CantidadMovimientos
								end
						else
							pvcf.Importe 
						end) 
	
			,pvcf.UnidadMedida
			,pvcf.TrasladaImpuesto
			,pvcf.RetieneImpuesto
			,ccf.NoIdentificacion
			,pvcf.IncluirCalculoIngresosLiquidacion
			,pvcf.IncluirCalculoLiquidacionPorcentajeSobreImpFlete
			,pv.CantidadMovimientos
			,pvcf.Observacion

			,ClaveSATProducto = ( CASE ISNULL(pvcf.ClaveSATProducto,'''')
			WHEN '''' THEN ccf.ClaveSATProducto
			ELSE pvcf.ClaveSATProducto
			END )

			,ClaveSATUnidad = (CASE ISNULL(pvcf.ClaveSATUnidad,'''')
			WHEN '''' THEN ccf.ClaveSATUnidad
			ELSE pvcf.ClaveSATUnidad
			END )


			,IdImpuestoTraslado = (
			CASE
			WHEN ISNULL(NuevoEsquemaConceptosImpuestosTrasladados.IdTrasladoNuevoEsquema,0) = 0 THEN /*VALIDA EL NUEVO ESQUEMA DE IMPUESTOS*/
				CASE 
				WHEN pv.ViajeConCP = 1 THEN /*SI ES CARTA PORTE*/
						CASE 
						WHEN pvcf.TrasladaImpuesto = 1 THEN
							/*Impuesto de la carta porte*/ 
							CPConceptosImpuestosTrasladados.IdTrasladadoCP
						ELSE 
							(SELECT TOP 1 IdImpuesto FROM CatImpuestos WHERE TipoCalculo IN (4) /*NO OBJETO DE IVA*/) 
						END
				ELSE /*SI ES VIAJE*/
					CASE WHEN pvcf.TrasladaImpuesto = 1 THEN
						CASE WHEN ISNULL(RutaConceptosImpuestosTrasladados.IdTrasladoRuta,0) <> 0 THEN --pvcf.IdConceptoFacturacion IN( SELECT TOP 1 IdConceptoFacturacion FROM CatRutasConceptosFacturacion WHERE IdRuta = pv.IdRuta ) THEN
							/*Impuesto de la ruta*/
							RutaConceptosImpuestosTrasladados.IdTrasladoRuta
						ELSE
							/*Impuesto predeterminado del concepto de facturacion*/
							PredeterminadoConceptosImpuestosTrasladados.IdTrasladoPredeterminado						
						END 
					ELSE 
						(SELECT TOP 1 IdImpuesto FROM CatImpuestos WHERE TipoCalculo IN (4) /*NO OBJETO DE IVA*/) 
					END
				END
			ELSE
				NuevoEsquemaConceptosImpuestosTrasladados.IdTrasladoNuevoEsquema
			END)
		

			,IdImpuestoRetencion = ( 
			CASE
			WHEN ISNULL(NuevoEsquemaConceptosImpuestosRetenidos.IdRetencionNuevoEsquema,0) = 0 THEN /*VALIDA EL NUEVO ESQUEMA DE IMPUESTOS*/
				CASE 
				WHEN pv.ViajeConCP = 1 THEN /*SI ES CARTA PORTE*/
						CASE 
						WHEN pvcf.RetieneImpuesto = 1 THEN
							/*Impuesto de la carta porte*/
							CPConceptosImpuestosRetenidos.IdRetencionCP
						ELSE 
							(SELECT TOP 1 IdImpuesto FROM CatImpuestos WHERE TipoCalculo IN (2) AND Porcentaje = 0 AND DefinidoPorSistema = 1) 
						END
				ELSE /*SI ES VIAJE*/
					CASE WHEN pvcf.RetieneImpuesto = 1 THEN
						CASE WHEN ISNULL(RutaConceptosImpuestosRetenidos.IdRetencionRuta,0) <> 0 THEN --pvcf.IdConceptoFacturacion IN( SELECT TOP 1 IdConceptoFacturacion FROM CatRutasConceptosFacturacion WHERE IdRuta = pv.IdRuta ) THEN
							/*Impuesto de la ruta*/
							RutaConceptosImpuestosRetenidos.IdRetencionRuta
						ELSE
							/*Impuesto predeterminado del concepto de facturacion*/
							PredeterminadoConceptosImpuestosRetenidos.IdRetencionPredeterminado
						END 
					ELSE 
						(SELECT TOP 1 IdImpuesto FROM CatImpuestos WHERE TipoCalculo IN (2) AND Porcentaje = 0 AND DefinidoPorSistema = 1) 
					END
				END
			ELSE
				NuevoEsquemaConceptosImpuestosRetenidos.IdRetencionNuevoEsquema
			END)

			FROM 
			ProViajes as pv
			LEFT JOIN ProViajesCartasPorte as pvcp ON pv.IdViaje = pvcp.IdViaje
			INNER JOIN ProViajesConceptosFacturacion AS pvcf ON pv.IdViaje = pvcf.IdViaje
			INNER JOIN CatConceptosFacturacion AS ccf ON pvcf.IdConceptoFacturacion = ccf.IdConceptoFacturacion
			/*1.	Identificar si el VIAJE/CP entro al nuevo esquema de impuestos*/
			/*Impuestos conceptos de facturacion nuevo esquema de impuestos*/
			LEFT JOIN (
				SELECT
					pvcfi.IdViajeConceptoFacturacion
				,IdTrasladoNuevoEsquema = pvcfi.IdImpuesto
				FROM
				ProViajesConceptosFacturacionImpuestos pvcfi
				INNER JOIN CatImpuestos ci ON pvcfi.IdImpuesto = ci.IdImpuesto
				WHERE ci.TipoCalculo IN (1,3,4) /*TRASLADA, EXCENTO, NO OBJETO DE IVA*/
			) NuevoEsquemaConceptosImpuestosTrasladados ON 
				pvcf.IdViajeConceptoFacturacion = NuevoEsquemaConceptosImpuestosTrasladados.IdViajeConceptoFacturacion
			AND pvcf.TrasladaImpuesto = 1

			LEFT JOIN (
				SELECT
					pvcfi.IdViajeConceptoFacturacionImpuesto
				,pvcfi.IdViajeConceptoFacturacion
				,IdRetencionNuevoEsquema = pvcfi.IdImpuesto
				FROM
				ProViajesConceptosFacturacionImpuestos pvcfi
				INNER JOIN CatImpuestos ci ON pvcfi.IdImpuesto = ci.IdImpuesto
				WHERE ci.TipoCalculo IN (2) /*RETENCION*/
			) NuevoEsquemaConceptosImpuestosRetenidos ON 
				pvcf.IdViajeConceptoFacturacion = NuevoEsquemaConceptosImpuestosRetenidos.IdViajeConceptoFacturacion
			AND pvcf.RetieneImpuesto = 1

			/*2.	SIno entro al nuevo esquema de impuestos, identificar si es una carta porte*/
			/*Impuestos conceptos de facturacion de la carta porte*/
			LEFT JOIN (
					SELECT
					IdTrasladadoCP = ci.IdImpuesto 
				,pvcpi.IdViajeCartaPorte
				FROM ProViajesCartasPorteImpuestos AS pvcpi
				INNER JOIN CatImpuestos AS ci ON ci.IdImpuesto = pvcpi.IdImpuesto
				WHERE 
				ci.TipoCalculo IN(1,3,4) /*Traslada,Exento , no objeto de iva*/
			) CPConceptosImpuestosTrasladados ON 
				pvcp.IdViajeCartaPorte = CPConceptosImpuestosTrasladados.IdViajeCartaPorte 
			AND NuevoEsquemaConceptosImpuestosTrasladados.IdTrasladoNuevoEsquema IS NULL
			AND pvcf.TrasladaImpuesto = 1

			LEFT JOIN (
					SELECT
					IdRetencionCP = ci.IdImpuesto 
				,pvcpi.IdViajeCartaPorte
				FROM ProViajesCartasPorteImpuestos AS pvcpi
				INNER JOIN CatImpuestos AS ci ON ci.IdImpuesto = pvcpi.IdImpuesto
				WHERE 
				ci.TipoCalculo IN(2) /*Retencion*/
			) CPConceptosImpuestosRetenidos ON 
				pvcp.IdViajeCartaPorte = CPConceptosImpuestosRetenidos.IdViajeCartaPorte 
			AND NuevoEsquemaConceptosImpuestosRetenidos.IdRetencionNuevoEsquema IS NULL
			AND pvcf.RetieneImpuesto = 1

			/*3.	Sino es una carta porte, tomar el impuesto del concepto de facturacion definido en la ruta 
					y que sea el mismo concepto de facturacion del viaje*/
			/*Impuestos conceptos de facturacion de la configuracion de la ruta*/
			LEFT JOIN (
				SELECT 
					IdTrasladoRuta = crcfi.IdImpuesto
				,crcf.IdRuta
				,crcf.IdConceptoFacturacion
				FROM CatRutasConceptosFacturacion AS crcf
				INNER JOIN CatRutasConceptosFacturacionImpuestos AS crcfi ON crcf.IdRutaConceptoFacturacion = crcfi.IdRutaConceptoFacturacion
				INNER JOIN CatImpuestos AS ci ON crcfi.IdImpuesto = ci.IdImpuesto  
				WHERE 
				ci.TipoCalculo IN(1,3,4)  /*TRASLADA, EXCENTO, NO OBJETO DE IVA*/
			) RutaConceptosImpuestosTrasladados ON 
				pv.IdRuta = RutaConceptosImpuestosTrasladados.IdRuta 
			AND pvcf.IdConceptoFacturacion = RutaConceptosImpuestosTrasladados.IdConceptoFacturacion
			AND NuevoEsquemaConceptosImpuestosTrasladados.IdTrasladoNuevoEsquema IS NULL
			AND CPConceptosImpuestosTrasladados.IdTrasladadoCP IS NULL
			AND pvcf.TrasladaImpuesto = 1

			LEFT JOIN (
				SELECT 
					IdRetencionRuta = crcfi.IdImpuesto
				,crcf.IdRuta
				,crcf.IdConceptoFacturacion
				FROM CatRutasConceptosFacturacion AS crcf
				INNER JOIN CatRutasConceptosFacturacionImpuestos AS crcfi ON crcf.IdRutaConceptoFacturacion = crcfi.IdRutaConceptoFacturacion
				INNER JOIN CatImpuestos AS ci ON crcfi.IdImpuesto = ci.IdImpuesto  
				WHERE 
				ci.TipoCalculo IN(2)  /*RETENCION*/
			) RutaConceptosImpuestosRetenidos  ON 
				pv.IdRuta = RutaConceptosImpuestosRetenidos.IdRuta 
			AND pvcf.IdConceptoFacturacion = RutaConceptosImpuestosRetenidos.IdConceptoFacturacion
			AND NuevoEsquemaConceptosImpuestosRetenidos.IdRetencionNuevoEsquema IS NULL
			AND CPConceptosImpuestosRetenidos.IdRetencionCP IS NULL
			AND pvcf.RetieneImpuesto = 1

			/*4.	SI la ruta no tiene un impuesto para un concepto de facturacion definido, 
					tomar el impuesto predeterminado del concepto de facturacion del catalogo*/
			/*Impuesto predeterminado del concepto de facturacion*/
			LEFT JOIN ( 
				SELECT 
						IdTrasladoPredeterminado = ccfi.IdImpuesto 
					,ccfi.IdConceptoFacturacion
				FROM
				CatConceptosFacturacionImpuestos AS ccfi 
				INNER JOIN CatImpuestos AS ci ON ci.IdImpuesto = ccfi.IdImpuesto
				WHERE 
				ci.TipoCalculo IN(1,3,4) /*TRASLADA, EXCENTO, NO OBJETO DE IVA*/
				AND ccfi.Predeterminado = 1 AND ccfi.Activo = 1 
			) PredeterminadoConceptosImpuestosTrasladados ON
					pvcf.IdConceptoFacturacion = PredeterminadoConceptosImpuestosTrasladados.IdConceptoFacturacion 
			AND NuevoEsquemaConceptosImpuestosTrasladados.IdTrasladoNuevoEsquema IS NULL
			AND CPConceptosImpuestosTrasladados.IdTrasladadoCP IS NULL
			AND	RutaConceptosImpuestosTrasladados.IdTrasladoRuta IS NULL
			AND pvcf.TrasladaImpuesto = 1

			LEFT JOIN ( 
				SELECT 
						IdRetencionPredeterminado = ccfi.IdImpuesto 
					,ccfi.IdConceptoFacturacion
				FROM
				CatConceptosFacturacionImpuestos AS ccfi 
				INNER JOIN CatImpuestos AS ci ON ci.IdImpuesto = ccfi.IdImpuesto
				WHERE 
				ci.TipoCalculo IN(2) /*retencion*/
				AND ccfi.Predeterminado = 1 AND ccfi.Activo = 1 
			) PredeterminadoConceptosImpuestosRetenidos ON
					pvcf.IdConceptoFacturacion = PredeterminadoConceptosImpuestosRetenidos.IdConceptoFacturacion 
			AND NuevoEsquemaConceptosImpuestosRetenidos.IdRetencionNuevoEsquema IS NULL
			AND CPConceptosImpuestosRetenidos.IdRetencionCP IS NULL
			AND	RutaConceptosImpuestosRetenidos.IdRetencionRuta IS NULL
			AND pvcf.RetieneImpuesto = 1

			WHERE
			pvcf.IdViaje in ( SELECT IdViaje FROM #TempConceptosFacturacionFacturasPorViaje )

		) ViajesConceptosFacturacionRegistro
	
	) ViajesConceptosFacturacion
	GROUP BY 
		ViajesConceptosFacturacion.IdConceptoFacturacion
	,	ViajesConceptosFacturacion.Codigo
	,	ViajesConceptosFacturacion.ConceptoFacturacion
	,	ViajesConceptosFacturacion.UnidadMedida
	,	ViajesConceptosFacturacion.TrasladaImpuesto
	,	ViajesConceptosFacturacion.RetieneImpuesto
	,	ViajesConceptosFacturacion.NoIdentificacion
	,	ViajesConceptosFacturacion.IncluirCalculoIngresosLiquidacion
	,	ViajesConceptosFacturacion.IncluirCalculoLiquidacionPorcentajeSobreImpFlete
	--,	ViajesConceptosFacturacion.CantidadMovimientos
	,	ViajesConceptosFacturacion.Observacion
	,	ViajesConceptosFacturacion.ClaveSATProducto
	,	ViajesConceptosFacturacion.ClaveSATUnidad
	,	ViajesConceptosFacturacion.IdImpuestoTraslado
	,	ViajesConceptosFacturacion.IdImpuestoRetencion
)
,CteImpuestos as (
	SELECT
	IdImpuesto
	,Impuesto
	,Porcentaje
	FROM 
	CatImpuestos
)


SELECT
	cte_vcf.IdConceptoFacturacion
,	cte_vcf.Codigo
,	cte_vcf.ConceptoFacturacion
,	cte_vcf.ImporteOriginal 
,	cte_vcf.Importe  
,	cte_vcf.UnidadMedida
,	cte_vcf.NoIdentificacion
,	cte_vcf.IncluirCalculoIngresosLiquidacion
,	cte_vcf.IncluirCalculoLiquidacionPorcentajeSobreImpFlete
,	cte_vcf.CantidadMovimientos
,	cte_vcf.Observacion
,	cte_vcf.ClaveSATProducto
,	cte_vcf.ClaveSATUnidad
,	cte_vcf.TrasladaImpuesto
,	cte_vcf.IdImpuestoTraslado
,	cte_vcf.RetieneImpuesto
,	cte_vcf.IdImpuestoRetencion
,	ImpuestoTraslado = Trasladado.Impuesto
,	ImpuestoRetencion = Retencion.Impuesto
,	PorcentajeTraslado = Trasladado.Porcentaje
,	PorcentajeRetencion = Retencion.Porcentaje
FROM 
CTEViajesConceptosFacturacion cte_vcf
LEFT JOIN CteImpuestos Trasladado ON cte_vcf.IdImpuestoTraslado = Trasladado.IdImpuesto
LEFT JOIN CteImpuestos Retencion ON cte_vcf.IdImpuestoRetencion = Retencion.IdImpuesto

ORDER BY cte_vcf.Codigo
'

 SET @Parametros = N'@Parametro bit';
 EXEC sp_executesql @SQL,@Parametros,@Parametro = @bParametroMov


--si existe la tabla temporal se elimina
IF OBJECT_ID('#TempConceptosFacturacionFacturasPorViaje') IS NOT NULL
BEGIN
DROP TABLE #TempConceptosFacturacionFacturasPorViaje
END
go

