CREATE PROCEDURE [dbo].[usp_CatCuentasContablesModificar]
	@IdCuentaContable int,
	@Codigo varchar(25),
	@Nombre varchar(150), 
	@Activa bit,	
	@ModificadoPor int, 
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@IdCuentaContableSAT int,
	@CuentaMayor tinyint,
	@IdCuentaContablePadre int,
	@TipoCuenta tinyint,
	@IdRubroNIF int,
	@Nivel int,
	@IdMoneda int	
AS
/*
MODIFICADO:
	Se agregaro un exec usp_CatCuentasContablesSaldosModificarNaturaleza
	para acutalizar los asientos contables del catalogo CatCuentasContablesSaldos cuando se cambia la naturaleza de la cuenta contable.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-30
SOLICITUD: 
	SOLICITUD 000266


MODIFICADO:
	Se agrego un alidacion para identificar si el IdMoneda tiene un valor, esto para que no muestre error de fk.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-06-18
SOLICITUD: 
	SOLICITUD 002197
*/
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdCuentaContable = 0
		RAISERROR(N'El identificador de la cuenta contable es un campo requerido',
			16,
			1
			)

	IF NOT EXISTS(SELECT IdCuentaContable FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContable)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)	

	IF (SELECT ModificadoEl FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContable) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta cuenta contable fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)								

	IF LTRIM(RTRIM(@Codigo)) = ''
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Codigo FROM CatCuentasContables WHERE Codigo = @Codigo AND IdCuentaContable != @IdCuentaContable)
		RAISERROR(N'El código de la cuenta contable ya está registrado en el catálogo',
			16,
			1
			)

	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El nombre de la cuenta contable es un campo requerido',
			16,
			1
			)

	--IF EXISTS(SELECT * FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContable AND CatalogoLigado IS NOT NULL)
	--	RAISERROR(N'La cuenta contable no se puede modificar porque está ligada a un catálogo del sistema',
	--		16,
	--		1
	--		)	

	-- VALIDA QUE LA CUENTA NO TENGA HIJOS
	

	IF ISNULL(@CuentaMayor,0) < 1 OR ISNULL(@CuentaMayor,0) > 4
		RAISERROR(N'El campo cuenta de mayor debe ser 1)Mayor o 2)Afectable o 3)Título o 4)Subtítulo',
			16,
			1
			)	

	IF ISNULL(@TipoCuenta,0) < 1 OR ISNULL(@TipoCuenta,0) > 10
		RAISERROR(N'El campo tipo de cuenta debe ser 1-Activo Deudora o 2-Activo Acreedora o 3-Pasivo Deudora o 4-Pasivo Acreedora o 5-Capital Deudora o 6-Capital Acreedora o 7-Resultado Deudora o 8-Resultado Acreedora o 9-Orden Deudora o 10-Orden Acreedora',
			16,
			1
			)	
	
	IF @CuentaMayor IN(1,2,4) AND @IdCuentaContablePadre = 0
		RAISERROR(N'El campo subcuenta de es un campo requerido',
			16,
			1
			)
	
	IF @IdCuentaContable = @IdCuentaContablePadre
		RAISERROR(N'La Cuenta Contable no puede ser subcuenta de ella misma',
			16,
			1
			)
				
	IF @IdCuentaContableSAT = 0
		SET @IdCuentaContableSAT = NULL	
							
	IF @CuentaMayor = 3
		SET @IdCuentaContablePadre = NULL		

	IF @IdRubroNIF = 0
		SET @IdRubroNIF = NULL	

	IF @Nivel = 0
		SET @Nivel = NULL	
	/*Se guarda el tipo de cuenta anterior para validar si es necesario ajustar los saldos de la cuenta contable en CatCuentasContblesSaldo*/	
	DECLARE @TipoCuentaAnterior INT = (SELECT TipoCuenta FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContable)				
	UPDATE CatCuentasContables SET
		Codigo = @Codigo,
		Nombre = @Nombre,
		Activa = @Activa,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		IdCuentaContableSAT = @IdCuentaContableSAT,
		CuentaMayor = @CuentaMayor,
		IdCuentaContablePadre =	@IdCuentaContablePadre,
		TipoCuenta = @TipoCuenta
		
	WHERE IdCuentaContable = @IdCuentaContable

	IF ISNULL(@IdMoneda,0) <> 0
	BEGIN
		UPDATE
		CatCuentasContables
		SET
		IdMoneda  = @IdMoneda
		WHERE IdCuentaContable = @IdCuentaContable
	END
	--- Actualiza cuentas de mayor y hereda el rubro los hijos de tipo cta mayor
		UPDATE CatCuentasContables
		SET    IdRubroNIF = @IdRubroNIF,
			   Nivel =	@Nivel	 
		FROM     CatCuentasContables LEFT OUTER JOIN
						  CatCuentasContables AS ccp ON CatCuentasContables.IdCuentaContablePadre = ccp.IdCuentaContable LEFT OUTER JOIN
						  CatCuentasContables AS cca ON ccp.IdCuentaContablePadre = cca.IdCuentaContable
		WHERE  (CatCuentasContables.IdCuentaContable = @IdCuentaContable) AND (CatCuentasContables.CuentaMayor = 1) 
			OR  (CatCuentasContables.CuentaMayor = 1) AND (ccp.IdCuentaContable = @IdCuentaContable)

	-- Fin de actualización

	
	--------------Afectar la moneda en las Cuentas Hijas afectables de mi cuenta de mayor---------------------
	If @CuentaMayor = 1 --MAYOR
	BEGIN
		Update CatCuentasContables SET
				IdMoneda = @IdMoneda
		Where IdCuentaContablePadre = @IdCuentaContable And CuentaMayor = 2--Afectable		
	END 
	----------------------------------
	--------------Heredar La Moneda de La cuenta Padre---------------------
	If @CuentaMayor = 2 --Afectable
	BEGIN
		Set @IdMoneda = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContablePadre)
		Update CatCuentasContables SET
			   IdMoneda = @IdMoneda
		Where IdCuentaContable = @IdCuentaContable
	END 
	-------------------------------------------------------------------
	/*Se valida si es necesario ajustar los saldos de la cuenta contable en CatCuentasContblesSaldo*/
	IF (@TipoCuentaAnterior % 2) <> (@TipoCuenta % 2)
	BEGIN
		EXEC usp_CatCuentasContablesSaldosModificarNaturaleza @IdPeticion,@IdCuentaContable
	END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

