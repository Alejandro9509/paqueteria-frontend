/* *************************************************************************************************
Script de agregar naviera para el catálogo de Navieras

Parámetros: 
	@Codigo int,				(entrada, entero). Código de Naviera
	@Descripcion varchar(50),	(entrada, string). Descripción de Naviera
	@Activo bit,				(entrada, bit). Estado de Naviera (Activo/Inactivo)
	@CreadoEl datetime,			(entrada, fecha hora). Fecha en la que se realiza la creación
	@CreadoPor int,				(entrada, entero). Quien solicita la creación
	@IdPeticion varchar(100)	(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento crea una nueva Terminal para el Catálogo de Navieras del módulo Operación Portuaria.

Implementada por: David Rivera Navarro
Fecha de implementación: 19/07/2019
Versión: 8.0.44.48

Modificada por:   David Rivera Navarro
Fecha de mofidicación: 25/07/2019
Versión:  8.0.44.54

Invocada desde: PAGE_CatNavierasAM (Solicitud 12874)

Valor de retorno: NA.

Ejemplo de Uso: NA.

***************************************************************************************************** */


CREATE PROCEDURE [dbo].[usp_CatNavierasAgregar]
	@Codigo int,
	@Descripcion varchar(50),
	@Activo bit,
	@CreadoEl datetime,
	@CreadoPor int,
	@IdPeticion varchar(100)
AS

DECLARE
-- Id de Naviera que se obtendrá después Agregar la nueva naviera para asociarla con el control de tiempos
	@IdNaviera int

BEGIN TRY
	BEGIN TRANSACTION

	-- Envía un mensaje de error si la el Código de Naviera no contiene información
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de naviera es un campo requerido',
			16,
			1
			)

	-- Envía un mensaje de error si el variable Codigo de naviera ya se encuentra registrado
	IF EXISTS(SELECT Codigo FROM CatNavieras WHERE Codigo = @Codigo)
		RAISERROR(N'El código de naviera ya existe',
			16,
			1
			)
	
	-- Envía un mensaje de error si la variable Descripcion no contiene información
	IF LTRIM(RTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)

	-- Si no tiene valor se asignan valores por defecto
	IF @CreadoEl IS NULL
		SET @CreadoEl = SYSDATETIME()

	-- Si no tiene valor se asignan valores por defecto
	IF @Activo IS NULL
		SET @Activo = 1
			
	-- Se agrega una nueva Naviera a la Tabla
	INSERT INTO CatNavieras(Codigo, Descripcion, Activo, CreadoEl, CreadoPor)
	VALUES(@Codigo,@Descripcion, @Activo, @CreadoEl, @CreadoPor)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

