CREATE TRIGGER [dbo].[trg_CatConceptosCobranza]
   ON  [dbo].[CatConceptosCobranza]
   AFTER UPDATE
AS 
BEGIN
	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
		RAISERROR(N'Este concepto no se puede modificar porque es dado de alta por sistema.',
			16,
			1
			)
	IF UPDATE(ConceptoCobranza) Or UPDATE(TipoConcepto) OR UPDATE(RequiereCtaBancaria)
	BEGIN
		IF EXISTS(Select Top 1 IdCobranza from ProCobranza Where IdConceptoCobranza = (SELECT IdConceptoCobranza FROM deleted))
		RAISERROR(N'El concepto no se puede modificar porque ya cuenta con movimientos de cobranza',
			16,
			1
			)
	END	
END
go

