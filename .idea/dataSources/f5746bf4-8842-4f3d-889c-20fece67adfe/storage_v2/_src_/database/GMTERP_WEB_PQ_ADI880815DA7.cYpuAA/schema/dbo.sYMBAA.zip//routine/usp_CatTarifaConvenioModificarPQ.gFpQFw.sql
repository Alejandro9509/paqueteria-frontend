



CREATE PROCEDURE [dbo].[usp_CatTarifaConvenioModificarPQ](
	@IdTarifaConvenio int,
	@IdTarifa int,
	@IdConvenio int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdTarifaConvenio, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador de la Tarifa de convenio es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdTarifa, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador de la Tarifa es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdConvenio, '') = '' begin
			RAISERROR(N'*INICIO*El identificador de convenio es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
		update CatTarifaConvenioPQ set 
		IdTarifa = @IdTarifa,
		IdConvenio = @IdConvenio
		where IdTarifaConvenio = @IdTarifaConvenio;
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

