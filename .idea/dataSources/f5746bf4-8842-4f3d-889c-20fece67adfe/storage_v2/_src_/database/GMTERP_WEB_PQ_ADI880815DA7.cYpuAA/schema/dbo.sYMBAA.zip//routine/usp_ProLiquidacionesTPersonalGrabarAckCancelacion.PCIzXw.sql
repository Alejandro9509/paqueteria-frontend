
CREATE PROCEDURE [dbo].[usp_ProLiquidacionesTPersonalGrabarAckCancelacion]
	@IdLiquidacion int,
	@AckCancelacion ntext,
	@FechaCancelacionSAT datetime,
	@EstatusUUID varchar(50),	
	@CanceladoPor int,
	@CanceladoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@SATComprobanteEsCancelable varchar(30) = NULL,
	@SATComprobanteEstado varchar(20) = NULL,
	@SATComprobanteEstatusCancelacion varchar(30) = NULL,
	@SATComprobanteFechaHoraEnvioSolicitud datetime = NULL
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF EXISTS(SELECT IdLiquidacionTPersonal FROM ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal = @IdLiquidacion AND FechaTimbrado IS NULL)
		RAISERROR(N'No se puede cancelar esta Liquidación porque no está timbrada en el SAT',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal = @IdLiquidacion) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta liquidación fueron modificados por otro usuario. Entre en modo de consulta para que revise.',
			16,
			1
			)				
	
	IF @SATComprobanteEstado = 'Vigente'
	BEGIN
		IF NOT EXISTS (SELECT IdProcesoLigado FROM ProDocumentosEnProcesoCancelacionSAT Where IdProcesoLigado = @IdLiquidacion AND ProcesoLigado = 'ProLiquidacionesTPersonal' AND EnProceso = 1)
		INSERT INTO ProDocumentosEnProcesoCancelacionSAT(IdProcesoLigado,ProcesoLigado,EnProceso,SATCanceladoPor) VALUES (@IdLiquidacion,'ProLiquidacionesTPersonal',1,@CanceladoPor)
	END

	IF @SATComprobanteEstado = 'Cancelado'
	BEGIN
		UPDATE ProDocumentosEnProcesoCancelacionSAT SET EnProceso = 0 Where IdProcesoLigado = @IdLiquidacion AND ProcesoLigado = 'ProLiquidacionesTPersonal'

		INSERT INTO ProLiquidacionesTPersonalCancelacionCFDI(AckCancelacion,CadenaOriginal,CadenaOriginalTimbrado,CanceladoEl,CanceladoPor,EstatusUUID,
		FechaCancelacionSAT,FechaTimbrado,FolioFiscalUUID,IdCertificado,IdLiquidacion,MotivoCancelacion,NoSerieCertificadoSAT,SelloDigital,SelloSAT,
		XMLArchivo,SATComprobanteEsCancelable,SATComprobanteEstado,SATComprobanteEstatusCancelacion,SATComprobanteFechaHoraEnvioSolicitud)
		SELECT @AckCancelacion,CadenaOriginal,CadenaOriginalTimbrado,@CanceladoEl,@CanceladoPor,@EstatusUUID,
		@FechaCancelacionSAT,FechaTimbrado,FolioFiscalUUID,IdCertificado,@IdLiquidacion,'',NoSerieCertificadoSAT,SelloDigital,SelloSAT,
		XMLArchivo,@SATComprobanteEsCancelable,@SATComprobanteEstado,@SATComprobanteEstatusCancelacion,@SATComprobanteFechaHoraEnvioSolicitud 
		FROM ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal = @IdLiquidacion

		UPDATE ProLiquidacionesTPersonal
		SET FolioFiscalUUID = NULL,
			FechaTimbrado = NULL,
			NoSerieCertificadoSAT = NULL,
			SelloSAT = NULL,
			CadenaOriginalTimbrado = NULL,
			XMLArchivo = NULL,
			TimbrePruebas = NULL,
			CadenaOriginal = NULL,
			SelloDigital = NULL,
			ModificadoEl = @CanceladoEl,
			ModificadoPor = @CanceladoPor
		WHERE IdLiquidacionTPersonal = @IdLiquidacion
	END


		
			
	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

