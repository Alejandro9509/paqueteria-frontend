CREATE PROCEDURE [dbo].[usp_ProLiquidacionesPropietariosGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProLiquidacionesPropietarios
go

