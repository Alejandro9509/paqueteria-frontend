CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosSaldoBancariosSituacionEmpresa]
@Fecha Datetime
AS  
WITH CTESaldoBancario
AS
(
---- Depositos
	SELECT  CatTiposMovimientosBancarios.TipoMovimiento, 
			ProMovimientosBancarios.IdCuentaBancaria, 
			0 As ImporteRetenido,
			0 As ImporteNoCobrado,
			sum(ProMovimientosBancarios.Importe) as ImporteDeposito,
			0 as ImporteRetiro
	FROM       ProMovimientosBancarios INNER JOIN
			   CatTiposMovimientosBancarios ON ProMovimientosBancarios.IdTipoMovimientoBancario = CatTiposMovimientosBancarios.IdTipoMovimientoBancario
	WHERE  CatTiposMovimientosBancarios.TipoMovimiento = 1      
	    And ProMovimientosBancarios.CanceladoEl is null
		and  cast(ProMovimientosBancarios.Fecha as  date) <=@Fecha 
	GROUP BY CatTiposMovimientosBancarios.TipoMovimiento,ProMovimientosBancarios.IdCuentaBancaria    
	UNION ALL
---- Retiros	
	SELECT  CatTiposMovimientosBancarios.TipoMovimiento, 
			ProMovimientosBancarios.IdCuentaBancaria, 
			0 As ImporteRetenido,
			0 As ImporteNoCobrado,
			0 as ImporteDeposito,
			sum(ProMovimientosBancarios.Importe) as ImporteRetiro
	FROM       ProMovimientosBancarios INNER JOIN
			   CatTiposMovimientosBancarios ON ProMovimientosBancarios.IdTipoMovimientoBancario = CatTiposMovimientosBancarios.IdTipoMovimientoBancario
	WHERE  CatTiposMovimientosBancarios.TipoMovimiento = 2     
	And ProMovimientosBancarios.CanceladoEl is null                
	and  cast(ProMovimientosBancarios.Fecha as  date) <=@Fecha 
	GROUP BY CatTiposMovimientosBancarios.TipoMovimiento,ProMovimientosBancarios.IdCuentaBancaria    
UNION ALL
---- 1 RETENIDO
SELECT  CatTiposMovimientosBancarios.TipoMovimiento, 
		ProMovimientosBancarios.IdCuentaBancaria, 
		sum(ProMovimientosBancarios.Importe)As ImporteRetenido,
		0 As ImporteNoCobrado,
		0 AS ImporteDeposito, 
		0 as ImporteRetiro
FROM         ProMovimientosBancarios INNER JOIN
                      CatTiposMovimientosBancarios ON ProMovimientosBancarios.IdTipoMovimientoBancario = CatTiposMovimientosBancarios.IdTipoMovimientoBancario INNER JOIN
                      ProCheques ON ProMovimientosBancarios.IdCheque = ProCheques.IdCheque INNER JOIN
                      CatEstatusCheques ON ProCheques.IdEstatuCheque = CatEstatusCheques.IdEstatuCheque
WHERE     (CatTiposMovimientosBancarios.TipoMovimiento = 2)and CatEstatusCheques.Codigo = 1 
And ProMovimientosBancarios.CanceladoEl is null
and  cast(ProMovimientosBancarios.Fecha as  date) <=@Fecha 
GROUP BY CatTiposMovimientosBancarios.TipoMovimiento, ProMovimientosBancarios.IdCuentaBancaria, ProMovimientosBancarios.IdCheque, CatEstatusCheques.Estatus, 
                      CatEstatusCheques.Codigo
UNION ALL
---- 2 ENTREGADO NO COBRADO
SELECT  CatTiposMovimientosBancarios.TipoMovimiento, 
		ProMovimientosBancarios.IdCuentaBancaria, 
		0 As ImporteRetenido,
		sum(ProMovimientosBancarios.Importe)As ImporteNoCobrado,
		0 AS ImporteDeposito, 
		0 as ImporteRetiro
FROM         ProMovimientosBancarios INNER JOIN
                      CatTiposMovimientosBancarios ON ProMovimientosBancarios.IdTipoMovimientoBancario = CatTiposMovimientosBancarios.IdTipoMovimientoBancario INNER JOIN
                      ProCheques ON ProMovimientosBancarios.IdCheque = ProCheques.IdCheque INNER JOIN
                      CatEstatusCheques ON ProCheques.IdEstatuCheque = CatEstatusCheques.IdEstatuCheque
WHERE     (CatTiposMovimientosBancarios.TipoMovimiento = 2)and CatEstatusCheques.Codigo = 2 
And ProMovimientosBancarios.CanceladoEl is null
and  cast(ProMovimientosBancarios.Fecha as  date) <=@Fecha 
GROUP BY CatTiposMovimientosBancarios.TipoMovimiento, ProMovimientosBancarios.IdCuentaBancaria, ProMovimientosBancarios.IdCheque, CatEstatusCheques.Estatus, 
                      CatEstatusCheques.Codigo                      	
)

SELECT CTESaldoBancario.IdCuentaBancaria,
CatCuentasBancarias.CuentaBancaria, 
CatCuentasBancarias.NumeroCuenta,
(Sum(ImporteDeposito) - Sum(ImporteRetiro)) as SaldoProyectado,
 Sum(ImporteRetenido) As ImporteRetenido,
 Sum(ImporteNoCobrado)As ImporteNoCobrado ,
CatCuentasBancarias.IdMoneda
FROM CTESaldoBancario INNER JOIN CatCuentasBancarias ON CTESaldoBancario.IdCuentaBancaria =CatCuentasBancarias.IdCuentaBancaria
GROUP BY CTESaldoBancario.IdCuentaBancaria,CatCuentasBancarias.CuentaBancaria,CatCuentasBancarias.NumeroCuenta,CatCuentasBancarias.IdMoneda
go

