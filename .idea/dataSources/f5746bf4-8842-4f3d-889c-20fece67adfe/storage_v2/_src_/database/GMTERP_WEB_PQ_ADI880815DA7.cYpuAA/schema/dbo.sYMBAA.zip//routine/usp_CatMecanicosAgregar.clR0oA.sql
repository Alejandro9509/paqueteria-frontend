CREATE PROCEDURE [dbo].[usp_CatMecanicosAgregar]
@Codigo int,
@NombreCompleto varchar(100),
@CostoPorHora money,
@Activo bit,
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de mecánico es un campo requerido',
			16,
			1
			)

	IF ISNULL(@NombreCompleto,'')= ''
		RAISERROR(N'El nombre del mecánico es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT Codigo FROM CatMecanicos WHERE Codigo = @Codigo)
		RAISERROR(N'El código del mecánico ya existe',
		    16,
            1
            )
			
	INSERT INTO CatMecanicos(Codigo,NombreCompleto,CostoPorHora,Activo,CreadoEl,CreadoPor)
	VALUES(@Codigo,@NombreCompleto,@CostoPorHora,@Activo,@CreadoEl,@CreadoPor)

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

