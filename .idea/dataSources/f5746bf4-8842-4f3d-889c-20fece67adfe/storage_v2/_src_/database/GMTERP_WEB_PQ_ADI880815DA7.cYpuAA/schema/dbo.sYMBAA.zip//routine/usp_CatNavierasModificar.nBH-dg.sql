
/* *************************************************************************************************
Script de modificar Naviera para el catálogo de Navieras

Parámetros: 
	@IdNaviera int					(entrada, entero). Identificador de Naviera a modificar
	@Codigo int,					(entrada, entero). Código de naviera
	@Descripcion varchar(50),		(entrada, string). Descripción de naviera
	@Activo bit,					(entrada, bit). Estado de naviera (Activo/Inactivo)
	@ModificadoEl datetime,			(entrada, fecha hora). Fecha en la que se realiza la modificación
	@ModificadoPor int,				(entrada, entero). Quien solicita la modificación
	@UltimaModificacion datetime	(entrada, fecha hora). Fecha en la que se tiene registrada la última modificación del registro
	@IdPeticion varchar(100)		(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento actualiza la información de una naviera previamente creada para el Catálogo de Navieras
			 del módulo Operación Portuaria.

Implementada por: David Rivera Navarro
Fecha de implementación: 10/07/2019
Versión: Versión 8.0.44.22

Modificada por:   <Nombre del último progrador que lo modificó>
Fecha de mofidicación: <(dd/mm/yyyy)>
Versión: <Versión ERP para la que fue modificada >

Invocada desde: PAGE_CatNavierasAM (Solicitud 12874)

Valor de retorno: NA.

Ejemplo de Uso: NA.

***************************************************************************************************** */

CREATE	 PROCEDURE [dbo].[usp_CatNavierasModificar]
	@IdNaviera int,
	@Codigo int,
	@Descripcion varchar(50),
	@Activo bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	-- Si no se tiene un Id de naviera a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF @IdNaviera = 0
		RAISERROR(N'El identificador de naviera es un campo requerido',
			16,
			1
			)			
	
	-- Si no se tiene una descripción a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF LTRIM(RTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)

	-- Si no se tiene un  código de naviera a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF @Codigo = 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)

	-- Se verifica que el registro se encuentre en existencia para control de concurrencia
	IF NOT EXISTS (SELECT Descripcion FROM CatNavieras WHERE IdNaviera = @IdNaviera)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)

	/* Se verifica que la última fecha de modificación que se haya obtenido en la consulta se encuentre acorde a la Fecha que tenga
	   registrada en la base de datos para control de concurrencia */
	IF (SELECT ModificadoEl FROM CatNavieras WHERE IdNaviera = @IdNaviera) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)

	-- Si el nuevo código coincide con el del algún otro registro, no permitirá modificar el registro
	IF EXISTS(SELECT Codigo FROM CatNavieras WHERE Codigo = @Codigo AND IdNaviera <> @IdNaviera)
		RAISERROR(N'El código de naviera ya existe',
			16,
			1
			)
			
	UPDATE CatNavieras SET 
		Codigo = @Codigo,
		Descripcion = @Descripcion,
		Activo = @Activo,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdNaviera = @IdNaviera
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

