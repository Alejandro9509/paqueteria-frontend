
CREATE PROCEDURE [dbo].[usp_SisOTPEliminarVencidoPQ](
	@FechaHora datetime
	)
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF ISNULL(@FechaHora, '') = '' begin
			RAISERROR(N'*INICIO*La fecha y hora es un campo requerido*FIN*', 16, 1);
			return 
		end;

		DELETE FROM sisOTPPQ WHERE FechaHora < @FechaHora


	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

