CREATE TRIGGER [dbo].[trg_ProViajesTrayectosConFacturasPorPesoDescarga]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE
AS
BEGIN		
			IF EXISTS(SELECT * FROM INSERTED I
			INNER JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
			WHERE I.PesoDescarga <> D.PesoDescarga
			AND EXISTS(SELECT pf.IdFactura FROM ProFacturas AS pf INNER JOIN ProViajesFacturas AS pvf ON pf.IdFactura = pvf.IdFactura WHERE pvf.IdViaje = I.IdViaje AND pvf.CanceladoEl IS NOT NULL AND pf.TipoFactura = 4))
			RAISERROR(N'No puede modificarse el viaje trayecto porque esta facturado el viaje por una factura por peso descarga',
				16,
				1
				)
END
go

