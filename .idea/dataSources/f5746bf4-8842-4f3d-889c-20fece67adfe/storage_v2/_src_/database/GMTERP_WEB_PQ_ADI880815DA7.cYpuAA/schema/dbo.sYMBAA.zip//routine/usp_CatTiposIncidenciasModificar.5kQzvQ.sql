CREATE PROCEDURE [dbo].[usp_CatTiposIncidenciasModificar]	  
	@IdTipoIncidencia int,
	@Codigo int,
    @Descripcion varchar(40),
    @Mnemonico varchar(4),
    @DerechoSueldo bit,
    @PorcentajeSueldo decimal(15,2),
    @TipoImss int,
    @TipoIncidencia int,
    @DerechoSeptimoDia bit,
    @ValorUnidad decimal(15,2),
	@ModificadoEl    datetime,    
	@ModificadoPor    int,    
	@IdPeticion varchar(100),
	@DefinidoPorSistema bit,
	@ClaveSat varchar(5)    
AS
BEGIN TRY
    BEGIN TRANSACTION    
    IF ISNULL(@IdTipoIncidencia,0) = 0
        RAISERROR(N'El Id es un campo requerido',
            16,
            1
            )            
            
	IF ISNULL(@Codigo,0) = 0
        RAISERROR(N'El código es un campo requerido',
            16,
            1
            ) 
            
    IF ISNULL(@Descripcion,'')= ''
      RAISERROR(N'La descripción de la incidencia es un campo requerido',
            16,
            1
            )            
                       
	IF EXISTS(SELECT Descripcion FROM CatTiposIncidencias WHERE Descripcion = @Descripcion and IdTipoIncidencia <> @IdTipoIncidencia)
		RAISERROR(N'El tipo de incidencia ya existe',
			16,
			1
			)                     
   
	UPDATE CatTiposIncidencias SET
	Codigo=@Codigo
	,Descripcion=@Descripcion
	,Mnemonico=@Mnemonico
	,DerechoSueldo=@DerechoSueldo
	,PorcentajeSueldo=@PorcentajeSueldo
	,TipoImss=@TipoImss
	,TipoIncidencia=@TipoIncidencia
	,DerechoSeptimoDia=@DerechoSeptimoDia
	,ValorUnidad=@ValorUnidad
	,ModificadoEl= @ModificadoEl
	,ModificadoPor = @ModificadoPor
	,DefinidoPorSistema = @DefinidoPorSistema
	,ClaveSat = @ClaveSat
	WHERE IdTipoIncidencia = @IdTipoIncidencia
  
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

