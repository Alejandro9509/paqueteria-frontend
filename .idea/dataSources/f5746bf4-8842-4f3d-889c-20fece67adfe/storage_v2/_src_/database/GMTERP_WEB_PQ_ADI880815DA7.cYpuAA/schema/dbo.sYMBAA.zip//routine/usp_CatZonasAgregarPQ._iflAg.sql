
	CREATE PROCEDURE [dbo].[usp_CatZonasAgregarPQ](
	@Folio int,
	@Descripcion varchar(50),
	@IdSucursal int,
	@CreadoEl datetime,
	@CreadoPor int,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@CostoRecolectar money,
	@CostoEntrega money)
AS
BEGIN
	DECLARE
	@IdZona int,
	@return_value int
	BEGIN TRANSACTION
		IF ISNULL(@Folio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Folio es un campo requerido*FIN*', 16, 1); 
			return;
			end
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La Descripcion es un campo requerido*FIN*', 16, 1) 
			return
			end
		
INSERT INTO CatZonasPQ(Folio, Descripcion, IdSucursal, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor, CostoRecolectar, CostoEntrega)

VALUES (@Folio, @Descripcion, @IdSucursal, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor, @CostoRecolectar, @CostoEntrega)

---------------------------------------------------------------------------------------------------------
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

