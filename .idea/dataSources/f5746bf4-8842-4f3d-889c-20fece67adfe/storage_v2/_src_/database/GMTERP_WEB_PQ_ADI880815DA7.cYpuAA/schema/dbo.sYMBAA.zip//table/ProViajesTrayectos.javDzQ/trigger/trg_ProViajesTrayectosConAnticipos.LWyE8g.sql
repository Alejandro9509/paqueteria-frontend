CREATE TRIGGER [dbo].[trg_ProViajesTrayectosConAnticipos]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE
AS
BEGIN		
			IF EXISTS(SELECT * FROM INSERTED I
			INNER JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
			WHERE (I.CodigoUnidadCamion <> D.CodigoUnidadCamion OR 
			I.IdDestino <> D.IdDestino OR 
			I.IdOperador <> D.IdOperador OR 			
			I.IdOrigen <> D.IdOrigen OR 
			I.IdUnidadCamion <> D.IdUnidadCamion OR 
			I.NombreOperador <> D.NombreOperador OR 
			I.PlacasUnidadCamion <> D.PlacasUnidadCamion) AND EXISTS(SELECT IdAnticipo FROM ProAnticipos WHERE IdViajeTrayecto = I.IdViajeTrayecto))
			RAISERROR(N'No puede modificarse el viaje trayecto porque ya tiene anticipos registrados',
				16,
				1
				)
END
go

