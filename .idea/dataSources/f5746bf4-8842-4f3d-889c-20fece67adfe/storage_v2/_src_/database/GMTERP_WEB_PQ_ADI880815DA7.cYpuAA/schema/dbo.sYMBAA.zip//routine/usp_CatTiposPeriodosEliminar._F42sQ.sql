CREATE PROCEDURE [dbo].[usp_CatTiposPeriodosEliminar]
@IdTipoPeriodo int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdTipoPeriodo ,0)= 0
	RAISERROR(N'El identificador del Tipo de Período es un campo requerido',
			16,
			1
			)
	--IF EXISTS(SELECT TOP 1 * FROM CatPeriodos WHERE IdTipoPeriodo = @IdTipoPeriodo)
	--		RAISERROR(N'El Tipo de período esta ligado a un período, no es posible eliminarlo',
	--			16,
	--			1
	--			)
	
	IF EXISTS(SELECT IdTipoPeriodo FROM CatPeriodos WHERE IdTipoPeriodo = @IdTipoPeriodo)
			RAISERROR(N'El Tipo de período esta ligado a un período, no es posible eliminarlo',
				16,
				1
				)
	
	IF EXISTS(SELECT TOP 1 * FROM CatEmpleados WHERE IdTipoPeriodo = @IdTipoPeriodo)
			RAISERROR(N'El Tipo de período está ligado a empleados, no es posible eliminarlo.',
				16,
				1
				)
		DELETE CatTiposPeriodos
		WHERE 	IdTipoPeriodo=@IdTipoPeriodo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

