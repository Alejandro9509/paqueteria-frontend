
CREATE PROCEDURE [dbo].[usp_CatMarcasLlantasModificar]
@IdMarcaLlanta	int,
@Codigo	int,	
@Descripcion varchar(50),
@ModificadoEl datetime,
@ModificadoPor int,
@UltimaModificacion datetime,	
@IdPeticion varchar(100),
@Activo bit	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMarcaLlanta,0)= 0
	RAISERROR(N'El identificador de la marca de llanta es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de la marca de llanta es un campo requerido',
			16,
			1
			)
	IF NOT EXISTS(SELECT IdMarcaLlanta FROM CatMarcasLlantas WHERE IdMarcaLlanta = @IdMarcaLlanta)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)						

	IF (SELECT ModificadoEl FROM CatMarcasLlantas WHERE IdMarcaLlanta = @IdMarcaLlanta) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta marca de llanta fueron modificados por otro usuario. salga sin grabar sus cambios y revise.',
			16,
			1
			)	
	
	 IF EXISTS(SELECT Codigo FROM CatMarcasLlantas WHERE Codigo = @Codigo And IdMarcaLlanta <> @IdMarcaLlanta)
		RAISERROR(N'El código de la marca de llanta ya existe',
			16,
			1
			)  
							
	IF ISNULL(@Descripcion,'')= ''
		RAISERROR(N'La descripcion es un campo requerido',
			16,
			1
			)
			
	UPDATE CatMarcasLlantas SET
	Codigo= @Codigo,
	DescripcionMarca= @Descripcion,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor,
	Activo = @Activo
	WHERE IdMarcaLlanta=@IdMarcaLlanta
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

