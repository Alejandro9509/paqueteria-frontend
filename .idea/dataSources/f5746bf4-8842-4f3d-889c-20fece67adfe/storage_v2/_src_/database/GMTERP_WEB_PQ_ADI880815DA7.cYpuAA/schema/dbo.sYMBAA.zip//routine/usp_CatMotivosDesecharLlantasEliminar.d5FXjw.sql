CREATE PROCEDURE [dbo].[usp_CatMotivosDesecharLlantasEliminar]
@IdMotivoDesecharLlanta int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMotivoDesecharLlanta,0)= 0
		RAISERROR(N'El identificador de motivo desechar llanta es un campo requerido',
				16,
				1
				)
	
	IF NOT EXISTS(SELECT IdMotivoDesecharLlanta FROM CatMotivosDesecharLlantas WHERE  IdMotivoDesecharLlanta<>@IdMotivoDesecharLlanta )
		RAISERROR(N'El motivo desechar llanta ya fue eliminado por otro usuario',
			16,
			1
			)	
										
	-- seccion para validar si el motivo desechar llantas tiene movimientos
	
			
		DELETE CatMotivosDesecharLlantas	
		WHERE 	IdMotivoDesecharLlanta=@IdMotivoDesecharLlanta
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

