CREATE TRIGGER [dbo].[trg_ProViajesTrayectosConVales]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE
AS
BEGIN
		
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
			WHERE (I.CodigoUnidadCamion <> D.CodigoUnidadCamion OR 
			I.IdDestino <> D.IdDestino OR 
			I.IdOperador <> D.IdOperador OR 
			I.IdOrigen <> D.IdOrigen OR 
			I.IdUnidadCamion <> D.IdUnidadCamion OR 
			I.NombreOperador <> D.NombreOperador OR 
			I.PlacasUnidadCamion <> D.PlacasUnidadCamion)
			AND EXISTS(SELECT IdValeCombustible FROM ProValesCombustible WHERE IdViajeTrayecto = I.IdViajeTrayecto AND IdUnidad = D.IdUnidadCamion AND CanceladoEl IS NULL))
			RAISERROR(N'No puede modificarse el viaje trayecto porque ya tiene vales de combustible registrados',
				16,
				1
				)
								            
END
go

