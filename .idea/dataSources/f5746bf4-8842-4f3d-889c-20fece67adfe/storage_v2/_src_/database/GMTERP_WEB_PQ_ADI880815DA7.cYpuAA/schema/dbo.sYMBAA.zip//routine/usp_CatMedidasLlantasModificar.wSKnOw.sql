create PROCEDURE [dbo].[usp_CatMedidasLlantasModificar]
@IdMedidaLLanta	int,
@Codigo	int,	
@DescripcionMedida	varchar(50),	
@Activo bit,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMedidaLLanta,0)= 0
	RAISERROR(N'El identificador de medida de llanta es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de medida de llanta es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatMedidasLlantas WHERE Codigo = @Codigo AND IdMedidaLLanta <> @IdMedidaLLanta )
		RAISERROR(N'El código de medida de llanta ya existe',
			16,
			1
			)	
				
	IF ISNULL(@DescripcionMedida,'')= ''
		RAISERROR(N'El descripción de medida de llanta es un campo requerido',
			16,
			1
			)
	-- Modifica datos del catalo de motivos de desechar llantas		
	UPDATE CatMedidasLlantas  SET
		Codigo= @Codigo,
		DescripcionMedida= @DescripcionMedida,
		Activo= @Activo,		
		ModificadoEl= @ModificadoEl,
		ModificadoPor= @ModificadoPor
	WHERE 	IdMedidaLLanta	 = @IdMedidaLLanta	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

