
	CREATE PROCEDURE [dbo].[usp_CatTarifaCobroModificarPQ](
	@IdTarifa int,
	@IdTipoCobro int,
	@IdTarifaCobro int
	)
AS
BEGIN
	
	BEGIN TRANSACTION
--BEGIN TRY
		IF ISNULL(@IdTarifaCobro, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tarifa de Cobro es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdTarifa, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tarifa es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdTipoCobro, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tipo de Servicio es un campo requerido*FIN*', 16, 1);
			return;
			end
			
		UPDATE CatTarifaCobroPQ
		set IdTipoCobro = @IdTipoCobro

		where IdTarifaCobro =@IdTarifaCobro
		
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
    go

