CREATE PROCEDURE [dbo].[usp_ProFacturasAgregar]
	@IdFolio int,
	@IdCliente int,
	@IdSucursal int,
	@FechaHora datetime,
	@SubTotal money,
	@Descuento money,
	@MotivoDescuento varchar(100),
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Estatus tinyint,
	@EstatusImpresoEnviadoCliente bit,
	@Observaciones varchar(3000),
	@TipoFactura tinyint,
	@CondicionesPago tinyint,
	@DiasCredito tinyint,
	@FechaProgPago datetime,
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),
	@IdCertificado int,
	@IdFormatoImpresion int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProFacturasConceptosFacturacion ntext,
	@dsProFacturasImpuestos ntext,
	@dsProViajesFacturas ntext,
	@IdPeticion varchar(100),
	@IdAddenda int,
	@Campo1 varchar(250),
	@Campo2 varchar(250),
	@Campo3 varchar(250),
	@Campo4 varchar(250),
	@Campo5 varchar(250),
	@Campo6 varchar(250),
	@Campo7 varchar(250),
	@Campo8 varchar(250),
	@Campo9 varchar(250),
	@Campo10 varchar(250),
	@PermitirFacturarRebaseCredito bit,
	@dsProViajesConceptosFacturacionFacturadosParcialmente ntext,
	@FacturarPorKmsRuta bit,
	@ClaveMetodoPago varchar(5),
	@dsProRecorridosFacturas ntext = NULL,
	@dsProFacturasImagenes ntext = NULL,
	@FacturaExterna bit,
	@CreadaParaCFDI33 bit=0,
	@IdUsoCFDI varchar(5)='',
	@IdCombustible int = NULL,
	@LitrosCombustible decimal(15,4) = NULL,
	@FacturarFlete bit = NULL,
	@FacturarCombustible bit = NULL,
	@IEPS money = NULL,
	@ClaveTAR varchar(15) = NULL,
	@IncluirIEPS bit = NULL,
	@FactorIeps money=NULL, 
	@Sustituir bit = NULL,
	@IdFacturaAnterior int = NULL,
	--solicitud 10363 isdejenuhe
	@AjustarImportes2DecimalesXML bit = 0,
	@dsProFacturasRelacionadasPorAnticipo ntext = NULL,
	@dsProFacturasCamposAdicionales ntext = NULL,
	@GMImporta bit = 0,
	@dsProFacturasRelacionPemex NTEXT = NULL,
	@numeroMetodoPago int = 0,
	@dsComplementos ntext = NULL,
	@Penske bit = 0,
	@ConceptosFacturaionDistribucion ntext = NULL
/* ****************************************************************************************************************************************************************

Descripción: El procedimiento agrega una factura de cualquier tipo junto con toda la informacion necesaria para ello y sus relaciones.
13/08/2019   Se cambio la condicion con la que se agregaba las relaciones de facturas con facturas por anticipos, quitando el boqueo que solo
			 permitia hacer estas relaciones entre facturas por anticipos
24/10/2019   Se cambio la forma en la que se agregan la relacion entre facturas por anticipo, isnertandose en una tabla puente llamada ProFacturasRelacion.
13/10/2020	 Se agregó campo de numero de metodo de pago a la clase de ProFacturas
15/05/2020   Se agregó al XML de conceptos los impuestos de IEPS y ISR para facturacion general

Modificada por: David Omar Cabrera Bernal
Fecha de mofidicacion: 13/08/2019
Versión:  8.0.45.13
Solicitud 000064

Modificada por: David Omar Cabrera Bernal
Fecha de mofidicacion: 24/10/2019
Versión:  8.0.47.11
Solicitud 000427

Modificada por: David Omar Cabrera Bernal
Fecha de mofidicacion: 24/10/2019
Versión:  8.0.52.05
Solicitud 001770

Modificada por: Jesús Humberto Morales Mojica
Fecha de mofidicacion: 15/05/2020
Versión:  8.0.52.14
Solicitud 001506

Modificada por: Jesús Ignacio Perez Macias
Fecha de mofidicacion: 04/08/2020
Versión 8.0.54.27
Solicitud 002644
Se modifico para realizar el agregado de los complementos a sus tablas correspondientes, esto se realizo para que los clientes que tengan el
complemento Liverpool activo se pueda ver reflejado en su xml para el timbrado, se agrego @dsComplementos y este es el que se manipula para
dicho agregado

Modificada por: Abril CG
Fecha de mofidicacion: 2020-10-05
Solicitud 002932
Se modifico la validacion "La suma de los importes facturados de los conceptos de facturación de los viajes no son iguales al subtotal" de facturacion por viaje parcial;
para que considere los importes segun la modena viaje vs factura

	Modificado por: Yarazeth Lemus
	Fecha de modificacion: 09/11/2020
	Versión 8.0.56.13
	Solicitud 003223
	se agrego el numero de identificacion en las tablas xml temporales

MODIFICADO:
	Se agregaro la bitacora de tipo de cambio ( SisBitacoraTipoCambio )
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2021-04-06
SOLICITUD: 
	SOLICITUD 004067

**************************************************************************************************************************************************************** */
/* ****************************************************************************************************************************************************************
Modificada por: Jesús Ignacio Perez Macias
Fecha de mofidicacion: 07/06/2021
Versión 8.0.62.02
Solicitud 004370
Se modifico para agregar el campo penske, espara para saber cuando se realizan exportaciones de facturas desde la aplicacion de penske

Se llama desde aplicacion PENSKE al generar una factura utiliza el ProFacturas:agregar de a clase de ClsProFacturas
**************************************************************************************************************************************************************** */
/*
	SOLICITUD:	004401
				Se agrego la distribucion de concepto por unidad 
	MODIFICADO EL:	2021-07-15
	MODIFICADO POR:	ABRIL CG
*/

AS
DECLARE
	@docHandle int,
	@IdFactura int,
	@CursorImporteFacturado money,
	@CursorIdViaje int,
	@CursorIdRecorrido int,
	@CursorModificadoEl datetime,
	@CursorKmsRuta int,
	@CursorEstaLiberado bit = 0, -- bandera para controlar si el viaje esta liberado desde la utileria
	@SubTotalViaje money,
	@SubTotalRecorrido money,
	@return_value int,
    @ViajeConCP bit,
    @IdMonedaAnt int,
    @TotalAnt money,
    @FacturableAnt bit,
    @IdClienteViaje int, -- id del cliente del viaje para quitarle el adeudo de lo facturado
    @IdClienteRecorrido int,
    @Viaje int,--se usa generar el mensaje de error cuando un viaje ya esta factutado
    @Recorrido int,
    @Sucursal varchar(12),--se usa generar el mensaje de error cuando un viaje ya esta factutado	
    @Mensaje varchar(500),--se usa generar el mensaje de error cuando un viaje ya esta factutado	
    @FacturadoParcialmente bit,-- es una badera para identificar si la factura es tipo 3
    @DocumentoCartaPorte varchar(100), --documento carta porte, para mostrar si se factura la cp/viaje durante el proceso por otro usuario
	@FolioSustitucion varchar(50),
	@CerosFolioSustitucion varchar(50),
	@SerieFolio varchar(50),
	@DiferenciaImporte money,
	@SumatoriaConceptos money,
	@CursorIdFactura int,
	@ImporteFacutradoParcialmenteViaje  float,
	@PendienteFacturarCliente float, -- Solicitud 11939 Se agrego las variables para tomar el valor completo del importe por facturar del cliente 
	@PendienteFacturarDLLSCliente float,
	@CursorImporte money,
	@CursorDireccionRelacion int,
	@CursorIdConceptoFacturacion int,
	@CursorCantidad decimal(15,4),
	@CursorPrecioUnitario decimal(15,6),
	@CursorImporteConcepto money,
	@CursorTrasladaImpuesto bit,
	@CursorRetieneImpuesto bit,@CursorObservaciones varchar(8000),
	@CursorUnidadMedida varchar(30),
	@CursorConceptoViaje bit,
	@CursorIncluirObservacionesXML tinyint,
	@CursorClaveSATProducto varchar(8),
	@CursorClaveSATUnidad varchar(8),
	@CursorDescuento money,
	@CursorIdImpuestoTraslado int,
	@CursorImporteTrasladado money,
	@CursorIdImpuestoRetencion int,
	@CursorImporteRetencion money,
	@CursorIdImpuestoIEPS int,
	@CursorImporteIEPS money,
	@CursorIdImpuestoISR int,
	@CursorImporteISR money,
	@CursorNoIdentificacion varchar(40),
	@IdFacturaConceptoFacturacion int,
	@IdFacturaRelacionPemex INT,
	@IdRelacionLiquidacionPemex INT,

	@CursorComplementoIdComplemento int,
	@CursorComplementoValor1 varchar(250),
	@CursorComplementoValor2 varchar(250),
	@CursorComplementoValor3 varchar(250)


	/*Conceptos Facturacion Distribucion*/
	DECLARE @VarConceptosFacturacionDistribucion TABLE  
	(IdConceptoFacturacion int ,
	IdUnidad int ,
	ImporteDistribuido money )


BEGIN TRY
	BEGIN TRANSACTION

	IF @IdFolio = 0
		RAISERROR(N'El folio del documento es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT IdFolio FROM ProFacturas WHERE IdFolio = @IdFolio)
		RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar.',
			16,
			1
			)				

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF @IdSucursal = 0
		RAISERROR(N'Ls sucursal es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaHora) = 0			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF @SubTotal = 0
		RAISERROR(N'El subtotal es un campo requerido',
			16,
			1
			)

	IF @IdMoneda = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)

	IF @TipoCambio <= 0
		RAISERROR(N'El tipo de cambio es un campo requerido',
			16,
			1
			)
			
	IF @dsProFacturasConceptosFacturacion IS NULL
		RAISERROR(N'Los conceptos de facturacion son requeridos',
			16,
			1
			)	

	IF @dsProFacturasImpuestos IS NULL
		RAISERROR(N'Los impuestos son requeridos',
			16,
			1
			)		

	IF (@TipoFactura = 2 OR @TipoFactura = 3 OR @TipoFactura = 4 OR @TipoFactura = 5) AND @dsProViajesFacturas IS NULL
		RAISERROR(N'Los viajes a facturar son requeridos',
			16,
			1
			)
	IF @TipoFactura = 6 AND @dsProRecorridosFacturas IS NULL
		RAISERROR(N'Los Recorridos a facturar son requeridos',
			16,
			1
			)

	IF @TipoFactura = 8 AND ISNULL(@LitrosCombustible,0) = 0 --Por Combustible
		RAISERROR(N'Los litros son requeridos',
			16,
			1
			)
			
			
	IF @TipoFactura = 8 AND ISNULL(@IdCombustible,0) = 0 --Por Combustible
		RAISERROR(N'El Combustible es requerido',
			16,
			1
			)
			

	SET @FacturadoParcialmente = 0
	
	IF @TipoFactura = 3 
	BEGIN			
		SET @FacturadoParcialmente = 1	
	END

	If @IdCertificado = 0
		SET @IdCertificado = NULL			

	If @IdFormatoImpresion = 0
		SET @IdFormatoImpresion = NULL
		
	IF @FacturaExterna = 0
		SET @FacturaExterna = NULL	

	--solicitud 10363 isdejenuhe se agrego campo AjustarImportes2DecimalesXML
	INSERT INTO ProFacturas(CondicionesPago,CreadoEl,CreadoPor,Descuento,DiasCredito,Estatus,EstatusImpresoEnviadoCliente,
	FechaHora,FechaProgPago,IdCertificado,IdCliente,IdFolio,IdFormatoImpresion,IdMoneda,IdSucursal,ImpuestosRetenidosFederales,
	ImpuestosRetenidosLocales,ImpuestosTrasladadosFederales,ImpuestosTrasladadosLocales,MetodoPago,MotivoDescuento,NroCuentaPago,
	Observaciones,SubTotal,TipoCambio,TipoFactura,Total,FacturarPorKmsRuta,ClaveMetodoPago,FacturaExterna,CreadaParaCFDI33,IdUsoCFDI,
	IdCombustible,LitrosCombustible,FacturarFlete,FacturarCombustible,IncluirIEPS,IEPS,ClaveTAR,FactorIeps,AjustarImportes2DecimalesXML,GMImporta,NumeroMetodoPago,Penske)
	VALUES(@CondicionesPago,@CreadoEl,@CreadoPor,@Descuento,@DiasCredito,@Estatus,@EstatusImpresoEnviadoCliente,
	@FechaHora,@FechaProgPago,@IdCertificado,@IdCliente,@IdFolio,@IdFormatoImpresion,@IdMoneda,@IdSucursal,@ImpuestosRetenidosFederales,
	@ImpuestosRetenidosLocales,@ImpuestosTrasladadosFederales,@ImpuestosTrasladadosLocales,@MetodoPago,@MotivoDescuento,@NroCuentaPago,
	@Observaciones,@SubTotal,@TipoCambio,@TipoFactura,@Total,@FacturarPorKmsRuta,@ClaveMetodoPago,@FacturaExterna,@CreadaParaCFDI33,@IdUsoCFDI,
	@IdCombustible,@LitrosCombustible,@FacturarFlete,@FacturarCombustible,@IncluirIEPS,@IEPS,@ClaveTAR,@FactorIeps,@AjustarImportes2DecimalesXML,@GMImporta,@numeroMetodoPago,@Penske)

	SET @IdFactura = (SELECT IDENT_CURRENT('ProFacturas'))	
	
	--SECCION MODIFICAR FACTURAS SUSTITUIDAS
	IF @Sustituir = 1
	BEGIN
		SET @FolioSustitucion = (SELECT Folio FROM CatFolios WHERE IdFolio = @IdFolio)
		SET @CerosFolioSustitucion = (SELECT REPLICATE('0', 8-LEN(Folio)) FROM CatFolios WHERE IdFolio = @IdFolio)
		SET @SerieFolio = (SELECT Serie FROM CatFolios WHERE IdFolio = @IdFolio)
		UPDATE ProFacturas SET
			IdFacturaAnterior = @IdFactura,
			FechaSustitucion = @CreadoEl,
			FolioSustitucion = @CerosFolioSustitucion + @FolioSustitucion + '-' + @SerieFolio
		WHERE IdFactura = @IdFacturaAnterior
	END

	--SECCION PARA AGREGAR LAS FACTURAS RELACIONADAS, se quitó el bloqueo en al condicion que solo dejaba hacer relaciones entre facturas por anticipo
	IF @dsProFacturasRelacionadasPorAnticipo IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasRelacionadasPorAnticipo

		SELECT ATT_IdFactura, ATT_Importe, ATT_DireccionRelacion
		INTO #TempProFacturasRelacionadasPorAnticipo
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasRelacionadas',2) 
		WITH (ATT_IdFactura int, ATT_Importe money, ATT_DireccionRelacion int )

		EXEC sp_xml_removedocument @docHandle	

		DECLARE dsProFacturasRelacionadasPorAnticipoCursor CURSOR FOR
		SELECT * FROM #TempProFacturasRelacionadasPorAnticipo

		OPEN dsProFacturasRelacionadasPorAnticipoCursor
		FETCH NEXT FROM dsProFacturasRelacionadasPorAnticipoCursor
		INTO @CursorIdFactura,@CursorImporte,@CursorDireccionRelacion

		WHILE @@FETCH_STATUS = 0
		BEGIN
			--Se cambio esta seccion para agregar la relacion entre facturas a la tabla de ProFacturasRelacion
			IF @CursorDireccionRelacion = 1 
			BEGIN
				INSERT INTO ProFacturasRelacion (IdFactura,IdFacturaRelacionada, Importe)
					VALUES( @IdFactura, @CursorIdFactura, @CursorImporte )
			END
			ELSE
			BEGIN
			--Se pone ademas un update para actualizar cuando una factura es la superior en el campo FacturaRelacionPadre
				INSERT INTO ProFacturasRelacion (IdFactura,IdFacturaRelacionada, Importe)
					VALUES( @CursorIdFactura, @IdFactura, @CursorImporte )
				UPDATE ProFacturas SET FacturaRelacionPadre = 1 WHERE IdFactura = @CursorIdFactura
			END
			FETCH NEXT FROM dsProFacturasRelacionadasPorAnticipoCursor
			INTO @CursorIdFactura,@CursorImporte,@CursorDireccionRelacion
		END
		CLOSE dsProFacturasRelacionadasPorAnticipoCursor
		DEALLOCATE dsProFacturasRelacionadasPorAnticipoCursor
		IF @CursorDireccionRelacion = 1 
		BEGIN
			UPDATE ProFacturas SET FacturaRelacionPadre = 1 WHERE IdFactura = @IdFactura
		END
	END
	
	--SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
	--EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasConceptosFacturacion

	--SELECT ATT_IdConceptoFacturacion,ATT_Cantidad,ATT_PrecioUnitario,ATT_Importe,ATT_TrasladaImpuesto,ATT_RetieneImpuesto,ATT_Observaciones,ATT_UnidadMedida,ATT_ConceptoViaje,ATT_IncluirObservacionesXML,ATT_ClaveSATProducto,ATT_ClaveSATUnidad,ATT_Descuento
	--INTO #TempProFacturasConceptosFacturacion
	--FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasConceptosFacturacion',2) 
	--WITH (ATT_IdConceptoFacturacion int,ATT_Cantidad decimal(15,4),ATT_PrecioUnitario decimal(15,6),ATT_Importe money,ATT_TrasladaImpuesto bit,ATT_RetieneImpuesto bit,ATT_Observaciones varchar(8000),ATT_UnidadMedida varchar(30),ATT_ConceptoViaje bit,ATT_IncluirObservacionesXML tinyint,ATT_ClaveSATProducto varchar(8),ATT_ClaveSATUnidad varchar(8),ATT_Descuento money)

	--EXEC sp_xml_removedocument @docHandle
	
	--INSERT INTO ProFacturasConceptosFacturacion(Cantidad,ConceptoViaje,IdConceptoFacturacion,IdFactura,Importe,Observaciones,PrecioUnitario,
	--RetieneImpuesto,TrasladaImpuesto,UnidadMedida,CreadoPor,CreadoEl,IncluirObservacionesXML,ClaveSATProducto,ClaveSATUnidad,Descuento)
	--SELECT ATT_Cantidad,ATT_ConceptoViaje,ATT_IdConceptoFacturacion,@IdFactura,ATT_Importe,ATT_Observaciones,ATT_PrecioUnitario,
	--ATT_RetieneImpuesto,ATT_TrasladaImpuesto,ATT_UnidadMedida,@CreadoPor,@CreadoEl,ATT_IncluirObservacionesXML,ATT_ClaveSATProducto,ATT_ClaveSATUnidad,ATT_Descuento
	--FROM #TempProFacturasConceptosFacturacion
	------------------------------------------------------------------------------------------------------------------------
	/*SE GENERA EL XML Y VARIABLE TABLA PARA LA DISTRIBUCION DE LOS CONCEPTOS DE FACTURACION*/
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @ConceptosFacturaionDistribucion
	
	SELECT ATT_IdConceptoFacturacion,ATT_IdUnidad,ATT_ImporteDistribuido
	INTO #ConceptosFacturacionDistribucion
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/ConceptoDistribucion',2) 
	WITH (ATT_IdConceptoFacturacion int ,ATT_IdUnidad int ,ATT_ImporteDistribuido money)
    
	EXEC sp_xml_removedocument @docHandle

	/*DISTRIBUCION DEL CONCEPTO DE FACTURACION POR UNIDADES*/
	INSERT INTO @VarConceptosFacturacionDistribucion (IdConceptoFacturacion,IdUnidad ,ImporteDistribuido)
	SELECT 
	 Temp.ATT_IdConceptoFacturacion
	,Temp.ATT_IdUnidad 
	,Temp.ATT_ImporteDistribuido
	FROM #ConceptosFacturacionDistribucion AS Temp 

	/*SE GENERA TABLA TEMPORAL PARA LOS CONCEPTOS DE FACTURACION*/
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasConceptosFacturacion

	SELECT ATT_IdConceptoFacturacion,ATT_Cantidad,ATT_PrecioUnitario,ATT_Importe,ATT_TrasladaImpuesto,ATT_RetieneImpuesto,ATT_Observaciones,ATT_UnidadMedida,ATT_ConceptoViaje,ATT_IncluirObservacionesXML,ATT_ClaveSATProducto,
	ATT_ClaveSATUnidad,ATT_Descuento,ATT_IdImpuestoTraslado,ATT_ImporteTrasladado,ATT_IdImpuestoRetencion,ATT_ImporteRetencion,ATT_IdImpuestoIEPS,ATT_ImporteIEPS,ATT_IdImpuestoISR,ATT_ImporteISR,ATT_NoIdentificacion
	INTO #TempProFacturasConceptosFacturacion
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasConceptosFacturacion',2) 
	WITH (ATT_IdConceptoFacturacion int,ATT_Cantidad decimal(15,4),ATT_PrecioUnitario decimal(15,6),ATT_Importe money,ATT_TrasladaImpuesto bit,ATT_RetieneImpuesto bit,ATT_Observaciones varchar(8000),
	ATT_UnidadMedida varchar(30),ATT_ConceptoViaje bit,ATT_IncluirObservacionesXML tinyint,ATT_ClaveSATProducto varchar(8),ATT_ClaveSATUnidad varchar(8),ATT_Descuento money,
	ATT_IdImpuestoTraslado int ,ATT_ImporteTrasladado money,ATT_IdImpuestoRetencion int ,ATT_ImporteRetencion money, ATT_IdImpuestoIEPS int, ATT_ImporteIEPS money, ATT_IdImpuestoISR int, ATT_ImporteISR money,ATT_NoIdentificacion varchar(40) )

	EXEC sp_xml_removedocument @docHandle
		
	DECLARE CursorFacturasConceptosFacturacion CURSOR FOR
	SELECT * FROM #TempProFacturasConceptosFacturacion
		
	OPEN CursorFacturasConceptosFacturacion
	FETCH NEXT FROM CursorFacturasConceptosFacturacion
	INTO @CursorIdConceptoFacturacion,@CursorCantidad,@CursorPrecioUnitario,@CursorImporteConcepto,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorObservaciones,@CursorUnidadMedida,@CursorConceptoViaje,@CursorIncluirObservacionesXML,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorDescuento,
	@CursorIdImpuestoTraslado,@CursorImporteTrasladado,@CursorIdImpuestoRetencion,@CursorImporteRetencion,@CursorIdImpuestoIEPS,@CursorImporteIEPS,@CursorIdImpuestoISR,@CursorImporteISR,@CursorNoIdentificacion
		
	WHILE @@FETCH_STATUS = 0
	BEGIN					
		INSERT INTO ProFacturasConceptosFacturacion(Cantidad,ConceptoViaje,IdConceptoFacturacion,IdFactura,Importe,Observaciones,PrecioUnitario,
		RetieneImpuesto,TrasladaImpuesto,UnidadMedida,CreadoPor,CreadoEl,IncluirObservacionesXML,ClaveSATProducto,ClaveSATUnidad,Descuento,NoIdentificacion)
		VALUES(@CursorCantidad,@CursorConceptoViaje ,@CursorIdConceptoFacturacion,@IdFactura,@CursorImporteConcepto,@CursorObservaciones,@CursorPrecioUnitario,
		@CursorRetieneImpuesto,@CursorTrasladaImpuesto,@CursorUnidadMedida,@CreadoPor,@CreadoEl,@CursorIncluirObservacionesXML,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorDescuento,@CursorNoIdentificacion)

		SET @IdFacturaConceptoFacturacion = (SELECT IDENT_CURRENT('ProFacturasConceptosFacturacion'))

		IF @CursorIdImpuestoTraslado > 0
		BEGIN
			INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
			VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoTraslado,@CursorImporteTrasladado )
		END

		IF @CursorIdImpuestoRetencion > 0
		BEGIN
			INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
			VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoRetencion,@CursorImporteRetencion )
		END

		IF @CursorIdImpuestoIEPS > 0
		BEGIN
			INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
			VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoIEPS,@CursorImporteIEPS)
		END

		IF @CursorIdImpuestoISR > 0
		BEGIN
			INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
			VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoISR,@CursorImporteISR)
		END

		/*SE GUARDA LA DISTRIBUCION DEL CONCEPTO DE FACTURACION*/
		INSERT INTO ProFacturasConceptosFacturacionDistribucion(IdFacturaConceptoFacturacion,IdUnidad,ImporteDistribuido)
		SELECT
		 @IdFacturaConceptoFacturacion
		,IdUnidad 
		,ImporteDistribuido
		FROM @VarConceptosFacturacionDistribucion WHERE IdConceptoFacturacion = @CursorIdConceptoFacturacion

		FETCH NEXT FROM CursorFacturasConceptosFacturacion
		INTO @CursorIdConceptoFacturacion,@CursorCantidad,@CursorPrecioUnitario,@CursorImporteConcepto,@CursorTrasladaImpuesto,@CursorRetieneImpuesto,@CursorObservaciones,@CursorUnidadMedida,@CursorConceptoViaje,@CursorIncluirObservacionesXML,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorDescuento,@CursorIdImpuestoTraslado,@CursorImporteTrasladado,@CursorIdImpuestoRetencion,@CursorImporteRetencion,@CursorIdImpuestoIEPS,@CursorImporteIEPS,@CursorIdImpuestoISR,@CursorImporteISR,@CursorNoIdentificacion
	END

	CLOSE CursorFacturasConceptosFacturacion
	DEALLOCATE CursorFacturasConceptosFacturacion	
	--------------------------------------------------------------------------------------------------------------------

	-- Se agrego un margen  de diferencia por las milesimas de centavos que se perdian en la conversión
	-- y causaban descuadre en los importes.-- solicitud 010606
	set @SumatoriaConceptos = (SELECT ISNULL(SUM(Importe),0) FROM ProFacturasConceptosFacturacion WHERE IdFactura = @IdFactura)
	set @DiferenciaImporte = @SubTotal - @SumatoriaConceptos

	IF @DiferenciaImporte > 1 OR @DiferenciaImporte < -1
		RAISERROR(N'La suma de los importes de los conceptos de facturación no son iguales al subtotal.',
			16,
			1
			)
	
	--SECCION PARA AGREGAR LOS IMPUESTOS
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasImpuestos
	
	SELECT COL_IdImpuesto,COL_Importe,COL_Porcentaje
	INTO #TempProFacturasImpuestos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProFacturasImpuestos',2) 
	WITH (COL_IdImpuesto int,COL_Importe money,COL_Porcentaje decimal(15,4))
	
	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO ProFacturasImpuestos(CreadoEl,CreadoPor,IdImpuesto,IdFactura,Importe,Porcentaje)
	SELECT @CreadoEl,@CreadoPor,COL_IdImpuesto,@IdFactura,COL_Importe,COL_Porcentaje
	FROM #TempProFacturasImpuestos
	
	IF @dsProFacturasImagenes IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasImagenes
		
		SELECT ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes
		INTO #TempProFacturasImagenes
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasImagenes',2) 
		WITH (ATT_Imagen ntext,ATT_ImagenNombreArchivo varchar(150),ATT_Descripcion varchar(50),ATT_PesoBytes int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProFacturasImagenes(IdFactura,Imagen,ImagenNombreArchivo,Descripcion,PesoBytes)
		SELECT @IdFactura,ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes FROM #TempProFacturasImagenes
	END
	
	--SECCION PARA AGREGAR LOS viajes facturados
	IF @dsProViajesFacturas IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesFacturas
		
		SELECT ATT_ImporteFacturado,ATT_IdViaje,ATT_ModificadoEl,ATT_KmsRuta,ATT_EstaLiberado
		INTO #TempProViajesFacturas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesFacturas',2) 
		WITH (ATT_ImporteFacturado money,ATT_IdViaje int,ATT_ModificadoEl datetime,ATT_KmsRuta int,ATT_EstaLiberado bit)
		
		EXEC sp_xml_removedocument @docHandle	

		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesConceptosFacturacionFacturadosParcialmente
		
		SELECT ATT_ImporteFacturado,ATT_IdViaje,ATT_IdConceptoFacturacion
		INTO #TempProViajesConceptosFacturacionFacturadosParcialmente
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesConceptosFacturacionFacturadosParcialmente',2) 
		WITH (ATT_ImporteFacturado money,ATT_IdViaje int,ATT_IdConceptoFacturacion int)
		
		EXEC sp_xml_removedocument @docHandle			
		
		DECLARE ProViajesFacturasCursor CURSOR FOR
		SELECT * FROM #TempProViajesFacturas

		OPEN ProViajesFacturasCursor
		FETCH NEXT FROM ProViajesFacturasCursor
		INTO @CursorImporteFacturado,@CursorIdViaje,@CursorModificadoEl,@CursorKmsRuta,@CursorEstaLiberado
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @Viaje = (SELECT Viaje FROM ProViajes WHERE IdViaje = @CursorIdViaje)
			SET @Sucursal = (SELECT Abreviacion FROM ProViajes INNER JOIN CatSucursales ON ProViajes.IdSucursal = CatSucursales.IdSucursal WHERE IdViaje = @CursorIdViaje)
						
			SET @IdClienteViaje = (SELECT IdCliente FROM ProViajes WHERE IdViaje = @CursorIdViaje)
			SET @SubTotalViaje = (SELECT SubTotal FROM ProViajes WHERE IdViaje = @CursorIdViaje)
			--se dismuye el saldo pend de facturar
			SET @ViajeConCP = (SELECT ViajeConCP FROM ProViajes WHERE IdViaje = @CursorIdViaje)
			SET @IdMonedaAnt = (SELECT IdMoneda FROM ProViajes WHERE IdViaje = @CursorIdViaje)
			SET @FacturableAnt = (SELECT Facturable FROM ProViajes WHERE IdViaje = @CursorIdViaje)
			IF @ViajeConCP = 0
				SET @TotalAnt = (SELECT SubTotal FROM ProViajes WHERE IdViaje = @CursorIdViaje)
			ELSE    
				SET @TotalAnt = (SELECT Total FROM ProViajesCartasPorte WHERE CanceladoEl IS NULL AND IdViaje = @CursorIdViaje)    
						
			IF @Viaje IS NULL
			BEGIN
				SET @Mensaje = 'Uno de los viajes a facturar acaba de ser eliminado o no existe, cancele la operación y revise por favor'
				
				RAISERROR(@Mensaje,
				16,
				1
				)
			END
			IF EXISTS(SELECT IdViaje FROM ProViajes WHERE IdViaje = @CursorIdViaje AND CanceladoEl IS NOT NULL)
				RAISERROR(N'El viaje fue cancelado por otro usuario',
					16,
					1
					)
			IF (SELECT PendienteFacturar FROM ProViajes WHERE IdViaje = @CursorIdViaje AND CanceladoEl IS NULL) = 0
			BEGIN
				SET @Mensaje = 'El viaje con folio '+CAST(@Viaje as varchar)+'-'+@Sucursal+' acaba de ser facturado por otro usuario, cancele la operación y revise por favor'
				
				RAISERROR(@Mensaje,
				16,
				1
				)
			END
			IF (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = @CursorIdViaje AND CanceladoEl IS NULL)	= 1
			BEGIN
				IF @TipoFactura = 3
				BEGIN
					IF (SELECT ISNULL(SUM(ImporteFacturado),0) FROM ProViajesFacturas WHERE IdViaje = @CursorIdViaje AND CanceladoEl IS NULL) > @SubTotalViaje
					BEGIN
						SET @Mensaje = 'El viaje con folio '+CAST(@Viaje as varchar)+'-'+@Sucursal+' acaba de ser facturado por otro usuario, cancele la operación y revise por favor'
				
						RAISERROR(@Mensaje,
						16,
						1
						)
					END
				END
				ELSE
				BEGIN
					SET @Mensaje = 'El viaje con folio '+CAST(@Viaje as varchar)+'-'+@Sucursal+' fue facturado parcialmente, favor de terminar de facturar por el mismo tipo de facturación'
					RAISERROR(@Mensaje,
					16,
					1
					)
				END
			END	
			
			IF (SELECT ModificadoEl FROM ProViajes WHERE IdViaje = @CursorIdViaje) <> isnull(@CursorModificadoEl,getdate()-1)
			BEGIN
				SET @Mensaje = 'El viaje con folio '+CAST(@Viaje as varchar)+'-'+@Sucursal+' acaba de ser modificado por otro usuario, cancele la operación y revise por favor'
				
				RAISERROR(@Mensaje,
					16,
					1
					)
			END

			IF @FacturableAnt = 1 and @TipoFactura <> 3    --Se agrega validacion para impedir restar el importe total del viaje al importe pendiente facturar 
			BEGIN
				


				IF @IdMonedaAnt = 1 OR @IdMonedaAnt = 3
					UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0)  - @TotalAnt WHERE IdCliente = @IdClienteViaje
				ELSE
					UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) - @TotalAnt WHERE IdCliente = @IdClienteViaje
			END

			IF @FacturableAnt = 1 and @TipoFactura = 3    
			BEGIN
				SET @PendienteFacturarCliente =(SELECT PendFacturar FROM CatClientes WHERE IdCliente = @IdClienteViaje) -- para tomar el importe pendiente completo 
				SET @PendienteFacturarDLLSCliente =(SELECT PendFacturarDLLS FROM CatClientes WHERE IdCliente = @IdClienteViaje)
				SET @ImporteFacutradoParcialmenteViaje = (Select Sum(fp.ATT_ImporteFacturado) from #TempProViajesConceptosFacturacionFacturadosParcialmente as fp
				Inner Join ProViajes as pv  on pv.IdViaje = fp.ATT_IdViaje
				where pv.IdCliente = @IdClienteViaje and pv.IdViaje = @CursorIdViaje)

				SET @ImporteFacutradoParcialmenteViaje  = ROUND(((@ImporteFacutradoParcialmenteViaje/(SELECT SubTotal FROM ProViajes WHERE IdViaje = @CursorIdViaje)) * @TotalAnt),2)-- se agrego el redondeo para asegurar los 2 decimales mostrados en la vista 
				IF @IdMonedaAnt = 1 OR @IdMonedaAnt = 3
					UPDATE CatClientes SET PendFacturar = @PendienteFacturarCliente  - @ImporteFacutradoParcialmenteViaje WHERE IdCliente = @IdClienteViaje
				ELSE
					UPDATE CatClientes SET PendFacturarDLLS = @PendienteFacturarDLLSCliente - @ImporteFacutradoParcialmenteViaje WHERE IdCliente = @IdClienteViaje
			END 	
		
			INSERT INTO ProViajesFacturas(CreadoEl,CreadoPor,IdFactura,IdViaje,ImporteFacturado,KmsRuta)
			VALUES(@CreadoEl,@CreadoPor,@IdFactura,@CursorIdViaje,@CursorImporteFacturado,@CursorKmsRuta)
				
			-- SE ACTUALIZA LA FACTURA EN ProViajesCartasPorteLiberadas SI PendienteFacturar es igual a 0 
			-- Y SI ESTA LIBERADO DESDE LA UTILERIA
			IF @CursorEstaLiberado IS NULL
			SET @CursorEstaLiberado = 0
			
			IF @CursorEstaLiberado = 1
			BEGIN
				IF (SELECT ISNULL(IdFacturaActual,0) FROM ProViajesCartasPorteLiberadas WHERE IdViaje = @CursorIdViaje AND Liberado = 1 ) = 0
				BEGIN				
					UPDATE ProViajesCartasPorteLiberadas SET 
						IdFacturaActual= @IdFactura,
						ModificadoEl = @CreadoEl, 
						ModificadoPor = @CreadoPor
					WHERE IdViaje = @CursorIdViaje
				END
				ELSE
				BEGIN
					SET @DocumentoCartaPorte = (SELECT 
						CASE cf.Serie
						WHEN  '' THEN ctd.Documento+' '+SUBSTRING('00000000',1,8-len(CAST(cf.Folio as varchar)))+CAST(cf.Folio as varchar)
						ELSE  ctd.Documento+' '+SubString('00000000',1,8-len(CAST(cf.Folio as varchar)))+CAST(cf.Folio as varchar)+'-'+cf.Serie
						END 
						FROM CatFolios AS cf 
						INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
						inner join ProViajesCartasPorte pvcp ON pvcp.IdViaje = @CursorIdViaje
						WHERE cf.IdFolio = pvcp.IdFolio) 
						
						SET @Mensaje = 'No se puede facturar CP/Viaje '+ @DocumentoCartaPorte + ' ,ya fue facturado por otro usuario durante el proceso.'
						RAISERROR(@Mensaje,
						16,
						1
						)
				END	
			END
			--si es factura por viaje parcial se actualiza el importe factura de los conceptos
			IF @TipoFactura = 3
			BEGIN
				UPDATE ProViajesConceptosFacturacion SET
				ImporteFacturado = ISNULL(ProViajesConceptosFacturacion.ImporteFacturado,0)+#TempProViajesConceptosFacturacionFacturadosParcialmente.ATT_ImporteFacturado
				FROM ProViajesConceptosFacturacion 
				INNER JOIN #TempProViajesConceptosFacturacionFacturadosParcialmente ON ProViajesConceptosFacturacion.IdConceptoFacturacion = #TempProViajesConceptosFacturacionFacturadosParcialmente.ATT_IdConceptoFacturacion AND ProViajesConceptosFacturacion.IdViaje = #TempProViajesConceptosFacturacionFacturadosParcialmente.ATT_IdViaje
				WHERE ProViajesConceptosFacturacion.IdViaje = @CursorIdViaje
				
				IF EXISTS(SELECT * FROM ProViajesConceptosFacturacion WHERE IdViaje = @CursorIdViaje AND cast(ImporteFacturado AS DECIMAL(15,2)) > cast(Importe AS DECIMAL(15,2)))
				BEGIN
					
					RAISERROR(N'Alguno de los importes facturados conceptos sobrepasa el importe registrado en el viaje',
						16,
						1
						)
				END

				INSERT INTO ProViajesConceptosFacturacionFacturadosParcialmente(IdViaje,IdFactura,ImporteFacturado,IdConceptoFacturacion)
				SELECT 	ATT_IdViaje,@IdFactura,ATT_ImporteFacturado,ATT_IdConceptoFacturacion	
				FROM #TempProViajesConceptosFacturacionFacturadosParcialmente
				WHERE ATT_IdViaje = @CursorIdViaje AND ATT_ImporteFacturado != 0
				
				UPDATE ProViajes SET 				
					ModificadoEl = @CreadoEl, 
					ModificadoPor = @CreadoPor,
					FacturadoParcialmente = @FacturadoParcialmente 
				WHERE IdViaje = @CursorIdViaje				
			END

			-- Si es facturación por relación Pemex se actualiza la información de los viajes
			IF @TipoFactura = 10
			BEGIN
				UPDATE ProViajes SET 				
					ModificadoEl = @CreadoEl, 
					ModificadoPor = @CreadoPor,
					PendienteFacturar = 1
				WHERE IdViaje = @CursorIdViaje
			END

			-- DETECTAMOS SI CP/VIAJE  ESTA LIBERADO DESDE LA UTILERIA
			IF @CursorEstaLiberado <> 1
			BEGIN
			---- SINO ESTA LIBERADA DESDE LA UTILERIA HACE EL FLUJO NORMAL.
				IF (SELECT ISNULL(SUM(ImporteFacturado),0) FROM ProViajesFacturas WHERE IdViaje = @CursorIdViaje AND CanceladoEl IS NULL) = @SubTotalViaje
				BEGIN				
					UPDATE ProViajes SET 
						PendienteFacturar = 0,
						ModificadoEl = @CreadoEl, 
						ModificadoPor = @CreadoPor,
						FacturadoParcialmente = @FacturadoParcialmente 
					WHERE IdViaje = @CursorIdViaje
				END
			END
			ELSE
			BEGIN
			----- SI ESTA LIBERADA DESDE LA UTILERIA
				-----SI EL IMPORTE ES DIFERENTE SE VALIDA QUE LA FACTURA NO ESTE LIBERADA POR LA UTILERIA
				---- Y SI EXISTE Y ESTA DENTRO DE LOS TIPOS DE FACTURAS  2 4 5 , ACTUALIZA EL ESTADO DE FACTURACION
				IF EXISTS(select pvcpl.IdFacturaActual from ProViajesCartasPorteLiberadas pvcpl
							inner join ProFacturas pf on pvcpl.IdFacturaActual = pf.IdFactura
							where
							pvcpl.IdFacturaActual = @IdFactura
							AND pvcpl.IdViaje = @CursorIdViaje
							AND pvcpl.Liberado = 1
							AND pf.TipoFactura in (2,4,5))
				BEGIN
					UPDATE ProViajes SET 
						PendienteFacturar = 0,
						ModificadoEl = @CreadoEl, 
						ModificadoPor = @CreadoPor --,
						--FacturadoParcialmente = @FacturadoParcialmente 
					WHERE IdViaje = @CursorIdViaje
				END
				ELSE
				BEGIN
					 SET @Mensaje = 'select pvcpl.IdFacturaActual from ProViajesCartasPorteLiberadas pvcpl
									inner join ProFacturas pf on pvcpl.IdFacturaActual = pf.IdFactura
									where
									pvcpl.IdFacturaActual = '+CAST(@IdFactura AS VARCHAR)+'
									AND pvcpl.IdViaje ='+ CAST(@CursorIdViaje AS VARCHAR)+'
									AND pvcpl.Liberado = '+ CAST(@CursorEstaLiberado AS VARCHAR)+'
									AND pf.TipoFactura in (2,4,5)'
				--	 RAISERROR(@Mensaje,
				    RAISERROR(N'Ocurrio un error con la carta porte liberada desde utilerias.',
					16,
					1
					)
				END
				
			END
				
			--------------------------------------------------------
			FETCH NEXT FROM ProViajesFacturasCursor
			INTO @CursorImporteFacturado,@CursorIdViaje,@CursorModificadoEl,@CursorKmsRuta,@CursorEstaLiberado
		END	
		

		IF @TipoFactura = 3
		BEGIN

			/*Se hizo uso del mismo metodo para mitigar las diferencias de centavos por conversionde moneda
			 en la validacion global endonde se da el rango de diferencia de 1*/
			SET @SumatoriaConceptos = CAST((SELECT
					ISNULL(SUM(Importe),0)
					FROM (
						SELECT 
						CASE @IdMoneda
						WHEN 1 THEN --pesos
							CASE pv.IdMoneda
							WHEN 1 THEN -- pesos
								pvparcial.ImporteFacturado
							ELSE -- dolares
								pvparcial.ImporteFacturado*@TipoCambio
							END 
						ELSE  --dolares
							CASE pv.IdMoneda
							WHEN 1 THEN -- pesos
								pvparcial.ImporteFacturado/@TipoCambio
							ELSE -- dolares
								pvparcial.ImporteFacturado
							END 
						END
						AS Importe 
						FROM ProViajesConceptosFacturacionFacturadosParcialmente pvparcial
						INNER JOIn ProViajes pv on pvparcial.IdViaje = pv.IdViaje
						WHERE IdFactura = @IdFactura
					) ImporteFacturado)AS DECIMAL(15,2))
			SET @DiferenciaImporte = @SubTotal - @SumatoriaConceptos

			IF @DiferenciaImporte > 1 OR @DiferenciaImporte < -1
			BEGIN			

				RAISERROR(N'La suma de los importes facturados de los conceptos de facturación de los viajes no son iguales al subtotal',
					16,
					1
					)	
			END	
		END	





		
		CLOSE ProViajesFacturasCursor
		DEALLOCATE ProViajesFacturasCursor
	END
	-----------------------------------------------------------------------------

	-- Si es factura por Relación Pemex Inserta la información correspondiente a su tabla puente actualiza la Relación
	IF @TipoFactura = 10 AND @dsProFacturasRelacionPemex IS NOT NULL
	BEGIN
		-- Se crea una tabla temporal
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasRelacionPemex

		SELECT ATT_IdRelacionPemex, ATT_IdViaje, ATT_Documento, ATT_Fecha, ATT_Remolques, ATT_Embarques, ATT_Ruta, ATT_SubTotal
		INTO #TempProViajesFacturasRelacionPemex
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesFacturasRelacionPemex', 2)
		WITH (ATT_IdRelacionPemex INT, ATT_IdViaje INT, ATT_Documento VARCHAR(100), ATT_Fecha DATETIME, ATT_Remolques VARCHAR(100), ATT_Embarques VARCHAR(100), ATT_Ruta VARCHAR(100), ATT_SubTotal MONEY)

		-- Se inserta la información
		INSERT INTO ProFacturasRelacionPemex(IdFactura, IdRelacionLiquidacionPemex, IdViaje, Documento, Fecha, Remolques, Embarques, Ruta, SubTotal, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor, CanceladoEl, CanceladoPor)
		SELECT @IdFactura, ATT_IdRelacionPemex, ATT_IdViaje, ATT_Documento, ATT_Fecha, ATT_Remolques, ATT_Embarques, ATT_Ruta, ATT_SubTotal, @CreadoEl, @CreadoPor, @CreadoEl, @CreadoPor, NULL, NULL
		FROM #TempProViajesFacturasRelacionPemex
		
		-- Se actualiza la Relación Pemex
		UPDATE ProRelacionLiquidacionesPemex SET Estatus = 2 FROM ProRelacionLiquidacionesPemex
		INNER JOIN #TempProViajesFacturasRelacionPemex ON IdRelacionLiquidacionPemex = ATT_IdRelacionPemex
	END
	
	--SECCION PARA AGREGAR LOS RECORRIDOS FACTURADOS
	IF @dsProRecorridosFacturas IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProRecorridosFacturas
		
		SELECT ATT_ImporteFacturado,ATT_IdRecorrido,ATT_ModificadoEl,ATT_KmsRuta
		INTO #TempProRecorridosFacturas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProRecorridosFacturas',2)
		WITH (ATT_ImporteFacturado money,ATT_IdRecorrido int,ATT_ModificadoEl datetime,ATT_KmsRuta int)
		
		EXEC sp_xml_removedocument @docHandle	
			
		
		DECLARE ProRecorridosFacturasCursor CURSOR FOR
		SELECT * FROM #TempProRecorridosFacturas

		OPEN ProRecorridosFacturasCursor
		FETCH NEXT FROM ProRecorridosFacturasCursor
		INTO @CursorImporteFacturado,@CursorIdRecorrido,@CursorModificadoEl,@CursorKmsRuta
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @Recorrido = (SELECT Recorrido FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido)
			SET @Sucursal = (SELECT Abreviacion FROM ProRecorridos INNER JOIN CatSucursales ON ProRecorridos.IdSucursal = CatSucursales.IdSucursal WHERE IdRecorrido = @CursorIdRecorrido)
						
			SET @IdClienteRecorrido = (SELECT IdCliente FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido)
			SET @SubTotalRecorrido = (SELECT SubTotal FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido)
			--se dismuye el saldo pend de facturar
			SET @IdMonedaAnt = (SELECT IdMoneda FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido)
			SET @FacturableAnt = (SELECT Facturable FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido)
			SET @TotalAnt = (SELECT SubTotal FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido)
						
			IF @Recorrido IS NULL
			BEGIN
				SET @Mensaje = 'Uno de los recorridos a facturar acaba de ser eliminado o no existe, cancele la operación y revise por favor'
				
				RAISERROR(@Mensaje,
				16,
				1
				)
			END
			IF EXISTS(SELECT IdRecorrido FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido AND CanceladoEl IS NOT NULL)
				RAISERROR(N'El recorrido fue cancelado por otro usuario',
					16,
					1
					)
			IF (SELECT PendienteFacturar FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido AND CanceladoEl IS NULL) = 0
			BEGIN
				SET @Mensaje = 'El recorrido con folio '+CAST(@Recorrido as varchar)+'-'+@Sucursal+' acaba de ser facturado por otro usuario, cancele la operación y revise por favor'
				
				RAISERROR(@Mensaje,
				16,
				1
				)
			END
			
			
			IF (SELECT ModificadoEl FROM ProRecorridos WHERE IdRecorrido = @CursorIdRecorrido) <> isnull(@CursorModificadoEl,getdate()-1)
			BEGIN
				SET @Mensaje = 'El recorrido con folio '+CAST(@Recorrido as varchar)+'-'+@Sucursal+' acaba de ser modificado por otro usuario, cancele la operación y revise por favor'
				
				RAISERROR(@Mensaje,
					16,
					1
					)
			END

			IF @FacturableAnt = 1     
			BEGIN
				IF @IdMonedaAnt = 1 OR @IdMonedaAnt = 3
					UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0)  - @TotalAnt WHERE IdCliente = @IdClienteViaje
				ELSE
					UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) - @TotalAnt WHERE IdCliente = @IdClienteRecorrido
			END        
						 
			INSERT INTO ProRecorridosFacturas(CreadoEl,CreadoPor,IdFactura,IdRecorrido,ImporteFacturado,KmsRuta)
			VALUES(@CreadoEl,@CreadoPor,@IdFactura,@CursorIdRecorrido,@CursorImporteFacturado,@CursorKmsRuta)					

			IF (SELECT ISNULL(SUM(ImporteFacturado),0) FROM ProRecorridosFacturas WHERE IdRecorrido = @CursorIdRecorrido AND CanceladoEl IS NULL) = @SubTotalRecorrido
			BEGIN				
				UPDATE ProRecorridos SET 
					PendienteFacturar = 0,
					ModificadoEl = @CreadoEl, 
					ModificadoPor = @CreadoPor
					--FacturadoParcialmente = @FacturadoParcialmente 
				WHERE IdRecorrido = @CursorIdRecorrido
			END		
			
			FETCH NEXT FROM ProRecorridosFacturasCursor
			INTO @CursorImporteFacturado,@CursorIdRecorrido,@CursorModificadoEl,@CursorKmsRuta
		END	
		
		CLOSE ProRecorridosFacturasCursor
		DEALLOCATE ProRecorridosFacturasCursor
	END

	--------SECCION PARA AGREGAR LOS CAMPOS ADICIONALES--------
	IF @dsProFacturasCamposAdicionales IS NOT NULL
	BEGIN
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasCamposAdicionales
		
		SELECT ATT_NombreCampo,ATT_ValorCampo
		INTO #TempProFacturasCamposAdicionales
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasCamposAdicionales',2) 
		WITH (ATT_NombreCampo varchar(50),ATT_ValorCampo varchar(150))

		EXEC sp_xml_removedocument @docHandle

		INSERT INTO ProFacturasCamposAdicionales( IdFactura,NombreCampo, ValorCampo )
		SELECT @IdFactura,ATT_NombreCampo, ATT_ValorCampo
		FROM #TempProFacturasCamposAdicionales
	END
	------------------Seccion para agregar los complementos-----------------------------------------------------------
	
	IF @dsComplementos IS NOT NULL
	BEGIN	
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsComplementos
		
		SELECT ATT_IdComplemento,ATT_Valor1,ATT_Valor2,ATT_Valor3
		INTO #TempCatFacturasComplementos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProComplementos',2) 
		WITH (ATT_IdComplemento int,ATT_Valor1 varchar(250), ATT_Valor2 varchar(250),ATT_Valor3 varchar(250))

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CatFacturasComplementosCursor CURSOR FOR
		SELECT * FROM #TempCatFacturasComplementos

		OPEN CatFacturasComplementosCursor
		FETCH NEXT FROM CatFacturasComplementosCursor
		INTO @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2,@CursorComplementoValor3
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			INSERT INTO CatFacturasComplementosCamposAdicionales(IdFactura, IdComplemento, Campo1, Campo2, Campo3, CreadoEl, CreadoPor)
			VALUES(@IdFactura, @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2,@CursorComplementoValor3, @CreadoEl, @CreadoPor )		
		
			FETCH NEXT FROM CatFacturasComplementosCursor
			INTO @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2, @CursorComplementoValor3
		END
		CLOSE CatFacturasComplementosCursor
		DEALLOCATE CatFacturasComplementosCursor
	END

	-----------------------------------------------------------------------------
	IF @IdAddenda > 0
	BEGIN
		INSERT INTO ProFacturasAddendasCamposAdicionales(Campo1,Campo10,Campo2,Campo3,Campo4,Campo5,Campo6,Campo7,Campo8,Campo9,IdAddenda,IdFactura,CreadoEl,CreadoPor)
		VALUES(@Campo1,@Campo10,@Campo2,@Campo3,@Campo4,@Campo5,@Campo6,@Campo7,@Campo8,@Campo9,@IdAddenda,@IdFactura,@CreadoEl,@CreadoPor)
	END

	--actualiza el saldo del cliente 
	IF @IdMoneda = 1 OR @IdMoneda = 3
		UPDATE CatClientes SET SaldoCredito = ISNULL(SaldoCredito,0) + @Total WHERE IdCliente = @IdCliente
	ELSE
		UPDATE CatClientes SET SaldoCreditoDLLS = ISNULL(SaldoCreditoDLLS,0) + @Total WHERE IdCliente = @IdCliente
	
	IF @PermitirFacturarRebaseCredito = 0
	BEGIN	
		IF (SELECT PendFacturar+SaldoCredito FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT Credito FROM CatClientes WHERE IdCliente = @IdCliente)
			RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
				16,
				1
				)

		IF (SELECT PendFacturarDLLS+SaldoCreditoDLLS FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT CreditoDLLS FROM CatClientes WHERE IdCliente = @IdCliente)
			RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
				16,
				1
				)
	END
	-- actualiza el estatus del folio
	UPDATE CatFolios SET Estatus = 2 WHERE IdFolio = @IdFolio
	
	-- ejecuta store procedure para agregare el movimiento de cobranza "FACTURA = 1 IdConceptoCobranza"
	EXEC @return_value = usp_ProCobranzaRegistrar 1,@IdCliente,@IdFactura,@FechaHora,@Total,@TipoCambio,@IdMoneda,'',@IdSucursal,0,@CreadoPor,@CreadoEl,@IdPeticion

	IF @return_value <> 0
	RAISERROR(N'Ocurrió un error al agregar el movimiento de cobranza',
		16,
		1
		)	

	Declare @IdProceso int = 0, @IdProcesoPadre int = 0 ,@TipoCambioDia  money = 0
	SET @TipoCambioDia = (SELECT TOP 1 TipoCambio FROM CatTiposCambio WHERE Cast(Fecha AS DATE) = cast(@FechaHora AS DATE))

	IF @TipoCambio <> isnull(@TipoCambioDia,0)
	BEGIN

		SET @IdProcesoPadre = (SELECT
							CASE @TipoFactura
							WHEN 1 THEN '300100'	/*POR CONCEPTO*/
							WHEN 2 THEN '300200'	/*POR VIAJE*/	
							WHEN 3 THEN '300300'	/*POR VIAJE PARCIAL*/
							WHEN 4 THEN '300400'	/*POR PESO DESCARGA*/
							WHEN 5 THEN '300500'	/*POR KILOMETROS*/
							WHEN 6 THEN '300600'	/*POR RECORRIDO*/
							WHEN 7 THEN '300700'	/*GENERAL*/
							WHEN 8 THEN '300800'	/*POR COMBUSTIBLE*/
							--WHEN 9 THEN ''	/*POR ANTICIPO*/
							WHEN 10 THEN '300900'	/*POR RELACION PEMEX*/
							END
							)
		 /*Agregar: Sustituir*/
		SET @IdProceso = (SELECT
								CASE @TipoFactura
								WHEN 1 THEN  CASE WHEN @Sustituir = 0 THEN '300101' ELSE '300114' END 	/*POR CONCEPTO*/
								WHEN 2 THEN	 CASE WHEN @Sustituir = 0 THEN '300201' ELSE '300216' END 	/*POR VIAJE*/	
								WHEN 3 THEN  CASE WHEN @Sustituir = 0 THEN '300301' ELSE '300314' END 	/*POR VIAJE PARCIAL*/
								WHEN 4 THEN  CASE WHEN @Sustituir = 0 THEN '300401' ELSE '300414' END 	/*POR PESO DESCARGA*/
								WHEN 5 THEN  CASE WHEN @Sustituir = 0 THEN '300501' ELSE '300514' END 	/*POR KILOMETROS*/
								WHEN 6 THEN  CASE WHEN @Sustituir = 0 THEN '300601' ELSE '300615' END 	/*POR RECORRIDO*/
								WHEN 7 THEN  CASE WHEN @Sustituir = 0 THEN '300701' ELSE '300714' END	/*GENERAL*/
								WHEN 8 THEN  CASE WHEN @Sustituir = 0 THEN '300801' ELSE '' END	/*POR COMBUSTIBLE*/
								--WHEN 9 THEN ''	/*POR ANTICIPO*/
								WHEN 10 THEN CASE WHEN @Sustituir = 0 THEN'300901' ELSE '300916' END	/*POR RELACION PEMEX*/
								END
								)
		
		EXEC @return_value = usp_SisBitacoraTipoCambioRegistrar @CreadoEl,@CreadoPor, @IdFactura,@IdProceso,@IdProcesoPadre ,@TipoCambioDia ,@TipoCambio ,@IdPeticion 

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al registrar la bitácora de tipo de cambio.',
			16,
			1
			)

	END


	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

