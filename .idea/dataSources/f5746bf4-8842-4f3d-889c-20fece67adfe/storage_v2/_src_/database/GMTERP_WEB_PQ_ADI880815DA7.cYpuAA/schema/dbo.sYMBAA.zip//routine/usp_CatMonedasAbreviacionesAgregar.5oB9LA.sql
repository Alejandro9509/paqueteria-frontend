CREATE PROCEDURE [dbo].[usp_CatMonedasAbreviacionesAgregar]
@IdMoneda int,
@Abreviacion varchar(25),	
@CreadoEl	datetime,	
@CreadoPor	int,	
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdMoneda,0)= 0
		RAISERROR(N'Identificador de moneda es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Abreviacion FROM CatMonedasAbreviaciones  WHERE Abreviacion  = @Abreviacion)
		RAISERROR(N'La abreviación ya existe',
			16,
			1
			)	
					
	IF ISNULL(@Abreviacion,'')= ''
		RAISERROR(N'La abreviación es un campo requerido',
			16,
			1
			)
			
	INSERT INTO CatMonedasAbreviaciones(IdMoneda,Abreviacion,CreadoEl,CreadoPor)
	VALUES(@IdMoneda,@Abreviacion,@CreadoEl,@CreadoPor)
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

