
CREATE PROCEDURE [dbo].[GenerarSecuenciaPQ]
(
	@proceso int
	)
AS 
BEGIN
	DECLARE @FOLIO bigint
	DECLARE @FOLIOSTR varchar(10)
	DECLARE @PREFIJO varchar(3)
	if (@proceso = 1) --recoleccion
	begin
		select @FOLIO =NEXT VALUE FOR dbo.SEQ_RECOLECCION;
	end
	else if (@proceso = 2)
	begin
		select @FOLIO = NEXT VALUE FOR dbo.SEQ_EMBARQUE;
	end
	else if (@proceso = 3)
	begin
		select @FOLIO =NEXT VALUE FOR dbo.SEQ_GUIA;
	end
	else if (@proceso = 4)
	begin
		select @FOLIO =NEXT VALUE FOR dbo.SEQ_INFORME;
	end
	else if (@proceso = 5)
	begin
		select @FOLIO=NEXT VALUE FOR dbo.SEQ_VIAJE;
	end
	else if (@proceso = 6)
	begin
		select @FOLIO =NEXT VALUE FOR dbo.SEQ_TRACKING;
	END
	else if (@proceso = 7)
	begin
		select @FOLIO =NEXT VALUE FOR dbo.SEQ_GUIA_EMBARQUE;
	END
	RETURN @FOLIO
END
go

