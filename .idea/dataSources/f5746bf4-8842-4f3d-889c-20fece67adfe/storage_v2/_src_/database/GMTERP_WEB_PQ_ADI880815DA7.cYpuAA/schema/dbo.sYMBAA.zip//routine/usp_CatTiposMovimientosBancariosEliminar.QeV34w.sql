CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosBancariosEliminar]
@IdTipoMovimientoBancario int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF (Select TOP 1 DefinidoPorSistema from CatTiposMovimientosBancarios where IdTipoMovimientoBancario=@IdTipoMovimientoBancario) = 1
		RAISERROR(N'Este tipo de movimiento es definido por el sistema, no es posible eliminarla',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdTipoMovimientoBancario=@IdTipoMovimientoBancario)
			RAISERROR(N'Esta cuenta tiene movimientos bancarios realizados, no es posible eliminarla',
				16,
				1
				)
						
    DELETE CatTiposMovimientosBancarios 
     WHERE CatTiposMovimientosBancarios.IdTipoMovimientoBancario = @IdTipoMovimientoBancario

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

