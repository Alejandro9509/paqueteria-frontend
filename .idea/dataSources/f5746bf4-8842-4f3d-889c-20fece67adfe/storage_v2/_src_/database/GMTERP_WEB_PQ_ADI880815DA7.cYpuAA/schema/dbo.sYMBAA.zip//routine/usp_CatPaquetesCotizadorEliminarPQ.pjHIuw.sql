CREATE PROCEDURE [dbo].[usp_CatPaquetesCotizadorEliminarPQ](
	@IdPaquete int
	)
AS

BEGIN

		delete CatPaquetesCotizador
		where IdPaquete = @IdPaquete;
	
END
go

