CREATE PROCEDURE [dbo].[usp_CatTiposPolizasAgregar]
	@Codigo int,
	@Nombre varchar(50),
	@NumeroInicial int,
	@NumeroFinal int,
	@UsarNumeroPor tinyint,
	@UltimoNumeroUsado int,
	@CreadoEl datetime,
	@CreadoPor int,
	@IdPeticion varchar(100),
	@AcronimoCoi varchar(2)
AS
DECLARE
	@AnioActual smallint,
	@IdTipoPoliza int,
	@Ejercicio smallint
BEGIN TRY
	BEGIN TRANSACTION

		IF @Codigo <= 0
			RAISERROR(N'El Codigo es un campo requerido',
				16,
				1
				)
				
		IF EXISTS(SELECT IdTipoPoliza FROM CatTiposPolizas WHERE Codigo = @Codigo)		
			RAISERROR(N'El código del tipo de póliza no se puede repetir',
				16,
				1
				)

		IF LTRIM(RTRIM(@Nombre)) = ''
			RAISERROR(N'El nombre del tipo de póliza es un campo requerido',
				16,
				1
				)
				
		------------Si no existe el Ejercicio entonces lo crea automaticamente------------------		
		Set @AnioActual = YEAR(Getdate())		
		IF NOT EXISTS(Select Ejercicio from ProEjerciciosPeriodos WHERE Ejercicio = @AnioActual) 
			Insert INTO ProEjerciciosPeriodos(Ejercicio) VALUES(@AnioActual)
		----------------------------------------------------------------------------------------	
			

		INSERT INTO CatTiposPolizas(Codigo,CreadoEl,CreadoPor,DefinidoPorSistema,Nombre,NumeroFinal,NumeroInicial,UltimoNumeroUsado,UltimoNumeroUsadoPeriodo1,UltimoNumeroUsadoPeriodo10,UltimoNumeroUsadoPeriodo11,UltimoNumeroUsadoPeriodo12,UltimoNumeroUsadoPeriodo13,UltimoNumeroUsadoPeriodo2,UltimoNumeroUsadoPeriodo3,UltimoNumeroUsadoPeriodo4,UltimoNumeroUsadoPeriodo5,UltimoNumeroUsadoPeriodo6,UltimoNumeroUsadoPeriodo7,UltimoNumeroUsadoPeriodo8,UltimoNumeroUsadoPeriodo9,UsarNumeroPor,AcronimoCoi)
		VALUES(@Codigo,@CreadoEl,@CreadoPor,0,@Nombre,@NumeroFinal,@NumeroInicial,@UltimoNumeroUsado,0,0,0,0,0,0,0,0,0,0,0,0,0,@UsarNumeroPor,@AcronimoCoi)
		
        SET @IdTipoPoliza = (SELECT IDENT_CURRENT('CatTiposPolizas'))
        
        
        
        
        DECLARE ProEjerciciosPeriodosCursor CURSOR FOR
		Select Ejercicio
		from ProEjerciciosPeriodos					
				
		OPEN ProEjerciciosPeriodosCursor
		FETCH ProEjerciciosPeriodosCursor INTO @Ejercicio
		WHILE (@@FETCH_STATUS = 0 )
		BEGIN
        
			INSERT INTO CatTiposPolizasEjercicios(IdTipoPoliza,Ejercicio,CreadoEl,CreadoPor,UltimoNumeroUsado,UltimoNumeroUsadoPeriodo1,UltimoNumeroUsadoPeriodo10,UltimoNumeroUsadoPeriodo11,UltimoNumeroUsadoPeriodo12,UltimoNumeroUsadoPeriodo13,UltimoNumeroUsadoPeriodo2,UltimoNumeroUsadoPeriodo3,UltimoNumeroUsadoPeriodo4,UltimoNumeroUsadoPeriodo5,UltimoNumeroUsadoPeriodo6,UltimoNumeroUsadoPeriodo7,UltimoNumeroUsadoPeriodo8,UltimoNumeroUsadoPeriodo9)
			VALUES(@IdTipoPoliza,@Ejercicio,@CreadoEl,@CreadoPor,@UltimoNumeroUsado,0,0,0,0,0,0,0,0,0,0,0,0,0)		

		FETCH ProEjerciciosPeriodosCursor INTO @Ejercicio
		END
		CLOSE ProEjerciciosPeriodosCursor
		DEALLOCATE ProEjerciciosPeriodosCursor



	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

