CREATE TRIGGER [dbo].[trg_CatFolios]
   ON  [dbo].[CatFolios]
   AFTER UPDATE
AS 
BEGIN
	IF UPDATE(Serie) OR UPDATE(Aprobacion) OR UPDATE(AnioAprobacion) OR UPDATE(IdTipoDocumento) OR UPDATE(FechaAprobacion) OR UPDATE(IdFolioCBB) OR UPDATE(IdSucursal)
			RAISERROR(N'No se puede modificar la información de los folios',
			16,
			1
			)

END
go

