CREATE PROCEDURE [dbo].[usp_ProFacturasAsociarViajes]
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProFacturasViajes ntext,
	@IdPeticion varchar(100)
AS
/**************************************
	@IdFactura int,
	@FechaHora datetime,
	@SubTotal money,
	@Total money,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@dsProFacturasViajes ntext,
	@IdPeticion varchar(100)

	Modificado por:  GUSTAVO PARTIDA
	Fecha de Creacion:  05/03/2021
	Versión: Versión 8.0.55.49
	Solicitud 3971

	Modificado por:  Jesús Humberto Morales
	Fecha de Creacion:  04/05/2021
	Versión: Versión 8.0.61.01
	Solicitud 4068
***************************************/
DECLARE
	@docHandle INT,
	@IdFactura INT,
	@CursorIdViaje INT,
	@CursorIdFactura INT,
	@CursorSubTotal money
	

BEGIN TRY
	BEGIN TRANSACTION	

		IF @dsProFacturasViajes IS NULL
		RAISERROR(N'Los viajes son requeridos',
			16,
			1
			)	

		IF @dsProFacturasViajes IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasViajes

			SELECT ATT_IdViaje, ATT_IdFactura, ATT_SubTotal
			INTO #TempProFacturasViajesLigados
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProViajesSinFacturar',2) 
			WITH (ATT_IdViaje int, ATT_IdFactura int, ATT_SubTotal money )

			EXEC sp_xml_removedocument @docHandle	

			DECLARE dsProFacturasViajesCursor CURSOR LOCAL FOR
			SELECT * FROM #TempProFacturasViajesLigados

			OPEN dsProFacturasViajesCursor
			FETCH NEXT FROM dsProFacturasViajesCursor
			INTO @CursorIdViaje,@CursorIdFactura,@CursorSubTotal

			WHILE @@FETCH_STATUS = 0
			BEGIN
				
				INSERT INTO ProViajesFacturas(IdViaje,IdFactura,ImporteFacturado, CreadoPor,CreadoEl)
				VALUES(@CursorIdViaje,@CursorIdFactura,@CursorSubTotal,@CreadoPor,@CreadoEl)

				UPDATE ProViajes SET PendienteFacturar = 0 WHERE IdViaje = @CursorIdViaje

				SET @IdFactura = @CursorIdFactura

				FETCH NEXT FROM dsProFacturasViajesCursor
				INTO @CursorIdViaje,@CursorIdFactura,@CursorSubTotal

			END

			CLOSE dsProFacturasViajesCursor
			DEALLOCATE dsProFacturasViajesCursor

		END 

		--SE CAMBIA EL ESTATUS DE LA FACTURA A TIPO VIAJE
		UPDATE ProFacturas SET TipoFactura = 2, UtileriaAsociar = 1 WHERE IdFactura = @IdFactura

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	/*Seccion para cerrar los cursores en caso de algun error*/
	IF (SELECT CURSOR_STATUS('LOCAL','dsProFacturasViajesCursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','dsProFacturasViajesCursor')) > -1
		BEGIN
			CLOSE dsProFacturasViajesCursor
		END
	DEALLOCATE dsProFacturasViajesCursor
	END
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

