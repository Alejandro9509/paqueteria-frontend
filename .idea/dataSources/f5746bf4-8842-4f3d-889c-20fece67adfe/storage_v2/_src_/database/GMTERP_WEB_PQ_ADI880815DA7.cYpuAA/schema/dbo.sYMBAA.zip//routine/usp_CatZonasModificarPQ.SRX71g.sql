
	CREATE PROCEDURE [dbo].[usp_CatZonasModificarPQ](
	@IdZona int,
	@Folio int,
	@Descripcion varchar(50),
	@IdSucursal int,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@CostoRecolectar money,
	@CostoEntrega money)
AS
BEGIN
	DECLARE
	@return_value int
	BEGIN TRANSACTION
	IF ISNULL(@IdZona, 0) <= 0 begin
			RAISERROR(N'*INICIO*El identificador de zona es un campo requerido*FIN*', 16, 1); 
			return;
			end
		IF ISNULL(@Folio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Folio es un campo requerido*FIN*', 16, 1); 
			return;
			end
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La Descripcion es un campo requerido*FIN*', 16, 1) 
			return
			end
	

			UPDATE CatZonasPQ SET
			Folio = @Folio,
			Descripcion = @Descripcion,
			IdSucursal = @IdSucursal,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor,
			CostoRecolectar = @CostoRecolectar,
			CostoEntrega = @CostoEntrega
			Where IdZona = @IdZona
--INSERT INTO CatZonas(Folio, Descripcion, IdSucursal, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor,
--CostoRecolectar, CostoEntregar)

--VALUES (@Folio, @Descripcion, @IdSucursal, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor,
--@CostoRecolectar, @CostoEntregar)

---------------------------------------------------------------------------------------------------------
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

