
CREATE PROCEDURE [dbo].[usp_CatTiposCambioModificarPQ](
	@IdTipoCambio INT,
	@Fecha DATETIME,
	@TipoCambio MONEY,
	@ModificadoEl DATETIME,
	@ModificadoPor INT)

	AS
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdTipoCambio,0) <= 0 begin
		RAISERROR(N'*INICIO*El Identificador de Tipo de cambio es un campo requerido*FIN*', 16, 1)
		return 
	end
		IF ISNULL(@Fecha, '') = ''
			RAISERROR(N'La fecha es un campo requerido', 16, 1)
		
		IF ISNULL(@TipoCambio, '') = ''
			RAISERROR(N'El Tipo de cambio es un campo requerido', 16, 1)

		UPDATE CatTiposCambioPQ SET
		Fecha = @Fecha,
		TipoCambio = @TipoCambio,
		ModificadoEl = @ModificadoEl,
		ModificadoPor =@ModificadoPor
		WHERE IdTipoCambio = @IdTipoCambio
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

