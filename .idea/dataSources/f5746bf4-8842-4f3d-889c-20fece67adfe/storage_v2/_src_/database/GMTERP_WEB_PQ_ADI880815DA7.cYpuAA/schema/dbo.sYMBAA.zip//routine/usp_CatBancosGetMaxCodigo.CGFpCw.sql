CREATE PROCEDURE [dbo].[usp_CatBancosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatBancos
go

