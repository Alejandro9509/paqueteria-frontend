CREATE PROCEDURE [dbo].[usp_ProInventarioAlmacenGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM ProInventarioAlmacen
go

