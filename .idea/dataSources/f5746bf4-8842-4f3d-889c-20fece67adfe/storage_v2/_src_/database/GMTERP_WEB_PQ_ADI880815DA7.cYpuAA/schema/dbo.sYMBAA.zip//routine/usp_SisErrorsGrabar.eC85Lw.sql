

CREATE PROCEDURE [dbo].[usp_SisErrorsGrabar]
	@IdPeticion varchar(100)
AS
DECLARE 
	@ErrorNumber int,
	@ErrorSeverity int,
	@ErrorState int,
	@ErrorLine int,
	@ErrorProcedure nvarchar(4000),
	@ErrorMessage nvarchar(4000),
	@IdLog int

SET @ErrorNumber = ERROR_NUMBER()
SET @ErrorSeverity = ERROR_SEVERITY()
SET @ErrorState = ERROR_STATE()
SET @ErrorLine = ERROR_LINE()
SET @ErrorProcedure = ERROR_PROCEDURE()
SET @ErrorMessage = ERROR_MESSAGE()

INSERT INTO SisErrors(ErrorNumber,ErrorSeverity,ErrorState,ErrorLine,ErrorProcedure,ErrorMessage,IdPeticion,FechaHora)
VALUES(@ErrorNumber,@ErrorSeverity,@ErrorState,@ErrorLine,@ErrorProcedure,@ErrorMessage,@IdPeticion,GETDATE())

SET @IdLog = (Select IDENT_CURRENT('SisErrors'))

RETURN @IdLog
go

