CREATE PROCEDURE [dbo].[usp_CatCuentasBancariasEliminar]
	@IdCuentaBancaria int,
	@IdPeticion varchar(100)
AS
/*
MODIFICADO:
	Se agrego en la seccion de eliminar la cuenta contable , un delete para la cuenta contable 
	en el catalogo de CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-10-01
SOLICITUD: 
	SOLICITUD 000266
*/
BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdCuentaBancaria = @IdCuentaBancaria)
		RAISERROR(N'Esta cuenta tiene movimientos bancarios realizados, no es posible eliminarla',
			16,
			1
			)
					
	DELETE FROM CatCuentasBancarias
	WHERE IdCuentaBancaria = @IdCuentaBancaria	
	
	--SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
	IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
	BEGIN
		/*Se elimina la cuenta contable del catalogo CatCuentasContablesSaldos*/
		DELETE FROM CatCuentasContablesSaldos WHERE
		IdCuentaContable IN (SELECT IdCuentaContable FROM CatCuentasContables WHERE CatalogoLigado = 'CatCuentasBancarias' AND IdCatalogoLigado = @IdCuentaBancaria)

		DELETE FROM CatCuentasContables 
		WHERE CatalogoLigado = 'CatCuentasBancarias' AND IdCatalogoLigado = @IdCuentaBancaria	
	END
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

