CREATE PROCEDURE [dbo].[usp_CatTiposPeriodosAgregar]
	  @Codigo int,
      @Nombre Varchar(40),
      @DiasdelPeriodo int,
      @DiasdePago Decimal(15,2),
      @PeriodoTrabajo int,
      @AjustarPeriodo bit,
      @NumerosSeptimos int,
      @PosicionSeptimos datetime,
      @PosicionPagoNomina datetime,
      @FechaInicioEjercicio datetime,
      @Ejercicio int,
	  @CreadoEl    datetime,    
	  @CreadoPor    int,    
	  @IdPeticion varchar(100),
	  @ClavePeriodicidadPago varchar(5),
	  @GeneraPoliza bit
AS
DECLARE
	@IdTipoPeriodo int
BEGIN TRY
    BEGIN TRANSACTION
    IF @Codigo <= 0
        RAISERROR(N'El Código es un campo requerido',
            16,
            1
            )
            
    IF ISNULL(@Nombre,'')= ''
        RAISERROR(N'El nombre es un campo requerido',
            16,
            1
            )
           
	 IF @DiasdelPeriodo  <= 0
	 RAISERROR(N'Los días del período campo requerido',
            16,
            1
            )
     IF @DiasdePago  <= 0
     RAISERROR(N'Los dias de pago son campo requerido',
            16,
            1
            )
     IF @PeriodoTrabajo <= 0
     RAISERROR(N'El Periodo de trabajo es un campo requerido',
            16,
            1
            )
     
     --IF @NumerosSeptimos <= 0
     --RAISERROR(N'El Código es un campo requerido',
     --       16,
     --       1
     --       )
     --IF @PosicionSeptimos <= 0
     --RAISERROR(N'El Código es un campo requerido',
     --       16,
     --       1
     --       )
     IF Isnull(@PosicionPagoNomina,0) <= 0
     RAISERROR(N'Posición del día de pago es un campo requerido',
            16,
            1
            )
     IF Isnull(@FechaInicioEjercicio,0) <= 0
     RAISERROR(N'Fecha de inicio del ejercicio es campo requerido',
            16,
            1
            )
     IF @Ejercicio <= 0  
     RAISERROR(N'El Ejercicio es un campo requerido',
            16,
            1
            )
            
	IF EXISTS(SELECT Codigo FROM CatTiposPeriodos WHERE Codigo = @Codigo)
		RAISERROR(N'El Código del tipo de periodo ya existe',
			16,
			1
			)                     
   	IF EXISTS(SELECT Nombre FROM CatTiposPeriodos WHERE Nombre = @Nombre)
		RAISERROR(N'El nombre del tipo de periodo ya existe',
			16,
			1
			)         
            
    INSERT INTO CatTiposPeriodos(Codigo,Nombre,DiasdelPeriodo,DiasdePago,PeriodoTrabajo,AjustarPeriodo,NumerosSeptimos,PosicionSeptimos,PosicionPagoNomina,FechaInicioEjercicio,Ejercicio,CreadoEl,CreadoPor,ClavePeriodicidadPago,GeneraPoliza)            
    VALUES(@Codigo,@Nombre,@DiasdelPeriodo,@DiasdePago,@PeriodoTrabajo,@AjustarPeriodo,@NumerosSeptimos,@PosicionSeptimos,@PosicionPagoNomina,@FechaInicioEjercicio,@Ejercicio,@CreadoEl,@CreadoPor,@ClavePeriodicidadPago,@GeneraPoliza)
 
 	SET @IdTipoPeriodo = (SELECT IDENT_CURRENT('CatTiposPeriodos'))

    --seccion para agregar el IdTipoPeriodo a paremtros y poder obtenerlo de lado del web
    IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdTipoPeriodo' AND IdUsuario = @CreadoPor)
    INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdTipoPeriodo',@IdTipoPeriodo,@CreadoPor)
    ELSE
    UPDATE SisParametrosPagina SET Parametros = @IdTipoPeriodo WHERE Pagina = 'IdTipoPeriodo' AND IdUsuario = @CreadoPor
 
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

