CREATE PROCEDURE [dbo].[usp_ProEmbarqueDetalleAgregarComplementoPQ](
	@IdEmbarque int,
	@Cantidad int ,
	@ClaveProductoServicio varchar(20),
	@ClaveUnidad varchar(20),
	@ClaveFraccionArancelaria varchar(20),
	@UUIDComercioExterior varchar(100),
	@EsMaterialPeligroso bit,
	@ClaveMaterialPeligroso varchar(20),
	@ClaveEmbalaje varchar(20),
	@TipoEmbalaje varchar(200),
	@DescripcionEmbalaje text,
	@Peso float
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdEmbarque, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de Embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		insert into ProEmbarqueComplementosSATPQ (IdEmbarque,Cantidad,
		ClaveProductoServicio,ClaveUnidad,ClaveFraccionArancelaria,UUIDComercioExterior,
		EsMaterialPeligroso,ClaveMaterialPeligroso,ClaveEmbalaje,TipoEmbalaje,DescripcionEmbalaje,Peso)
		values (@IdEmbarque,@Cantidad,@ClaveProductoServicio,
		@ClaveUnidad,@ClaveFraccionArancelaria,@UUIDComercioExterior,@EsMaterialPeligroso,
		@ClaveMaterialPeligroso,@ClaveEmbalaje,@TipoEmbalaje,@DescripcionEmbalaje,@Peso);
		
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

