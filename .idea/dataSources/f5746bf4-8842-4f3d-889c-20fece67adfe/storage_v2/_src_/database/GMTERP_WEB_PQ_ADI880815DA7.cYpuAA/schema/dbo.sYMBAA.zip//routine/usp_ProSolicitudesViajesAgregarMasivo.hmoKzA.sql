CREATE PROCEDURE [dbo].[usp_ProSolicitudesViajesAgregarMasivo]
	@dsSolicitudes NTEXT,
	@IdCliente INT,
	@IdClienteContacto INT,
	@CreadoEl DATETIME,
	@IdPeticion VARCHAR(100)
AS 
DECLARE
	@RetornoSolicitudesViaje VARCHAR(MAX),
	@docHandle int,
	@NombreFiscal VARCHAR(150)
BEGIN TRY
	BEGIN TRANSACTION
		
	IF @dsSolicitudes IS NOT NULL
	BEGIN 
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsSolicitudes

		SELECT 
		  ATT_Consecutivo
		, ATT_LoadNumber
		, ATT_Origen
		, ATT_Destino
		, ATT_EntregarEn
		, ATT_RecorgerEn
		, ATT_Observaciones
		, ATT_Peso
		, ATT_FechaHoraCarga
		, ATT_FechaHoraDescarga
		, ATT_Correo
		, ATT_Telefono
		INTO #TempDetalleEquipo
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProSolicitudesViaje',2) 
		WITH (ATT_Consecutivo INT
		    , ATT_LoadNumber VARCHAR(20)
			, ATT_Origen VARCHAR(70)
			, ATT_Destino VARCHAR(70)
			, ATT_EntregarEn VARCHAR(100)
			, ATT_RecorgerEn VARCHAR(100)
			, ATT_Observaciones VARCHAR(512)
			, ATT_Peso DECIMAL(15,4)
			, ATT_FechaHoraCarga DATETIME
			, ATT_FechaHoraDescarga DATETIME
			, ATT_Correo VARCHAR(100)
			, ATT_Telefono VARCHAR(20))

		EXEC sp_xml_removedocument @docHandle

		INSERT INTO ProSolicitudesViajes (Consecutivo, IdCliente, IdContacto, FechaHora, LoadNumber, Origen, Destino, SeEntregaraEn, SeRecogeraEn, Observaciones, PesoEstimado, FechaHoraCarga, FechaHoraDescarga, Correo, Telefono, Tipo, Estatus)
		SELECT 
		  ATT_Consecutivo
		, @IdCliente
		, @IdClienteContacto
		, @CreadoEl
		, ATT_LoadNumber
		, ATT_Origen
		, ATT_Destino
		, ATT_EntregarEn
		, ATT_RecorgerEn
		, ATT_Observaciones
		, ATT_Peso
		, ATT_FechaHoraCarga
		, ATT_FechaHoraDescarga
		, ATT_Correo
		, ATT_Telefono
		, 3
		, 2 
		FROM #TempDetalleEquipo

		--Se obtiene los Id de las solicitudes de viaje agregadas y se agrega a SisParametrosValores
		SET @RetornoSolicitudesViaje = (SELECT STUFF((SELECT ',' + 'LoadNumber:' + CAST(PSV.LoadNumber AS VARCHAR(MAX)) + '|IdSolicitud:'+ CAST(PSV.IdSolicitudViaje AS VARCHAR(MAX)) FROM ProSolicitudesViajes AS PSV WHERE PSV.IdCliente = @IdCliente AND PSV.Consecutivo IN (SELECT ATT_Consecutivo FROM #TempDetalleEquipo) FOR XML PATH('')), 1, 1, ''))
		IF NOT EXISTS(SELECT * FROM SisParametrosValores WHERE Parametro = 'SolicitudesViajeAPI')
			INSERT INTO SisParametrosValores(Parametro, Valor) VALUES('SolicitudesViajeAPI', @RetornoSolicitudesViaje)
		ELSE
			UPDATE SisParametrosValores SET Valor = @RetornoSolicitudesViaje WHERE Parametro = 'SolicitudesViajeAPI'
		END

		--Se agregan las asistencias por cada LoadNumber agregado
		SET @NombreFiscal = (SELECT NombreFiscal FROM CatClientes WHERE IdCliente = @IdCliente)

		INSERT INTO SisAsistencias(FechaHora, Mensaje, Aviso, CreadoEL, CreadoPor, Atendido, AtendidoPor, ComentariosAtendio, DescripcionEvento, LinkUbicacion, IdCliente)
		SELECT 
		  GETUTCDATE()
		, 'NUEVA SOLICITUD DE CARTA PORTE DESDE EL SERVCIO WEB (API), CLIENTE: ' + @NombreFiscal + ', CON REFERENCIA ' + CAST(ATT_LoadNumber AS varchar)
		, 'NUEVA SOLICITUD DE CARTA PORTE'
		, @CreadoEl
		, 0
		, 0
		, 0
		, ''
		, 'ALTA SOLICITUD DE CARTA PORTE'
		, ''
		, @IdCliente
		FROM #TempDetalleEquipo

	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT > 0)
	BEGIN
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

