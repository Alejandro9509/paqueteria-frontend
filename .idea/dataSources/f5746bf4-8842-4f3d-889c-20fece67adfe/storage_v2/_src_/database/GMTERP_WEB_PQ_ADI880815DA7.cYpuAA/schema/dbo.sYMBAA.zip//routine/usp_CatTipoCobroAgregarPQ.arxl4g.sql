

CREATE PROCEDURE [dbo].[usp_CatTipoCobroAgregarPQ](
	@Codigo int,
	@Descripcion VARCHAR(125),
	@CreadoEl Datetime,
	@CreadoPor int, 
	@ModificadoEl Datetime,
	@ModificadoPor int)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Codigo, '') = ''begin
			
			RAISERROR(N'*INICIO*El código es un campo requerido*FIN*', 16,  1)
			return
		end
		
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La descripción es un campo requerido*FIN*', 16,  1)
			return
		end
		
		INSERT INTO CatTipoCobro (Codigo, Descripcion, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
		VALUES (@Codigo, @Descripcion, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH

select * from CatTipoCobro
go

