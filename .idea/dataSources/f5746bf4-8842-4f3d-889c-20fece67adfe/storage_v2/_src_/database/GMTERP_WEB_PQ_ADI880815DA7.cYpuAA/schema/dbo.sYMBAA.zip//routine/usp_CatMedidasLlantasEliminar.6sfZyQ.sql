
CREATE PROCEDURE [dbo].[usp_CatMedidasLlantasEliminar]
@IdMedidaLLanta int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMedidaLLanta,0)= 0
		   RAISERROR(N'El identificador de medida de llanta es un campo requerido',
					16,
					1
					)
	IF EXISTS(SELECT TOP 1 * FROM CatModelosLlantas WHERE IdMedidaLlanta = @IdMedidaLLanta)
		RAISERROR(N'La Medida tiene Modelos asignados, no es posible eliminarla',
			16,
			1
			)
	IF NOT EXISTS(SELECT IdMedidaLLanta  FROM CatMedidasLlantas WHERE  IdMedidaLLanta  <> @IdMedidaLLanta)
			RAISERROR(N'El medida de llanta ya fue eliminado por otro usuario',
				16,
				1
				)	
										
		-- seccion para validar si el motivo desechar llantas tiene movimientos
	
			
		DELETE CatMedidasLlantas	
		WHERE 	IdMedidaLLanta = @IdMedidaLLanta
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

