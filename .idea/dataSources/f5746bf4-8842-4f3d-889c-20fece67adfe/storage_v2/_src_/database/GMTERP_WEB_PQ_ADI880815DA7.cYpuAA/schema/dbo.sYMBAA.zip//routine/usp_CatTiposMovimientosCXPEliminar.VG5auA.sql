CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosCXPEliminar]
@IdTipoMovimientoCXP Int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdTipoMovimientoCXP,0)= 0
		RAISERROR(N'El identificador de tipo de movimiento CxP es un campo requerido',
			16,
			1
			)
	IF (SELECT DefinidoPorSistema  FROM CatTiposMovimientosCXP WHERE IdTipoMovimientoCXP = @IdTipoMovimientoCXP)  = 1
		RAISERROR(N'El tipo de movimiento se encuentra definido por sistema ',
			16,
			1
			)
			
	IF EXISTS(SELECT * FROM ProPagosProveedoresDocumentos WHERE IdTipoMovimientoCXP = @IdTipoMovimientoCXP)
		RAISERROR(N'El tipo de movimiento tiene pago a proveedores registrados',
			16,
			1
			)
	IF EXISTS(SELECT * FROM ProPasivos WHERE IdTipoMovimientoCXP = @IdTipoMovimientoCXP)
		RAISERROR(N'El tipo de movimiento tiene pasivos registrados',
			16,
			1
			)
		DELETE	FROM CatTiposMovimientosCXP	WHERE IdTipoMovimientoCXP = @IdTipoMovimientoCXP
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

