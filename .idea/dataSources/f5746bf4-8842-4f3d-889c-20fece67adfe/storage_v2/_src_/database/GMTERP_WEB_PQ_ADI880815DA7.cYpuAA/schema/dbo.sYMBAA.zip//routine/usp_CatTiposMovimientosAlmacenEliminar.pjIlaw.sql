CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosAlmacenEliminar]
@IdTipoMovimientoAlmacen int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdTipoMovimientoAlmacen,0)= 0
		RAISERROR(N'El identificador del tipo de movimiento es un campo requerido',
				16,
				1
			)

	IF (SELECT ISNULL(DefinidoPorSistema,0) from CatTiposMovimientosAlmacen where IdTipoMovimientoAlmacen = @IdTipoMovimientoAlmacen) <> 0 
		RAISERROR(N'Tipo de movimiento de almacén es definido por sistema, no es posible eliminar',
				16,
				1
				)

	IF (SELECT COUNT(IdTipoMovimientoAlmacen) FROM ProMovimientosAlmacen WHERE IdTipoMovimientoAlmacen = @IdTipoMovimientoAlmacen)<> 0
				RAISERROR(N'El tipo de movimiento almacén tiene ligados movimientos de almacen, no es posible eliminarlo',
				16,
				1
				)

		DELETE CatTiposMovimientosAlmacen	
		WHERE 	IdTipoMovimientoAlmacen=@IdTipoMovimientoAlmacen
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

