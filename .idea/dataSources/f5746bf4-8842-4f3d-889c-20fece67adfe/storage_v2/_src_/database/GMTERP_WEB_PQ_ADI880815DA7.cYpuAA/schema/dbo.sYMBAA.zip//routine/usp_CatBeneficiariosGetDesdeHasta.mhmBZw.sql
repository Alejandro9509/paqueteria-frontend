CREATE PROCEDURE [dbo].[usp_CatBeneficiariosGetDesdeHasta]

AS

SELECT ISNULL(MAX(NumeroBeneficiario),0) AS Hasta,ISNULL(MIN(NumeroBeneficiario),0) AS Desde 
FROM CatBeneficiarios
go

