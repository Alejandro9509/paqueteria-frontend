CREATE PROCEDURE [dbo].[usp_ProPasivosMaxFolioDocumento]    
AS    
Select ISNULL(MAX(FolioDocumento),0)+1 AS FolioDocumento from ProPasivos where SerieDocumento='SIN SERIE'
go

