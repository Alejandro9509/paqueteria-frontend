
CREATE PROCEDURE [dbo].[usp_SisCuentasCorreoModificarPQ](
	@IdCuentaCorreo int,
	@TipoCuenta int,
	@Servidor varchar(30),
	@Puerto int,
	@Usuario varchar(50),
	@Contrasenia varchar(100),
	@TipoCifrado int,
	@ModificadoEl datetime,
	@ModificadoPor int)
AS
BEGIN 
	BEGIN TRANSACTION
		IF ISNULL(@Puerto, 0) <= 0 begin
			RAISERROR(N'El Tipo de Cuenta es un campo requerido', 16, 1);
			return;
		end;
		IF ISNULL(@TipoCuenta, 0) <= 0 begin
			RAISERROR(N'El Tipo de Cuenta es un campo requerido', 16, 1);
			return;
		end;
		IF ISNULL(@Servidor, '') = '' begin
			RAISERROR(N'El servidor es un campo requerido', 16, 1);
			return;
		end;	
		IF ISNULL(@Puerto, 0) <= 0 begin
			RAISERROR(N'El Puerto es un campo requerido', 16, 1);
			return;
		end;
		IF ISNULL(@Usuario, '') = '' begin
			RAISERROR(N'El usuario es un campo requerido', 16, 1);
			return;
		end;
		IF ISNULL(@Contrasenia, '') = '' begin
			RAISERROR(N'La contraseña es un campo requerido', 16, 1);
			return;
		end;		
		IF ISNULL(@TipoCifrado, 0) <= 0 begin
			RAISERROR(N'El Tipo de Cifrado es un campo requerido', 16, 1);
			return;
		end;
		
		
		UPDATE SisCuentasCorreoPQ set 
		Servidor = @Servidor,
		TipoCuenta=@TipoCuenta,
		Puerto = @Puerto,
		Usuario = @Usuario,
		Contrasenia = @Contrasenia,
		TipoCifrado = @TipoCifrado,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor 
		where IdCuentasCorreo = @IdCuentaCorreo;

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END
go

