
CREATE PROCEDURE [dbo].[usp_ProLiquidacionesTPersonalGrabarTimbre]
	@IdLiquidacion int,
	@CadenaOriginal ntext,
	@SelloDigital ntext,	
	@XMLArchivo ntext,
	@FolioFiscalUUID varchar(36),
	@FechaTimbrado datetime,
	@NoSerieCertificadoSAT varchar(20),
	@SelloSAT ntext,
	@CadenaOriginalTimbrado ntext,
	@TimbrePruebas bit,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

	UPDATE ProLiquidacionesTPersonal
	SET FolioFiscalUUID = @FolioFiscalUUID,
		FechaTimbrado = @FechaTimbrado,
		NoSerieCertificadoSAT = @NoSerieCertificadoSAT,
		SelloSAT = @SelloSAT,
		CadenaOriginalTimbrado = @CadenaOriginalTimbrado,
		XMLArchivo = @XMLArchivo,
		TimbrePruebas = @TimbrePruebas,
		CadenaOriginal = @CadenaOriginal,
		SelloDigital = @SelloDigital
	WHERE IdLiquidacionTPersonal = @IdLiquidacion

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

