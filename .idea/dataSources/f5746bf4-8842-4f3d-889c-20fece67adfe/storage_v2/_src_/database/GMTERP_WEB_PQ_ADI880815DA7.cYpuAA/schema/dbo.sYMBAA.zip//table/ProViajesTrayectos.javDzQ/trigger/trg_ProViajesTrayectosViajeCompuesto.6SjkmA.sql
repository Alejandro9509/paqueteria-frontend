CREATE TRIGGER [dbo].[trg_ProViajesTrayectosViajeCompuesto]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE
AS
BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
		WHERE (I.CodigoUnidadCamion <> D.CodigoUnidadCamion 
		OR I.IdOperador <> D.IdOperador 
		OR I.IdUnidadCamion <> D.IdUnidadCamion
		OR I.NombreOperador <> D.NombreOperador 
		OR I.PlacasUnidadCamion <> D.PlacasUnidadCamion)
		AND ISNULL(D.EsCompuesto,0) = 1)
        RAISERROR(N'No puede modificarse el viaje/trayecto porque es un viaje compuesto',
            16,
            1
            )                
END
go

