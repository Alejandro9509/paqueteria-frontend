
CREATE PROCEDURE [dbo].[usp_ProSolicitudesViajesActualizarCantidadPedida]
    @IdSolicitudViaje INT,
    @CantidadPedida SMALLINT,
    @IdPeticion VARCHAR(100)
AS
DECLARE
      @CantidadPedidaAnterior INT
    , @Estatus TINYINT
BEGIN TRY
    BEGIN TRANSACTION
    
    IF NOT EXISTS(SELECT IdSolicitudViaje FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje)
        RAISERROR(N'Este registro fue eliminado por otro usuario',
            16,
            1
            )
        
    IF @CantidadPedida < 1 OR @CantidadPedida > 99
        RAISERROR(N'El numero de cartas porte a crear debe ser entre 1 o 99.',
            16,
            1
            )
    
    SELECT  @CantidadPedidaAnterior = CantidadPedida
          , @Estatus = Estatus
        FROM ProSolicitudesViajes
    WHERE IdSolicitudViaje = @IdSolicitudViaje;

    IF @Estatus = 3
        RAISERROR(N'Esta solicitud ya ha sido cancelada.',
        16,
        1
        )

    IF NOT ISNULL(@CantidadPedidaAnterior, -1) = -1
    BEGIN
        IF @CantidadPedidaAnterior > @CantidadPedida
        BEGIN
            DECLARE @Mensaje VARCHAR(100)
            SET @Mensaje = CONCAT('No es posible ingresar un número menor:', @CantidadPedida, ' al número de viajes ya registrados ', @CantidadPedidaAnterior)

            RAISERROR(@Mensaje,
                16,
                1
                )
        END
    END

    IF @Estatus = 1
    BEGIN
        -- Si la solicitud ya estaba aceptada pasa a incompleta
        UPDATE ProSolicitudesViajes
            SET 
                  Estatus = 4
                , CantidadPedida = @CantidadPedida
        WHERE IdSolicitudViaje = @IdSolicitudViaje
    END
    ELSE
    BEGIN
        UPDATE ProSolicitudesViajes
            SET 
                CantidadPedida = @CantidadPedida
        WHERE IdSolicitudViaje = @IdSolicitudViaje
    END
    
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

