CREATE PROCEDURE [dbo].[usp_ProFacturasAsociarXML]
	@SubTotal money,
	@Total money,
	@Descuento money,
	@Serie varchar(10),
	@Folio int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@XMLArchivo ntext,
	@FolioFiscalUUID varchar(36),
	@FechaTimbrado datetime,
	@NoSerieCertificadoSAT varchar(20),
	@SelloSAT ntext,
	@Emisor varchar(13),
	@CadenaOriginal ntext,
	@CadenaOriginalTimbrado ntext,
	@SelloDigital ntext,
	@IdMoneda int,
	@IdCliente int,
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money
AS
DECLARE
	@IdFolio int,
	@MensajeError varchar(MAX) = '',
	@RFC varchar(13)
BEGIN TRY
	BEGIN TRANSACTION
	
	--Se valida el Folio Fiscal que se asociara a la factura
	IF ISNULL(@FolioFiscalUUID,'') = ''
		SET @MensajeError = @MensajeError+'El Folio Fiscal del documento es requerido'+CHAR(10)

	--Se valida que existan la serie y el folio proporcionados
	SET @IdFolio = (SELECT IdFolio FROM CatFolios WHERE Serie = @Serie AND Folio = @Folio AND IdTipoDocumento = 2)
	IF ISNULL(@IdFolio,0) = 0
		SET @MensajeError ='No se encontró el folio '+(SELECT CAST(@Folio as varchar(10)))+' de la serie '+@Serie+CHAR(10)
		
	--Se valida que el Folio este ligado a una factura
	IF NOT EXISTS (SELECT IdFactura FROM ProFacturas WHERE IdFolio = @IdFolio)
		SET @MensajeError = @MensajeError+'No se encontró factura con la serie y folio proporcionados.'+CHAR(10)
			
	--Se valida que la factura ligada al folio sea por concepto	
	IF ISNULL((SELECT TipoFactura FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> 1
		SET @MensajeError = @MensajeError+'La factuara a la que intenta asociar el XML no es por concepto.'+CHAR(10)
			
	--Se valida que la factura ligada al folio no este Timbrada	
	IF ISNULL ((SELECT FolioFiscalUUID FROM ProFacturas WHERE IdFolio = @IdFolio),'') <> ''
		SET @MensajeError = @MensajeError+'La factuara a la que intenta asociar el XML ya se encuentra timbrada.'+CHAR(10)
		
	--Se valida que el FolioFiscal no este ligado a una factura
	IF ISNULL((SELECT FolioFiscalUUID FROM ProFacturas WHERE FolioFiscalUUID = @FolioFiscalUUID),'') <> ''
		SET @MensajeError = @MensajeError+'El folio fiscal que intenta asociar ya se encuentra registrado en otra factura.'+CHAR(10)

	--Se validan los datos de la factura a la que se esta intentando asociar el documento
	
	SET @RFC = (select ISNULL(cc.RFC,'') from CatCertificados as cc
		Inner Join CatFolios AS cf ON cc.IdCertificado = cf.IdCertificado
		WHERE cf.IdFolio = @IdFolio)
		
	IF (@RFC = '' AND @Emisor <> (Select RFC From SisParametros)) OR (@RFC <> '' AND @RFC <> @Emisor)
		SET @MensajeError = @MensajeError+'El RFC del emisor no corresponde al RFC asociado al certificado de la factura.'+CHAR(10)
	
	IF ISNULL((SELECT IdCliente FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> @IdCliente
		SET @MensajeError = @MensajeError+'El RFC del receptor no coincide con el cliente de la factura.'+CHAR(10)
	
	IF ISNULL((SELECT IdMoneda FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> @IdMoneda
		SET @MensajeError = @MensajeError+'La moneda de la factura no coincide con la del documento.'+CHAR(10)
	
	IF ISNULL((SELECT SubTotal FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> @SubTotal
		SET @MensajeError = @MensajeError+'El Subtotal de la factura no coincide con el del documento.'+CHAR(10)
	
	IF ISNULL((SELECT Descuento FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> @Descuento
		SET @MensajeError = @MensajeError+'El Descuento de la factura no coincide con el del documento.'+CHAR(10)
		
	IF ISNULL((SELECT Total FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> @Total
		SET @MensajeError = @MensajeError+'El Total de la factura no coincide con el del documento.'+CHAR(10)
		
	IF ISNULL((SELECT ImpuestosTrasladadosFederales FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> @ImpuestosTrasladadosFederales
		SET @MensajeError = @MensajeError+'El Total de impuestos trasladados de la factura no coincide con el del documento.'+CHAR(10)
		
	IF ISNULL((SELECT ImpuestosRetenidosFederales FROM ProFacturas WHERE IdFolio = @IdFolio),0) <> @ImpuestosRetenidosFederales
		SET @MensajeError = @MensajeError+'El Total de impuestos retenidos de la factura no coincide con el del documento.'+CHAR(10)
		
	IF @MensajeError <> ''
			RAISERROR(@MensajeError,
			16,
			1
			)

	UPDATE ProFacturas SET
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl,
		XMLArchivo = @XMLArchivo, 
		FolioFiscalUUID = @FolioFiscalUUID,
		FechaTimbrado = @FechaTimbrado,
		NoSerieCertificadoSAT = @NoSerieCertificadoSAT,
		SelloSAT = @SelloSAT,
		CadenaOriginal = @CadenaOriginal,
		CadenaOriginalTimbrado = @CadenaOriginalTimbrado,
		SelloDigital = @SelloDigital,
		UtileriaAsociar = 1
	WHERE IdFolio = @IdFolio
		
	COMMIT

END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

