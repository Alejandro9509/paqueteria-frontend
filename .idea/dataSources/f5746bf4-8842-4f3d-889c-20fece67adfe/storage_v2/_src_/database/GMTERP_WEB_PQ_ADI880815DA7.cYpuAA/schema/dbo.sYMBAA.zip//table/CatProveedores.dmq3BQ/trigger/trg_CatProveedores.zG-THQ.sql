CREATE TRIGGER [dbo].[trg_CatProveedores]
    ON [dbo].[CatProveedores]
    AFTER UPDATE
AS
BEGIN
    DECLARE @IdProveedor int
    
    SET @IdProveedor = (SELECT IdProveedor FROM deleted)

    IF EXISTS(SELECT TOP 1 IdProveedor FROM ProValesCombustible WHERE IdProveedor = @IdProveedor)
    BEGIN
        IF EXISTS(SELECT * FROM
        INSERTED I
        JOIN DELETED D ON D.RFC <> I.RFC)
        RAISERROR(N'El RFC ó Nombre Fiscal no puede modificarse porque tiene vales de combustible asignados',
            16,
            1
            )        
    END
    
    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
        IF EXISTS(SELECT * FROM CatCuentasContables WHERE CatalogoLigado = 'CatProveedores' AND IdCatalogoLigado = @IdProveedor)
        AND EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON D.NumeroProveedor <> I.NumeroProveedor)
        RAISERROR(N'El número de proveedor no puede modificarse porque tiene ligada cuentas contables',
            16,
            1
            )        
    END    
END
go

