CREATE PROCEDURE [dbo].[usp_ProEmbarqueEliminarPQ](
	@IdEmbarque int
	)
AS

BEGIN
	BEGIN TRANSACTION
		declare @ExisteGuia int;
		IF ISNULL(@IdEmbarque, '') = '' begin
			RAISERROR(N'*INICIO*El identificador de embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		select @ExisteGuia = count(*)
		from dbo.ProEmbarquePQ g
		where g.IdEmbarque = @IdEmbarque and (IdGuia is not null and IdGuia > 0);
		if @ExisteGuia > 0 begin
			RAISERROR(N'*INICIO*No es posible eliminar el embarque ya que tiene una guia asignada*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		select @ExisteGuia = count(*)
		from dbo.ProEmbarquePQ g
		where g.IdEmbarque = @IdEmbarque and IdEstatusEmbarque <> 21;
		if @ExisteGuia > 0 begin
			RAISERROR(N'*INICIO*Para eliminar el embarque es necesario que este cancelado*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		delete ProEmbarqueDetallePQ
		where IdEmbarque = @IdEmbarque;
        delete ProEmbarqueComplementosSATPQ WHERE IdEmbarque = @IdEmbarque;

		IF @@TRANCOUNT > 0
			BEGIN
				delete ProEmbarquePQ
				WHERE IdEmbarque = @IdEmbarque;

				IF @@TRANCOUNT > 0
				BEGIN
					COMMIT TRANSACTION
				end
				else
					GOTO CANCELAR_TRANSACCION
				end
			
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

