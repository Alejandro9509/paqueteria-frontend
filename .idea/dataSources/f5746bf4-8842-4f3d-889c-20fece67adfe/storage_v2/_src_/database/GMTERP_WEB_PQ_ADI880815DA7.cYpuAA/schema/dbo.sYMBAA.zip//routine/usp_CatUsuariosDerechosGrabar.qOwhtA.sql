CREATE PROCEDURE [dbo].[usp_CatUsuariosDerechosGrabar]
	@IdUsuario int,
	@dsCatUsuariosDerechos ntext,
	@CreadoPor int,
	@CreadoEl datetime,	
	@IdPeticion varchar(100)
	/* *************************************************************************************************
	Modificado por:   EDGAR RAMOS
	Solicitud:4124
	Fecha de Modificado: 05/04/2021
	Versión: 8.0.59.27

	Modificado por:   EDGAR RAMOS
	Solicitud:4660
	Fecha de Modificado: 28/09/2021
	Modificacion : Se modifico la forma en que se guardan los procesos , ahora son unicos por usuario.
	Versión: 8.0.65.10


	Invocada desde: GMTERPV8 --ClsCatUsuarios--GrabarDerechos
	************************************************************************************************ */
AS
DECLARE
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdUsuario,0) <= 0
		RAISERROR(N'El identificador del usuario es un campo requerido',
			16,
			1
			)
			
	IF @dsCatUsuariosDerechos IS NULL
		RAISERROR(N'Los derechos son requeridos',
			16,
			1
			)

	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUsuariosDerechos

	SELECT COL_IdProceso,COL_Derecho
	INTO #TempCatUsuariosDerechos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatUsuarioDerechos',2) 
	WITH (COL_IdProceso int,COL_Derecho bit)
	--WHERE COL_IdProceso NOT IN (SELECT COL_IdProceso FROM #TempCatUsuariosDerechos)
	
	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO CatUsuariosDerechos(IdUsuario,IdProceso,Derecho,CreadoEl,CreadoPor)
	SELECT @IdUsuario,COL_IdProceso,COL_Derecho,@CreadoEl,@CreadoPor FROM #TempCatUsuariosDerechos 
	WHERE COL_IdProceso NOT IN (SELECT IdProceso FROM CatUsuariosDerechos WHERE IdProceso = COL_IdProceso AND IdUsuario = @IdUsuario )
	GROUP BY COL_IdProceso,COL_Derecho
	
	UPDATE CatUsuariosDerechos SET
	CatUsuariosDerechos.Derecho = #TempCatUsuariosDerechos.COL_Derecho,
	CatUsuariosDerechos.ModificadoEl = @CreadoEl,
	CatUsuariosDerechos.ModificadoPor = @CreadoPor
	FROM CatUsuariosDerechos
	INNER JOIN #TempCatUsuariosDerechos ON CatUsuariosDerechos.IdUsuario = @IdUsuario AND CatUsuariosDerechos.IdProceso = #TempCatUsuariosDerechos.COL_IdProceso


	/*--Solicitud 4124 Se agrego esta linea para que al iniciar sesion se vuelva armar el menu,autocomplete y los accesos directos.*/
	UPDATE CatUsuarios SET 
	Menu= NULL,
	XMLAutoCompleteMenu = NULL,
	AccesosDirectos = NULL
	WHERE IdUsuario = @IdUsuario
	/*FIN DE LA SOLICITUD 4124*/
	
	DELETE FROM CatUsuariosDerechos WHERE IdUsuario = @IdUsuario AND (ModificadoEl <> @CreadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @CreadoEl
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

