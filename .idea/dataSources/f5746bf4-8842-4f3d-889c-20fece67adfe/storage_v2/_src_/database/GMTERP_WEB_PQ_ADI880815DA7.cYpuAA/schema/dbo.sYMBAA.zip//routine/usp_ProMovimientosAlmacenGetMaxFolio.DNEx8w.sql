CREATE PROCEDURE [dbo].[usp_ProMovimientosAlmacenGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen
go

