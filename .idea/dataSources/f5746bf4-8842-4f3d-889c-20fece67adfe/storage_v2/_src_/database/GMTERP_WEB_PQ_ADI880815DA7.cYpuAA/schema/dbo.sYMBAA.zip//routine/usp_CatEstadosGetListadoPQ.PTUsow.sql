
CREATE PROCEDURE [dbo].[usp_CatEstadosGetListadoPQ]
AS

SELECT TOP 33 * FROM CatEstados
go

