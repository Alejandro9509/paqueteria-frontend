CREATE PROCEDURE [dbo].[usp_SisGetListado]
	@SqlQuery VARCHAR(MAX),
	@Rows INT,
	@Page INT,
	@IdUsuario INT,
	@Sort VARCHAR(100)
AS
DECLARE 
@SqlQueryFinal VARCHAR(MAX),
	@ConsultaParametros nvarchar(max), 
	@ConsultaFinal nvarchar(max),
	@XmlResult varchar(max) 
BEGIN 
	SET @SqlQueryFinal = '
	with result as(
	SELECT 
	ROW_NUMBER() OVER (ORDER BY pv.IdViaje) AS RowNum,'
	+ @SqlQuery+
	' ) SELECT @XmlResult = 
	(
	SELECT (
	SELECT MAX(RowNum) from result) AS  TotalRows ,* from result
	WHERE result.RowNum BETWEEN (('+CAST(@Page AS VARCHAR(10))+'-1)*'+CAST(@Rows AS VARCHAR(10))+')+1
	AND '+CAST(@Rows AS VARCHAR(10))+'*('+CAST(@Page AS VARCHAR(10))+') '

	SET @ConsultaParametros = N'@XmlResult varchar(max) OUTPUT'
	SET @ConsultaFinal = N''+@SqlQueryFinal+@Sort+'FOR XML RAW (''Registro''), ROOT (''Consulta''))'
	--PRINT @SqlQueryFinal
	print @ConsultaFinal
	exec dbo.sp_executesql @ConsultaFinal,@ConsultaParametros,@XmlResult OUTPUT
	--SELECT ISNULL(@XmlResult,'') As Listado
	
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'ProViajesListadoOptimizado' AND IdUsuario = @IdUsuario)
		INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('ProViajesListadoOptimizado',@XmlResult,@IdUsuario)
	ELSE
		UPDATE SisParametrosPagina SET Parametros = @XmlResult WHERE Pagina = 'ProViajesListadoOptimizado' AND IdUsuario = @IdUsuario
		
END
go

