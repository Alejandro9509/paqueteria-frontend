CREATE PROCEDURE [dbo].[usp_ProOrdenCompraGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProOrdenCompra
go

