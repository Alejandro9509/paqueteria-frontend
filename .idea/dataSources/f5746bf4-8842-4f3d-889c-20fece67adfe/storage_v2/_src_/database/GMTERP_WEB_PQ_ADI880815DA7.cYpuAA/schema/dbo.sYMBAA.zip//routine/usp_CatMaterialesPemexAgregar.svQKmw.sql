CREATE PROC [dbo].[usp_CatMaterialesPemexAgregar]
    @Codigo int,
    @Descripcion varchar(30),
	@IdTipoMaterialPemex int,
	@PrecioUnitario money,
    @Activo bit,
    @CreadoEl datetime,
    @CreadoPor int,
    @ModificadoEl datetime,
    @ModificadoPor int,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatMaterialesPemexAgregar

Parámetros:
    @Codigo              (entrada, entero). Código del material PEMEX.
    @Descripcion         (entrada, texto). Descripción del material PEMEX.
	@IdTipoMaterialPemex (entrada, entero). Identificador del tipo material PEMEX
	@PrecioUnitario      (entrada, dinero). Cantidad del precio unitario del material.
    @Activo              (entrada, booleno). Bandera para saber si se encuentra activo el material PEMEX.
    @CreadoEl            (entrada, fecha hora). Fecha y hora en la que fue creado el registro.
    @CreadoPor           (entrada, entero). Id del usuario que creo el registro.
    @ModificadoEl        (entrada, fecha hora). Fecha y hora en la que fue modificado el registro.
    @ModificadoPor       (entrada, entero). Id del usuario que modifico el registro.
    @IdPeticion          (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para agregar un nuevo Material PEMEX.

07/02/2020 - Se creó.
21/02/2020 - Se cambió el tipo de dato de Precio Unitario a MONEY

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 07/02/2020
Versión ERP:

Modificada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 21/02/2020
Versión ERP: 8.0.50.12

Invocada desde: PAGE_CatMaterialesPemexAM (Solicitud 895)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
    -- Validaciones
    IF @Codigo = 0
        RAISERROR(N'El código del material es un campo requerido.', 16, 1)

	IF ISNULL(@Descripcion, '') = ''
        RAISERROR(N'El nombre del material es un campo requerido.', 16, 1)

	IF @IdTipoMaterialPemex = 0
		RAISERROR(N'El id del tipo de material es un campo requerido.', 16, 1)

	IF @PrecioUnitario = 0
		RAISERROR(N'El precio unitario es un campo requerido.', 16, 1)

    IF EXISTS(SELECT Codigo FROM CatMaterialesPemex WHERE Codigo = @Codigo)
        RAISERROR(N'Ya existe un material con el código ingresado, favor de ingresar otro código.', 16, 1)

    -- Inserta el registro y aplica el cambio
    INSERT INTO CatMaterialesPemex(Codigo, Descripcion, IdTipoMaterialPemex, PrecioUnitario, Activo, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
    VALUES(@Codigo, @Descripcion, @IdTipoMaterialPemex, @PrecioUnitario, @Activo, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor)

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

