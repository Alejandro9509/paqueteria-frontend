
CREATE PROCEDURE [dbo].[usp_CatOperadoresAplicacionesMovilesTokenLimpiar]	
	@Token varchar(max),
	@IdPeticion varchar(100),
	@IdOperador int = 0,
	@Aplicacion tinyint = 0
	/*************************************************************************************************************************************
	@Token varchar(max),
	@IdPeticion varchar(100),
	@IdOperador int = 0,
	@Aplicacion tinyint = 0

	Creado por:  Luis Edgar Ramos Cadena
	Fecha de Creacion: 16/03/2021
	Versión  Versión 8.0.59.10
	Solicitud 3939
	
	Se creo para limpiar el token del operador y aplicacion movil
	***************************************/
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF @IdOperador = 0 
		BEGIN
			UPDATE CatOperadoresAplicacionesMoviles SET
			Token = NULL,
			TokenIOS = NULL,
			Sistema = NULL
			WHERE Token = @Token
		END
		ELSE
		BEGIN
			DECLARE @IdAplicacion int
			SET @IdAplicacion = (SELECT IdAplicacionMovil FROM CatAplicacionesMoviles WHERE Aplicacion = @Aplicacion)
			UPDATE CatOperadoresAplicacionesMoviles SET
			Token = NULL,
			TokenIOS = NULL,
			Sistema = NULL,
			Dispositivo = NULL
			WHERE IdOperador = @IdOperador AND IdAplicacionMovil = @IdAplicacion
		END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

