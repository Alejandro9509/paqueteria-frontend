CREATE PROCEDURE [dbo].[usp_ProLiquidacionesGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProLiquidaciones WHERE LiquidacionPermisionario = 0
go

