CREATE PROCEDURE [dbo].[usp_CatClientesPaginado]
@pagina int,
@cantidadRegistros int
AS
BEGIN
DECLARE @skipReg int = @pagina * @cantidadRegistros

select
    cl.IdCliente as m_nIdCliente,
    cl.NumeroCliente as m_nNumeroCliente,
    cl.TipoCliente as m_nTipoCliente,
    cl.RFC as m_sRFC,
    cl.NombreFiscal as m_sNombreFiscal,
    cl.NombreCorto as m_sNombreCorto,
    cl.Activo as m_bActivo,
    cl.CodigoPostal as m_nIdCP,
    cl.CodigoPostal as m_sCodigoPostal,
    cl.IdEstado as m_nIdEstado,
    cl.Municipio as m_sMunicipio,
    cl.Localidad as m_sLocalidad,
    cl.Colonia as m_sColonia,
    cl.Calle as m_sCalle,
    cl.NoExterior as m_sNoExterior,
    cl.NoInterior as m_sNoInterior,
    cl.Telefono as m_sTelefono,
    cl.Celular as m_sCelular,
    cl.Celular as m_sTelefonoCelular,
    cl.Nextel as m_sNextel,
    cl.CorreoElectronico m_sCorreoElectronico,
    (case when cl.TieneSeguro is null or cl.TieneSeguro = 0 then CAST(0 AS BIT) else CAST(1 AS BIT) end) as m_bTieneSeguro,
    (case when cl.IdTipoSeguro is null then 0 else cl.IdTipoSeguro end) as m_nIdTipoSeguro,
    (case when cl.PorcentajeSeguro is null then 0 else cl.PorcentajeSeguro end) as m_cPorcentajeSeguro,
    cl.IdSucursal as m_nIdSucursal,
    cl.IdImpuestoTransladado as m_nIdImpuestoTransladado,
	(case when cl.SaldoCredito > 0 or cl.DiasCredito <= 0 then 1 else 0 end) as m_bCreditoVencido,
	(case when cl.SaldoCredito > 0 and cl.DiasCredito > 0 then 1 else 0 end) as m_bCreditoDisponible,
	(case when cl.SaldoCredito = 0 and cl.DiasCredito = 0 then 1 else 0 end) as m_bSinCredito,
	cl.DiasCredito as m_nDiasCredito,
    (select Sucursal from CatSucursales s where s.IdSucursal = cl.IdSucursal) as m_sNombreSucursal,
    (select IdPais from CatEstados e where e.IdEstado = cl.IdEstado) as m_nIdPais
from CatClientes cl
ORDER BY cl.IdCliente
OFFSET @skipReg ROWS
FETCH NEXT @cantidadRegistros ROWS ONLY

END
go

