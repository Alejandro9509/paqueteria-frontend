
CREATE trigger [dbo].[trg_ProViajesTrayectosDesligarPadre]
  on [dbo].[ProViajesTrayectos]
  for delete 
 as
 BEGIN
   Update ProViajesTrayectos SET ProViajesTrayectos.IdViajeTrayectoCompuestoPadre = NULL,ProViajesTrayectos.EsCompuesto=NULL
   from ProViajesTrayectos join DELETED 
   on ProViajesTrayectos.IdViajeTrayectoCompuestoPadre=DELETED.IdViajeTrayecto
END
go

