CREATE FUNCTION [dbo].[fnProBitacorasConducccionListado]
(	
	@FechaHoraInical datetime, 
	@FechaHoraFinal datetime
)
RETURNS TABLE 
AS
RETURN 
(
--NO MOVER EL ORDEN DE LAS COLUMNAS, PORQUE AFECTA LA PAGINA PAGE_ProBitacorasConduccionListado GMTERPV
SELECT Fecha,NumeroOperador,NombreOperador, 
[1] AS 'Conduciendo', 
[2] AS 'Pausa', 
[3] AS 'Actividades Auxiliares', 
[4] AS 'Casos de Excepción', 
[5] AS 'Descanso', 
[6] AS 'Fuera de Servicio',
IdOperador
FROM           
	(SELECT        
	CAST(dbo.fnConvertFechaHoraUTCToLocal(ISNULL(CS.ZonaHoraria, - 8), PBC.FechaHoraInicialUTC, ISNULL(CS.DescripcionZonaHoraria, '(UTC-08:00)	Baja California')) AS DATE) AS Fecha, 
	dbo.fnNumPadLeft(CO.NumeroOperador, 6) AS NumeroOperador, 
	CO.Nombre AS NombreOperador, 
	DATEDIFF(MINUTE, dbo.fnConvertFechaHoraUTCToLocal(ISNULL(CS.ZonaHoraria, - 8), PBC.FechaHoraInicialUTC,ISNULL(CS.DescripcionZonaHoraria, '(UTC-08:00)	Baja California')), 
	dbo.fnConvertFechaHoraUTCToLocal(ISNULL(CS.ZonaHoraria, - 8), ISNULL(PBC.FechaHoraFinalUTC, GETUTCDATE()), ISNULL(CS.DescripcionZonaHoraria, '(UTC-08:00)	Baja California'))) AS Tiempo, 
	PBC.Accion,PBC.IdOperador
	FROM dbo.ProBitacorasConduccion AS PBC 
	INNER JOIN  dbo.CatOperadores AS CO ON PBC.IdOperador = CO.IdOperador 
	LEFT OUTER JOIN dbo.CatSucursales AS CS ON CO.IdSucursal = CS.IdSucursal
	WHERE PBC.FechaHoraInicialUTC BETWEEN @FechaHoraInical AND @FechaHoraFinal
	OR ISNULL(PBC.FechaHoraFinalUTC,GETUTCDATE()) BETWEEN @FechaHoraInical AND @FechaHoraFinal
	) AS pvtProBitacorasConduccion 
PIVOT (SUM(Tiempo) FOR Accion IN ([1], [2], [3], [4], [5], [6])) AS pvt
)
go

