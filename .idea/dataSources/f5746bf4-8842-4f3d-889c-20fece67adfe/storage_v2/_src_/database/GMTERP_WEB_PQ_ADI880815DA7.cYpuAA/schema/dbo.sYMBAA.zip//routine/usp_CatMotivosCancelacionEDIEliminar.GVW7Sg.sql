create  PROCEDURE [dbo].[usp_CatMotivosCancelacionEDIEliminar]
@IdMotivoCancelacionEDI int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMotivoCancelacionEDI,0)= 0
	RAISERROR(N'El identificador de motivo de cancelación EDI es un campo requerido',
			16,
			1
			)


	IF NOT EXISTS(SELECT IdMotivoCancelacionEDI FROM CatMotivosCancelacionEDI   WHERE IdMotivoCancelacionEDI = @IdMotivoCancelacionEDI)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)
						
			
		DELETE CatMotivosCancelacionEDI  	
		WHERE IdMotivoCancelacionEDI=@IdMotivoCancelacionEDI
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

