CREATE PROCEDURE [dbo].[usp_CatTablaValoresEliminar]
	@IdTablaValor INT,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Procedimiento usp_CatTablaValoresEliminar

Parámetros: 
	@@IdTablaValor (entrada, entero). Id del valor de calculo
	@IdPeticion	   (entrada, string). Id de la Petición, generada en WEBDEV 	
 
Descripción: Procedimiento para eliminar un valor de caluclo

20/05/2020 - Se agrego validación para que no te permita borrar el registro si esta ligado a una liquidación

Implementada por: Jesús Humberto Morales
Fecha de implementacion: 12/05/2020
Versión ERP: 8.0.52.05

Modificada por: Jesús Humberto Morales 
Fecha de mofidicacion: 20/05/2020
Versión ERP: 8.0.52.21

Invocada desde: PAGE_ProActivosFijosListado (Solicitud 713)
***************************************************************************************************** */

AS
BEGIN TRY
	BEGIN TRANSACTION
		
		IF EXISTS(SELECT TOP 1 * FROM ProViajesTrayectos WHERE IdTablaValores = @IdTablaValor)
			RAISERROR(N'No es posible eliminar el valor para cálculo ya que se encuentra en una liquidación', 16, 1)

		DELETE FROM CatTablaValores
		WHERE IdTablaValores = @IdTablaValor
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

