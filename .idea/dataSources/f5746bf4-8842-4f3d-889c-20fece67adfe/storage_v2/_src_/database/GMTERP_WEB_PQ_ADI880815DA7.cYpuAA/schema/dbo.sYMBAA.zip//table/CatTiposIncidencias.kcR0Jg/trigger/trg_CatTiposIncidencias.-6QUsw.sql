create TRIGGER [dbo].[trg_CatTiposIncidencias]
   ON  [dbo].[CatTiposIncidencias]
   AFTER UPDATE
AS 
BEGIN	
	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I INNER JOIN DELETED D ON I.IdTipoIncidencia = D.IdTipoIncidencia
					  WHERE 
						I.Codigo <> D.Codigo OR					
						I.Mnemonico <> D.Mnemonico OR
						I.DerechoSueldo <> D.DerechoSueldo OR
						I.PorcentajeSueldo <> D.PorcentajeSueldo OR
						I.TipoImss <> D.TipoImss OR
						I.TipoIncidencia <> D.TipoIncidencia OR
						I.DerechoSeptimoDia <> D.DerechoSeptimoDia OR 
						I.ValorUnidad <> D.ValorUnidad
					  )
			RAISERROR(N'El tipo de incidencia no puede ser modificado porque esta definido por sistema',
				16,
				1
				)
	END		
END
go

