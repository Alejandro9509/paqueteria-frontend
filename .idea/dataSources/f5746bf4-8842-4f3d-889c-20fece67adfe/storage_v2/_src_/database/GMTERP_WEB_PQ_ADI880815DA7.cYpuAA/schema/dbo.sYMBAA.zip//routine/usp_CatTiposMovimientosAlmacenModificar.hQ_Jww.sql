CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosAlmacenModificar]
@IdTipoMovimientoAlmacen	int,
@Codigo	int,	
@Movimiento	varchar(50),	
@Tipo	varchar(50),
@Folio	int,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdTipoMovimientoAlmacen,0)= 0
			RAISERROR(N'El identificador del tipo de movimiento es un campo requerido',
				16,
				1
				)

	IF (SELECT ISNULL(DefinidoPorSistema,0) from CatTiposMovimientosAlmacen where IdTipoMovimientoAlmacen = @IdTipoMovimientoAlmacen) <> 0 
		RAISERROR(N'Tipo de movimiento de almacén es definido por sistema, no es posible modificar',
				16,
				1
				)
				
	IF ISNULL(@Codigo,0)= 0
			RAISERROR(N'El código del tipo de movimiento es un campo requerido',
				16,
				1
				)
			
	IF ISNULL(@Movimiento,'')= ''
		RAISERROR(N'El nombre del tipo de movimiento es un campo requerido',
			16,
			1
			)
			
	UPDATE CatTiposMovimientosAlmacen SET
	Codigo= @Codigo,
	Movimiento= @Movimiento,
	Tipo= @Tipo,
	Folio= @Folio,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor
	WHERE 	IdTipoMovimientoAlmacen=@IdTipoMovimientoAlmacen
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

