
CREATE PROCEDURE [dbo].[usp_CatSucursalesEliminarPQ]
	@IdSucursal INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdSucursal,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de la sucursal es un campo requerido*FIN*', 16, 1)
			return
		end
		DELETE FROM CatSucursales
		WHERE IdSucursal = @IdSucursal
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

