CREATE TRIGGER [dbo].[trg_ProViajesDescripcionesCargaLiquidados]
	ON [dbo].[ProViajesDescripcionesCarga]
	AFTER UPDATE
AS
BEGIN
	DECLARE @ParametroPermitirModificarImporteBaseLiq7 bit 
	SET @ParametroPermitirModificarImporteBaseLiq7 = (Select  Valor  from SisParametrosValores Where Parametro = 'PermitirModificarImporteBaseLiq7')
	
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViajeDescripcionCarga = D.IdViajeDescripcionCarga
        WHERE (I.ImporteBaseLiquidacion <> D.ImporteBaseLiquidacion OR I.ImporteLiquidar <> D.ImporteLiquidar OR I.Peso <> D.Peso OR I.Cantidad <> D.Cantidad)
        AND (SELECT CerradaEl FROM ProLiquidaciones WHERE TipoLiquidacion = 7 AND IdLiquidacion IN (SELECT IdLiquidacion FROM ProViajesTrayectos WHERE IdViaje = I.IdViaje)) IS NOT NULL)
        RAISERROR(N'No puede modificarse las descripciones de carga del viaje porque esta liquidado',
            16,
            1
            )
            
        --seccion se puso por la solicitud 10210
 		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViajeDescripcionCarga = D.IdViajeDescripcionCarga
        WHERE (I.ImporteBaseLiquidacion <> D.ImporteBaseLiquidacion) AND (@ParametroPermitirModificarImporteBaseLiq7 = 1)
        AND (SELECT CerradaEl FROM ProLiquidaciones WHERE IdLiquidacion IN (SELECT IdLiquidacion FROM ProViajesTrayectos WHERE IdViaje = I.IdViaje)) IS NOT NULL)
        RAISERROR(N'No puede modificarse el Importe Base a Liquidar porque uno de los trayectos esta liquidado',
            16,
            1
            )       
END
go

