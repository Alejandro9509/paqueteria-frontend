CREATE TRIGGER [dbo].[trg_ProViajesTrayectosLiquidados]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE
AS
BEGIN

		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
		WHERE (I.CodigoUnidadCamion <> D.CodigoUnidadCamion OR 
		I.IdDestino <> D.IdDestino OR 
		I.IdOperador <> D.IdOperador OR 
		I.IdOrigen <> D.IdOrigen OR 
		I.IdUnidadCamion <> D.IdUnidadCamion OR 
		I.NombreOperador <> D.NombreOperador OR 
		I.PlacasUnidadCamion <> D.PlacasUnidadCamion OR
		I.Kilometros <> D.Kilometros OR
		I.IdLiquidacion <> D.IdLiquidacion OR
		I.ImporteLiquidar <> D.ImporteLiquidar OR
		I.Llegada <> D.Llegada OR
		I.PorcentajeLiquidar <> D.PorcentajeLiquidar OR
		I.Salida <> D.Salida OR
		I.CargadoVacioUnidadCarga1 <> D.CargadoVacioUnidadCarga1 OR
		I.CargadoVacioUnidadCarga2 <> D.CargadoVacioUnidadCarga2) AND (SELECT CerradaEl FROM ProLiquidaciones WHERE IdLiquidacion = (SELECT IdLiquidacion FROM ProViajesTrayectos WHERE IdViajeTrayecto = I.IdViajeTrayecto)) IS NOT NULL)
        RAISERROR(N'No puede modificarse el viaje/trayectos porque está liquidado',
            16,
            1
            )                
END
go

