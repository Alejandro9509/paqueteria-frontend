
CREATE PROCEDURE [dbo].[usp_CatTiposCambioAgregarPQ](
	@Fecha Datetime,
	@TipoCambio Money,
	@CreadoEl Datetime,
	@CreadoPor int, 
	@ModificadoEl Datetime,
	@ModificadoPor int)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Fecha, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			return
		end
		
		IF ISNULL(@TipoCambio, '') = '' begin
			RAISERROR(N'*INICIO*El Tipo de cambio es un campo requerido*FIN*', 16, 1)
			return
		end
		
		INSERT INTO CatTiposCambioPQ (Fecha, TipoCambio,CreadoEl, CreadoPor,ModificadoEl,ModificadoPor)
		VALUES (@Fecha, @TipoCambio,@CreadoEl, @CreadoPor,@ModificadoEl,@ModificadoPor)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH

go

