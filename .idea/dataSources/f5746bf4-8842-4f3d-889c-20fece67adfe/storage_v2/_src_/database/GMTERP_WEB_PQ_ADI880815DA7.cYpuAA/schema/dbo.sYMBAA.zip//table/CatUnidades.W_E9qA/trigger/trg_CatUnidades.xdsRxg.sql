CREATE TRIGGER [dbo].[trg_CatUnidades]
   ON  [dbo].[CatUnidades]
   AFTER UPDATE
AS 
BEGIN
 DECLARE @IdUnidad int

 SET @IdUnidad = (SELECT IdUnidad FROM deleted)
 
 IF EXISTS(Select Top 1 IdViaje from ProViajes Where IdUnidadCarga1 = @IdUnidad OR IdUnidadCarga2 = @IdUnidad OR IdUnidadContenedor1 = @IdUnidad OR IdUnidadContenedor2 = @IdUnidad OR IdUnidadDolly = @IdUnidad) 
 OR EXISTS(SELECT TOP 1 IdViajeTrayecto FROM ProViajesTrayectos WHERE IdUnidadCamion = @IdUnidad)
 OR EXISTS(SELECT TOP 1 IdValeCombustible FROM ProValesCombustible WHERE IdUnidad = @IdUnidad)
 BEGIN
  IF EXISTS(SELECT * FROM
        INSERTED I
        INNER JOIN DELETED D ON I.IdUnidad = D.IdUnidad
        WHERE -- Se comentaron las validaciones de IdTipoUnidad y IdSucursa para la Solicitud 009940
        --(D.IdTipoUnidad <> I.IdTipoUnidad AND (SELECT d1.Identificador FROM CatTiposUnidades AS d1 WHERE d1.IdTipoUnidad = D.IdTipoUnidad) <> (SELECT i1.Identificador FROM CatTiposUnidades AS i1 WHERE i1.IdTipoUnidad = I.IdTipoUnidad))OR 
       -- D.IdSucursal <> I.IdSucursal OR 
        I.Codigo <> D.Codigo)
  RAISERROR(N'No puede modificarse el tipo de unidad,la sucursal y el código porque tiene viajes asignados',
   16,
   1
   )
-- Se comentaron las validaciones para la Solicitud 1184
  --IF EXISTS(SELECT * FROM
  --      INSERTED I
  --      INNER JOIN DELETED D ON I.IdUnidad = D.IdUnidad
  --      WHERE D.EsUnidadPermisionario <> I.EsUnidadPermisionario)
  --RAISERROR(N'No puede modificarse el check de "Es unidad de un permisionario" porque tiene viajes asignados',
  -- 16,
  -- 1
  -- )
 END 
 
END
go

