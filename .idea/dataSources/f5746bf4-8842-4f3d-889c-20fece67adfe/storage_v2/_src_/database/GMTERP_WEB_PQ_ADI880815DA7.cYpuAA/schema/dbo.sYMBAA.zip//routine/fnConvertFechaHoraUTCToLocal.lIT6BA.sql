
CREATE FUNCTION [dbo].[fnConvertFechaHoraUTCToLocal](@ZonaHoraria int,@FechaHoraUTC datetime,@DescripcionZonaHoraria varchar(100))
RETURNS datetime
AS BEGIN
	DECLARE @FechaHoraLocal datetime,		
		@TimeZone varchar(6) = '00'

		SET @TimeZone = '-'+LEFT(@TimeZone,2-LEN(CAST(@ZonaHoraria*-1 as varchar)))+CAST(@ZonaHoraria*-1 as varchar)+':00'

		SET @FechaHoraLocal = (SWITCHOFFSET (CAST(@FechaHoraUTC AS datetimeoffset(3)), @TimeZone))

		IF EXISTS(SELECT * FROM CatHorariosVerano WHERE DescripcionZonaHoraria = @DescripcionZonaHoraria AND @FechaHoraLocal BETWEEN Inicio AND Fin)
		BEGIN
			SET @TimeZone = '00'
			SET @ZonaHoraria = @ZonaHoraria + 1
			SET @TimeZone = '-'+LEFT(@TimeZone,2-LEN(CAST(@ZonaHoraria*-1 as varchar)))+CAST(@ZonaHoraria*-1 as varchar)+':00'
			SET @FechaHoraLocal = (SWITCHOFFSET (CAST(@FechaHoraUTC AS datetimeoffset(3)), @TimeZone))			
		END


	RETURN @FechaHoraLocal
END
go

