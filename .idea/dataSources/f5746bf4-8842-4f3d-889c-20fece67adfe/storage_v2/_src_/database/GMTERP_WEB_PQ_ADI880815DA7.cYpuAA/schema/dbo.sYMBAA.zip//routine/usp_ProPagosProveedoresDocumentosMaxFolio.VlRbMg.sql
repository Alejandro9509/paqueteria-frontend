CREATE PROCEDURE [dbo].[usp_ProPagosProveedoresDocumentosMaxFolio]      
AS      
Select ISNULL(MAX(Folio),0)+1 AS Folio from ProPagosProveedoresDocumentos
go

