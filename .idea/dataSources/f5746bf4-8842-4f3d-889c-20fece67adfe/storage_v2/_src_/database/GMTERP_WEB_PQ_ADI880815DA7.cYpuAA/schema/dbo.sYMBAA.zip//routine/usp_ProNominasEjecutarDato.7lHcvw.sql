CREATE PROCEDURE [dbo].[usp_ProNominasEjecutarDato]
@Query	ntext		
AS
EXECUTE  dbo.sp_executesql @Query
go

