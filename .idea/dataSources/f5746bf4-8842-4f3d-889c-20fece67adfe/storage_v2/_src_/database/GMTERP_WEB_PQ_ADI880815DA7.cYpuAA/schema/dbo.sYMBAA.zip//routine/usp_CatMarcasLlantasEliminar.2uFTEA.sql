
CREATE PROCEDURE [dbo].[usp_CatMarcasLlantasEliminar]
@IdMarcaLlanta int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMarcaLlanta,0)= 0
	RAISERROR(N'El identificador de la marca de llanta es un campo requerido',
			16,
			1
			)
   IF EXISTS(SELECT TOP 1 * FROM CatModelosLlantas WHERE IdMarcaLlanta = @IdMarcaLlanta)
		RAISERROR(N'La Marca tiene Modelos asignados, no es posible eliminarla',
			16,
			1
			)									
			
		DELETE CatMarcasLlantas		
		WHERE IdMarcaLlanta=@IdMarcaLlanta
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

