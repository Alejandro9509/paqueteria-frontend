CREATE PROCEDURE [dbo].[usp_CatCuentasContablesAgregar]
	@Codigo varchar(25),
	@Nombre varchar(150), 
	@TipoCuenta tinyint,
	@CuentaMayor tinyint,
	@IdCuentaContablePadre int,
	@Activa bit,
	@CreadoPor int, 
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@IdCuentaContableSAT int,
	@IdRubroNIF int,
	@Nivel int,
	@IdMoneda int
AS
/*
MODIFICADO:
	Se agregaro un exec usp_CatCuentasContablesSaldosAgregar
	para agregar la nueva cuenta contable al catalogo CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-30
SOLICITUD: 
	SOLICITUD 000266
*/
BEGIN TRY
	BEGIN TRANSACTION

	IF LTRIM(RTRIM(@Codigo)) = ''
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Codigo FROM CatCuentasContables WHERE Codigo = @Codigo)
		RAISERROR(N'El código de la cuenta contable ya está registrado en el catálogo',
			16,
			1
			)

	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El nombre de la cuenta contable es un campo requerido',
			16,
			1
			)

	IF ISNULL(@CuentaMayor,0) < 1 OR ISNULL(@CuentaMayor,0) > 4
		RAISERROR(N'El campo cuenta de mayor debe ser 1)Mayor o 2)Afectable o 3)Título o 4)Subtítulo',
			16,
			1
			)	

	IF ISNULL(@TipoCuenta,0) < 1 OR ISNULL(@TipoCuenta,0) > 10
		RAISERROR(N'El campo tipo de cuenta debe ser 1-Activo Deudora o 2-Activo Acreedora o 3-Pasivo Deudora o 4-Pasivo Acreedora o 5-Capital Deudora o 6-Capital Acreedora o 7-Resultado Deudora o 8-Resultado Acreedora o 9-Orden Deudora o 10-Orden Acreedora',
			16,
			1
			)	
	
	IF @CuentaMayor IN(1,2,4) AND @IdCuentaContablePadre = 0
		RAISERROR(N'El campo subcuenta de es un campo requerido',
			16,
			1
			)
	
	--se valida que la cuenta de mayor tenga una cuenta padre diferente de afectable
	IF @CuentaMayor = 1 AND (SELECT CuentaMayor FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContablePadre) = 2
		RAISERROR(N'El campo subcuenta de es tipo afectable',
			16,
			1
			)

	--se valida que la cuenta de afectable tenga una cuenta padre de mayor
	IF @CuentaMayor = 2 AND (SELECT CuentaMayor FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContablePadre) <> 1
		RAISERROR(N'El campo subcuenta de no es de mayor',
			16,
			1
			)

	--se valida que la cuenta de subtitulo tenga una cuenta padre de titulo
	IF @CuentaMayor = 4 AND (SELECT CuentaMayor FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContablePadre) <> 3
		RAISERROR(N'El campo subcuenta de no es de título',
			16,
			1
			)
			
	IF @CuentaMayor = 3
		SET @IdCuentaContablePadre = NULL	
		
	IF @IdCuentaContableSAT = 0
		SET @IdCuentaContableSAT = NULL		
	
	IF @IdRubroNIF = 0
		SET @IdRubroNIF = NULL	

	IF @Nivel = 0
		SET @Nivel = NULL
		
	IF @IdMoneda = 0
		SET @IdMoneda = NULL	

	--------------Heredar La Moneda de La cuenta Padre---------------------
	If @CuentaMayor = 2 --Afectable
	BEGIN
		Set @IdMoneda = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContablePadre)
	END 
	---------------Si es Cuenta De Titulo O Subtitulo-------------------
	If @CuentaMayor = 3 Or @CuentaMayor = 4
	BEGIN
		Set @IdMoneda = (Select IdMoneda From CatMonedas Where Moneda = 'PESOS')
	END 
    ----------------------------------------------------------		
						
	INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,IdCuentaContableSAT,IdRubroNIF,Nivel,IdMoneda)
	VALUES(@Activa,@Codigo,@CreadoEl,@CreadoPor,@CuentaMayor,@IdCuentaContablePadre,@Nombre,@TipoCuenta,@IdCuentaContableSAT,@IdRubroNIF,@Nivel,@IdMoneda)
	

	/*Se registra en el catalogo CatCuentasContablesSaldos*/
	EXEC usp_CatCuentasContablesSaldosAgregar @IdPeticion,@IdMoneda
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

