CREATE PROCEDURE [dbo].[usp_CatMarcasLlantasAgregar]

@Codigo int,    
@Descripcion varchar(50),
@CreadoEl    datetime,    
@CreadoPor    int,
@Activo       bit,    
@IdPeticion varchar(100)        
AS
BEGIN TRY
    BEGIN TRANSACTION
    IF ISNULL(@Codigo,0)= 0
        RAISERROR(N'El código de la Marca de llanta es un campo requerido',
            16,
            1
            )
            
   	IF EXISTS(SELECT Codigo FROM CatMarcasLlantas WHERE Codigo = @Codigo)
		RAISERROR(N'El código de la Marca de llanta ya existe',
			16,
			1
			)         
            
    IF ISNULL(@Descripcion,'')= ''
        RAISERROR(N'La descripcion de la Marca de llanta es un campo requerido',
            16,
            1
            )
    INSERT INTO CatMarcasLlantas(Codigo,DescripcionMarca,CreadoEl,CreadoPor,Activo)
    VALUES(@Codigo,@Descripcion,@CreadoEl,@CreadoPor,@Activo)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

