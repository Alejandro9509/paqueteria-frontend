CREATE TRIGGER [dbo].[trg_ProViajesTrayectosConSalida]
	ON dbo.ProViajesTrayectos
	AFTER UPDATE
AS
BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
        INNER JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
        WHERE (upper(I.CodigoUnidadCamion) <> upper(D.CodigoUnidadCamion) OR I.IdDestino <> D.IdDestino
        OR I.IdOperador <> D.IdOperador OR I.IdOrigen <> D.IdOrigen OR I.IdUnidadCamion <> D.IdUnidadCamion
        OR I.NombreOperador <> D.NombreOperador OR ISNULL(upper(I.PlacasUnidadCamion),'') <> ISNULL(upper(D.PlacasUnidadCamion),''))
        AND D.Salida IS NOT NULL)
        RAISERROR(N'No puede modificarse el viaje trayecto porque ya tiene registrada la salida',
            16,
            1
            )                  
END
go

