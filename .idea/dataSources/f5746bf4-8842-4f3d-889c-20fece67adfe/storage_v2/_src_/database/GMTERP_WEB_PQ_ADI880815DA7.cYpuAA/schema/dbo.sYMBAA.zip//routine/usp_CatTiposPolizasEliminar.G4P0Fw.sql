CREATE PROCEDURE [dbo].[usp_CatTiposPolizasEliminar]
	@IdTipoPoliza int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM ProPolizas WHERE IdTipoPoliza = @IdTipoPoliza)
		RAISERROR(N'El tipo de póliza ya tiene pólizas referenciadas, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM CatPrepolizas WHERE IdTipoPoliza = @IdTipoPoliza)
		RAISERROR(N'El tipo de póliza ya tiene prepólizas referenciadas, no es posible eliminarlo',
			16,
			1
			)			
			
	IF (SELECT DefinidoPorSistema FROM CatTiposPolizas WHERE IdTipoPoliza = @IdTipoPoliza) = 1
		RAISERROR(N'El tipo de póliza está definido por sistema, no es posible eliminarlo',
			16,
			1
			)				
				
	DELETE FROM CatTiposPolizas
	WHERE IdTipoPoliza = @IdTipoPoliza
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

