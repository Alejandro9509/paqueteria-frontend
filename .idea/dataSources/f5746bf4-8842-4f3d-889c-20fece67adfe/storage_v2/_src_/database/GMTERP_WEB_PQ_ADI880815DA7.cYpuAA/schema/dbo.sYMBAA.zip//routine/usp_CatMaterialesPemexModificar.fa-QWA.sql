CREATE PROC [dbo].[usp_CatMaterialesPemexModificar]
    @IdMaterialPemex int,
    @Codigo int,
    @Descripcion varchar(30),
	@IdTipoMaterialPemex int,
	@PrecioUnitario money,
    @Activo bit,
    @ModificadoEl datetime,
    @ModificadoPor int,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatMaterialesPemexModificar

Parámetros:
    @IdMaterialPemex     (entrada, entero). Id del material PEMEX.
    @Codigo              (entrada, entero). Código del material PEMEX.
    @Descripcion         (entrada, texto). Descripción del material PEMEX.
	@IdTipoMaterialPemex (entrada, entero). Identificador del tipo de material PEMEX
	@PrecioUnitario      (entrada, dinero). Cantidad del precio unitario del material.
    @Activo              (entrada, booleno). Bandera para saber si se encuentra activo el tipo de material PEMEX.
    @ModificadoEl        (entrada, fecha hora). Fecha y hora en la que fue modificado el registro.
    @ModificadoPor       (entrada, entero). Id del usuario que modifico el registro.
    @IdPeticion          (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento que modifica los valores de un Material PEMEX.

10/02/2020 - Se creó.
21/02/2020 - Se cambió el tipo de dato de Precio Unitario a MONEY.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 10/02/2020
Versión ERP:

Modificada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 21/02/2020
Versión ERP: 8.0.50.12

Invocada desde: PAGE_CatMaterialesPemexAM (Solicitud 896)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION

    -- Validaciones
	IF @IdMaterialPemex = 0
        RAISERROR(N'El id del material es un campo requerido', 16, 1)

    IF @Codigo = 0
        RAISERROR(N'El código del material es un campo requerido.', 16, 1)

	IF ISNULL(@Descripcion, '') = ''
        RAISERROR(N'El nombre del material es un campo requerido.', 16, 1)

	IF @IdTipoMaterialPemex = 0
		RAISERROR(N'El id del tipo de material es un campo requerido.', 16, 1)

	IF @PrecioUnitario = 0
		RAISERROR(N'El precio unitario es un campo requerido.', 16, 1)

    -- Modifica el registro
    UPDATE CatMaterialesPemex SET
    Codigo = @Codigo,
    Descripcion = @Descripcion,
	IdTipoMaterialPemex = @IdTipoMaterialPemex,
	PrecioUnitario = @PrecioUnitario,
    Activo = @Activo,
    ModificadoEl = @ModificadoEl,
    ModificadoPor = @ModificadoPor 
    WHERE IdMaterialPemex = @IdMaterialPemex

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

