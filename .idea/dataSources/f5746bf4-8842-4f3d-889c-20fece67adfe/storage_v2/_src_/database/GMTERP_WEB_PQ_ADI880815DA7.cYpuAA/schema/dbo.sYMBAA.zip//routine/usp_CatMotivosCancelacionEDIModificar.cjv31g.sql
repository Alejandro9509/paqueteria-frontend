create PROCEDURE [dbo].[usp_CatMotivosCancelacionEDIModificar]
@IdMotivoCancelacionEDI int,
@Codigo int,    
@Descripcion varchar(100),
@TextoLibre varchar(2000),
@UltimaModificacion datetime,
@ModificadoEl    datetime,    
@ModificadoPor    int,
@IdPeticion varchar(100)        
AS
BEGIN TRY
    BEGIN TRANSACTION
   	
	IF ISNULL(@IdMotivoCancelacionEDI,0)= 0
	RAISERROR(N'El identificador de motivo de cancelación EDI es un campo requerido',
			16,
			1
			)
			

	IF NOT EXISTS(SELECT IdMotivoCancelacionEDI FROM CatMotivosCancelacionEDI   WHERE IdMotivoCancelacionEDI = @IdMotivoCancelacionEDI)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM CatMotivosCancelacionEDI WHERE IdMotivoCancelacionEDI = @IdMotivoCancelacionEDI) <> @UltimaModificacion
		RAISERROR(N'Los datos de motivo de cancelación EDI fueron modificados por otro usuario. salga sin grabar sus cambios y revise.',
			16,
			1
			)	
						
			 
    IF ISNULL(@Codigo,0)= 0
        RAISERROR(N'El código de motivo de cancelación EDI es un campo requerido',
            16,
            1
            )
            
   	IF EXISTS(SELECT Codigo FROM CatMotivosCancelacionEDI WHERE Codigo = @Codigo and IdMotivoCancelacionEDI <> @IdMotivoCancelacionEDI)
		RAISERROR(N'El código de motivo de cancelación EDI ya existe',
			16,
			1
			)         
            
    IF ISNULL(@Descripcion,'')= ''
        RAISERROR(N'La descripcion de motivo de cancelación EDI es un campo requerido',
            16,
            1
            )
            

			
	UPDATE CatMotivosCancelacionEDI SET
	Codigo= @Codigo,
	Descripcion= @Descripcion,
	TextoLibre= @TextoLibre,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor
	WHERE IdMotivoCancelacionEDI = @IdMotivoCancelacionEDI
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

