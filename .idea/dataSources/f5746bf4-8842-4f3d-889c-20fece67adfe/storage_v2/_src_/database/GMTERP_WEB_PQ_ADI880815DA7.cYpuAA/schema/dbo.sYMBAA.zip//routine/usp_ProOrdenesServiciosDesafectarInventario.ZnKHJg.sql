CREATE PROCEDURE [dbo].[usp_ProOrdenesServiciosDesafectarInventario]
@IdOrdenServicioDetalle   int,
@dsOrdenesServiciosPartes ntext,
@CreadoEl				  datetime,
@CreadoPor				  int,
@IdPeticion				  varchar(100)

/* *************************************************************************************************
	SOLICITUD 601

	Descripcion: Se modifico el rollback para que ahora se ejecute correctamente al aplicar
	el trigger de bloqueo ubicado en ProMovimientosAlmacenConceptos
	
	Modificada por:   Amado Navarro
	Fecha de mofidicacion: 15/11/2019
	Versión: Versión 8.0.47.48

	Invocada desde: <PAGE_ProOrdenesServiciosListadoServicios>
	************************************************************************************************ */
	/* *************************************************************************************************
	SOLICITUD 4749
	
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 21/09/2021
	Versión: Versión 8.0.65.01

	Se comento codigo al final, esto por que ponia IdMovimientoAlmacenConcepto como null, y al momento de desafectar 
	inventario se pierde la relacion con la poliza, la poliza si se crea, pero la relacion se perdia.

	Invocada desde: <PAGE_ProOrdenesServiciosListadoServicios>
	************************************************************************************************ */

AS
DECLARE @docHandle INT,
		@MessageError varchar(max),
		@return_value int, 
		@IdTipoMovimientoAlmacen int,
		@IdMovimientoAlmacen int,
		@DetalleArticulo VARCHAR(max)


SET XACT_ABORT ON

BEGIN TRY
	BEGIN TRANSACTION
		IF @dsOrdenesServiciosPartes  IS NULL
			RAISERROR(N'Partes del servicio son requeridos',
					16,
					1
					)
		-- valida que este afectado el inventario 
		IF EXISTS(SELECT FechaAplicaInventario FROM ProOrdenesServiciosDetalles 
					WHERE  ProOrdenesServiciosDetalles.IdOrdenServicioDetalle = @IdOrdenServicioDetalle
						AND FechaAplicaInventario IS NULL
				 ) 
				RAISERROR(N'El servicio no esta afectado el inventario',
						16,
						1
						)

		-- valida que el artículo no este devuelta
		SET @MessageError = ''
		
		DECLARE TempProOrdenesServiciosPartesDevolucion CURSOR FOR
		SELECT 
			'Artículo: '+ca.Articulo + ' [ Cantidad devuelta ('+cast(sum(pospd.CantidadDevuelta) as varchar(10))+' ) ]'  As DetalleArticulo
								 FROM  ProOrdenesServiciosDetalles as posd 
										INNER JOIN ProOrdenesServiciosPartes  as posp 
									ON  posd.IdOrdenServicioDetalle = posp.IdOrdenServicioDetalle 
										INNER JOIN ProOrdenesServiciosPartesDevolucion as pospd 
									ON posp.IdOrdenServicioParte = pospd.IdOrdenServicioParte
										INNER JOIN CatArticulos as ca on posp.IdArticulo = ca.IdArticulo
								 WHERE  posd.IdOrdenServicioDetalle  = @IdOrdenServicioDetalle
								 group by posp.IdArticulo,ca.Articulo
		-- apertura del cursor

		OPEN TempProOrdenesServiciosPartesDevolucion
		FETCH TempProOrdenesServiciosPartesDevolucion INTO @DetalleArticulo
		WHILE ( @@FETCH_STATUS = 0 )
		  BEGIN
			  SET @MessageError = @MessageError + @DetalleArticulo + Char(10)
			  FETCH TempProOrdenesServiciosPartesDevolucion INTO @DetalleArticulo
		  END -- Fin del bucle WHILE
		CLOSE TempProOrdenesServiciosPartesDevolucion
		DEALLOCATE TempProOrdenesServiciosPartesDevolucion

		IF @MessageError <>''
				BEGIN
				SET @MessageError = @MessageError+char(10)+' El servicio tiene artículos devueltos, no es posible desafectar inventario' 
					RAISERROR(@MessageError ,
					16,
					1
					)
				END


		-- valida que el artículo de tipo llanta no esten asignados a ninguna unidad 
		SET @MessageError = ''
		SET @DetalleArticulo = ''
		DECLARE TempProOrdenesServiciosPartesLlanta CURSOR FOR
		SELECT    
				'Artículo tipo llanta: '+ca.Articulo + ' [ Número económico: '+pll.NumeroEconomico+ ' ( Unidad asignada: '+cu.Codigo+' ) ]'  as DetalleArticulo
						FROM  ProOrdenesServiciosDetalles as posd 
							 INNER JOIN ProOrdenesServiciosPartes  as posp ON  posd.IdOrdenServicioDetalle = posp.IdOrdenServicioDetalle 
							 INNER JOIN ProLlantas as pll ON posp.IdOrdenServicioParte = pll.IdOrdenServicioParte
							 INNER JOIN CatUnidades as cu on pll.IdUnidad = cu.IdUnidad 
							 INNER JOIN CatArticulos as ca on pll.IdArticulo = ca.IdArticulo
					   WHERE  posd.IdOrdenServicioDetalle  = @IdOrdenServicioDetalle
		-- apertura del cursor
		SET @MessageError = ''
		OPEN TempProOrdenesServiciosPartesLlanta
		FETCH TempProOrdenesServiciosPartesLlanta INTO @DetalleArticulo
		WHILE ( @@FETCH_STATUS = 0 )
		  BEGIN
			  SET @MessageError = @MessageError + @DetalleArticulo + Char(10)
			  FETCH TempProOrdenesServiciosPartesLlanta INTO @DetalleArticulo
		END -- Fin del bucle WHILE
		CLOSE TempProOrdenesServiciosPartesLlanta
		DEALLOCATE TempProOrdenesServiciosPartesLlanta

		IF @MessageError <>''
				BEGIN
				SET @MessageError = @MessageError+char(10)+' El servicio tiene artículos tipo llanta ya asignadas, no es posible desafectar inventario' 
					RAISERROR(@MessageError ,
					16,
					1
					)
				END
	

	-- Actualiza servicio
	   UPDATE ProOrdenesServiciosDetalles
	   SET	Estatus = Null,
			FechaAplicaInventario = Null
		WHERE  ProOrdenesServiciosDetalles.IdOrdenServicioDetalle = @IdOrdenServicioDetalle
		
	-- Convertir Partes Adicionales a Propias
	   UPDATE ProOrdenesServiciosPartes
	   SET	ParteAdicional = Null
	   WHERE  ProOrdenesServiciosPartes.IdOrdenServicioDetalle = @IdOrdenServicioDetalle

	-- Desafectar inventario
	   SET @IdTipoMovimientoAlmacen = (Select IdTipoMovimientoAlmacen From CatTiposMovimientosAlmacen 
			WHERE Movimiento = 'DESAFECTAR SALIDA ' AND DefinidoPorSistema = 1)

	   IF ISNULL(@IdTipoMovimientoAlmacen,0) = 0
	   			RAISERROR(N'Identificador de tipo de movimiento es un campo requerido ',
					16,
					1
					)
		
	   DECLARE TempIdMovimientosAlmacen CURSOR local FOR
	   SELECT  DISTINCT pmac.IdMovimientoAlmacen 
	   From ProOrdenesServiciosDetalles as posd
	   inner join ProOrdenesServiciosPartes as posp on posd.IdOrdenServicioDetalle = posp.IdOrdenServicioDetalle 
	   inner join ProMovimientosAlmacenConceptos as pmac on pmac.IdMovimientoAlmacenConcepto = posp.IdMovimientoAlmacenConcepto
	   WHERE posp.IdOrdenServicioDetalle = @IdOrdenServicioDetalle 
	   OPEN TempIdMovimientosAlmacen
	   FETCH TempIdMovimientosAlmacen INTO @IdMovimientoAlmacen
	   WHILE ( @@FETCH_STATUS = 0 )
			BEGIN
				EXEC @return_value = usp_ProMovimientosAlmacenSalidaCancelar
						@IdMovimientoAlmacen, 
						'SE CANCELA POR DESAFECTAR INVENTARIO',
						@IdTipoMovimientoAlmacen,
						@CreadoEl,
						@CreadoPor,
						@IdPeticion,
						NULL
				FETCH TempIdMovimientosAlmacen INTO @IdMovimientoAlmacen
		END -- Fin del bucle WHILE
		CLOSE TempIdMovimientosAlmacen
		DEALLOCATE TempIdMovimientosAlmacen

	   IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al actualizar cancelación de salida de movimiento de almacén',
			16,
			1
			)

			--Se comento en la solicitud 4779
	 -- UPDATE ProOrdenesServiciosPartes
		--SET IdMovimientoAlmacenConcepto = NULL
		--WHERE ProOrdenesServiciosPartes.IdOrdenServicioDetalle = @IdOrdenServicioDetalle
			
	COMMIT		
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

