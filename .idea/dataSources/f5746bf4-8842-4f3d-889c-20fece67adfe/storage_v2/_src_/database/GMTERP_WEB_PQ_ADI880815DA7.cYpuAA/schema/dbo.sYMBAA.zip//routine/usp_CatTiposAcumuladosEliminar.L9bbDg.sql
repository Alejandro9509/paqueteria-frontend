CREATE PROCEDURE [dbo].[usp_CatTiposAcumuladosEliminar]
	@IdTipoAcumulado int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF NOT EXISTS(SELECT IdTipoAcumulado FROM CatTiposAcumulados WHERE IdTipoAcumulado = @IdTipoAcumulado)
		RAISERROR(N'El registro ya fue eliminado por otro usuario.',
			16,
			1
			)
					
	DELETE FROM CatTiposAcumulados
	WHERE IdTipoAcumulado = @IdTipoAcumulado
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

