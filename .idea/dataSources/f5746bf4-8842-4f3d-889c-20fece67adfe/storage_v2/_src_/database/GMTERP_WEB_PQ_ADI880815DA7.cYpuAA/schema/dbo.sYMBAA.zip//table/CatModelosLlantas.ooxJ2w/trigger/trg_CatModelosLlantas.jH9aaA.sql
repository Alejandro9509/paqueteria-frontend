CREATE TRIGGER [dbo].[trg_CatModelosLlantas]
    ON [dbo].[CatModelosLlantas]
    AFTER UPDATE
AS
BEGIN               
    IF EXISTS(Select Top 1 IdModeloLlanta
				from ProLlantas 
				Where IdModeloLlanta = (SELECT IdModeloLlanta FROM deleted d where  d.IdModeloLlanta =IdModeloLlanta)) 	
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON 
		I.Descripcion <> D.Descripcion OR
		I.IdMarcaLlanta <> D.IdMarcaLlanta OR
		I.IdMedidaLlanta <> D.IdMedidaLlanta )
		RAISERROR(N'El Modelo no se puede modificar porque ya cuenta con llantas ligadas',
			16,
			1
			)		
	END	                   
END
go

