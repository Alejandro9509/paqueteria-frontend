
CREATE PROCEDURE [dbo].[usp_CatZonasTarifasModificarPQ](
	@IdZona int,
	@CodigoZona varchar(50),
	@IdEstado varchar(5),
	@Estado varchar(100),
	@CodMunicipio varchar(5),
	@Municipio varchar(100)
)
AS
BEGIN
	BEGIN TRANSACTION
		/*INSERT INTO CatZonasOperativasPQ (CodigoZona, IdSucursal, IdEstado, Estado, CodigoMunicipio, Municipio)
		values(@CodigoZona, @IdSucursal, @IdEstado, @Estado, @CodMunicipio, @Municipio)*/
		UPDATE CatZonasTarifasPQ 
		SET CodigoZona = @CodigoZona,
		IdEstado = @IdEstado,
		Estado = @Estado
		WHERE IdZona = @IdZona

		DELETE FROM CatZonasTarifasCPPQ WHERE IdZona = @IdZona
		DELETE FROM CatZonasTarifasConceptosPQ WHERE IdZona = @IdZona
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

