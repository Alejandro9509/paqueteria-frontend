
/* *************************************************************************************************
Script de modificar Terminal para el catálogo de Terminales

Parámetros: 
	@IdTerminal int				(entrada, entero). Identificador de Terminal a modificar
	@Codigo int,				(entrada, entero). Código de terminal
	@Descripcion varchar(50),	(entrada, string). Descripción de Terminal
	@Activo bit,				(entrada, bit). Estado de Terminal (Activo/Inactivo)
	@ModificadoEl datetime,		(entrada, fecha hora). Fecha en la que se realiza la modificación
	@ModificadoPor int,			(entrada, entero). Quien solicita la modificación
	@IdPeticion varchar(100)	(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento actualiza la información de una terminal previamente creada para el Catálogo de Terminales
			 del módulo Operación Portuaria.

Implementada por: David Rivera Navarro
Fecha de implementación: 10/07/2019
Versión: Versión 8.0.44.22

Modificada por:   <Nombre del último progrador que lo modificó>
Fecha de mofidicación: <(dd/mm/yyyy)>
Versión: <Versión ERP para la que fue modificada >

Invocada desde: PAGE_CatTerminalesAM (Solicitud 12815)

Valor de retorno: NA.

Ejemplo de Uso: NA.

***************************************************************************************************** */

CREATE	 PROCEDURE [dbo].[usp_CatTerminalesModificar]
	@IdTerminal int,
	@Codigo int,
	@Descripcion varchar(50),
	@Activo bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	-- Si no se tiene un Id de terminal a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF @IdTerminal = 0
		RAISERROR(N'El identificador de terminal es un campo requerido',
			16,
			1
			)			
	
	-- Si no se tiene una descripción a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF LTRIM(RTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)

	-- Si no se tiene un  código de terminal a modificar, no permitirá ejecutar el proceso ya que este es requerido
	IF @Codigo = 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)

	-- Si el nuevo código coincide con el del algún otro registro, no permitirá modificar el registro
	IF EXISTS(SELECT Codigo FROM CatTerminales WHERE Codigo = @Codigo AND IdTerminal <> @IdTerminal)
		RAISERROR(N'El código de terminal ya existe',
			16,
			1
			)
			
	UPDATE CatTerminales SET 
		Codigo = @Codigo,
		Descripcion = @Descripcion,
		Activo = @Activo,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdTerminal = @IdTerminal
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

