CREATE PROCEDURE [dbo].[usp_ProLiquidacionesPagoPropietariosGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProLiquidacionesPagoPropietarios
go

