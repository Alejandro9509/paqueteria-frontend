
CREATE PROCEDURE usp_dbadefragmentIndex 
/* *************************************************************************************************
Procedimiento usp_dbadefragmentIndex 

Parámetros: 
    Ninguno

Descripción: Crea una tabla temporal y un cursos para todos los indices en la base de datos con un 
             porcentaje de fragmentacion supeior al 10%.
             Recorre el cursor Reindexando o reorganizando cada indice según su % de fragmentación

Implementada por: José Luis Cisneros G.
Fecha de implementacion: 6/Abril/2021
Versión: 8.0.60.09
SOLICITUD: 
	SOLICITUD 002279

Invocada desde: Portal de Azure con fines de Mantenimiento de fragmentación de Indices
***************************************************************************************************** */
AS

SET NOCOUNT ON;

DECLARE @objectid int;
DECLARE @indexid int;
DECLARE @partitioncount bigint;
DECLARE @schemaname nvarchar(130); 
DECLARE @objectname nvarchar(130); 
DECLARE @indexname nvarchar(130); 
DECLARE @partitionnum bigint;
DECLARE @partitions bigint;
DECLARE @frag float;
DECLARE @command nvarchar(4000);


BEGIN
   BEGIN TRY   --- lógica del procedimiento
        -- Conditionally SELECT tables and indexes FROM the sys.dm_db_index_physical_stats function and convert object and index IDs to names.

        SELECT object_id AS [objected], index_id AS [indexid], partition_number AS [partitionnum], avg_fragmentation_in_percent AS [frag]
        INTO #work_to_do
        FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL , NULL, 'LIMITED')
        WHERE avg_fragmentation_in_percent > 10.0 AND index_id > 0 ;

        -- Declare the cursor for the list of partitions to be processed.

        DECLARE partitions CURSOR LOCAL FOR SELECT * FROM #work_to_do;

        -- Open the cursor.

        OPEN partitions;

        -- Loop through the partitions.
        WHILE (1=1)
            BEGIN
                FETCH NEXT
                   FROM partitions
                   INTO @objectid, @indexid, @partitionnum, @frag;
                IF @@FETCH_STATUS < 0 BREAK;
        
                SELECT @objectname = QUOTENAME(o.name), @schemaname = QUOTENAME(s.name)
                FROM sys.objects AS o
                JOIN sys.schemas as s ON s.schema_id = o.schema_id
                WHERE o.object_id = @objectid;
        
                SELECT @indexname = QUOTENAME(name)
                FROM sys.indexes
                WHERE  object_id = @objectid AND index_id = @indexid;
        
                SELECT @partitioncount = count (*)
                FROM sys.partitions
                WHERE object_id = @objectid AND index_id = @indexid;

        -- 30 is an arbitrary decision point at which to switch between reorganizing and rebuilding.
                IF @frag < 30.0
                    SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REORGANIZE';
                IF @frag >= 30.0
                    SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REBUILD';
                IF @partitioncount > 1
                    SET @command = @command + N' PARTITION=' + CAST(@partitionnum AS nvarchar(10));
                EXEC (@command);
        ---     PRINT N'Executed: ' + @command;
            END

        -- Clean, Close and deallocate the cursor.
        DROP TABLE #work_to_do
        CLOSE partitions;
        DEALLOCATE partitions;

   END TRY
   BEGIN CATCH  --- bloque de manejo de errores
   --- Si estaba abierta una transaccion se cierra por error
   	IF(@@TRANCOUNT > 0)
        -- Clean, Close and deallocate the cursor
		
	IF (SELECT CURSOR_STATUS('LOCAL','partitions')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('LOCAL','partitions')) > -1
			BEGIN
				CLOSE partitions
			END
			DEALLOCATE partitions
		END

	  ROLLBACK TRANSACTION;	
 
   END CATCH
END
go

