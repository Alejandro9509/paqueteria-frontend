
CREATE PROC [dbo].[usp_CatTipoMaterialesPemexEliminar]
    @IdTipoMaterialPemex int,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatTipoMaterialesPemexEliminar

Parámetros:
    @IdTipoMaterialPemex (entrada, entero). Id del tipo de material PEMEX.
    @IdPeticion          (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para elimina un Tipo de Material PEMEX.

04/02/2020 - Se creó.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 04/02/2020
Versión ERP:

Invocada desde: PAGE_CatTipoMaterialPemexListado (Solicitud 997)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
    -- Valida que el Id no venga en cero
    IF @IdTipoMaterialPemex = 0
        RAISERROR(N'El id del tipo de material es un campo requerido', 16, 1)

	IF EXISTS(SELECT IdTipoMaterialPemex FROM CatMaterialesPemex WHERE IdTipoMaterialPemex = @IdTipoMaterialPemex)
        RAISERROR(N'No es posible eliminar el registro ya que se encuentra ligado a un material', 16, 1)
    
    -- Elimina el registro que tenga el mismo Id
    DELETE FROM CatTipoMaterialesPemex 
    WHERE IdTipoMaterialPemex = @IdTipoMaterialPemex

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

