-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GeneraFolioPQ] 
(
	-- Add the parameters for the function here
	@proceso int,@FOLIO int
)
RETURNS varchar(10)
AS
BEGIN
	DECLARE @PREFIJO varchar(3);
	DECLARE @FOLIOR varchar(10);
	select @PREFIJO = Prefijo 
	from dbo.CatProcesosPQ
	where IdProceso = @proceso;
	if (len(isnull(@PREFIJO,'')) = 0)
		select @FOLIOR = (ISNULL(@PREFIJO,'') +format(@FOLIO,'0000000000'))
	else
	if (len(@PREFIJO) = 1)
		select @FOLIOR =ISNULL(@PREFIJO,'') +format(@FOLIO,'000000000')
	else if (len(@PREFIJO) = 2)
		select @FOLIOR =ISNULL(@PREFIJO,'') +format(@FOLIO,'00000000')
	else
		select @FOLIOR =ISNULL(@PREFIJO,'') +format(@FOLIO,'0000000')	
	-- Return the result of the function
	RETURN @FOLIOR

END

go

