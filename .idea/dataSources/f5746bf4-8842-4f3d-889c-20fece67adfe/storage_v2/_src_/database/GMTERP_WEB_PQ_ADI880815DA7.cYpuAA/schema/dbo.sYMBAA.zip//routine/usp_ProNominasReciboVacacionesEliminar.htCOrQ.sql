CREATE PROCEDURE [dbo].[usp_ProNominasReciboVacacionesEliminar]
	@IdNominaReciboVacaciones int,
	@IdPeticion varchar(100),
	@IdEmpleadoV int, 
	@IdPeriodoV int	
AS
DECLARE

 @VacacionesAcumuladas int,
 @DiasPrimaAcumulados decimal(15,2),
 @VacacionesPendientes int,
 @DiasPrimaPendientes decimal(15,2),
 @IdEmpleado int,
 @IdPeriodo int,
 @DiasVacaciones int,
 @PrimaVacacionalDias decimal(15,2)
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdNominaReciboVacaciones,0)= 0
		RAISERROR(N'El Identificador es un campo requerido',
				16,
				1
				)
	IF NOT EXISTS(SELECT IdNominaReciboVacaciones FROM ProNominasReciboVacaciones WHERE IdNominaReciboVacaciones = @IdNominaReciboVacaciones)
		RAISERROR(N'El registro ya fue eliminado por otro usuario',
			16,
			1
			)
	
    --se obtiene el id del empleado 
    SET @IdEmpleado = (SELECT IdEmpleado FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones)
    --se obtiene el id del periodo 
    SET @IdPeriodo = (SELECT IdPeriodo FROM ProNominasReciboVacaciones where IdPeriodo = @IdPeriodo)
    
    --Con el id del empleado verificamos si se tiene mas de 1 registro entoces entramos a acutalizar todos los registros del empleado
	IF (SELECT COUNT(*) FROM ProNominasReciboVacaciones WHERE IdEmpleado = @IdEmpleado) > 1  
	BEGIN
	
	SET @DiasVacaciones = (SELECT DiasVacaciones FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones)
	SET @PrimaVacacionalDias = (SELECT PrimaVacacionalDias FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones)
	--afectar acumulados 
	SET @VacacionesAcumuladas = (SELECT VacacionesAcumuladas FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones) - @DiasVacaciones
	SET @DiasPrimaAcumulados = (SELECT DiasPrimaAcumulados FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones) - @PrimaVacacionalDias
	SET @VacacionesPendientes =(SELECT VacacionesPendientes FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones) + @DiasVacaciones
	SET @DiasPrimaPendientes = (SELECT DiasPrimaPendientes FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones) + @PrimaVacacionalDias
	--actualizar todos los registros del empleado
	UPDATE ProNominasReciboVacaciones 
	SET VacacionesAcumuladas = @VacacionesAcumuladas,
		DiasPrimaAcumulados =@DiasPrimaAcumulados,
		VacacionesPendientes = @VacacionesPendientes,
		DiasPrimaPendientes = @DiasPrimaPendientes
	WHERE IdEmpleado = @IdEmpleado
	END
		
	-- Eliminar
	DELETE FROM ProNominasReciboVacaciones where IdNominaReciboVacaciones = @IdNominaReciboVacaciones
	UPDATE ProNominasRecibo
	SET Calculado = 0
	WHERE IdEmpleado=@IdEmpleado AND IdPeriodo = @IdPeriodo

	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleadoV AND IdPeriodo = @IdPeriodoV

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

