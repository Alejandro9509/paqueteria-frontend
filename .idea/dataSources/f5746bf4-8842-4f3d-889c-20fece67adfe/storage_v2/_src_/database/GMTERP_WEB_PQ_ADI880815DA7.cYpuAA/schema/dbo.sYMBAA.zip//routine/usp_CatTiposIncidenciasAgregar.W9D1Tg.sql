CREATE PROCEDURE [dbo].[usp_CatTiposIncidenciasAgregar]	  
	@Codigo int,
    @Descripcion varchar(40),
    @Mnemonico varchar(4),
    @DerechoSueldo bit,
    @PorcentajeSueldo decimal(15,2),
    @TipoImss int,
    @TipoIncidencia int,
    @DerechoSeptimoDia bit,
    @ValorUnidad decimal(15,2),
	@CreadoEl    datetime,    
	@CreadoPor    int,    
	@IdPeticion varchar(100),
	@DefinidoPorSistema bit,
	@ClaveSat varchar(5) 
AS
BEGIN TRY
    BEGIN TRANSACTION    
	IF ISNULL(@Codigo,0) = 0
        RAISERROR(N'El código es un campo requerido',
            16,
            1
            )            
            
	IF EXISTS(SELECT Codigo FROM CatTiposIncidencias WHERE Codigo = @Codigo)
		RAISERROR(N'El código ya existe',
			16,
			1
			)
	
	 IF ISNULL(@Descripcion,'')= ''
        RAISERROR(N'La descripción de la incidencia es un campo requerido',
            16,
            1
            )
   
    IF EXISTS(SELECT Descripcion FROM CatTiposIncidencias WHERE Descripcion = @Descripcion)
		RAISERROR(N'La descripción de la incidencia ya existe',
			16,
			1
			)                         
   
	INSERT INTO CatTiposIncidencias(Codigo,Descripcion,Mnemonico,DerechoSueldo,PorcentajeSueldo,TipoImss,TipoIncidencia,DerechoSeptimoDia,ValorUnidad,CreadoEl,CreadoPor,DefinidoPorSistema,ClaveSat)
	     VALUES(@Codigo,@Descripcion,@Mnemonico,@DerechoSueldo,@PorcentajeSueldo,@TipoImss,@TipoIncidencia,@DerechoSeptimoDia,@ValorUnidad,@CreadoEl,@CreadoPor,@DefinidoPorSistema,@ClaveSat)
  
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

