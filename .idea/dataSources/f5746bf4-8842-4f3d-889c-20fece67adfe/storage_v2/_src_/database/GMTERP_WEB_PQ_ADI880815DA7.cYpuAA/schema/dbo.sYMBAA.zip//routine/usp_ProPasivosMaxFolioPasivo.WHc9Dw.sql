CREATE PROCEDURE [dbo].[usp_ProPasivosMaxFolioPasivo]    
AS    
Select ISNULL(MAX(FolioPasivo),0)+1 AS FolioPasivo from ProPasivos
go

