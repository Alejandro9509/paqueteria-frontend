
CREATE PROC [dbo].[usp_CatTipoMaterialesPemexModificar]
    @IdTipoMaterialPemex int,
    @Codigo int,
    @Descripcion varchar(30),
    @Activo bit,
    @ModificadoEl datetime,
    @ModificadoPor int,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatTipoMaterialesPemexModificar

Parámetros:
    @IdTipoMaterialPemex (entrada, entero). Id del tipo de material PEMEX.
    @Codigo              (entrada, entero). Código del tipo de material PEMEX.
    @Descripcion         (entrada, texto). Descripción del tipo de material PEMEX.
    @Activo              (entrada, booleno). Bandera para saber si se encuentra activo el tipo de material PEMEX.
    @ModificadoEl        (entrada, fecha hora). Fecha y hora en la que fue modificado el registro.
    @ModificadoPor       (entrada, entero). Id del usuario que modifico el registro.
    @IdPeticion          (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para modifica un Tipo de Material PEMEX.

04/02/2020 - Se creó.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 04/02/2020
Versión ERP:

Invocada desde: PAGE_CatTipoMaterialPemexAM (Solicitud 997)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
    -- Validaciones
    IF @IdTipoMaterialPemex = 0
        RAISERROR(N'El Id del tipo de material pemex es un campo requerido', 16, 1)

    IF @Codigo = 0
        RAISERROR(N'El código del tipo de material pemex es un campo requerido', 16, 1)

    IF ISNULL(@Descripcion, '') = ''
        RAISERROR(N'El nombre del tipo de material es un campo requerido', 16, 1)

    -- Modifica el registro
    UPDATE CatTipoMaterialesPemex SET
    Codigo = @Codigo,
    Descripcion = @Descripcion,
    Activo = @Activo,
    ModificadoEl = @ModificadoEl,
    ModificadoPor = @ModificadoPor 
    WHERE IdTipoMaterialPemex = @IdTipoMaterialPemex

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

