CREATE PROCEDURE [dbo].[usp_CatTiposDocumentosAgregarConfiguracion]
	@IdTipoDocumento INT,
	@IdSucursal INT,
	@Complemento INT,
	@CreadoEl DATETIME,
	@CreadoPor INT,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Procedimiento usp_CatTiposDocumentosAgregarConfiguracion

Parámetros: 
	@IdTipoDocumento	(entrada, entero). Identificador del tipo de documento
	@IdSucursal			(entrada, entero). Identificador de la sucursal
	@Complemento		(entrada, entero). Enum del tipo de configuracion (1 - Traslado, 2 - Ingreso, 3 - Ninguno)
	@CreadoEl			(entrada, fecha hora). Fecha y hora de creacion
	@CreadoPor			(entrada, entero). Usuario que crea la configuracion
	@IdPeticion			(entrada, string). Id de la Petición, generada en WEBDEV 		
 
Descripción: Procedimiento que crea las configuraciones del timbrado de los tipos de documentos CFDI tipo carta porte

Implementada por: Jesús Humberto Morales
Fecha de implementacion: 15/11/2021
Versión ERP: 8.0.66.23

Modificada por:   XXXXX
Fecha de mofidicacion: XXXXX
Versión ERP: XXXXX

Invocada desde: PAGE_CatTiposDocumentosConfigurarTimbrado (Solicitud 5022)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
		
		IF ISNULL(@IdTipoDocumento, 0) <= 0
			RAISERROR(N'El tipo de documento es un campo requerido', 16, 1)

		IF ISNULL(@IdSucursal, 0) <= 0
			RAISERROR(N'La sucursal es un campo requerido', 16, 1)

		IF EXISTS(SELECT IdTipoDocumentoConfiguracionTimbrado FROM CatTiposDocumentosConfiguracionTimbrado WHERE IdTipoDocumento = @IdTipoDocumento AND IdSucursal = @IdSucursal)
			RAISERROR(N'La configuración ya existe', 16, 1)

		INSERT INTO CatTiposDocumentosConfiguracionTimbrado (IdTipoDocumento, IdSucursal, Complemento, CreadoEl, CreadoPor)
		VALUES (@IdTipoDocumento, @IdSucursal, @Complemento, @CreadoEl, @CreadoPor)

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

