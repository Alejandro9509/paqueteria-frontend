


CREATE PROCEDURE [dbo].[usp_CatSucursalesEliminar]
	@IdSucursal int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM CatClientes WHERE IdSucursal = @IdSucursal)
		RAISERROR(N'La sucursal está asignada a clientes, no es posible eliminarla',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM CatFolios WHERE IdSucursal = @IdSucursal)
		RAISERROR(N'La sucursal tiene folios de documentos, no es posible eliminarla',
			16,
			1
			)
			
	IF EXISTS(SELECT TOP 1 * FROM CatUsuarios WHERE IdSucursal = @IdSucursal)
		RAISERROR(N'La sucursal está asignada a usuarios, no es posible eliminarla',
			16,
			1
			)			
				
	DELETE FROM CatSucursales
	WHERE IdSucursal = @IdSucursal
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

