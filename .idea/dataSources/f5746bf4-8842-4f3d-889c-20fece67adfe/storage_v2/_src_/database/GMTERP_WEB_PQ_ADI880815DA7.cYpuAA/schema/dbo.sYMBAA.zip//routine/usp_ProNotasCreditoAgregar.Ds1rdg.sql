CREATE PROCEDURE [dbo].[usp_ProNotasCreditoAgregar]
	@IdFolio	int,
	@IdCliente	int,
	@IdSucursal	int,
	@FechaHora	datetime,
	@SubTotal	money,
	@ImpuestosTrasladadosFederales	money,
	@ImpuestosRetenidosFederales	money,
	@ImpuestosTrasladadosLocales	money,
	@ImpuestosRetenidosLocales	money,
	@Total	money,
	@TipoCambio	money,
	@IdMoneda	int,
	@EstatusImpresoEnviadoCliente	bit,
	@NroCuentaPago	varchar(50),
	@MetodoPago	varchar(50),
	@IdCertificado	int,
	@IdFormatoImpresion	int,
	@CreadoPor	int,
	@CreadoEl	datetime,
	@Concepto	varchar(1000),
	@UnidadMedida	varchar(30),
	@dsProNotasCreditoConceptosFacturacion ntext,
	@dsProNotasCreditoFacturas ntext,
	@dsProNotasCreditoImpuestos ntext,
	@IdConceptoCobranza int,
	@IdPeticion varchar(100),
	@Observaciones varchar(512),
	@ClaveMetodoPago varchar(5),
	@NotaCreditoExterna	bit,
	@CreadaParaCFDI33 bit,
	@IdUsoCFDI varchar(5),
	@TieneAjuste bit,
	@CondicionesPago tinyint = NULL,
	@EsFacturaGeneral bit = 0,
	@IdAddenda int = 0,
	@Campo1 varchar(250) = '',
	@Campo2 varchar(250) = '',
	@Campo3 varchar(250) = '',
	@Campo4 varchar(250) = '',
	@Campo5 varchar(250) = '',
	@Campo6 varchar(250) = '',
	@Campo7 varchar(250) = '',
	@Campo8 varchar(250) = '',
	@Campo9 varchar(250) = '',
	@Campo10 varchar(250)= '',
	@Sustituir bit = NULL,
	@IdNotaCreditoAnterior int = NULL
AS
DECLARE
	@docHandle int,
	@IdNotaCredito int,
	@IdFacturaError int,
	@DoctoFacturaError varchar(50),
	@MensajeFacturaError varchar(250),
	@ATT_IdContraReciboCliente int,
	@ATT_IdFactura int,
	@ATT_Importe money,
	@MensajeError varchar(250),
	@ImporteClienteDLLSContraRecibo money,
	@ImporteClientePESOSContraRecibo money,
	@IdCobranza int,

	@IdNotaCreditoConceptoFacturacion int,
	@ATT_IdConceptoFacturacion int,
	@ATT_IdFacturaConceptoFacturacion int,
	@ATT_TrasladaImpuesto bit,
	@ATT_RetieneImpuesto bit,
	@ATT_IdImpuestoTraslada int,
	@ATT_ImporteTraslada money,
	@ATT_IdImpuestoRetiene int,
	@ATT_ImporteRetiene money,
	@ATT_IdImpuestoIEPS int,
	@ATT_ImporteIEPS money,
	@ATT_IdImpuestoISR int,
	@ATT_ImporteISR money,
	@FolioSustitucion varchar(50),
	@CerosFolioSustitucion varchar(50),
	@SerieFolio varchar(50)

/*
MODIFICACION:
	SEMODIFICO PROCEDIMIENTO usp_ProNotasCreditoAgregar CON LA FINALIDAD DE AGREGAR LOS CAMPOS DE LAS ADDENDAS ASI COMO LA ADDENDA CORRESPONDIENTE.
MODIFICADO POR:
	GUSTAVO PARTIDA NEVAREZ
SOLICITUD: 
	SOLICITUD 001109
MODIFICACION:
	SE MODIFICO LA COMPARACION DE LOS IMPORTES DE LOS CONCEPTOS CON EL SUBTOTAL DE LA NOTA DE CREDITO ABRIENDOLA A 4 DECIMALES
MODIFICADO POR:
	JESÚS HUMBERTO MORALES
SOLICITUD: 
	SOLICITUD 003601

CAMBIO:
	Se retiro el codigo del boleano @TieneAjuste ya que ocaciona problemas cuando los importes de los CF y el subtotal son iguales
VERSIÓN:
	Versión 8.0.58.08
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2021-01-26
INVOCADA DESDE:
	Regostrar: 
		Notas de credito
SOLICITUD: 
	SOLICITUD 003601

CAMBIO:
	Se agrego el nodo de IdFacturaConceptoFacturacion en el XML de conceptos para que se agrege en la tabla de conceptos de la nota de credito
VERSIÓN:
	Versión 8.0.64.09
MODIFICADA POR:
	Jesús Humberto Morales
FECHA DE MODIFICACIÓN:
	2021-08-24
INVOCADA DESDE:
	Regostrar: 
		Notas de credito
SOLICITUD: 
	SOLICITUD 004646
*/

BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@IdFolio,0) <= 0
			RAISERROR(N'El folio del documento es un campo requerido',
				16,
				1
				)

		IF EXISTS(SELECT IdFolio FROM ProNotasCredito WHERE IdFolio = @IdFolio)
			RAISERROR(N'El folio ya fue utilizado por otro usuario',
				16,
				1
				)

		IF ISNULL(@IdCliente,0) <= 0
			RAISERROR(N'El cliente es un campo requerido',
				16,
				1
				)

		IF ISNULL(@IdSucursal,0) <= 0
			RAISERROR(N'La sucursal es un campo requerido',
				16,
				1
				)
				
		IF ISDATE(@FechaHora) = 0
			RAISERROR(N'La fecha es un campo requerido',
				16,
				1
				)

		IF ISNULL(@SubTotal,0) <= 0
			RAISERROR(N'El subtotal es un campo requerido',
				16,
				1
				)

		IF ISNULL(@IdMoneda,0) <= 0
			RAISERROR(N'La moneda es un campo requerido',
				16,
				1
				)
				
		IF RTRIM(LTRIM(@Concepto)) = ''		
			RAISERROR(N'El Concepto es un campo requerido',
				16,
				1
				)		
				
		IF @dsProNotasCreditoConceptosFacturacion IS NULL
			RAISERROR(N'Los conceptos de facturacion son requeridos',
				16,
				1
				)

		IF @dsProNotasCreditoFacturas IS NULL
			RAISERROR(N'Las facturas son requeridos',
				16,
				1
				)

		IF @dsProNotasCreditoImpuestos IS NULL
			RAISERROR(N'Los impuestos son requeridos',
				16,
				1
				)				
								
		If @IdCertificado = 0
			SET @IdCertificado = NULL			

		If @IdFormatoImpresion = 0
			SET @IdFormatoImpresion = NULL
			
		IF @NotaCreditoExterna = NULL
			SET @NotaCreditoExterna = 0	
			
		INSERT INTO ProNotasCredito(Concepto,CreadoEl,CreadoPor,EstatusImpresoEnviadoCliente,FechaHora,
		IdCertificado,IdCliente,IdFolio,IdFormatoImpresion,IdMoneda,IdSucursal,ImpuestosRetenidosFederales,
		ImpuestosRetenidosLocales,ImpuestosTrasladadosFederales,ImpuestosTrasladadosLocales,MetodoPago,
		NroCuentaPago,SubTotal,TipoCambio,Total,UnidadMedida,Observaciones,ClaveMetodoPago,NotaCreditoExterna,CreadaParaCFDI33,IdUsoCFDI,CondicionesPago,EsFacturaGeneral)
		VALUES(@Concepto,@CreadoEl,@CreadoPor,@EstatusImpresoEnviadoCliente,@FechaHora,
		@IdCertificado,@IdCliente,@IdFolio,@IdFormatoImpresion,@IdMoneda,@IdSucursal,@ImpuestosRetenidosFederales,
		@ImpuestosRetenidosLocales,@ImpuestosTrasladadosFederales,@ImpuestosTrasladadosLocales,@MetodoPago,
		@NroCuentaPago,@SubTotal,@TipoCambio,@Total,@UnidadMedida,@Observaciones,@ClaveMetodoPago,@NotaCreditoExterna,@CreadaParaCFDI33,@IdUsoCFDI,@CondicionesPago,@EsFacturaGeneral)
	
		SET @IdNotaCredito = (SELECT IDENT_CURRENT('ProNotasCredito'))

		--SECCION MODIFICAR NOTAS DE CREDITO SUSTITUIDAS
		SELECT @Sustituir
		IF @Sustituir = 1
		BEGIN
			SET @FolioSustitucion = (SELECT Folio FROM CatFolios WHERE IdFolio = @IdFolio)
			SET @CerosFolioSustitucion = (SELECT REPLICATE('0', 8-LEN(Folio)) FROM CatFolios WHERE IdFolio = @IdFolio)
			SET @SerieFolio = (SELECT Serie FROM CatFolios WHERE IdFolio = @IdFolio)
			UPDATE ProNotasCredito SET
				IdNotaCreditoAnterior = @IdNotaCredito,
				FechaSustitucion = @CreadoEl,
				FolioSustitucion = @CerosFolioSustitucion + @FolioSustitucion + '-' + @SerieFolio
			WHERE IdNotaCredito = @IdNotaCreditoAnterior
		END
		
		----------------------SECCION PARA AGREGAR LOS IMPUESTOS----------------------------------
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNotasCreditoImpuestos
		
		SELECT COL_IdImpuesto,COL_Importe, COL_Porcentaje
		INTO #TempProNotasCreditoImpuestos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProNotasCreditoImpuestos',2) 
		WITH (COL_IdImpuesto int,COL_Importe money,COL_Porcentaje money)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProNotasCreditoImpuestos(CreadoEl,CreadoPor,IdImpuesto,IdNotaCredito,Importe,Porcentaje)
		SELECT @CreadoEl,@CreadoPor,COL_IdImpuesto,@IdNotaCredito,COL_Importe,COL_Porcentaje
		FROM #TempProNotasCreditoImpuestos
		
		-------------------se carga las facturas a una tabla temporal------------------------
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNotasCreditoFacturas
	    
		SELECT ATT_IdFactura,ATT_Importe
		INTO #TempProNotasCreditoFacturas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNotasCreditoFacturas',2) 
		WITH (ATT_IdFactura int,ATT_Importe money)
	    
		EXEC sp_xml_removedocument @docHandle

		------------------SI ALGUNA FACTURA no tiene saldo esta cancelada o pagada genera error
		SET @IdFacturaError = (SELECT TOP 1 IdFactura FROM ProFacturas WHERE (IdCliente != @IdCliente OR Estatus != 0 OR CanceladoEl IS NOT NULL OR ISNULL(Abonos,0) = Total) AND IdFactura IN(SELECT ATT_IdFactura FROM #TempProNotasCreditoFacturas))
		IF @IdFacturaError IS NOT NULL AND @IdFacturaError <> 0
		BEGIN
			SET @DoctoFacturaError = (SELECT CASE cf.Serie
				WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
				ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
			END
			FROM ProFacturas AS pf
			INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
			INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
			WHERE IdFactura = @IdFacturaError)

			--SE  cambio el mensaje de validacion por faltas de ortografia, solicitud 9304
			--SET @MensajeFacturaError = 'La factura '+@DoctoFacturaError+' que esta intentando aplicar la nota de crédito no cumple con los criterios; Ya sea que no es de ese cliente, No tiene el estatus de pendiente de pago, Este cancelada o Ya fue pagada por otro usuario'
			SET @MensajeFacturaError = 'El documento '+@DoctoFacturaError+' al que intenta aplicar la nota de crédito, no cumple con los criterios. Es probable que el documento esté pagado, tenga un abono, esté cancelado o pertenezca a otro cliente.'

			RAISERROR(@MensajeFacturaError,
				16,
				1
				)
		END
		
		--actualizo saldo de facturacion
		UPDATE ProFacturas SET
			ProFacturas.Abonos = ISNULL(ProFacturas.Abonos,0) + #TempProNotasCreditoFacturas.ATT_Importe,
			ProFacturas.Estatus = CASE WHEN (ISNULL(ProFacturas.Abonos,0)+ #TempProNotasCreditoFacturas.ATT_Importe)= ProFacturas.Total THEN 1 ELSE ProFacturas.Estatus END,
			ProFacturas.ModificadoEl = @CreadoEl,
			ProFacturas.ModificadoPor = @CreadoPor
		FROM ProFacturas
		INNER JOIN #TempProNotasCreditoFacturas ON ProFacturas.IdFactura = #TempProNotasCreditoFacturas.ATT_IdFactura
		
		-----genera un error si los abonos registrados son mayores al total de la factura
		SET @IdFacturaError = (SELECT TOP 1 pf.IdFactura FROM ProFacturas AS pf INNER JOIN #TempProNotasCreditoFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura WHERE ISNULL(pf.Abonos,0) > pf.Total)
		IF @IdFacturaError IS NOT NULL AND @IdFacturaError <> 0
		BEGIN
			SET @DoctoFacturaError = (SELECT CASE cf.Serie
				WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
				ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
			END
			FROM ProFacturas AS pf
			INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
			INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
			WHERE IdFactura = @IdFacturaError)
	    
			SET @MensajeFacturaError =    'El saldo de la factura '+@DoctoFacturaError+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago o una nota de crédito a esta factura.'
	                    
			RAISERROR(@MensajeFacturaError,
				16,
				1
				)
		END

		---------------------SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION de las notas de credito
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNotasCreditoConceptosFacturacion

		SELECT ATT_IdFactura,ATT_IdConceptoFacturacion,ATT_Importe,ATT_TrasladaImpuesto,ATT_RetieneImpuesto,ATT_IdImpuestoTraslada,ATT_ImporteTraslada,ATT_IdImpuestoRetiene,ATT_ImporteRetiene,ATT_IdImpuestoIEPS, ATT_ImporteIEPS, ATT_IdImpuestoISR,ATT_ImporteISR,ATT_IdFacturaConceptoFacturacion
		INTO #TempProNotasCreditoConceptosFacturacion
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNotasCreditoConceptosFacturacion',2) 
		WITH (ATT_IdFactura int,ATT_IdConceptoFacturacion int,ATT_Importe money,ATT_TrasladaImpuesto bit,ATT_RetieneImpuesto bit,ATT_IdImpuestoTraslada int,ATT_ImporteTraslada money,ATT_IdImpuestoRetiene int,ATT_ImporteRetiene money,ATT_IdImpuestoIEPS int,ATT_ImporteIEPS money,ATT_IdImpuestoISR int,ATT_ImporteISR money,ATT_IdFacturaConceptoFacturacion int)

		EXEC sp_xml_removedocument @docHandle
		
		/*Cursor para agregar conceptos de facturacion e impuestos de conceptos de facturacion*/
		DECLARE ProNotasCreditoConceptosFacturacionCursor CURSOR FOR
		SELECT * FROM #TempProNotasCreditoConceptosFacturacion
		
		OPEN ProNotasCreditoConceptosFacturacionCursor
		FETCH NEXT FROM ProNotasCreditoConceptosFacturacionCursor
		INTO @ATT_IdFactura ,@ATT_IdConceptoFacturacion,@ATT_Importe ,@ATT_TrasladaImpuesto ,@ATT_RetieneImpuesto,	@ATT_IdImpuestoTraslada ,@ATT_ImporteTraslada,@ATT_IdImpuestoRetiene,@ATT_ImporteRetiene,@ATT_IdImpuestoIEPS ,@ATT_ImporteIEPS,@ATT_IdImpuestoISR,@ATT_ImporteISR,@ATT_IdFacturaConceptoFacturacion

		WHILE @@FETCH_STATUS = 0
		BEGIN					

			INSERT INTO ProNotasCreditoConceptosFacturacion(CreadoEl,CreadoPor,IdConceptoFacturacion,IdFactura,IdNotaCredito,Importe,RetieneImpuesto,TrasladaImpuesto,IdFacturaConceptoFacturacion)
			VALUES(@CreadoEl,@CreadoPor,@ATT_IdConceptoFacturacion,@ATT_IdFactura,@IdNotaCredito,@ATT_Importe,@ATT_RetieneImpuesto,@ATT_TrasladaImpuesto,@ATT_IdFacturaConceptoFacturacion)

			SET @IdNotaCreditoConceptoFacturacion = (SELECT IDENT_CURRENT('ProNotasCreditoConceptosFacturacion'))

			IF @ATT_IdImpuestoTraslada > 0
			BEGIN
				INSERT INTO ProNotasCreditoConceptosFacturacionImpuestos(IdNotaCreditoConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdNotaCreditoConceptoFacturacion,@ATT_IdImpuestoTraslada,@ATT_ImporteTraslada )
			END
			 
			IF @ATT_IdImpuestoRetiene > 0
			BEGIN
				INSERT INTO ProNotasCreditoConceptosFacturacionImpuestos(IdNotaCreditoConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdNotaCreditoConceptoFacturacion,@ATT_IdImpuestoRetiene,@ATT_ImporteRetiene )
			END

			IF @ATT_IdImpuestoIEPS > 0
			BEGIN
				INSERT INTO ProNotasCreditoConceptosFacturacionImpuestos(IdNotaCreditoConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdNotaCreditoConceptoFacturacion,@ATT_IdImpuestoIEPS,@ATT_ImporteIEPS )
			END
			
			IF @ATT_IdImpuestoISR > 0
			BEGIN
				INSERT INTO ProNotasCreditoConceptosFacturacionImpuestos(IdNotaCreditoConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdNotaCreditoConceptoFacturacion,@ATT_IdImpuestoISR,@ATT_ImporteISR)
			END


			FETCH NEXT FROM ProNotasCreditoConceptosFacturacionCursor
			INTO @ATT_IdFactura ,@ATT_IdConceptoFacturacion ,@ATT_Importe ,@ATT_TrasladaImpuesto ,@ATT_RetieneImpuesto,	@ATT_IdImpuestoTraslada ,@ATT_ImporteTraslada,@ATT_IdImpuestoRetiene,@ATT_ImporteRetiene,@ATT_IdImpuestoIEPS ,@ATT_ImporteIEPS,@ATT_IdImpuestoISR ,@ATT_ImporteISR,@ATT_IdFacturaConceptoFacturacion
		END

		CLOSE ProNotasCreditoConceptosFacturacionCursor
		DEALLOCATE ProNotasCreditoConceptosFacturacionCursor
		/**/


		
		
		--IF @TieneAjuste = 0
		--BEGIN		
		--	---------genera un error si los importes de los conceptos de fact son mayores al subtotal de  la nota de credio
		--	IF (SELECT ISNULL(SUM(ROUND(Importe,4)),0) FROM ProNotasCreditoConceptosFacturacion WHERE IdNotaCredito = @IdNotaCredito) <> ROUND(@SubTotal,4)
		--		RAISERROR(N'La suma de los importes de los conceptos de facturación no son iguales al subtotal',
		--			16,
		--			1
		--			)
		--END			
		
				
		---actualizo abonos en los conceptos de facturacion de la factura		
		UPDATE ProFacturasConceptosFacturacion SET 
			Abonos = ISNULL(Abonos,0)+#TempProNotasCreditoConceptosFacturacion.ATT_Importe
		FROM ProFacturasConceptosFacturacion 
		INNER JOIN #TempProNotasCreditoConceptosFacturacion ON ProFacturasConceptosFacturacion.IdFactura = #TempProNotasCreditoConceptosFacturacion.ATT_IdFactura AND ProFacturasConceptosFacturacion.IdConceptoFacturacion = #TempProNotasCreditoConceptosFacturacion.ATT_IdConceptoFacturacion AND ProFacturasConceptosFacturacion.IdFacturaConceptoFacturacion = #TempProNotasCreditoConceptosFacturacion.ATT_IdFacturaConceptoFacturacion
		
		--agrego cobranza
		INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdNotaCredito,IdSucursal,Importe,TipoCambio)
		SELECT @CreadoEl,@CreadoPor,@FechaHora,@IdCliente,@IdConceptoCobranza,ATT_IdFactura,@IdMoneda,@IdNotaCredito,@IdSucursal,ATT_Importe,@TipoCambio
		FROM #TempProNotasCreditoFacturas
		
		--verificar que la suma de cobranza por factura sea igual a los abonos
		SET @IdFacturaError = 
		(SELECT TOP 1 pf.IdFactura FROM ProFacturas AS pf 
		INNER JOIN #TempProNotasCreditoFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura 
		WHERE ISNULL(pf.Abonos,0) != 
			(SELECT ISNULL(SUM(pc.Importe),0) FROM ProCobranza AS pc 
			INNER JOIN CatConceptosCobranza AS ccc ON pc.IdConceptoCobranza = ccc.IdConceptoCobranza 
			LEFT JOIN ProMovimientosBancarios AS pmb ON pc.IdMovimientoBancario = pmb.IdMovimientoBancario
			WHERE ccc.TipoConcepto = 2 
			AND pc.IdFactura = pf.IdFactura 
			AND ((pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NULL AND pmb.CanceladoEl IS NULL) 
				OR (pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NOT NULL AND pmb.FechaCancelacionSAT IS NULL) 
				OR (pc.IdConceptoCobranza IN(3) AND pc.CanceladoEl IS NULL) 
				OR (pc.IdConceptoCobranza IN(6) AND pc.CanceladoEl IS NULL AND NOT EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor)) 
				OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND Secuencia=pc.Secuencia AND FolioFiscalUUIDPagos IS NOT NULL AND FechaCancelacionSAT IS NULL))
				OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND FolioFiscalUUIDPagos IS NULL AND pc.CanceladoEl IS NULL))
				)
			)
		)
		
		IF @IdFacturaError IS NOT NULL AND @IdFacturaError <> 0
		BEGIN
			SET @DoctoFacturaError = (SELECT CASE cf.Serie
				WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
				ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
			END
			FROM ProFacturas AS pf
			INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
			INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
			WHERE IdFactura = @IdFacturaError)

			SET @MensajeFacturaError = 'El saldo de la factura '+@DoctoFacturaError+' es menor al importe a pagar de la nota de crédito, favor de revisar que otro usuario no haya realizado un pago o una nota de crédito a esta factura.'
	                    
			RAISERROR(@MensajeFacturaError,
				16,
				1
				)            
		END
		
		--inicia seccion para actualizar la informacion de los contrarecibos solicitud 9304
		DECLARE ProFacturasCursor CURSOR FOR
		SELECT DISTINCT tmp.ATT_IdFactura,tmp.ATT_Importe,pcrcf.IdContraReciboCliente,pc.IdCobranza
		FROM #TempProNotasCreditoFacturas AS tmp
		INNER JOIN ProContraRecibosClienteFacturas AS pcrcf ON tmp.ATT_IdFactura = pcrcf.IdFactura
		INNER JOIN ProCobranza AS pc ON tmp.ATT_IdFactura = pc.IdFactura 
		INNER JOIN ProContraRecibosCliente AS pcrc ON pcrcf.IdContraReciboCliente = pcrc.IdContraReciboCliente
		WHERE pc.IdNotaCredito = @IdNotaCredito AND pc.IdMoneda = @IdMoneda AND pcrc.Estatus <> 3

		OPEN ProFacturasCursor
		FETCH NEXT FROM ProFacturasCursor
		INTO @ATT_IdFactura,@ATT_Importe,@ATT_IdContraReciboCliente,@IdCobranza
    
		WHILE @@FETCH_STATUS = 0
		BEGIN		

			DECLARE @FolioContraRecibo int, @DocFacturaContraRecibo varchar(50)
			-- valida que el contra recibo no este cancelado
			SET @FolioContraRecibo = (Select Folio from ProContraRecibosCliente WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente)	
			IF EXISTS(Select IdContraReciboCliente from ProContraRecibosCliente where Estatus = 3 AND IdContraReciboCliente = @ATT_IdContraReciboCliente)	
			BEGIN		
				SET @MensajeError = 'El contra recibo de cliente '+@FolioContraRecibo +' que esta intentando pagar ya fue cancelada por otro usuario, verificar información'
				RAISERROR(@MensajeError,
							16,
							1
							)
			END	

			SET @ImporteClienteDLLSContraRecibo = 0
			SET @ImporteClientePESOSContraRecibo = 0

			IF @IdMoneda = 2
				SET @ImporteClienteDLLSContraRecibo =@ATT_Importe
			ELSE
				SET @ImporteClientePESOSContraRecibo  =@ATT_Importe
			
			-- Actualiza la información en la tabla puente, asignando el IdCobranza si es nulo, o agregando un nuevo registro si ya tiene registrado un pago 
			IF (SELECT TOP 1 ISNULL(IdCobranza,0) FROM ProContraRecibosClienteFacturas WHERE IdFactura = @ATT_IdFactura) = 0
				--Se agrega el top 1 para evitar IdCobranza duplicado en caso de que existan mas registros de la factura con IdCobranza NULL SOLICITUD 010143
				UPDATE TOP (1) ProContraRecibosClienteFacturas set IdCobranza = @IdCobranza where IdFactura = @ATT_IdFactura
			ELSE
				IF NOT EXISTS(SELECT IdCobranza FROM ProContraRecibosClienteFacturas WHERE IdFactura = @ATT_IdFactura AND IdCobranza = @IdCobranza)
				BEGIN
					INSERT INTO ProContraRecibosClienteFacturas (IdContraReciboCliente,IdFactura,Importe,IdCobranza)
					values(@ATT_IdContraReciboCliente,@ATT_IdFactura,@ATT_Importe,@IdCobranza)
				END
			
			UPDATE ProContraRecibosCliente 
					SET TotalAbonoDolares =TotalAbonoDolares +@ImporteClienteDLLSContraRecibo 
					,TotalAbonoPesos=TotalAbonoPesos+@ImporteClientePESOSContraRecibo
			WHERE ProContraRecibosCliente.IdContraReciboCliente =  	@ATT_IdContraReciboCliente
			
		 -- Actualizar estatus	contra recibo de cliente  	
			DECLARE @CantidadFacturas int, @CantidadFacturasPagadas int
			SET @CantidadFacturas = (SELECT  count(ProFacturas.Estatus)
												FROM  ProContraRecibosClienteFacturas INNER JOIN
														ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
												WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @ATT_IdContraReciboCliente  AND ProFacturas.Estatus<> 2) )

			SET @CantidadFacturasPagadas =(SELECT  count(ProFacturas.Estatus)
												FROM  ProContraRecibosClienteFacturas INNER JOIN
														ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
												WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @ATT_IdContraReciboCliente  and ProFacturas.Estatus = 1 AND ProFacturas.Estatus<> 2 ))
			--se comenta seccion y se agrega parte para cambiar el estatus del contrarecibo en cuanto tenga un abono solicitud 9304
			--IF @CantidadFacturasPagadas > 0 
				IF @CantidadFacturas = @CantidadFacturasPagadas
					UPDATE ProContraRecibosCliente SET Estatus = 2, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
					WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente  -- Pagada
				ELSE
					UPDATE ProContraRecibosCliente SET Estatus = 1, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
					WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente  -- Parcialmente pagada
			--Se agrega seccion para actualizar los saldos del contrarecibo SOLICITUD 10087
			--ELSE
			--	UPDATE ProContraRecibosCliente SET Estatus = 0, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
			--	WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente  -- Pendiente de pagar
			-- Fin actualizar estatus de contra recibo de cliente        			        
			FETCH NEXT FROM ProFacturasCursor
			INTO @ATT_IdFactura,@ATT_Importe,@ATT_IdContraReciboCliente,@IdCobranza
		END        
    
		CLOSE ProFacturasCursor
		DEALLOCATE ProFacturasCursor
		--termina seccion para actualizar la informacion de los contrarecibos solicitud 9304				
		
		-- actualiza el estatus del folio
		UPDATE CatFolios SET Estatus = 2 WHERE IdFolio = @IdFolio

		IF @IdAddenda > 0
		BEGIN
			INSERT INTO ProNotasCreditoAddendasCamposAdicionales(Campo1,Campo10,Campo2,Campo3,Campo4,Campo5,Campo6,Campo7,Campo8,Campo9,IdAddenda,IdNotaCredito,CreadoEl,CreadoPor)
			VALUES(@Campo1,@Campo10,@Campo2,@Campo3,@Campo4,@Campo5,@Campo6,@Campo7,@Campo8,@Campo9,@IdAddenda,@IdNotaCredito,@CreadoEl,@CreadoPor)
		END

		--actualiza el saldo del cliente 
		IF @IdMoneda = 1 OR @IdMoneda = 3
			UPDATE CatClientes SET SaldoCredito = SaldoCredito - @Total WHERE IdCliente = @IdCliente
		ELSE
			UPDATE CatClientes SET SaldoCreditoDLLS = SaldoCreditoDLLS - @Total WHERE IdCliente = @IdCliente

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

