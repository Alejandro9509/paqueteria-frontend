CREATE PROCEDURE [dbo].[usp_CatMotivosDesecharLlantasModificar]
@IdMotivoDesecharLlanta	int,
@Codigo	int,	
@DescripcionMotivo	varchar(50),	
@Activo bit,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMotivoDesecharLlanta,0)= 0
	RAISERROR(N'El identificador de motivo desechar llanta es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de motivo desechar llanta  es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatMotivosDesecharLlantas WHERE Codigo = @Codigo AND IdMotivoDesecharLlanta<>@IdMotivoDesecharLlanta )
		RAISERROR(N'El código de motivo desechar llanta ya existe',
			16,
			1
			)	
				
	IF ISNULL(@DescripcionMotivo,'')= ''
		RAISERROR(N'El descripción de motivo desechar llanta  es un campo requerido',
			16,
			1
			)
	-- Modifica datos del catalo de motivos de desechar llantas		
	UPDATE CatMotivosDesecharLlantas SET
		Codigo= @Codigo,
		DescripcionMotivo= @DescripcionMotivo,
		Activo= @Activo,		
		ModificadoEl= @ModificadoEl,
		ModificadoPor= @ModificadoPor
	WHERE 	IdMotivoDesecharLlanta=@IdMotivoDesecharLlanta
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

