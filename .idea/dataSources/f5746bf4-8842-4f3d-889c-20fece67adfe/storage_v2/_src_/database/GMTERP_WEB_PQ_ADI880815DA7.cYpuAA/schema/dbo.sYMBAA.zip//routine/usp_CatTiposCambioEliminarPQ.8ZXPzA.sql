
CREATE PROCEDURE [dbo].[usp_CatTiposCambioEliminarPQ]
	@IdTipoCambio INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdTipoCambio,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del Tipo de cambio es un campo requerido*FIN*', 16, 1)
			return

		end
		DELETE FROM CatTiposCambioPQ
		WHERE IdTipoCambio = @IdTipoCambio
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

