CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosMaxNumeroMovimiento]  
@IdCuentaBancaria int 
AS  
Select ISNULL(MAX(NumeroMovimiento),0)+1 AS NumeroCheque from ProMovimientosBancarios where IdCuentaBancaria = @IdCuentaBancaria
go

