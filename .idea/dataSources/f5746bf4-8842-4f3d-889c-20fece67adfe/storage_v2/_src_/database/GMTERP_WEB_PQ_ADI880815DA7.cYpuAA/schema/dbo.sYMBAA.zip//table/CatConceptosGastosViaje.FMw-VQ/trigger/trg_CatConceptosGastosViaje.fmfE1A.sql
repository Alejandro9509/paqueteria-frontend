CREATE TRIGGER [dbo].[trg_CatConceptosGastosViaje]
   ON  [dbo].[CatConceptosGastosViaje]
   AFTER UPDATE
AS 
BEGIN

	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
	BEGIN
		IF EXISTS(SELECT * 
		FROM INSERTED I
		INNER JOIN DELETED D ON I.IdConceptoGastoViaje = D.IdConceptoGastoViaje
		WHERE I.ConceptoGastoViaje <> D.ConceptoGastoViaje OR 
		I.Codigo <> D.Codigo OR 
		I.Activo <> D.Activo OR
		I.DefinidoPorSistema <> D.DefinidoPorSistema OR
		I.ConsiderarCalculoISPT <> D.ConsiderarCalculoISPT OR
		I.ConsiderarCalculoRendimiento <> D.ConsiderarCalculoRendimiento OR
		I.GastoACredito <> D.GastoACredito)
		RAISERROR(N'Este concepto no se puede modificar porque es dado de alta por sistema.',
			16,
			1
			)
	END
	
	IF EXISTS(SELECT * 	FROM INSERTED I
		INNER JOIN DELETED D ON I.IdConceptoGastoViaje = D.IdConceptoGastoViaje
		WHERE I.ConceptoGastoViaje <> D.ConceptoGastoViaje)
	BEGIN
		IF EXISTS(Select Top 1 IdRutaTrayectoGasto from CatRutasTrayectosGastos Where IdConceptoGastoViaje IN (SELECT IdConceptoGastoViaje FROM deleted))
			RAISERROR(N'El concepto no se puede modificar porque ya cuenta con asignaciones en gastos autorizados de la ruta/trayecto',
				16,
				1
				)

		IF EXISTS(Select Top 1 IdGastoViaje from ProGastosViaje Where IdConceptoGastoViaje IN (SELECT IdConceptoGastoViaje FROM deleted))
			RAISERROR(N'El concepto no se puede modificar porque ya cuenta con asignaciones en gastos de viaje',
				16,
				1
				)			
	END	
END
go

