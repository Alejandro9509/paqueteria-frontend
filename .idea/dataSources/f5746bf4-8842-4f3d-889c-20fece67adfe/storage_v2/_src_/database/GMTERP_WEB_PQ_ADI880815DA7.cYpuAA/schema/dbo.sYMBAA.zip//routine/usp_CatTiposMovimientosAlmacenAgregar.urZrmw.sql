
CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosAlmacenAgregar]
@Codigo	int,	
@Movimiento	varchar(50),	
@Tipo	varchar(50),
@Folio	int,
@CreadoEl	datetime,	
@CreadoPor	int,	
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del tipo de movimiento es un campo requerido',
			16,
			1
			)
	IF ISNULL(@Movimiento,'')= ''
		RAISERROR(N'El tipo de movimiento es un campo requerido',
			16,
			1
			)
	INSERT INTO CatTiposMovimientosAlmacen(Codigo,Movimiento,Tipo,Folio,CreadoEl,CreadoPor)
	VALUES(@Codigo,@Movimiento,@Tipo,@Folio,@CreadoEl,@CreadoPor)
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

