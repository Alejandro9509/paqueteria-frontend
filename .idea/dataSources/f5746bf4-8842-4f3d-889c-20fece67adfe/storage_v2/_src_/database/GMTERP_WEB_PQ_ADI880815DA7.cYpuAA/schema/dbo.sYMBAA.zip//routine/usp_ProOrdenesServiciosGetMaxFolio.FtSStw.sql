CREATE PROCEDURE [dbo].[usp_ProOrdenesServiciosGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProOrdenesServicios
go

