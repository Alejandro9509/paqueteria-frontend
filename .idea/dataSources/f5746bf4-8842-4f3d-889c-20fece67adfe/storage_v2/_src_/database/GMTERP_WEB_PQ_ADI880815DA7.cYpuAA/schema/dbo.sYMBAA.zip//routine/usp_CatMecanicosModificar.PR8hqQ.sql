CREATE PROCEDURE [dbo].[usp_CatMecanicosModificar]
@IdMecanico int,
@Codigo int,
@NombreCompleto varchar(100),
@CostoPorHora money,
@Activo bit,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMecanico,0)= 0
	RAISERROR(N'El identificador de mecánico es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de mecánico es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@NombreCompleto,'')= ''
		RAISERROR(N'El nombre del mecánico es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT Codigo FROM CatMecanicos WHERE Codigo = @Codigo AND IdMecanico <> @IdMecanico)
       RAISERROR(N'El código del mecánico ya existe',
           16,
           1
           )

	UPDATE CatMecanicos SET
			Codigo= @Codigo,
			NombreCompleto= @NombreCompleto,
			CostoPorHora = @CostoPorHora,
			Activo = @Activo,
			ModificadoEl= @ModificadoEl,
			ModificadoPor= @ModificadoPor
	WHERE 	IdMecanico=@IdMecanico

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

