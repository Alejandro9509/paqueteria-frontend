CREATE PROCEDURE [dbo].[usp_CatCotizacionAgregarPQ](
@IdOrigen int,
@IdDestino int,
@IdZonaEntrega int,
@IdCliente int,
@EntregaSucursal bit,
@ValorDeclarado money,
@AplicaRecoleccion bit,
@IdSeguro int,
@IdZonaRecoleccion int,
@IdEmbarque int,
@IdRecoleccion int
	)
AS
BEGIN
	BEGIN TRANSACTION
		
		insert into CatCotizacion(IdOrigen,IdDestino,IdZonaEntrega,IdCliente,EntregaSucursal,ValorDeclarado,AplicaRecoleccion,
		                          IdSeguro, IdZonaRecoleccion,IdEmbarque, IdRecoleccion)
		values (@IdOrigen,@IdDestino,@IdZonaEntrega,@IdCliente,@EntregaSucursal,@ValorDeclarado,@AplicaRecoleccion,
		        @IdSeguro, @IdZonaRecoleccion, @IdEmbarque, @IdRecoleccion);
	
end
go

