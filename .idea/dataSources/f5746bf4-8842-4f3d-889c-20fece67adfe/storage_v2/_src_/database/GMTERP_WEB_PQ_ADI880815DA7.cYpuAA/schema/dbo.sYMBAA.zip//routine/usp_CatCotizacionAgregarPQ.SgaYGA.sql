CREATE PROCEDURE [dbo].[usp_CatCotizacionAgregarPQ](
@IdOrigen int,
@IdDestino int,
@IdZonaEntrega int,
@IdCliente int,
@EntregaSucursal bit,
@ValorDeclarado money,
@AplicaRecoleccion bit,
@IdSeguro int,
@IdZonaRecoleccion int,
@IdEmbarque int,
@IdRecoleccion int,
    @AplicaSeguro bit,
@PorcentajeSeguro float
	)
AS
BEGIN
	BEGIN TRANSACTION
		
		insert into CatCotizacion(IdOrigen,IdDestino,IdZonaEntrega,IdCliente,EntregaSucursal,ValorDeclarado,AplicaRecoleccion,
		                          IdSeguro, IdZonaRecoleccion,IdEmbarque, IdRecoleccion, AplicaSeguro, PorcentajeSeguro)
		values (@IdOrigen,@IdDestino,@IdZonaEntrega,@IdCliente,@EntregaSucursal,@ValorDeclarado,@AplicaRecoleccion,
		        @IdSeguro, @IdZonaRecoleccion, @IdEmbarque, @IdRecoleccion, @AplicaSeguro,@PorcentajeSeguro );
	
end
go

