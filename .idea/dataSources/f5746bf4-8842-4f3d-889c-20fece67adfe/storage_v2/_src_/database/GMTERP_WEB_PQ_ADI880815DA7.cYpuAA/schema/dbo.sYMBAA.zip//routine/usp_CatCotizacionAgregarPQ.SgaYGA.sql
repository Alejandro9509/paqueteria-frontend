CREATE PROCEDURE [dbo].[usp_CatCotizacionAgregarPQ](
@IdOrigen int,
@IdDestino int,
@IdZonaEntrega int,
@IdCliente int,
@EntregaSucursal bit,
@ValorDeclarado money,
@AplicaRecoleccion bit,
@IdSeguro int,
@AplicaSeguro bit,
@PorcentajeSeguro float,
@IdEmbarque int,
@IdRecoleccion int,
    @IdZonaRecoleccion int
	)
AS
BEGIN
	BEGIN TRANSACTION
		
		insert into CatCotizacion(IdOrigen,IdDestino,IdZonaEntrega,IdCliente,EntregaSucursal,ValorDeclarado,AplicaRecoleccion,
		                          IdSeguro, IdZonaRecoleccion,IdEmbarque, IdRecoleccion, AplicaSeguro, PorcentajeSeguro)
		values (@IdOrigen,@IdDestino,@IdZonaEntrega,@IdCliente,@EntregaSucursal,@ValorDeclarado,@AplicaRecoleccion,
		        @IdSeguro, @IdZonaRecoleccion, @IdEmbarque, @IdRecoleccion, @AplicaSeguro,@PorcentajeSeguro );


        IF @@TRANCOUNT > 0
            BEGIN
                COMMIT TRANSACTION
            END
        ELSE
            BEGIN
                GOTO CANCELAR_TRANSACCION
            END

        CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
            BEGIN
                EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
            END
		end
go

