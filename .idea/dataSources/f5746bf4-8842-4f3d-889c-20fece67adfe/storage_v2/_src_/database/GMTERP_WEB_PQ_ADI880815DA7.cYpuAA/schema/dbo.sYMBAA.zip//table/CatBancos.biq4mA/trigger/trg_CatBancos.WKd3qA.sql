CREATE TRIGGER [dbo].[trg_CatBancos]
   ON  [dbo].[CatBancos]
   AFTER UPDATE
AS 
BEGIN
	IF EXISTS(SELECT TOP 1 IdBanco FROM CatCuentasBancarias Where IdBanco = (SELECT IdBanco FROM deleted))
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Banco <> D.Banco)
			RAISERROR(N'El Campo banco no puede ser modificado porque tiene cuentas bancarias asignadas',
				16,
				1
				)
	END
	
	IF (SELECT ClaveSAT FROM deleted) <> '999'
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Banco <> D.Banco)
			RAISERROR(N'El Campo banco no puede ser modificado porque pertenece al catálogo del SAT',
				16,
				1
				)
		IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Codigo <> D.Codigo)
			RAISERROR(N'El Campo codigo no puede ser modificado porque pertenece al catálogo del SAT',
				16,
				1
				)
	END
END
go

