
CREATE PROCEDURE [dbo].[usp_CatOperadoresAplicacionesMovilesDispositivo]
	@IdPeticion varchar(100),
	@IdOperador int ,
	@Aplicacion tinyint,
	@Dispositivo varchar(max)
	/*************************************************************************************************************************************
	@IdPeticion varchar(100),
	@IdOperador int ,
	@Aplicacion tinyint,
	@Dispositivo varchar(max),

	Creado por:  Luis Edgar Ramos Cadena
	Fecha de Creacion: 30/03/2021
	Versión
	Solicitud 3939
	
	Se creo para agregar un token al operador y aplicacion movil
	***************************************/
AS
BEGIN TRY
	BEGIN TRANSACTION

		DECLARE @IdAplicacion int
		SET @IdAplicacion = (SELECT IdAplicacionMovil FROM CatAplicacionesMoviles WHERE Aplicacion = @Aplicacion)

		UPDATE CatOperadoresAplicacionesMoviles SET
		Dispositivo = @Dispositivo
		WHERE IdOperador = @IdOperador AND IdAplicacionMovil = @IdAplicacion

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

