CREATE PROCEDURE [dbo].[usp_CatTiposCambioModificar]
	@IdTipoCambio int,
	@Fecha datetime,
	@TipoCambio money,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@IdPeticion varchar(100),
	@UltimaModificacion datetime
AS
BEGIN TRY	
	BEGIN TRANSACTION
	
	IF (SELECT ModificadoEl FROM CatTiposCambio WHERE IdTipoCambio = @IdTipoCambio) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
	IF @Fecha = 0
		RAISERROR(N'El campo de fecha es requerido',
			16,
			1
			)
	IF @TipoCambio = 0
		RAISERROR(N'El campo tipo de cambio es requerido',
			16,
			1
			)			
	
	UPDATE CatTiposCambio SET TipoCambio = @TipoCambio,ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor WHERE IdTipoCambio = @IdTipoCambio
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

