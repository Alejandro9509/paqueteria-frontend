CREATE PROCEDURE [dbo].[usp_CatUnidadesAgregar]
	@IdTipoUnidad int,
	@Codigo varchar(16),
	@IdSucursal int,
	@IdOperador int,
	@Descripcion varchar(50),
	@Modelo smallint,
	@Activa bit,
	@SerieUnidad varchar(26),
	@SerieMotor varchar(26),
	@Placas varchar(9),
	@PlacasVencimiento datetime,
	@PlacasExtranjeras varchar(9),
	@PlacasExtranjerasVencimiento datetime,
	@Observaciones varchar(100),
	@Largo decimal(15,2),
	@Ancho decimal(15,2),
	@Alto decimal(15,2),
	@CantidadLlantas tinyint,
	@CapacidadTanqueCombustible int,
	@TipoCombustible tinyint,
	@RendimientoCargado decimal(15,2),
	@RendimientoVacio decimal(15,2),
	@Capacidad int,
	@TipoTransmision varchar(41),
	@TipoMotor varchar(41),
	@NumeroEjes tinyint,
	@CompaniaSeguros varchar(51),
	@TelefonosCompaniaSeguros varchar(21),
	@NumeroSeguro varchar(26),
	@VencimientoSeguro datetime,
	@TipoCoberturaSeguro tinyint,
	@PermisoSCT varchar(35),
	@VerificacionVehicular varchar(21),
	@VerificacionVehicularVencimiento datetime,
	@IdentificadorSatelital varchar(26),
	@Odometro int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsCatUnidadesImagenes ntext,
	@IdPeticion varchar(100),
	@CompaniaSeguros1 varchar(51),
	@TelefonosCompaniaSeguros1 varchar(21),
	@NumeroSeguro1 varchar(26),
	@VencimientoSeguro1 datetime,
	@TipoCoberturaSeguro1 tinyint,
	@TarjetaIAVE varchar(21),
	@TarjetaIAVE2 varchar(21),
	@PorcentajeRepIngresos decimal(15,2),
	@Rentada bit,
	@PlacasDefault tinyint,
	@dsCatUnidadesDocumentos ntext,
	@IdGrupoUnidad int,
	@TarjetaDiesel varchar(26),
	@TarjetaDiesel2 varchar(26),
	@EsUnidadPermisionario bit,
	@NumeroLlanta int,
	@LlantasRefaccion int,
	@IdTipoLlanta int,
	@IdMarcaLlanta int,
	@IdModeloLlanta int,
	@IdMedidaLlanta int,
	@IdPropietarioEquipo int,
	@AccesorioTV bit,
	@AccesorioAC bit,
	@AccesorioWIFI bit,
	@AccesorioDiscapacitados bit,
	@ColorUnidad varchar(20),
	@Horometro int,
	@CapacidadTanqueCombustibleGalones decimal(15,2),
	@OdometroMillas decimal (15,2),
	@RendimientoCargadoMillasGalones decimal(15,2),
	@RendimientoVacioMillasGalones decimal(15,2),
	@IdentificadorConvoy varchar(16),
	@VelocidadPromedio decimal (15,2),
	@Neutralizaciones decimal (15,2),
	@FrenadosBrusco decimal (15,2),
	@CargaDeAceleracion decimal (15,2),
	@AccionamientoPedalDeFreno decimal (15,2),
	@VelocidadMaximaMotor decimal (15,2),
	@PorcUltimoCambio decimal (15,2),
	@VelocidadPromedioUM Varchar(20),
	@NeutralizacionesUM Varchar(20),
	@FrenadosBruscoUM Varchar(20),
	@CargaDeAceleracionUM Varchar(20),
	@AccionamientoPedalDeFrenoUM Varchar(20),
	@VelocidadMaximaMotorUM Varchar(20),
	@PorcUltimoCambioUM Varchar(20), 
	@TarjetaDiesel3 Varchar(26),
	@HorasTrabajadasMotorNoGPS int = NULL,
	@TipoRemolqueSAT varchar(20) =	NULL,
	@PermisoSCTSAT varchar(20) = NULL,
	@PesoTara decimal(15,3) = NULL,
	@TransporteRentadaOPrestadaSAT varchar(20) = NULL

	/* *************************************************************************************************
	SOLICITUD 1178

	Descripcion: Se agrego el campo @HorasTrabajadasMotorNoGPS con el fin de utilizar el submodulo de mantenimiento "Servicios Programados"
	sin la necesidad de que la unidad tenga GPS.

	Modificada por:   Amado Navarro
	Fecha de mofidicacion: 27/02/2020
	Versión: Versión 8.0.50.18

	Descripcion: Se agregaron los campos @PesoTara, @PermisoSCTSAT y @TipoRemolqueSAT 

	Modificada por:   Gilberto Garcia
	Fecha de mofidicacion: 07/06/2021
	Versión: Versión 8.0.62.02

	Invocada desde: <CatUnidadesAM>
	************************************************************************************************ */
		
AS
DECLARE
	@IdUnidad int,
	@docHandle int,
	@CodigoUnidadTarjetaRegistrada varchar(16),--se usa para armar mensajes de error
	@MensajeError varchar(200),
	@IdentificadorUnidad int
BEGIN TRY
	BEGIN TRANSACTION
	
	IF LTRIM(RTRIM(@Codigo)) = ''
		RAISERROR(N'El código de la unidad es un campo requerido',
			16,
			1
			)

	SET @CodigoUnidadTarjetaRegistrada = (SELECT ctu.TipoUnidad FROM CatUnidades as cu INNER JOIN CatTiposUnidades AS ctu ON cu.IdTipoUnidad = ctu.IdTipoUnidad WHERE cu.Codigo = @Codigo)
	IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
	BEGIN
		SET @MensajeError = 'La unidad con el código '+@Codigo+' ya se encuentra registrada con el tipo de unidad '+@CodigoUnidadTarjetaRegistrada
			
		RAISERROR(@MensajeError,
			16,
			1
			)

	END
	IF @IdTipoUnidad = 0 
	RAISERROR(N'El tipo de unidad es un campo requerido',
		16,
		1
		)	

	IF @IdSucursal = 0 
	RAISERROR(N'La sucursal es un campo requerido',
		16,
		1
		)	

	IF @IdGrupoUnidad = 0 
	RAISERROR(N'El grupo de unidades es un campo requerido',
		16,
		1
		)					
			
	IF LTRIM(RTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)

	--IF @NumeroEjes = 0 
	--RAISERROR(N'El número de ejes es un campo requerido',
	--	16,
	--	1
	--	)
	
	IF EXISTS(SELECT IdentificadorSatelital FROM CatUnidades WHERE IdentificadorSatelital = @IdentificadorSatelital AND IdentificadorSatelital <> '')
	RAISERROR(N'El identificador satelital de la unidad ya existe',
		16,
		1
		)	

	IF LTRIM(RTRIM(@TarjetaIAVE)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE TarjetaIAVE = @TarjetaIAVE OR TarjetaIAVE2 = @TarjetaIAVE)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta iave/epass '+@TarjetaIAVE
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END	

	IF LTRIM(RTRIM(@TarjetaIAVE2)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE TarjetaIAVE = @TarjetaIAVE2 OR TarjetaIAVE2 = @TarjetaIAVE2)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta iave/epass '+@TarjetaIAVE2
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END	

	IF LTRIM(RTRIM(@TarjetaDiesel)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE TarjetaDiesel = @TarjetaDiesel OR TarjetaDiesel2 = @TarjetaDiesel OR TarjetaDiesel3 = @TarjetaDiesel)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta de combustible '+@TarjetaDiesel
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END	

	IF LTRIM(RTRIM(@TarjetaDiesel2)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE TarjetaDiesel = @TarjetaDiesel2 OR TarjetaDiesel2 = @TarjetaDiesel2 OR TarjetaDiesel3 = @TarjetaDiesel2)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta combustible '+@TarjetaDiesel2
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END

	IF LTRIM(RTRIM(@TarjetaDiesel3)) <> ''
	BEGIN
		SET @CodigoUnidadTarjetaRegistrada = (SELECT Codigo FROM CatUnidades WHERE TarjetaDiesel = @TarjetaDiesel3 OR TarjetaDiesel2 = @TarjetaDiesel3 OR TarjetaDiesel3 = @TarjetaDiesel3)
		
		IF ISNULL(@CodigoUnidadTarjetaRegistrada,'') <> ''
		BEGIN
			SET @MensajeError = 'La unidad '+@CodigoUnidadTarjetaRegistrada+' tiene registrada la tarjeta combustible '+@TarjetaDiesel3
			
			RAISERROR(@MensajeError,
				16,
				1
				)

		END
	END				
		
	IF @IdOperador = 0 
		SET @IdOperador = NULL
	ELSE
	BEGIN
		IF @EsUnidadPermisionario <> (SELECT EsPermisionario FROM CatOperadores WHERE IdOperador = @IdOperador)
		RAISERROR(N'La unidad y el operador deben tener el check de Permisionario activo para poder asignarse',
		16,
		1
		)
	END			
	
	--SE CONVIERTEN LAS LLAVES FORANEAS A NULL SI VIENEN CERO
	
	IF @IdMarcaLlanta = 0
	BEGIN 
		SET @IdMarcaLlanta = NULL
	END
	
	IF @IdModeloLlanta = 0 
	BEGIN
		SET @IdModeloLlanta = NULL
	END
	
	IF @IdMedidaLlanta = 0
	BEGIN 
		SET @IdMedidaLlanta = NULL
	END
	
	IF @IdTipoLlanta = 0
	BEGIN 
		SET @IdTipoLlanta = NULL
	END

	IF @IdPropietarioEquipo = 0
	BEGIN 
		SET @IdPropietarioEquipo = NULL
	END	

	IF @Horometro = 0
	BEGIN 
		SET @Horometro = NULL
	END	
	 
	 --SE REALIZA LA VALIDACION PARA QUE NO SE REPITA EL Identificador del convoy en los vehiculos unitarios con tractocamiones, igual para los dollys mas 2 dollrs no podran tener el mismo identidicador
	 --de acuerdo con los semiremolques si se podra repetir pero no mas de 2 semiremolques podran tener el mismo identiciadaor
	 IF ISNULL(@IdentificadorConvoy,'') <>''
	 BEGIN
		SET @IdentificadorUnidad = (select Identificador from CatTiposUnidades where IdTipoUnidad = @IdTipoUnidad )
		--1 VEHICULI uNITARIO, 2 TRACTOCAMION
		IF @IdentificadorUnidad = 1 OR @IdentificadorUnidad = 2 
		BEGIN
			IF (SELECT count(cu.IdUnidad) as NumeroUnidades FROM CatUnidades AS cu INNER JOIN CatTiposUnidades AS ctp ON cu.IdTipoUnidad = ctp.IdTipoUnidad where  ctp.Identificador in (1,2) and cu.IdentificadorConvoy = @IdentificadorConvoy ) >= 1
				RAISERROR(N'El identificador ya existe',
					16,
					1
					)
		END
		--4 SEMIRREMOLQUE,
		IF  @IdentificadorUnidad = 4
		BEGIN
			IF (SELECT count(cu.IdUnidad) as NumeroUnidades FROM CatUnidades AS cu INNER JOIN CatTiposUnidades AS ctp ON cu.IdTipoUnidad = ctp.IdTipoUnidad where  ctp.Identificador = @IdentificadorUnidad and cu.IdentificadorConvoy = @IdentificadorConvoy ) >= 2
				RAISERROR(N'El identificador ya existe',
					16,
					1
					)
		END

		--5 dolly,
		IF  @IdentificadorUnidad = 5
		BEGIN
			IF (SELECT count(cu.IdUnidad) as NumeroUnidades FROM CatUnidades AS cu INNER JOIN CatTiposUnidades AS ctp ON cu.IdTipoUnidad = ctp.IdTipoUnidad where  ctp.Identificador = @IdentificadorUnidad and cu.IdentificadorConvoy = @IdentificadorConvoy ) >= 1
				RAISERROR(N'El identificador ya existe',
					16,
					1
					)
		END

	 END

	 
	 		
	INSERT INTO CatUnidades(Activa,Alto,Ancho,CantidadLlantas,Capacidad,CapacidadTanqueCombustible,Codigo,CompaniaSeguros,CreadoEl,CreadoPor,
	Descripcion,IdOperador,IdSucursal,IdTipoUnidad,IdentificadorSatelital,Largo,Modelo,NumeroEjes,NumeroSeguro,Observaciones,Odometro,PermisoSCT,
	Placas,PlacasExtranjerasVencimiento,PlacasExtranjeras,PlacasVencimiento,RendimientoCargado,RendimientoVacio,SerieMotor,SerieUnidad,
	TelefonosCompaniaSeguros,TipoCoberturaSeguro,TipoCombustible,TipoMotor,TipoTransmision,VencimientoSeguro,VerificacionVehicular,
	VerificacionVehicularVencimiento,CompaniaSeguros1,TelefonosCompaniaSeguros1,NumeroSeguro1,VencimientoSeguro1,TipoCoberturaSeguro1,
	TarjetaIAVE,TarjetaIAVE2,PorcentajeRepIngresos,Rentada,PlacasDefault,IdGrupoUnidad,TarjetaDiesel,TarjetaDiesel2,EsUnidadPermisionario,
	NumeroLlanta,LlantaRefaccion,IdTipoLlanta,IdMarcaLlanta,IdModeloLlanta,IdMedidaLlanta,IdPropietarioEquipo,AccesorioTV,AccesorioAC,AccesorioWIFI,AccesorioDiscapacitados,ColorUnidad,Horometro,
	CapacidadTanqueCombustibleGalones,OdometroMillas,RendimientoCargadoMillasGalones,RendimientoVacioMillasGalones,IdentificadorConvoy,
	VelocidadPromedio,Neutralizaciones,FrenadosBrusco,CargaDeAceleracion,AccionamientoPedalDeFreno,VelocidadMaximaMotor,PorcUltimoCambio,
	VelocidadPromedioUM,NeutralizacionesUM,FrenadosBruscoUM,CargaDeAceleracionUM,AccionamientoPedalDeFrenoUM,VelocidadMaximaMotorUM,
	PorcUltimoCambioUM,TarjetaDiesel3,HorasTrabajadasMotorNoGPS, TipoRemolqueSAT, PermisoSCTSAT, PesoTara, TransporteRentadaOPrestadaSAT)
	VALUES(@Activa,@Alto,@Ancho,@CantidadLlantas,@Capacidad,@CapacidadTanqueCombustible,@Codigo,@CompaniaSeguros,@CreadoEl,@CreadoPor,
	@Descripcion,@IdOperador,@IdSucursal,@IdTipoUnidad,@IdentificadorSatelital,@Largo,@Modelo,@NumeroEjes,@NumeroSeguro,@Observaciones,@Odometro,@PermisoSCT,
	@Placas,@PlacasExtranjerasVencimiento,@PlacasExtranjeras,@PlacasVencimiento,@RendimientoCargado,@RendimientoVacio,@SerieMotor,@SerieUnidad,
	@TelefonosCompaniaSeguros,@TipoCoberturaSeguro,@TipoCombustible,@TipoMotor,@TipoTransmision,@VencimientoSeguro,@VerificacionVehicular,
	@VerificacionVehicularVencimiento,@CompaniaSeguros1,@TelefonosCompaniaSeguros1,@NumeroSeguro1,@VencimientoSeguro1,@TipoCoberturaSeguro1,
	@TarjetaIAVE,@TarjetaIAVE2,@PorcentajeRepIngresos,@Rentada,@PlacasDefault,@IdGrupoUnidad,@TarjetaDiesel,@TarjetaDiesel2,@EsUnidadPermisionario,
	@NumeroLlanta,@LlantasRefaccion,@IdTipoLlanta,@IdMarcaLlanta,@IdModeloLlanta,@IdMedidaLlanta,@IdPropietarioEquipo,@AccesorioTV,@AccesorioAC,@AccesorioWIFI,@AccesorioDiscapacitados,@ColorUnidad,@Horometro,
	@CapacidadTanqueCombustibleGalones,@OdometroMillas,@RendimientoCargadoMillasGalones,@RendimientoVacioMillasGalones,@IdentificadorConvoy,
	@VelocidadPromedio,@Neutralizaciones,@FrenadosBrusco,@CargaDeAceleracion,@AccionamientoPedalDeFreno,@VelocidadMaximaMotor,@PorcUltimoCambio,
	@VelocidadPromedioUM,@NeutralizacionesUM,@FrenadosBruscoUM,@CargaDeAceleracionUM,@AccionamientoPedalDeFrenoUM,@VelocidadMaximaMotorUM,
	@PorcUltimoCambioUM,@TarjetaDiesel3,@HorasTrabajadasMotorNoGPS, @TipoRemolqueSAT, @PermisoSCTSAT, @PesoTara, @TransporteRentadaOPrestadaSAT)
	
	SET @IdUnidad = (SELECT IDENT_CURRENT('CatUnidades'))
	
	IF @dsCatUnidadesImagenes IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUnidadesImagenes
		
		SELECT ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes
		INTO #TempCatUnidadesImagenes
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatUnidadesImagenes',2) 
		WITH (ATT_Imagen ntext,ATT_ImagenNombreArchivo varchar(150),ATT_Descripcion varchar(50),ATT_PesoBytes int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatUnidadesImagenes(IdUnidad,Imagen,ImagenNombreArchivo,Descripcion,PesoBytes)
		SELECT @IdUnidad,ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes 
		FROM #TempCatUnidadesImagenes
	END
	
	IF @dsCatUnidadesDocumentos IS NOT NULL
	BEGIN
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUnidadesDocumentos
		
		SELECT ATT_DescripcionDocumento,ATT_FechaVencimiento,ATT_NumeroDocumento
		INTO #TempCatUnidadesDocumentos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatUnidadesDocumentos',2) 
		WITH (ATT_DescripcionDocumento varchar(50),ATT_FechaVencimiento Datetime,ATT_NumeroDocumento varchar(50))

		EXEC sp_xml_removedocument @docHandle

		INSERT INTO CatUnidadesDocumentos(IdUnidad,DescripcionDocumento,FechaVencimiento,NumeroDocumento)
		SELECT @IdUnidad,ATT_DescripcionDocumento, ATT_FechaVencimiento,ATT_NumeroDocumento
		FROM #TempCatUnidadesDocumentos
	
	END
	
	INSERT INTO ProUnidadesOdometros(IdUnidad,Odometro,FechaLectura,Horometro,OdometroMillas)
	VALUES(@IdUnidad,@Odometro,@CreadoEl,@Horometro,@OdometroMillas)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

