
CREATE PROCEDURE [dbo].[usp_CatZonasTarifasCPAgregarPQ](
	@IdZona int,
	@IdCP int 
)
AS
BEGIN
	BEGIN TRANSACTION
		INSERT INTO CatZonasTarifasCPPQ (IdZona, IdCP)
		values(@IdZona, @IdCP)
		/*UPDATE CatZonasOperativasPQ 
		SET CodigoZona = @CodigoZona,
		IdEstado = @IdEstado,
		Estado = @IdEstado,
		CodigoMunicipio = @CodMunicipio,
		Municipio = @Municipio
		WHERE IdZona = @IdZona

		DELETE FROM CatZonasOperativasCPPQ WHERE IdZona = @IdZona*/
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

