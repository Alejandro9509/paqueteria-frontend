CREATE TRIGGER [dbo].[trg_CatPercepciones]
   ON  [dbo].[CatPercepciones]
   AFTER UPDATE
AS 
BEGIN
	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Percepcion <> D.Percepcion OR I.Codigo <> D.Codigo OR I.Activo <> D.Activo)
			RAISERROR(N'El Campo percepción y código no puede ser modificado porque esta definido por sistema o activo',
				16,
				1
				)
	END

	IF EXISTS(SELECT TOP 1 IdPercepcion FROM ProLiquidacionesPercepciones Where IdPercepcion = (SELECT IdPercepcion FROM deleted))
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Percepcion <> D.Percepcion OR I.Codigo <> D.Codigo)
			RAISERROR(N'El Campo percepción no puede ser modificado porque tiene liquidaciones asignadas',
				16,
				1
				)
	END
	--OR I.ClaveSAT <> D.ClaveSAT..(Se elimino esta condion para la SOLICITUD 006802 integracioon del complemento de nomina 12,para cambiar la ClaveSAT del las percepciones) 

	IF EXISTS(SELECT TOP 1 IdPercepcion FROM ProLiquidacionesFiscalesPercepciones Where IdPercepcion = (SELECT IdPercepcion FROM deleted))
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Percepcion <> D.Percepcion  OR I.Codigo <> D.Codigo)
			RAISERROR(N'El Campo percepción no puede ser modificado porque tiene liquidaciones asignadas',
				16,
				1
				)
	END
	--OR I.ClaveSAT <> D.ClaveSAT..(Se elimino esta condion para la SOLICITUD 006802 integracioon del complemento de nomina 12,para cambiar la ClaveSAT del las percepciones)	
END
go

