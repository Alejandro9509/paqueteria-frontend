CREATE PROCEDURE [dbo].[usp_CatFormatosAgregar]
	@Formato Varchar(50),
	@TipoProceso tinyint,
	@FormatoWDE ntext,
	@NombreArchivo Varchar(256),	
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@dsCatFormatosImagenes ntext,
	@dsCatFormatosEnvioAutomatico ntext
AS
DECLARE @IdFormato INT,
		@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	IF LTRIM(RTRIM(@Formato)) = ''
		RAISERROR(N'El formato es un campo requerido',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@NombreArchivo)) = ''
		RAISERROR(N'El Archivo es un campo requerido',
			16,
			1
			)

			
	INSERT INTO CatFormatos(Formato,TipoProceso,FormatoWDE,NombreArchivo,CreadoPor,CreadoEl,Activo)
	VALUES(@Formato,@TipoProceso,@FormatoWDE,@NombreArchivo,@CreadoPor,@CreadoEl,1)
	
	SET @IdFormato = (SELECT IDENT_CURRENT('CatFormatos'))
	
--  Guarda imagenes que se utiliza en el formato	
	IF @dsCatFormatosImagenes IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatFormatosImagenes
		
		SELECT ATT_Imagen,ATT_ImagenNombreArchivo
		INTO #TempCatFormatosImagenes
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatFormatosImagenes',2) 
		WITH (ATT_Imagen ntext,ATT_ImagenNombreArchivo varchar(150))
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatFormatosImagenes(IdFormato,Imagen,ImagenNombreArchivo,CreadoEl,CreadoPor)
		SELECT @IdFormato,ATT_Imagen,ATT_ImagenNombreArchivo,@CreadoEl,@CreadoPor FROM #TempCatFormatosImagenes
	END

	IF @dsCatFormatosEnvioAutomatico  IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatFormatosEnvioAutomatico 
		
		SELECT COL_IdFormatoEnvioAutomatico, COL_IdFormato, COL_TipoProceso, COL_TipoFactura, COL_TipoCobranza
		INTO #TempCatFormatosEnvioAutomatico
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_FormatosEnviosAutomaticos',2) 
		WITH (COL_IdFormatoEnvioAutomatico INT,COL_IdFormato int, COL_TipoProceso int,COL_TipoFactura int,COL_TipoCobranza int)
		
		EXEC sp_xml_removedocument @docHandle
		
		DELETE FROM CatFormatosEnvioAutomatico WHERE IdFormato = @IdFormato AND TipoProceso IN (select top 1 COL_TipoProceso FROM #TempCatFormatosEnvioAutomatico ) AND IdFormatoEnvioAutomatico NOT IN(SELECT COL_IdFormatoEnvioAutomatico FROM #TempCatFormatosEnvioAutomatico WHERE COL_IdFormatoEnvioAutomatico <> 0)
				
		INSERT INTO CatFormatosEnvioAutomatico(IdFormato, TipoProceso, TipoFactura, TipoCobranza, CreadoEl, CreadoPor)
		SELECT COL_IdFormato,COL_TipoProceso, COL_TipoFactura, COL_TipoCobranza, @CreadoEl, @CreadoPor
		FROM #TempCatFormatosEnvioAutomatico
		WHERE COL_IdFormatoEnvioAutomatico = 0		
	END
	ELSE
	BEGIN
		DELETE FROM CatFormatosEnvioAutomatico WHERE IdFormato = @IdFormato
	END
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

