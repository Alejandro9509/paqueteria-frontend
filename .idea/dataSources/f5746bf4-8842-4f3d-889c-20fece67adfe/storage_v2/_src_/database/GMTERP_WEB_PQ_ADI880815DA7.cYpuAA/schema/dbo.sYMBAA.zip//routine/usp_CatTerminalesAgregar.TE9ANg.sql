
/* *************************************************************************************************
Script de agregar terminal para el catálogo de Terminales

Parámetros: 
	@Codigo int,				(entrada, entero). Código de Terminal
	@Descripcion varchar(50),	(entrada, string). Descripción de Terminal
	@Activo bit,				(entrada, bit). Estado de Terminal (Activo/Inactivo)
	@CreadoEl datetime,			(entrada, fecha hora). Fecha en la que se realiza la creación
	@CreadoPor int,				(entrada, entero). Quien solicita la creación
	@IdPeticion varchar(100)	(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento crea una nueva Terminal para el Catálogo de Terminales del módulo Operación Portuaria.

Implementada por: David Rivera Navarro
Fecha de implementación: 09/07/2019
Versión: Versión 8.0.44.22

Modificada por:   <Nombre del último progrador que lo modificó>
Fecha de mofidicación: <(dd/mm/yyyy)>
Versión: <Versión ERP para la que fue modificada >

Invocada desde: PAGE_CatTerminalesAM (Solicitud 12815)

Valor de retorno: NA.

Ejemplo de Uso: NA.

***************************************************************************************************** */


CREATE PROCEDURE [dbo].[usp_CatTerminalesAgregar]
	@Codigo int,
	@Descripcion varchar(50),
	@Activo bit,
	@CreadoEl datetime,
	@CreadoPor int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	-- Envía un mensaje de error si la el Código de Terminal no contiene información
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de terminal es un campo requerido',
			16,
			1
			)

	-- Envía un mensaje de error si el variable Codigo de terminal ya se encuentra registrado
	IF EXISTS(SELECT Codigo FROM CatTerminales WHERE Codigo = @Codigo)
		RAISERROR(N'El código de terminal ya existe',
			16,
			1
			)
	
	-- Envía un mensaje de error si la variable Descripcion no contiene información
	IF LTRIM(RTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)
			
	-- Se agrega una nueva Terminal a la Tabla
	INSERT INTO CatTerminales(Codigo, Descripcion, Activo,CreadoEl, CreadoPor)
	VALUES(@Codigo,@Descripcion, @Activo,@CreadoEl,@CreadoPor)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

