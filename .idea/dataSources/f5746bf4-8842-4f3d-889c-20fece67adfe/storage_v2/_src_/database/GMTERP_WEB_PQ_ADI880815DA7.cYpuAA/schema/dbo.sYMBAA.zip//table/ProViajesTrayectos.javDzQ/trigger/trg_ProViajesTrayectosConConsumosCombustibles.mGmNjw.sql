CREATE TRIGGER [dbo].[trg_ProViajesTrayectosConConsumosCombustibles]
    ON dbo.ProViajesTrayectos
    AFTER UPDATE
AS
BEGIN
        
        IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
        WHERE (I.CodigoUnidadCamion <> D.CodigoUnidadCamion OR I.IdUnidadCamion <> D.IdUnidadCamion)
        AND EXISTS(SELECT IdConsumoCombustible FROM ProConsumosCombustible WHERE ProConsumosCombustible.IdViajeTrayecto = I.IdViajeTrayecto))
        BEGIN            
            RAISERROR(N'No puede modificarse el viaje trayecto porque ya tiene consumos de combustibles referenciadas',
                16,
                1
                )
        END                  
END
go

