CREATE TRIGGER [dbo].[trg_ProViajesDescripcionesCargaFacturados]
	ON [dbo].[ProViajesDescripcionesCarga]
	AFTER UPDATE,INSERT
AS
BEGIN
	DECLARE @PendienteFacturar bit 
	DECLARE @FacturadoParcialmente bit
	DECLARE @CPCreadaParaComplemento BIT

	SET @PendienteFacturar = (SELECT top 1 PendienteFacturar FROM ProViajes WHERE IdViaje in (SELECT IdViaje FROM deleted))
	SET @FacturadoParcialmente = (SELECT tOP 1 FacturadoParcialmente FROM ProViajes WHERE IdViaje in (SELECT IdViaje FROM deleted))
	SET @CPCreadaParaComplemento = (SELECT TOP 1 CreadaParaComplemento FROM ProViajesCartasPorte WHERE IdViaje IN (SELECT IdViaje FROM deleted));

	IF @CPCreadaParaComplemento = 1
	BEGIN
		IF @PendienteFacturar = 0 OR @FacturadoParcialmente = 1
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.IdViajeDescripcionCarga=D.IdViajeDescripcionCarga
			WHERE I.Tarifa <> D.Tarifa OR I.Importe <> D.Importe OR I.TarifaAplicadaPor <> D.TarifaAplicadaPor)
			RAISERROR(N'No pueden modificarse las descripciones de carga del viaje porque está facturado.',
				16,
				1
				)        
        
		END
	END

END
go

