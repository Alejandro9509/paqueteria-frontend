CREATE TRIGGER [dbo].[trg_CatMedidasLlantas]
    ON [dbo].[CatMedidasLlantas]
    AFTER UPDATE
AS
BEGIN               
    IF EXISTS(Select Top 1 IdMedidaLlanta 
				from CatModelosLlantas 
				Where IdMedidaLlanta = (SELECT IdMedidaLlanta FROM deleted d where  d.IdMedidaLLanta =IdMedidaLlanta)) 	
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.DescripcionMedida <> D.DescripcionMedida)
		RAISERROR(N'La Medida no se puede modificar porque ya cuenta con modelos ligados',
			16,
			1
			)
	END	                   
END
go

