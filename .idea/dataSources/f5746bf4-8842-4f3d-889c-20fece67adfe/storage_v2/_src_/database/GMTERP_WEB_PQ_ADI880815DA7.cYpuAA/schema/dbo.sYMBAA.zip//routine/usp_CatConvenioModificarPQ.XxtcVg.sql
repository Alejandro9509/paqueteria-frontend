

CREATE PROCEDURE [dbo].[usp_CatConvenioModificarPQ](
	@IdConvenio int,
	@IdCliente int,
	@Vigencia varchar(80),
	@activo bit,
	@CuotaMensual money)
AS
BEGIN
	BEGIN TRANSACTION
	DECLARE @VigenciaDate date;
		IF ISNULL(@IdConvenio, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador de convenio es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF @Vigencia IS NOT NULL AND LEN(@Vigencia) > 0 begin
			set @VigenciaDate = CAST(@Vigencia as date)
		end
		update CatConveniosPQ set IdCliente = @IdCliente,
		Vigencia = @VigenciaDate,
		activo = @activo,
		CuotaMensual=@CuotaMensual
		where IdConvenio = @IdConvenio;
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

