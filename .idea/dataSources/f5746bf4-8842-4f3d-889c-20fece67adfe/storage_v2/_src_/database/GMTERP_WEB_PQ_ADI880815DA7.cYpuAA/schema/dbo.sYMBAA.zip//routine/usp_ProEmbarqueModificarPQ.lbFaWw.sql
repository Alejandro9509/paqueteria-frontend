CREATE PROCEDURE [dbo].[usp_ProEmbarqueModificarPQ](
	@IdEmbarque int, @FolioRecoleccion int, @Fecha varchar(20), @Hora varchar(20) , --4
	@IdEstatusEmbarque int, @IdMoneda int, @TipoCambio money, @IdTipoCobro int , --8
	@NombreRemitente varchar(150), @RFCRemitente varchar(13),@DomicilioRemitente varchar(250) ,@IdCodigoPostalRemitente int , --12 bien
	@IdCiudadRemitente int ,@CorreoRemitente varchar(150) ,@TelefonoRemitente varchar(20) ,@ContactoRemitente varchar(80) , --16
	@IdCiudadOrigen int , @NombreDestinatario varchar(150) ,@RFCDestinatario varchar(13) ,@DomicilioDestinatario varchar(250) , --20
	@IdCodigoPostalDestinatario int ,@IdCiudadDestinatario int ,@CorreoDestinatario varchar(150) ,@TelefonoDestinatario varchar(20) , --24
	@ContactoDestinatario varchar(80) ,@IdCiudadDestino int ,@FechaEntrega date NULL,@HoraEntrega time(7) NULL, --28
	@NoPaquetes int ,@NoSobres int,@IdOperador int,@IdUnidad int, --32
	@EntregarMismoDomicilio bit,@FechaLlegada date,@HoraLlegada time(7),@CodigoPostalEntrega int, --36 bien
	@IdCiudadEntrega int,@IdZonaEntrega int,@DomicilioEntrega varchar(200),@EntregarEn varchar(200), --40
	@DatosAdicionales varchar(500),@IdSucursal int,@EntregaEnSucursal bit, @IdSucursalEntrega int, --44
	@FolioEmbarque varchar(200),@IdCliente int,@IdZonaRemitente int,@IdZonaDestinatario int, --48
	@IdRemitente int,@IdDestinatario int,@AliasRemitente varchar(100),@AliasDestinatario varchar(100),--52

	@CalleRemitente varchar(100),@NoIntRemitente varchar(20),@NoExtRemitente varchar(20),@ColoniaRemitente varchar(100), --56
	@CalleDestinatario varchar(100),@NoIntDestinatario varchar(20),@NoExtDestinatario varchar(20),@ColoniaDestinatario varchar(100), @RecoleccionConCita bit,
	@FechaCita varchar(50),
	@HoraCitaMinima varchar(50),
	@HoraCitaMaxima varchar(50), --64
	@Latitud text,
	@Longitud text,
	@IdZonaOperativa int,
	@IdZonaTarifa int
	,@IdEstadoRemitente int,
	@IdEstadoDestinatario int,
	@MunicipioRemitente varchar(100),
	@MunicipioDestinatario varchar(100),
	@IdZonaOperativaRecoleccion int,
	@IdZonaTarifaRecoleccion int,
	@IdEstadoEntrega int,
	@CodigoMunicipioEntrega varchar(100),
	@ValorDeclarado float,
    @IdTipoSeguro int,
    @PorcentajeSeguro float,
    @AplicaSeguro bit
	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @FechaCitaDate date;
		DECLARE @HoraCitaMinimaTime time;
		DECLARE @HoraCitaMaximaTime time;

		IF @FechaCita IS NOT NULL AND LEN(@FechaCita) > 1 begin
			set @FechaCitaDate= CAST(@FechaCita as date)
		end
		IF @HoraCitaMinima IS NOT NULL AND LEN(@HoraCitaMinima) > 1 begin
			set @HoraCitaMinimaTime= CAST(@HoraCitaMinima as time)
		end

		IF @HoraCitaMaxima IS NOT NULL AND LEN(@HoraCitaMaxima) > 1 begin
			set @HoraCitaMaximaTime= CAST(@HoraCitaMaxima as time)
		end

		IF ISNULL(@IdSucursal, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			return;
		end

		IF ISNULL(@IdEmbarque, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador es un campo requerido*FIN*', 16, 1)
			
			return;
		end
		
		
		IF ISNULL(@IdEstatusEmbarque, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de estatus es un campo requerido*FIN*', 16, 1)
			
			return;
		end
		IF ISNULL(@IdMoneda, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de Moneda es un campo requerido*FIN*', 16, 1)
			
			return;
		end
		IF ISNULL(@TipoCambio, 0) = 0 begin
			RAISERROR(N'*INICIO*El Tipo de cambio es un campo requerido*FIN*', 16, 1)
			
			return;
		end
		IF ISNULL(@IdTipoCobro, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de tipo de cobro es un campo requerido*FIN*', 16, 1)
			
			return;
		end

		declare @ExisteGuia int;
		select @ExisteGuia = count(*)
		from dbo.ProGuiaPQ g
		where g.IdEmbarque = @IdEmbarque;
		if @ExisteGuia > 0 begin
			RAISERROR(N'*INICIO*No es posible modificar el embarque ya que pertenece a una guia*FIN*', 16, 1)
			return;
		end
		
		update dbo.ProEmbarquePQ 
		set IdRecoleccion = @FolioRecoleccion,
		IdEstatusEmbarque = @IdEstatusEmbarque,

		IdMoneda = @IdMoneda,
		TipoCambio = @TipoCambio,
		IdTipoCobro = @IdTipoCobro,
		NombreRemitente = @NombreRemitente,
		RFCRemitente = @RFCRemitente,

		DomicilioRemitente = @DomicilioRemitente,
		IdCodigoPostalRemitente = @IdCodigoPostalRemitente,
		IdCiudadRemitente = @IdCiudadRemitente,
		CorreoRemitente = @CorreoRemitente,
		TelefonoRemitente = @TelefonoRemitente,

		ContactoRemitente = @ContactoRemitente,
		IdCiudadOrigen = @IdCiudadOrigen, 
		NombreDestinatario = @NombreDestinatario,
		RFCDestinatario = @RFCDestinatario,
		DomicilioDestinatario = @DomicilioDestinatario,

		IdCodigoPostalDestinatario = @IdCodigoPostalDestinatario,
		IdCiudadDestinatario = @IdCiudadDestinatario,
		CorreoDestinatario = @CorreoDestinatario,
		TelefonoDestinatario = @TelefonoDestinatario,
		ContactoDestinatario = @ContactoDestinatario,
		
		IdCiudadDestino = @IdCiudadDestino,
		--FechaEntrega = @FechaEntrega,
		--HoraEntrega = @HoraEntrega,
		NoPaquetes = @NoPaquetes,
		NoSobres = @NoSobres,

		--IdOperador = @IdOperador,
		--IdUnidad = @IdUnidad,
		EntregarMismoDomicilio = @EntregarMismoDomicilio,
		--FechaLlegada = @FechaLlegada,
		--HoraLlegada = @HoraLlegada,
		CodigoPostalEntrega = @CodigoPostalEntrega,

		IdCiudadEntrega = @IdCiudadEntrega,
		IdZonaEntrega = @IdZonaEntrega,
		DomicilioEntrega = @DomicilioEntrega,
		EntregarEn = @EntregarEn,
		DatosAdicionales = @DatosAdicionales,
		IdSucursal = @IdSucursal,
		EntregaEnSucursal = @EntregaEnSucursal,
		IdSucursalEntrega = @IdSucursalEntrega,
		FolioEmbarque = @FolioEmbarque,
		IdCliente = @IdCliente,
		IdZonaRemitente = @IdZonaRemitente,
		IdZonaDestinatario = @IdZonaDestinatario,
		IdRemitente = @IdRemitente,
		IdDestinatario = @IdDestinatario,
		AliasRemitente = @AliasRemitente,
		AliasDestinatario = @AliasDestinatario,
		CalleRemitente = @CalleRemitente, 
		NoIntRemitente = @NoIntRemitente, 
		NoExtRemitente = @NoExtRemitente, 
		ColoniaRemitente = @ColoniaRemitente,
		CalleDestinatario = @CalleDestinatario, 
		NoIntDestinatario= @NoIntDestinatario, 
		NoExtDestinatario= @NoExtDestinatario, 
		ColoniaDestinatario= @ColoniaDestinatario,
		EmbarqueConCita = @RecoleccionConCita,
		FechaCita = @FechaCitaDate,
		HoraCitaMinima = @HoraCitaMinimaTime,
		HoraCitaMaxima = @HoraCitaMaximaTime,
		Latitud =  @Latitud, Longitud = @Longitud,
		IdZonaOperativa = @IdZonaOperativa, 
		IdZonaTarifa = @IdZonaTarifa
		,IdEstadoRemitente=@IdEstadoRemitente ,
		IdEstadoDestinatario=@IdEstadoDestinatario ,
		MunicipioRemitente=@MunicipioRemitente,
		MunicipioDestinatario=@MunicipioDestinatario ,
		IdZonaOperativaRecoleccion=@IdZonaOperativaRecoleccion ,
		IdZonaTarifaRecoleccion=@IdZonaTarifaRecoleccion ,
		IdEstadoEntrega=@IdEstadoEntrega ,
		CodigoMunicipioEntrega =@CodigoMunicipioEntrega , ValorDeclarado = @ValorDeclarado,
        IdTipoSeguro = @IdTipoSeguro,PorcentajeSeguro = @PorcentajeSeguro,AplicaSeguro = @AplicaSeguro
	

		WHERE IdEmbarque = @IdEmbarque; 
		delete ProEmbarqueDetallePQ WHERE IdEmbarque = @IdEmbarque; 
		delete ProEmbarqueComplementosSATPQ WHERE IdEmbarque = @IdEmbarque;
		IF @EntregarMismoDomicilio = 0 and @EntregaEnSucursal = 0 BEGIN
	update CatRemitentesDestinatarios SET Latitud = @Latitud, Longitud = @Longitud Where IdRemitenteDestinatario = @IdDestinatario
	
	END
	  	IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

