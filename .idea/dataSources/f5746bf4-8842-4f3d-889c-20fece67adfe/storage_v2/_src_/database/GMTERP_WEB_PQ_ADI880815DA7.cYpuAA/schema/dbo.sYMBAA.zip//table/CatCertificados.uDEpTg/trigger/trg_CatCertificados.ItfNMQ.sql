CREATE TRIGGER [dbo].[trg_CatCertificados]
   ON  [dbo].[CatCertificados]
   AFTER UPDATE
AS 
BEGIN
	IF UPDATE(NoSerieCertificado) OR UPDATE(CertificadoBase64) OR UPDATE(LlavePrivada) OR UPDATE(LlavePrivadaContrasena) OR UPDATE(VigenteDesde) OR UPDATE(VigenteHasta)
			RAISERROR(N'No se puede modificar la información del certificado y llave privada',
			16,
			1
			)

END
go

