CREATE PROCEDURE [dbo].[usp_ProEmbarqueCancelarPQ]
	@IdEmbarque INT,
	@IdUsuarioCancelacion INT,
	@FechaCancelacion DATETIME,
	@MotivoCancelacion VARCHAR(500)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdEmbarque,0) <= 0 
			RAISERROR(N'Identificador de embarque es un campo requerido', 16, 1)
			IF ISNULL(@MotivoCancelacion, '') = ''
			RAISERROR(N'El motivo de cancelacion es un campo requerido', 16, 1)
			IF ISNULL(@IdEmbarque,0) <= 0 
			RAISERROR(N'El ussuario que cancela es un campo requerido', 16, 1)
			IF ISNULL(@FechaCancelacion, '') = ''
			RAISERROR(N'La fecha y hora de cancelacion es un campo requerido', 16, 1)
		UPDATE ProEmbarquePQ
		SET MotivoCancelacion = @MotivoCancelacion,
		IdEstatusEmbarque = 21,
		UsuarioCancelacion = @IdUsuarioCancelacion,
		FechaCancelacion = @FechaCancelacion
		WHERE IdEmbarque = @IdEmbarque
	COMMIT TRANSACTION
	BEGIN TRANSACTION
		UPDATE ProRecoleccionPQ
		set IdEmbarque = NULL
		WHERE IdEmbarque = @IdEmbarque
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

