CREATE PROCEDURE [dbo].[usp_CatOperadoresEliminar]
	@IdOperador int,
	@IdPeticion varchar(100),
	@EliminarEmpleado bit
AS
DECLARE
@IdEmpleado int --Todas las validaciones que se agregen hay que ponerlas en CatEmpleadosEliminar
SET XACT_ABORT ON
BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM ProViajesTrayectos WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene viajes asignados, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 IdValeCombustible FROM ProValesCombustible WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene vales de combustible asignados, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 IdUnidad FROM CatUnidades WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene unidad asignada, no es posible eliminarlo',
			16,
			1
			)	

	IF EXISTS(SELECT TOP 1 * FROM ProLiquidacionesFiscales WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene liquidaciones fiscales, no es posible eliminarlo',
			16,
			1
			)					
				

	IF EXISTS(SELECT TOP 1 * FROM ProReportesFallas WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene reportes de fallas, no es posible eliminarlo',
			16,
			1
			)
	IF EXISTS(SELECT TOP 1 * FROM ProRecorridos WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene recorridos, no es posible eliminarlo',
			16,
			1
			)
	IF EXISTS(SELECT TOP 1 * FROM ProAnticipos WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene anticipos, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM CatDescuentosOperadores WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene descuentos, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM CatOperadoresInstalacionesAppBitacora WHERE IdOperador = @IdOperador)
		RAISERROR(N'El operador tiene asignado número de teléfono para instalar la app bitácora de conducción, no es posible eliminarlo',
			16,
			1
			)

	--Eliminar Empleado
	IF EXISTS (Select IdOperador from CatEmpleados where IdOperador = @IdOperador) AND @EliminarEmpleado = 1
	BEGIN
		Set @IdEmpleado = (Select IdEmpleado From CatEmpleados Where IdOperador = @IdOperador)
		EXEC usp_CatEmpleadosEliminar @IdEmpleado,@IdPeticion,NULL	 
	END		
								
	DELETE FROM CatOperadores
	WHERE IdOperador = @IdOperador
	
	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

