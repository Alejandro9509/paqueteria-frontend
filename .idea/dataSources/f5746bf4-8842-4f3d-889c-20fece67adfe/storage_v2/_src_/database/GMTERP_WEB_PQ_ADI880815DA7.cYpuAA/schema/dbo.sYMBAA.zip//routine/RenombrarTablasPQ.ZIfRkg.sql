-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[RenombrarTablasPQ] 
AS
BEGIN
DECLARE 
    @table_name VARCHAR(MAX),@stmt VARCHAR(MAX) ;

	DECLARE cursor_name CURSOR
    FOR SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG='GMTPQ_WEB';
	OPEN cursor_name;
	FETCH NEXT FROM cursor_name INTO @table_name;
	WHILE @@FETCH_STATUS = 0  
	BEGIN
	SET @stmt = CONCAT(@table_name, 'PQ')
	exec sp_rename @table_name, @stmt 
        FETCH NEXT FROM cursor_name into @table_name;  
    END;
	CLOSE cursor_name;
	DEALLOCATE cursor_name;
END

go

