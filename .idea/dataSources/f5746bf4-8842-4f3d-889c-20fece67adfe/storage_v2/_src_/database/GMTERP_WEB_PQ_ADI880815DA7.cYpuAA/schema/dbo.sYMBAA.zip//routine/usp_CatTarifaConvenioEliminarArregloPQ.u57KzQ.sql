
CREATE PROCEDURE [dbo].[usp_CatTarifaConvenioEliminarArregloPQ](
	@IdTarifaConvenio INT)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdTarifaConvenio,0) <= 0 begin
			RAISERROR(N'*INICIO*El Identidicador de Tarifa es un campo requerido*FIN*', 16, 1);
			return 
		end;

		DELETE FROM CatTarifaConvenioConceptosPQ
		WHERE IdTarifaConvenio= @IdTarifaConvenio

	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

