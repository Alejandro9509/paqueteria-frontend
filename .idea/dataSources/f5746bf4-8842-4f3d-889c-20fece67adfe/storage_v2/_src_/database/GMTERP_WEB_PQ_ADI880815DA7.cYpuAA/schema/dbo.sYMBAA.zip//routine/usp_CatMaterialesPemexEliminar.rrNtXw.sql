CREATE PROC [dbo].[usp_CatMaterialesPemexEliminar]
    @IdMaterialPemex int,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatMaterialesPemexEliminar

Parámetros:
    @IdMaterialPemex (entrada, entero). Id de material PEMEX.
    @IdPeticion      (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para eliminar un Material PEMEX.

10/02/2020 - Se creó.
18/02/2020 - Se modificó el mensaje de error cuando el material está ligado a una ruta/tarifa.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 10/02/2020
Versión ERP: 8.0.50.06

Invocada desde: PAGE_CatMaterialPemexListado (Solicitud 897)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
    -- Valida que el Id no venga en cero
    IF @IdMaterialPemex = 0
        RAISERROR(N'El id del material pemex es un campo requerido', 16, 1)

	IF EXISTS(SELECT IdMaterialPemex FROM CatRutasTarifasMateriales WHERE IdMaterialPemex = @IdMaterialPemex)
        RAISERROR(N'No es posible eliminar el registro ya que se encuentra ligado a una Ruta/Tarifa', 16, 1)

    -- Elimina el registro que tenga el mismo Id
    DELETE FROM CatMaterialesPemex 
    WHERE IdMaterialPemex = @IdMaterialPemex

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

