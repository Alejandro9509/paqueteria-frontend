CREATE TRIGGER [dbo].[trg_CatDeducciones]
   ON  [dbo].[CatDeducciones]
   AFTER UPDATE
AS 
BEGIN

	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Deduccion <> D.Deduccion OR I.Codigo <> D.Codigo)
			RAISERROR(N'El Campo Deduccion y código no puede ser modificado porque esta definido por sistema',
				16,
				1
				)
	END

	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
	BEGIN
	
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.ModificarEnLiquidacion <> D.ModificarEnLiquidacion )
			RAISERROR(N'El Check Modificar en liquidación no puede ser modificado porque esta definido por sistema',
				16,
				1
				)
	END 

	IF EXISTS(SELECT TOP 1 IdDeduccion FROM ProLiquidacionesDeducciones Where IdDeduccion = (SELECT IdDeduccion FROM deleted))
	OR EXISTS(SELECT TOP 1 IdDeduccion FROM CatDescuentosOperadores Where IdDeduccion = (SELECT IdDeduccion FROM deleted))
	OR EXISTS(SELECT TOP 1 IdDeduccion FROM ProLiquidacionesFiscalesDeducciones Where IdDeduccion = (SELECT IdDeduccion FROM deleted))
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Deduccion <> D.Deduccion OR I.ClaveSAT <> D.ClaveSAT OR I.Codigo <> D.Codigo)
			RAISERROR(N'El Campo deducción no puede ser modificado porque tiene liquidaciones asignadas',
				16,
				1
				)
	END
END
go

