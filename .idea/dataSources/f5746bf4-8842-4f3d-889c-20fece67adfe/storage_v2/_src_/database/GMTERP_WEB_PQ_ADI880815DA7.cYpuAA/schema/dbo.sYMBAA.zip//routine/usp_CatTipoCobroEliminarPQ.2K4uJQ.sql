
CREATE PROCEDURE [dbo].[usp_CatTipoCobroEliminarPQ]
	@IdTipoCobro INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdTipoCobro,0) <= 0  begin
			RAISERROR(N'*INICIO*Identificador del tipo de unidad es un campo requerido*FIN*', 16,  1)
			return
		end
		DELETE FROM CatTipoCobro
		WHERE IdTipoCobro = @IdTipoCobro
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

