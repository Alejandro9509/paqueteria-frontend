CREATE PROCEDURE [dbo].[usp_CatTiposAcumuladosModificar]	  
	@IdTipoAcumulado int,
	@Nombre varchar(40),
	@TipoMovtoAcumulado int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,   
	@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION

	IF ISNULL(@IdTipoAcumulado,0) = 0
		RAISERROR(N'El identificador es un campo requerido',
			16,
			1
			)
        
	IF RTRIM(LTRIM(@Nombre)) = ''
		RAISERROR(N'El Nombre es un campo requerido',
			16,
			1
			)	        
                            
  	IF EXISTS(SELECT Nombre FROM CatTiposAcumulados WHERE Nombre = @Nombre AND IdTipoAcumulado <> @IdTipoAcumulado)
		RAISERROR(N'El Nombre ya existe',
			16,
			1
			)  

 	IF (SELECT ModificadoEl FROM CatTiposAcumulados WHERE IdTipoAcumulado = @IdTipoAcumulado) <> @UltimaModificacion
		RAISERROR(N'Los datos fueron modificados por otro usuario. salga sin grabar sus cambios.',
			16,
			1
			)	
 	     
	UPDATE CatTiposAcumulados SET
		Nombre = @Nombre,
		TipoMovtoAcumulado = @TipoMovtoAcumulado,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdTipoAcumulado = @IdTipoAcumulado     
	     
  
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

