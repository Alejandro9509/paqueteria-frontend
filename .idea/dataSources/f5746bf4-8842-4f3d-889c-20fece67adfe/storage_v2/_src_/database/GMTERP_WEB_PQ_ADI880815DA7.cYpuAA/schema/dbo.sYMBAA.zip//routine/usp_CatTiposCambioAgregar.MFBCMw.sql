
CREATE PROCEDURE [dbo].[usp_CatTiposCambioAgregar]
	@Fecha datetime,
	@TipoCambio money,
	@CreadoEl datetime,
	@CreadoPor int,
	@IdPeticion varchar(100),
	@BanderaPermitirModificar bit
AS
BEGIN TRY	
	BEGIN TRANSACTION
	IF @Fecha = 0
		RAISERROR(N'El campo de fecha es requerido',
			16,
			1
			)
	IF @TipoCambio = 0
		RAISERROR(N'El campo tipo de cambio es requerido',
			16,
			1
			)			
	IF EXISTS(SELECT IdTipoCambio FROM CatTiposCambio WHERE Fecha = @Fecha)
	BEGIN
		IF @BanderaPermitirModificar = 1
		Begin
			UPDATE CatTiposCambio SET TipoCambio = @TipoCambio,ModificadoEl = @CreadoEl,
			ModificadoPor = @CreadoPor WHERE Fecha = @Fecha
		end
	END		
	ELSE
	BEGIN
		INSERT INTO CatTiposCambio(Fecha,TipoCambio,CreadoEl,CreadoPor)
		VALUES(@Fecha,@TipoCambio,@CreadoEl,@CreadoPor)
	END				
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

