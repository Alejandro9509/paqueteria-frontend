CREATE TRIGGER [dbo].[trg_ProViajesConceptosFacturacionFacturados]
	ON [dbo].[ProViajesConceptosFacturacion]
	AFTER UPDATE,INSERT
AS
BEGIN
	DECLARE @PendienteFacturar bit
	DECLARE @FacturadoParcialmente bit
	SET @PendienteFacturar = (SELECT PendienteFacturar FROM ProViajes WHERE IdViaje = (SELECT TOP 1 IdViaje FROM deleted))
	SET @FacturadoParcialmente = (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = (SELECT TOP 1 IdViaje FROM deleted))
	
	IF @PendienteFacturar = 0 OR @FacturadoParcialmente = 1
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViajeConceptoFacturacion = D.IdViajeConceptoFacturacion
        WHERE D.Importe <> I.Importe OR
        D.TrasladaImpuesto <> I.TrasladaImpuesto OR D.RetieneImpuesto <> I.RetieneImpuesto)
        RAISERROR(N'No puede modificarse los conceptos de facturación del viaje porque está facturado',
            16,
            1
            ) 

	END
END
go

