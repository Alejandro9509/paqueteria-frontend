CREATE TRIGGER [dbo].[trg_CatCuentasContables]
   ON  [dbo].[CatCuentasContables]
   AFTER UPDATE
AS 
BEGIN	

		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdCuentaContable = D.IdCuentaContable
		WHERE  (I.Codigo <> D.Codigo 
		OR I.Nombre <> D.Nombre
		OR I.Activa <> D.Activa)
		AND ((I.CatalogoLigado IS NOT NULL OR D.CatalogoLigado IS NOT NULL) 
		AND (NOT I.CatalogoLigado IN ('CatClientes','CatProveedores'))))
		RAISERROR(N'La cuenta contable no se puede modificar porque está ligada a un catálogo del sistema',
				16,
				1
				)

						
		-- valida que la cuenta no tenga hijos
		IF EXISTS(SELECT * FROM INSERTED I
				INNER JOIN DELETED D ON I.IdCuentaContable = D.IdCuentaContable
				WHERE  (D.CuentaMayor <> I.CuentaMayor)) 
 					BEGIN
 					IF EXISTS(SELECT  TOP 1 IdCuentaContable FROM  CatCuentasContables WHERE   (IdCuentaContablePadre = (SELECT top 1 IdCuentaContable FROM DELETED ) ))   
									RAISERROR(N'La cuenta contable no se puede modificar porque ya tiene cuentas ligadas',
											 16,
											 1
											 )

 					END
 			
		-- valida que la cuenta contable (afectable) no tenga póliza
		IF EXISTS(SELECT * FROM INSERTED I
				INNER JOIN DELETED D ON I.IdCuentaContable = D.IdCuentaContable
				WHERE  (D.IdCuentaContablePadre<> I.IdCuentaContablePadre)) 		
 					BEGIN
					IF EXISTS(SELECT TOP 1 ProPolizasCuentasContables.IdCuentaContable FROM  ProPolizasCuentasContables INNER JOIN
										CatCuentasContables ON ProPolizasCuentasContables.IdCuentaContable = CatCuentasContables.IdCuentaContable
										WHERE ProPolizasCuentasContables.IdCuentaContable = (SELECT top 1 IdCuentaContable FROM DELETED))
							RAISERROR(N'La cuenta contable no se puede modificar porque ya tiene pólizas ligadas',
							16,
							1
							)

 					END
END
go

