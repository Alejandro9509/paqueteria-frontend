CREATE PROCEDURE [dbo].[usp_CatEstatusViajeAgregar]
	@Estatus varchar(30),
	@Abreviacion varchar(5),
	@Color varchar(6),
	@ColorLetra int,
	@EnviarPorCorreo bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@NoEnviarPorCorreoSeguimientoViajes bit,
	@InformarEnvioArchivo214 bit,
	@CargaDescarga tinyint,
	@Carga bit, -- Identificador de estatus de carga
	@Descarga bit, -- Identificador de estatus de descarga
	@Activo bit
AS

/*************************************************************************************************************************************
Procedimiento almacenado usp_CatEstatusViajeAgregar

Parámetros: 
	@Estatus varchar(30),
	@Abreviacion varchar(5),
	@Color varchar(6),
	@ColorLetra int,
	@EnviarPorCorreo bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@NoEnviarPorCorreoSeguimientoViajes bit,
	@InformarEnvioArchivo214 bit,
	@CargaDescarga tinyint,
	@Carga bit -- Identificador de estatus de carga
	@Activo bit

Descripción: Agrega identificadoees para estatus de viajes

Fecha de modificación: 10/12/2019
Versión: Versión 8.0.48.22
Solicitud 286

Fecha de modificación: 17/08/2021
Versión: 8.0.64.01
Solicitud 4715

Fecha de modificación: 21/09/2021
Versión: 8.0.65.01
Solicitud 4851
Descripcion: se agrego la columna Activo


Invocada desde: PAGE_CatEstatusViajeAM
    Solicitud 4851
******************************************************************************************************************* */

BEGIN TRY
	BEGIN TRANSACTION
	
	IF LTRIM(RTRIM(@Estatus)) = ''
		RAISERROR(N'El estatus es un campo requerido',
			16,
			1
			)
			
	INSERT INTO CatEstatusViaje(Abreviacion,Color,ColorLetra,CreadoEl,CreadoPor,DefinidoPorSistema,EnviarPorCorreo,Estatus,NoEnviarPorCorreoSeguimientoViajes,InformarEnvioArchivo214,CargaDescarga, Carga, Descarga, Activo)
	VALUES(@Abreviacion,@Color,@ColorLetra,@CreadoEl,@CreadoPor,0,@EnviarPorCorreo,@Estatus,@NoEnviarPorCorreoSeguimientoViajes,@InformarEnvioArchivo214,@CargaDescarga, @Carga, @Descarga, @Activo)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

