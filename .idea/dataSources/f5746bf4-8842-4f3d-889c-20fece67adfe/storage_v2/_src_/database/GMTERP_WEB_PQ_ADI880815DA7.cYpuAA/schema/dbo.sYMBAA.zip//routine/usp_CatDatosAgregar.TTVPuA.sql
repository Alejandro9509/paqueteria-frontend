CREATE PROCEDURE [dbo].[usp_CatDatosAgregar]
	@Nombre varchar(50),
	@ConsultaSQL ntext,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@dsCatDatosParametros ntext
AS
DECLARE 
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

		IF LTRIM(RTRIM(@Nombre)) = ''
			RAISERROR(N'El nombre del dato es un campo requerido',
				16,
				1
				)

		IF EXISTS(SELECT Nombre FROM CatDatos WHERE Nombre = @Nombre)
			RAISERROR(N'El nombre del datos ya esta registrado',
				16,
				1
				)

		IF @ConsultaSQL IS NULL
			RAISERROR(N'La consulta es un campo requerido',
				16,
				1
				)
				
		INSERT INTO CatDatos(ConsultaSQL,CreadoEl,CreadoPor,Nombre)
		VALUES(@ConsultaSQL,@CreadoEl,@CreadoPor,@Nombre)

		--SE AGREGA O ACTUALIZAN LA TABLA DE DATOS PARAMETROS
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatDatosParametros

		SELECT ATT_Parametro,ATT_Descripcion,ATT_TipoParametro,ATT_IdDatoParametro
		INTO #TempCatDatosParametros
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatDatosParametros',2) 
		WITH (ATT_Parametro varchar(15),ATT_Descripcion varchar(20),ATT_TipoParametro tinyint,ATT_IdDatoParametro int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatDatosParametros(Descripcion,Parametro,TipoParametro,CreadoEl,CreadoPor)
		SELECT ATT_Descripcion,ATT_Parametro,ATT_TipoParametro,@CreadoEl,@CreadoPor
		FROM #TempCatDatosParametros
		WHERE ATT_IdDatoParametro = 0
		
		UPDATE CatDatosParametros SET
			CatDatosParametros.Descripcion = #TempCatDatosParametros.ATT_Descripcion,
			CatDatosParametros.Parametro = #TempCatDatosParametros.ATT_Parametro,
			CatDatosParametros.TipoParametro = #TempCatDatosParametros.ATT_TipoParametro,
			CatDatosParametros.ModificadoEl = @CreadoEl, 
			CatDatosParametros.ModificadoPor = @CreadoPor
		FROM CatDatosParametros
		INNER JOIN #TempCatDatosParametros ON CatDatosParametros.IdDatoParametro = #TempCatDatosParametros.ATT_IdDatoParametro

		DELETE FROM CatDatosParametros WHERE (ModificadoEl <> @CreadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @CreadoEl
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

