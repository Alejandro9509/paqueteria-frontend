CREATE PROCEDURE [dbo].[usp_Push]
	--@title varchar(500),
	--@body_content varchar(500),
	--@id int,
	--@to varchar(15),
	--@click_action varchar(50)
AS
BEGIN
	BEGIN TRANSACTION
		--HTTP POST
		DECLARE @URL NVARCHAR(MAX) = 'https://fcm.googleapis.com/fcm/send';
DECLARE @Object AS INT;
DECLARE @ResponseText AS VARCHAR(8000);
DECLARE @Body AS VARCHAR(8000) =
'{
    "to" : "allDevices",
    "notification" : {
    	"title": "🚛 ¡Prepárate!",
    	"body" : "Mañana el camión de recolección estará en tu casa 👍",
    	"priority":"HIGH",
    	"badge" : 1,
    	"id": 9,
        "click_action" : "OPEN_SALES_ACTIVITY"
 },
    "data" : {
    	"ticketNumber" : "202012450",
    	"title" : "IMPORTANTE",
    	"id": 9,
    	"content" : "Esto es un aviso de prueba para revisar los flujos de notificaciones en la aplicación, independientemente de si tiene sesión iniciada o no, al igual que dentro de la app o fuera, gracias por su atencion",
    	"lastEdited" : "202002171542"
    }
 }'
EXEC sp_OACreate 'MSXML2.XMLHTTP', @Object OUT;
EXEC sp_OAMethod @Object, 'open', NULL, 'post',
                 @URL,
                 'false'
EXEC sp_OAMethod @Object, 'setRequestHeader', null, 'Content-Type', 'application/json'
EXEC sp_OAMethod @Object, 'send', null, @body
EXEC sp_OAMethod @Object, 'responseText', @ResponseText OUTPUT
IF CHARINDEX('false',(SELECT @ResponseText)) > 0
BEGIN
 SELECT @ResponseText As 'Message'
 print @ResponseText
END
--ELSE
--BEGIN
-- SELECT @ResponseText As 'Employee Details'
--END
EXEC sp_OADestroy @Object
		--END HTTP POSTR
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END


go

