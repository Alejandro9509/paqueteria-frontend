CREATE PROCEDURE [dbo].[usp_CatDeduccionesAgregar]
	@Codigo int,
	@Deduccion varchar(50),
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
    @ClaveSAT varchar(5),
    @ModificarEnLiquidacion bit,
    @ClaveOtrosPagos varchar(5),
	@Activo tinyint

/*************************************************************************************************************************************
Procedimiento almacenado [usp_CatDeduccionesAgregar]

Parámetros: 
	@Codigo int,
	@Deduccion varchar(50),
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
    @ClaveSAT varchar(5),
    @ModificarEnLiquidacion bit,
    @ClaveOtrosPagos varchar(5),
	@Activo tinyint

Descripción: Agrega conceptos de deducciones  

Modificada por:   Diego Arturo Rubio Meza
Fecha de modificación: 22/10/2019
Versión: V8 8.0.47.06
Descripción: Se agrego el parametro activo a las deducciones 

Invocada desde: ClsCatDeducciones
    Solicitud 330
******************************************************************************************************************************/

AS
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@Codigo,0) <= 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)	

	IF EXISTS(SELECT Codigo FROM CatDeducciones WHERE Codigo = @Codigo)
		RAISERROR(N'El código ya existe',
			16,
			1
			)

	IF LTRIM(RTRIM(@Deduccion)) = ''
		RAISERROR(N'El campo deducción es requerido',
			16,
			1
			)

    IF RTRIM(LTRIM(@ClaveSAT)) = ''
        RAISERROR(N'La clave del SAT es un campo requerido',
            16,
            1
            )
    IF RTRIM(LTRIM(@ClaveOtrosPagos)) = ''
        RAISERROR(N'La clave de otros pagos del SAT es un campo requerido',
            16,
            1
            )        
	INSERT INTO CatDeducciones(Codigo,CreadoEl,CreadoPor,DefinidoPorSistema,Deduccion,ClaveSAT,ModificarEnLiquidacion,ClaveOtrosPagos,Activo)
	VALUES(@Codigo,@CreadoEl,@CreadoPor,0,@Deduccion,@ClaveSAT,@ModificarEnLiquidacion,@ClaveOtrosPagos,@Activo)
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

