

CREATE PROCEDURE [dbo].[usp_UltimaMillaRemplazarPaquetePQ](
	@IdParada int,
	@IdGuia int,
	@EsRecoleccion bit,
	@IdNuevaGuia int,
	@NuevaGuiaEsRecoleccion bit,
	@Lat text,
	@Lng text
	)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@IdParada, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador de la parada es un campo requerido*FIN*', 16, 1)
			return
		end

		IF ISNULL(@IdGuia, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador de la guía es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@IdNuevaGuia, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador de la guía es un campo requerido*FIN*', 16, 1)
			return
		end
		
		
		UPDATE	ProParadaUltimaMillaGuiasPQ set  m_nIdGuia= @IdNuevaGuia, EsRecoleccion = @NuevaGuiaEsRecoleccion where m_nIdGuia = @IdGuia and m_nIdParadaUltimaMilla = @IdParada and EsRecoleccion = @EsRecoleccion
		if @EsRecoleccion = 1 begin
		Update ProRecoleccionPQ set IdEstatusRecoleccion = 1 where IdRecoleccion = @IdGuia
		end
		ELSE begin
		Update ProGuiaPQ set IdEstatusGuia = 11 where IdGuia = @IdGuia
		END

		if @NuevaGuiaEsRecoleccion = 1 begin
		Update ProRecoleccionPQ set Latitud = @Lat, Longitud=@Lng where IdRecoleccion = @IdNuevaGuia
		end
		ELSE begin
		Update ProGuiaPQ set Latitud = @Lat, Longitud=@Lng where IdGuia = @IdNuevaGuia
		END
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

