

CREATE PROCEDURE [dbo].[usp_CatAlmacenesGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatAlmacenes
go

