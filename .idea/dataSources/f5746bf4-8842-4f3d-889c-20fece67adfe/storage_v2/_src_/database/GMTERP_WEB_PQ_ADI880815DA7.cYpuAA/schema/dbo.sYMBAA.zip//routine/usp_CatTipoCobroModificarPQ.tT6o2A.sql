

CREATE PROCEDURE [dbo].[usp_CatTipoCobroModificarPQ](
	@IdTipoCobro int,
	@Codigo int,
	@Descripcion VARCHAR(125),
	@ModificadoEl Datetime,
	@ModificadoPor int)
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdTipoCobro,0) <= 0 begin		
		RAISERROR(N'*INICIO*El Identificador de Tipo de cobro es un campo requerido*FIN*', 16, 1)
		return
	end
		IF ISNULL(@Codigo, '') = '' begin
			RAISERROR(N'*INICIO*El Código es un campo requerido*FIN*', 16, 1)
			return
		end
		
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La Descripción es un campo requerido*FIN*', 16, 1)
			return
		end

		UPDATE CatTipoCobro SET
		Codigo = @Codigo,
		Descripcion = @Descripcion,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
		WHERE IdTipoCobro = @IdTipoCobro
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH

select * from CatTipoCobro
go

