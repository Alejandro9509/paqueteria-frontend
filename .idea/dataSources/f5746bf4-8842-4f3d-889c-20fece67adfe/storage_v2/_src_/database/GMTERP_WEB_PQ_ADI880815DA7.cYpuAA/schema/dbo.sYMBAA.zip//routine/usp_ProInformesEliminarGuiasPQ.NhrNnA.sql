-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_ProInformesEliminarGuiasPQ]
	@IdInforme int
AS
BEGIN
BEGIN TRANSACTION
	Delete from ProInformeGuiaPQ where IdInforme = @IdInforme
	update ProGuiaPQ set IdInforme = 0, IdEstatusGuia = 4 where IdInforme = @IdInforme
	IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END
go

