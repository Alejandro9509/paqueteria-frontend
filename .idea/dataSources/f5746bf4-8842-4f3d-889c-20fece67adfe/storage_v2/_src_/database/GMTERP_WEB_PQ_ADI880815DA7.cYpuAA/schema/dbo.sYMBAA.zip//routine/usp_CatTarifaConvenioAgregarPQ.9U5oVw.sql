
CREATE PROCEDURE [dbo].[usp_CatTarifaConvenioAgregarPQ](
	@IdTarifa int,
	@IdConvenio int
)
AS
BEGIN
	BEGIN TRANSACTION
	IF ISNULL(@IdTarifa, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador de la tarifa es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdConvenio, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador del Convenio es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		INSERT INTO CatTarifaConvenioPQ(IdTarifa, IdConvenio )
		Values (@IdTarifa, @IdConvenio)
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

