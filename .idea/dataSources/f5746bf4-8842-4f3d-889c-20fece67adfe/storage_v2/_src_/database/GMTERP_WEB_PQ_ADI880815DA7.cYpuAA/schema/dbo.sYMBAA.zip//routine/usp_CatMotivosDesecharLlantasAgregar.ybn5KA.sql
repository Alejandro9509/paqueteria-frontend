CREATE PROCEDURE [dbo].[usp_CatMotivosDesecharLlantasAgregar]
@Codigo	int,	
@DescripcionMotivo	varchar(50),	
@Activo bit,    
@CreadoEl    datetime,    
@CreadoPor    int,    
@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION
 
    IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de motivo desechar llanta  es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatMotivosDesecharLlantas WHERE Codigo = @Codigo)
		RAISERROR(N'El código de motivo desechar llanta ya existe',
			16,
			1
			)	
				
	IF ISNULL(@DescripcionMotivo,'')= ''
		RAISERROR(N'El descripción de motivo desechar llanta  es un campo requerido',
			16,
			1
			)
			
	-- agrega un nuevo motivo de desechar llanta		
    INSERT INTO CatMotivosDesecharLlantas (Codigo,DescripcionMotivo,Activo,CreadoEl,CreadoPor)
    VALUES(@Codigo,@DescripcionMotivo,@Activo,@CreadoEl,@CreadoPor)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

