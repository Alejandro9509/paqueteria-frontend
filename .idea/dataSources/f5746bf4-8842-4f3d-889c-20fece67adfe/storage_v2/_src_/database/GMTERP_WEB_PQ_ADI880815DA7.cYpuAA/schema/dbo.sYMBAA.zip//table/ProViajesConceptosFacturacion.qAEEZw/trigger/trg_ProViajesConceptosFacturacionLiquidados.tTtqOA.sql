--SOLICITUD 009915 - JAVIER - GMWEB/TRAFICO/PARAMETROS DE CONFIGURACION

CREATE TRIGGER [dbo].[trg_ProViajesConceptosFacturacionLiquidados]
	ON [dbo].[ProViajesConceptosFacturacion]
	AFTER UPDATE,INSERT
AS
DECLARE
	@TieneLiquidacionCerrada bit,
	@PermitirModificarImportesLiquidacion1 bit,
	@IdViaje int,
	@Bandera bit = 0
BEGIN
	SET @IdViaje = (SELECT TOP 1 IdViaje FROM deleted) --Duda con el IdViaje 
	IF (SELECT TOP 1 pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt INNER JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion 
		WHERE pvt.IdViaje = @IdViaje AND pl.CerradaEl IS NOT NULL AND pl.TipoLiquidacion = 1) <> ''
	BEGIN
		SET @TieneLiquidacionCerrada = 1
	END 
	
	SET @PermitirModificarImportesLiquidacion1 = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'PermitirModificarImporteCartaPorteViajeLiquidacion1')
	IF @TieneLiquidacionCerrada = 1 AND  @PermitirModificarImportesLiquidacion1 = 1 
	BEGIN
		SET @Bandera = 1 	
	END 
	
	IF @Bandera = 0 
	BEGIN 
		IF EXISTS(SELECT pvtc.IdLiquidacion 
		FROM ProViajesTrayectos AS pvtc
		INNER JOIN ProLiquidaciones plc ON pvtc.IdLiquidacion = plc.IdLiquidacion
		WHERE pvtc.IdViaje = (SELECT TOP 1 IdViaje FROM deleted)
		AND plc.CerradaEl IS NOT NULL AND plc.TipoLiquidacion IN(1,6))
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.IdViajeConceptoFacturacion = D.IdViajeConceptoFacturacion
			WHERE D.Importe <> I.Importe 
			OR D.IncluirCalculoIngresosLiquidacion <> I.IncluirCalculoIngresosLiquidacion 
			OR D.IncluirCalculoLiquidacionPorcentajeSobreImpFlete <> I.IncluirCalculoLiquidacionPorcentajeSobreImpFlete)
			RAISERROR(N'No puede modificarse los importes de los conceptos de facturación del viaje porque la liquidación está cerrada y es del tipo 1)porcentaje sobre importe flete ó 6)sueldo semanal + porcentaje importe flete',
				16,
				1
				)
		END 
	END
END
go

