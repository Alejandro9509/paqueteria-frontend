CREATE PROCEDURE [dbo].[usp_CatCuentasContablesEliminar]
	@IdCuentaContable int,
	@IdPeticion varchar(100)
AS
DECLARE 
@Query nvarchar(max),
@Catalogo nvarchar(max),
@Columna nvarchar(max),
@Equivalencia nvarchar(max),
@Parametros nvarchar(max)
/*
PARÁMETROS:
	@IdPeticion:		Sesion activa
	@IdCuentaContable:	CuentaContable que se va a eliminar.
IMPLEMENTADA POR:
	
FECHA DE IMPLEMENTACIÓN:
	
VERSIÓN:
	
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-17
INVOCADA DESDE:
	ClsCatCuentasContables::Eliminar()
SOLICITUD: 
	SOLCITUD 000266
*/
SET XACT_ABORT ON	
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdCuentaContable = 0
		RAISERROR(N'El identificador de la cuenta contable es un campo requerido',
			16,
			1
			)	

	IF NOT EXISTS(SELECT IdCuentaContable FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContable)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)				

	--IF EXISTS(SELECT * FROM CatCuentasContables WHERE IdCuentaContable = @IdCuentaContable AND CatalogoLigado IS NOT NULL)
	--	RAISERROR(N'La cuenta contable no se puede eliminar porque está ligada a un catálogo del sistema',
	--		16,
	--		1
	--		)
	----Se comenta esta validacion a peticion de la solicitud 005675

	IF EXISTS(SELECT TOP 1 * FROM CatCuentasContables WHERE IdCuentaContablePadre = @IdCuentaContable)
		RAISERROR(N'La cuenta contable no se puede eliminar porque tiene cuentas ligadas',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM ProPolizasCuentasContables WHERE IdCuentaContable = @IdCuentaContable)
		RAISERROR(N'La cuenta contable no se puede eliminar porque tiene pólizas',
			16,
			1
			)
	--Se obtiene el Catalogo ligado y el codigo de la cuenta contablable para poder limpiar las equivalanecias de pesos o dolares solicitud 11470
	SET @Catalogo = (Select CatalogoLigado FROM CatCuentasContables where IdCuentaContable = @IdCuentaContable)	
	SET @Equivalencia = (Select Codigo FROM CatCuentasContables where IdCuentaContable = @IdCuentaContable)			 				
	
	/*Se elimina la cuenta contable de CatCuentasContablesSaldos*/
	DELETE FROM CatCuentasContablesSaldos
	WHERE IdCuentaContable = @IdCuentaContable

	DELETE FROM CatCuentasContables
	WHERE IdCuentaContable = @IdCuentaContable

	--Se agrego condicion para limpiar las equivalencia de pesos o dolares, del catalago ligado solicitud 11470
	IF ISNULL(@Catalogo,'') <> ''
	BEGIN
		--Si el codigo de la cuenta contable se encuentra en la equivalencia 1 se limpia la equivalencia pesos
		SET @Columna = 'EquivalenciaCuentaContable1'
		SET @Query = 'UPDATE '+ @Catalogo + ' SET ' +@Columna +'= NULL'+' WHERE '+ @Columna +' = ''' + @Equivalencia + '''';
		EXEC sp_executesql @Query

		--Si el codigo de la cuenta contable se encuentra en la equivalencia 2 se limpia la equivalencia dolares
		SET @Columna = 'EquivalenciaCuentaContable2'
		SET @Query = 'UPDATE '+ @Catalogo + ' SET ' +@Columna +'= NULL'+' WHERE '+ @Columna +' = ''' + @Equivalencia + '''';
		EXEC sp_executesql @Query
	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

