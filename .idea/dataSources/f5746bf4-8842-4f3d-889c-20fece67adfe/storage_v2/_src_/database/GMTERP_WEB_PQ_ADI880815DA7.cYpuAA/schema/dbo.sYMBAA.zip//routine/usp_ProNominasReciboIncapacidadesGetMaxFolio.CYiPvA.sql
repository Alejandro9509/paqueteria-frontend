CREATE PROCEDURE [dbo].[usp_ProNominasReciboIncapacidadesGetMaxFolio]  
AS  
SELECT top 1 Folio FROM ProNominasReciboIncapacidades ORDER BY IdProNominaReciboIncapacidades desc
go

