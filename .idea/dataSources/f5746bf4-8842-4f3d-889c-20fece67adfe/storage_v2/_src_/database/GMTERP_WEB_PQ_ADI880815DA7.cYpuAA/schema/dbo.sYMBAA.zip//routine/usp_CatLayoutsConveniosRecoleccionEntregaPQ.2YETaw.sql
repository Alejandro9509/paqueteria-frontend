CREATE PROCEDURE [dbo].[usp_CatLayoutsConveniosRecoleccionEntregaPQ]
AS
BEGIN
    BEGIN TRANSACTION
        
        DECLARE @NumeroCliente int;

        DECLARE @Concepto varchar(50);
        DECLARE @PesoMinimo decimal(20,6);
        DECLARE @PesoMaximo decimal(20,6);
        DECLARE @Importe decimal(20,6);
        DECLARE @TipoCalculo varchar(20);
        DECLARE @Producto varchar(150);
        DECLARE @IdCliente int;
        DECLARE @IdTarifa int;
        DECLARE @IdProducto int;
        DECLARE @IdConceptoFacturacion int;
        DECLARE @IdTarifaTipoCalculo int;
        DECLARE @IdZonaConvenio int;
        DECLARE @IdZonaTarifa int;

        DECLARE @IdCatConveniosPQ int;
        DECLARE @IdCatTarifaConvenioPQ int;


        DECLARE @tempCatZonasTarifasConvenioPQ TABLE
                               (  
                                  IdTarifaConvenioZona int,
                                   IdConvenio int,
                                   IdTarifa int
                               );
 


        IF @@TRANCOUNT > 0
            BEGIN

                DECLARE ProdLayoutConvenioCliente CURSOR FOR select distinct NumeroCliente from CarLayoutsConvenioZonaTarifaPQ --where NumeroCliente=783
                        OPEN ProdLayoutConvenioCliente
                            FETCH NEXT FROM ProdLayoutConvenioCliente INTO @NumeroCliente
                            WHILE @@fetch_status = 0
                            BEGIN
                                        
                                
                                Select @IdCliente=IdCliente from CatClientes where NumeroCliente=@NumeroCliente;
                                select @IdCatConveniosPQ=IdConvenio from CatConveniosPQ where IdCliente in (select IdCliente from CatClientes where NumeroCliente=@NumeroCliente);

                    DECLARE ProdLayoutConvenioProducto CURSOR FOR select distinct IdZona from CarLayoutsConvenioZonaTarifaPQ where NumeroCliente=@NumeroCliente
                        OPEN ProdLayoutConvenioProducto
                            FETCH NEXT FROM ProdLayoutConvenioProducto INTO @IdZonaTarifa
                            WHILE @@fetch_status = 0
                            BEGIN                   

                                        set @IdCatTarifaConvenioPQ=0;                                        

                                        select @IdCatTarifaConvenioPQ=isnull(IdTarifaConvenioZona,0) from @tempCatZonasTarifasConvenioPQ where IdConvenio=@IdCatConveniosPQ and IdTarifa=@IdZonaTarifa;

                                        if @IdCatTarifaConvenioPQ=0 
                                            begin
                                                INSERT INTO [dbo].[CatZonasTarifasConvenioPQ]( [IdConvenio], [IdZonaTarifa]) VALUES(@IdCatConveniosPQ, @IdZonaTarifa);

                                                SET @IdCatTarifaConvenioPQ= @@IDENTITY;

                                                INSERT INTO @tempCatZonasTarifasConvenioPQ (IdTarifaConvenioZona,IdConvenio,IdTarifa) VALUES(@IdCatTarifaConvenioPQ,@IdCatConveniosPQ,@IdZonaTarifa);
                                            end        
                                        
                                        DECLARE ProdLayoutConvenio CURSOR FOR select Concepto,PesoMinimo,PesoMaximo,Importe,TipoCalculo,Producto from CarLayoutsConvenioZonaTarifaPQ where NumeroCliente=@NumeroCliente and IdZona=@IdZonaTarifa
                                        OPEN ProdLayoutConvenio
                                            FETCH NEXT FROM ProdLayoutConvenio INTO @Concepto,@PesoMinimo,@PesoMaximo,@Importe,@TipoCalculo,@Producto
                                            WHILE @@fetch_status = 0
                                            BEGIN                                                                                                  
                                                
                                                    set @IdConceptoFacturacion=0;
                                                    set @IdTarifaTipoCalculo=0;    

                                                    select @IdConceptoFacturacion=IdConceptoFacturacion from CatConceptosFacturacion where ConceptoFacturacion=@Concepto and Activo=1;
                                                    select @IdTarifaTipoCalculo=IdTarifaTipoCalculo from CatTarifaTipoCalculoPQ where TarifaTipoCalculo=@TipoCalculo;
                                                    


                                                    if  @IdCatTarifaConvenioPQ > 0 
                                                        begin
                                                            if @Concepto = 'MANIOBRAS DE ENTREGA'
                                                                       begin
                                   
                                                                            INSERT INTO [dbo].[CatZonasTarifasConvenioConceptosPQ]([IdZonaConvenio], [IdConceptoFacturacion], [Importe], 
                                                                            [IdImpuestoTraslada], [ImporteIva], [IdImpuestoRetiene], [ImporteRetiene], 
                                                                            [IdTipoCalculo], [RangoMinimo], [RangoMaximo], [IdAgregadoDesde], [IdTipoMedida]) 
                                                                                VALUES(@IdCatTarifaConvenioPQ, @IdConceptoFacturacion, @Importe, 3, (@Importe * 0.16), 5, (@Importe * 0.04), @IdTarifaTipoCalculo, @PesoMinimo, @PesoMaximo, 2, 2);
                                                                       end 
                                                             else
                                                                 begin
                                   
                                                                            INSERT INTO [dbo].[CatZonasTarifasConvenioConceptosPQ]([IdZonaConvenio], [IdConceptoFacturacion], [Importe], 
                                                                            [IdImpuestoTraslada], [ImporteIva], [IdImpuestoRetiene], [ImporteRetiene], 
                                                                            [IdTipoCalculo], [RangoMinimo], [RangoMaximo], [IdAgregadoDesde], [IdTipoMedida]) 
                                                                                VALUES(@IdCatTarifaConvenioPQ, @IdConceptoFacturacion, @Importe, 3, (@Importe * 0.16), 5, (@Importe * 0.04), @IdTarifaTipoCalculo, @PesoMinimo, @PesoMaximo, 3, 2);
                                                                    end 

                                                          
                                                        end


                                                FETCH NEXT FROM ProdLayoutConvenio INTO @Concepto,@PesoMinimo,@PesoMaximo,@Importe,@TipoCalculo,@Producto
                                            END
                                        CLOSE ProdLayoutConvenio
                                        DEALLOCATE ProdLayoutConvenio

                                    FETCH NEXT FROM ProdLayoutConvenioProducto INTO @IdZonaTarifa
                                   END
                                 CLOSE ProdLayoutConvenioProducto
                              DEALLOCATE ProdLayoutConvenioProducto                                        



                   FETCH NEXT FROM ProdLayoutConvenioCliente INTO @NumeroCliente
                   END
                CLOSE ProdLayoutConvenioCliente
                DEALLOCATE ProdLayoutConvenioCliente


                COMMIT TRANSACTION
                END
        ELSE
        BEGIN            
            GOTO CANCELAR_TRANSACCION
        

            CANCELAR_TRANSACCION:
            IF @@TRANCOUNT > 0
            BEGIN
            EXECUTE usp_GetErrorInfo;
                    ROLLBACK TRANSACTION
                    RETURN -1
            END
        END
end
go

