CREATE PROCEDURE [dbo].[usp_CatTarifasFletesCombustibleEliminar]
@IdCombustibleTarifaFlete int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
   BEGIN TRANSACTION
   IF EXISTS(SELECT TOP 1 IdCombustibleTarifaFlete  FROM ProViajes WHERE ProViajes.IdCombustibleTarifaFlete = @IdCombustibleTarifaFlete)
				RAISERROR(N'La tarifa está ligada a otro procedimiento, no es posible eliminarla.',
				16,
				1
				)

		DELETE CatTarifasFletesCombustible 
		WHERE 	IdCombustibleTarifaFlete=@IdCombustibleTarifaFlete
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

