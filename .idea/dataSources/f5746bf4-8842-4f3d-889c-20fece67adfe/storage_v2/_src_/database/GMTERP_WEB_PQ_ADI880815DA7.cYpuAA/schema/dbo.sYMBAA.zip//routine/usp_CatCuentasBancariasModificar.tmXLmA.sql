CREATE PROCEDURE [dbo].[usp_CatCuentasBancariasModificar]
	@IdCuentaBancaria int,
	@NumeroCuenta varchar(50),
	@CuentaBancaria varchar(50),
	@IdMoneda Int,
	@IdSucursal Int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@IdBanco int,
	@Activa bit,
	@Contabilizar bit,
	@CreadoPor int
AS
DECLARE 
	@IdCuentaContable3 int,
	@IdCuentaContable2 int,
	@Codigo varchar(25),--auxiliar para formatear los cuentas contables xxx-xxx-xxxxxx o la que el usuario desee
	@num int,--numero inciial de la cuenta ver archivo de excel con listado detallado
	@CodigoCatalogo1 int,--codigo para generar la cuenta contable
	@Nombre1 varchar(250),--nombre para generar la cuenta contable
	@CodigoCatalogo2 int,--codigo para generar la cuenta contable
	@Nombre2 varchar(250),--nombre para generar la cuenta contable
	@CodigoCatalogoAux int,--auxiliar para los break como por ejemplo de bancos
	@IdCatalogo1 int,--es el id del catalogo origen para dejar la liga con cuentas contables
	@IdCatalogo2 int,--es el id del catalogo origen para dejar la liga con cuentas contables
	@Niveles tinyint,
	@PrimerNivel tinyint,
	@SegundoNivel tinyint,
	@TercerNivel tinyint,
	@CuartoNivel tinyint,
	@IdMonedaPadre int	
BEGIN TRY
	BEGIN TRANSACTION
	
	IF (SELECT ModificadoEl FROM CatCuentasBancarias WHERE IdCuentaBancaria = @IdCuentaBancaria) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)	

	IF LTRIM(RTRIM(@NumeroCuenta)) = ''
		RAISERROR(N'El Número de cuenta es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT NumeroCuenta FROM CatCuentasBancarias WHERE NumeroCuenta = @NumeroCuenta  and IdCuentaBancaria <>@IdCuentaBancaria)
		RAISERROR(N'El número de Cuenta ya existe, verifique ',
			16,
			1
			)		
			
	IF LTRIM(RTRIM(@CuentaBancaria)) = ''
		RAISERROR(N'La cuenta bancaria es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@IdBanco,0)=0
		RAISERROR(N'El identificador de banco es un campo requerido',
			16,
			1
			)		

	IF @IdMoneda <=0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)
			
	UPDATE CatCuentasBancarias SET
		NumeroCuenta = @NumeroCuenta,
		CuentaBancaria = @CuentaBancaria,
		IdMoneda = @IdMoneda,
		IdSucursal = @IdSucursal,		
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl,
		IdBanco = @IdBanco,
		Activa = @Activa,
		Contabilizar = @Contabilizar
	WHERE IdCuentaBancaria = @IdCuentaBancaria
	
	--SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
	IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
	BEGIN
		UPDATE CatCuentasContables SET
		Nombre = @CuentaBancaria
		WHERE CatalogoLigado = 'CatCuentasBancarias' AND IdCatalogoLigado = @IdCuentaBancaria
	END
	
	IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> '' AND @Contabilizar = 1 AND Not exists(Select IdCuentaContable from CatCuentasContables WHERE CatalogoLigado = 'CatCuentasBancarias' AND IdCatalogoLigado = @IdCuentaBancaria)
	BEGIN

		SET @IdCuentaBancaria = (SELECT IDENT_CURRENT('CatCuentasBancarias'))
		SET @Niveles =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'NivelesEstructuraCatalogoCuentas')
		SET @PrimerNivel =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'PrimerNivelEstructuraCatalogoCuentas')
		SET @SegundoNivel=(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'SegundoNivelEstructuraCatalogoCuentas')
		SET @TercerNivel =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'TercerNivelEstructuraCatalogoCuentas')
		SET @CuartoNivel =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'CuartoNivelEstructuraCatalogoCuentas')
		
		IF NOT EXISTS(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'CargarCatalogoDeCuentasContablesDefinidoPorSAT')
		BEGIN

			DECLARE CatBancosCuentasBancariasCursor CURSOR FOR
			SELECT cb.Codigo,cb.Banco,ccb.IdCuentaBancaria,ccb.CuentaBancaria,cb.IdBanco,ccb.IdCuentaBancaria
			FROM CatBancos AS cb 
			INNER JOIN CatCuentasBancarias AS ccb ON cb.IdBanco = ccb.IdBanco
			WHERE ccb.IdCuentaBancaria = @IdCuentaBancaria
	
			OPEN CatBancosCuentasBancariasCursor 
			FETCH NEXT FROM CatBancosCuentasBancariasCursor 
			INTO @CodigoCatalogo1,@Nombre1,@CodigoCatalogo2,@Nombre2,@IdCatalogo1,@IdCatalogo2
		
			SET @CodigoCatalogoAux = 0

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @CodigoCatalogoAux <> @CodigoCatalogo1
				BEGIN
					SET @CodigoCatalogoAux = @CodigoCatalogo1
						SET @num = 102
					IF @Niveles = 3
					BEGIN
						SET @Codigo = 
						SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
						+'-'+
						SUBSTRING(replicate('0',@SegundoNivel),1,@SegundoNivel-len(CAST(@CodigoCatalogo1 as varchar)))+SUBSTRING(CAST(@CodigoCatalogo1 as varchar),1,len(CAST(@CodigoCatalogo1 as varchar)))
						+'-'+
						replicate('0',@TercerNivel)				
					END
					ELSE
					BEGIN
						SET @Codigo = 
						SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
						+'-'+
						replicate('0',@SegundoNivel)
						+'-'+
						SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@CodigoCatalogo1 as varchar)))+SUBSTRING(CAST(@CodigoCatalogo1 as varchar),1,len(CAST(@CodigoCatalogo1 as varchar)))
						+'-'+
						replicate('0',@CuartoNivel)
					END
						
					IF NOT EXISTS(SELECT * FROM CatCuentasContables WHERE CatalogoLigado = 'CatBancos' AND IdCatalogoLigado = @IdCatalogo1)
					BEGIN
						SET @IdCuentaContable2 = (SELECT TOP 1 IdCuentaContablePadre FROM CatCuentasContables WHERE CatalogoLigado = 'CatBancos' AND IdCatalogoLigado IS NOT NULL)
						--------------Heredar La Moneda de La cuenta Padre---------------------
						Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable2)
						--------------------------------------------------------------------------  
						INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
						VALUES(1,@Codigo,GETDATE(),@CreadoPor,1,@IdCuentaContable2,@Nombre1,1,'CatBancos',@IdCatalogo1,@IdMonedaPadre)		
	
						SET @IdCuentaContable3 = (SELECT IDENT_CURRENT('CatCuentasContables'))				
						
						UPDATE CatBancos SET EquivalenciaCuentaContable1 = @Codigo WHERE IdBanco = @IdCatalogo1
					END
					ELSE
					BEGIN
						SET @IdCuentaContable3 = (SELECT IdCuentaContable FROM CatCuentasContables WHERE CatalogoLigado = 'CatBancos' AND IdCatalogoLigado = @IdCatalogo1)
					END
				END
				
				SET @num = 102
				IF @Niveles = 3
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
					+'-'+
					SUBSTRING(replicate('0',@SegundoNivel),1,@SegundoNivel-len(CAST(@CodigoCatalogo1 as varchar)))+SUBSTRING(CAST(@CodigoCatalogo1 as varchar),1,len(CAST(@CodigoCatalogo1 as varchar)))
					+'-'+
					SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@CodigoCatalogo2 as varchar)))+SUBSTRING(CAST(@CodigoCatalogo2 as varchar),1,len(CAST(@CodigoCatalogo2 as varchar)))
				END
				ELSE
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
					+'-'+
					replicate('0',@SegundoNivel)
					+'-'+
					SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@CodigoCatalogo1 as varchar)))+SUBSTRING(CAST(@CodigoCatalogo1 as varchar),1,len(CAST(@CodigoCatalogo1 as varchar)))
					+'-'+
					SUBSTRING(replicate('0',@CuartoNivel),1,@CuartoNivel-len(CAST(@CodigoCatalogo2 as varchar)))+SUBSTRING(CAST(@CodigoCatalogo2 as varchar),1,len(CAST(@CodigoCatalogo2 as varchar)))
				END			
				--------------Heredar La Moneda de La cuenta Padre---------------------
			    Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable3)
				--------------------------------------------------------------------------  
				INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
				VALUES(1,@Codigo,GETDATE(),@CreadoPor,2,@IdCuentaContable3,@Nombre2,1,'CatCuentasBancarias',@IdCatalogo2,@IdMonedaPadre)
	
				UPDATE CatCuentasBancarias SET EquivalenciaCuentaContable1 = @Codigo WHERE IdCuentaBancaria = @IdCatalogo2
	
				FETCH NEXT FROM CatBancosCuentasBancariasCursor 
				INTO @CodigoCatalogo1,@Nombre1,@CodigoCatalogo2,@Nombre2,@IdCatalogo1,@IdCatalogo2
			END

			CLOSE CatBancosCuentasBancariasCursor
			DEALLOCATE CatBancosCuentasBancariasCursor		
		END
		ELSE
		BEGIN
			IF (Select isnull(Valor,0) From SisParametrosValores where Parametro = 'ParametrosContabilidadBancosCBOX')<> 0
			BEGIN

				SET @Codigo = (Select TOP 1 Valor from SisParametrosValores where Parametro = 'ParametrosContabilidadBancos')
				SET @IdCuentaContable2 = (Select TOP 1 IdCuentaContable From CatCuentasContables where Codigo = @Codigo)
	
	
				IF @Niveles = 3
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+1)
					+'-'+
					SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@IdCuentaBancaria as varchar)))+SUBSTRING(CAST(@IdCuentaBancaria as varchar),1,len(CAST(@IdCuentaBancaria as varchar)))
				END
				ELSE
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+@TercerNivel+2)
					+'-'+
					SUBSTRING(replicate('0',@CuartoNivel),1,@CuartoNivel-len(CAST(@IdCuentaBancaria as varchar)))+SUBSTRING(CAST(@IdCuentaBancaria as varchar),1,len(CAST(@IdCuentaBancaria as varchar)))
				END	
				--------------Heredar La Moneda de La cuenta Padre---------------------
				Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable2)
				--------------------------------------------------------------------------  
				
				INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
				VALUES(1,@Codigo,GETDATE(),@CreadoPor,2,@IdCuentaContable2,@CuentaBancaria,1,'CatCuentasBancarias',@IdCuentaBancaria,1)		
	
				UPDATE CatCuentasBancarias SET EquivalenciaCuentaContable1 = @Codigo WHERE IdCuentaBancaria = @IdCuentaBancaria
		
			END
			--------CATALOGO CUENTAS BANCARIAS DOLARES
			IF (Select isnull(Valor,0) From SisParametrosValores where Parametro = 'ParametrosContabilidadBancosDolaresCBOX')<> 0
			BEGIN

				SET @Codigo = (Select TOP 1 Valor from SisParametrosValores where Parametro = 'ParametrosContabilidadBancosDolares')
				SET @IdCuentaContable2 = (Select TOP 1 IdCuentaContable From CatCuentasContables where Codigo = @Codigo)
	
				IF @Niveles = 3
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+1)
					+'-'+
					SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@IdCuentaBancaria as varchar)))+SUBSTRING(CAST(@IdCuentaBancaria as varchar),1,len(CAST(@IdCuentaBancaria as varchar)))
				END
				ELSE
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+@TercerNivel+2)
					+'-'+
					SUBSTRING(replicate('0',@CuartoNivel),1,@CuartoNivel-len(CAST(@IdCuentaBancaria as varchar)))+SUBSTRING(CAST(@IdCuentaBancaria as varchar),1,len(CAST(@IdCuentaBancaria as varchar)))
				END	
				
				--------------Heredar La Moneda de La cuenta Padre---------------------
				Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable2)
				-----------------------------------------------------------------------  
					
				INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
				VALUES(1,@Codigo,GETDATE(),@CreadoPor,2,@IdCuentaContable2,@CuentaBancaria,1,'CatCuentasBancarias',@IdCuentaBancaria,2)		
	
				UPDATE CatCuentasBancarias SET EquivalenciaCuentaContable2 = @Codigo WHERE IdCuentaBancaria = @IdCuentaBancaria
			END		
		END				
	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

