
CREATE PROCEDURE [dbo].[usp_CatSupervisoresRutasPersonalAgregar]
	@Codigo int,
	@Nombre varchar(100),
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF LTRIM(RTRIM(@Codigo)) = ''
		RAISERROR(N'El Codigo es un campo requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El Nombre es un campo requerido',
			16,
			1
			)
	
	IF EXISTS(SELECT Codigo FROM CatSupervisoresRutasPersonal WHERE Codigo = @Codigo)
		RAISERROR(N'El Codigo ya existe',
			16,
			1
			)
			
	INSERT INTO CatSupervisoresRutasPersonal(Codigo,Nombre,CreadoEl,CreadoPor)
	VALUES(@Codigo,@Nombre,@CreadoEl,@CreadoPor)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

