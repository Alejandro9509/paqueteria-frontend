CREATE PROCEDURE [dbo].[usp_ProEmbarqueGetListadoFiltroPQ]
	@IdSucursal INT,
	@IdEstatus INT,
	@FechaInicial DATE,
	@FechaFinal DATE,
	@FolioEmbarque VARCHAR(100),
	@IdOrigen int,
	@IdDestino int
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT
    FORMAT(FechaRegistro, 'dd-MM-yyyy') + ' ' +  convert(char(5),convert(time(0),HoraRegistro)) as m_sFechaHora
	,IdEstatusEmbarque as m_nIdEstatusEmbarque
	,(select Estatus from CatEstatusEmbarquePQ ee where ee.IdEstatusEmbarque = pp.IdEstatusEmbarque) as m_sEstatusEmbarque
	,(select Color from CatEstatusEmbarquePQ ee where ee.IdEstatusEmbarque = pp.IdEstatusEmbarque) as m_sColorEstatus
	,IdCiudadOrigen as m_nIdCiudadOrigen
    ,(select OrigenDestino from CatOrigenesDestinos cd where cd.IdOrigenDestino = pp.IdCiudadOrigen) as m_sCiudadOrigen
	,IdCiudadDestino as m_nIdCiudadDestino
    ,(select OrigenDestino from CatOrigenesDestinos cd where cd.IdOrigenDestino = pp.IdCiudadDestino) as m_sCiudadDestino
	,IdEmbarque as m_nIdEmbarque
	,FolioEmbarque as m_nFolioEmbarque
	,IdCliente as m_nIdCliente
	,(select cc.NombreFiscal from CatClientes cc WHERE pp.IdCliente =cc.IdCliente ) as m_sNombreCliente
    ,IdSucursal as IdSucursal
	,(select Sucursal from CatSucursales su where su.IdSucursal = pp.IdSucursal) as m_sSucursal
    ,(select max(FolioGuia) from dbo.ProGuiaPQ pg where pg.IdEmbarque = pp.IdEmbarque) as m_sFolioGuia
	,IdRecoleccion as m_nIdRecoleccion
    ,(case when IdRecoleccion = 0 then CAST(0 AS BIT) else CAST(1 AS BIT) end) as m_bEsRecolecta
	,(select max(FolioRecoleccion) from ProRecoleccionPQ pg where pg.IdRecoleccion = pp.IdRecoleccion) as m_sFolioRecoleccion
	,FechaCancelacion as m_dtFechaCancelacion
	,UsuarioCancelacion as m_sUsuarioCancelacion
	FROM ProEmbarquePQ pp
		WHERE (IdSucursal = @IdSucursal OR @IdSucursal IS NULL)
		AND (IdEstatusEmbarque = @IdEstatus OR @IdEstatus IS NULL)
		AND ((FechaRegistro >= @FechaInicial OR @FechaInicial IS NULL)
		AND (FechaRegistro <= @FechaFinal OR @FechaFinal IS NULL))
		AND (IdCiudadOrigen = @IdOrigen OR @IdOrigen IS NULL)
		AND (IdCiudadDestino = @IdDestino OR @IdDestino IS NULL)
		OR (FolioEmbarque LIKE '%'+@FolioEmbarque+'%' OR @FolioEmbarque IS NULL)
		ORDER BY FechaRegistro DESC, HoraRegistro DESC
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

