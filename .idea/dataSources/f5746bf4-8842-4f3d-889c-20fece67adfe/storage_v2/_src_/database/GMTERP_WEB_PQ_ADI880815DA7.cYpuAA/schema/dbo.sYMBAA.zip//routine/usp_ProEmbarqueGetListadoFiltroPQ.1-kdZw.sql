CREATE PROCEDURE [dbo].[usp_ProEmbarqueGetListadoFiltroPQ]
	@IdSucursal INT,
	@IdEstatus INT,
	@FechaInicial DATE,
	@FechaFinal DATE,
	@FolioEmbarque VARCHAR(100),
	@IdOrigen int,
	@IdDestino int
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT
    FORMAT(FechaRegistro, 'dd-MM-yyyy') + ' ' +  convert(char(5),convert(time(0),HoraRegistro)) as m_sFechaHora
	,pp.IdEstatusEmbarque as m_nIdEstatusEmbarque
	,CEEP.Estatus as m_sEstatusEmbarque
	,CEEP.Color as m_sColorEstatus
	,pp.IdCiudadOrigen as m_nIdCiudadOrigen
    ,(select OrigenDestino from CatOrigenesDestinos cd where cd.IdOrigenDestino = pp.IdCiudadOrigen) as m_sCiudadOrigen
	,pp.IdCiudadDestino as m_nIdCiudadDestino
    ,(select OrigenDestino from CatOrigenesDestinos cd where cd.IdOrigenDestino = pp.IdCiudadDestino) as m_sCiudadDestino
	,pp.IdEmbarque as m_nIdEmbarque
	,pp.FolioEmbarque as m_nFolioEmbarque
	,pp.IdCliente as m_nIdCliente
	, C.NombreFiscal as m_sNombreCliente
    ,pp.IdSucursal as IdSucursal
	,CS.Sucursal as m_sSucursal
    ,PGP.FolioGuia as m_sFolioGuia
	,pp.IdRecoleccion as m_nIdRecoleccion
    ,(case when IdRecoleccion = 0 then CAST(0 AS BIT) else CAST(1 AS BIT) end) as m_bEsRecolecta
	,(select max(FolioRecoleccion) from ProRecoleccionPQ pg where pg.IdRecoleccion = pp.IdRecoleccion) as m_sFolioRecoleccion
	,pp.FechaCancelacion as m_dtFechaCancelacion
	,pp.UsuarioCancelacion as m_sUsuarioCancelacion
	FROM ProEmbarquePQ pp
		inner join CatClientes C on pp.IdCliente = C.IdCliente
		left join ProGuiaPQ PGP on pp.IdEmbarque = PGP.IdEmbarque
		inner join CatSucursales CS on C.IdSucursal = CS.IdSucursal
		inner join CatEstatusEmbarquePQ CEEP on pp.IdEstatusEmbarque = CEEP.IdEstatusEmbarque
		WHERE (pp.IdSucursal = @IdSucursal OR @IdSucursal IS NULL)
		AND (pp.IdEstatusEmbarque = @IdEstatus OR @IdEstatus IS NULL)
		AND ((pp.FechaRegistro >= @FechaInicial OR @FechaInicial IS NULL)
		AND (pp.FechaRegistro <= @FechaFinal OR @FechaFinal IS NULL))
		AND (pp.IdCiudadOrigen = @IdOrigen OR @IdOrigen IS NULL)
		AND (pp.IdCiudadDestino = @IdDestino OR @IdDestino IS NULL)
		OR (pp.FolioEmbarque LIKE '%'+@FolioEmbarque+'%' OR @FolioEmbarque IS NULL)
		ORDER BY pp.FechaRegistro DESC, pp.HoraRegistro DESC
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

