
CREATE TRIGGER [dbo].[trg_CatCuentasBancariasIdMoneda]
   ON  [dbo].[CatCuentasBancarias]
   AFTER UPDATE
AS 
BEGIN	
	IF EXISTS(SELECT TOP 1 IdMovimientoBancario FROM ProMovimientosBancarios Where IdCuentaBancaria = (SELECT IdCuentaBancaria FROM deleted))
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.IdMoneda <> D.IdMoneda)	
			RAISERROR(N'El Campo Moneda no puede ser modificado porque tiene movimientos bancarios registrados',
				16,
				1
				)
	END
END
go

