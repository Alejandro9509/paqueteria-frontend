
CREATE PROCEDURE [dbo].[usp_ProLiquidacionesFiscalesGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProLiquidacionesFiscales
go

