CREATE PROCEDURE [dbo].[usp_ProFacturasModificarFechaObservacion]
	@IdFactura int,
	@FechaHora datetime,
	@Observaciones varchar(3000),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@TipoCambio MONEY,
	@FechaProPago DATE,
	@dsProFacturasCamposAdicionales ntext = NULL,
	@IdAddenda int,
	@Campo1 varchar(250),
	@Campo2 varchar(250),
	@Campo3 varchar(250),
	@Campo4 varchar(250),
	@Campo5 varchar(250),
	@Campo6 varchar(250),
	@Campo7 varchar(250),
	@Campo8 varchar(250),
	@Campo9 varchar(250),
	@Campo10 varchar(250),
	@ConceptosFacturaionDistribucion ntext = NULL
AS
/*************************************************************************************************************************************
	@IdFactura int
	@FechaHora datetime
	@Observaciones varchar(3000)
	@ModificadoPor int
	@ModificadoEl datetime
	@UltimaModificacion datetime
	@IdPeticion varchar(100)
	@TipoCambio MONEY
	@FechaProPago DATE
	@dsProFacturasCamposAdicionales ntext = NULL
	@IdAddenda int
	@Campo1 varchar(250)
	@Campo2 varchar(250)
	@Campo3 varchar(250)
	@Campo4 varchar(250)
	@Campo5 varchar(250)
	@Campo6 varchar(250)
	@Campo7 varchar(250)
	@Campo8 varchar(250)
	@Campo9 varchar(250)
	@Campo10 varchar(250)

	Modificado por:  David Omar cabrera Bernal
	Fecha de Creacion:  24/06/2020
	Versión: 8.0.53.25
	Solicitud 001734
	se agregó campos de addenda en la modificacion de observaciones

	Se creo para guardar las observaciones y campos adicionales de las facturas

	MODIFICADO:
		Se agregaro la bitacora de tipo de cambio ( SisBitacoraTipoCambio )
	MODIFICADA POR:
		Abril CG
	FECHA DE MODIFICACIÓN:
		2021-04-06
	SOLICITUD: 
		SOLICITUD 004067

***************************************/
/*
	SOLICITUD:	004401
				Se agrego la distribucion de concepto por unidad 
	MODIFICADO EL:	2021-07-15
	MODIFICADO POR:	ABRIL CG
*/

	/*Conceptos Facturacion Distribucion*/
	DECLARE @VarConceptosFacturacionDistribucion TABLE  
	(IdFacturaConceptoFacturacionDistribucion int,
	IdFacturaConceptoFacturacion int,
	IdConceptoFacturacion int ,
	IdUnidad int ,
	ImporteDistribuido money )

DECLARE
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION		

	IF @IdFactura = 0
		RAISERROR(N'El identificador de la factura es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaHora) = 0			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT TimbrePruebas FROM ProFacturas WHERE IdFactura = @IdFactura AND TimbrePruebas = 0 AND FolioFiscalUUID <> '') AND (SELECT FechaHora FROM ProFacturas WHERE IdFactura = @IdFactura ) <> @FechaHora -- si es timbre real y tiene uuid
		RAISERROR(N'No puede ser modificada la fecha de la factura porque ya se timbró y esta registrada en el SAT',
			16,
			1
			)	
			
	IF (SELECT ISNULL(Abonos,0) FROM ProFacturas WHERE IdFactura = @IdFactura) <> 0 AND (SELECT  FechaHora FROM ProFacturas WHERE IdFactura = @IdFactura ) <> @FechaHora
		RAISERROR(N'No puede ser modificada la fecha de la  factura porque tiene abonos',
			16,
			1
			)
			
	IF (SELECT ModificadoEl FROM ProFacturas WHERE IdFactura = @IdFactura) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario, favor de salir de modificar y volver a entrar',
			16,
			1
			)
			
	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 2 --cancelada
		RAISERROR(N'No puede ser modificada esta factura porque está cancelada',
			16,
			1
			)
	IF (SELECT FacturaExterna FROM ProFacturas WHERE IdFactura = @IdFactura) = 1 
		RAISERROR(N'No se puede modificar esta factura por que es externa ',
			16,
			1
			)
	UPDATE ProFacturas SET
		FechaHora = @FechaHora,
		Observaciones = @Observaciones,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		FechaProgPago = @FechaProPago,
		TipoCambio = @TipoCambio
	WHERE IdFactura = @IdFactura

	--Se agregó inserccion de addenda
	IF @IdAddenda > 0
	BEGIN
		IF EXISTS( SELECT * FROM  ProFacturasAddendasCamposAdicionales WHERE IdFactura = @IdFactura ) 
		BEGIN
			UPDATE ProFacturasAddendasCamposAdicionales SET
				Campo1 = @Campo1,
				Campo2 = @Campo2,
				Campo3 = @Campo3,
				Campo4 = @Campo4,
				Campo5 = @Campo5,
				Campo6 = @Campo6,
				Campo7 = @Campo7,
				Campo8 = @Campo8,
				Campo9 = @Campo9,
				Campo10 = @Campo10,
				IdAddenda = @IdAddenda
			WHERE IdFactura = @IdFactura --AND IdAddenda = @IdAddenda
		END
		ELSE
		BEGIN
			INSERT INTO ProFacturasAddendasCamposAdicionales(Campo1,Campo10,Campo2,Campo3,Campo4,Campo5,Campo6,Campo7,Campo8,Campo9,IdAddenda,IdFactura,CreadoEl,CreadoPor)
			VALUES(@Campo1,@Campo10,@Campo2,@Campo3,@Campo4,@Campo5,@Campo6,@Campo7,@Campo8,@Campo9,@IdAddenda,@IdFactura,@ModificadoEl,@ModificadoPor)
		END
	END

	IF @dsProFacturasCamposAdicionales  IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasCamposAdicionales 
		
		SELECT ATT_NombreCampo,ATT_ValorCampo,ATT_IdFacturaCampoAdicional
		INTO #TempProFacturasCamposAdicionales
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasCamposAdicionales',2) 
		WITH ( ATT_NombreCampo Varchar(50), ATT_ValorCampo varchar( 150 ),ATT_IdFacturaCampoAdicional int )
		
		EXEC sp_xml_removedocument @docHandle
		
		UPDATE ProFacturasCamposAdicionales
		SET	ProFacturasCamposAdicionales.IdFactura = @IdFactura,
				ProFacturasCamposAdicionales.NombreCampo = #TempProFacturasCamposAdicionales.ATT_NombreCampo,
				ProFacturasCamposAdicionales.ValorCampo = #TempProFacturasCamposAdicionales.ATT_ValorCampo
		FROM ProFacturasCamposAdicionales INNER JOIN #TempProFacturasCamposAdicionales
		ON   ProFacturasCamposAdicionales.IdFacturaCampoAdicional = #TempProFacturasCamposAdicionales.ATT_IdFacturaCampoAdicional 

		DELETE FROM ProFacturasCamposAdicionales WHERE IdFactura = @IdFactura AND IdFacturaCampoAdicional    NOT IN(SELECT ATT_IdFacturaCampoAdicional FROM #TempProFacturasCamposAdicionales WHERE ATT_IdFacturaCampoAdicional <> 0)
		
		INSERT INTO ProFacturasCamposAdicionales( IdFactura, NombreCampo, ValorCampo )
		SELECT @IdFactura,ATT_NombreCampo,ATT_ValorCampo
		FROM #TempProFacturasCamposAdicionales
		WHERE ATT_IdFacturaCampoAdicional = 0	
	END
	ELSE
	BEGIN
		DELETE FROM ProFacturasCamposAdicionales WHERE IdFactura = @IdFactura
	END

	Declare @IdProceso int = 0, @IdProcesoPadre int = 0 ,@TipoCambioDia  money = 0, @TipoFactura int = 0,@return_value int = 0
	SET @TipoCambioDia = (SELECT TOP 1 TipoCambio FROM CatTiposCambio WHERE Cast(Fecha AS DATE) = cast(@FechaHora AS DATE))
	SET @TipoFactura = (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura)

	IF @TipoCambio <> isnull(@TipoCambioDia,0)
	BEGIN

		SET @IdProcesoPadre = (SELECT
							CASE @TipoFactura
							WHEN 1 THEN '300100'	/*POR CONCEPTO*/
							WHEN 2 THEN '300200'	/*POR VIAJE*/	
							WHEN 3 THEN '300300'	/*POR VIAJE PARCIAL*/
							WHEN 4 THEN '300400'	/*POR PESO DESCARGA*/
							WHEN 5 THEN '300500'	/*POR KILOMETROS*/
							WHEN 6 THEN '300600'	/*POR RECORRIDO*/
							WHEN 7 THEN '300700'	/*GENERAL*/
							WHEN 8 THEN '300800'	/*POR COMBUSTIBLE*/
							--WHEN 9 THEN ''	/*POR ANTICIPO*/
							WHEN 10 THEN '300900'	/*POR RELACION PEMEX*/
							END
							)
		SET @IdProceso = (SELECT
							CASE @TipoFactura
							WHEN 1 THEN '300101'	/*POR CONCEPTO*/
							WHEN 2 THEN '300201'	/*POR VIAJE*/	
							WHEN 3 THEN '300301'	/*POR VIAJE PARCIAL*/
							WHEN 4 THEN '300401'	/*POR PESO DESCARGA*/
							WHEN 5 THEN '300501'	/*POR KILOMETROS*/
							WHEN 6 THEN '300601'	/*POR RECORRIDO*/
							WHEN 7 THEN '300701'	/*GENERAL*/
							WHEN 8 THEN '300801'	/*POR COMBUSTIBLE*/
							--WHEN 9 THEN ''	/*POR ANTICIPO*/
							WHEN 10 THEN '300901'	/*POR RELACION PEMEX*/
							END
							)
		EXEC @return_value = usp_SisBitacoraTipoCambioRegistrar @ModificadoEl,@ModificadoPor, @IdFactura,@IdProceso,@IdProcesoPadre ,@TipoCambioDia ,@TipoCambio ,@IdPeticion 

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al registrar la bitácora de tipo de cambio.',
			16,
			1
			)

	END

	/*SE GENERA EL XML Y VARIABLE TABLA PARA LA DISTRIBUCION DE LOS CONCEPTOS DE FACTURACION*/
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @ConceptosFacturaionDistribucion
	
	SELECT ATT_IdFacturaConceptoFacturacionDistribucion,ATT_IdFacturaConceptoFacturacion,ATT_IdConceptoFacturacion,ATT_IdUnidad,ATT_ImporteDistribuido
	INTO #ConceptosFacturacionDistribucion
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/ConceptoDistribucion',2) 
	WITH (ATT_IdFacturaConceptoFacturacionDistribucion int,ATT_IdFacturaConceptoFacturacion int, ATT_IdConceptoFacturacion int ,ATT_IdUnidad int ,ATT_ImporteDistribuido money)
    
	EXEC sp_xml_removedocument @docHandle

	/*DISTRIBUCION DEL CONCEPTO DE FACTURACION POR UNIDADES*/
	INSERT INTO @VarConceptosFacturacionDistribucion (IdFacturaConceptoFacturacionDistribucion,IdFacturaConceptoFacturacion,IdConceptoFacturacion,IdUnidad ,ImporteDistribuido)
	SELECT
	 Temp.ATT_IdFacturaConceptoFacturacionDistribucion
	,Temp.ATT_IdFacturaConceptoFacturacion
	,Temp.ATT_IdConceptoFacturacion
	,Temp.ATT_IdUnidad 
	,Temp.ATT_ImporteDistribuido
	FROM #ConceptosFacturacionDistribucion AS Temp 

	/*ELIMINA LAS DISTRIBUCION DE UNIDADES QUE NO ESTAN EN LA RELACION  @VarConceptosFacturacionDistribucion*/
	DELETE FROM ProFacturasConceptosFacturacionDistribucion 
	WHERE IdFacturaConceptoFacturacion IN ( SELECT IdFacturaConceptoFacturacion FROM ProFacturasConceptosFacturacion WHERE IdFactura = @IdFactura )
		
	/*SE GUARDA LA DISTRIBUCION DEL CONCEPTO DE FACTURACION*/
	INSERT INTO ProFacturasConceptosFacturacionDistribucion(IdFacturaConceptoFacturacion,IdUnidad,ImporteDistribuido)
	SELECT
	 distribucion.IdFacturaConceptoFacturacion
	,distribucion.IdUnidad 
	,distribucion.ImporteDistribuido
	FROM @VarConceptosFacturacionDistribucion distribucion	

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

