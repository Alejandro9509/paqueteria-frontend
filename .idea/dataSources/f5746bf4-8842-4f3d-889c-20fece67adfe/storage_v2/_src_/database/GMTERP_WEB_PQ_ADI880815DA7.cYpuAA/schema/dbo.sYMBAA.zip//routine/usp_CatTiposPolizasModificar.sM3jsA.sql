
CREATE PROCEDURE [dbo].[usp_CatTiposPolizasModificar]
	@IdTipoPoliza int,
	@Codigo Int,
	@Nombre varchar(50),
	@NumeroInicial int,
	@NumeroFinal int,
	@UsarNumeroPor tinyint,
	@UltimoNumeroUsado int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@AcronimoCoi varchar(2)
AS
DECLARE
	@AnioActual smallint
	
BEGIN TRY
	BEGIN TRANSACTION	

		IF @IdTipoPoliza = 0
			RAISERROR(N'El identificador del tipo de poliza es un campo requerido',
				16,
				1
				)

		IF NOT EXISTS(SELECT IdTipoPoliza FROM CatTiposPolizas WHERE IdTipoPoliza = @IdTipoPoliza)
			RAISERROR(N'Este registro fue eliminado por otro usuario',
				16,
				1
				)				
							
		IF (SELECT ModificadoEl FROM CatTiposPolizas WHERE IdTipoPoliza = @IdTipoPoliza) <> @UltimaModificacion
			RAISERROR(N'Este registro fue modificado por otro usuario',
				16,
				1
				)	

		IF @Codigo <= 0
			RAISERROR(N'El Codigo es un campo requerido',
				16,
				1
				)
				
		IF EXISTS(SELECT IdTipoPoliza FROM CatTiposPolizas WHERE Codigo = @Codigo AND IdTipoPoliza <> @IdTipoPoliza)		
			RAISERROR(N'El código del tipo de póliza no se puede repetir',
				16,
				1
				)

		IF LTRIM(RTRIM(@Nombre)) = ''
			RAISERROR(N'El nombre del tipo de póliza es un campo requerido',
				16,
				1
				)	
				
		UPDATE CatTiposPolizas SET
			Codigo = @Codigo,
			Nombre = @Nombre,
			NumeroInicial = @NumeroInicial,
			NumeroFinal = @NumeroFinal,
			UsarNumeroPor = @UsarNumeroPor,
			UltimoNumeroUsado = @UltimoNumeroUsado,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor,
			AcronimoCoi = @AcronimoCoi
		WHERE IdTipoPoliza = @IdTipoPoliza	
		
		Set @AnioActual = YEAR(Getdate())	
		
		IF exists(Select * from CatTiposPolizasEjercicios Where IdTipoPoliza = @IdTipoPoliza	And Ejercicio = @AnioActual)
		begin
			UPDATE CatTiposPolizasEjercicios SET
				UltimoNumeroUsado = @UltimoNumeroUsado,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdTipoPoliza = @IdTipoPoliza and Ejercicio = @AnioActual						
		end
		else
		begin
			INSERT INTO CatTiposPolizasEjercicios (IdTipoPoliza,
						UltimoNumeroUsado,
						UltimoNumeroUsadoPeriodo1,
						UltimoNumeroUsadoPeriodo2,
						UltimoNumeroUsadoPeriodo3,
						UltimoNumeroUsadoPeriodo4,
						UltimoNumeroUsadoPeriodo5,
						UltimoNumeroUsadoPeriodo6,
						UltimoNumeroUsadoPeriodo7,
						UltimoNumeroUsadoPeriodo8,
						UltimoNumeroUsadoPeriodo9,
						UltimoNumeroUsadoPeriodo10,
						UltimoNumeroUsadoPeriodo11,
						UltimoNumeroUsadoPeriodo12,
						UltimoNumeroUsadoPeriodo13,
						Ejercicio,
						CreadoEl,
						CreadoPor)
			SELECT CP.IdTipoPoliza,
						CP.UltimoNumeroUsado,
						CP.UltimoNumeroUsadoPeriodo1,
						CP.UltimoNumeroUsadoPeriodo2,
						CP.UltimoNumeroUsadoPeriodo3,
						CP.UltimoNumeroUsadoPeriodo4,
						CP.UltimoNumeroUsadoPeriodo5,
						CP.UltimoNumeroUsadoPeriodo6,
						CP.UltimoNumeroUsadoPeriodo7,
						CP.UltimoNumeroUsadoPeriodo8,
						CP.UltimoNumeroUsadoPeriodo9,
						CP.UltimoNumeroUsadoPeriodo10,
						CP.UltimoNumeroUsadoPeriodo11,
						CP.UltimoNumeroUsadoPeriodo12,
						CP.UltimoNumeroUsadoPeriodo13,
						@AnioActual,
						CP.CreadoEl,
						CP.CreadoPor
			FROM CatTiposPolizas AS CP
		end
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

