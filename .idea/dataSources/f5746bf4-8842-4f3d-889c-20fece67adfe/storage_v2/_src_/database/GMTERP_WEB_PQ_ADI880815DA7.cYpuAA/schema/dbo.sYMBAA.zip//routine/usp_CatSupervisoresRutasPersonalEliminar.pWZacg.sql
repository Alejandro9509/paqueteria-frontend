CREATE PROCEDURE [dbo].[usp_CatSupervisoresRutasPersonalEliminar]
@IdSupervisorRutaPersonal int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdSupervisorRutaPersonal,0)= 0
		RAISERROR(N'El identificador del Supervisor es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT TOP 1 * FROM CatRutasPersonal WHERE IdSupervisor = @IdSupervisorRutaPersonal )
		RAISERROR(N'El supervisor esta ligado a una ruta, no es posible eliminarlo',
			16,
			1
			)
			
	IF EXISTS(SELECT TOP 1 * FROM ProRecorridos WHERE IdSupervisorRutaPersonal = @IdSupervisorRutaPersonal )
		RAISERROR(N'El supervisor esta ligado a un recorrido, no es posible eliminarlo',
			16,
			1
			)
				
		DELETE CatSupervisoresRutasPersonal		
		WHERE 	IdSupervisorRutaPersonal = @IdSupervisorRutaPersonal
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

