CREATE  PROCEDURE usp_CatMonedasAbreviacionesEliminar
@IdMonedaAbreviacion int,	
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION	
		IF ISNULL(@IdMonedaAbreviacion,0)= 0
			RAISERROR(N'Identificador de abreviación es un campo requerido',
				16,
				1
				)
		DELETE 	CatMonedasAbreviaciones
		WHERE IdMonedaAbreviacion = @IdMonedaAbreviacion		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

