CREATE PROCEDURE [dbo].[usp_ProViajesEliminar]
	@IdViaje int,
	@IdPeticion varchar(100)
AS
DECLARE
	@IdFolio int,
	@IdSolicitudEDI int,
	@IdViajeCartaPorte int,
	@IdSolicitudViaje INT,
	@ConsecutivoSolicitudViaje INT
/*
MODIFICADO:
    Se agrego validacion para que no permita eliminar cartas porte que tengan cancelaciones ante el sat cuando tenga timbre real.
MODIFICADO POR:
    Edgar Ramos
FECHA DE MODIFICACIÓN:
    2021-07-14
SOLICITUD: 
    SOLICITUD 004576
Invocada desde: <PAGE_ProViajesListado,PAGE_ProViajesListadoOptimizado  / ClsProViajes / Eliminar() >
*/
BEGIN TRY
	BEGIN TRANSACTION 
	
	
	IF ISNULL(@IdViaje,0) <= 0
	 RAISERROR(N'El identificador del viaje es un campo requerido',
	 	16,
	 	1
	 	) 
	 	 
	
	IF EXISTS(SELECT IdViaje FROM ProViajes WHERE IdViaje= @IdViaje AND CanceladoEl IS NULL)
	 RAISERROR(N'No se puede eliminar el Viaje porque no esta cancelado',
	 	16,
	 	1
	 	)
	 	

	IF NOT EXISTS(SELECT IdViaje FROM ProViajes WHERE IdViaje= @IdViaje)
	 RAISERROR(N'El Viaje fue eliminado por otro usuario',
	 	16,
	 	1
	 	)
	 	

	IF EXISTS(SELECT IdViaje FROM ProViajesCartasPorte WHERE IdViaje = @IdViaje AND FolioFiscalUUID IS Not NULL)
	 RAISERROR(N'No se puede eliminar el viaje porque ya se timbró la Carta porte',
	 	16,
	 	1
	 	)

	IF (SELECT COUNT(PVCFFC.FolioFiscalUUID) AS Documentos FROM ProViajesCartasPorteFoliosFiscalesCancelados AS PVCFFC INNER JOIN ProViajesCartasPorte AS PVC ON PVCFFC.IdViajeCartaPorte = PVC.IdViajeCartaPorte WHERE PVC.IdViaje = @IdViaje AND ISNULL(PVC.TimbrePruebas,1) = 0 ) > 0
	RAISERROR(N'La carta porte que intenta eliminar ya a sido timbrada con anterioridad, no es posible eliminarla.',
	 	16,
	 	1
	 	)
	
	SELECT @IdSolicitudViaje = psv.IdSolicitudViaje, @ConsecutivoSolicitudViaje = psv.Consecutivo FROM ProSolicitudesViajes psv INNER JOIN ProViajesSolicitudesViajes pvsv ON psv.IdSolicitudViaje = pvsv.IdSolicitudViaje INNER JOIN ProViajes pv ON pvsv.IdViaje = pv.IdViaje WHERE pv.IdViaje = @IdViaje;

	IF @IdSolicitudViaje > 0
	BEGIN
		DECLARE @Mensaje VARCHAR(200)
		SET @Mensaje = CONCAT('No es posible eliminar el viaje seleccionado debido a que se encuentra ligado a la solicitud de viaje ', RIGHT('000000' + CAST(@ConsecutivoSolicitudViaje AS VARCHAR(6)), 6), '.')
			
		RAISERROR(@Mensaje,
			16,
			1
			)
	END

	SET @IdViajeCartaPorte = (SELECT IdViajeCartaPorte FROM ProViajesCartasPorte WHERE IdViaje = @IdViaje)
	--Eliminamos de ProInventarioUnidadesHistorico
	Delete ProInventarioUnidadesHistorico where IdViaje = @IdViaje

	-- se actualiza a null el idviaje de la tabla ProInventarioUnidades
	UPDATE ProInventarioUnidades SET IdViaje = NULL WHERE IdViaje = @IdViaje
	
	--Eliminamos de ProViajesFacturas
	Delete from ProViajesFacturas Where IdViaje = @IdViaje
	
	--Si es con CartaPorte
	--Se saca el folio de ProViajesCartasPorte
	Set @IdFolio = (Select IdFolio from ProViajesCartasPorte Where IdViaje = @IdViaje)
	--Liberamos el Folio de CatFolios
	Update CatFolios Set Estatus = 1 where IdFolio = @IdFolio
	--Eliminamos la referencia de las cancelaciones ante el sat
	Delete from ProViajesCartasPorteFoliosFiscalesCancelados where IdViajeCartaPorte = @IdViajeCartaPorte
	--Eliminamos ProViajesCartasPorte
	Delete from ProViajesCartasPorte where IdViaje = @IdViaje

	-- si viene de una solicitudEDI, se elimina la relacion y se deja la solicitud como Pendiente
	SET @IdSolicitudEDI = (Select Isnull(IdSolicitudEDI,0) from ProSolicitudesEDIViaje Where IdViaje = @IdViaje)
	IF @IdSolicitudEDI <> 0
	BEGIN
	 Delete from ProSolicitudesEDIViaje Where IdSolicitudEDI = @IdSolicitudEDI
	 Update ProSolicitudesEDI SET AceptadoPor=NULL,AceptadoEl=NULL Where IdSolicitudEDI = @IdSolicitudEDI
	END

	--Eliminamos de ProViajes
	Delete From ProViajes where IdViaje = @IdViaje

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

