CREATE PROCEDURE [dbo].[usp_ProModificacionVariablesPercVariablesByEmpleadoPeriodo]
	@FechaInicio DATE,
	@FechaFinal DATE,
	@IdEmpleado INT,
	@IdTipoPeriodo INT

/* *************************************************************************************************
Procedimiento usp_ProModificacionVariables

Parámetros: 
    @IdEmpleado			            (entrada, entero)  Identificador del empleado
    @FechaInicio					(entrada, date)	   Identificador de la fecha de inicio del periodo de busqueda
    @FechaFinal						(entrada, date)    Identificador de la fecha final del periodo de busqueda
	@IdTipoPeriodo					(entrada,date)	   Identificador del tipo del periodo del recibo de nomina
    
    

Descripción: El procedimiento regresa la coleccion de importes del empleado en los periodos del bimestre concerniente al IMSS PERCEPCION VARIABLE

30/09/2019:  Se realizo optimizacion del query para poder obtener toda la informacion en una sola consulta	 

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 30/09/2019
Versión ERP: Versión 8.0.46.30

Modificada por: Raymundo Espinoza Garcia
Fecha de mofidicacion: 25/11/2019
Versión ERP: 

Invocada desde: PAGE_ProModificacionVariables (Solicitud 165)
Invocada desde: PAGE_ProModificacionVariables (Solicitud 703)
***************************************************************************************************** */
AS

DECLARE @cols AS NVARCHAR(MAX),
        @query  AS NVARCHAR(MAX)

BEGIN
set @query = 'SELECT pnr.IdEmpleado,CONVERT(DATE,cp.FechaInicio) AS FechaInicio, ISNULL(SUM(Importe),0) as ImporteTotal 
    FROM ProNominasRecibosTiposAcumulados as pnrta
	Inner join ProNominasRecibo AS pnr ON pnr.IdNominaRecibo = pnrta.IdNominaRecibo
	Inner join CatTiposAcumulados AS cta ON cta.IdTipoAcumulado = pnrta.IdTipoAcumulado
	Inner join CatPeriodos AS cp ON cp.IdPeriodo = pnr.IdPeriodo
	WHERE cp.FechaInicio>='''+CONVERT(VARCHAR, @FechaInicio) + '''
	AND  cp.FechaInicio<='''+CONVERT(VARCHAR, @FechaFinal) + '''
	AND pnr.IdTipoPeriodo= '+  CONVERT(varchar,@IdTipoPeriodo) + '
	AND cta.Nombre= ''IMSS PERCEPCION VARIABLE''	
	GROUP BY pnr.IdEmpleado,cp.FechaInicio
	ORDER BY pnr.IdEmpleado,cp.FechaInicio
	'
EXECUTE (@query)
END
go

