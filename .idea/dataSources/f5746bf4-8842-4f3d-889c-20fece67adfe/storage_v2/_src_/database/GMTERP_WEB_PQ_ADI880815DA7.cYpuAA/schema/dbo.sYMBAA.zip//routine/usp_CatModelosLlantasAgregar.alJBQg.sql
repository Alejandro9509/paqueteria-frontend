

CREATE PROCEDURE [dbo].[usp_CatModelosLlantasAgregar]
@Codigo	int,	
@Descripcion	varchar(50),    
@CreadoEl    datetime,    
@CreadoPor    int,    
@Activo bit,
@ProfundidadOriginal decimal(10,2),
@ProfundidadMinima decimal(10,2),
@PresionMaxima decimal(10,2),
@PresionMimina decimal(10,2),
@IdMarca int,
@IdMedida int,
@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION
 
   	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del modelo es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatModelosLlantas WHERE Codigo = @Codigo )
		RAISERROR(N'El código del modelo ya existe',
			16,
			1
			)	
				
	IF ISNULL(@Descripcion,'')= ''
		RAISERROR(N'El descripción del modelo es un campo requerido',
			16,
			1
			)
	IF ISNULL(@IdMarca,0)= 0
		RAISERROR(N'La Marca es un campo requerido',
			16,
			1
			)
	IF ISNULL(@IdMedida,0)= 0
		RAISERROR(N'La Medida es un campo requerido',
			16,
			1
			)
			
    INSERT INTO CatModelosLlantas (Codigo,Descripcion,Activo,ProfundidadOriginal,ProfundidadMinima,PresionMaxima,PresionMimina,IdMarcaLlanta,IdMedidaLlanta,CreadoEl,CreadoPor)
    VALUES(@Codigo,@Descripcion,@Activo,@ProfundidadOriginal,@ProfundidadMinima,@PresionMaxima,@PresionMimina,@IdMarca,@IdMedida,@CreadoEl,@CreadoPor)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

