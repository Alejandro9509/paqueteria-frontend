
	CREATE PROCEDURE [dbo].[usp_CatTarifaServicioModificarPQ](
	@IdTarifa int,
	@IdTipoServicio int,
	@CreadoEl datetime,
	@CreadoPor int,
	@ModificadoEl datetime,
	@ModificadoPor int ,
	@Activo bit,
	@IdTarifaServicio int
	)
AS
BEGIN
	
	BEGIN TRANSACTION
--BEGIN TRY
		IF ISNULL(@IdTarifaServicio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tarifa de Servicio es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdTarifa, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tarifa es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdTipoServicio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tipo de Servicio es un campo requerido*FIN*', 16, 1);
			return;
			end
			
		UPDATE CatTarifaServicioPQ
		set IdTipoServicio = @IdTipoServicio
		where IdTarifaServicio =@IdTarifaServicio
		
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

