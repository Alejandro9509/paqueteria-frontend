
CREATE PROCEDURE [dbo].[usp_CatOperadoresAplicacionesMovilesToken]
	@IdOperador int ,
	@Aplicacion tinyint,
	@Token varchar(max) = NULL,
	@Sistema tinyint,
	@IdPeticion varchar(100)
	/*************************************************************************************************************************************
	@IdOperador int ,
	@Aplicacion tinyint,
	@Token varchar(max) = NULL,
	@Sistema tinyint,
	@IdPeticion varchar(100)

	Creado por:  Luis Edgar Ramos Cadena
	Fecha de Creacion: 16/03/2021
	Versión  Versión 8.0.59.10
	Solicitud 3939
	
	Se creo para agregar un token al operador y aplicacion movil
	***************************************/
AS
BEGIN TRY
	BEGIN TRANSACTION

		DECLARE @IdAplicacion int
		SET @IdAplicacion = (SELECT IdAplicacionMovil FROM CatAplicacionesMoviles WHERE Aplicacion = @Aplicacion)

		UPDATE CatOperadoresAplicacionesMoviles SET
		Token = @Token,
		TokenIOS = @Token,
		Sistema = @Sistema
		WHERE IdOperador = @IdOperador AND IdAplicacionMovil = @IdAplicacion

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

