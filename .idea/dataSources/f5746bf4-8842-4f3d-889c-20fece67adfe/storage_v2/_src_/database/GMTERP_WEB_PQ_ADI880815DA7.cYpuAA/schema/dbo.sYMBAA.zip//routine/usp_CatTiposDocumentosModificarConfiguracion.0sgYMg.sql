CREATE PROCEDURE [dbo].[usp_CatTiposDocumentosModificarConfiguracion]
	@IdTipoDocumentoConfiguracionTimbrado INT,
	@Complemento INT,
	@ModificadoEl DATETIME,
	@ModificadoPor INT,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Procedimiento usp_CatTiposDocumentosModificarConfiguracion

Parámetros: 
	@IdTipoDocumentoConfiguracionTimbrado	(entrada, entero). Identificador de la configuracion
	@Complemento							(entrada, entero). Enum del tipo de configuracion (1 - Traslado, 2 - Ingreso, 3 - Ninguno)
	@ModificadoEl							(entrada, fecha hora). Fecha y hora de modificacion
	@ModificadoPor							(entrada, entero). Usuario que modifica la configuracion
	@IdPeticion								(entrada, string). Id de la Petición, generada en WEBDEV 		
 
Descripción: Procedimiento que modifica las configuraciones del timbrado de los tipos de documentos CFDI tipo carta porte

Implementada por: Jesús Humberto Morales
Fecha de implementacion: 15/11/2021
Versión ERP: 8.0.66.23

Modificada por:   XXXXX
Fecha de mofidicacion: XXXXX
Versión ERP: XXXXX

Invocada desde: PAGE_CatTiposDocumentosConfigurarTimbrado (Solicitud 5022)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
		
		IF ISNULL(@IdTipoDocumentoConfiguracionTimbrado, 0) <= 0
			RAISERROR(N'El identificador de la configuración es un campo requerido', 16, 1)

		UPDATE CatTiposDocumentosConfiguracionTimbrado SET 
		Complemento = @Complemento,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
		WHERE IdTipoDocumentoConfiguracionTimbrado = @IdTipoDocumentoConfiguracionTimbrado

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

