CREATE PROCEDURE [dbo].[usp_ProPolizasAgregar]
	@IdTipoPoliza	int,
	@Numero	int,
	@Fecha	datetime,
	@ConceptoGeneral	varchar(125),
	@TotalCargos	money,
	@TotalAbonos	money,
	@ProcesoLigado	varchar(100),
	@IdProcesoLigado	int,
	@Periodo	int,
	@Ejercicio	int,
	@dsProPolizasCuentasContables ntext,	
	@CreadoEl	datetime,
	@CreadoPor	int,
	@IdPeticion varchar(100),
	@dsProPolizasDocumentos ntext,
	@IdProcesoLigadoAux int,
	@EsPolizaCancelacion bit = 0,
	@PolizaSaldoInicial bit = 0,
	@FoliadoAutomatico bit = 0,
	@Importar bit = 0,
	@ProcesoOriginal varchar(50) = NULL
	
AS
DECLARE 
	@docHandle int,
	@IdPoliza int,
	@AgregadoPorUsuario bit,
	@AnioActual smallint,
	@ATT_Concepto Varchar(125),
	@ATT_IdCuentaContable int,
	@ATT_Importe money = 0,
	@ATT_Referencia varchar(50),
	@ATT_TipoMovimiento tinyint,
	@ATT_ImporteMonedaExtranjera money = 0,
	@ATT_TipoCambio money = 0,
	@SumaCargos money = 0,
	@SumaAbonos money = 0,
	@CuentaMayor int,
	@CodigoCuentaContable Varchar(25),
	@MensageErrorCuentasConstable Varchar(1000)
/*
MODIFICADO:
	Se agrego el parametro:
	@ProcesoOriginal varchar(50) = NULL: para reconocer el proceso de donde se origino el Pago/MovimientoBancario para el reproceso desde la utileria
MODIFICADA POR:
	Diego Rubio
FECHA DE MODIFICACIÓN:
	2020-02-17
SOLICITUD: 
	SOLICITUD 000990

MODIFICADO:
	Se adecuo el usp para considerar polizas que son de saldo inicial.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-10-30
SOLICITUD: 
	SOLICITUD 000461

MODIFICADO:
	Se agregaron los parametros:
	@PolizaSaldoInicial bit = 0: Para distinguir si la poliza es de saldo inicial(Agregar/Importar polizas)
	@FoliadoAutomatico bit = 0: Para general foliado automatico , si el folio ya existe.(Esto para importar polizas)
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-10-29
SOLICITUD: 
	SOLICITUD 000462

MODIFICADO:
Se comentaron los cambios de la ejecucion usp_CatCuentasContablesSaldosActualizaSaldoInicial, usp_CatCuentasContablesSaldosActualizarSaldos
ya que con un pago mayor a las 800 facturas se atoraba la poliza.
MODIFICADA POR:
	Edgar Ramos
FECHA DE MODIFICACIÓN:
	2020-09-10
SOLICITUD: 
	SOLICITUD 2280
*/
/*
MODIFICADO:
Se Inicializaron a 0 las variables declaradas: @ATT_Importe,@ATT_ImporteMonedaExtranjera ,@ATT_TipoCambio,@SumaCargos,@SumaAbonos
MODIFICADA POR:
	Ignacio Perez
FECHA DE MODIFICACIÓN:
	2021-10-11
SOLICITUD: 
	SOLICITUD 4908
*/
BEGIN TRY
	BEGIN TRANSACTION
		
		IF @IdTipoPoliza = 0
			RAISERROR(N'El tipo de póliza es un campo requerido',
				16,
				1
				)

		IF LTRIM(RTRIM(@ConceptoGeneral)) = ''
			RAISERROR(N'El motivo de cancelación es un campo requerido',
				16,
				1
				)

		IF ISDATE(@Fecha) = 0
			RAISERROR(N'La fecha es un campo requerido',
				16,
				1
				)
	  IF @Periodo <> 13
	  Begin
		  IF @dsProPolizasCuentasContables IS NULL
				RAISERROR(N'Los asientos contables son requeridos',
					16,
					1
					) 				
	  End

		IF @PolizaSaldoInicial = 1
		BEGIN
			IF EXISTS(SELECT IdPoliza FROM ProPolizas WHERE Ejercicio = @Ejercicio AND SaldoInicial = 1)
			BEGIN
				RAISERROR(N'La póliza de saldo inicial ya existe en el ejercicio.',
					16,
					1
					) 
			END
		END

		Set @AnioActual = YEAR(Getdate())
		IF @ProcesoLigado <> '' AND @IdProcesoLigado <> 0
		BEGIN
			SET @AgregadoPorUsuario = 0
			--SE VALIDA QUE EL NUMERO NO ESTE YA REGISTRADO EN LOS PROCESOS AUTOMATICOS SI YA ESTA SE ASIGNA UNO
			IF (SELECT UsarNumeroPor FROM CatTiposPolizas WHERE IdTipoPoliza = @IdTipoPoliza) = 1
			BEGIN
				--SE ENUMERA POR EJERCICIO
				IF EXISTS(SELECT IdPoliza FROM ProPolizas WHERE Ejercicio = @Ejercicio AND IdTipoPoliza = @IdTipoPoliza AND Numero = @Numero)
				BEGIN
					SET @Numero = (SELECT UltimoNumeroUsado+1 FROM CatTiposPolizasEjercicios where IdTipoPoliza = @IdTipoPoliza AND Ejercicio = @AnioActual)
					IF EXISTS(SELECT IdPoliza FROM ProPolizas WHERE Ejercicio = @Ejercicio AND IdTipoPoliza = @IdTipoPoliza AND Numero = @Numero)
					BEGIN
						--SE ENUMERA POR EJERCICIO
						SET @Numero = (SELECT ISNULL(MAX(pp.Numero),0) AS Numero FROM ProPolizas AS pp WHERE pp.IdTipoPoliza = @IdTipoPoliza AND pp.Ejercicio = @Ejercicio)+1					
					END					
				END
			END
			ELSE
			BEGIN
				--SE ENUMERA POR PERIODO
				IF EXISTS(SELECT IdPoliza FROM ProPolizas WHERE Ejercicio = @Ejercicio AND Periodo = @Periodo AND IdTipoPoliza = @IdTipoPoliza AND Numero = @Numero)
				BEGIN
					SET @Numero = (SELECT UltimoNumeroUsado+1 FROM CatTiposPolizasEjercicios where IdTipoPoliza = @IdTipoPoliza AND Ejercicio = @AnioActual)
					IF EXISTS(SELECT IdPoliza FROM ProPolizas WHERE Ejercicio = @Ejercicio AND Periodo = @Periodo AND IdTipoPoliza = @IdTipoPoliza AND Numero = @Numero)
					BEGIN
						SET @Numero = (SELECT ISNULL(MAX(pp.Numero),0) AS Numero FROM ProPolizas AS pp WHERE pp.IdTipoPoliza = @IdTipoPoliza AND pp.Ejercicio = @Ejercicio AND pp.Periodo = @Periodo)+1						
					END					
				END
			END
		END
		ELSE
		BEGIN
			SET @AgregadoPorUsuario = 1
			IF (SELECT UsarNumeroPor FROM CatTiposPolizas WHERE IdTipoPoliza = @IdTipoPoliza) = 1
			BEGIN
				--SE ENUMERA POR EJERCICIO
				IF EXISTS(SELECT IdPoliza FROM ProPolizas WHERE Ejercicio = @Ejercicio AND IdTipoPoliza = @IdTipoPoliza AND Numero = @Numero)
				BEGIN
					IF @FoliadoAutomatico = 0 /*Foliado automatico desactivado*/
					BEGIN
						RAISERROR(N'Número de póliza duplicado',
							16,
							1
							) 
					END
					ELSE /*Foliado automatico activado*/
					BEGIN
						SET @Numero = (SELECT MAX(Numero)+1 FROM ProPolizas WHERE Ejercicio = @Ejercicio AND IdTipoPoliza = @IdTipoPoliza)
					END
				END
			END
			ELSE
			BEGIN
				--SE ENUMERA POR PERIODO
				IF EXISTS(SELECT IdPoliza FROM ProPolizas WHERE Ejercicio = @Ejercicio AND Periodo = @Periodo AND IdTipoPoliza = @IdTipoPoliza AND Numero = @Numero)
				BEGIN
					IF @FoliadoAutomatico = 0 /*Foliado automatico desactivado*/
					BEGIN
						RAISERROR(N'Número de póliza duplicado',
							16,
							1
							) 	
					END
					ELSE /*Foliado automatico activado*/
					BEGIN
						SET @Numero = (SELECT MAX(Numero)+1 FROM ProPolizas WHERE Ejercicio = @Ejercicio AND Periodo = @Periodo AND IdTipoPoliza = @IdTipoPoliza)
					END
				END			
			END		
		END
		
		IF @TotalCargos <> @TotalAbonos
			RAISERROR(N'El total de cargos no es igual al total de abonos la póliza esta descuadrada',
				16,
				1
				)

		INSERT INTO ProPolizas(ConceptoGeneral,CreadoEl,CreadoPor,Ejercicio,Fecha,IdProcesoLigado,IdTipoPoliza,Numero,Periodo,ProcesoLigado,TotalAbonos,TotalCargos,IdProcesoLigadoAux,EsPolizaCancelacion,SaldoInicial,Importar,ProcesoOriginal)
		VALUES(@ConceptoGeneral,@CreadoEl,@CreadoPor,@Ejercicio,@Fecha,@IdProcesoLigado,@IdTipoPoliza,@Numero,@Periodo,@ProcesoLigado,@TotalAbonos,@TotalCargos,@IdProcesoLigadoAux,@EsPolizaCancelacion,@PolizaSaldoInicial,@Importar,@ProcesoOriginal)
		
		SET @IdPoliza = (SELECT IDENT_CURRENT('ProPolizas'))

		--seccion para agregar el idPoliza a paremtros y poder obtenerlo de lado del web
		IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdPoliza' AND IdUsuario = @CreadoPor)
		INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdPoliza',@IdPoliza,@CreadoPor)
		ELSE
		UPDATE SisParametrosPagina SET Parametros = @IdPoliza WHERE Pagina = 'IdPoliza' AND IdUsuario = @CreadoPor						
		SET @MensageErrorCuentasConstable  = ''
		SET @CuentaMayor = 0
		SET @SumaCargos =0
		SET @SumaAbonos =0
		IF @dsProPolizasCuentasContables IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProPolizasCuentasContables

			SELECT ATT_Concepto,ATT_IdCuentaContable,ATT_Importe,ATT_Referencia,ATT_TipoMovimiento,ATT_ImporteMonedaExtranjera,ATT_TipoCambio
			INTO #TempProPolizasCuentasContables
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProPolizasCuentasContables',2) 
			WITH (ATT_Concepto varchar(125),ATT_IdCuentaContable int,ATT_Importe money,ATT_Referencia varchar(50),ATT_TipoMovimiento tinyint,ATT_ImporteMonedaExtranjera money,ATT_TipoCambio money)

			EXEC sp_xml_removedocument @docHandle
			
			DECLARE CursorProPolizasCuentasContables CURSOR FOR
			SELECT ATT_Concepto,ATT_IdCuentaContable,ATT_Importe,ATT_Referencia,ATT_TipoMovimiento,ATT_ImporteMonedaExtranjera,ATT_TipoCambio
			FROM #TempProPolizasCuentasContables
			
			OPEN CursorProPolizasCuentasContables
			FETCH NEXT FROM CursorProPolizasCuentasContables
			INTO @ATT_Concepto,@ATT_IdCuentaContable,@ATT_Importe,@ATT_Referencia,@ATT_TipoMovimiento,@ATT_ImporteMonedaExtranjera,@ATT_TipoCambio
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
				(Select @CuentaMayor = CuentaMayor,@CodigoCuentaContable = Codigo from CatCuentasContables Where IdCuentaContable = @ATT_IdCuentaContable)
				--Si la cuenta es  Afectable o de Cuadre
				If @CuentaMayor = 2 or @CuentaMayor = 5
				begin
				
					INSERT INTO ProPolizasCuentasContables(Concepto,CreadoEl,CreadoPor,IdCuentaContable,IdPoliza,Importe,Referencia,TipoMovimiento,AgregadoPorUsuario,ImporteMonedaExtranjera,TipoCambio)
				    Values(@ATT_Concepto,@CreadoEl,@CreadoPor,@ATT_IdCuentaContable,@IdPoliza,@ATT_Importe,@ATT_Referencia,@ATT_TipoMovimiento,@AgregadoPorUsuario,@ATT_ImporteMonedaExtranjera,@ATT_TipoCambio)
				   
				    IF @ATT_TipoMovimiento = 1
					BEGIN
						Set @SumaCargos = @SumaCargos + @ATT_Importe
					END
				    else
					BEGIN					
						Set @SumaAbonos = @SumaAbonos + @ATT_Importe
					END

					/*Se actualizan los saldos de la cuenta contable*/				
					/*IF @PolizaSaldoInicial = 0
					BEGIN
						EXEC usp_CatCuentasContablesSaldosActualizarSaldos @IdPeticion,@IdPoliza,@ATT_IdCuentaContable,@ATT_Importe,@ATT_ImporteMonedaExtranjera,@Ejercicio,@Periodo,@ATT_TipoMovimiento,1,0
					END*/
				end
				else
				begin
					SET @MensageErrorCuentasConstable = @MensageErrorCuentasConstable + 'La cuenta '+@CodigoCuentaContable+' no es afectable o de cuadre' + CHAR(13) + CHAR(10)
				end																	

				FETCH NEXT FROM CursorProPolizasCuentasContables
				INTO @ATT_Concepto,@ATT_IdCuentaContable,@ATT_Importe,@ATT_Referencia,@ATT_TipoMovimiento,@ATT_ImporteMonedaExtranjera,@ATT_TipoCambio
			END

			CLOSE CursorProPolizasCuentasContables
			DEALLOCATE CursorProPolizasCuentasContables	
			
			IF @SumaCargos <> @TotalCargos
			BEGIN
				Set @MensageErrorCuentasConstable = @MensageErrorCuentasConstable + 'La sumatoria por asiento de los Cargos no coincide con el total de Cargos'+ CHAR(13) + CHAR(10)
			END
			IF @SumaAbonos <> @TotalAbonos
			BEGIN
				Set @MensageErrorCuentasConstable = @MensageErrorCuentasConstable + 'La sumatoria por asiento de los Abonos no coincide con el total de Abonos'+ CHAR(13) + CHAR(10)
			END
				
			If @MensageErrorCuentasConstable <> ''	
				RAISERROR(@MensageErrorCuentasConstable,
						16,
						1
						) 					
		END
		--IF @dsProPolizasCuentasContables IS NOT NULL
		--BEGIN
		--	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProPolizasCuentasContables

		--	SELECT ATT_Concepto,ATT_IdCuentaContable,ATT_Importe,ATT_Referencia,ATT_TipoMovimiento,ATT_ImporteMonedaExtranjera,ATT_TipoCambio
		--	INTO #TempProPolizasCuentasContables
		--	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProPolizasCuentasContables',2) 
		--	WITH (ATT_Concepto varchar(125),ATT_IdCuentaContable int,ATT_Importe money,ATT_Referencia varchar(50),ATT_TipoMovimiento tinyint,ATT_ImporteMonedaExtranjera money,ATT_TipoCambio money)

		--	EXEC sp_xml_removedocument @docHandle
			
		--	INSERT INTO ProPolizasCuentasContables(Concepto,CreadoEl,CreadoPor,IdCuentaContable,IdPoliza,Importe,Referencia,TipoMovimiento,AgregadoPorUsuario,ImporteMonedaExtranjera,TipoCambio)
		--	SELECT ATT_Concepto,@CreadoEl,@CreadoPor,ATT_IdCuentaContable,@IdPoliza,ATT_Importe,ATT_Referencia,ATT_TipoMovimiento,@AgregadoPorUsuario,ATT_ImporteMonedaExtranjera,ATT_TipoCambio
		--	FROM #TempProPolizasCuentasContables
		--END	
		
		UPDATE CatTiposPolizas SET
			UltimoNumeroUsado = @Numero,
			UltimoNumeroUsadoPeriodo1 = CASE @Periodo WHEN 1 THEN @Numero ELSE UltimoNumeroUsadoPeriodo1 END,
			UltimoNumeroUsadoPeriodo2 = CASE @Periodo WHEN 2 THEN @Numero ELSE UltimoNumeroUsadoPeriodo2 END,
			UltimoNumeroUsadoPeriodo3 = CASE @Periodo WHEN 3 THEN @Numero ELSE UltimoNumeroUsadoPeriodo3 END,
			UltimoNumeroUsadoPeriodo4 = CASE @Periodo WHEN 4 THEN @Numero ELSE UltimoNumeroUsadoPeriodo4 END,
			UltimoNumeroUsadoPeriodo5 = CASE @Periodo WHEN 5 THEN @Numero ELSE UltimoNumeroUsadoPeriodo5 END,
			UltimoNumeroUsadoPeriodo6 = CASE @Periodo WHEN 6 THEN @Numero ELSE UltimoNumeroUsadoPeriodo6 END,
			UltimoNumeroUsadoPeriodo7 = CASE @Periodo WHEN 7 THEN @Numero ELSE UltimoNumeroUsadoPeriodo7 END,
			UltimoNumeroUsadoPeriodo8 = CASE @Periodo WHEN 8 THEN @Numero ELSE UltimoNumeroUsadoPeriodo8 END,
			UltimoNumeroUsadoPeriodo9 = CASE @Periodo WHEN 9 THEN @Numero ELSE UltimoNumeroUsadoPeriodo9 END,
			UltimoNumeroUsadoPeriodo10 = CASE @Periodo WHEN 10 THEN @Numero ELSE UltimoNumeroUsadoPeriodo10 END,
			UltimoNumeroUsadoPeriodo11 = CASE @Periodo WHEN 11 THEN @Numero ELSE UltimoNumeroUsadoPeriodo11 END,
			UltimoNumeroUsadoPeriodo12 = CASE @Periodo WHEN 12 THEN @Numero ELSE UltimoNumeroUsadoPeriodo12 END,
			UltimoNumeroUsadoPeriodo13 = CASE @Periodo WHEN 13 THEN @Numero ELSE UltimoNumeroUsadoPeriodo13 END
		WHERE IdTipoPoliza = @IdTipoPoliza	
		
		
		IF exists(Select * from CatTiposPolizasEjercicios Where IdTipoPoliza = @IdTipoPoliza	And Ejercicio = @Ejercicio)
		begin
			UPDATE CatTiposPolizasEjercicios SET
				UltimoNumeroUsado = @Numero,
				UltimoNumeroUsadoPeriodo1 = CASE @Periodo WHEN 1 THEN @Numero ELSE UltimoNumeroUsadoPeriodo1 END,
				UltimoNumeroUsadoPeriodo2 = CASE @Periodo WHEN 2 THEN @Numero ELSE UltimoNumeroUsadoPeriodo2 END,
				UltimoNumeroUsadoPeriodo3 = CASE @Periodo WHEN 3 THEN @Numero ELSE UltimoNumeroUsadoPeriodo3 END,
				UltimoNumeroUsadoPeriodo4 = CASE @Periodo WHEN 4 THEN @Numero ELSE UltimoNumeroUsadoPeriodo4 END,
				UltimoNumeroUsadoPeriodo5 = CASE @Periodo WHEN 5 THEN @Numero ELSE UltimoNumeroUsadoPeriodo5 END,
				UltimoNumeroUsadoPeriodo6 = CASE @Periodo WHEN 6 THEN @Numero ELSE UltimoNumeroUsadoPeriodo6 END,
				UltimoNumeroUsadoPeriodo7 = CASE @Periodo WHEN 7 THEN @Numero ELSE UltimoNumeroUsadoPeriodo7 END,
				UltimoNumeroUsadoPeriodo8 = CASE @Periodo WHEN 8 THEN @Numero ELSE UltimoNumeroUsadoPeriodo8 END,
				UltimoNumeroUsadoPeriodo9 = CASE @Periodo WHEN 9 THEN @Numero ELSE UltimoNumeroUsadoPeriodo9 END,
				UltimoNumeroUsadoPeriodo10 = CASE @Periodo WHEN 10 THEN @Numero ELSE UltimoNumeroUsadoPeriodo10 END,
				UltimoNumeroUsadoPeriodo11 = CASE @Periodo WHEN 11 THEN @Numero ELSE UltimoNumeroUsadoPeriodo11 END,
				UltimoNumeroUsadoPeriodo12 = CASE @Periodo WHEN 12 THEN @Numero ELSE UltimoNumeroUsadoPeriodo12 END,
				UltimoNumeroUsadoPeriodo13 = CASE @Periodo WHEN 13 THEN @Numero ELSE UltimoNumeroUsadoPeriodo13 END
			WHERE IdTipoPoliza = @IdTipoPoliza	And Ejercicio = @Ejercicio
		end
		else
		begin
			INSERT INTO CatTiposPolizasEjercicios (IdTipoPoliza,
						UltimoNumeroUsado,
						UltimoNumeroUsadoPeriodo1,
						UltimoNumeroUsadoPeriodo2,
						UltimoNumeroUsadoPeriodo3,
						UltimoNumeroUsadoPeriodo4,
						UltimoNumeroUsadoPeriodo5,
						UltimoNumeroUsadoPeriodo6,
						UltimoNumeroUsadoPeriodo7,
						UltimoNumeroUsadoPeriodo8,
						UltimoNumeroUsadoPeriodo9,
						UltimoNumeroUsadoPeriodo10,
						UltimoNumeroUsadoPeriodo11,
						UltimoNumeroUsadoPeriodo12,
						UltimoNumeroUsadoPeriodo13,
						Ejercicio,
						CreadoEl,
						CreadoPor)
			SELECT CP.IdTipoPoliza,
						CP.UltimoNumeroUsado,
						CP.UltimoNumeroUsadoPeriodo1,
						CP.UltimoNumeroUsadoPeriodo2,
						CP.UltimoNumeroUsadoPeriodo3,
						CP.UltimoNumeroUsadoPeriodo4,
						CP.UltimoNumeroUsadoPeriodo5,
						CP.UltimoNumeroUsadoPeriodo6,
						CP.UltimoNumeroUsadoPeriodo7,
						CP.UltimoNumeroUsadoPeriodo8,
						CP.UltimoNumeroUsadoPeriodo9,
						CP.UltimoNumeroUsadoPeriodo10,
						CP.UltimoNumeroUsadoPeriodo11,
						CP.UltimoNumeroUsadoPeriodo12,
						CP.UltimoNumeroUsadoPeriodo13,
						@Ejercicio,
						CP.CreadoEl,
						CP.CreadoPor
			FROM CatTiposPolizas AS CP
		end
		
		
		-- AGREGAR DOCUMENTOS A LA POLIZA
		IF @dsProPolizasDocumentos IS NOT NULL
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProPolizasDocumentos
				
				SELECT ATT_Documento,ATT_DocumentoNombreArchivo,ATT_Descripcion,ATT_PesoBytes
				INTO #TempProPolizasDocumentos
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProPolizasDocumentos',2) 
				WITH (ATT_Documento ntext,ATT_DocumentoNombreArchivo varchar(MAX),ATT_Descripcion varchar(50),ATT_PesoBytes int)
				
				EXEC sp_xml_removedocument @docHandle
				
				INSERT INTO ProPolizasDocumentos(CreadoEl,CreadoPor,IdPoliza,Documento,DocumentoNombreArchivo,Descripcion,PesoBytes)
				SELECT @CreadoEl,@CreadoPor,@IdPoliza,ATT_Documento,ATT_DocumentoNombreArchivo,ATT_Descripcion,ATT_PesoBytes FROM #TempProPolizasDocumentos
			END
			
			/*Hasta que se termine de procesar la póliza , se va a validar si es póliza de saldo inicial*/
			/*para actualizar los saldos iniciales de CatCuentasContables Saldos*/	
			/*IF @PolizaSaldoInicial = 1
			BEGIN
				EXEC usp_CatCuentasContablesSaldosActualizaSaldoInicial @IdPeticion,@IdPoliza
			END
			*/
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

