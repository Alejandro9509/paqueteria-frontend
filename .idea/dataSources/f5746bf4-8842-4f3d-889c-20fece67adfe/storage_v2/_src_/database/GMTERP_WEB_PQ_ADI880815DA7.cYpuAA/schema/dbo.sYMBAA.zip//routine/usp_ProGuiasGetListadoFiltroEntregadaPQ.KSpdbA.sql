CREATE PROCEDURE [dbo].[usp_ProGuiasGetListadoFiltroEntregadaPQ]
	@Fecha DATE,
	@Destino int,
	@IdMoneda int,
	@IdTipoPago int
AS
BEGIN TRY
	BEGIN TRANSACTION
	SELECT
		g.IdEmbarque
		,(select FolioEmbarque from ProEmbarquePQ e where g.IdEmbarque = e.IdEmbarque) as FolioEmbarque
		,(select IdRecoleccion from ProRecoleccionPQ r where r.IdRecoleccion =  e.IdRecoleccion) as foliorecoleccion
		,g.FolioGuia
		,(select FolioInforme from ProInformePQ r where r.IdInforme =  g.IdInforme) as FolioInforme
		,e.Fecha
		,g.Hora
		,g.IdEstatusGuia
		
		,e.TipoCambio
		,e.IdTipoCobro
		,e.NombreRemitente
		,e.RFCRemitente
		,e.DomicilioRemitente
		,e.IdCodigoPostalRemitente
		,e.IdCiudadRemitente
		,e.CorreoRemitente
		,e.TelefonoRemitente
		,e.ContactoRemitente
		,e.IdCiudadOrigen
		,e.NombreDestinatario
		,e.RFCDestinatario
		,e.DomicilioDestinatario
		,e.IdCodigoPostalDestinatario
		,e.IdCiudadDestinatario
		,e.CorreoDestinatario
		,e.TelefonoDestinatario
		,e.ContactoDestinatario
		,e.IdCiudadDestino
		,e.FechaEntrega
		,e.HoraEntrega
		,e.NoPaquetes
		,e.NoSobres
		,e.IdOperador
		,e.IdUnidad
		,e.FechaSalida
		,e.HoraSalida
		,g.FechaCancelacion
		,g.UsuarioCancelacion
		,e.MotivoCancelacion
		,e.EntregarMismoDomicilio 
		,e.FechaLlegada 
		,e.HoraLlegada  
		,e.CodigoPostalEntrega  
		,e.IdCiudadEntrega 
		,e.IdZonaEntrega 
		,e.DomicilioEntrega  
		,e.EntregarEn  
		,DatosAdicionales 
		,g.Tracking,g.IdMoneda,g.CreadoPor,g.CreadoEl,g.ModificadoPor,g.ModificadoEl,g.IdGuia,g.IdSucursal,
		(select Sucursal from CatSucursales s where s.IdSucursal = g.IdSucursal ) as Sucursal,	
		(select Estatus from CatEstatusGuiasPQ eg where eg.IdEstatusGuias = g.IdEstatusGuia ) as estatusguia,
        (select OrigenDestino from CatOrigenesDestinos c where c.IdOrigenDestino = e.IdCiudadOrigen) as CiudadOrigen,
        (select OrigenDestino from CatOrigenesDestinos c where c.IdOrigenDestino = e.IdCiudadDestino) as CiudadDestino,

		(select Estado from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadRemitente)) as EstadoRemitente,
		(select Estado from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadDestinatario)) as EstadoDestinatario,
		(select Estado from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadEntrega)) as EstadoEntregaGuia,
		(select Pais from CatPaises pai where pai.IdPais = (select IdPais from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadRemitente))) as PaisRemitente,
		(select Pais from CatPaises pai where pai.IdPais = (select IdPais from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadDestinatario))) as PaisDestinatario,
		(select Pais from CatPaises pai where pai.IdPais = (select IdPais from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadEntrega))) as PaisEntregaGuia
		,g.ValorDeclarado,g.IdTipoServicio, g.qrValidado, g.utimaMillaOrden, g.pagado
		,e.IdCliente
		,(Select c.NombreFiscal from CatClientes c where c.IdCliente = e.IdCliente) as Cliente
		,(Select c.Bloqueado from CatClientes c where c.IdCliente = e.IdCliente) as ClienteBloqueado
		FROM ProGuiaPQ g inner join  ProEmbarquePQ e on g.IdEmbarque= e.IdEmbarque
		WHERE g.Fecha = @Fecha and e.IdGuia = g.IdGuia and (IdEstatusGuia = 18 OR IdEstatusGuia = 7 OR IdEstatusGuia = 17) and (e.IdCiudadDestino = @Destino) and (g.IdMoneda = @IdMoneda) and (g.TipoPago = @IdTipoPago)
		ORDER BY Fecha DESC, Hora DESC
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

