CREATE PROCEDURE [dbo].[usp_ProFacturasModificar]
	@IdFactura int,
	@FechaHora datetime,
	@SubTotal money,
	@Descuento money,
	@MotivoDescuento varchar(100),
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Estatus tinyint,
	@Observaciones varchar(3000),
	@CondicionesPago tinyint,
	@DiasCredito tinyint,
	@FechaProgPago datetime,
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),
	@IdFormatoImpresion int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@dsProFacturasConceptosFacturacion ntext,
	@dsProFacturasImpuestos ntext,
	@IdPeticion varchar(100),
	@IdAddenda int,
	@Campo1 varchar(250),
	@Campo2 varchar(250),
	@Campo3 varchar(250),
	@Campo4 varchar(250),
	@Campo5 varchar(250),
	@Campo6 varchar(250),
	@Campo7 varchar(250),
	@Campo8 varchar(250),
	@Campo9 varchar(250),
	@Campo10 varchar(250),
	@PermitirFacturarRebaseCredito bit,
	@FacturarPorKmsRuta bit,
	@ClaveMetodoPago varchar(5),
	@dsProFacturasImagenes ntext,
	@IdUsoCFDI varchar(5),
	@IdCombustible int = NULL,
	@LitrosCombustible decimal(15,4) = NULL,
	@FacturarFlete bit = NULL,
	@FacturarCombustible bit = NULL,
	@IEPS money = NULL,
	@ClaveTAR varchar(15)=NULL,
	@IncluirIEPS bit = NULL,
	@FactorIeps money=NULL,
	@dsProFacturasCamposAdicionales ntext = NULL,
	@numeroMetodoPago int = 0,
	@dsComplementos ntext = NULL,
	@ConceptosFacturaionDistribucion ntext = NULL
AS
/*************************************************************************************************************************************
	@IdFactura int,
	@FechaHora datetime,
	@SubTotal money,
	@Descuento money,
	@MotivoDescuento varchar(100),
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Estatus tinyint,
	@Observaciones varchar(3000),
	@CondicionesPago tinyint,
	@DiasCredito tinyint,
	@FechaProgPago datetime,
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),
	@IdFormatoImpresion int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@dsProFacturasConceptosFacturacion ntext,
	@dsProFacturasImpuestos ntext,
	@IdPeticion varchar(100),
	@IdAddenda int,
	@Campo1 varchar(250),
	@Campo2 varchar(250),
	@Campo3 varchar(250),
	@Campo4 varchar(250),
	@Campo5 varchar(250),
	@Campo6 varchar(250),
	@Campo7 varchar(250),
	@Campo8 varchar(250),
	@Campo9 varchar(250),
	@Campo10 varchar(250),
	@PermitirFacturarRebaseCredito bit,
	@FacturarPorKmsRuta bit,
	@ClaveMetodoPago varchar(5),
	@dsProFacturasImagenes ntext,
	@IdUsoCFDI varchar(5),
	@IdCombustible int = NULL,
	@LitrosCombustible decimal(15,4) = NULL,
	@FacturarFlete bit = NULL,
	@FacturarCombustible bit = NULL,
	@IEPS money = NULL,
	@ClaveTAR varchar(15)=NULL,
	@IncluirIEPS bit = NULL,
	@FactorIeps money=NULL,
	@dsProFacturasCamposAdicionales ntext = NULL,
	@numeroMetodoPago int = 0

	Modificado por:  Enrique Ramos Alvarez
	Fecha de Creacion:  19/02/2020
	Versión: 8.0.50.06 
	Solicitud 633

	Modificado por:  David Omar Cabrera Bernal
	Fecha de Creacion:  21/04/2020
	Versión: 8.0.51.41
	Solicitud 001505
	Se modifico la forma en la que se cargan los conceptos de facturacion, agregando una seccion apra impuestos por concepto

	Modificado por:  David Omar Cabrera Bernal
	Fecha de Creacion:  13/05/2020
	Versión: 8.0.52.05
	Solicitud 001770
	Se agregó campo de numero de metodo de pago a la clase de ProFacturas

	Modificada por: Jesús Humberto Morales Mojica
	Fecha de mofidicacion: 15/05/2020
	Versión:  8.0.52.14
	Solicitud 001507
	Se agregó al XML de conceptos los impuestos de IEPS y ISR para facturacion general

	Modificada por: Luis Edgar Ramos Cadena
	Fecha de mofidicacion: 07/07/2020
	Versión:  8.0.53.50
	Solicitud 1734
	Se agrego validacion cuando se tiene un @IdAddenda donde valida si no existe una addenda ligada a la factura en la tabla ProFacturasAddendasCamposAdicionales
	realiza una inserccion en caso contrario modifica el registro existente en la tabla ProFacturasAddendasCamposAdicionales

	Se creo para guardar los datos de los archivos en base de datos 


	Modificada por: Jesús Ignacio Perez Macias
	Fecha de mofidicacion: 04/08/2020
	Versión 8.0.54.27
	Solicitud 002644
	Se modifico para realizar el modificado de los complementos a sus tablas correspondientes, esto se realizo para que los clientes que tengan el
	complemento Liverpool activo se pueda ver reflejado en su xml para el timbrado, se agrego @dsComplementos y este es el que se manipula para
	dicho modificado

	
	Modificado por: Yarazeth Lemus
	Fecha de modificacion: 09/11/2020
	Versión 8.0.56.13
	Solicitud 003223
	se agrego el numero de identificacion en las tablas xml temporales

	MODIFICADO:
		Se agregaro la bitacora de tipo de cambio ( SisBitacoraTipoCambio )
	MODIFICADA POR:
		Abril CG
	FECHA DE MODIFICACIÓN:
		2021-04-06
	SOLICITUD: 
		SOLICITUD 004067

	Modificada por: Abril CG
	Fecha de mofidicacion: 2021-04-15
	Versión 8.0.58.02
	Solicitud: 004178 - Se cerraron cursores

***************************************/
/*
	SOLICITUD:	004401
				Se agrego la distribucion de concepto por unidad 
	MODIFICADO EL:	2021-07-15
	MODIFICADO POR:	ABRIL CG
*/

DECLARE
	@IdCliente int,
	@IdSucursal int,
	@IdMonedaAnt int,
	@TotalAnt money,
	@docHandle int,
	@CursorIdFacturaConceptoFacturacion int,
	@CursorIdConceptoFacturacion int,
	@CursorCantidad decimal(15,4),
	@CursorPrecio_Unitario money,
	@CursorImporte money,
	@CursorTraslada_IVA bit,
	@CursorRetiene_IVA bit,
	@CursorObservaciones varchar(8000),
	@CursorUnidad_Medida varchar(30),
	@CursorConceptoViaje bit,
	@CursorIdFacturaImpuesto int,
	@CursorIdImpuesto int,
	@CursorIncluirObservacionesXML tinyint,
	@CursorClaveSATProducto varchar(8),
	@CursorClaveSATUnidad varchar(8),
	@CursorDescuento money,
	@CursorPorcentaje decimal(15,4),
	@TipoFactura int,
	@return_value int,
	@IdFacturaConceptoFacturacion int,
	@CursorIdImpuestoTrasladado int,
	@CursorIdImpuestoRetenido int,
	@CursorImporteTrasladado money,
	@CursorImporteRetenido money,
	@CursorIdImpuestoIEPS int,
	@CursorImporteIEPS money,
	@CursorIdImpuestoISR int,
	@CursorImporteISR money,
	@CursorNoIdentificacion varchar(40),
	@ComplementosCreadoEl datetime,
	@ComplementosCreadoPor int,

	@CursorComplementoIdComplemento int,
	@CursorComplementoValor1 varchar(250),
	@CursorComplementoValor2 varchar(250),
	@CursorComplementoValor3 varchar(250)

	/*Conceptos Facturacion Distribucion*/
	DECLARE @VarConceptosFacturacionDistribucion TABLE  
	(IdFacturaConceptoFacturacionDistribucion int,
	IdFacturaConceptoFacturacion int,
	IdConceptoFacturacion int ,
	IdUnidad int ,
	ImporteDistribuido money )

BEGIN TRY
	BEGIN TRANSACTION		


	IF EXISTS(SELECT * FROM ProPolizas WHERE ProcesoLigado = 'ProFacturas' AND IdProcesoLigado = @IdFactura)
    AND (SELECT CONVERT(DATE,FechaHora) FROM ProFacturas WHERE IdFactura=@IdFactura) <> CONVERT(DATE,@FechaHora) 
        RAISERROR(N'La fecha no se puede modificar porque tiene una póliza contable ligada',
            16,
            1
            )
            
	IF @IdFactura = 0
		RAISERROR(N'El identificador de la factura es un campo requerido',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM ProFacturas WHERE IdFactura = @IdFactura) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)

	IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura) = 2
		RAISERROR(N'Las facturas por viaje no pueden ser modificadas',
			16,
			1
			)	

	IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura) = 3
		RAISERROR(N'Las facturas por viaje parcial no pueden ser modificadas',
			16,
			1
			)				

	IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura) = 4
		RAISERROR(N'Las facturas por peso descarga no pueden ser modificadas',
			16,
			1
			)

	IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura) = 5
		RAISERROR(N'Las facturas por kilómetro no pueden ser modificadas',
			16,
			1
			)
			
	IF (SELECT ISNULL(Abonos,0) FROM ProFacturas WHERE IdFactura = @IdFactura) <> 0
		RAISERROR(N'No puede ser modificada esta factura porque tiene abonos',
			16,
			1
			)

	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 1--pagada
		RAISERROR(N'No puede ser modificada esta factura porque está pagada',
			16,
			1
			)
			
	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 2--cancelada
		RAISERROR(N'No puede ser modificada esta factura porque está cancelada',
			16,
			1
			)

	IF (SELECT EstatusImpresoEnviadoCliente FROM ProFacturas WHERE IdFactura = @IdFactura) = 1--impresao enviada al cliente
		RAISERROR(N'No puede ser modificada esta factura porque está impresa o se envió por correo al cliente',
			16,
			1
			)
						
	IF EXISTS(SELECT TimbrePruebas FROM ProFacturas WHERE IdFactura = @IdFactura AND TimbrePruebas = 0 AND FolioFiscalUUID <> '') -- si es timbre real y tiene uuid
		RAISERROR(N'No puede ser modificada esta factura porque ya se timbró y esta registrada en el SAT',
			16,
			1
			)			
			
	IF ISDATE(@FechaHora) = 0			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF @SubTotal = 0
		RAISERROR(N'El subtotal es un campo requerido',
			16,
			1
			)

	IF @IdMoneda = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)

	IF @TipoCambio <= 0
		RAISERROR(N'El tipo de cambio es un campo requerido',
			16,
			1
			)			
			
	IF @dsProFacturasConceptosFacturacion IS NULL
		RAISERROR(N'Los conceptos de facturacion son requeridos',
			16,
			1
			)	

	IF @dsProFacturasImpuestos IS NULL
		RAISERROR(N'Los impuestos son requeridos',
			16,
			1
			)					
	IF (SELECT FacturaExterna FROM ProFacturas WHERE IdFactura = @IdFactura) = 1 
	RAISERROR(N'No se puede modificar esta Factura por que es externa',
		16,
		1
		)
		
		
	IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura) = 8 AND ISNULL(@LitrosCombustible,0) = 0 --Por Combustible
		RAISERROR(N'Los litros son requeridos',
			16,
			1
			)
			
			
	IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura) = 8 AND ISNULL(@IdCombustible,0) = 0 --Por Combustible
		RAISERROR(N'El Combustible es requerido',
			16,
			1
			)
			

		
		
	If @IdFormatoImpresion = 0
		SET @IdFormatoImpresion = NULL
	
	--se le disminuye el saldo al cliente 
	SET @IdCliente = (SELECT IdCliente FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @TotalAnt = (SELECT Total FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @IdSucursal = (SELECT IdSucursal FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @IdMonedaAnt = (SELECT IdMoneda FROM ProFacturas WHERE IdFactura = @IdFactura)
		
	IF @IdMonedaAnt = 1 OR @IdMonedaAnt = 3
		UPDATE CatClientes SET SaldoCredito = SaldoCredito - @TotalAnt WHERE IdCliente = @IdCliente
	ELSE
		UPDATE CatClientes SET SaldoCreditoDLLS = SaldoCreditoDLLS - @TotalAnt WHERE IdCliente = @IdCliente	
	
	UPDATE ProFacturas SET
		FechaHora = @FechaHora,
		SubTotal = @SubTotal,
		Descuento = @Descuento,
		MotivoDescuento = @MotivoDescuento,
		ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales,
		ImpuestosRetenidosLocales = @ImpuestosRetenidosLocales,
		ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales,
		ImpuestosTrasladadosLocales = @ImpuestosTrasladadosLocales,
		Total = @Total,
		TipoCambio = @TipoCambio,
		IdMoneda = @IdMoneda,
		Estatus = @Estatus,
		Observaciones = @Observaciones,
		CondicionesPago = @CondicionesPago,
		DiasCredito = @DiasCredito,
		FechaProgPago = @FechaProgPago,
		NroCuentaPago = @NroCuentaPago,
		MetodoPago = @MetodoPago,
		IdFormatoImpresion = @IdFormatoImpresion,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		FacturarPorKmsRuta = @FacturarPorKmsRuta,
		ClaveMetodoPago = @ClaveMetodoPago,
		IdUsoCFDI = @IdUsoCFDI,
		IdCombustible = @IdCombustible,
		LitrosCombustible = @LitrosCombustible,
		FacturarFlete = @FacturarFlete,
		FacturarCombustible = @FacturarCombustible,
		IncluirIEPS=@IncluirIEPS,
		IEPS = @IEPS,
		ClaveTAR = @ClaveTAR,
		FactorIeps = @FactorIeps,
		NumeroMetodoPago = @numeroMetodoPago
	WHERE IdFactura = @IdFactura

	/*SE GENERA EL XML Y VARIABLE TABLA PARA LA DISTRIBUCION DE LOS CONCEPTOS DE FACTURACION*/
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @ConceptosFacturaionDistribucion
	
	SELECT ATT_IdFacturaConceptoFacturacionDistribucion,ATT_IdFacturaConceptoFacturacion,ATT_IdConceptoFacturacion,ATT_IdUnidad,ATT_ImporteDistribuido
	INTO #ConceptosFacturacionDistribucion
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/ConceptoDistribucion',2) 
	WITH (ATT_IdFacturaConceptoFacturacionDistribucion int,ATT_IdFacturaConceptoFacturacion int, ATT_IdConceptoFacturacion int ,ATT_IdUnidad int ,ATT_ImporteDistribuido money)
    
	EXEC sp_xml_removedocument @docHandle

	/*DISTRIBUCION DEL CONCEPTO DE FACTURACION POR UNIDADES*/
	INSERT INTO @VarConceptosFacturacionDistribucion (IdFacturaConceptoFacturacionDistribucion,IdFacturaConceptoFacturacion,IdConceptoFacturacion,IdUnidad ,ImporteDistribuido)
	SELECT
	 Temp.ATT_IdFacturaConceptoFacturacionDistribucion
	,Temp.ATT_IdFacturaConceptoFacturacion
	,Temp.ATT_IdConceptoFacturacion
	,Temp.ATT_IdUnidad 
	,Temp.ATT_ImporteDistribuido
	FROM #ConceptosFacturacionDistribucion AS Temp 

	/*ELIMINA LAS DISTRIBUCION DE UNIDADES QUE NO ESTAN EN LA RELACION  @VarConceptosFacturacionDistribucion*/
	DELETE FROM ProFacturasConceptosFacturacionDistribucion 
	WHERE IdFacturaConceptoFacturacion IN ( SELECT IdFacturaConceptoFacturacion FROM ProFacturasConceptosFacturacion WHERE IdFactura = @IdFactura )

	/*SE GENERA TABLA TEMPORAL PARA LOS CONCEPTOS DE FACTURACION*/
	----SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasConceptosFacturacion

	SELECT ATT_IdFacturaConceptoFacturacion,ATT_IdConceptoFacturacion,ATT_Cantidad,ATT_PrecioUnitario,ATT_Importe,ATT_TrasladaImpuesto,ATT_RetieneImpuesto,ATT_Observaciones,ATT_UnidadMedida,
	ATT_ConceptoViaje,ATT_IncluirObservacionesXML,ATT_ClaveSATProducto,ATT_ClaveSATUnidad,ATT_Descuento,
	ATT_IdImpuestoTraslado,ATT_ImporteTrasladado,ATT_IdImpuestoRetencion,ATT_ImporteRetencion,ATT_IdImpuestoIEPS,ATT_ImporteIEPS,ATT_IdImpuestoISR,ATT_ImporteISR,ATT_NoIdentificacion
	INTO #TempProFacturasConceptosFacturacion
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasConceptosFacturacion',2) 
	WITH (ATT_IdFacturaConceptoFacturacion int,ATT_IdConceptoFacturacion int,ATT_Cantidad decimal(15,4),ATT_PrecioUnitario decimal(15,6),ATT_Importe money,ATT_TrasladaImpuesto bit,
	ATT_RetieneImpuesto bit,ATT_Observaciones varchar(8000),ATT_UnidadMedida varchar(30),ATT_ConceptoViaje bit,ATT_IncluirObservacionesXML tinyint,ATT_ClaveSATProducto varchar(8),ATT_ClaveSATUnidad varchar(8),ATT_Descuento money,
	ATT_IdImpuestoTraslado int,ATT_ImporteTrasladado money,ATT_IdImpuestoRetencion int,ATT_ImporteRetencion money, ATT_IdImpuestoIEPS int, ATT_ImporteIEPS money, ATT_IdImpuestoISR int, ATT_ImporteISR money, ATT_NoIdentificacion varchar(40))

	EXEC sp_xml_removedocument @docHandle
	
	DECLARE ProFacturasConceptosFacturacionCursor CURSOR LOCAL FOR
	SELECT * FROM #TempProFacturasConceptosFacturacion

	OPEN ProFacturasConceptosFacturacionCursor
	FETCH NEXT FROM ProFacturasConceptosFacturacionCursor
	INTO @CursorIdFacturaConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorCantidad,@CursorPrecio_Unitario,@CursorImporte,@CursorTraslada_IVA,@CursorRetiene_IVA,@CursorObservaciones,@CursorUnidad_Medida,
	@CursorConceptoViaje,@CursorIncluirObservacionesXML,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorDescuento,
	@CursorIdImpuestoTrasladado,@CursorImporteTrasladado,@CursorIdImpuestoRetenido,@CursorImporteRetenido,@CursorIdImpuestoIEPS,@CursorImporteIEPS,@CursorIdImpuestoISR,@CursorImporteISR,@CursorNoIdentificacion
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		print @CursorIdFacturaConceptoFacturacion
		IF @CursorIdFacturaConceptoFacturacion = 0
		BEGIN
			INSERT INTO ProFacturasConceptosFacturacion(Cantidad,ConceptoViaje,IdConceptoFacturacion,IdFactura,Importe,Observaciones,PrecioUnitario,
			RetieneImpuesto,TrasladaImpuesto,UnidadMedida,CreadoEl,CreadoPor,IncluirObservacionesXML,ClaveSATProducto,ClaveSATUnidad,Descuento,NoIdentificacion)
			VALUES(@CursorCantidad,@CursorConceptoViaje,@CursorIdConceptoFacturacion,@IdFactura,@CursorImporte,@CursorObservaciones,@CursorPrecio_Unitario,
			@CursorRetiene_IVA,@CursorTraslada_IVA,@CursorUnidad_Medida,@ModificadoEl,@ModificadoPor,@CursorIncluirObservacionesXML,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorDescuento,@CursorNoIdentificacion)
		
			SET @IdFacturaConceptoFacturacion = (SELECT IDENT_CURRENT('ProFacturasConceptosFacturacion'))
		
			/*SE GUARDA LA DISTRIBUCION DEL CONCEPTO DE FACTURACION*/
			INSERT INTO ProFacturasConceptosFacturacionDistribucion(IdFacturaConceptoFacturacion,IdUnidad,ImporteDistribuido)
			SELECT
			 @IdFacturaConceptoFacturacion
			,IdUnidad 
			,ImporteDistribuido
			FROM @VarConceptosFacturacionDistribucion WHERE IdConceptoFacturacion = @CursorIdConceptoFacturacion

			IF @CursorIdImpuestoTrasladado != 0 
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoTrasladado,@CursorImporteTrasladado )
			END

			IF @CursorIdImpuestoRetenido != 0
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoRetenido,@CursorImporteRetenido )
			END

			IF @CursorIdImpuestoIEPS != 0
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoIEPS,@CursorImporteIEPS)
			END

			IF @CursorIdImpuestoISR != 0
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @IdFacturaConceptoFacturacion,@CursorIdImpuestoISR,@CursorImporteISR)
			END
		END
		ELSE
		BEGIN
			UPDATE ProFacturasConceptosFacturacion SET
				IdConceptoFacturacion = @CursorIdConceptoFacturacion,
				Cantidad = @CursorCantidad,
				PrecioUnitario = @CursorPrecio_Unitario,
				Importe = @CursorImporte,
				TrasladaImpuesto = @CursorTraslada_IVA,
				RetieneImpuesto = @CursorRetiene_IVA,
				Observaciones = @CursorObservaciones,
				ConceptoViaje = @CursorConceptoViaje,
				UnidadMedida = @CursorUnidad_Medida,
				IncluirObservacionesXML = @CursorIncluirObservacionesXML,
				ClaveSATProducto = @CursorClaveSATProducto,
				ClaveSATUnidad = @CursorClaveSATUnidad,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor,
				Descuento = @CursorDescuento,
				NoIdentificacion = @CursorNoIdentificacion
			WHERE IdFacturaConceptoFacturacion = @CursorIdFacturaConceptoFacturacion

			/*SE GUARDA LA DISTRIBUCION DEL CONCEPTO DE FACTURACION*/
			INSERT INTO ProFacturasConceptosFacturacionDistribucion(IdFacturaConceptoFacturacion,IdUnidad,ImporteDistribuido)
			SELECT
			 IdFacturaConceptoFacturacion
			,IdUnidad 
			,ImporteDistribuido
			FROM @VarConceptosFacturacionDistribucion WHERE IdFacturaConceptoFacturacion = @CursorIdFacturaConceptoFacturacion

			DELETE FROM ProFacturasConceptosFacturacionImpuestos WHERE IdFacturaConceptoFacturacion = @CursorIdFacturaConceptoFacturacion

			DECLARE @IdFacturaConceptoFacturacionImpuesto int

			print @CursorIdImpuestoTrasladado
			IF @CursorIdImpuestoTrasladado > 0 
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @CursorIdFacturaConceptoFacturacion,@CursorIdImpuestoTrasladado,@CursorImporteTrasladado )
			END

			PRINT @CursorIdImpuestoRetenido
			IF @CursorIdImpuestoRetenido > 0
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @CursorIdFacturaConceptoFacturacion,@CursorIdImpuestoRetenido,@CursorImporteRetenido )
			END

			IF @CursorIdImpuestoIEPS > 0
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @CursorIdFacturaConceptoFacturacion,@CursorIdImpuestoIEPS,@CursorImporteIEPS)
			END

			IF @CursorIdImpuestoISR > 0
			BEGIN
				INSERT INTO ProFacturasConceptosFacturacionImpuestos(IdFacturaConceptoFacturacion,IdImpuesto,Importe)
				VALUES( @CursorIdFacturaConceptoFacturacion,@CursorIdImpuestoISR,@CursorImporteISR)
			END

			SET @IdFacturaConceptoFacturacionImpuesto = ( SELECT COUNT(*) FROM ProFacturasConceptosFacturacionImpuestos)
		END


		FETCH NEXT FROM ProFacturasConceptosFacturacionCursor
		INTO @CursorIdFacturaConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorCantidad,@CursorPrecio_Unitario,@CursorImporte,@CursorTraslada_IVA,
		@CursorRetiene_IVA,@CursorObservaciones,@CursorUnidad_Medida,@CursorConceptoViaje,@CursorIncluirObservacionesXML,@CursorClaveSATProducto,@CursorClaveSATUnidad,@CursorDescuento,
		@CursorIdImpuestoTrasladado,@CursorImporteTrasladado,@CursorIdImpuestoRetenido,@CursorImporteRetenido,@CursorIdImpuestoIEPS,@CursorImporteIEPS,@CursorIdImpuestoISR,@CursorImporteISR,@CursorNoIdentificacion
	END

	CLOSE ProFacturasConceptosFacturacionCursor
	DEALLOCATE ProFacturasConceptosFacturacionCursor
	

	DELETE FROM ProFacturasConceptosFacturacion WHERE IdFactura = @IdFactura AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	IF (SELECT ISNULL(SUM(Importe),0) FROM ProFacturasConceptosFacturacion WHERE IdFactura = @IdFactura) <> @SubTotal
	RAISERROR(N'La suma de los importes de los conceptos de facturación no son iguales al subtotal',
		16,
		1
		)	

	----SECCION PARA AGREGAR LOS IMPUESTOS
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasImpuestos

	SELECT COL_IdFacturaImpuesto,COL_IdImpuesto,COL_Importe,COL_Porcentaje
	INTO #TempProFacturasImpuestos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProFacturasImpuestos',2) 
	WITH (COL_IdFacturaImpuesto int,COL_IdImpuesto int,COL_Importe money,COL_Porcentaje decimal(15,4))

	EXEC sp_xml_removedocument @docHandle
	
	DECLARE ProFacturasImpuestosCursor CURSOR LOCAL FOR
	SELECT * FROM #TempProFacturasImpuestos

	OPEN ProFacturasImpuestosCursor
	FETCH NEXT FROM ProFacturasImpuestosCursor
	INTO @CursorIdFacturaImpuesto,@CursorIdImpuesto,@CursorImporte,@CursorPorcentaje
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @CursorIdFacturaImpuesto = 0
			INSERT INTO ProFacturasImpuestos(IdFactura,IdImpuesto,Importe,CreadoEl,CreadoPor,Porcentaje)
			VALUES(@IdFactura,@CursorIdImpuesto,@CursorImporte,@ModificadoEl,@ModificadoPor,@CursorPorcentaje)
		ELSE
			UPDATE ProFacturasImpuestos SET
				IdImpuesto = @CursorIdImpuesto,
				Importe = @CursorImporte,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor,
				Porcentaje = @CursorPorcentaje
			WHERE IdFacturaImpuesto = @CursorIdFacturaImpuesto
	
		FETCH NEXT FROM ProFacturasImpuestosCursor
		INTO @CursorIdFacturaImpuesto,@CursorIdImpuesto,@CursorImporte,@CursorPorcentaje
	END

	CLOSE ProFacturasImpuestosCursor
	DEALLOCATE ProFacturasImpuestosCursor
	
	SET @TipoFactura = (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura)
	
	DELETE FROM ProFacturasImpuestos WHERE IdFactura = @IdFactura AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL OR (Importe = 0 AND @TipoFactura = 7 AND IdImpuesto NOT IN(1,4))) AND CreadoEl <> @ModificadoEl
	
	IF @IdAddenda > 0
	BEGIN
		/*Solicitud 1734 Validacion donde si no existe una addenda ligada a la factura crea el registro en caso contrario lo modifica*/
		IF NOT EXISTS (SELECT IdFactura FROM ProFacturasAddendasCamposAdicionales WHERE IdFactura = @IdFactura)
		BEGIN
			INSERT INTO ProFacturasAddendasCamposAdicionales(Campo1,Campo2,Campo3,Campo4,Campo5,Campo6,Campo7,Campo8,Campo9,Campo10,IdAddenda,IdFactura,CreadoEl,CreadoPor)
			VALUES(@Campo1,@Campo2,@Campo3,@Campo4,@Campo5,@Campo6,@Campo7,@Campo8,@Campo9,@Campo10,@IdAddenda,@IdFactura,@ModificadoEl,@ModificadoPor)
		END
		ELSE
		BEGIN
			UPDATE ProFacturasAddendasCamposAdicionales SET
				Campo1 = @Campo1,
				Campo2 = @Campo2,
				Campo3 = @Campo3,
				Campo4 = @Campo4,
				Campo5 = @Campo5,
				Campo6 = @Campo6,
				Campo7 = @Campo7,
				Campo8 = @Campo8,
				Campo9 = @Campo9,
				Campo10 = @Campo10,
				IdAddenda = @IdAddenda
			WHERE IdFactura = @IdFactura --AND IdAddenda = @IdAddenda
		END
	END

	IF @dsProFacturasCamposAdicionales  IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturasCamposAdicionales 
		
		SELECT ATT_NombreCampo,ATT_ValorCampo,ATT_IdFacturaCampoAdicional
		INTO #TempProFacturasCamposAdicionales
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturasCamposAdicionales',2) 
		WITH ( ATT_NombreCampo Varchar(50), ATT_ValorCampo varchar( 150 ),ATT_IdFacturaCampoAdicional int )
		
		EXEC sp_xml_removedocument @docHandle
		
		UPDATE ProFacturasCamposAdicionales
		SET	ProFacturasCamposAdicionales.IdFactura = @IdFactura,
				ProFacturasCamposAdicionales.NombreCampo = #TempProFacturasCamposAdicionales.ATT_NombreCampo,
				ProFacturasCamposAdicionales.ValorCampo = #TempProFacturasCamposAdicionales.ATT_ValorCampo
		FROM ProFacturasCamposAdicionales INNER JOIN #TempProFacturasCamposAdicionales
		ON   ProFacturasCamposAdicionales.IdFacturaCampoAdicional = #TempProFacturasCamposAdicionales.ATT_IdFacturaCampoAdicional 

		DELETE FROM ProFacturasCamposAdicionales WHERE IdFactura = @IdFactura AND IdFacturaCampoAdicional    NOT IN(SELECT ATT_IdFacturaCampoAdicional FROM #TempProFacturasCamposAdicionales WHERE ATT_IdFacturaCampoAdicional <> 0)
		
		INSERT INTO ProFacturasCamposAdicionales( IdFactura, NombreCampo, ValorCampo )
		SELECT @IdFactura,ATT_NombreCampo,ATT_ValorCampo
		FROM #TempProFacturasCamposAdicionales
		WHERE ATT_IdFacturaCampoAdicional = 0	
	END
	ELSE
	BEGIN
		DELETE FROM ProFacturasCamposAdicionales WHERE IdFactura = @IdFactura
	END
	-----------------------SEccion de complementos----------------------------------------------

		IF @dsComplementos IS NOT NULL
		BEGIN	
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsComplementos
		
		SELECT ATT_IdComplemento,ATT_Valor1,ATT_Valor2, ATT_Valor3
		INTO #TempProFacturasComplementos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProComplementos',2) 
		WITH (ATT_IdComplemento int,ATT_Valor1 varchar(250), ATT_Valor2 varchar(250), ATT_Valor3 varchar(250))

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE ProFacturasComplementosCursor CURSOR LOCAL FOR
		SELECT * FROM #TempProFacturasComplementos

		OPEN ProFacturasComplementosCursor
		FETCH NEXT FROM ProFacturasComplementosCursor
		INTO @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2, @CursorComplementoValor3
		
		WHILE @@FETCH_STATUS = 0 
		BEGIN
		SET @ComplementosCreadoEl = (SELECT CreadoEl From CatFacturasComplementosCamposAdicionales WHERE IdFactura = @IdFactura)
		SET @ComplementosCreadoPor = (SELECT CreadoPor From CatFacturasComplementosCamposAdicionales WHERE IdFactura = @IdFactura)

			DELETE FROM CatFacturasComplementosCamposAdicionales WHERE IdFactura = @IdFactura

			INSERT INTO CatFacturasComplementosCamposAdicionales(IdFactura, IdComplemento, Campo1, Campo2, Campo3, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
			VALUES(@IdFactura, @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2,@CursorComplementoValor3,@ComplementosCreadoEl,@ComplementosCreadoPor, @ModificadoEl, @ModificadoPor )
		
			FETCH NEXT FROM ProFacturasComplementosCursor
			INTO @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2, @CursorComplementoValor3
		END
		CLOSE ProFacturasComplementosCursor
		DEALLOCATE ProFacturasComplementosCursor
	END
	ELSE
	BEGIN
		DELETE FROM CatClientesComplementosCamposAdicionales WHERE IdCliente = @IdCliente 
	END

	-------------------------------------------------------------------------------------------


	--actualiza el saldo del cliente 
	IF @IdMoneda = 1 OR @IdMoneda = 3
		UPDATE CatClientes SET SaldoCredito = SaldoCredito + @Total WHERE IdCliente = @IdCliente
	ELSE
		UPDATE CatClientes SET SaldoCreditoDLLS = SaldoCreditoDLLS + @Total WHERE IdCliente = @IdCliente
	
	IF @PermitirFacturarRebaseCredito = 0
	BEGIN	
		IF (SELECT PendFacturar+SaldoCredito FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT Credito FROM CatClientes WHERE IdCliente = @IdCliente)
			RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
				16,
				1
				)

		IF (SELECT PendFacturarDLLS+SaldoCreditoDLLS FROM CatClientes WHERE IdCliente = @IdCliente) > (SELECT CreditoDLLS FROM CatClientes WHERE IdCliente = @IdCliente)
			RAISERROR(N'Sobrepasa el límite de crédito asignado al cliente, Reportar al responsable de crédito y cobranza o incremente el crédito, si cuenta con permisos.',
				16,
				1
				)		
	END	

	--RAISERROR(N'Error provocado por desarrollo para pruebas',
	--	16,
	--	1
	--	)	
	
	--se elimina el movimiento cobranza para que se vuelva agregar
	DELETE FROM ProCobranza WHERE IdFactura = @IdFactura AND IdConceptoCobranza = 1
	
	-- ejecuta store procedure para agregare el movimiento de cobranza "FACTURA = 1 IdConceptoCobranza"
	EXEC @return_value = usp_ProCobranzaRegistrar 1,@IdCliente,@IdFactura,@FechaHora,@Total,@TipoCambio,@IdMoneda,'',@IdSucursal,0,@ModificadoPor,@ModificadoEl,@IdPeticion

	IF @return_value <> 0
	RAISERROR(N'Ocurrió un error al agregar el movimiento de cobranza',
		16,
		1
		)	
		

	Declare @IdProceso int = 0, @IdProcesoPadre int = 0 ,@TipoCambioDia  money = 0
	SET @TipoCambioDia = (SELECT TOP 1 TipoCambio FROM CatTiposCambio WHERE Cast(Fecha AS DATE) = cast(@FechaHora AS DATE))
	
	IF @TipoCambio <> isnull(@TipoCambioDia,0)
	BEGIN

		SET @IdProcesoPadre = (SELECT
							CASE @TipoFactura
							WHEN 1 THEN '300100'	/*POR CONCEPTO*/
							WHEN 2 THEN '300200'	/*POR VIAJE*/	
							WHEN 3 THEN '300300'	/*POR VIAJE PARCIAL*/
							WHEN 4 THEN '300400'	/*POR PESO DESCARGA*/
							WHEN 5 THEN '300500'	/*POR KILOMETROS*/
							--WHEN 6 THEN '300600'	/*POR RECORRIDO*/
							WHEN 7 THEN '300700'	/*GENERAL*/
							WHEN 8 THEN '300800'	/*POR COMBUSTIBLE*/
							--WHEN 9 THEN ''	/*POR ANTICIPO*/
							WHEN 10 THEN '300900'	/*POR RELACION PEMEX*/
							END
							)
		SET @IdProceso = (SELECT
							CASE @TipoFactura
							WHEN 1 THEN '300102'	/*POR CONCEPTO*/
							WHEN 2 THEN '300214'	/*POR VIAJE*/	
							WHEN 3 THEN '300313'	/*POR VIAJE PARCIAL*/
							WHEN 4 THEN '300413'	/*POR PESO DESCARGA*/
							WHEN 5 THEN '300513'	/*POR KILOMETROS*/
							--WHEN 6 THEN '300702'	/*POR RECORRIDO*/
							WHEN 7 THEN '300702'	/*GENERAL*/
							WHEN 8 THEN '300802'	/*POR COMBUSTIBLE*/
							--WHEN 9 THEN ''	/*POR ANTICIPO*/
							WHEN 10 THEN '300914'	/*POR RELACION PEMEX*/
							END
							)
		EXEC @return_value = usp_SisBitacoraTipoCambioRegistrar @ModificadoEl,@ModificadoPor, @IdFactura,@IdProceso,@IdProcesoPadre ,@TipoCambioDia ,@TipoCambio ,@IdPeticion 

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al registrar la bitácora de tipo de cambio.',
			16,
			1
			)

	END
		
	COMMIT
END TRY
BEGIN CATCH

	IF (SELECT CURSOR_STATUS('LOCAL','ProFacturasConceptosFacturacionCursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','ProFacturasConceptosFacturacionCursor')) > -1
		BEGIN
			CLOSE ProFacturasConceptosFacturacionCursor
		END
		DEALLOCATE ProFacturasConceptosFacturacionCursor
	END
		
	IF (SELECT CURSOR_STATUS('LOCAL','ProFacturasImpuestosCursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','ProFacturasImpuestosCursor')) > -1
		BEGIN
			CLOSE ProFacturasImpuestosCursor
		END
		DEALLOCATE ProFacturasImpuestosCursor
	END	
	
	IF (SELECT CURSOR_STATUS('LOCAL','ProFacturasComplementosCursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','ProFacturasComplementosCursor')) > -1
		BEGIN
			CLOSE ProFacturasComplementosCursor
		END
		DEALLOCATE ProFacturasComplementosCursor
	END
	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

