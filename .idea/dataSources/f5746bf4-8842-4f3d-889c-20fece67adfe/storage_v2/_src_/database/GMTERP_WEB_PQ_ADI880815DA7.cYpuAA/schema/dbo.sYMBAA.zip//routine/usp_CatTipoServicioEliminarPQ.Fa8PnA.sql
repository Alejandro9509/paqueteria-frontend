
CREATE PROCEDURE [dbo].[usp_CatTipoServicioEliminarPQ]
	@IdTipoServicio INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdTipoServicio,0) <= 0 
			RAISERROR(N'Identificador del tipo de servicio es un campo requerido', 16, 1)
		
		DELETE FROM CatTipoServicio
		WHERE IdTipoServicio = @IdTipoServicio
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

