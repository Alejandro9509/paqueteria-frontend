CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosBancariosAgregar]
@Codigo int,	  
@MovimientoBancario	varchar(50),	  
@TipoMovimiento	tinyint,	
@CreadoEl	datetime,	
@CreadoPor	int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de movimiento bancario es un campo requerido',
			16,
			1
			)
				
	IF ISNULL(@TipoMovimiento,'')= ''
		RAISERROR(N'La descripción de movimiento bancario es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@TipoMovimiento,0)= 0
		RAISERROR(N'El tipo de movimiento es un campo requerido',
			16,
			1
			)
			
	INSERT INTO CatTiposMovimientosBancarios (Codigo,MovimientoBancario,TipoMovimiento,CreadoPor,CreadoEl)
	VALUES (@Codigo,@MovimientoBancario,@TipoMovimiento,@CreadoPor,@CreadoEl)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

