
CREATE PROCEDURE [dbo].[usp_CatZonasTarifasCPGetByIdZonaPQ](
	@IdZona int
)
AS
BEGIN
	BEGIN TRANSACTION
		SELECT 
			*
		FROM CatZonasTarifasCPPQ cz
		JOIN CatCodigosPostales c on cz.IdCP = c.IdCodigoPostal
		WHERE IdZona = @IdZona

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

