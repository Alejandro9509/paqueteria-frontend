	CREATE PROCEDURE [dbo].[usp_SisDerechoEliminarPQ](@IdUsuario int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdUsuario, 0) <= 0 begin
			RAISERROR(N'El Identificador de usuario es un campo requerido', 16, 1);
			return;
			end
		
		DELETE from SisDerechoPQ
		where IdUsuario = @IdUsuario

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
    go

