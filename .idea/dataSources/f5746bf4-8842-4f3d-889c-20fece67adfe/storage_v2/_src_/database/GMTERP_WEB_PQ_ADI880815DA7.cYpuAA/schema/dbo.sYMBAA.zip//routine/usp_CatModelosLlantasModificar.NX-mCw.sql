

CREATE PROCEDURE [dbo].[usp_CatModelosLlantasModificar]
@IdModeloLlanta	int,
@Codigo	int,	
@Descripcion	varchar(50),	
@Activo bit,
@ProfundidadOriginal decimal(10,2),
@ProfundidadMinima decimal(10,2),
@PresionMaxima decimal(10,2),
@PresionMimina decimal(10,2),
@IdMarca int,
@IdMedida int,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdModeloLlanta,0)= 0
	RAISERROR(N'El identificador del modelo es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del modelo es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatModelosLlantas WHERE Codigo = @Codigo AND IdModeloLlanta <> @IdModeloLlanta )
		RAISERROR(N'El código del modelo ya existe',
			16,
			1
			)	
				
	IF ISNULL(@Descripcion,'')= ''
		RAISERROR(N'El descripción del modelo es un campo requerido',
			16,
			1
			)
	IF ISNULL(@IdMarca,0)= 0
		RAISERROR(N'La Marca es un campo requerido',
			16,
			1
			)
	IF ISNULL(@IdMedida,0)= 0
		RAISERROR(N'La Medida es un campo requerido',
			16,
			1
			)
	
	UPDATE CatModelosLlantas  SET
		Codigo= @Codigo,
		Descripcion= @Descripcion,
		Activo= @Activo,
		ProfundidadOriginal=@ProfundidadOriginal,
		ProfundidadMinima=@ProfundidadMinima,
		PresionMaxima=@PresionMaxima,
		PresionMimina=@PresionMimina,
		IdMarcaLlanta = @IdMarca,
		IdMedidaLlanta = @IdMedida,
		ModificadoEl= @ModificadoEl,
		ModificadoPor= @ModificadoPor
	WHERE IdModeloLlanta	 = @IdModeloLlanta	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

