
CREATE PROCEDURE [dbo].[usp_CatCuentasContablesModificarNombre]
	@IdCuentaContable int,
	@Nombre varchar(150),
	@ModificadoPor int,
	@ModificadoEl datetime,	
	@IdPeticion varchar(100)
AS
/*
	SOLICITUD:		002197
					El usp desactiva el TRIGGER de catcuentascontables para poder modificar el nombre de la cuenta contable.
	MODIFICADO EL:	2020-06-18
	MODIFICADO POR:	Abril CG
*/
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdCuentaContable = 0
		RAISERROR(N'El Identificador de la cuenta contable es un campo requerido.',
			16,
			1
			)
	
	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El Nombre de la cuenta contable es un campo requerido.',
			16,
			1
			)


	ALTER TABLE	CatCuentasContables DISABLE TRIGGER trg_CatCuentasContables

	UPDATE CatCuentasContables SET 
	Nombre = @Nombre,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl
	WHERE IdCuentaContable = @IdCuentaContable	

	ALTER TABLE	CatCuentasContables ENABLE TRIGGER trg_CatCuentasContables	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

