
CREATE PROCEDURE [dbo].[usp_CatOperadoresAgregarNotificaciones]
	@IdPeticion varchar(100),
	@FechaHoraUTC datetime,
	@Mensaje nvarchar(max),
	@Proceso tinyint,
	@Aplicacion int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsOperadores XML,
	@Parametros nvarchar(max)
	
	/*************************************************************************************************************************************
	@IdPeticion varchar(100),
	@FechaHoraUTC datetime,
	@Mensaje nvarchar(max),
	@Proceso tinyint,
	@Aplicacion int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsOperadores XML

	Creado por:  Luis Edgar Ramos Cadena
	Fecha de Creacion: 19/03/2021
	Versión  Versión 8.0.59.10
	Solicitud 3939

	
	Se creo para grabar las notificaciones de las app moviles
	***************************************/
AS
DECLARE @TemporalXML TABLE
(	
IdOperador int
)
Declare @IdAplicacionMovil int

SET @IdAplicacionMovil = (SELECT IdAplicacionMovil FROM CatAplicacionesMoviles WHERE Aplicacion = @Aplicacion)


BEGIN TRY
	BEGIN TRANSACTION

	INSERT INTO @TemporalXML (IdOperador)
	Select  
	 IdOperador = Node.Data.value('(ATT_IdOperador)[1]', 'int')
	FROM   @dsOperadores.nodes('/WINDEV_TABLE/LOOP_Operadores') Node(Data) 

	--Se elimina la informacion anterior para actualizar la nueva

	INSERT INTO CatOperadoresNotificacionesMovil(IdOperador,IdAplicacionMovil,FechaHora,Proceso,Descripcion,Atendido,CreadoPor,CreadoEl,Parametros)
	SELECT
	IdOperador,
	@IdAplicacionMovil,
	@FechaHoraUTC,
	@Proceso,
	@Mensaje,
	0,
	@CreadoPor,
	@CreadoEl,
	@Parametros
	FROM @TemporalXML

COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

