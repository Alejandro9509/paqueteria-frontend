CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosBancariosModificar]
	@IdTipoMovimientoBancario int,
	@Codigo int,	  
	@MovimientoBancario	varchar(50),	  
	@TipoMovimiento	tinyint,	
	@ModificadoEl	datetime,	
	@ModificadoPor	int,	
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF (Select DefinidoPorSistema from CatTiposMovimientosBancarios where IdTipoMovimientoBancario=@IdTipoMovimientoBancario) =  1
		RAISERROR(N'Este tipo de movimiento esta definido por el sistema, no es posible modificar',
			16,
			1
			)

	IF ISNULL(@IdTipoMovimientoBancario,0)= 0
		RAISERROR(N'Identificador de movimiento bancario es un campo requerido',
			16,
			1
			)
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de movimiento bancario es un campo requerido',
			16,
			1
			)		
	
	IF ISNULL(@TipoMovimiento,'')= ''
		RAISERROR(N'La descripción de movimiento bancario es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@TipoMovimiento,0)= 0
		RAISERROR(N'El tipo de movimiento es un campo requerido',
			16,
			1
			)
				
	UPDATE CatTiposMovimientosBancarios  SET 
			Codigo = @Codigo,
			MovimientoBancario = @MovimientoBancario,
			TipoMovimiento = @TipoMovimiento,
			ModificadoPor = @ModificadoPor,
			ModificadoEl = @ModificadoEl
	WHERE 	IdTipoMovimientoBancario  =@IdTipoMovimientoBancario 
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

