CREATE PROCEDURE [dbo].[usp_CatConvenioEliminarPQ]
	@IdConvenio INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdConvenio,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de la Tarifa es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		DELETE FROM CatConveniosPQ
		WHERE IdConvenio = @IdConvenio

        delete from CatTarifaConvenioConceptosPQ where IdTarifaConvenio in (select tc.IdTarifaConvenio from CatTarifaConvenioPQ tc where IdConvenio = @IdConvenio);--1
        delete from CatTarifaConvenioPQ where IdConvenio = @IdConvenio;--2

        delete from CatZonasTarifasConvenioConceptosPQ where IdZonaConvenio in (select tc.IdZonaConvenio from CatZonasTarifasConvenioPQ tc where IdConvenio = @IdConvenio);--1
        delete from CatZonasTarifasConvenioPQ where IdConvenio = @IdConvenio;--2
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END
go

