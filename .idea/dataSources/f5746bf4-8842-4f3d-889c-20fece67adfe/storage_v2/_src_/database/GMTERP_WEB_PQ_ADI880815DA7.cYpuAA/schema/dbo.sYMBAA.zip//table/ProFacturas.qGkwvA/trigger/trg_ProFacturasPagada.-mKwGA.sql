CREATE TRIGGER [dbo].[trg_ProFacturasPagada]
   ON  [dbo].[ProFacturas]
   AFTER UPDATE
AS 
BEGIN
    DECLARE @IdGuia int
	DECLARE @Estatus tinyint
  

	 set @IdGuia = (select pv.IdGuia from ProViajesFacturas pvf 
 inner join ProFacturas pf on pf.IdFactura=pvf.IdFactura
 inner join ProViajes pv on pv.IdViaje=pvf.IdViaje
 where pf.IdFactura=(SELECT IdFactura FROM INSERTED) and pv.IdTipoViaje in (select IdTipoViaje from CatTiposViajes where TipoViaje like '%CONSOLIDADO%'))

 set @Estatus = (select pf.Estatus from ProViajesFacturas pvf 
 inner join ProFacturas pf on pf.IdFactura=pvf.IdFactura
 inner join ProViajes pv on pv.IdViaje=pvf.IdViaje
 where pf.IdFactura= (SELECT IdFactura FROM INSERTED) and pv.IdTipoViaje in (select IdTipoViaje from CatTiposViajes where TipoViaje like '%CONSOLIDADO%'))
    
	IF @Estatus = 1
		BEGIN
		 update ProGuiaPQ set pagado=1  where IdGuia=@IdGuia;
		END

END
go

disable trigger trg_ProFacturasPagada on ProFacturas
go

