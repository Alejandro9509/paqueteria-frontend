CREATE PROCEDURE [dbo].[usp_CatTarifaConvenioProductosAgregarPQ](
	@IdTarifaConvenio int,
	@IdProducto int
    ,@Importe money
    ,@IdImpuestoTraslada int
    ,@ImporteIva int
    ,@IdImpuestoRetiene int
    ,@ImporteRetiene int
    )
	 
AS
BEGIN
	
	BEGIN TRANSACTION
--BEGIN TRY
		IF ISNULL(@IdTarifaConvenio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Tarifa es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@IdProducto, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Producto es un campo requerido*FIN*', 16, 1);
			return;
			end
 			
		INSERT INTO CatProductosTarifaConvenioPQ(
		IdTarifaConvenio,
		IdProducto
        ,Importe
        ,IdImpuestoTraslada
        ,ImporteIva
        ,IdImpuestoRetiene
        ,ImporteRetiene
        )
		VALUES (
		@IdTarifaConvenio,
		@IdProducto
       ,@Importe
       ,@IdImpuestoTraslada
       ,@ImporteIva
       ,@IdImpuestoRetiene
       ,@ImporteRetiene
       )
	
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

