CREATE PROCEDURE [dbo].[usp_ProLiquidacionesPagoPropietariosPagarGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProLiquidacionesPagoPropietariosPagar
go

