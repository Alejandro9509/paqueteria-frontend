
CREATE PROCEDURE [dbo].[usp_ProLlantasImportar]
@XML_Llantas xml = null,
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100)

AS
DECLARE	
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	/*SE VALIDA QUE LA TABLA TEMPORAL NO EXISTA*/
	IF OBJECT_ID('tempdb..#Llantas') IS NOT NULL
	BEGIN
		DROP TABLE #Llantas;
	END

	CREATE TABLE #Llantas(
	Registro int,
	NumeroEconomico varchar(20),
	ProfundidadOriginal decimal (10, 2),
	ProfundidadMinima  decimal (10, 2),
	ProfundidadActual  decimal (10, 2),
	PresionMinima  decimal (10, 2),
	PresionOriginal  decimal (10, 2),
	PresionActual  decimal (10, 2),
	DisponibleDesde datetime,
	VidaUtil int,
	CostoLlantaMN money,
	CostoLlantaDlls money,
	IdModeloLlanta int,
	IdMarcaLlanta int,
	IdMedidaLlanta int,
	IdTipoLlanta int,
	IdEstatuLlanta int);

	/*SE VALIDA QUE LA TABLA TEMPORAL NO EXISTA*/
	IF OBJECT_ID('tempdb..#Errores') IS NOT NULL
	BEGIN
		DROP TABLE #Errores;
	END

	CREATE TABLE #Errores(
	Registro int,
	Columna int,
	Detalle varchar(MAX) );


	IF @XML_Llantas IS NOT NULL
	BEGIN

		INSERT INTO #Llantas(Registro,NumeroEconomico ,ProfundidadOriginal ,ProfundidadMinima  ,ProfundidadActual ,PresionMinima  ,PresionOriginal  
		,PresionActual  ,DisponibleDesde ,VidaUtil ,CostoLlantaMN ,	CostoLlantaDlls ,IdModeloLlanta ,IdMarcaLlanta ,IdMedidaLlanta ,IdTipoLlanta ,IdEstatuLlanta)
		SELECT  Registro = T.Item.value('Registro[1]', 'int')
			   ,NumeroEconomico = replace(T.Item.value('NumeroEconomico[1]', 'varchar(20)'),'', 'xx') -- T.Item.value('NumeroEconomico[1]', 'varchar(20)')
			   ,ProfundidadOriginal = T.Item.value('ProfundidadOriginal[1]', 'decimal (10, 2)')
			   ,ProfundidadMinima = T.Item.value('ProfundidadMinima[1]', 'decimal (10, 2)')
			   ,ProfundidadActual = T.Item.value('ProfundidadActual[1]', 'decimal (10, 2)')
			   ,PresionMinima = T.Item.value('PresionMinima[1]', 'decimal (10, 2)')
			   ,PresionOriginal = T.Item.value('PresionOriginal[1]', 'decimal (10, 2)')
			   ,PresionActual =  T.Item.value('PresionActual[1]', 'decimal (10, 2)')
			   ,DisponibleDesde =  T.Item.value('DisponibleDesde[1]', 'datetime')
			   ,VidaUtil =  T.Item.value('VidaUtil[1]', 'int')
			   ,CostoLlantaMN =  T.Item.value('CostoLlantaMN[1]', 'money')
			   ,CostoLlantaDlls =  T.Item.value('CostoLlantaDlls[1]', 'money')
			   ,IdModelo =  T.Item.value('IdModelo[1]', 'int')
			   ,IdMarcaLlanta =  T.Item.value('IdMarcaLlanta[1]', 'int')
			   ,IdMedidaLlanta =  T.Item.value('IdMedidaLlanta[1]', 'int')
			   ,IdTipoLlanta =  T.Item.value('IdTipoLlanta[1]', 'int')
			   ,IdEstatusLlanta =  T.Item.value('IdEstatusLlanta[1]', 'int')
		FROM   @XML_Llantas.nodes('Llantas/Llanta') AS T(Item);

	END

	/*
		Se guardan los registros que generaron error
	*/
	INSERT INTO  #Errores(Registro ,Columna ,Detalle)
	SELECT Registro,Columna,Detalle FROM (
		SELECT
		 Registro	--Renglon Excel
		,Columna ='1'		-- A - Columna Excel
		,Detalle = 'El Número Económico de la llanta ya existe.'
		FROM  #Llantas
		WHERE NumeroEconomico IN (
								SELECT pl.NumeroEconomico FROM ProLlantas pl
								WHERE pl.NumeroEconomico IN (select NumeroEconomico FROM #Llantas) )
		UNION ALL
		SELECT
		 Registro	--Renglon Excel
		,Columna = '1'		-- A - Columna Excel
		,Detalle = 'El Número Económico de la llanta es un campo requerido.'
		FROM  #Llantas WHERE NumeroEconomico IN ('',NULL)
		UNION ALL
		SELECT 
		 Registro			--Renglon Excel
		,Columna = '16'		-- P - Columna Excel
		,Detalle = 'Identificador de Modelo es un campo requerido.' 
		FROM #Llantas WHERE IdModeloLlanta NOT IN (SELECT IdModeloLlanta FROM CatModelosLlantas)
		UNION ALL
		SELECT 
		 Registro			--Renglon Excel
		,Columna = '17'		-- Q - Columna Excel
		,Detalle = 'Identificador de Marca es un campo requerido.' 
		FROM #Llantas WHERE IdMarcaLlanta NOT IN (SELECT IdMarcaLlanta FROM CatMarcasLlantas)
		UNION ALL
		SELECT 
		 Registro			--Renglon Excel
		,Columna = '18'		-- R - Columna Excel
		,Detalle = 'Identificador de Medida es un campo requerido.' 
		FROM #Llantas
		WHERE IdMedidaLlanta NOT IN (SELECT IdMedidaLLanta FROM CatMedidasLlantas)
		UNION ALL
		SELECT 
		 Registro			--Renglon Excel
		,Columna = '19'		-- S - Columna Excel
		,Detalle = 'Identificador de Tipo Llanta es un campo requerido.' 
		FROM #Llantas
		WHERE IdTipoLlanta NOT IN (SELECT IdTipoLlanta FROM CatTiposLlantas)
		UNION ALL
		SELECT 
		 Registro			--Renglon Excel
		,Columna = '20'		-- T - Columna Excel
		,Detalle = 'Identificador de Estatus Llanta es un campo requerido.' 
		FROM #Llantas
		WHERE IdEstatuLlanta NOT IN (SELECT IdEstatuLlanta FROM CatEstatusLlantas)

	)Errores;

	/*
		Se eliminan los registros que generaron Error - #Llantas
	*/
	DELETE FROM #Llantas WHERE Registro IN (SELECT Registro FROM #Errores)

	/*
		Se insertan los registros que cumplen con los criterios del proceso registrar llantas
		en ProLlantas
	*/
	INSERT INTO ProLlantas (NumeroEconomico
	,IdModeloLlanta
	,IdMarcaLlanta
	,IdMedidaLlanta
	,IdTipoLlanta
	,ProfundidadOriginal
	,ProfundidadMinima
	,PresionMaxima
	,PresionMinima
	,ProfundidadActual
	,PresionActual
	,IdEstatuLlanta
	,DisponibleDesde
	,CreadoPor
	,CreadoEl
	,CostoLlanta
	,VidaUtil
	,CostoLlantaDlls
	,TipoCambio
	,FechaRegistro)
	SELECT
	NumeroEconomico
	,IdModeloLlanta
	,IdMarcaLlanta
	,IdMedidaLlanta
	,IdTipoLlanta
	,ProfundidadOriginal
	,ProfundidadMinima
	,PresionOriginal
	,PresionMinima
	,ProfundidadActual
	,PresionActual
	,IdEstatuLlanta
	,DisponibleDesde
	,@CreadoPor
	,@CreadoEl
	,CostoLlantaMN
	,VidaUtil
	,CostoLlantaDlls
	,0
	,GetDate()
	FROM
	#Llantas
	
	/*
		Se guarda en #Errores la cantidad de llantas registradas
	*/
	INSERT INTO  #Errores(Registro ,Columna ,Detalle)
	SELECT 0,0,(SELECT COUNT(IdModeloLlanta) FROM #Llantas)

	/*Se retornan a la APP los errores detectados*/
	SELECT * FROM #Errores ORDER BY Registro,Columna;

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
	SELECT Registro = -1,Columna=-1,Detalle='Ocurrio un error al registrar, por favor comunicarse con soporte.'
END CATCH
go

