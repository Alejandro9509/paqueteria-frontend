CREATE PROCEDURE [dbo].[usp_ProLiquidacionesGetDesdeHasta]

AS

SELECT ISNULL(MAX(Folio),0) AS Hasta,ISNULL(MIN(Folio),0) AS Desde FROM ProLiquidaciones
go

