CREATE PROCEDURE [dbo].[usp_CatTarifasGetByOrigenDestinoTipoPQ]
@IdEmbarque int
,@IdTipoTarifa int
AS
BEGIN TRY
    BEGIN TRANSACTION
        DECLARE @tempConceptos TABLE
                               (
                                   id                       int PRIMARY KEY IDENTITY (1,1),
                                   m_nIdPadre               int,
                                   m_bEsTarifaZona          bit,
                                   m_nIdConceptoFacturacion int,
                                   m_sConcepto              varchar(30),
                                   m_cImporte               money,
                                   m_nIdImpuestoTraslada    int,
                                   m_cImporteIva            money,
                                   m_nIdImpuestoRetiene     int,
                                   m_cImporteRetiene        money,
                                   m_nIdTipoCalculo         int,
                                   m_cRangoMinimo           float,
                                   m_cRangoMaximo           float
                               )

        DECLARE @IdOrigen int = (select IdCiudadOrigen from ProEmbarquePQ WHERE IdEmbarque = @IdEmbarque);
        DECLARE @IdDestino int = (select IdCiudadDestino from ProEmbarquePQ WHERE IdEmbarque = @IdEmbarque);
        declare @IdCliente int = (select IdCliente from ProEmbarquePQ WHERE IdEmbarque = @IdEmbarque);
        declare @IdTarifaRangos int;
        DECLARE @IdTarifa int;
        declare @TarifaDeConvenio bit = 0;
        declare @FleteMinimo money = 0;
        declare @MontoMinimo money = 0;

        --Tarifa POR RANGOS
        IF @IdTipoTarifa = 2
            BEGIN
                Declare @IdRecoleccion int = (SELECT IdRecoleccion FROM ProEmbarquePQ WHERE IdEmbarque = @IdEmbarque);
                IF @IdRecoleccion > 0
                    BEGIN

                        declare @PesoKg float = 0;
                        declare @PesoVolumetrico float = 0;
                        declare @paquetesTotales int = 0;
                        --En esta ultima se almacena el tipo de peso que se usará para los calculos
                        declare @pesoFinal float = 0;

                        declare @ctdPaquete int; declare @pesoPaquete float; declare @largoPaquete float; declare @altoPaquete float; declare @anchoPaquete float;
                        declare cursor_productos_recoleccion CURSOR LOCAL
                            FOR select ed.Cantidad, ed.Peso, ed.Largo, ed.Alto, ed.Ancho FROM ProRecoleccionPaquetePQ ed where ed.IdRecoleccion = @IdRecoleccion;

                        OPEN cursor_productos_recoleccion;
                        FETCH NEXT FROM cursor_productos_recoleccion INTO @ctdPaquete, @pesoPaquete, @largoPaquete, @altoPaquete,@anchoPaquete;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                set @PesoKg += @pesoPaquete * @ctdPaquete;
                                set @PesoVolumetrico += (@largoPaquete * @altoPaquete * @anchoPaquete) * @ctdPaquete * 0.0005;
                                set @paquetesTotales += @ctdPaquete;

                                FETCH NEXT FROM cursor_productos_recoleccion INTO @ctdPaquete, @pesoPaquete, @largoPaquete, @altoPaquete,@anchoPaquete;
                            END;
                        CLOSE cursor_productos_recoleccion;
                        DEALLOCATE cursor_productos_recoleccion;
                        IF @PesoKg >= @PesoVolumetrico
                            begin
                                set @pesoFinal = @PesoKg;
                            end
                        IF @PesoKg < @PesoVolumetrico
                            begin
                                set @pesoFinal = @PesoVolumetrico;
                            end

                        print @pesoFinal;
                        declare @IdConceptoFacturacion int;
                        declare @Importe money = 0;
                        declare @IdImpuestoTraslada int;
                        declare @ImporteIva money = 0;
                        declare @IdImpuestoRetiene int;
                        declare @ImporteRetiene money = 0;
                        declare @IdTipoCalculo int;
                        declare @RangoMinimo int;
                        declare @RangoMaximo int;
                        declare @IdTipoMedida int;
                        declare @porcentajeTrasladaTempRecoleccion float;
                        declare @porcentajeRetieneTempRecoleccion float;

                        declare @IdTarifaZonaRecoleccion int = (Select IdZonaTarifa FROM ProRecoleccionPQ where IdRecoleccion = @IdRecoleccion);
                        declare @IdZonaTarifaConvenioRecoleccion int = (select CTCP.IdZonaConvenio
                                                                        from CatConveniosPQ C
                                                                                 join CatZonasTarifasConvenioPQ CTCP on C.IdConvenio = CTCP.IdConvenio
                                                                        WHERE C.IdCliente = @IdCliente
                                                                          and CTCP.IdZonaTarifa = @IdTarifaZonaRecoleccion);
                        /*Si esa zona está en un convenio para el cliente*/
                        if @IdZonaTarifaConvenioRecoleccion is not null
                            begin
                                SELECT @IdConceptoFacturacion = zt.IdConceptoFacturacion,
                                       @Importe = Importe,
                                       @IdImpuestoTraslada = IdImpuestoTraslada,
                                       @ImporteIva = ImporteIva,
                                       @IdImpuestoRetiene = IdImpuestoRetiene,
                                       @ImporteRetiene = ImporteRetiene,
                                       @IdTipoCalculo = IdTipoCalculo,
                                       @RangoMinimo = RangoMinimo,
                                       @RangoMaximo = RangoMaximo,
                                       @IdTipoMedida = IdTipoMedida,
                                       @porcentajeTrasladaTempRecoleccion = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                       @porcentajeRetieneTempRecoleccion = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                                FROM CatZonasTarifasConvenioConceptosPQ zt
                                         JOIN CatConceptosFacturacion cd ON cd.IdConceptoFacturacion = zt.IdConceptoFacturacion
                                WHERE zt.IdZonaConvenio = @IdZonaTarifaConvenioRecoleccion and cd.Codigo = 14
                                  AND zt.IdAgregadoDesde = 3
                                  AND zt.RangoMinimo <= (case when zt.IdTipoCalculo = 3 then @ctdPaquete else (case when IdTipoMedida = 2 then @pesoFinal/1000.00 else @pesoFinal end) end)
                                  AND zt.RangoMaximo >= (case when zt.IdTipoCalculo = 3 then @ctdPaquete else (case when IdTipoMedida = 2 then @pesoFinal/1000.00 else @pesoFinal end) end)
                            end
                        else
                            /*Si no esa zona no está en el convenio*/
                            begin
                                SELECT @IdConceptoFacturacion = zt.IdConceptoFacturacion,
                                       @Importe = Importe,
                                       @IdImpuestoTraslada = IdImpuestoTraslada,
                                       @ImporteIva = ImporteIva,
                                       @IdImpuestoRetiene = IdImpuestoRetiene,
                                       @ImporteRetiene = ImporteRetiene,
                                       @IdTipoCalculo = IdTipoCalculo,
                                       @RangoMinimo = RangoMinimo,
                                       @RangoMaximo = RangoMaximo,
                                       @IdTipoMedida = IdTipoMedida,
                                       @porcentajeTrasladaTempRecoleccion = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                       @porcentajeRetieneTempRecoleccion = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                                FROM CatZonasTarifasConceptosPQ zt
                                         JOIN CatConceptosFacturacion cd ON cd.IdConceptoFacturacion = zt.IdConceptoFacturacion
                                WHERE zt.IdZona = @IdTarifaZonaRecoleccion and cd.Codigo = 14
                                  AND zt.IdAgregadoDesde = 3
                                  AND zt.RangoMinimo <= (case when zt.IdTipoCalculo = 3 then @ctdPaquete else (case when IdTipoMedida = 2 then @pesoFinal/1000.00 else @pesoFinal end) end)
                                  AND zt.RangoMaximo >= (case when zt.IdTipoCalculo = 3 then @ctdPaquete else (case when IdTipoMedida = 2 then @pesoFinal/1000.00 else @pesoFinal end) end)
                            end


                        --Si el tipo de medida es KG y el tipo de calculo es Fijo
                        IF @IdTipoMedida = 1 AND @IdTipoCalculo = 1
                            BEGIN
                                SET @Importe = @Importe;
                            end
                        --Si el tipo de medida es KG y el tipo de calculo es Factor
                        IF @IdTipoMedida = 1 AND @IdTipoCalculo = 2
                            BEGIN
                                SET @Importe = (@Importe * (@pesoFinal/1000.00));
                                SET @ImporteIva = (@Importe * (@porcentajeTrasladaTempRecoleccion/100));
                                SET @ImporteRetiene = (@Importe * (@porcentajeRetieneTempRecoleccion/100));
                            end
                        --Si el tipo de medida es TONELADAS y el tipo de calculo es Fijo
                        IF @IdTipoMedida = 2 AND @IdTipoCalculo = 1
                            BEGIN
                                SET @Importe = @Importe;
                            end
                        --Si el tipo de medida es TONELADAS y el tipo de calculo es Factor
                        IF @IdTipoMedida = 2 AND @IdTipoCalculo = 2
                            BEGIN
                                SET @Importe = (@Importe * (@pesoFinal/1000.00));
                                SET @ImporteIva = (@Importe * (@porcentajeTrasladaTempRecoleccion/100));
                                SET @ImporteRetiene = (@Importe * (@porcentajeRetieneTempRecoleccion/100));
                            end
                        --Si el tipo de medida es PRODUCTO
                        IF @IdTipoMedida = 3
                            BEGIN
                                SET @Importe = @Importe;
                            end

                        SET @ImporteIva = (@Importe * ((select Porcentaje from CatImpuestos where IdImpuesto = @IdImpuestoTraslada)/ 100))
                        SET @ImporteRetiene = (@Importe * ((select Porcentaje from CatImpuestos where IdImpuesto = @IdImpuestoRetiene)/ 100))
                        insert into @tempConceptos(m_nIdPadre,m_bEsTarifaZona,
                                                   m_nIdConceptoFacturacion ,
                                                   m_cImporte,
                                                   m_nIdImpuestoTraslada,
                                                   m_cImporteIva,
                                                   m_nIdImpuestoRetiene,
                                                   m_cImporteRetiene,
                                                   m_nIdTipoCalculo,
                                                   m_cRangoMinimo,
                                                   m_cRangoMaximo,
                                                   m_sConcepto)
                        values (0, 1, @IdConceptoFacturacion, @Importe, @IdImpuestoTraslada,
                                @ImporteIva, @IdImpuestoRetiene, @ImporteRetiene, @IdTipoCalculo,@RangoMinimo,@RangoMaximo,
                                (Select ConceptoFacturacion from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacion));

                    END

                IF (select EntregaEnSucursal from ProEmbarquePQ where IdEmbarque = @IdEmbarque) = 0
                    BEGIN
                        declare @PesoKgEntrega float = 0;
                        declare @PesoVolumetricoEntrega float = 0;
                        declare @paquetesTotalesEntrega int = 0;
                        --En esta ultima se almacena el tipo de peso que se usará para los calculos
                        declare @pesoFinalEntrega float = 0;

                        declare @ctdPaqueteEntrega int; declare @pesoPaqueteEntrega float; declare @largoPaqueteEntrega float; declare @altoPaqueteEntrega float; declare @anchoPaqueteEntrega float;
                        declare cursor_productos_embarque CURSOR LOCAL
                            FOR select ed.ctd, ed.Peso, ed.Largo, ed.Alto, ed.Ancho FROM ProEmbarqueDetallePQ ed where ed.IdEmbarque = @IdEmbarque;

                        OPEN cursor_productos_embarque;
                        FETCH NEXT FROM cursor_productos_embarque INTO @ctdPaqueteEntrega, @pesoPaqueteEntrega, @largoPaqueteEntrega, @altoPaqueteEntrega,@anchoPaqueteEntrega;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                set @PesoKgEntrega += @pesoPaqueteEntrega * @ctdPaqueteEntrega;
                                set @PesoVolumetricoEntrega += (@largoPaqueteEntrega * @altoPaqueteEntrega * @anchoPaqueteEntrega) * @ctdPaqueteEntrega * 0.0005;
                                set @paquetesTotalesEntrega += @ctdPaqueteEntrega;

                                FETCH NEXT FROM cursor_productos_embarque INTO @ctdPaqueteEntrega, @pesoPaqueteEntrega, @largoPaqueteEntrega, @altoPaqueteEntrega,@anchoPaqueteEntrega;
                            END;
                        CLOSE cursor_productos_embarque;
                        DEALLOCATE cursor_productos_embarque;
                        IF @PesoKgEntrega >= @PesoVolumetricoEntrega
                            begin
                                set @pesoFinalEntrega = @PesoKgEntrega;
                            end
                        IF @PesoKgEntrega < @PesoVolumetricoEntrega
                            begin
                                set @pesoFinalEntrega = @PesoVolumetricoEntrega;
                            end

                        print @pesoFinalEntrega;
                        declare @IdConceptoFacturacionEntrega int;
                        declare @ImporteEntrega money = 0;
                        declare @IdImpuestoTrasladaEntrega int;
                        declare @ImporteIvaEntrega money = 0;
                        declare @IdImpuestoRetieneEntrega int;
                        declare @ImporteRetieneEntrega money = 0;
                        declare @IdTipoCalculoEntrega int;
                        declare @RangoMinimoEntrega int;
                        declare @RangoMaximoEntrega int;
                        declare @IdTipoMedidaEntrega int;
                        declare @porcentajeTrasladaTempEntrega float;
                        declare @porcentajeRetieneTempEntrega float;

                        declare @IdTarifaZonaEntrega int = (Select IdZonaTarifa FROM ProEmbarquePQ where IdEmbarque = @IdEmbarque);
                        declare @IdZonaTarifaConvenioEntrega int = (select CTCP.IdZonaConvenio
                                                                    from CatConveniosPQ C
                                                                             join CatZonasTarifasConvenioPQ CTCP on C.IdConvenio = CTCP.IdConvenio
                                                                    WHERE C.IdCliente = @IdCliente
                                                                      and CTCP.IdZonaTarifa = @IdTarifaZonaEntrega);
                        /*Si esa zona está en un convenio para el cliente*/
                        if @IdZonaTarifaConvenioEntrega is not null
                            begin
                                SELECT @IdConceptoFacturacionEntrega = zt.IdConceptoFacturacion,
                                       @ImporteEntrega = Importe,
                                       @IdImpuestoTrasladaEntrega = IdImpuestoTraslada,
                                       @ImporteIvaEntrega = ImporteIva,
                                       @IdImpuestoRetieneEntrega = IdImpuestoRetiene,
                                       @ImporteRetieneEntrega = ImporteRetiene,
                                       @IdTipoCalculoEntrega = IdTipoCalculo,
                                       @RangoMinimoEntrega = RangoMinimo,
                                       @RangoMaximoEntrega = RangoMaximo,
                                       @IdTipoMedidaEntrega = IdTipoMedida,
                                       @porcentajeTrasladaTempEntrega = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                       @porcentajeRetieneTempEntrega = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                                FROM CatZonasTarifasConvenioConceptosPQ zt
                                         JOIN CatConceptosFacturacion cd ON cd.IdConceptoFacturacion = zt.IdConceptoFacturacion
                                WHERE zt.IdZonaConvenio = @IdZonaTarifaConvenioEntrega and cd.Codigo = 15
                                  AND zt.IdAgregadoDesde = 2
                                  AND zt.RangoMinimo <= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteEntrega else (case when IdTipoMedida = 2 then @pesoFinalEntrega/1000.00 else @pesoFinalEntrega end) end)
                                  AND zt.RangoMaximo >= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteEntrega else (case when IdTipoMedida = 2 then @pesoFinalEntrega/1000.00 else @pesoFinalEntrega end) end)
                            end
                        else
                            /*Si no esa zona no está en el convenio*/
                            begin
                                SELECT @IdConceptoFacturacionEntrega = zt.IdConceptoFacturacion,
                                       @ImporteEntrega = Importe,
                                       @IdImpuestoTrasladaEntrega = IdImpuestoTraslada,
                                       @ImporteIvaEntrega = ImporteIva,
                                       @IdImpuestoRetieneEntrega = IdImpuestoRetiene,
                                       @ImporteRetieneEntrega = ImporteRetiene,
                                       @IdTipoCalculoEntrega = IdTipoCalculo,
                                       @RangoMinimoEntrega = RangoMinimo,
                                       @RangoMaximoEntrega = RangoMaximo,
                                       @IdTipoMedidaEntrega = IdTipoMedida,
                                       @porcentajeTrasladaTempEntrega = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                       @porcentajeRetieneTempEntrega = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                                FROM CatZonasTarifasConceptosPQ zt
                                         JOIN CatConceptosFacturacion cd ON cd.IdConceptoFacturacion = zt.IdConceptoFacturacion
                                WHERE zt.IdZona = @IdTarifaZonaEntrega and cd.Codigo = 15
                                  AND zt.IdAgregadoDesde = 2
                                  AND zt.RangoMinimo <= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteEntrega else (case when IdTipoMedida = 2 then @pesoFinalEntrega/1000.00 else @pesoFinalEntrega end) end)
                                  AND zt.RangoMaximo >= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteEntrega else (case when IdTipoMedida = 2 then @pesoFinalEntrega/1000.00 else @pesoFinalEntrega end) end)
                            end


                        --Si el tipo de medida es KG y el tipo de calculo es Fijo
                        IF @IdTipoMedidaEntrega = 1 AND @IdTipoCalculoEntrega = 1
                            BEGIN
                                SET @ImporteEntrega = @ImporteEntrega;
                            end
                        --Si el tipo de medida es KG y el tipo de calculo es Factor
                        IF @IdTipoMedidaEntrega = 1 AND @IdTipoCalculoEntrega = 2
                            BEGIN
                                SET @ImporteEntrega = (@ImporteEntrega * (@pesoFinalEntrega/1000.00));
                                SET @ImporteIvaEntrega = (@ImporteEntrega * (@porcentajeTrasladaTempEntrega/100));
                                SET @ImporteRetieneEntrega = (@ImporteEntrega * (@porcentajeRetieneTempEntrega/100));
                            end
                        --Si el tipo de medida es TONELADAS y el tipo de calculo es Fijo
                        IF @IdTipoMedidaEntrega = 2 AND @IdTipoCalculoEntrega = 1
                            BEGIN
                                SET @ImporteEntrega = @ImporteEntrega;
                            end
                        --Si el tipo de medida es TONELADAS y el tipo de calculo es Factor
                        IF @IdTipoMedidaEntrega = 2 AND @IdTipoCalculoEntrega = 2
                            BEGIN
                                SET @ImporteEntrega = (@ImporteEntrega * (@pesoFinalEntrega/1000.00))
                                SET @ImporteIvaEntrega = (@ImporteEntrega * (@porcentajeTrasladaTempEntrega/100));
                                SET @ImporteRetieneEntrega = (@ImporteEntrega * (@porcentajeRetieneTempEntrega/100));
                            end
                        --Si el tipo de medida es PRODUCTO
                        IF @IdTipoMedidaEntrega = 3
                            BEGIN
                                SET @ImporteEntrega = @ImporteEntrega;
                            end

                        SET @ImporteIvaEntrega = (@ImporteEntrega * ((select Porcentaje from CatImpuestos where IdImpuesto = @IdImpuestoTrasladaEntrega)/ 100))
                        SET @ImporteRetieneEntrega = (@ImporteEntrega * ((select Porcentaje from CatImpuestos where IdImpuesto = @IdImpuestoRetieneEntrega)/ 100))
                        insert into @tempConceptos(m_nIdPadre,m_bEsTarifaZona,
                                                   m_nIdConceptoFacturacion ,
                                                   m_cImporte,
                                                   m_nIdImpuestoTraslada,
                                                   m_cImporteIva,
                                                   m_nIdImpuestoRetiene,
                                                   m_cImporteRetiene,
                                                   m_nIdTipoCalculo,
                                                   m_cRangoMinimo,
                                                   m_cRangoMaximo,
                                                   m_sConcepto)
                        values (0, 1, @IdConceptoFacturacionEntrega, @ImporteEntrega, @IdImpuestoTrasladaEntrega,
                                @ImporteIvaEntrega, @IdImpuestoRetieneEntrega, @ImporteRetieneEntrega, @IdTipoCalculoEntrega,@RangoMinimoEntrega,@RangoMaximoEntrega,
                                (Select ConceptoFacturacion from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionEntrega));

                    END

                IF (select AplicaSeguro from ProEmbarquePQ WHERE IdEmbarque = @IdEmbarque) = 1
                    begin
                        declare @valorDeclarado money = 0;
                        declare @porcentajeSeguro float = 0;
                        select @valorDeclarado = ValorDeclarado,
                               @porcentajeSeguro = PorcentajeSeguro
                        from ProEmbarquePQ where IdEmbarque = @IdEmbarque;

                        declare @IdConceptoFacturacionSeguro int;
                        declare @ImporteSeguro money = 0;
                        declare @IdImpuestoTrasladaSeguro int;
                        declare @ImporteIvaSeguro money = 0;
                        declare @IdImpuestoRetieneSeguro int;
                        declare @ImporteRetieneSeguro money = 0;
                        declare @porcentajeTrasladaTempSeguro float;
                        declare @porcentajeRetieneTempSeguro float;

                        select @IdConceptoFacturacionSeguro = IdConceptoFacturacion from CatConceptosFacturacion where Codigo = 19
                        SELECT
                                @IdImpuestoTrasladaSeguro = IdImpuesto
                             --,(SELECT CASE WHEN TipoCalculo = 1 THEN 1 ELSE 0 END  from CatImpuestos WHERE IdImpuesto = Detalle.IdImpuesto) AS Trasladado
                             ,@porcentajeTrasladaTempSeguro = (SELECT Porcentaje FROM CatImpuestos WHERE IdImpuesto = Detalle.IdImpuesto)
                        FROM CatConceptosFacturacionImpuestos AS Detalle
                        WHERE IdConceptoFacturacion = @IdConceptoFacturacionSeguro and Detalle.Predeterminado = 1 and (SELECT CASE WHEN TipoCalculo = 1 THEN 1 ELSE 0 END  from CatImpuestos WHERE IdImpuesto = Detalle.IdImpuesto) = 1

                        SELECT
                                @IdImpuestoRetieneSeguro = IdImpuesto
                             --,(SELECT CASE WHEN TipoCalculo = 1 THEN 1 ELSE 0 END  from CatImpuestos WHERE IdImpuesto = Detalle.IdImpuesto) AS Trasladado
                             ,@porcentajeRetieneTempSeguro = (SELECT Porcentaje FROM CatImpuestos WHERE IdImpuesto = Detalle.IdImpuesto)
                        FROM CatConceptosFacturacionImpuestos AS Detalle
                        WHERE IdConceptoFacturacion = @IdConceptoFacturacionSeguro and Detalle.Predeterminado = 1 and (SELECT CASE WHEN TipoCalculo = 1 THEN 1 ELSE 0 END  from CatImpuestos WHERE IdImpuesto = Detalle.IdImpuesto) = 0

                        set @ImporteSeguro = @valorDeclarado * (@porcentajeSeguro/100)
                        set @ImporteIvaSeguro = @ImporteSeguro * (@porcentajeTrasladaTempSeguro/100)
                        set @ImporteRetieneSeguro = @ImporteSeguro * (@porcentajeRetieneTempSeguro/100)

                        insert into @tempConceptos(m_nIdPadre,m_bEsTarifaZona,
                                                   m_nIdConceptoFacturacion ,
                                                   m_cImporte,
                                                   m_nIdImpuestoTraslada,
                                                   m_cImporteIva,
                                                   m_nIdImpuestoRetiene,
                                                   m_cImporteRetiene,
                                                   m_nIdTipoCalculo,
                                                   m_cRangoMinimo,
                                                   m_cRangoMaximo,
                                                   m_sConcepto)
                        values (0, 0, @IdConceptoFacturacionSeguro, @ImporteSeguro, @IdImpuestoTrasladaSeguro,
                                @ImporteIvaSeguro, @IdImpuestoRetieneSeguro, @ImporteRetieneSeguro, 0,0,0,
                                (Select ConceptoFacturacion from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionSeguro));
                    end

                declare @IdEmbaqueDetalle int;
                declare @IdProductoEmbarqueRangos int;
                declare @ctdPaqueteRangos int;
                declare @pesoPaqueteRangos float;
                declare @largoPaqueteRangos float;
                declare @altoPaqueteRangos float;
                declare @anchoPaqueteRangos float;

                declare @IdConceptoFacturacionRangos int;
                declare @ImporteRangos money = 0;
                declare @IdImpuestoTrasladaRangos int;
                declare @ImporteIvaRangos money = 0;
                declare @IdImpuestoRetieneRangos int;
                declare @ImporteRetieneRangos money = 0;
                declare @IdTipoCalculoRangos int;
                declare @IdTipoMedidaRangos int;

                declare cursor_productos_embarque CURSOR LOCAL
                    FOR select ed.IdEmbarqueDetalle,ed.[IdProducto], ed.Peso, ed.ctd, ed.Largo, ed.Alto, ed.Ancho FROM ProEmbarqueDetallePQ ed where ed.IdEmbarque = @IdEmbarque;

                OPEN cursor_productos_embarque;
                FETCH NEXT FROM cursor_productos_embarque INTO @IdEmbaqueDetalle,@IdProductoEmbarqueRangos, @pesoPaqueteRangos,@ctdPaqueteRangos,@largoPaqueteRangos,@altoPaqueteRangos,@anchoPaqueteRangos;
                WHILE @@FETCH_STATUS = 0
                    BEGIN
                        declare @PesoKgRangos float = 0;
                        declare @PesoVolumetricoRangos float = 0;
                        declare @pesoFinalRangos float = 0;
                        declare @ImporteTemp money = 0;
                        declare @ImporteTrasladaTemp money = 0;
                        declare @ImporteRetieneTemp money = 0;
                        declare @porcentajeTrasladaTempRangos float;
                        declare @porcentajeRetieneTempRangos float;

                        set @PesoKgRangos = @pesoPaqueteRangos * @ctdPaqueteRangos;
                        set @PesoVolumetricoRangos = (@largoPaqueteRangos * @altoPaqueteRangos * @anchoPaqueteRangos) * @ctdPaqueteRangos * 0.0005;
                        IF @PesoKgRangos >= @PesoVolumetricoRangos
                            begin
                                set @pesoFinalRangos = @PesoKgRangos;
                            end
                        IF @PesoKgRangos < @PesoVolumetricoRangos
                            begin
                                set @pesoFinalRangos = @PesoVolumetricoRangos;
                            end

                        /**Se busca convenio con esa tarifa, para el cliente del emabarque*/
                        set @IdTarifaRangos = (select --C.IdConvenio,
                                                      CTCP.IdTarifaConvenio
                                               from CatConveniosPQ C
                                                        join CatTarifaConvenioPQ CTCP on C.IdConvenio = CTCP.IdConvenio
                                                        join CatTarifaPQ t on t.IdTarifa = CTCP.IdTarifa
                                                        JOIN CatProductosTarifaConvenioPQ p ON p.IdTarifaConvenio = CTCP.IdTarifaConvenio
                                                        JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa
                                               WHERE t.IdOrigen = @IdOrigen
                                                 AND td.IdDestino = @IdDestino
                                                 AND t.PorRango = 1
                                                 AND p.IdProducto = @IdProductoEmbarqueRangos
                                                 AND C.IdCliente = @IdCliente);

                        /*Si no hay tarifa en convenio*/
                        IF @IdTarifaRangos IS NULL
                            BEGIN
                                /*Se busca tarifa regular*/
                                set @IdTarifaRangos = (SELECT Distinct t.IdTarifa FROM CatTarifaPQ t JOIN CatProductosTarifaPQ p ON p.IdTarifa = t.IdTarifa JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa WHERE t.IdOrigen = @IdOrigen and td.IdDestino = @IdDestino and t.PorRango = 1 AND p.IdProducto = @IdProductoEmbarqueRangos);
                                /*Si no hay tarifa regular para ese producto especifico*/
                                IF @IdTarifaRangos IS NULL
                                    BEGIN
                                        /*Se busca tarifa regular para producto generico*/
                                        set @IdTarifaRangos = (SELECT Distinct t.IdTarifa FROM CatTarifaPQ t JOIN CatProductosTarifaPQ p ON p.IdTarifa = t.IdTarifa JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa WHERE t.IdOrigen = @IdOrigen and td.IdDestino = @IdDestino and t.PorRango = 1 AND p.IdProducto = 1);
                                    end
                                /*Se verifica que haya tarifa nomas por si acaso*/
                                IF @IdTarifaRangos IS NOT NULL
                                    /*Se consigue el concepto de la tarifa que cuadre con las caracterisiticas del paquete*/
                                    BEGIN
                                        declare cursor_conceptos_tarifa CURSOR LOCAL
                                            FOR SELECT IdConceptoFacturacion,
                                                       Importe,
                                                       IdImpuestoTraslada,
                                                       ImporteIva,
                                                       IdImpuestoRetiene,
                                                       ImporteRetiene,
                                                       IdTipoCalculo,
                                                       IdTipoMedida,
                                                       (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                                       (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                                                FROM CatTarifaConceptosPQ zt
                                                WHERE zt.IdTarifa = @IdTarifaRangos
                                                  AND zt.RangoMinimo <= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteRangos else (case when IdTipoMedida = 2 then @pesoFinalRangos/1000.00 else @pesoFinalRangos end) end)
                                                  AND zt.RangoMaximo >= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteRangos else (case when IdTipoMedida = 2 then @pesoFinalRangos/1000.00 else @pesoFinalRangos end) end)
                                        --AND zt.IdConceptoFacturacion = (Select IdConceptosFacturacion from ConceptosDefectoPQ where IdConcepto = 1);
                                        OPEN cursor_conceptos_tarifa;
                                        FETCH NEXT FROM cursor_conceptos_tarifa INTO
                                            @IdConceptoFacturacionRangos,
                                            @ImporteTemp,
                                            @IdImpuestoTrasladaRangos,
                                            @ImporteTrasladaTemp,
                                            @IdImpuestoRetieneRangos,
                                            @ImporteRetieneTemp,
                                            @IdTipoCalculoRangos,
                                            @IdTipoMedidaRangos,
                                            @porcentajeTrasladaTempRangos,
                                            @porcentajeRetieneTempRangos;
                                        WHILE @@FETCH_STATUS = 0
                                            BEGIN
                                                IF ((select Codigo from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos) = 1)
                                                    or (@IdRecoleccion > 0 and (select Codigo from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos) = 16)
                                                    or ((select EntregaEnSucursal from ProEmbarquePQ where IdEmbarque = @IdEmbarque) = 0 and (select Codigo from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos) = 17)
                                                    begin
                                                        --Si el tipo de medida es KG y el tipo de calculo es Fijo
                                                        IF @IdTipoMedidaRangos = 1 AND @IdTipoCalculoRangos = 1
                                                            BEGIN
                                                                SET @ImporteRangos = @ImporteTemp;
                                                                SET @ImporteIvaRangos = @ImporteTrasladaTemp;
                                                                SET @ImporteRetieneRangos = @ImporteRetieneTemp;
                                                            end
                                                        --Si el tipo de medida es KG y el tipo de calculo es Factor
                                                        IF @IdTipoMedidaRangos = 1 AND @IdTipoCalculoRangos = 2
                                                            BEGIN
                                                                SET @ImporteRangos = (@ImporteTemp * (@pesoFinalRangos/1000.00));
                                                                SET @ImporteIvaRangos = (@ImporteRangos * (@porcentajeTrasladaTempRangos/100));
                                                                SET @ImporteRetieneRangos = (@ImporteRangos * (@porcentajeRetieneTempRangos/100));
                                                            end
                                                        --Si el tipo de medida es TONELADAS y el tipo de calculo es Fijo
                                                        IF @IdTipoMedidaRangos = 2 AND @IdTipoCalculoRangos = 1
                                                            BEGIN
                                                                SET @ImporteRangos = @ImporteTemp;
                                                                SET @ImporteIvaRangos = @ImporteTrasladaTemp;
                                                                SET @ImporteRetieneRangos = @ImporteRetieneTemp;
                                                            end
                                                        --Si el tipo de medida es TONELADAS y el tipo de calculo es Factor
                                                        IF @IdTipoMedidaRangos = 2 AND @IdTipoCalculoRangos = 2
                                                            BEGIN
                                                                SET @ImporteRangos = (@pesoFinalRangos/1000.00) * @ImporteTemp;
                                                                SET @ImporteIvaRangos = (@ImporteRangos * (@porcentajeTrasladaTempRangos/100));
                                                                SET @ImporteRetieneRangos = (@ImporteRangos * (@porcentajeRetieneTempRangos/100));
                                                            end
                                                        --Si el tipo de medida es PRODUCTO
                                                        IF @IdTipoMedidaRangos = 3
                                                            BEGIN
                                                                SET @ImporteRangos = @ImporteTemp;
                                                                SET @ImporteIvaRangos = @ImporteTrasladaTemp;
                                                                SET @ImporteRetieneRangos = @ImporteRetieneTemp;
                                                            end

                                                        insert into @tempConceptos(m_nIdPadre,m_bEsTarifaZona,
                                                                                   m_nIdConceptoFacturacion ,
                                                                                   m_cImporte,
                                                                                   m_nIdImpuestoTraslada,
                                                                                   m_cImporteIva,
                                                                                   m_nIdImpuestoRetiene,
                                                                                   m_cImporteRetiene,
                                                                                   m_nIdTipoCalculo,
                                                                                   m_cRangoMinimo,
                                                                                   m_cRangoMaximo,
                                                                                   m_sConcepto)
                                                        values (0, 0, @IdConceptoFacturacionRangos, @ImporteRangos, @IdImpuestoTrasladaRangos,
                                                                @ImporteIvaRangos, @IdImpuestoRetieneRangos, @ImporteRetieneRangos, 0,0,0,
                                                                (Select ConceptoFacturacion from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos));
                                                    end

                                                FETCH NEXT FROM cursor_conceptos_tarifa INTO
                                                    @IdConceptoFacturacionRangos,
                                                    @ImporteTemp,
                                                    @IdImpuestoTrasladaRangos,
                                                    @ImporteTrasladaTemp,
                                                    @IdImpuestoRetieneRangos,
                                                    @ImporteRetieneTemp,
                                                    @IdTipoCalculoRangos,
                                                    @IdTipoMedidaRangos,
                                                    @porcentajeTrasladaTempRangos,
                                                    @porcentajeRetieneTempRangos;
                                            end
                                        CLOSE cursor_conceptos_tarifa;
                                        DEALLOCATE cursor_conceptos_tarifa;

                                    end
                            end
                        ELSE
                            /*Si sí hubo convenio con tarifa*/
                            BEGIN
                                /*Se consigue el concepto de la tarifa que cuadre con las caracterisiticas del paquete*/
                                declare cursor_conceptos_tarifa_convenio CURSOR LOCAL
                                    FOR SELECT IdConceptoFacturacion,
                                               Importe,
                                               IdImpuestoTraslada,
                                               ImporteIva,
                                               IdImpuestoRetiene,
                                               ImporteRetiene,
                                               IdTipoCalculo,
                                               IdTipoMedida,
                                               (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                               (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                                        FROM CatTarifaConvenioConceptosPQ zt
                                        WHERE zt.IdTarifaConvenio = @IdTarifaRangos
                                          AND zt.RangoMinimo <= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteRangos else (case when IdTipoMedida = 2 then @pesoFinalRangos/1000.00 else @pesoFinalRangos end) end)
                                          AND zt.RangoMaximo >= (case when zt.IdTipoCalculo = 3 then @ctdPaqueteRangos else (case when IdTipoMedida = 2 then @pesoFinalRangos/1000.00 else @pesoFinalRangos end) end);
                                --                                           AND zt.IdConceptoFacturacion = (Select IdConceptosFacturacion from ConceptosDefectoPQ where IdConcepto = 1);
                                OPEN cursor_conceptos_tarifa_convenio;
                                FETCH NEXT FROM cursor_conceptos_tarifa_convenio INTO
                                    @IdConceptoFacturacionRangos,
                                    @ImporteTemp,
                                    @IdImpuestoTrasladaRangos,
                                    @ImporteTrasladaTemp,
                                    @IdImpuestoRetieneRangos,
                                    @ImporteRetieneTemp,
                                    @IdTipoCalculoRangos,
                                    @IdTipoMedidaRangos,
                                    @porcentajeTrasladaTempRangos,
                                    @porcentajeRetieneTempRangos;
                                WHILE @@FETCH_STATUS = 0
                                    BEGIN
                                        IF ((select Codigo from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos) = 1)
                                            or (@IdRecoleccion > 0 and (select Codigo from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos) = 16)
                                            or ((select EntregaEnSucursal from ProEmbarquePQ where IdEmbarque = @IdEmbarque) = 0 and (select Codigo from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos) = 17)
                                            begin
                                                --Si el tipo de medida es KG y el tipo de calculo es Fijo
                                                IF @IdTipoMedidaRangos = 1 AND @IdTipoCalculoRangos = 1
                                                    BEGIN
                                                        SET @ImporteRangos = @ImporteTemp;
                                                        SET @ImporteIvaRangos = @ImporteTrasladaTemp;
                                                        SET @ImporteRetieneRangos = @ImporteRetieneTemp;
                                                    end
                                                --Si el tipo de medida es KG y el tipo de calculo es Factor
                                                IF @IdTipoMedidaRangos = 1 AND @IdTipoCalculoRangos = 2
                                                    BEGIN
                                                        SET @ImporteRangos = (@ImporteTemp * (@pesoFinalRangos/1000.00));
                                                        SET @ImporteIvaRangos = (@ImporteRangos * (@porcentajeTrasladaTempRangos/100));
                                                        SET @ImporteRetieneRangos = (@ImporteRangos * (@porcentajeRetieneTempRangos/100));
                                                    end
                                                --Si el tipo de medida es TONELADAS y el tipo de calculo es Fijo
                                                IF @IdTipoMedidaRangos = 2 AND @IdTipoCalculoRangos = 1
                                                    BEGIN
                                                        SET @ImporteRangos = @ImporteTemp;
                                                        SET @ImporteIvaRangos = @ImporteTrasladaTemp;
                                                        SET @ImporteRetieneRangos = @ImporteRetieneTemp;
                                                    end
                                                --Si el tipo de medida es TONELADAS y el tipo de calculo es Factor
                                                IF @IdTipoMedidaRangos = 2 AND @IdTipoCalculoRangos = 2
                                                    BEGIN
                                                        SET @ImporteRangos = (@pesoFinalRangos/1000.00) * @ImporteTemp;
                                                        SET @ImporteIvaRangos = (@ImporteRangos * (@porcentajeTrasladaTempRangos/100));
                                                        SET @ImporteRetieneRangos = (@ImporteRangos * (@porcentajeRetieneTempRangos/100));
                                                    end
                                                --Si el tipo de medida es PRODUCTO
                                                IF @IdTipoMedidaRangos = 3
                                                    BEGIN
                                                        SET @ImporteRangos = @ImporteTemp;
                                                        SET @ImporteIvaRangos = @ImporteTrasladaTemp;
                                                        SET @ImporteRetieneRangos = @ImporteRetieneTemp;
                                                    end

                                                insert into @tempConceptos(m_nIdPadre,m_bEsTarifaZona,
                                                                           m_nIdConceptoFacturacion ,
                                                                           m_cImporte,
                                                                           m_nIdImpuestoTraslada,
                                                                           m_cImporteIva,
                                                                           m_nIdImpuestoRetiene,
                                                                           m_cImporteRetiene,
                                                                           m_nIdTipoCalculo,
                                                                           m_cRangoMinimo,
                                                                           m_cRangoMaximo,
                                                                           m_sConcepto)
                                                values (0, 0, @IdConceptoFacturacionRangos, @ImporteRangos, @IdImpuestoTrasladaRangos,
                                                        @ImporteIvaRangos, @IdImpuestoRetieneRangos, @ImporteRetieneRangos, 0,0,0,
                                                        (Select ConceptoFacturacion from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionRangos));
                                            end

                                        FETCH NEXT FROM cursor_conceptos_tarifa_convenio INTO
                                            @IdConceptoFacturacionRangos,
                                            @ImporteTemp,
                                            @IdImpuestoTrasladaRangos,
                                            @ImporteTrasladaTemp,
                                            @IdImpuestoRetieneRangos,
                                            @ImporteRetieneTemp,
                                            @IdTipoCalculoRangos,
                                            @IdTipoMedidaRangos,
                                            @porcentajeTrasladaTempRangos,
                                            @porcentajeRetieneTempRangos;
                                    end
                                CLOSE cursor_conceptos_tarifa_convenio;
                                DEALLOCATE cursor_conceptos_tarifa_convenio;
                            end

                        FETCH NEXT FROM cursor_productos_embarque INTO @IdEmbaqueDetalle,@IdProductoEmbarqueRangos, @pesoPaqueteRangos,@ctdPaqueteRangos,@largoPaqueteRangos,@altoPaqueteRangos,@anchoPaqueteRangos;
                    END;
                CLOSE cursor_productos_embarque;
                DEALLOCATE cursor_productos_embarque;

            END
        --Tarifa POR REGION
        IF @IdTipoTarifa = 3
            BEGIN
                declare @IdConceptoFacturacionTarifa int;
                declare @IdImpuestoTrasladaTarifa int;
                declare @porcentajeTrasladaTarifa float;
                declare @IdImpuestoRetieneTarifa int;
                declare @porcentajeRetieneTarifa float;

                declare @IdProductoEmbarque int;
                declare @ctdPaqueteEmbarque int;
                declare @ImporteProducto money;
                declare @ImporteConcepto money = 0;
                declare @ImporteIvaConcepto money = 0;
                declare @ImporteRetieneConcepto money = 0;

                /*Se busca tarifa en convenio del cliente del embarque*/
                set @IdTarifa = (select --C.IdConvenio,
                                        CTCP.IdTarifaConvenio
                                 from CatConveniosPQ C
                                          join CatTarifaConvenioPQ CTCP on C.IdConvenio = CTCP.IdConvenio
                                          join CatTarifaPQ t on t.IdTarifa = CTCP.IdTarifa
                                          JOIN CatProductosTarifaConvenioPQ p ON p.IdTarifaConvenio = CTCP.IdTarifaConvenio
                                          JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa
                                 WHERE t.IdOrigen = @IdOrigen
                                   AND td.IdDestino = @IdDestino
                                   AND t.PorRegion = 1
                                   AND p.IdProducto = @IdProductoEmbarqueRangos
                                   AND C.IdCliente = @IdCliente);
                set @FleteMinimo =    (select t.FleteMinimo from CatConveniosPQ C join CatTarifaConvenioPQ CTCP on C.IdConvenio = CTCP.IdConvenio join CatTarifaPQ t on t.IdTarifa = CTCP.IdTarifa JOIN CatProductosTarifaConvenioPQ p ON p.IdTarifaConvenio = CTCP.IdTarifaConvenio JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa WHERE t.IdOrigen = @IdOrigen AND td.IdDestino = @IdDestino AND t.PorRegion = 1 AND p.IdProducto = @IdProductoEmbarqueRangos AND C.IdCliente = @IdCliente);
                set @MontoMinimo =    (select t.MontoMinimo from CatConveniosPQ C join CatTarifaConvenioPQ CTCP on C.IdConvenio = CTCP.IdConvenio join CatTarifaPQ t on t.IdTarifa = CTCP.IdTarifa JOIN CatProductosTarifaConvenioPQ p ON p.IdTarifaConvenio = CTCP.IdTarifaConvenio JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa WHERE t.IdOrigen = @IdOrigen AND td.IdDestino = @IdDestino AND t.PorRegion = 1 AND p.IdProducto = @IdProductoEmbarqueRangos AND C.IdCliente = @IdCliente);

                /*Si no hay tarifa en convenio*/
                IF @IdTarifa IS NULL
                    /*Se busca tarifa regular*/
                    begin
                        set @TarifaDeConvenio = 0;

                    end
                ELSE
                    /*si sí hubo tarifa en convenio*/
                    begin
                        set @TarifaDeConvenio = 1;

                    end


                IF @TarifaDeConvenio = 1
                    begin
                        select  @IdConceptoFacturacionTarifa = IdConceptoFacturacion,
                                @IdImpuestoTrasladaTarifa =  IdImpuestoTraslada,
                                @IdImpuestoRetieneTarifa =  IdImpuestoRetiene,
                                @porcentajeTrasladaTarifa = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                @porcentajeRetieneTarifa = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                        from CatTarifaConvenioConceptosPQ
                        where IdTarifaConvenio = @IdTarifa;

                        declare cursor_productos_embarque CURSOR LOCAL
                            FOR select ed.[IdProducto],ed.[ctd],(select pt.Importe from CatProductosTarifaConvenioPQ pt where pt.IdProducto = ed.IdProducto and pt.IdTarifaConvenio = @IdTarifa) as Importe FROM ProEmbarqueDetallePQ ed where ed.IdEmbarque = @IdEmbarque;
                        OPEN cursor_productos_embarque;
                        FETCH NEXT FROM cursor_productos_embarque INTO @IdProductoEmbarque, @ctdPaqueteEmbarque, @ImporteProducto;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                set @ImporteConcepto = @ImporteConcepto + (CASE WHEN (@ImporteProducto * @ctdPaqueteEmbarque) < @MontoMinimo THEN @MontoMinimo ELSE (@ImporteProducto * @ctdPaqueteEmbarque) END);
                                set @ImporteIvaConcepto = @ImporteConcepto * (@porcentajeTrasladaTarifa / 100);
                                set @ImporteRetieneConcepto = @ImporteConcepto * (@porcentajeRetieneTarifa / 100);
                                FETCH NEXT FROM cursor_productos_embarque INTO @IdProductoEmbarque, @ctdPaqueteEmbarque,@ImporteProducto;
                            END;
                        CLOSE cursor_productos_embarque;
                        DEALLOCATE cursor_productos_embarque;
                    end
                ELSE
                    begin
                        set @IdTarifa = (SELECT Distinct t.IdTarifa
                                         FROM CatTarifaPQ t
                                                  JOIN CatProductosTarifaPQ p ON p.IdTarifa = t.IdTarifa
                                                  JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa
                                         WHERE t.IdOrigen = @IdOrigen
                                           and td.IdDestino = @IdDestino
                                           and t.PorRegion = 1
                                           AND p.IdProducto in (Select ED.IdProducto
                                                                from ProEmbarqueDetallePQ ED
                                                                where ED.IdEmbarque = @IdEmbarque));
                        set @FleteMinimo =    (SELECT Distinct t.FleteMinimo FROM CatTarifaPQ t JOIN CatProductosTarifaPQ p ON p.IdTarifa = t.IdTarifa JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa WHERE t.IdOrigen = @IdOrigen and td.IdDestino = @IdDestino and t.PorRegion = 1 AND p.IdProducto in (Select ED.IdProducto from ProEmbarqueDetallePQ ED where ED.IdEmbarque = @IdEmbarque));
                        set @MontoMinimo =    (SELECT Distinct t.MontoMinimo FROM CatTarifaPQ t JOIN CatProductosTarifaPQ p ON p.IdTarifa = t.IdTarifa JOIN CatTarifaDestinosPQ td ON td.IdTarifa = t.IdTarifa WHERE t.IdOrigen = @IdOrigen and td.IdDestino = @IdDestino and t.PorRegion = 1 AND p.IdProducto in (Select ED.IdProducto from ProEmbarqueDetallePQ ED where ED.IdEmbarque = @IdEmbarque));

                        select  @IdConceptoFacturacionTarifa = IdConceptoFacturacion,
                                @IdImpuestoTrasladaTarifa =  IdImpuestoTraslada,
                                @IdImpuestoRetieneTarifa =  IdImpuestoRetiene,
                                @porcentajeTrasladaTarifa = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoTraslada),
                                @porcentajeRetieneTarifa = (select Porcentaje from CatImpuestos where IdImpuesto = IdImpuestoRetiene)
                        from CatTarifaConceptosPQ
                        where IdTarifa = @IdTarifa;

                        declare cursor_productos_embarque CURSOR LOCAL
                            FOR select ed.[IdProducto],ed.[ctd],(select pt.Importe from CatProductosTarifaPQ pt where pt.IdProducto = ed.IdProducto and pt.IdTarifa = @IdTarifa) as Importe FROM ProEmbarqueDetallePQ ed where ed.IdEmbarque = @IdEmbarque;

                        OPEN cursor_productos_embarque;
                        FETCH NEXT FROM cursor_productos_embarque INTO @IdProductoEmbarque, @ctdPaqueteEmbarque, @ImporteProducto;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                set @ImporteConcepto = @ImporteConcepto + (CASE WHEN (@ImporteProducto * @ctdPaqueteEmbarque) < @MontoMinimo THEN @MontoMinimo ELSE (@ImporteProducto * @ctdPaqueteEmbarque) END);
                                set @ImporteIvaConcepto = @ImporteConcepto * (@porcentajeTrasladaTarifa / 100);
                                set @ImporteRetieneConcepto = @ImporteConcepto * (@porcentajeRetieneTarifa / 100);
                                FETCH NEXT FROM cursor_productos_embarque INTO @IdProductoEmbarque, @ctdPaqueteEmbarque,@ImporteProducto;
                            END;
                        CLOSE cursor_productos_embarque;
                        DEALLOCATE cursor_productos_embarque;
                    end

                insert into @tempConceptos(m_nIdPadre,
                                           m_bEsTarifaZona,
                                           m_nIdConceptoFacturacion ,
                                           m_cImporte ,
                                           m_nIdImpuestoTraslada,
                                           m_cImporteIva,
                                           m_nIdImpuestoRetiene,
                                           m_cImporteRetiene,
                                           m_nIdTipoCalculo,
                                           m_cRangoMinimo,
                                           m_cRangoMaximo,
                                           m_sConcepto)
                values (@IdTarifa, 0, @IdConceptoFacturacionTarifa, @ImporteConcepto, @IdImpuestoTrasladaTarifa,
                        @ImporteIvaConcepto, @IdImpuestoRetieneTarifa, @ImporteRetieneConcepto, 0,0,0,
                        (Select ConceptoFacturacion from CatConceptosFacturacion where IdConceptoFacturacion = @IdConceptoFacturacionTarifa));

            END

        SELECT m_nIdPadre,
               sum(m_cImporte) as m_cImporte,
               m_bEsTarifaZona,
               m_nIdConceptoFacturacion,
               m_sConcepto,

               m_nIdImpuestoTraslada,
               sum(m_cImporteIva) as m_cImporteIva,
               --                m_cImporteIva,
               m_nIdImpuestoRetiene,
               sum(m_cImporteRetiene) as m_cImporteRetiene,
               --                m_cImporteRetiene,
               m_nIdTipoCalculo,
               m_cRangoMinimo,
               m_cRangoMaximo
        FROM @tempConceptos t
        group by
            m_nIdPadre,
            m_bEsTarifaZona,
            m_nIdConceptoFacturacion,
            m_sConcepto,
            m_nIdImpuestoTraslada,
            --                  m_cImporteIva,
            m_nIdImpuestoRetiene,
            --                  m_cImporteRetiene,
            m_nIdTipoCalculo,
            m_cRangoMinimo,
            m_cRangoMaximo;
    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION
    EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

