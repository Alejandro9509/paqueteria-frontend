
CREATE PROCEDURE [dbo].[usp_CatModelosLlantasEliminar]
@IdModeloLLanta int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdModeloLLanta,0)= 0
		   RAISERROR(N'El identificador del modelo es un campo requerido',
					16,
					1
					)
	
	IF NOT EXISTS(SELECT IdModeloLlanta  FROM CatModelosLlantas WHERE  IdModeloLlanta  <> @IdModeloLLanta)
			RAISERROR(N'El modelo ya fue eliminado por otro usuario',
				16,
				1
				)	
					
	IF EXISTS(SELECT top 1 IdModeloLlanta  FROM ProLlantas WHERE  IdModeloLlanta  = @IdModeloLLanta)
			RAISERROR(N'El Modelo no se puede eliminar porque ya cuenta con llantas ligadas',
				16,
				1
				)
																				
		DELETE CatModelosLlantas	
		WHERE 	IdModeloLlanta = @IdModeloLLanta
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

