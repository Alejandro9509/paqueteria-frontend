/* *************************************************************************************************
	SOLICITUD 172

	Descripcion: Obtiene el ultimo folio en la tabla y suma 1

	Modificada por:   Amado NAvarro
	Fecha de mofidicacion: 16/10/2019
	Versión: Versión 8.0.47.01

	Invocada desde: <PAGE_ProInventariosAM>
************************************************************************************************* */

CREATE PROCEDURE [dbo].[usp_ProInventariosDeAlmacenGetMaxFolio]
AS
BEGIN
	SET NOCOUNT ON;
    SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProInventariosDeAlmacen
END
go

