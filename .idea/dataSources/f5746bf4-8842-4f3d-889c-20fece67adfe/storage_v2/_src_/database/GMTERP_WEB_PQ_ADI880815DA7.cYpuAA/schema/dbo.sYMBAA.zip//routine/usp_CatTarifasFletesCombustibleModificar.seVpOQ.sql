CREATE PROCEDURE [dbo].[usp_CatTarifasFletesCombustibleModificar]
@IdCombustibleTarifaFlete int,
@Tarifa decimal(15,4),
@KM int,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@Tarifa,0)= 0
		RAISERROR(N'La Tarifa es un campo requerido',
			16,
			1
			)
						
	IF ISNULL(@KM,0)= 0
		RAISERROR(N'KMs es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT TOP 1 KM  FROM CatTarifasFletesCombustible WHERE KM = @KM and IdCombustibleTarifaFlete <>@IdCombustibleTarifaFlete )
		RAISERROR(N'Ya existe una tarifa para esos kilómetros.',
			16,
			1
			)
			
	UPDATE CatTarifasFletesCombustible SET
			Tarifa = @Tarifa ,
				KM = @KM ,
      ModificadoEl = @ModificadoEl ,
     ModificadoPor = @ModificadoPor 
       WHERE IdCombustibleTarifaFlete=@IdCombustibleTarifaFlete
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

