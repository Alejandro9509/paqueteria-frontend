
CREATE PROCEDURE [dbo].[usp_CatZonasTarifasAgregarPQ](
	@CodigoZona varchar(50),
	@IdSucursal int,
	@IdEstado varchar(5),
	@Estado varchar(100),
	@CodMunicipio varchar(5),
	@Municipio varchar(100)
)
AS
BEGIN
	BEGIN TRANSACTION
		INSERT INTO CatZonasTarifasPQ (CodigoZona, IdSucursal, IdEstado, Estado)
		values(@CodigoZona, @IdSucursal, @IdEstado, @Estado) 

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

