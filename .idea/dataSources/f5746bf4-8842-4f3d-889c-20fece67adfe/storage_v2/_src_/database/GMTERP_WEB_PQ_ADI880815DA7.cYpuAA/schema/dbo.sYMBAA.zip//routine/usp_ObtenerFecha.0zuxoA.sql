CREATE PROCEDURE [dbo].[usp_ObtenerFecha]

AS
BEGIN 
	BEGIN TRANSACTION
	DECLARE @VFecha datetime = GETDATE();

	SELECT FORMAT(@VFecha, 'yyyy-MM-dd') as Fecha
	COMMIT
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

