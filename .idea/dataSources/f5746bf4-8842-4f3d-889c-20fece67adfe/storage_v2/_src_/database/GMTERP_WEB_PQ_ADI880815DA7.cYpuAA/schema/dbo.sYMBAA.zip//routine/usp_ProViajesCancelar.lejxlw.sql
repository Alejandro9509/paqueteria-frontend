CREATE PROCEDURE [dbo].[usp_ProViajesCancelar]
	@IdViaje int,
	@IdViajeCartaPorte int,
	@MotivoCancelacion varchar(500),
	@CanceladoEl datetime,
	@CanceladoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@IdEstatuViaje int
	/*************************************************************************************************************************************
Procedimiento almacenado usp_ProViajesCancelar

Parámetros: 
	@IdViaje int,
	@IdViajeCartaPorte int,
	@MotivoCancelacion varchar(500),
	@CanceladoEl datetime,
	@CanceladoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@IdEstatuViaje int

Descripción: Cancela Viajes seleccionados en el listado de viajes 

Fecha de modificación: 08/11/2019
Versión: 8.0.47.37
Solicitud 133
Se desligan contenedores porturarios de un viaje al ser cancelado

Modificada por:   Gilberto Garcia
Fecha de modificación: 24/11/2020
Versión: 8.0.56.29

Invocada desde: PAGE_ProViajesListadoOptimizado
******************************************************************************************************************* */
AS
DECLARE
	@IdFolio int,
    @ViajeConCP bit,
    @IdMonedaAnt int,
    @TotalAnt money,
    @FacturableAnt bit,
    @IdClienteAnt int,
    @return_value int,
    @IdUnidadCarga1 int,
	@IdUnidadDolly int,
	@IdUnidadCarga2 int,
	@IdUnidadCamion int,
	@CursorIdEstatuUnidad int,
	@CursorIdCliente int,
	@CursorIdViaje int,
	@CursorIdUbicacion int,
	@CursorDesde datetime,
	@CursorLlegadaTrayecto datetime,
	@KilometrosTrayecto int,
	@MillasTrayecto decimal(15,2),
	@CursorIdViajeTrayecto int,
	@MensajeError varchar(max),
	@IdSolicitudViaje INT,
	@Estatus TINYINT
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdViaje = 0
		RAISERROR(N'El identificador de la Viaje es un campo requerido',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM ProViajes WHERE IdViaje = @IdViaje) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)

	IF (SELECT FechaHora FROM ProViajes WHERE IdViaje = @IdViaje) > @CanceladoEl
		RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de elaboración',
			16,
			1
			)
			
	IF (SELECT CanceladoEl FROM ProViajes WHERE IdViaje = @IdViaje) IS NOT NULL --cancelado
		RAISERROR(N'No puede ser cancelado este viaje porque está cancelado',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@MotivoCancelacion)) = ''
		RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)		

	IF ISNULL(@IdEstatuViaje,0) = 0
		RAISERROR(N'El estatus del viaje es un campo requerido',
			16,
			1
			)

	SET @MensajeError = (
	SELECT
	STUFF(
	(SELECT
	CHAR(13)+CHAR(10)+
	Folios
	FROM 
	(
	SELECT 'Anticipos: '+
	STUFF(
	(SELECT ', '+RIGHT('000000'+ LTRIM(RTRIM(Folio)),6)
	FROM 
	(
	SELECT CAST(PA.Folio AS varchar) AS Folio
	FROM ProViajesTrayectos PVT
	INNER JOIN ProAnticipos PA ON PVT.IdViajeTrayecto = PA.IdViajeTrayecto
	WHERE PVT.IdViaje = @IdViaje
	) FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') as Folios
	
	UNION ALL
	
	SELECT 'Vales: '+
	STUFF(
	(SELECT ', '+RIGHT('000000'+ LTRIM(RTRIM(Folio)),6)
	FROM 
	(
	SELECT CAST(PVC.Folio AS varchar) AS Folio
	FROM ProViajesTrayectos PVT
	INNER JOIN ProValesCombustible PVC ON PVT.IdViajeTrayecto = PVC.IdViajeTrayecto
	WHERE PVT.IdViaje = @IdViaje
	) FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') as Folios
	
	UNION ALL
	
	SELECT 'Gastos: '+
	STUFF(
	(SELECT ', '+RIGHT('000000'+ LTRIM(RTRIM(Folio)),6)
	FROM 
	(
	SELECT CAST(PGV.NumeroComprobante AS varchar) AS Folio
	FROM ProViajesTrayectos PVT
	INNER JOIN ProGastosViaje PGV ON PVT.IdViajeTrayecto = PGV.IdViajeTrayecto
	WHERE PVT.IdViaje = @IdViaje
	) FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') as Folios
	
	UNION ALL 
	
	SELECT 'Viajes Compuestos Hijos: '+
	STUFF(
	(SELECT ', '+Folio
	FROM 
	(
	SELECT CS.Abreviacion+'-'+SubString('000000',1,6-len(CAST(PV.Viaje as varchar)))+CAST(PV.Viaje as varchar)  AS Folio
	FROM ProViajes PV
	INNER JOIN CatSucursales CS ON PV.IdSucursal = CS.IdSucursal
	WHERE PV.IdViajeCompuestoPadre = @IdViaje
	) FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') as Folios
	
	UNION ALL
	
	SELECT 'Viajes Compuestos Padres: '+
	STUFF(
	(SELECT ', '+Viaje
	FROM 
	(
	SELECT CAST(PV2.Viaje AS varchar) as Viaje
	FROM ProViajes PV2 WHERE PV2.IdViaje = (
	SELECT PV.IdViajeCompuestoPadre
	FROM ProViajes PV
	WHERE PV.IdViaje = @IdViaje AND PV.IdViajeCompuestoPadre IS NOT NULL)
	) FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') as Folios
	
	UNION ALL
	
	SELECT 'Liquidaciones: '+
	STUFF(
	(SELECT ', '+RIGHT('000000'+ LTRIM(RTRIM(Folio)),6)
	FROM 
	(
	SELECT DISTINCT  CAST(PL.Folio AS varchar) AS Folio
	FROM ProViajesTrayectos PVT 
	INNER JOIN ProLiquidaciones PL ON PVT.IdLiquidacion = PL.IdLiquidacion
	WHERE PVT.IdLiquidacion IS NOT NULL AND PVT.IdViaje = @IdViaje
	)FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') as Folios
	
	UNION ALL 
	
	SELECT 'Facturas: '+
	STUFF(
	(SELECT ', '+Factura
	FROM 
	(
	SELECT (CAST(ctd.Documento AS varchar) + ' ' + CAST(RIGHT('00000000'+ LTRIM(RTRIM(cf.Folio)),8) AS varchar) + '-' + CAST(cf.Serie AS varchar)) AS Factura
	FROM ProFacturas PF
	INNER JOIN ProViajesFacturas PVF ON PF.IdFactura = PVF.IdFactura
	INNER JOIN CatFolios AS cf ON PF.IdFolio = cf.IdFolio
	INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
	WHERE PVF.IdViaje = @IdViaje AND PF.CanceladoPor IS NULL
	)FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') as Folios
	
	)FoliosRelacionados            
	FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)'),1,1,'') AS FoliosRelacionados
			)
	IF LEN(@MensajeError) > 1		
			RAISERROR(N'El registro no puede ser cancelado porque tiene ligado los siguientes procesos: %s',
			16,
			1,
			@MensajeError
			)


	IF EXISTS(SELECT pvt.IdViaje FROM ProViajesTrayectos AS pvt INNER JOIN ProCargasAutopistas AS pvc ON pvt.IdViajeTrayecto = pvc.IdViajeTrayecto WHERE pvt.IdViaje = @IdViaje)
		RAISERROR(N'No puede ser cancelado este viaje porque tiene cargas de autopistas registrados',
			16,
			1
			)

	IF EXISTS(SELECT pvt.IdViaje FROM ProViajesTrayectos AS pvt INNER JOIN ProConsumosCombustible AS pvc ON pvt.IdViajeTrayecto = pvc.IdViajeTrayecto WHERE pvt.IdViaje = @IdViaje)
		RAISERROR(N'No puede ser cancelado este viaje porque tiene consumos de combustibles registrados',
			16,
			1
			)						
			
						

	SET @IdFolio = (SELECT IdFolio FROM ProViajesCartasPorte WHERE IdViaje = @IdViaje AND IdViajeCartaPorte = @IdViajeCartaPorte)
	SET @ViajeConCP = (SELECT ViajeConCP FROM ProViajes WHERE IdViaje = @IdViaje)
	
    --se le disminuye el saldo al cliente 
    IF @ViajeConCP = 0
        SET @TotalAnt = (SELECT SubTotal FROM ProViajes WHERE IdViaje = @IdViaje)
    ELSE    
        SET @TotalAnt = (SELECT Total FROM ProViajesCartasPorte WHERE IdViajeCartaPorte = @IdViajeCartaPorte)    
    
    SET @IdMonedaAnt = (SELECT IdMoneda FROM ProViajes WHERE IdViaje = @IdViaje)
    SET @FacturableAnt = (SELECT Facturable FROM ProViajes WHERE IdViaje = @IdViaje)
    SET @IdClienteAnt = (SELECT IdCliente FROM ProViajes WHERE IdViaje = @IdViaje)
    
    IF @FacturableAnt = 1     
    BEGIN
        IF @IdMonedaAnt = 1 OR @IdMonedaAnt = 3
            UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0)  - @TotalAnt WHERE IdCliente = @IdClienteAnt
        ELSE
            UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) - @TotalAnt WHERE IdCliente = @IdClienteAnt
    END        
																	
	UPDATE ProViajes	
	SET MotivoCancelacion = @MotivoCancelacion,	
	CanceladoEl = @CanceladoEl,
	CanceladoPor = @CanceladoPor,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @CanceladoPor,
	IdEstatuViaje = @IdEstatuViaje,
	FechaHoraEstatuViaje = @CanceladoEl
	WHERE IdViaje = @IdViaje
	
	INSERT INTO ProViajesEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatuViaje,IdViaje)
	VALUES(@ModificadoEl,@CanceladoPor,@CanceladoEl,@IdEstatuViaje,@IdViaje)
	
	UPDATE ProViajesCartasPorte SET
	MotivoCancelacion = @MotivoCancelacion,	
	CanceladoEl = @CanceladoEl,
	CanceladoPor = @CanceladoPor,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @CanceladoPor
	WHERE IdViaje = @IdViaje AND IdViajeCartaPorte = @IdViajeCartaPorte

	-- actualiza el estatus del folio
	UPDATE CatFolios SET Estatus = 3 WHERE IdFolio = @IdFolio	
	
	/**********************************************************************
	*			SE ACTUALIZA EL ESTATUS DE LA SOLICITUD
	***********************************************************************/
	SELECT  @IdSolicitudViaje	= psv.IdSolicitudViaje
		  , @Estatus			= psv.Estatus
		FROM ProViajesSolicitudesViajes pvsv
		INNER JOIN ProSolicitudesViajes psv
				ON pvsv.IdSolicitudViaje = psv.IdSolicitudViaje
		WHERE pvsv.IdViaje = @IdViaje;
	
	IF @Estatus = 1
	BEGIN
		-- Si la solicitud ya estaba aceptada pasa a incompleta
		UPDATE ProSolicitudesViajes
			SET 
				  Estatus = 4
				, CantidadEntregada = CantidadEntregada - 1
		WHERE IdSolicitudViaje = @IdSolicitudViaje
	END
	ELSE
	BEGIN
		UPDATE ProSolicitudesViajes
			SET 
				CantidadEntregada = CantidadEntregada - 1
		WHERE IdSolicitudViaje = @IdSolicitudViaje
	END

	--se busca si el remolque1 esta en el mismo viaje en el inve
	--para regresar al ultimo estatus antes de este
	SET @IdUnidadCarga1 = (SELECT IdUnidadCarga1 FROM ProViajes WHERE IdViaje = @IdViaje)
	
	IF (SELECT IdViaje FROM ProInventarioUnidades WHERE IdUnidad = @IdUnidadCarga1) = @IdViaje
	BEGIN
		DECLARE ProInventarioUnidadesHistoricoCursor CURSOR FOR
		SELECT TOP 2 piuh.IdEstatuUnidad,piuh.IdCliente,piuh.IdViaje,piuh.IdUbicacion,piuh.Desde
		FROM ProInventarioUnidadesHistorico AS piuh
		INNER JOIN ProInventarioUnidades AS piu ON piuh.IdInventarioUnidad = piu.IdInventarioUnidad
		WHERE piu.IdUnidad = @IdUnidadCarga1
		ORDER BY piuh.IdInventarioUnidadHistorico desc
		
		OPEN ProInventarioUnidadesHistoricoCursor
		FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
		INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
		FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
		INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
		
		EXEC @return_value = usp_ProInventarioUnidadesActualizar @IdUnidadCarga1,'',@CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde,@CanceladoPor,@ModificadoEl,@IdPeticion,0,''

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al actualizar el inventario de equipo remolque1',
			16,
			1
			)
		
		CLOSE ProInventarioUnidadesHistoricoCursor
		DEALLOCATE ProInventarioUnidadesHistoricoCursor
	END

	SET @IdUnidadDolly = (SELECT IdUnidadDolly FROM ProViajes WHERE IdViaje = @IdViaje)
	
	IF (SELECT IdViaje FROM ProInventarioUnidades WHERE IdUnidad = @IdUnidadDolly) = @IdViaje
	BEGIN
		DECLARE ProInventarioUnidadesHistoricoCursor CURSOR FOR
		SELECT TOP 2 piuh.IdEstatuUnidad,piuh.IdCliente,piuh.IdViaje,piuh.IdUbicacion,piuh.Desde
		FROM ProInventarioUnidadesHistorico AS piuh
		INNER JOIN ProInventarioUnidades AS piu ON piuh.IdInventarioUnidad = piu.IdInventarioUnidad
		WHERE piu.IdUnidad = @IdUnidadDolly
		ORDER BY piuh.IdInventarioUnidadHistorico desc
		
		OPEN ProInventarioUnidadesHistoricoCursor
		FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
		INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
		FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
		INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
		
		EXEC @return_value = usp_ProInventarioUnidadesActualizar @IdUnidadDolly,'',@CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde,@CanceladoPor,@ModificadoEl,@IdPeticion,0,''

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al actualizar el inventario de equipo dolly',
			16,
			1
			)
		
		CLOSE ProInventarioUnidadesHistoricoCursor
		DEALLOCATE ProInventarioUnidadesHistoricoCursor
	END
	
	--act estatus de inv del remolque2
	SET @IdUnidadCarga2 = (SELECT IdUnidadCarga2 FROM ProViajes WHERE IdViaje = @IdViaje)
	
	IF (SELECT IdViaje FROM ProInventarioUnidades WHERE IdUnidad = @IdUnidadCarga2) = @IdViaje
	BEGIN
		DECLARE ProInventarioUnidadesHistoricoCursor CURSOR FOR
		SELECT TOP 2 piuh.IdEstatuUnidad,piuh.IdCliente,piuh.IdViaje,piuh.IdUbicacion,piuh.Desde
		FROM ProInventarioUnidadesHistorico AS piuh
		INNER JOIN ProInventarioUnidades AS piu ON piuh.IdInventarioUnidad = piu.IdInventarioUnidad
		WHERE piu.IdUnidad = @IdUnidadCarga2
		ORDER BY piuh.IdInventarioUnidadHistorico desc
		
		OPEN ProInventarioUnidadesHistoricoCursor
		FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
		INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
		FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
		INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
		
		EXEC @return_value = usp_ProInventarioUnidadesActualizar @IdUnidadCarga2,'',@CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde,@CanceladoPor,@ModificadoEl,@IdPeticion,0,''

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al actualizar el inventario de equipo remolque2',
			16,
			1
			)
		
		CLOSE ProInventarioUnidadesHistoricoCursor
		DEALLOCATE ProInventarioUnidadesHistoricoCursor
	END	
	
	--se recorreo la tabla de trayectos para obtener los camiones
	DECLARE ProViajesTrayectosCursor CURSOR FOR
	SELECT IdUnidadCamion, IdViajeTrayecto, Llegada FROM ProViajesTrayectos WHERE IdViaje = @IdViaje
	
	OPEN ProViajesTrayectosCursor
	FETCH NEXT FROM ProViajesTrayectosCursor
	INTO @IdUnidadCamion, @CursorIdViajeTrayecto, @CursorLlegadaTrayecto
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF (SELECT IdViaje FROM ProInventarioUnidades WHERE IdUnidad = @IdUnidadCamion) = @IdViaje
		BEGIN
			DECLARE ProInventarioUnidadesHistoricoCursor CURSOR FOR
			SELECT TOP 2 piuh.IdEstatuUnidad,piuh.IdCliente,piuh.IdViaje,piuh.IdUbicacion,piuh.Desde
			FROM ProInventarioUnidadesHistorico AS piuh
			INNER JOIN ProInventarioUnidades AS piu ON piuh.IdInventarioUnidad = piu.IdInventarioUnidad
			WHERE piu.IdUnidad = @IdUnidadCamion
			ORDER BY piuh.IdInventarioUnidadHistorico desc
			
			OPEN ProInventarioUnidadesHistoricoCursor
			FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
			INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
			FETCH NEXT FROM ProInventarioUnidadesHistoricoCursor
			INTO @CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde
			
			EXEC @return_value = usp_ProInventarioUnidadesActualizar @IdUnidadCamion,'',@CursorIdEstatuUnidad,@CursorIdCliente,@CursorIdViaje,@CursorIdUbicacion,@CursorDesde,@CanceladoPor,@ModificadoEl,@IdPeticion,0,''

			IF @return_value <> 0
			RAISERROR(N'Ocurrió un error al actualizar el inventario de equipo camión',
				16,
				1
				)
			
			CLOSE ProInventarioUnidadesHistoricoCursor
			DEALLOCATE ProInventarioUnidadesHistoricoCursor
		END


		-- Se agregó seccion que actualiza los odometros, horometros y el historico de los odometros
		-- de las unidades en caso de que el viaje a cancelar tenga llegada, viene de la solicitud 4092
		IF @CursorLlegadaTrayecto IS NOT NULL
		BEGIN
		
			DECLARE  @HorometroUnidad int, @OdometroKMUnidad int, @OdometroMillasUnidad decimal(15,2)

			IF @IdUnidadCamion IS NOT NULL
			BEGIN
				SET @KilometrosTrayecto = (SELECT ISNULL( Kilometros, 0 ) FROM ProViajesTrayectos WHERE IdViajeTrayecto = @CursorIdViajeTrayecto)
				SET @MillasTrayecto = (SELECT ISNULL( Millas, 0 ) FROM ProViajesTrayectos WHERE IdViajeTrayecto = @CursorIdViajeTrayecto)

				UPDATE CatUnidades SET
					Odometro = Odometro - @KilometrosTrayecto,
					OdometroMillas = OdometroMillas - @MillasTrayecto
				WHERE IdUnidad = @IdUnidadCamion

				SET @OdometroKMUnidad = ( SELECT Odometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCamion )
				SET @OdometroMillasUnidad = ( SELECT OdometroMillas FROM CatUnidades WHERE IdUnidad = @IdUnidadCamion )
				SET @HorometroUnidad = ( SELECT Horometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCamion )

				INSERT INTO ProUnidadesOdometros( IdUnidad, Odometro, FechaLectura, OdometroMillas, Horometro )
				VALUES( @IdUnidadCamion, @OdometroKMUnidad, @CanceladoEl, @OdometroMillasUnidad, @HorometroUnidad )
			END

			IF @IdUnidadCarga1 IS NOT NULL AND @IdUnidadCarga1 <> 0
			BEGIN
				UPDATE CatUnidades SET
					Odometro = Odometro - @KilometrosTrayecto,
					OdometroMillas = OdometroMillas - @MillasTrayecto
				WHERE IdUnidad = @IdUnidadCarga1

				IF ( SELECT TipoUnidad FROM CatTiposUnidades WHERE IdTipoUnidad = ( SELECT IdTipoUnidad FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga1 ) ) = 'THERMOKING/CAJA REFRIGERADA'
				BEGIN
					UPDATE CatUnidades SET
					Horometro = Horometro - ( SELECT ISNULL( Horas, 0 ) * 60 AS Horas FROM ProViajesTrayectos WHERE IdViajeTrayecto = @CursorIdViajeTrayecto)
					WHERE IdUnidad = @IdUnidadCarga1
				END

				SET @OdometroKMUnidad = ( SELECT Odometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga1 )
				SET @OdometroMillasUnidad = ( SELECT OdometroMillas FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga1 )
				SET @HorometroUnidad = ( SELECT Horometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga1 )

				INSERT INTO ProUnidadesOdometros( IdUnidad, Odometro, FechaLectura, OdometroMillas, Horometro )
				VALUES( @IdUnidadCarga1, @OdometroKMUnidad, @CanceladoEl, @OdometroMillasUnidad, @HorometroUnidad )
			END

			IF @IdUnidadDolly IS NOT NULL AND @IdUnidadDolly <> 0
			BEGIN
				UPDATE CatUnidades SET
					Odometro = Odometro - @KilometrosTrayecto,
					OdometroMillas = OdometroMillas - @MillasTrayecto
				WHERE IdUnidad = @IdUnidadDolly

				SET @OdometroKMUnidad = ( SELECT Odometro FROM CatUnidades WHERE IdUnidad = @IdUnidadDolly )
				SET @OdometroMillasUnidad = ( SELECT OdometroMillas FROM CatUnidades WHERE IdUnidad = @IdUnidadDolly )
				SET @HorometroUnidad = ( SELECT Horometro FROM CatUnidades WHERE IdUnidad = @IdUnidadDolly )

				INSERT INTO ProUnidadesOdometros( IdUnidad, Odometro, FechaLectura, OdometroMillas, Horometro )
				VALUES( @IdUnidadDolly, @OdometroKMUnidad, @CanceladoEl, @OdometroMillasUnidad, @HorometroUnidad )
			END	

			IF @IdUnidadCarga2 IS NOT NULL AND @IdUnidadCarga2 <> 0
			BEGIN
				UPDATE CatUnidades SET
					Odometro = Odometro - @KilometrosTrayecto,
					OdometroMillas = OdometroMillas - @MillasTrayecto
				WHERE IdUnidad = @IdUnidadCarga2

				IF ( SELECT TipoUnidad FROM CatTiposUnidades WHERE IdTipoUnidad = ( SELECT IdTipoUnidad FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga2 ) ) = 'THERMOKING/CAJA REFRIGERADA'
				BEGIN
					UPDATE CatUnidades SET
					Horometro = Horometro - (SELECT ISNULL( Horas, 0 ) * 60 AS Horas FROM ProViajesTrayectos WHERE IdViajeTrayecto = @CursorIdViajeTrayecto)
					WHERE IdUnidad = @IdUnidadCarga2
				END

				SET @OdometroKMUnidad = ( SELECT Odometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga2 )
				SET @OdometroMillasUnidad = ( SELECT OdometroMillas FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga2 )
				SET @HorometroUnidad = ( SELECT Horometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCarga2 )

				INSERT INTO ProUnidadesOdometros( IdUnidad, Odometro, FechaLectura, OdometroMillas, Horometro )
				VALUES( @IdUnidadCarga2, @OdometroKMUnidad, @CanceladoEl, @OdometroMillasUnidad, @HorometroUnidad )
			END
		END
		
		FETCH NEXT FROM ProViajesTrayectosCursor
		INTO @IdUnidadCamion, @CursorIdViajeTrayecto, @CursorLlegadaTrayecto
	END	
	
	CLOSE ProViajesTrayectosCursor
	DEALLOCATE ProViajesTrayectosCursor

	-- Se desliga el viaje del tablero de contenedores
	Update ProDetalleEntregaContenedores SET IdViaje = NULL WHERE IdViaje = @IdViaje

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

