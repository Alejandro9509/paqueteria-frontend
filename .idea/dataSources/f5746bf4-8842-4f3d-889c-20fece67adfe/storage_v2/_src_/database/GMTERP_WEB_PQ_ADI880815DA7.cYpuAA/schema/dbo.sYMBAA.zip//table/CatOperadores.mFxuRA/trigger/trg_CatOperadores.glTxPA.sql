CREATE TRIGGER [dbo].[trg_CatOperadores]
    ON [dbo].[CatOperadores]
    AFTER UPDATE
AS
BEGIN
    DECLARE @IdOperador int
    --se le integro un top 1 para evitar el error Subquery returned more than 1 value. This is not permitted when the subquery follows =, !=, <, <= , >, >= or when the subquery is used as an expression. con el IdOperador solicitud 006802
    SET @IdOperador = (SELECT top 1 IdOperador FROM deleted)

    IF EXISTS(SELECT TOP 1 IdOperador FROM ProViajesTrayectos WHERE IdOperador = @IdOperador)
    OR EXISTS(SELECT TOP 1 IdOperador FROM ProValesCombustible WHERE IdOperador = @IdOperador)
    BEGIN

        --IF EXISTS(SELECT * FROM
        --INSERTED I
        --JOIN DELETED D ON I.IdOperador = D.IdOperador
        --WHERE (D.RFC <> I.RFC) AND D.EsPermisionario = 1)
        --RAISERROR(N'El nombre/RFC no puede modificarse porque tiene viajes/trayectos asignados',
        --    16,
        --    1
        --    )  

        IF EXISTS(SELECT * FROM
        INSERTED I
        JOIN DELETED D ON I.IdOperador = D.IdOperador
        WHERE D.EsPermisionario = 1 AND D.EsPermisionario <> I.EsPermisionario)
        RAISERROR(N'El check de "Es un Permisionario" no puede modificarse porque tiene viajes/trayectos asignados',
            16,
            1
            )
    END 
    
	IF EXISTS(SELECT TOP 1 IdOperador FROM CatUnidades WHERE IdOperador = @IdOperador)
	BEGIN
        IF EXISTS(SELECT * FROM
        INSERTED I
        JOIN DELETED D ON I.IdOperador = D.IdOperador
        WHERE D.EsPermisionario <> I.EsPermisionario)
        RAISERROR(N'El check de "Es un Permisionario" no puede modificarse porque tiene unidad asignada',
            16,
            1
            )	
	END
	
	IF EXISTS(SELECT TOP 1 IdOperador FROM CatRutasTrayectosPermisionarios WHERE IdOperador = @IdOperador)
	BEGIN
        IF EXISTS(SELECT * FROM
        INSERTED I
        JOIN DELETED D ON I.IdOperador = D.IdOperador
        WHERE D.EsPermisionario <> I.EsPermisionario)
        RAISERROR(N'El check de "Es un Permisionario" no puede modificarse porque tiene tarifas capturadas',
            16,
            1
            )	
	END	
	
END
go

