CREATE PROCEDURE [dbo].[usp_CatDatosEliminar]
	@IdDato int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
				
	DELETE FROM CatDatos
	WHERE IdDato = @IdDato
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

