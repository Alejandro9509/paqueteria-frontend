CREATE PROCEDURE [dbo].[usp_CatTiposCambioImportar]
	@IdPeticion varchar(100),
	@dsTiposCambio XML,
	@Sustituir bit,
	@IdUsuario int,
	@FechaUsuario datetime
	
	/*************************************************************************************************************************************
	@IdPeticion varchar(100),
	@dsTiposCambio XML,
	@Sustituir bit,
	@IdUsuario int,
	@FechaUsuario datetime

	Creado por:  Luis Edgar Ramos Cadena
	Fecha de Creacion: 16/02/2021
	Fecha de Modificacion : 19/02/2021
	Versión  8.0.59.03
	Solicitud 3849
	
	Se creo para la importacion de tipos de cambio
	***************************************/
AS
DECLARE @TemporalXML TABLE
(	
Fecha datetime ,
TipoCambio money
)
DECLARE
@CantidadRegistrosAgregar int,
@CantidadRegistrosModificar int

BEGIN TRY
	BEGIN TRANSACTION

	INSERT INTO @TemporalXML (Fecha,TipoCambio)
	Select  
	 Fecha = Node.Data.value('(ATT_Fecha)[1]', 'datetime')
	,TipoCambio =	Node.Data.value('(ATT_TipoCambio)[1]', 'money') 
	FROM   @dsTiposCambio.nodes('/WEBDEV_TABLE/TiposCambio') Node(Data) 


	SET @CantidadRegistrosAgregar = (SELECT COUNT(Fecha) FROM @TemporalXML WHERE Fecha NOT IN(SELECT CTC.Fecha FROM CatTiposCambio as CTC WHERE CAST(CTC.Fecha AS DATE) = CAST(Fecha AS  DATE)) )
	SET @CantidadRegistrosModificar = (SELECT COUNT(Fecha) FROM @TemporalXML WHERE Fecha IN(SELECT CTC.Fecha FROM CatTiposCambio as CTC WHERE CAST(CTC.Fecha AS DATE) = CAST(Fecha AS  DATE)) )

	INSERT INTO CatTiposCambio(Fecha,TipoCambio,CreadoEl,CreadoPor)
	SELECT 
	Fecha,
	TipoCambio,
	@FechaUsuario,
	@IdUsuario
	FROM @TemporalXML
	WHERE 
	Fecha NOT IN(SELECT CTC.Fecha FROM CatTiposCambio as CTC WHERE CAST(CTC.Fecha AS DATE) = CAST(Fecha AS  DATE))

	IF @Sustituir = 1
	BEGIN 
		UPDATE CTC SET
		CTC.Fecha = Tp.Fecha,
		CTC.TipoCambio = Tp.TipoCambio,
		CTC.ModificadoEl = @FechaUsuario,
		CTC.ModificadoPor = @IdUsuario
		FROM
		CatTiposCambio AS CTC
		INNER JOIN @TemporalXML AS Tp ON CAST(CTC.Fecha AS DATE) = CAST(Tp.Fecha AS DATE)
	END
	ELSE	
    BEGIN	
        SET @CantidadRegistrosModificar = 0	
    END 

	SELECT @CantidadRegistrosAgregar AS CantidadRegistrosAgregar,@CantidadRegistrosModificar AS CantidadRegistrosModificar

COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

