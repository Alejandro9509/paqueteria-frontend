CREATE PROCEDURE [dbo].[usp_CatMecanicosEliminar]
@IdMecanico int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMecanico,0)= 0
	RAISERROR(N'El identificador de mecánico es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT IdMecanico FROM ProOrdenesServiciosDetalles WHERE IdMecanico = @IdMecanico)
    RAISERROR(N'No es posible eliminar mecánico porque tiene ordenes de servicio ligadas',
            16,
            1
            )
            
            
	-- IF EXISTS(SELECT TOP 1 * FROM CatCuentasBancarias WHERE IdBanco = @IdBanco)
	--		RAISERROR(N'El banco tiene cuentas bancarias ligados, no es posible eliminarlo',
	--			16,
	--			1
	--			)

			
		DELETE CatMecanicos
		WHERE 	IdMecanico=@IdMecanico
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

