CREATE TRIGGER [dbo].[trg_CatArticulos]
   ON  [dbo].[CatArticulos]
   AFTER UPDATE
AS 
BEGIN	
---- Valida si ya tiene movimiento
---- catalogos	
	IF EXISTS(Select top 1 IdArticulo  from CatPaquetesServiciosPartes WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		OR EXISTS(Select top 1 IdArticulo from CatServiciosPartes WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.EsLlanta <> D.EsLlanta)
			RAISERROR(N'El check es llanta no se puede modificar porque ya esta ligado a catálogo de servicios o paquetes de servicio',
				16,
				1
				)
				
			IF EXISTS(SELECT * FROM INSERTED I
				JOIN DELETED D ON I.IdModeloLlanta <> D.IdModeloLlanta)
				RAISERROR(N'El modelo de llanta no se puede modificar porque ya esta ligado a catálogo de servicios o paquetes de servicio',
					16,
					1
					)	
		END	
	

---- requisiciones / ordenes de compra
	IF EXISTS(Select top 1 IdArticulo from ProRequisicionConceptos WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		OR EXISTS(Select top 1 IdArticulo from ProOrdenCompraConceptos  WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.EsLlanta <> D.EsLlanta)
			RAISERROR(N'El check es llanta no se puede modificar porque ya esta ligado a requisiciones o ordenes de compra',
				16,
				1
				)
		
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.IdModeloLlanta <> D.IdModeloLlanta)
			RAISERROR(N'El modelo de llanta no se puede modificar porque ya esta ligado a requisiciones o ordenes de compra',
				16,
				1
				)		
		END	
		
---- ordenes de servicio
	IF EXISTS(Select top 1 IdArticulo from ProOrdenesServiciosPartes  WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.EsLlanta <> D.EsLlanta)
			RAISERROR(N'El check es llanta no se puede modificar porque ya esta ligado a ordenes de servicio',
				16,
				1
				)
				
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.IdModeloLlanta <> D.IdModeloLlanta)
			RAISERROR(N'El modelo de llanta no se puede modificar porque ya esta ligado a ordenes de servicio',
				16,
				1
				)		
		END	

---- movimiento de almacén
	IF EXISTS(Select top 1 IdArticulo from ProComprasConceptos WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		OR EXISTS(Select top 1 IdArticulo from ProInventarioAlmacen  WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		OR EXISTS(Select top 1 IdArticulo from ProMovimientosAlmacenConceptos  WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		OR EXISTS(Select top 1 IdArticulo from ProMovimientosAlmacenConceptosPEPS  WHERE IdArticulo = (SELECT IdArticulo FROM deleted))
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
				JOIN DELETED D ON I.EsLlanta <> D.EsLlanta)
				RAISERROR(N'El check es llanta no se puede modificar porque ya cuenta con movimientos de almacén',
					16,
					1
					)
					
			IF EXISTS(SELECT * FROM INSERTED I
				JOIN DELETED D ON I.IdModeloLlanta <> D.IdModeloLlanta)
				RAISERROR(N'El modelo de llanta no se puede modificar porque ya cuenta con movimientos de almacén',
					16,
					1
					)				
				
				
		END	
END
go

