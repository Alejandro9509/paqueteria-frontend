CREATE PROCEDURE [dbo].[usp_CatSupervisoresRutasPersonalModificar]
	@IdSupervisorRutaPersonal int,
	@Codigo int,
	@Nombre varchar(100),
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdSupervisorRutaPersonal,0)= 0
		RAISERROR(N'El identificador del Supervisor es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del Turno es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatSupervisoresRutasPersonal WHERE Codigo = @Codigo And IdSupervisorRutaPersonal <> @IdSupervisorRutaPersonal)
		RAISERROR(N'El Codigo ya existe',
			16,
			1
			)	
				
	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El Nombre es un campo requerido',
			16,
			1
			)
	

			
	UPDATE CatSupervisoresRutasPersonal SET 
		Codigo = @Codigo,
		Nombre = @Nombre,
		CreadoPor = @CreadoPor,
		CreadoEl = @CreadoEl
	WHERE IdSupervisorRutaPersonal = @IdSupervisorRutaPersonal
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

