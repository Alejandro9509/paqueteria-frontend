
CREATE PROCEDURE [dbo].[usp_ProLiquidacionesTPersonalGenerar]
	@Folio int,
	@IdOperador int,
	@IdUnidadCamion int,
	@TipoLiquidacion tinyint,
	@Fecha datetime,
	@FechaInicial datetime,
	@FechaFinal datetime,
	@Dias int,
	@CerradaEl	datetime,
	@CerradaPor	int,		
	@OdometroInicial int,
	@OdometroFinal int,
	@KilometrosReales int,
	@KilometrosEstimados int,
	@RendimientoReal	decimal(15, 2),	
	@RendimientoUnidad decimal(15,2),
	@Observaciones varchar(500),
	@Sueldo	money,
	@TotalPercepciones	money,
	@TotalDeducciones	money,	
	@NetoAPagar	money,
	@CreadoPor int,
	@CreadoEl datetime,
	@Ingresos	money,
	@Gastos	money,
	@GastosConIVA	money,	
	@GastosSinIVA	money,
	@GastosCreditoConIVA	money,	
	@GastosCreditoSinIVA	money,
	@UtilidadBruta	money,	
	@PorcentajeUtilidad	decimal(15, 2),		
	@CombustibleInicial decimal(15,2),
	@CombustibleCargado	decimal(15, 2),
	@ImporteCombustibleCargado	money,	
	@CombustibleAutorizado	decimal(15, 2),
	@ImporteCombustibleAutorizado	money,	
	@DiferenciaCombustibleAutorizadoVsCargado	decimal(15, 2),
	@ImporteDiferenciaCombustibleAutorizadoVsCargado	money,	
	@CombustibleFinal	decimal(15, 2),
	@CombustibleFaltante	decimal(15, 2),
	@ImporteCargoPorCombustibleFaltante	money,
	@Anticipos	money,
	@DiferenciaAnticiposGastos	money,
	@CostoPorKMS	decimal(15, 4),
	@IngresoPorKMS	decimal(15, 4),	
	@Productividad	decimal(15, 4),	
	@dsProViajesTrayectos ntext,
	@dsProLiquidacionesDeducciones ntext,
	@dsProLiquidacionesPercepciones ntext,	
	@IdPeticion varchar(100),
	@IdMoneda int,
	@TipoCambio money,
	@GenerarDescuentoPorCombustibleFaltante bit,
	@DiasRealesTrabajados int,
	@IdMonedaReferencia int,
	@TotalDeduccionesNoAfectanNetoAPagar decimal(15,2),
	@OdometroInicialMillas decimal(15,2),
	@OdometroFinalMillas decimal(15,2),
	@MillasReales decimal(15,2),
	@MillasEstimadas decimal(15,2),
	@CombustibleInicialGalones decimal(15,2),
	@CombustibleCargadoGalones decimal(15,2),
	@CombustibleAutorizadoGalones decimal(15,2),
	@DiferenciaCombustibleAutorizadoVsCargadoGalones decimal(15,2),
	@CombustibleFinalGalones decimal(15,2),
	@CombustibleFaltanteGalones decimal(15,2),
	@FactorKmsMi int,
	@IdAnticipoLigado int = NULL
AS
DECLARE
/*
Descripción: Generar liquidaciones de traporte de personal.

Creado por: Francisco Villela
Fecha de Creacion: 22/07/2020
Versión: 8.0.52.15
*/
	@IdLiquidacion int,
	@docHandle int,
	@IdLiquidacionDeduccion int,
	@ATT_IdDeduccion int,
	@ATT_Importe money,
	@ATT_IdDescuentoOperador int,
	@ATT_ImporteOriginal money,
	@ATT_ImporteGravado money,
	@ATT_ImporteExento money,
	@ATT_Modificado bit,
	@ATT_IdMoneda int,
	@ATT_TipoCambio money, 
	@ATT_ImporteGravadoOriginal money,
	@ATT_ImporteExentoOriginal money,
	@FolioDescto int,
	@return_value int,
	@ObservacionesDescuento varchar(500),
	@IdDescuentoOperador int--recibe el id del desucneot recien agregado por descuento por faltante de combustible
SET XACT_ABORT ON 
	
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@Folio,0) <= 0
			RAISERROR(N'El folio es un campo requerido',
				16,
				1
				)		

		IF EXISTS(SELECT Folio FROM ProLiquidacionesTPersonal WHERE Folio = @Folio )
			RAISERROR(N'El folio de la liquidación ya existe',
				16,
				1
				)

		IF ISNULL(@IdOperador,0) <= 0
			RAISERROR(N'El operador es un campo requerido',
				16,
				1
				)

		--se quito porque el idunidad va estar parametrizado
		--IF ISNULL(@IdUnidadCamion,0) <= 0
		--	RAISERROR(N'La unidad es un campo requerido',
		--		16,
		--		1
		--		)	

		IF ISNULL(@TipoLiquidacion,0) <= 0
			RAISERROR(N'El tipo de liquidación es un campo requerido',
				16,
				1
				)					

		IF ISDATE(@Fecha) = 0
			RAISERROR(N'La fecha es un campo requerido',
				16,
				1
				)

		IF ISDATE(@FechaInicial) = 0
			RAISERROR(N'La fecha inicial es un campo requerido',
				16,
				1
				)

		IF ISDATE(@FechaFinal) = 0
			RAISERROR(N'La fecha final es un campo requerido',
				16,
				1
				)

		IF IsNull(@OdometroInicial,0) > ISNULL(@OdometroFinal,0)
				RAISERROR(N'El odómetro inical no puede ser mayor al odómetro final',
					16,
					1
					)

		IF ISNULL(@IdMoneda,0) <= 0
			RAISERROR(N'La moneda es un campo requerido',
				16,
				1
				)
					
		--SE VALIDA QUE LOS KMS REALES,ODOMETRO Y VIAJES SEAN REQUERIDOS UNICAMENTE CUANDO ESTE CERRADA LA LIQ. CAMBIO INDIRECTO SOL-2686
		IF @CerradaEl IS NOT NULL
		BEGIN
			
					
			IF ISNULL(@OdometroFinal,0) <= 0
				RAISERROR(N'El odómetro final es un campo requerido',
					16,
					1
					)	
								
			IF ISNULL(@KilometrosReales,0) <= 0
				RAISERROR(N'Los kilómetros reales son un campo requerido',
					16,
					1
					)
			
			IF @dsProViajesTrayectos IS NULL
				RAISERROR(N'Los viajes a liquidar son requeridos',
					16,
					1
					)	

			IF @CerradaEl < @Fecha
				RAISERROR(N'La fecha de cierre no puede ser menor que la fecha de la liquidación',
					16,
					1
					)					
		END

		--IF @dsProLiquidacionesDeducciones IS NULL
		--	RAISERROR(N'Los conceptos de deducciones son requeridos',
		--		16,
		--		1
		--		)				

		IF @dsProLiquidacionesPercepciones IS NULL
			RAISERROR(N'Los conceptos de percepciones son requeridos',
				16,
				1
				)

		--/*Solicitud 1929*/
		--IF @IdAnticipoLigado <= 0
		--BEGIN
		--	SET @IdAnticipoLigado = NULL
		--END
		
		--/*Solicitud 1929 Validacion para concurrencia*/
		--IF EXISTS(SELECT IdAnticipo FROM ProAnticipos WHERE IdAnticipo = @IdAnticipoLigado AND IdLiquidacionAsignada IS NOT NULL) AND @IdAnticipoLigado IS NOT NULL
		--	BEGIN
		--		RAISERROR(N'El anticipo generado por Diferencia de Gastos fue modificado favor de validar',
		--		16,
		--		1
		--		)
		--	END

		IF @IdUnidadCamion = 0 
			SET @IdUnidadCamion = NULL
		IF @IdMonedaReferencia = 0
			SET @IdMonedaReferencia = NULL
			

		INSERT INTO ProLiquidacionesTPersonal(Anticipos,CombustibleAutorizado,CombustibleCargado,CombustibleFaltante,CombustibleFinal,CombustibleInicial,CostoPorKMS,
		CreadoEl,CreadoPor,Dias,DiferenciaAnticiposGastos,DiferenciaCombustibleAutorizadoVsCargado,Fecha,FechaFinal,FechaInicial,Folio,Gastos,GastosConIVA,
		GastosCreditoConIVA,GastosCreditoSinIVA,GastosSinIVA,IdOperador,IdUnidadCamion,ImporteCargoPorCombustibleFaltante,ImporteCombustibleAutorizado,
		ImporteCombustibleCargado,ImporteDiferenciaCombustibleAutorizadoVsCargado,IngresoPorKMS,Ingresos,KilometrosEstimados,KilometrosReales,NetoAPagar,
		Observaciones,OdometroFinal,OdometroInicial,PorcentajeUtilidad,Productividad,RendimientoReal,RendimientoUnidad,Sueldo,TipoLiquidacion,
		TotalDeducciones,TotalPercepciones,UtilidadBruta,IdMoneda,TipoCambio,DiasRealesTrabajados,IdMonedaReferencia,TotalDeduccionesNoAfectanNetoAPagar,
		OdometroInicialMillas,OdometroFinalMillas,MillasReales,MillasEstimadas,CombustibleInicialGalones,CombustibleCargadoGalones,CombustibleAutorizadoGalones,
		DiferenciaCombustibleAutorizadoVsCargadoGalones,CombustibleFinalGalones,CombustibleFaltanteGalones,FactorKmsMi)
		VALUES(@Anticipos,@CombustibleAutorizado,@CombustibleCargado,@CombustibleFaltante,@CombustibleFinal,@CombustibleInicial,@CostoPorKMS,
		@CreadoEl,@CreadoPor,@Dias,@DiferenciaAnticiposGastos,@DiferenciaCombustibleAutorizadoVsCargado,@Fecha,@FechaFinal,@FechaInicial,@Folio,@Gastos,@GastosConIVA,
		@GastosCreditoConIVA,@GastosCreditoSinIVA,@GastosSinIVA,@IdOperador,@IdUnidadCamion,@ImporteCargoPorCombustibleFaltante,@ImporteCombustibleAutorizado,
		@ImporteCombustibleCargado,@ImporteDiferenciaCombustibleAutorizadoVsCargado,@IngresoPorKMS,@Ingresos,@KilometrosEstimados,@KilometrosReales,@NetoAPagar,
		@Observaciones,@OdometroFinal,@OdometroInicial,@PorcentajeUtilidad,@Productividad,@RendimientoReal,@RendimientoUnidad,@Sueldo,@TipoLiquidacion,
		@TotalDeducciones,@TotalPercepciones,@UtilidadBruta,@IdMoneda,@TipoCambio,@DiasRealesTrabajados,@IdMonedaReferencia,@TotalDeduccionesNoAfectanNetoAPagar,
		@OdometroInicialMillas,@OdometroFinalMillas,@MillasReales,@MillasEstimadas,@CombustibleInicialGalones,@CombustibleCargadoGalones,@CombustibleAutorizadoGalones,
		@DiferenciaCombustibleAutorizadoVsCargadoGalones,@CombustibleFinalGalones,@CombustibleFaltanteGalones,@FactorKmsMi)
		
		SET @IdLiquidacion = (SELECT IDENT_CURRENT('ProLiquidacionesTPersonal'))

        --seccion para agregar el idmovimientobancario a paremtros y poder obtenerlo de lado del web
        IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdLiquidacionTPersonal' AND IdUsuario = @CreadoPor)
        INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdLiquidacionTPersonal',@IdLiquidacion,@CreadoPor)
        ELSE
        UPDATE SisParametrosPagina SET Parametros = @IdLiquidacion WHERE Pagina = 'IdLiquidacionTPersonal' AND IdUsuario = @CreadoPor        		
		
		IF @CerradaEl IS NOT NULL AND @NetoAPagar < 0
		BEGIN
			SET @FolioDescto = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM CatDescuentosOperadores)
			SET @NetoAPagar = @NetoAPagar*(-1)
			
			EXEC @return_value = usp_CatDescuentosOperadoresTPersonalRegistrar @FolioDescto,@IdOperador,4,2,@Fecha,1,@NetoAPagar,0,0,@IdMoneda,@NetoAPagar,@CreadoEl,@CreadoPor,@IdPeticion,@IdLiquidacion,'',0
			
			IF @return_value <= 0
			RAISERROR(N'Ocurrió un error al registrar el descuento por adeudo de liquidación',
				16,
				1
				)		

		END

		IF(SELECT Odometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCamion) < @OdometroInicial
		BEGIN
			UPDATE CatUnidades SET
			Odometro = @OdometroInicial
			WHERE IdUnidad = @IdUnidadCamion
			
			INSERT INTO ProUnidadesOdometros(IdUnidad,Odometro,FechaLectura)
			VALUES(@IdUnidadCamion,@OdometroInicial,@Fecha)
		END	
		
		--actualiza los idliquidacion de los viajes trayectos			
		IF @dsProViajesTrayectos IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProViajesTrayectos

			SELECT ATT_IdViajeTrayecto,ATT_PorcentajeLiquidar,ATT_ImporteLiquidar,ATT_ComisionPermisionario,ATT_IdTablaValorCalculo,ATT_PorcentajeValorCalculo
			INTO #TempProProViajesTrayectos
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProViajesTrayectos',2) 
			WITH (ATT_IdViajeTrayecto int,ATT_PorcentajeLiquidar decimal(15,2),ATT_ImporteLiquidar money,ATT_ComisionPermisionario money,ATT_IdTablaValorCalculo int,ATT_PorcentajeValorCalculo decimal(10,6))

			EXEC sp_xml_removedocument @docHandle
			
			IF EXISTS(SELECT IdRecorridoParada FROM ProRecorridoParadas WHERE IdRecorridoParada IN(SELECT ATT_IdViajeTrayecto FROM #TempProProViajesTrayectos) AND (IdLiquidacion IS NOT NULL AND IdLiquidacion <> @IdLiquidacion))
				RAISERROR(N'Verifique que los recorridos a liquidar no hayan sido liquidados por otro usuario',
					16,
					1
					)			
			
			UPDATE ProRecorridoParadas SET
				ProRecorridoParadas.IdLiquidacion = @IdLiquidacion,
				ProRecorridoParadas.PorcentajeLiquidar = #TempProProViajesTrayectos.ATT_PorcentajeLiquidar,
				ProRecorridoParadas.ImporteLiquidar = #TempProProViajesTrayectos.ATT_ImporteLiquidar
			FROM ProRecorridoParadas 
			INNER JOIN #TempProProViajesTrayectos ON ProRecorridoParadas.IdRecorridoParada = #TempProProViajesTrayectos.ATT_IdViajeTrayecto
		END

		----Solicitud 1929 Se actualiza un campo que liga un anticipo con una liquidacion sin depender de un trayecto
		--IF @IdAnticipoLigado > 0 AND @IdAnticipoLigado IS NOT NULL
		--BEGIN
		--	UPDATE ProAnticipos SET IdLiquidacionAsignada = @IdLiquidacion WHERE IdAnticipo = @IdAnticipoLigado
		--END
		
		--se act el esttaus de cerrada despues de act los trayectos por el trigger de viajes trayectos liquidados
		UPDATE ProLiquidacionesTPersonal SET
			CerradaEl = @CerradaEl,
			CerradaPor = @CerradaPor
		WHERE IdLiquidacionTPersonal = @IdLiquidacion

		--se genera descuento x faltante de diesel
		IF @CerradaEl IS NOT NULL AND @ImporteCargoPorCombustibleFaltante > 0 AND @GenerarDescuentoPorCombustibleFaltante = 1
		BEGIN
			SET @FolioDescto = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM CatDescuentosOperadoresTPersonal)
			SET @ObservacionesDescuento = 'DESCUENTO POR FALTANTE DE COMBUSTIBLE '+CAST(@CombustibleFaltante as varchar)+'LTS LIQ.'+CAST(@Folio as varchar)
			EXEC @IdDescuentoOperador = usp_CatDescuentosOperadoresTPersonalRegistrar @FolioDescto,@IdOperador,5,2,@Fecha,1,@ImporteCargoPorCombustibleFaltante,0,0,@IdMoneda,@ImporteCargoPorCombustibleFaltante,@CreadoEl,@CreadoPor,@IdPeticion,@IdLiquidacion,@ObservacionesDescuento,0
			
			IF @IdDescuentoOperador <= 0
			RAISERROR(N'Ocurrió un error al registrar el descuento por faltante de combustible',
				16,
				1
				)		

		END	
			
		--graba los conceptos de deduccion
		IF @dsProLiquidacionesDeducciones IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProLiquidacionesDeducciones

			SELECT ATT_IdDeduccion, ATT_Importe,ATT_IdDescuentoOperador,ATT_ImporteOriginal,ATT_ImporteGravado,ATT_ImporteExento,ATT_Modificado,ATT_IdMoneda,ATT_TipoCambio,ATT_ImporteGravadoOriginal,ATT_ImporteExentoOriginal
			INTO #TempProLiquidacionesDeducciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProLiquidacionesDeducciones',2) 
			WITH (ATT_IdDeduccion int,ATT_Importe money,ATT_IdDescuentoOperador int,ATT_ImporteOriginal money,ATT_ImporteGravado money,ATT_ImporteExento money,ATT_Modificado bit,ATT_IdMoneda int,ATT_TipoCambio money,ATT_ImporteGravadoOriginal money,ATT_ImporteExentoOriginal money)

			EXEC sp_xml_removedocument @docHandle
			
			-- SI EN LA LIQUIDAICON SE PAGA EL DESCUENTO POR FALTANTE DE COMBUSTIBLE SE ACTUALIZA EL ID DE REFERENCIA
			IF ISNULL(@IdDescuentoOperador,0) > 0 
				UPDATE #TempProLiquidacionesDeducciones SET ATT_IdDescuentoOperador = @IdDescuentoOperador WHERE ATT_IdDescuentoOperador = 0 AND ATT_IdDeduccion = 5
			
			DECLARE ProLiquidacionesDeduccionesCursor CURSOR FOR
			SELECT * FROM #TempProLiquidacionesDeducciones 

			OPEN ProLiquidacionesDeduccionesCursor
			FETCH NEXT FROM ProLiquidacionesDeduccionesCursor
			INTO @ATT_IdDeduccion,@ATT_Importe,@ATT_IdDescuentoOperador,@ATT_ImporteOriginal,@ATT_ImporteGravado,@ATT_ImporteExento,@ATT_Modificado,@ATT_IdMoneda,@ATT_TipoCambio,@ATT_ImporteGravadoOriginal,@ATT_ImporteExentoOriginal
		
			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @ATT_IdDescuentoOperador = 0 
					SET @ATT_IdDescuentoOperador = NULL
					
				--IF @ATT_Modificado = 0
				--	SET @ATT_Modificado = NULL
					
				IF @ATT_IdMoneda = 0
					SET @ATT_IdMoneda = NULL
					
				--IF @ATT_TipoCambio = 0
				--	SET @ATT_TipoCambio = NULL
					
				--IF @ATT_ImporteOriginal = 0    Se comentaron porque se detecto error al calcular, no lo podia hacer por estar null Sol:7820
				--	SET @ATT_ImporteOriginal = NULL

				--IF @ATT_ImporteGravadoOriginal = 0
				--	SET @ATT_ImporteGravadoOriginal = NULL
					
				--IF @ATT_ImporteExentoOriginal = 0
				--	SET @ATT_ImporteExentoOriginal = NULL																										
					
				INSERT INTO ProLiquidacionesTPersonalDeducciones(CreadoEl,CreadoPor,IdDeduccion,IdLiquidacion,Importe,IdDescuentoOperador,ImporteGravado,ImporteExento,Modificado,IdMoneda,TipoCambio,ImporteOriginal,ImporteGravadoOriginal,ImporteExentoOriginal)
				VALUES(@CreadoEl,@CreadoPor,@ATT_IdDeduccion,@IdLiquidacion,@ATT_Importe,@ATT_IdDescuentoOperador,@ATT_ImporteGravado,@ATT_ImporteExento,@ATT_Modificado,@ATT_IdMoneda,@ATT_TipoCambio,@ATT_ImporteOriginal,@ATT_ImporteGravadoOriginal,@ATT_ImporteExentoOriginal)				
				
				IF ISNULL(@ATT_IdDescuentoOperador,0) > 0 AND @CerradaEl IS NOT NULL
				BEGIN
					SET @IdLiquidacionDeduccion = (SELECT IDENT_CURRENT('ProLiquidacionesTPersonalDeducciones'))
					
					INSERT INTO CatDescuentosOperadoresTPersonalPagos(IdDescuentoOperador,IdLiquidacionDeduccion,Importe)
					VALUES(@ATT_IdDescuentoOperador,@IdLiquidacionDeduccion,@ATT_ImporteOriginal)
					
					UPDATE CatDescuentosOperadoresTPersonal 
						SET ImporteDescontado = ISNULL(ImporteDescontado,0)+@ATT_ImporteOriginal
					WHERE IdDescuentoOperador = @ATT_IdDescuentoOperador

					IF EXISTS(SELECT Folio FROM CatDescuentosOperadoresTPersonal WHERE IdDescuentoOperador = @ATT_IdDescuentoOperador AND ISNULL(ImporteDescontado,0) > ImporteTotalPorDescontar AND TipoDescuento = 2)
					RAISERROR(N'El importe descontado del descuento es mayor al importe total por descontar',
						16,
						1
						)
				END	

				FETCH NEXT FROM ProLiquidacionesDeduccionesCursor
				INTO @ATT_IdDeduccion,@ATT_Importe,@ATT_IdDescuentoOperador,@ATT_ImporteOriginal,@ATT_ImporteGravado,@ATT_ImporteExento,@ATT_Modificado,@ATT_IdMoneda,@ATT_TipoCambio,@ATT_ImporteGravadoOriginal,@ATT_ImporteExentoOriginal
			END

			CLOSE ProLiquidacionesDeduccionesCursor
			DEALLOCATE ProLiquidacionesDeduccionesCursor						
		END
		
		DECLARE @ImporteDeduccion money
		SET @ImporteDeduccion = (SELECT ISNULL(ROUND(SUM(ProLiquidacionesTPersonalDeducciones.Importe),2),0) FROM ProLiquidacionesTPersonalDeducciones LEFT JOIN CatDescuentosOperadoresTPersonal ON ProLiquidacionesTPersonalDeducciones.IdDescuentoOperador = CatDescuentosOperadoresTPersonal.IdDescuentoOperador WHERE ProLiquidacionesTPersonalDeducciones.IdLiquidacion = @IdLiquidacion AND ISNULL(CatDescuentosOperadoresTPersonal.NoAfectaNetoAPagar,0) <> 1)
		
		IF @ImporteDeduccion <> ROUND((@TotalDeducciones),2) -- Se modifico por parte de la solicitud 11690
		RAISERROR(N'La suma de los importes de los conceptos de deducción no son iguales al total de deducción',
			16,
			1
			)				
		
		--actualiza los conceptos de percepcion
		IF @dsProLiquidacionesPercepciones IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProLiquidacionesPercepciones

			SELECT ATT_IdPercepcion, ATT_Importe,ATT_ConsiderarCalculoISPT,ATT_ConsiderarCalculoIMSS,ATT_ImporteGravado,ATT_ImporteExento
			INTO #TempProLiquidacionesPercepciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProLiquidacionesPercepciones',2) 
			WITH (ATT_IdPercepcion int,ATT_Importe money,ATT_ConsiderarCalculoISPT bit,ATT_ConsiderarCalculoIMSS bit,ATT_ImporteGravado money,ATT_ImporteExento money)

			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO ProLiquidacionesTPersonalPercepciones(CreadoEl,CreadoPor,IdPercepcion,IdLiquidacion,Importe,ConsiderarCalculoIMSS,ConsiderarCalculoISPT,ImporteGravado,ImporteExento)
			SELECT @CreadoEl,@CreadoPor,ATT_IdPercepcion,@IdLiquidacion,ATT_Importe,ATT_ConsiderarCalculoIMSS,ATT_ConsiderarCalculoISPT,ATT_ImporteGravado,ATT_ImporteExento
			FROM #TempProLiquidacionesPercepciones
		END
		
		IF (SELECT ISNULL(SUM(Importe),0) FROM ProLiquidacionesTPersonalPercepciones WHERE IdLiquidacion = @IdLiquidacion) <> @TotalPercepciones
		RAISERROR(N'La suma de los importes de los conceptos de percepción no son iguales al total de percepción',
			16,
			1
			)	
				
				
	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

