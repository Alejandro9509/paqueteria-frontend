CREATE TRIGGER [dbo].[trg_ProViajesTrayectosConAutopistas]
    ON dbo.ProViajesTrayectos
    AFTER UPDATE
AS
BEGIN
        
        IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViajeTrayecto = D.IdViajeTrayecto
        WHERE (I.CodigoUnidadCamion <> D.CodigoUnidadCamion OR I.IdUnidadCamion <> D.IdUnidadCamion)
        AND EXISTS(SELECT IdCargaAutopista FROM ProCargasAutopistas WHERE ProCargasAutopistas.IdViajeTrayecto = I.IdViajeTrayecto))
        BEGIN            
            RAISERROR(N'No puede modificarse el viaje trayecto porque ya tiene autopistas referenciadas',
                16,
                1
                )
        END                  
END
go

