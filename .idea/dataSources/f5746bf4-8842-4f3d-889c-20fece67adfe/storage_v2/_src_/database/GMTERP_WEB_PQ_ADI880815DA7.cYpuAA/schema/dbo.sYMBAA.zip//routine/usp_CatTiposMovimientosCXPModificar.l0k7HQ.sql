CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosCXPModificar]
@IdTipoMovimientoCXP Int,
@Codigo int,	  
@TipoMovimiento	varchar(50),	  
@DesminuirSaldoProveedor bit,	
@AfectaSaldoBanco bit,	
@ModificadoEl	datetime,	
@ModificadoPor	int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdTipoMovimientoCXP,0) = 0 
		RAISERROR(N'Identificador de tipo de movimiento CxP es un campo requerido',
			16,
			1
			)	
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de tipo de movimiento cuentas por pagar es un campo requerido',
			16,
			1
			)
				
	IF ISNULL(@TipoMovimiento,'')= ''
		RAISERROR(N'La descripción de movimiento cuentas por pagar es un campo requerido',
			16,
			1
			)
			
	UPDATE CatTiposMovimientosCXP
	 SET TipoMovimiento = @TipoMovimiento,
		 DesminuirSaldoProveedor = @DesminuirSaldoProveedor,
		 AfectaSaldoBanco = @AfectaSaldoBanco,
		 ModificadoEl = @ModificadoEl,
		 ModificadoPor = @ModificadoPor
	WHERE CatTiposMovimientosCXP.IdTipoMovimientoCXP =@IdTipoMovimientoCXP

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

