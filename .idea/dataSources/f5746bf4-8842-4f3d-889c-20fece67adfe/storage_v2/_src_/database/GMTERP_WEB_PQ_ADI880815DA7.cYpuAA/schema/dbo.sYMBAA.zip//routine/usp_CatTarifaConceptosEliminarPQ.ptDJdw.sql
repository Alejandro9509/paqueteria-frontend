

CREATE PROCEDURE [dbo].[usp_CatTarifaConceptosEliminarPQ]
	@IdTarifaConcepto INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdTarifaConcepto,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de Concepto de la Tarifa es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		DELETE FROM CatTarifaConceptosPQ
		WHERE IdTarifaConceptos = @IdTarifaConcepto
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END


go

