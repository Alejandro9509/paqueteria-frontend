
CREATE PROCEDURE [dbo].[usp_CatMonedasAbreviacionesModificar]
@IdMonedaAbreviacion int,
@IdMoneda int,
@Abreviacion varchar(25),	
@ModificadoEl	datetime,	
@ModificadoPor	int,	
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION	
	IF ISNULL(@IdMonedaAbreviacion,0)= 0
		RAISERROR(N'Identificador de abreviación es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdMoneda,0)= 0
		RAISERROR(N'Identificador de moneda es un campo requerido',
			16,
			1
			)
					
	IF EXISTS(SELECT Abreviacion FROM CatMonedasAbreviaciones  WHERE Abreviacion  = @Abreviacion  And IdMonedaAbreviacion <> @IdMonedaAbreviacion)
		RAISERROR(N'La abreviación ya existe',
			16,
			1
			)	
					
	IF ISNULL(@Abreviacion,'')= ''
		RAISERROR(N'La abreviación es un campo requerido',
			16,
			1
			)
			
	UPDATE 	CatMonedasAbreviaciones
		SET IdMoneda = @IdMoneda,
			Abreviacion = @Abreviacion,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor 
	WHERE IdMonedaAbreviacion = @IdMonedaAbreviacion
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

