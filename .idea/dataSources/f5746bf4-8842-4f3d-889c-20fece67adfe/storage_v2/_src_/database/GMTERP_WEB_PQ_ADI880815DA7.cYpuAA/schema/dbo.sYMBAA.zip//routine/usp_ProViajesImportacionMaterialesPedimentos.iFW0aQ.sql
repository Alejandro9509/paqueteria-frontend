CREATE PROCEDURE [dbo].[usp_ProViajesImportacionMaterialesPedimentos]
@IdViaje int,
@XMLMateriales ntext,
@XMLPedimentos ntext,
@CreadoEl datetime,
@CreadoPor int,
@IdUsuarioAviso int,
@FechaHoraSucursalAviso datetime,
@MensajeAviso ntext,
@IdPeticion  varchar(100),
@TipoCobroViaje int,
@IdViajeCartaPorte int
AS
/*************************************************************************************************************************************
Procedimiento almacenado [usp_ProViajesImportacionMaterialesPedimentos]

Parámetros: 
@IdViaje int,
@XMLMateriales XML,
@XMLPedimentos XML,
@IdPeticion  varchar(100)

Descripción: Realiza la importacion a un viaje en especifico de los materiales o pedimentos.

Fecha de Creacion: 22/09/2021
Versión: 1.0.1.7
Solicitud 4841

Fecha de Modificacion: 24/09/2021
Versión: 1.0.1.8
Solicitud 4841
Modificacion : Se agrego la seccion para actualizar los impuestos del concepto de materiales.

Fecha de Modificacion: 24/09/2021
Versión: 1.0.1.9
Solicitud 4841
Modificacion : Se agrego la seccion para ligar los materiales con los trayectos.

Invocada desde: GMTERPV8_API/REST_GMTERPV8_Importacion/api/gmterpv8/importacion/MaterialesPedimentos
******************************************************************************************************************* */
Declare 
@docHandle int
,@IdAviso int = 0
,@IdViajeDescripcionCarga int = 0
,@IdUnidadPeso int = 0
,@IdConceptoFacturacion int = 0
,@IdViajeConceptoFacturacion int = 0
,@PesoTotal decimal(15,4) = 0
,@ImporteTotal money = 0
,@Cursor_Cantidad decimal(15,4)
,@Cursor_IdUnidadEmbalaje int
,@Cursor_DescripcionMaterial varchar(1024)
,@Cursor_Peso decimal(15,4)
,@Cursor_IdUnidadPeso int
,@Cursor_ClaveProductoServicios varchar(10)
,@Cursor_ClaveUnidad varchar(10)
,@Cursor_ClaveFraccionArancelaria varchar(10)
,@Cursor_UUIDComercioExterior nvarchar(100)
,@Cursor_ClaveMaterialPeligroso varchar(10)
,@Cursor_ClaveTipoEmbalaje varchar(10)
,@Cursor_DescripcionEmbalaje nvarchar(100)
,@Cursor_AplicaTarifa tinyint
,@Cursor_Tarifa float
,@Cursor_Importe money
,@Cursor_ImporteBase float 
,@Cursor_GeneradoDesde tinyint
,@Cursor_Consecutivo int
,@Cursor_XMLTrayectos varchar(max)
BEGIN TRY
	BEGIN TRANSACTION
		IF @CreadoPor = 0
			SET @CreadoPor = NULL

		IF @XMLMateriales IS NOT NULL 
		BEGIN
			/*Se eliminan las dependencias de la tabla ProViajesDescripcionCarga*/
			DELETE FROM ProViajesTrayectosMateriales WHERE IdViajeDescripcionCarga  IN (SELECT IdViajeDescripcionCarga FROM ProViajesDescripcionesCarga WHERE IdViaje = @IdViaje)
			/*Se eliminan los materiales ligados al viaje*/
			DELETE FROM ProViajesDescripcionesCarga WHERE IdViaje = @IdViaje
			
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLMateriales
			
			SELECT
			 Cantidad
			,IdUnidadEmbalaje
			,DescripcionMaterial
			,Peso
			,IdUnidadPeso
			,ClaveProductoServicios 
			,ClaveUnidad 
			,ClaveFraccionArancelaria 
			,UUIDComercioExterior 
			,ClaveMaterialPeligroso 
			,ClaveTipoEmbalaje
			,DescripcionEmbalaje 
			,AplicaTarifa 
			,Tarifa 
			,Importe 
			,ImporteBase 
			,GeneradoDesde 
			,Consecutivo
			,Trayectos
			INTO #TempProViajesDescripcionesCarga
			FROM OPENXML(@docHandle, N'/Materiales/Material',2) 
			WITH (
			 Cantidad decimal(15,4)
			,IdUnidadEmbalaje int
			,DescripcionMaterial varchar(1024)
			,Peso decimal(15,4)
			,IdUnidadPeso int
			,ClaveProductoServicios varchar(10)
			,ClaveUnidad varchar(10)
			,ClaveFraccionArancelaria varchar(10)
			,UUIDComercioExterior nvarchar(100)
			,ClaveMaterialPeligroso varchar(10)
			,ClaveTipoEmbalaje varchar(10)
			,DescripcionEmbalaje nvarchar(100)
			,AplicaTarifa tinyint
			,Tarifa float
			,Importe money
			,ImporteBase float 
			,GeneradoDesde tinyint
			,Consecutivo int
			,Trayectos varchar(max))
		
			EXEC sp_xml_removedocument @docHandle
			
			DECLARE CursorProViajesDescripcionesCarga CURSOR LOCAL FOR
			SELECT  Cantidad,IdUnidadEmbalaje,DescripcionMaterial,Peso,IdUnidadPeso,ClaveProductoServicios,ClaveUnidad,ClaveFraccionArancelaria,UUIDComercioExterior,ClaveMaterialPeligroso,ClaveTipoEmbalaje,DescripcionEmbalaje,AplicaTarifa,Tarifa,Importe,ImporteBase,GeneradoDesde,Consecutivo,Trayectos 
			FROM #TempProViajesDescripcionesCarga
		
			OPEN CursorProViajesDescripcionesCarga
			FETCH NEXT FROM CursorProViajesDescripcionesCarga
			INTO @Cursor_Cantidad,@Cursor_IdUnidadEmbalaje,@Cursor_DescripcionMaterial,@Cursor_Peso,@Cursor_IdUnidadPeso,@Cursor_ClaveProductoServicios,@Cursor_ClaveUnidad,@Cursor_ClaveFraccionArancelaria,@Cursor_UUIDComercioExterior,@Cursor_ClaveMaterialPeligroso,@Cursor_ClaveTipoEmbalaje,@Cursor_DescripcionEmbalaje,@Cursor_AplicaTarifa,@Cursor_Tarifa,@Cursor_Importe,@Cursor_ImporteBase,@Cursor_GeneradoDesde,@Cursor_Consecutivo,@Cursor_XMLTrayectos
		    
			WHILE @@FETCH_STATUS = 0
			BEGIN
		      
				INSERT INTO ProViajesDescripcionesCarga(IdViaje,Cantidad,IdUnidadMedidaEmbalaje,DescripcionCarga,Peso,IdUnidadMedidaPeso,Tarifa,Importe,ImporteBaseLiquidacion,TarifaAplicadaPor,CreadoPor,CreadoEl,CreadoDesde,Consecutivo)
				VALUES(@IdViaje,@Cursor_Cantidad,@Cursor_IdUnidadEmbalaje,@Cursor_DescripcionMaterial,@Cursor_Peso,@Cursor_IdUnidadPeso,@Cursor_Tarifa,@Cursor_Importe,@Cursor_ImporteBase,@Cursor_AplicaTarifa,@CreadoPor,@CreadoEl,@Cursor_GeneradoDesde,@Cursor_Consecutivo)
				
				SET @IdViajeDescripcionCarga = (SELECT IDENT_CURRENT('ProViajesDescripcionesCarga'))
				
				SET @ImporteTotal = (@ImporteTotal + @Cursor_Importe)
				SET @PesoTotal =   (@PesoTotal + @Cursor_Peso)
				
				IF @IdUnidadPeso = 0 
				BEGIN 
				SET @IdUnidadPeso = @Cursor_IdUnidadPeso 
				END
			
				--Seccion para las claves del sat de los materiales
				IF @Cursor_ClaveProductoServicios <> ''
				BEGIN
					INSERT INTO ProViajesDescripcionesCargaClavesSAT(IdViajeDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					VALUES (@IdViajeDescripcionCarga,@Cursor_ClaveProductoServicios,'c_ClaveProdServCP',NULL,GETDATE())
				END

				IF @Cursor_ClaveUnidad <> ''
				BEGIN
					INSERT INTO ProViajesDescripcionesCargaClavesSAT(IdViajeDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					VALUES (@IdViajeDescripcionCarga,@Cursor_ClaveUnidad,'c_ClaveUnidad',NULL,GETDATE())
				END

				IF @Cursor_ClaveFraccionArancelaria <> ''
				BEGIN
					INSERT INTO ProViajesDescripcionesCargaClavesSAT(IdViajeDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					VALUES (@IdViajeDescripcionCarga,@Cursor_ClaveFraccionArancelaria,'c_FraccionArancelaria',@Cursor_UUIDComercioExterior,GETDATE())
				END

				IF @Cursor_ClaveMaterialPeligroso <> ''
				BEGIN
					INSERT INTO ProViajesDescripcionesCargaClavesSAT(IdViajeDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					VALUES (@IdViajeDescripcionCarga,@Cursor_ClaveMaterialPeligroso,'c_MaterialPeligroso',NULL,GETDATE())
				END

				IF @Cursor_ClaveTipoEmbalaje <> ''
				BEGIN
					INSERT INTO ProViajesDescripcionesCargaClavesSAT(IdViajeDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					VALUES (@IdViajeDescripcionCarga,@Cursor_ClaveTipoEmbalaje,'c_TipoEmbalaje',@Cursor_DescripcionEmbalaje,GETDATE())
				END

				/*Liga los materiales al trayecto*/
				SELECT @Cursor_XMLTrayectos AS XML
				IF @Cursor_XMLTrayectos <> '' 
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @Cursor_XMLTrayectos
			
					SELECT IdViajeTrayecto,Cantidad
					INTO #TempProViajesTrayectosMateriales
					FROM OPENXML(@docHandle, N'/Trayectos/Trayecto',2) 
					WITH (IdViajeTrayecto int,Cantidad decimal(15,4))

					EXEC sp_xml_removedocument @docHandle

					SELECT * FROM #TempProViajesTrayectosMateriales

					INSERT INTO ProViajesTrayectosMateriales (Consecutivo,IdViajeDescripcionCarga,IdViajeTrayecto,Cantidad)
					SELECT @Cursor_Consecutivo,@IdViajeDescripcionCarga,tmp.IdViajeTrayecto,tmp.Cantidad
					FROM #TempProViajesTrayectosMateriales AS tmp
					INNER JOIN ProViajesTrayectos as pvt ON tmp.IdViajeTrayecto = pvt.IdViajeTrayecto
					WHERE pvt.IdViaje = @IdViaje

					DROP TABLE #TempProViajesTrayectosMateriales
				END

			FETCH NEXT FROM CursorProViajesDescripcionesCarga
			INTO @Cursor_Cantidad,@Cursor_IdUnidadEmbalaje,@Cursor_DescripcionMaterial,@Cursor_Peso,@Cursor_IdUnidadPeso,@Cursor_ClaveProductoServicios,@Cursor_ClaveUnidad,@Cursor_ClaveFraccionArancelaria,@Cursor_UUIDComercioExterior,@Cursor_ClaveMaterialPeligroso,@Cursor_ClaveTipoEmbalaje,@Cursor_DescripcionEmbalaje,@Cursor_AplicaTarifa,@Cursor_Tarifa,@Cursor_Importe,@Cursor_ImporteBase,@Cursor_GeneradoDesde,@Cursor_Consecutivo,@Cursor_XMLTrayectos
			END
			
			CLOSE CursorProViajesDescripcionesCarga
			DEALLOCATE CursorProViajesDescripcionesCarga
			/*Fin cursor*/

			/*Actualiza el viaje*/
			UPDATE ProViajes SET
				Peso = @PesoTotal
			   ,IdUnidadPeso = @IdUnidadPeso
			WHERE IdViaje = @IdViaje

			/*Tipo de cobro materiales = 2*/
			IF @TipoCobroViaje = 2
			BEGIN
				/*Se obtiene el concepto de facturacion configurado en parametros de trafico*/
				SET @IdConceptoFacturacion = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'ConceptoFactPorMateriales')

				/*Se valida que tenga concepto de facturacion*/
				IF @IdConceptoFacturacion = 0 
					RAISERROR(N'No se tiene configurado un concepto de facturacion para materiales.',
					16,
					1
					)

				/*Se eliminan los conceptos de facturacion y se vuelve a agregar el que este configurado como default*/
				DELETE ProViajesConceptosFacturacion WHERE IdViaje = @IdViaje

				/*Se Inicializan las variables a utilizar*/
				Declare
				 @IdImpuestoNoObjeto int = 0
				,@IdImpuestoTraslada int = 0
				,@PorcentajeTraslada decimal(15,4) = 0
				,@PorcentajeRetencion decimal(15,4) = 0
				,@IdImpuestoRetiene int = 0
				,@TrasladaImpuesto bit = 0
				,@RetieneImpuesto bit = 0
				,@UnidadMedida varchar(30) = ''
				,@IncluirCalculoIngresosLiquidacion bit = 0
				,@IncluirCalculoLiquidacionPorcentajeSobreImpFlete bit = 0
				,@ClaveSATProducto varchar(10) = ''
				,@ClaveSATUnidad varchar(10) = ''
				,@ImporteTrasladado money = 0
				,@ImporteRetenido money = 0
				,@TipoCalculoTraslada int = 0
				,@IdRetencionCero int  = 0

				/*Se Inicializa la informacion del concepto de facturacion*/
				SELECT 
				@TrasladaImpuesto  = TrasladaImpuesto
				,@RetieneImpuesto  = RetieneImpuesto
				,@UnidadMedida     = UnidadMedida
				,@IncluirCalculoIngresosLiquidacion =IncluirCalculoIngresosLiquidacion 
				,@IncluirCalculoLiquidacionPorcentajeSobreImpFlete = IncluirCalculoLiquidacionPorcentajeSobreImpFlete
				,@ClaveSATProducto  = ClaveSATProducto
				,@ClaveSATUnidad  = ClaveSATUnidad
				FROM CatConceptosFacturacion WHERE IdConceptoFacturacion = @IdConceptoFacturacion
				
				/*Se inicilizan los impuestos por default*/
				SET @IdImpuestoNoObjeto = (SELECT IdImpuesto FROM CatImpuestos WHERE Porcentaje = '0' AND TipoCalculo = 4 AND DefinidoPorSistema = 1)
				SET @IdRetencionCero    = (SELECT IdImpuesto FROM CatImpuestos WHERE Porcentaje = '0' AND TipoCalculo = 2 AND DefinidoPorSistema = 1)
				
				/*Si el concepto traslada impuesto se obtienen los impuestos predeterminados del concepto*/
				IF @TrasladaImpuesto = 1
				BEGIN
					/*Impuesto Traslada*/
					SELECT TOP 1
					 @IdImpuestoTraslada = cci.IdImpuesto
					,@PorcentajeTraslada = ci.Porcentaje
					,@TipoCalculoTraslada = ci.TipoCalculo
					FROM
					CatConceptosFacturacion ccf
					INNER JOIN CatConceptosFacturacionImpuestos cci ON ccf.IdConceptoFacturacion = cci.IdConceptoFacturacion
					INNER JOIN CatImpuestos ci ON cci.IdImpuesto = ci.IdImpuesto
					WHERE ccf.IdConceptoFacturacion = @IdConceptoFacturacion
					AND ci.TipoCalculo IN(1,3,4)
					AND cci.Predeterminado = 1
					ORDER BY ci.IdImpuesto
					
					/*Si traslada iva se obtiene la retencion en caso de aplicar.*/
					IF @TipoCalculoTraslada = 1
					BEGIN
						/*Impuesto Retencion*/
						SELECT TOP 1
						@IdImpuestoRetiene = cci.IdImpuesto
						,@PorcentajeRetencion = ci.Porcentaje
						FROM
						CatConceptosFacturacion ccf
						INNER JOIN CatConceptosFacturacionImpuestos cci ON ccf.IdConceptoFacturacion = cci.IdConceptoFacturacion
						INNER JOIN CatImpuestos ci ON cci.IdImpuesto = ci.IdImpuesto
						WHERE ccf.IdConceptoFacturacion = @IdConceptoFacturacion
						AND ci.TipoCalculo = 2
						AND cci.Predeterminado = 1
						ORDER BY ci.IdImpuesto
					END
					ELSE
					BEGIN
						SET @IdImpuestoRetiene = @IdRetencionCero
						SET @ImporteRetenido = 0
						SET @PorcentajeRetencion = 0
					END
				END
				ELSE
				BEGIN
					SET @IdImpuestoTraslada = @IdImpuestoNoObjeto
					SET @ImporteTrasladado = 0
					SET @PorcentajeTraslada = 0
				END

				IF @PorcentajeTraslada  <> 0 BEGIN SET @ImporteTrasladado   = ROUND((@PorcentajeTraslada/100)*@ImporteTotal,2) END
				IF @PorcentajeRetencion <> 0 BEGIN SET @ImporteRetenido = ROUND((@PorcentajeRetencion/100)*@ImporteTotal,2) END

				IF @IdImpuestoTraslada = 0 
				BEGIN 
				SET @IdImpuestoTraslada = @IdImpuestoNoObjeto 
				SET @ImporteTrasladado = 0
				END

				IF @IdImpuestoRetiene = 0 
				BEGIN 
				SET @IdImpuestoRetiene = @IdRetencionCero 
				SET @ImporteRetenido = 0
				END

				INSERT INTO ProViajesConceptosFacturacion(
				IdViaje
				,IdConceptoFacturacion
				,Importe
				,TrasladaImpuesto
				,RetieneImpuesto
				,UnidadMedida
				,CreadoPor
				,CreadoEl
				,IncluirCalculoIngresosLiquidacion
				,IncluirCalculoLiquidacionPorcentajeSobreImpFlete
				,Observacion
				,ClaveSATProducto
				,ClaveSATUnidad
				,Timbrado)
				Values(
				@IdViaje
				,@IdConceptoFacturacion
				,@ImporteTotal
				,@TrasladaImpuesto
				,@RetieneImpuesto
				,@UnidadMedida
				,@CreadoPor
				,@CreadoEl
				,@IncluirCalculoIngresosLiquidacion
				,@IncluirCalculoLiquidacionPorcentajeSobreImpFlete
				,''
				,@ClaveSATProducto
				,@ClaveSATUnidad
				,0)

				SET @IdViajeConceptoFacturacion = (SELECT IDENT_CURRENT('ProViajesConceptosFacturacion'))
			
				IF @IdImpuestoTraslada > 0 
				BEGIN
					INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
					VALUES( @IdViajeConceptoFacturacion,@IdImpuestoTraslada,@ImporteTrasladado)
				END

				IF @IdImpuestoRetiene > 0 
				BEGIN
					INSERT INTO ProViajesConceptosFacturacionImpuestos(IdViajeConceptoFacturacion,IdImpuesto,Importe)
					VALUES( @IdViajeConceptoFacturacion,@IdImpuestoRetiene,@ImporteRetenido)
				END

				/*Actualiza el viaje*/
				UPDATE ProViajes SET
					SubTotal = @ImporteTotal
				WHERE IdViaje = @IdViaje

				IF @IdViajeCartaPorte <> 0 
				BEGIN
					/*Actualiza la carta porte*/
					UPDATE ProViajesCartasPorte SET
						SubTotal = @ImporteTotal
						,Total = @ImporteTotal + @ImporteTrasladado - @ImporteRetenido
						,ImpuestosTrasladadosFederales = @ImporteTrasladado
						,ImpuestosRetenidosFederales = @ImporteRetenido
					WHERE IdViaje = @IdViaje
					
					/*Actualizamos los impuestos de la carta porte*/
					DELETE  FROM ProViajesCartasPorteImpuestos WHERE IdViajeCartaPorte = @IdViajeCartaPorte

					IF @IdImpuestoTraslada > 0 
					BEGIN
						INSERT INTO ProViajesCartasPorteImpuestos(IdViajeCartaPorte,IdImpuesto,Importe,CreadoPor,CreadoEl)
						VALUES(@IdViajeCartaPorte,@IdImpuestoTraslada,@ImporteTrasladado,@CreadoPor,@CreadoEl)
					END

					IF @IdImpuestoRetiene > 0 
					BEGIN
						INSERT INTO ProViajesCartasPorteImpuestos(IdViajeCartaPorte,IdImpuesto,Importe,CreadoPor,CreadoEl)
						VALUES(@IdViajeCartaPorte,@IdImpuestoRetiene,@ImporteRetenido,@CreadoPor,@CreadoEl)
					END

				END/*Fin validacion carta porte*/
			END/*Fin validacion tipo de cobro materiales*/
		END/*Fin de la importacion de materiales*/
		
		/*Importacion de pedimentos*/
		IF @XMLPedimentos IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLPedimentos
		
			SELECT NumeroPedimento,Fecha,Aduana
			INTO #TempProViajesPedimentos
			FROM OPENXML(@docHandle, N'/Pedimentos/Pedimento',2) 
			WITH (NumeroPedimento varchar(25),Fecha datetime,Aduana varchar(25))
		
			EXEC sp_xml_removedocument @docHandle

			INSERT INTO ProViajesPedimentos(IdViaje,NumeroPedimento,Fecha,Aduana,CreadoEl,CreadoPor)
			SELECT @IdViaje,NumeroPedimento,Fecha,Aduana,@CreadoEl,@CreadoPor
			FROM #TempProViajesPedimentos
		
		END	

		/*Seccion Avisos*/
		IF @IdUsuarioAviso <> 0 
		BEGIN
			INSERT INTO SisAvisos(Asunto,Aviso,CreadoPor,CreadoEl,EnviarEl,EnviarTodosLosUsuarios,RecordarCadaMin)
			VALUES('',@MensajeAviso,@CreadoPor,@CreadoEl,@FechaHoraSucursalAviso,0,5)
				
			SET @IdAviso = (SELECT IDENT_CURRENT('SisAvisos'))

			INSERT INTO SisAvisosDestinatarios(IdAviso,IdUsuarioDestinatario,UltimaNotificacion)
			VALUES(@IdAviso,@IdUsuarioAviso,@FechaHoraSucursalAviso)
		END	
   
	COMMIT 
END TRY
BEGIN CATCH
	IF (SELECT CURSOR_STATUS('LOCAL','CursorProViajesDescripcionesCarga')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('LOCAL','CursorProViajesDescripcionesCarga')) > -1
			BEGIN
				CLOSE CursorProViajesDescripcionesCarga
			END
	DEALLOCATE CursorProViajesDescripcionesCarga
	END
   ROLLBACK
   EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

