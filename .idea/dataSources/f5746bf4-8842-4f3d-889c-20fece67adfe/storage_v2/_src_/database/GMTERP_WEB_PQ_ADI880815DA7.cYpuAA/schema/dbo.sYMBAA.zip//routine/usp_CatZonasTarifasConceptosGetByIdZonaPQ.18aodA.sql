
CREATE PROCEDURE [dbo].[usp_CatZonasTarifasConceptosGetByIdZonaPQ](
	@IdZona int
)
AS
BEGIN
	BEGIN TRANSACTION
		/*SELECT 
			*
		FROM CatZonasTarifasCPPQ cz
		JOIN CatCodigosPostales c on cz.IdCP = c.IdCodigoPostal
		WHERE IdZona = @IdZona*/

		SELECT
			IdZonaConceptos
			,IdZona
			,Importe      
			,IdImpuestoTraslada
			,ImporteIva
			,IdImpuestoRetiene
			,ImporteRetiene
			,TF.IdConceptoFacturacion as IdConceptoFacturacion
			,IdTipoCalculo
			,RangoMinimo
			,RangoMaximo
			,IdAgregadoDesde
			,IdTipoMedida
			,CF.ConceptoFacturacion AS Concepto
		FROM CatZonasTarifasConceptosPQ TF INNER JOIN CatConceptosFacturacion CF ON TF.IdConceptoFacturacion = CF.IdConceptoFacturacion
		WHERE IdZona = @IdZona

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

