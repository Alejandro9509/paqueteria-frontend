CREATE PROCEDURE [dbo].[usp_CatEstatusViajeModificar]
	@IdEstatuViaje int,
	@Estatus varchar(30),
	@Abreviacion varchar(5),
	@Color varchar(6),
	@ColorLetra int,
	@EnviarPorCorreo bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@NoEnviarPorCorreoSeguimientoViajes bit,
	@InformarEnvioArchivo214 bit,
	@CargaDescarga tinyint,
	@Carga bit,-- Identificador para estatus de carga
	@Descarga bit,-- Identificador para estatus de Descarga
	@Activo bit
AS

/*************************************************************************************************************************************
Procedimiento almacenado usp_CatEstatusViajeModificar

Parámetros: 
	@IdEstatuViaje int,
	@Estatus varchar(30),
	@Abreviacion varchar(5),
	@Color varchar(6),
	@ColorLetra int,
	@EnviarPorCorreo bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@NoEnviarPorCorreoSeguimientoViajes bit,
	@InformarEnvioArchivo214 bit,
	@CargaDescarga tinyint,
	@Carga -- Identificador para estatus de carga
	@Activo bit
Descripción: Actualiza identificadoees para estatus de viajes

Fecha de modificación: 10/12/2019
Versión: Versión 8.0.48.22
Solicitud 286

Fecha de modificación: 17/08/2021
Versión: 8.0.64.01
Solicitud 4715

Fecha de modificación: 21/09/2021
Versión: 8.0.65.01
Solicitud 4851
Descripcion: se agrego la columna activo


Invocada desde: PAGE_CatEstatusViajeAM
    Solicitud 4851
******************************************************************************************************************* */

BEGIN TRY
	BEGIN TRANSACTION
	
	IF (SELECT ModificadoEl FROM CatEstatusViaje WHERE IdEstatuViaje = @IdEstatuViaje) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)

	IF @IdEstatuViaje = 0
		RAISERROR(N'El identificador del estatus es un campo requerido',
			16,
			1
			)			
	
	IF LTRIM(RTRIM(@Estatus)) = ''
		RAISERROR(N'El estatus es un campo requerido',
			16,
			1
			)
			
	UPDATE CatEstatusViaje SET 
		Abreviacion = @Abreviacion,
		Color = @Color,
		ColorLetra = @ColorLetra,
		EnviarPorCorreo = @EnviarPorCorreo,
		Estatus = @Estatus,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		NoEnviarPorCorreoSeguimientoViajes = @NoEnviarPorCorreoSeguimientoViajes,
		InformarEnvioArchivo214 = @InformarEnvioArchivo214,
		CargaDescarga =	@CargaDescarga,
		Carga = @Carga
		,Descarga = @Descarga
		,Activo = @Activo
	WHERE IdEstatuViaje = @IdEstatuViaje
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

