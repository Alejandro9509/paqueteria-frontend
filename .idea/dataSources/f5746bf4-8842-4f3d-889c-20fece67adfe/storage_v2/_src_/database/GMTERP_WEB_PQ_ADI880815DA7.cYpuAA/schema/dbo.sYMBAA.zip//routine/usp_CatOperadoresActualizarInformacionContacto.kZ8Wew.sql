CREATE PROCEDURE [dbo].[usp_CatOperadoresActualizarInformacionContacto]
	@IdOperador int,
	@Telefonos varchar(26),
	@CorreoOperador Varchar(50),
	@IdPeticion varchar(100),
	@TelefonoCelular varchar(10) = NULL
	/*************************************************************************************************************************************
	@IdOperador int,
	@Telefonos varchar(26),
	@CorreoOperador Varchar(50),
	@IdPeticion varchar(100),
	@TelefonoCelular varchar(10) NULL

	Modificado por:  Luis Edgar Ramos Cadena
	Fecha de modificacion: 14/05/2021
	Versión  
	Solicitud 3939

	
	Se agrego condicion para modificar el telefono celular cuando corresponda
	***************************************/
AS
BEGIN TRY
	BEGIN TRANSACTION
		
		IF ISNULL(@TelefonoCelular,'') <> ''
		BEGIN
			UPDATE CatOperadores SET
			TelefonoCelular = @TelefonoCelular,
			CorreoOperador = @CorreoOperador
			WHERE IdOperador = @IdOperador
		END
		ELSE
		BEGIN
			UPDATE CatOperadores SET
			Telefonos = @Telefonos,
			CorreoOperador = @CorreoOperador
			WHERE IdOperador = @IdOperador
		END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

