
CREATE FUNCTION [dbo].[fnConvertFechaHoraLocalToUTC](@ZonaHoraria int,@FechaHoraLocal datetime,@DescripcionZonaHoraria varchar(100))
RETURNS datetime
AS BEGIN
	DECLARE @FechaHoraUTC datetime,		
		@TimeZone varchar(6) = '00'

		SET @TimeZone = '+'+LEFT(@TimeZone,2-LEN(CAST(@ZonaHoraria*-1 as varchar)))+CAST(@ZonaHoraria*-1 as varchar)+':00'

		SET @FechaHoraUTC = (SWITCHOFFSET (CAST(@FechaHoraLocal AS datetimeoffset(3)), @TimeZone))

		IF EXISTS(SELECT * FROM CatHorariosVerano WHERE DescripcionZonaHoraria = @DescripcionZonaHoraria AND @FechaHoraLocal BETWEEN Inicio AND Fin)
		BEGIN
			SET @TimeZone = '00'
			SET @ZonaHoraria = @ZonaHoraria + 1
			SET @TimeZone = '+'+LEFT(@TimeZone,2-LEN(CAST(@ZonaHoraria*-1 as varchar)))+CAST(@ZonaHoraria*-1 as varchar)+':00'
			SET @FechaHoraUTC = (SWITCHOFFSET (CAST(@FechaHoraLocal AS datetimeoffset(3)), @TimeZone))			
		END

	RETURN @FechaHoraUTC
END
go

