
	CREATE PROCEDURE [dbo].[usp_CatTipoViajeEliminarPQ]
	@IdTipoViaje int
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdTipoViaje, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador es un campo requerido*FIN*', 16, 1); 
			return;
			end
	Delete from CatTipoViaje
	Where IdTipoViaje = @IdTipoViaje

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

