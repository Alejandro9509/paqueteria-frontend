CREATE PROCEDURE [dbo].[usp_ProGuiasGetListadoFiltro2PQ] @IdSucursal INT,
                                                         @IdEstatus INT,
                                                         @FechaInicial DATE,
                                                         @FechaFinal DATE,
                                                         @FolioGuia VARCHAR(100),
                                                         @IdOrigen INT,
                                                         @IdDestino INT
AS
BEGIN TRY
    BEGIN TRANSACTION
        SELECT FORMAT(e.Fecha, 'dd-MM-yyyy') + ' ' +  convert(char(5),convert(time(0),g.Hora)) as m_sFechaHora
             , g.IdEstatusGuia as m_nIdEstatusGuia
             , (select Estatus from CatEstatusGuiasPQ eg where eg.IdEstatusGuias = g.IdEstatusGuia) as m_sEstatusGuia
             , e.IdCiudadOrigen as m_nIdCiudadOrigen
             , (select OrigenDestino from CatOrigenesDestinos c where c.IdOrigenDestino = e.IdCiudadOrigen) as m_sCiudadOrigen
             , e.IdCiudadDestino as m_nIdCiudadDestino
             , (select OrigenDestino from CatOrigenesDestinos c where c.IdOrigenDestino = e.IdCiudadDestino) as m_sCiudadDestino
             , g.IdGuia as m_nIdGuia
             , g.FolioGuia as m_nFolioGuia
             , g.IdEmbarque as m_nIdEmbarque
             , e.FolioEmbarque as m_sFolioEmbarque
             , e.IdCliente as m_nIdCliente
             , (Select c.NombreFiscal from CatClientes c where c.IdCliente = e.IdCliente) as m_sCliente
             , g.IdSucursal as IdSucursal
             , (select Sucursal from CatSucursales s where s.IdSucursal = g.IdSucursal) as m_sSucursal
             , (select FolioInforme from ProInformePQ r where r.IdInforme = g.IdInforme) as m_sFolioInforme
             , g.FechaCancelacion as m_dtFechaCancelacion
             , g.UsuarioCancelacion as m_nUsuarioCancelacion
        FROM ProGuiaPQ g
                 inner join ProEmbarquePQ e on g.IdEmbarque = e.IdEmbarque
        WHERE (g.IdSucursal = @IdSucursal OR @IdSucursal IS NULL)
          OR (g.IdEstatusGuia = @IdEstatus OR @IdEstatus IS NULL)
          OR ((g.Fecha >= @FechaInicial OR @FechaInicial IS NULL)
          OR (g.Fecha <= @FechaFinal OR @FechaFinal IS NULL))
          OR (IdCiudadOrigen = @IdOrigen OR @IdOrigen IS NULL)
          OR (IdCiudadDestino = @IdDestino OR @IdDestino IS NULL)
          OR (FolioGuia LIKE '%' + @FolioGuia + '%' OR @FolioGuia IS NULL)
          and e.IdGuia = g.IdGuia
        ORDER BY g.Fecha DESC, g.Hora DESC
    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION
    EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

