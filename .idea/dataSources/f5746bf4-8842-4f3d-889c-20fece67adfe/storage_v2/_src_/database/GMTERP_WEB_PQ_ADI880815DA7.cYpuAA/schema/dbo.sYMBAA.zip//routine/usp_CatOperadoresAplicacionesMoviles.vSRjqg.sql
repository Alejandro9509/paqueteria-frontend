CREATE PROCEDURE [dbo].[usp_CatOperadoresAplicacionesMoviles]
	@IdPeticion varchar(100),
	@IdOperador int,
	@dsAplicacionesMoviles XML
	
	/*************************************************************************************************************************************
	@IdPeticion varchar(100),
	@IdOperador int,
	@dsAplicacionesMoviles XML

	Creado por:  Luis Edgar Ramos Cadena
	Fecha de Creacion: 28/02/2021
	Versión  Versión 8.0.59.10
	Solicitud 3898

	Modificado por:  Luis Edgar Ramos Cadena
	Fecha de Creacion: 11/03/2021
	Versión  Versión 8.0.59.20
	Solicitud 3898
	
	Se creo para ligar las aplicaciones moviles al operador
	***************************************/
AS
DECLARE @TemporalXML TABLE
(	
IdAplicacionMovil int,
Activo bit,
Usuario nvarchar(20),
Contrasena nvarchar(20),
Derechos nvarchar(MAX)
)


BEGIN TRY
	BEGIN TRANSACTION

	INSERT INTO @TemporalXML (IdAplicacionMovil,Activo,Usuario,Contrasena,Derechos)
	Select  
	 IdAplicacionMovil = Node.Data.value('(ATT_IdAplicacionMovil)[1]', 'int')
	,Activo =	Node.Data.value('(ATT_Activo)[1]', 'bit') 
	,Usuario =	Node.Data.value('(ATT_Usuario)[1]', 'nvarchar(20)') 
	,Contrasena =	Node.Data.value('(ATT_Contrasena)[1]', 'nvarchar(20)')
	,Derechos = Node.Data.value('(ATT_Derechos)[1]', 'nvarchar(MAX)')
	FROM   @dsAplicacionesMoviles.nodes('/WINDEV_TABLE/LOOP_AplicacionesMoviles') Node(Data) 

	--Se elimina la informacion anterior para actualizar la nueva
	DELETE FROM CatOperadoresAplicacionesMoviles where IdOperador = @IdOperador

	INSERT INTO CatOperadoresAplicacionesMoviles(IdOperador,IdAplicacionMovil,Activo,Usuario,Contraseña,Derechos)
	SELECT
	 @IdOperador
	,IdAplicacionMovil
	,Activo
	,Usuario
	,Contrasena
	,Derechos
	FROM @TemporalXML

COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

