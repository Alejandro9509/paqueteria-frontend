

CREATE PROCEDURE [dbo].[usp_CatTarifaEliminarPQ]
	@IdTarifa INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdTarifa,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de la Tarifa es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		DELETE FROM CatTarifaPQ
		WHERE IdTarifa = @IdTarifa

		DELETE FROM CatTarifaCobroPQ
		WHERE IdTarifa= @IdTarifa

		DELETE FROM CatTarifaConceptosPQ
		WHERE IdTarifa= @IdTarifa

		DELETE FROM CatTarifaServicioPQ
		WHERE IdTarifa= @IdTarifa

		DELETE FROM CatProductosTarifaPQ
		WHERE IdTarifa = @IdTarifa

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END


go

