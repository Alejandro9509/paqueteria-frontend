
	CREATE PROCEDURE [dbo].[usp_ProCotizadorGetMaxFolio]

	AS

	SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProCotizaciones
    go

