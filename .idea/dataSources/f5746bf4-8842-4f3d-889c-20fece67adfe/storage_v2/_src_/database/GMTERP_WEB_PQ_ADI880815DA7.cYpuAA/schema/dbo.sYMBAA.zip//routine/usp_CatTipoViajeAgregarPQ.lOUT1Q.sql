
	CREATE PROCEDURE [dbo].[usp_CatTipoViajeAgregarPQ](
	@Codigo int,
	@TipoViaje varchar(80),
	@CreadoEl datetime,
	@CreadoPor int,
	@ModificadoEl datetime,
	@ModificadoPor int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@Codigo, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Codigo es un campo requerido*FIN*', 16, 1); 
			return;
			end
		IF ISNULL(@TipoViaje, '') = '' begin
			RAISERROR(N'*INICIO*La Descripcion de viaje es un campo requerido*FIN*', 16, 1) 
			return
		end
INSERT INTO CatTipoViaje

VALUES (@Codigo ,@TipoViaje, @CreadoEl,
	@CreadoPor, @ModificadoEl, @ModificadoPor)

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END


    go

