CREATE PROCEDURE [dbo].[usp_ProSolicitudesEDIAgregar]
    @IdentSolicitud VARCHAR(100),
    @CarrierPro VARCHAR(30),
    @Customer VARCHAR(30),    
    @Origen VARCHAR(500),
    @Destino VARCHAR(500),
    @Cliente VARCHAR(150),
    @DireccionCliente VARCHAR(150),
    @EspecificacionesUnidad VARCHAR(150),
    @EspecificacionesCarga VARCHAR(150),
    @FechaHoraSalida DATETIME,
    @FechaHoraLlegada DATETIME,
    @dsProSolicitudesEDIDetalles NTEXT,
    @CreadoEl DATETIME,
    @CreadoPor INT,
    @IdPeticion VARCHAR(100),
    @InterchangeReceiverID VARCHAR(50),
    @InterchangeIDQualifier VARCHAR(5),
    @IdentificadorSCAC VARCHAR(20),
    @RunNumber VARCHAR(20),
    @ManifestNumber VARCHAR(20),
    @CarrierAplicacion INT,
    @SCACAplicacion VARCHAR(20),
	@Tipo VARCHAR(10)

/*************************************************************************************************************************************
Procedimiento almacenado usp_ProSolicitudesEDIAgregar

Parámetros: 
    @IdentSolicitud varchar(100),
    @CarrierPro varchar(30),
    @Customer   varchar(30),    
    @Origen varchar(500),
    @Destino    varchar(500),
    @Cliente    varchar(150),
    @DireccionCliente   varchar(150),
    @EspecificacionesUnidad varchar(150),
    @EspecificacionesCarga  varchar(150),
    @FechaHoraSalida    datetime,
    @FechaHoraLlegada   datetime,
    @dsProSolicitudesEDIDetalles ntext,
    @CreadoEl   datetime,
    @CreadoPor  int,
    @IdPeticion varchar(100),
    @InterchangeReceiverID Varchar(50),
    @InterchangeIDQualifier Varchar(5),
    @IdentificadorSCAC Varchar(20)
    @IdentL11 Varchar(5)

Descripción: Agrega las Solicitudes EDI

23/09/2020 - Se agrego paramtro para grabar el identL11
10/12/2020 - Se agrego el paramtro @CarrierAplicacion y @SCACAplicacion
08/10/2021 - Se agrego el parametro @Tipo

Modificada por:  Francisco Villela
Fecha de modificación: 23/09/2020

Modificada por:  Francisco Villela
Fecha de modificación: 10/12/2020

Modificada por:  Humberto Morales
Fecha de modificación: 08/10/2021

Invocada desde: ClsProSolicitudesEDI
*************************************************************************************************************************************/
AS
DECLARE 
    @DoNotShipBefore VARCHAR(100),--Nueva variable para la fecha del mensaje de aviso
    @docHandle INT,
    @IdSolicitudEDI INT,
    @IdentSolicitudYaExistente VARCHAR(100)
BEGIN TRY
    BEGIN TRANSACTION
        SET @IdentSolicitudYaExistente =(SELECT TOP 1 IdentSolicitud FROM ProSolicitudesEDI WHERE IdentSolicitud = @IdentSolicitud)
        
        IF ISNULL(@IdentSolicitudYaExistente,'') = ''
			BEGIN
				-----------------INSERTAR-------------------
				INSERT INTO ProSolicitudesEDI(CarrierPro
											, CreadoEl
											, CreadoPor
											, Customer
											, Destino
											, EspecificacionesCarga
											, EspecificacionesUnidad
											, FechaHoraLlegada
											, FechaHoraSalida
											, IdentSolicitud
											, Origen
											, Cliente
											, DireccionCliente
											, InterchangeReceiverID
											, InterchangeIDQualifier
											, IdentificadorSCAC
											, RunNumber
											, ManifestNumber
											, CarrierAplicacion
											, SCACAplicacion
											, Tipo)
				VALUES(@CarrierPro
					 , @CreadoEl
					 , @CreadoPor
					 , @Customer
					 , dbo.fn_ConversionUTF8(@Destino)
					 , @EspecificacionesCarga
					 , @EspecificacionesUnidad
					 , @FechaHoraLlegada
					 , @FechaHoraSalida
					 , @IdentSolicitud
					 , dbo.fn_ConversionUTF8(@Origen)
					 , dbo.fn_ConversionUTF8(@Cliente)
					 , dbo.fn_ConversionUTF8(@DireccionCliente)
					 , @InterchangeReceiverID
					 , @InterchangeIDQualifier
					 , @IdentificadorSCAC
					 , @RunNumber
					 , @ManifestNumber
					 , @CarrierAplicacion
					 , @SCACAplicacion
					 , @Tipo)
            
				SET @IdSolicitudEDI = (SELECT IDENT_CURRENT('ProSolicitudesEDI'))
            
				IF @dsProSolicitudesEDIDetalles IS NOT NULL
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProSolicitudesEDIDetalles

					SELECT 
					  ATT_IdentSolicitud
					, ATT_TransactionID
					, ATT_AccountingID
					, ATT_Purpose
					, ATT_Type
					, ATT_StopNum
					, ATT_StopReason
					, ATT_StopWeight
					, ATT_StopVolume
					, ATT_BOL
					, ATT_PONumber
					, ATT_TrackingNum
					, ATT_DockNum
					, ATT_CustomerOrder
					, ATT_RequestedPickupDate
					, ATT_RequestedPickupTime
					, ATT_RequestedDeliveryDate
					, ATT_RequestedDeliveryTime
					, ATT_DoNotShipBefore
					, ATT_ShipNoLaterThan
					, ATT_Weight
					, ATT_Pieces
					, ATT_Volume
					, ATT_PalletsShipped
					, ATT_PalletExchangeCode
					, ATT_ShipFromName
					, ATT_ShipFromAddress1
					, ATT_ShipFromAddress2
					, ATT_ShipFromCity
					, ATT_ShipFromState
					, ATT_ShipFromZip
					, ATT_ShipFromCountry
					, ATT_ShipFromAddressCode
					, ATT_ShipToName
					, ATT_ShipToAddress1
					, ATT_ShipToAddress2
					, ATT_ShipToCity
					, ATT_ShipToState
					, ATT_ShipToZip
					, ATT_ShipToCountry
					, ATT_ShipToAddressCode
					, ATT_ContactName
					, ATT_ContactPhone
					, ATT_LadingDecription
					, ATT_ReportRemarks
					, ATT_PaymentMethod
					, ATT_MustRespondByDate
					, ATT_MustRespondByTime
					, ATT_SCAC
					, ATT_ContinuousMove
					, ATT_CarrierID
					, ATT_MilesTotalDistance
					, ATT_Customer
					, ATT_Equipment
					, ATT_EquipmentDescription
					, ATT_TemperatureControl
					, ATT_EquipmentLength
					, ATT_TotalFreightWeight
					, ATT_TotalFreightCost
					, ATT_TotalFreightVolumeCube
					, ATT_BillToName
					, ATT_BillToAddress1
					, ATT_BillToCity
					, ATT_BillToState
					, ATT_BillToZip
					, ATT_BillToCountry
					, ATT_BillToCode
					, ATT_ContactName1
					, ATT_ContactPhone1
					, ATT_ReportRemarks1
					, ATT_Reference
					, ATT_PO
					, ATT_Quantity
					, ATT_UOM
					, ATT_Weight1
					, ATT_WeightUOM
					, ATT_VolumeCubicFeet
					, ATT_PaymentMethod1
					, ATT_LocationIdValue
					, ATT_Latitude
					, ATT_Longitude
					, ATT_WeightQualifier
					, ATT_WeightUnitCode
					, ATT_LadingQuantity
					INTO #TempProSolicitudesEDIDetalles
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProSolicitudesEDIDetalles',2) 
					WITH (ATT_IdentSolicitud VARCHAR(100)
						, ATT_TransactionID VARCHAR(100)
						, ATT_AccountingID VARCHAR(100)
						, ATT_Purpose VARCHAR(100)
						, ATT_Type VARCHAR(150)
						, ATT_StopNum VARCHAR(100)
						, ATT_StopReason VARCHAR(100)
						, ATT_StopWeight VARCHAR(100)
						, ATT_StopVolume VARCHAR(100)
						, ATT_BOL VARCHAR(100)
						, ATT_PONumber VARCHAR(100)
						, ATT_TrackingNum VARCHAR(100)
						, ATT_DockNum VARCHAR(100)
						, ATT_CustomerOrder VARCHAR(100)
						, ATT_RequestedPickupDate VARCHAR(100)
						, ATT_RequestedPickupTime VARCHAR(100)
						, ATT_RequestedDeliveryDate VARCHAR(100)
						, ATT_RequestedDeliveryTime VARCHAR(100)
						, ATT_DoNotShipBefore VARCHAR(100)
						, ATT_ShipNoLaterThan VARCHAR(100)
						, ATT_Weight VARCHAR(100)
						, ATT_Pieces VARCHAR(100)
						, ATT_Volume VARCHAR(100)
						, ATT_PalletsShipped VARCHAR(100)
						, ATT_PalletExchangeCode VARCHAR(100)
						, ATT_ShipFromName VARCHAR(100)
						, ATT_ShipFromAddress1 VARCHAR(100)
						, ATT_ShipFromAddress2 VARCHAR(100)
						, ATT_ShipFromCity VARCHAR(100)
						, ATT_ShipFromState VARCHAR(100)
						, ATT_ShipFromZip VARCHAR(100)
						, ATT_ShipFromCountry VARCHAR(100)
						, ATT_ShipFromAddressCode VARCHAR(100)
						, ATT_ShipToName VARCHAR(100)
						, ATT_ShipToAddress1 VARCHAR(100)
						, ATT_ShipToAddress2 VARCHAR(100)
						, ATT_ShipToCity VARCHAR(100)
						, ATT_ShipToState VARCHAR(100)
						, ATT_ShipToZip VARCHAR(100)
						, ATT_ShipToCountry VARCHAR(100)
						, ATT_ShipToAddressCode VARCHAR(100)
						, ATT_ContactName VARCHAR(100)
						, ATT_ContactPhone VARCHAR(100)
						, ATT_LadingDecription VARCHAR(100)
						, ATT_ReportRemarks VARCHAR(100)
						, ATT_PaymentMethod VARCHAR(100)
						, ATT_MustRespondByDate VARCHAR(100)
						, ATT_MustRespondByTime VARCHAR(100)
						, ATT_SCAC VARCHAR(100)
						, ATT_ContinuousMove VARCHAR(100)
						, ATT_CarrierID VARCHAR(100)
						, ATT_MilesTotalDistance VARCHAR(100)
						, ATT_Customer VARCHAR(100)
						, ATT_Equipment VARCHAR(100)
						, ATT_EquipmentDescription VARCHAR(100)
						, ATT_TemperatureControl VARCHAR(100)
						, ATT_EquipmentLength VARCHAR(100)
						, ATT_TotalFreightWeight VARCHAR(100)
						, ATT_TotalFreightCost VARCHAR(100)
						, ATT_TotalFreightVolumeCube VARCHAR(100)
						, ATT_BillToName VARCHAR(100)
						, ATT_BillToAddress1 VARCHAR(100)
						, ATT_BillToCity VARCHAR(100)
						, ATT_BillToState VARCHAR(100)
						, ATT_BillToZip VARCHAR(100)
						, ATT_BillToCountry VARCHAR(100)
						, ATT_BillToCode VARCHAR(100)
						, ATT_ContactName1 VARCHAR(100)
						, ATT_ContactPhone1 VARCHAR(100)
						, ATT_ReportRemarks1 VARCHAR(100)
						, ATT_Reference VARCHAR(100)
						, ATT_PO VARCHAR(100)
						, ATT_Quantity VARCHAR(100)
						, ATT_UOM VARCHAR(100)
						, ATT_Weight1 VARCHAR(100)
						, ATT_WeightUOM VARCHAR(100)
						, ATT_VolumeCubicFeet VARCHAR(100)
						, ATT_PaymentMethod1 VARCHAR(100)
						, ATT_LocationIdValue VARCHAR(30)
						, ATT_Latitude VARCHAR (50)
						, ATT_Longitude VARCHAR(50)
						, ATT_WeightQualifier VARCHAR(100)
						, ATT_WeightUnitCode VARCHAR(100)
						, ATT_LadingQuantity VARCHAR(100))

					EXEC sp_xml_removedocument @docHandle
                
					INSERT INTO ProSolicitudesEDIDetalles(CreadoEl
														, CreadoPor
														, IdSolicitudEDI
														, IdentSolicitud
														, TransactionID
														, AccountingID
														, Purpose
														, [Type]
														, StopNum
														, StopReason
														, StopWeight
														, StopVolume
														, BOL
														, PONumber
														, TrackingNum
														, DockNum
														, CustomerOrder
														, RequestedPickupDate
														, RequestedPickupTime
														, RequestedDeliveryDate
														, RequestedDeliveryTime
														, DoNotShipBefore
														, ShipNoLaterThan
														, [Weight]
														, Pieces
														, Volume
														, PalletsShipped
														, PalletExchangeCode
														, ShipFromName
														, ShipFromAddress1
														, ShipFromAddress2
														, ShipFromCity
														, ShipFromState
														, ShipFromZip
														, ShipFromCountry
														, ShipFromAddressCode
														, ShipToName
														, ShipToAddress1
														, ShipToAddress2
														, ShipToCity
														, ShipToState
														, ShipToZip
														, ShipToCountry
														, ShipToAddressCode
														, ContactName
														, ContactPhone
														, LadingDecription
														, ReportRemarks
														, PaymentMethod
														, MustRespondByDate
														, MustRespondByTime
														, SCAC
														, ContinuousMove
														, CarrierID
														, MilesTotalDistance
														, Customer
														, Equipment
														, EquipmentDescription
														, TemperatureControl
														, EquipmentLength
														, TotalFreightWeight
														, TotalFreightCost
														, TotalFreightVolumeCube
														, BillToName
														, BillToAddress1
														, BillToCity
														, BillToState
														, BillToZip
														, BillToCountry
														, BillToCode
														, ContactName1
														, ContactPhone1
														, ReportRemarks1
														, Reference
														, PO
														, Quantity
														, UOM
														, Weight1
														, WeightUOM
														, VolumeCubicFeet
														, PaymentMethod1
														, LocationIdValue
														, Latitude
														, Longitude
														, WeightQualifier
														, WeightUnitCode
														, LadingQuantity)
					SELECT 
					  @CreadoEl
					, @CreadoPor
					, @IdSolicitudEDI
					, ATT_IdentSolicitud
					, ATT_TransactionID
					, ATT_AccountingID
					, ATT_Purpose
					, ATT_Type
					, ATT_StopNum
					, ATT_StopReason
					, ATT_StopWeight
					, ATT_StopVolume
					, ATT_BOL
					, ATT_PONumber
					, ATT_TrackingNum
					, ATT_DockNum
					, ATT_CustomerOrder
					, ATT_RequestedPickupDate
					, ATT_RequestedPickupTime
					, ATT_RequestedDeliveryDate
					, ATT_RequestedDeliveryTime
					, ATT_DoNotShipBefore
					, ATT_ShipNoLaterThan
					, ATT_Weight
					, ATT_Pieces
					, ATT_Volume
					, ATT_PalletsShipped
					, ATT_PalletExchangeCode
					, dbo.fn_ConversionUTF8(ATT_ShipFromName)
					, dbo.fn_ConversionUTF8(ATT_ShipFromAddress1)
					, ATT_ShipFromAddress2
					, dbo.fn_ConversionUTF8(ATT_ShipFromCity)
					, ATT_ShipFromState
					, ATT_ShipFromZip
					, dbo.fn_ConversionUTF8(ATT_ShipFromCountry)
					, ATT_ShipFromAddressCode
					, dbo.fn_ConversionUTF8(ATT_ShipToName)
					, dbo.fn_ConversionUTF8(ATT_ShipToAddress1)
					, ATT_ShipToAddress2
					, dbo.fn_ConversionUTF8(ATT_ShipToCity)
					, dbo.fn_ConversionUTF8(ATT_ShipToState)
					, ATT_ShipToZip
					, dbo.fn_ConversionUTF8(ATT_ShipToCountry)
					, ATT_ShipToAddressCode
					, ATT_ContactName
					, ATT_ContactPhone
					, ATT_LadingDecription
					, ATT_ReportRemarks
					, ATT_PaymentMethod
					, ATT_MustRespondByDate
					, ATT_MustRespondByTime
					, ATT_SCAC
					, ATT_ContinuousMove
					, ATT_CarrierID
					, ATT_MilesTotalDistance
					, ATT_Customer
					, ATT_Equipment
					, ATT_EquipmentDescription
					, ATT_TemperatureControl
					, ATT_EquipmentLength
					, ATT_TotalFreightWeight
					, ATT_TotalFreightCost
					, dbo.fn_ConversionUTF8(ATT_TotalFreightVolumeCube)
					, dbo.fn_ConversionUTF8(ATT_BillToName)
					, dbo.fn_ConversionUTF8(ATT_BillToAddress1)
					, ATT_BillToCity
					, ATT_BillToState
					, ATT_BillToZip
					, ATT_BillToCountry
					, ATT_BillToCode
					, ATT_ContactName1
					, ATT_ContactPhone1
					, ATT_ReportRemarks1
					, ATT_Reference
					, ATT_PO
					, ATT_Quantity
					, ATT_UOM
					, ATT_Weight1
					, ATT_WeightUOM
					, ATT_VolumeCubicFeet
					, ATT_PaymentMethod1
					, dbo.fn_ConversionUTF8(ATT_LocationIdValue)
					, ATT_Latitude
					, ATT_Longitude
					, ATT_WeightQualifier
					, ATT_WeightUnitCode
					, ATT_LadingQuantity
					FROM #TempProSolicitudesEDIDetalles
				END
    
				--se hace un Select para traer la fecha que mostrara el aviso de la solicitud EDI
				SET @DoNotShipBefore = (SELECT TOP 1 [DoNotShipBefore] FROM [ProSolicitudesEDIDetalles] WHERE IdSolicitudEDI = @IdSolicitudEDI AND ISNULL(DoNotShipBefore,'') <> '')
				-----------------FIN DE INSERTAR------------
				-----------------AVISO----------------------
				INSERT INTO SisAvisos(Asunto
									, Aviso
									, CreadoEl
									, CreadoPor
									, EnviarEl
									, RecordarCadaMin
									, AtendidoPor
									, AtendidoEl
									, ComentariosAtendio
									, EnviarTodosLosUsuarios)
				VALUES(''
					 , 'Has recibido una solicitud de Viaje del cliente ' + dbo.fn_ConversionUTF8(@Cliente) + ', dentro de tu Modulo EDI. Se pide respuesta antes de ' + @DoNotShipBefore
					 , @CreadoEl
					 , @CreadoPor
					 , @CreadoEl
					 , 5
					 , NULL
					 , NULL
					 , NULL
					 , 1)
			END
        ELSE
			BEGIN
				-----------------MODIFICAR------------------
				SET  @IdSolicitudEDI = (SELECT TOP 1 IdSolicitudEDI FROM ProSolicitudesEDI WHERE IdentSolicitud = @IdentSolicitud)
            
				UPDATE ProSolicitudesEDI SET 
					CarrierPro = @CarrierPro,
					ModificadoEl = @CreadoEl,
					ModificadoPor = @CreadoPor,
					Customer = @Customer,
					Destino = dbo.fn_ConversionUTF8(@Destino),
					EspecificacionesCarga = @EspecificacionesCarga,
					EspecificacionesUnidad = @EspecificacionesUnidad,
					FechaHoraLlegada = @FechaHoraLlegada,
					FechaHoraSalida = @FechaHoraSalida,
					Origen = dbo.fn_ConversionUTF8(@Origen),
					Cliente = dbo.fn_ConversionUTF8(@Cliente),
					DireccionCliente = dbo.fn_ConversionUTF8(@DireccionCliente),
					InterchangeReceiverID = @InterchangeReceiverID,
					InterchangeIDQualifier= @InterchangeIDQualifier,
					IdentificadorSCAC = @IdentificadorSCAC,
					RunNumber = @RunNumber,
					ManifestNumber = @ManifestNumber,
					CarrierAplicacion = @CarrierAplicacion,
					SCACAplicacion = @SCACAplicacion,
					Tipo = @Tipo
				WHERE 
					IdSolicitudEDI = @IdSolicitudEDI 
            
				--Borrar el detalle existente para agregar el nuevo
				DELETE ProSolicitudesEDIDetalles WHERE IdSolicitudEDI = @IdSolicitudEDI
				--Se agrega de nuevo 
				IF @dsProSolicitudesEDIDetalles IS NOT NULL
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProSolicitudesEDIDetalles

					SELECT 
					  ATT_IdentSolicitud
					, ATT_TransactionID
					, ATT_AccountingID
					, ATT_Purpose
					, ATT_Type
					, ATT_StopNum
					, ATT_StopReason
					, ATT_StopWeight
					, ATT_StopVolume
					, ATT_BOL
					, ATT_PONumber
					, ATT_TrackingNum
					, ATT_DockNum
					, ATT_CustomerOrder
					, ATT_RequestedPickupDate
					, ATT_RequestedPickupTime
					, ATT_RequestedDeliveryDate
					, ATT_RequestedDeliveryTime
					, ATT_DoNotShipBefore
					, ATT_ShipNoLaterThan
					, ATT_Weight
					, ATT_Pieces
					, ATT_Volume
					, ATT_PalletsShipped
					, ATT_PalletExchangeCode
					, ATT_ShipFromName
					, ATT_ShipFromAddress1
					, ATT_ShipFromAddress2
					, ATT_ShipFromCity
					, ATT_ShipFromState
					, ATT_ShipFromZip
					, ATT_ShipFromCountry
					, ATT_ShipFromAddressCode
					, ATT_ShipToName
					, ATT_ShipToAddress1
					, ATT_ShipToAddress2
					, ATT_ShipToCity
					, ATT_ShipToState
					, ATT_ShipToZip
					, ATT_ShipToCountry
					, ATT_ShipToAddressCode
					, ATT_ContactName
					, ATT_ContactPhone
					, ATT_LadingDecription
					, ATT_ReportRemarks
					, ATT_PaymentMethod
					, ATT_MustRespondByDate
					, ATT_MustRespondByTime
					, ATT_SCAC
					, ATT_ContinuousMove
					, ATT_CarrierID
					, ATT_MilesTotalDistance
					, ATT_Customer
					, ATT_Equipment
					, ATT_EquipmentDescription
					, ATT_TemperatureControl
					, ATT_EquipmentLength
					, ATT_TotalFreightWeight
					, ATT_TotalFreightCost
					, ATT_TotalFreightVolumeCube
					, ATT_BillToName
					, ATT_BillToAddress1
					, ATT_BillToCity
					, ATT_BillToState
					, ATT_BillToZip
					, ATT_BillToCountry
					, ATT_BillToCode
					, ATT_ContactName1
					, ATT_ContactPhone1
					, ATT_ReportRemarks1
					, ATT_Reference
					, ATT_PO
					, ATT_Quantity
					, ATT_UOM
					, ATT_Weight1
					, ATT_WeightUOM
					, ATT_VolumeCubicFeet
					, ATT_PaymentMethod1
					, ATT_LocationIdValue
					, ATT_Latitude
					, ATT_Longitude
					, ATT_WeightQualifier
					, ATT_WeightUnitCode
					, ATT_LadingQuantity
					INTO #TempProSolicitudesEDIDetalles2
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProSolicitudesEDIDetalles',2) 
					WITH (ATT_IdentSolicitud varchar(100)
					    , ATT_TransactionID  varchar(100)
						, ATT_AccountingID VARCHAR(100)
						, ATT_Purpose VARCHAR(100)
						, ATT_Type VARCHAR(150)
						, ATT_StopNum VARCHAR(100)
						, ATT_StopReason VARCHAR(100)
						, ATT_StopWeight VARCHAR(100)
						, ATT_StopVolume VARCHAR(100)
						, ATT_BOL VARCHAR(100)
						, ATT_PONumber VARCHAR(100)
						, ATT_TrackingNum VARCHAR(100)
						, ATT_DockNum VARCHAR(100)
						, ATT_CustomerOrder VARCHAR(100)
						, ATT_RequestedPickupDate VARCHAR(100)
						, ATT_RequestedPickupTime VARCHAR(100)
						, ATT_RequestedDeliveryDate VARCHAR(100)
						, ATT_RequestedDeliveryTime VARCHAR(100)
						, ATT_DoNotShipBefore VARCHAR(100)
						, ATT_ShipNoLaterThan VARCHAR(100)
						, ATT_Weight VARCHAR(100)
						, ATT_Pieces VARCHAR(100)
						, ATT_Volume VARCHAR(100)
						, ATT_PalletsShipped VARCHAR(100)
						, ATT_PalletExchangeCode VARCHAR(100)
						, ATT_ShipFromName VARCHAR(100)
						, ATT_ShipFromAddress1 VARCHAR(100)
						, ATT_ShipFromAddress2 VARCHAR(100)
						, ATT_ShipFromCity VARCHAR(100)
						, ATT_ShipFromState VARCHAR(100)
						, ATT_ShipFromZip VARCHAR(100)
						, ATT_ShipFromCountry VARCHAR(100)
						, ATT_ShipFromAddressCode VARCHAR(100)
						, ATT_ShipToName VARCHAR(100)
						, ATT_ShipToAddress1 VARCHAR(100)
						, ATT_ShipToAddress2 VARCHAR(100)
						, ATT_ShipToCity VARCHAR(100)
						, ATT_ShipToState VARCHAR(100)
						, ATT_ShipToZip VARCHAR(100)
						, ATT_ShipToCountry VARCHAR(100)
						, ATT_ShipToAddressCode VARCHAR(100)
						, ATT_ContactName VARCHAR(100)
						, ATT_ContactPhone VARCHAR(100)
						, ATT_LadingDecription VARCHAR(100)
						, ATT_ReportRemarks VARCHAR(100)
						, ATT_PaymentMethod VARCHAR(100)
						, ATT_MustRespondByDate VARCHAR(100)
						, ATT_MustRespondByTime VARCHAR(100)
						, ATT_SCAC VARCHAR(100)
						, ATT_ContinuousMove VARCHAR(100)
						, ATT_CarrierID VARCHAR(100)
						, ATT_MilesTotalDistance VARCHAR(100)
						, ATT_Customer VARCHAR(100)
						, ATT_Equipment VARCHAR(100)
						, ATT_EquipmentDescription VARCHAR(100)
						, ATT_TemperatureControl VARCHAR(100)
						, ATT_EquipmentLength VARCHAR(100)
						, ATT_TotalFreightWeight VARCHAR(100)
						, ATT_TotalFreightCost VARCHAR(100)
						, ATT_TotalFreightVolumeCube VARCHAR(100)
						, ATT_BillToName VARCHAR(100)
						, ATT_BillToAddress1 VARCHAR(100)
						, ATT_BillToCity VARCHAR(100)
						, ATT_BillToState VARCHAR(100)
						, ATT_BillToZip VARCHAR(100)
						, ATT_BillToCountry VARCHAR(100)
						, ATT_BillToCode VARCHAR(100)
						, ATT_ContactName1 VARCHAR(100)
						, ATT_ContactPhone1 VARCHAR(100)
						, ATT_ReportRemarks1 VARCHAR(100)
						, ATT_Reference VARCHAR(100)
						, ATT_PO VARCHAR(100)
						, ATT_Quantity VARCHAR(100)
						, ATT_UOM VARCHAR(100)
						, ATT_Weight1 VARCHAR(100)
						, ATT_WeightUOM VARCHAR(100)
						, ATT_VolumeCubicFeet VARCHAR(100)
						, ATT_PaymentMethod1 VARCHAR(100)
						, ATT_LocationIdValue VARCHAR(30)
						, ATT_Latitude VARCHAR(50)
						, ATT_Longitude VARCHAR(50)
						, ATT_WeightQualifier VARCHAR(100)
						, ATT_WeightUnitCode VARCHAR(100)
						, ATT_LadingQuantity VARCHAR(100))

					EXEC sp_xml_removedocument @docHandle
                
					INSERT INTO ProSolicitudesEDIDetalles(CreadoEl
														, CreadoPor
														, IdSolicitudEDI
														, IdentSolicitud
														, TransactionID
														, AccountingID
														, Purpose
														, [Type]
														, StopNum
														, StopReason
														, StopWeight
														, StopVolume
														, BOL
														, PONumber
														, TrackingNum
														, DockNum
														, CustomerOrder
														, RequestedPickupDate
														, RequestedPickupTime
														, RequestedDeliveryDate
														, RequestedDeliveryTime
														, DoNotShipBefore
														, ShipNoLaterThan
														, [Weight]
														, Pieces
														, Volume
														, PalletsShipped
														, PalletExchangeCode
														, ShipFromName
														, ShipFromAddress1
														, ShipFromAddress2
														, ShipFromCity
														, ShipFromState
														, ShipFromZip
														, ShipFromCountry
														, ShipFromAddressCode
														, ShipToName
														, ShipToAddress1
														, ShipToAddress2
														, ShipToCity
														, ShipToState
														, ShipToZip
														, ShipToCountry
														, ShipToAddressCode
														, ContactName
														, ContactPhone
														, LadingDecription
														, ReportRemarks
														, PaymentMethod
														, MustRespondByDate
														, MustRespondByTime
														, SCAC
														, ContinuousMove
														, CarrierID
														, MilesTotalDistance
														, Customer
														, Equipment
														, EquipmentDescription
														, TemperatureControl
														, EquipmentLength
														, TotalFreightWeight
														, TotalFreightCost
														, TotalFreightVolumeCube
														, BillToName
														, BillToAddress1
														, BillToCity
														, BillToState
														, BillToZip
														, BillToCountry
														, BillToCode
														, ContactName1
														, ContactPhone1
														, ReportRemarks1
														, Reference
														, PO
														, Quantity
														, UOM
														, Weight1
														, WeightUOM
														, VolumeCubicFeet
														, PaymentMethod1
														, LocationIdValue
														, Latitude
														, Longitude
														, WeightQualifier
														, WeightUnitCode
														, LadingQuantity)
					SELECT 
					  @CreadoEl
					, @CreadoPor
					, @IdSolicitudEDI
					, ATT_IdentSolicitud
					, ATT_TransactionID
					, ATT_AccountingID
					, ATT_Purpose
					, ATT_Type
					, ATT_StopNum
					, ATT_StopReason
					, ATT_StopWeight
					, ATT_StopVolume
					, ATT_BOL
					, ATT_PONumber
					, ATT_TrackingNum
					, ATT_DockNum
					, ATT_CustomerOrder
					, ATT_RequestedPickupDate
					, ATT_RequestedPickupTime
					, ATT_RequestedDeliveryDate
					, ATT_RequestedDeliveryTime
					, ATT_DoNotShipBefore
					, ATT_ShipNoLaterThan
					, ATT_Weight
					, ATT_Pieces
					, ATT_Volume
					, ATT_PalletsShipped
					, ATT_PalletExchangeCode
					, dbo.fn_ConversionUTF8(ATT_ShipFromName)
					, dbo.fn_ConversionUTF8(ATT_ShipFromAddress1)
					, ATT_ShipFromAddress2
					, dbo.fn_ConversionUTF8(ATT_ShipFromCity)
					, ATT_ShipFromState
					, ATT_ShipFromZip
					, dbo.fn_ConversionUTF8(ATT_ShipFromCountry)
					, ATT_ShipFromAddressCode
					, dbo.fn_ConversionUTF8(ATT_ShipToName)
					, dbo.fn_ConversionUTF8(ATT_ShipToAddress1)
					, ATT_ShipToAddress2
					, dbo.fn_ConversionUTF8(ATT_ShipToCity)
					, dbo.fn_ConversionUTF8(ATT_ShipToState)
					, ATT_ShipToZip
					, dbo.fn_ConversionUTF8(ATT_ShipToCountry)
					, ATT_ShipToAddressCode
					, ATT_ContactName
					, ATT_ContactPhone
					, ATT_LadingDecription
					, ATT_ReportRemarks
					, ATT_PaymentMethod
					, ATT_MustRespondByDate
					, ATT_MustRespondByTime
					, ATT_SCAC
					, ATT_ContinuousMove
					, ATT_CarrierID
					, ATT_MilesTotalDistance
					, ATT_Customer
					, ATT_Equipment
					, ATT_EquipmentDescription
					, ATT_TemperatureControl
					, ATT_EquipmentLength
					, ATT_TotalFreightWeight
					, ATT_TotalFreightCost
					, dbo.fn_ConversionUTF8(ATT_TotalFreightVolumeCube)
					, dbo.fn_ConversionUTF8(ATT_BillToName)
					, dbo.fn_ConversionUTF8(ATT_BillToAddress1)
					, ATT_BillToCity
					, ATT_BillToState
					, ATT_BillToZip
					, ATT_BillToCountry
					, ATT_BillToCode
					, ATT_ContactName1
					, ATT_ContactPhone1
					, ATT_ReportRemarks1
					, ATT_Reference
					, ATT_PO
					, ATT_Quantity
					, ATT_UOM
					, ATT_Weight1
					, ATT_WeightUOM
					, ATT_VolumeCubicFeet
					, ATT_PaymentMethod1
					, dbo.fn_ConversionUTF8(ATT_LocationIdValue)
					, ATT_Latitude
					, ATT_Longitude
					, ATT_WeightQualifier
					, ATT_WeightUnitCode
					, ATT_LadingQuantity
					FROM #TempProSolicitudesEDIDetalles2
				END        
			-----------------FIN DE MODIFICAR-----------
			-----------------AVISO----------------------
			SET @DoNotShipBefore = (SELECT TOP 1 [DoNotShipBefore] FROM [ProSolicitudesEDIDetalles]WHERE IdSolicitudEDI = @IdSolicitudEDI AND ISNULL(DoNotShipBefore,'') <> '')

			INSERT INTO SisAvisos(Asunto
								, Aviso
								, CreadoEl
								, CreadoPor
								, EnviarEl
								, RecordarCadaMin
								, AtendidoPor
								, AtendidoEl
								, ComentariosAtendio
								, EnviarTodosLosUsuarios)
			VALUES(''
				 , 'Has recibido una solicitud de Viaje del cliente ' + dbo.fn_ConversionUTF8(@Cliente) + ', dentro de tu Modulo EDI. Se pide respuesta antes de ' + @DoNotShipBefore
				 , @CreadoEl
				 , @CreadoPor
				 , @CreadoEl
				 , 5
				 , NULL
				 , NULL
				 , NULL
				 , 1)
        END 
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

