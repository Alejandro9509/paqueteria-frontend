
CREATE TRIGGER [dbo].[trg_CatTiposPolizas]
   ON  [dbo].[CatTiposPolizas]
   AFTER UPDATE
AS 
BEGIN	
	IF (SELECT DefinidoPorSistema FROM deleted) = 1 
	BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON I.Nombre <> D.Nombre OR I.Codigo <> D.Codigo)
			RAISERROR(N'El Campo nombre y código no puede ser modificado porque está definido por sistema',
				16,
				1
				)
	END

	IF EXISTS(Select Top 1 IdPrepoliza from CatPrepolizas Where IdTipoPoliza = (SELECT IdTipoPoliza FROM deleted)) 
	OR EXISTS(Select Top 1 IdPoliza from ProPolizas Where IdTipoPoliza = (SELECT IdTipoPoliza FROM deleted)) 
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.Nombre <> D.Nombre)
		RAISERROR(N'El nombre no se puede modificar porque ya cuenta con movimientos de pólizas o prepólizas',
			16,
			1
			)
	END	
	
	IF EXISTS(Select Top 1 IdPoliza from ProPolizas Where IdTipoPoliza = (SELECT IdTipoPoliza FROM deleted)) 
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.UsarNumeroPor <> D.UsarNumeroPor)
		RAISERROR(N'El modo de numerar las pólizas no se puede modificar porque ya cuenta con movimientos de pólizas',
			16,
			1
			)
	END	

END
go

