
CREATE PROCEDURE [dbo].[usp_SisOTPAgregarPQ](
	@NumeroTelefono varchar(15),
	@OTP varchar(5),
	@FechaHora datetime
	)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@NumeroTelefono, '') = '' begin			
			RAISERROR(N'*INICIO*El número de teléfono es un campo requerido*FIN*', 16, 1);
			return
		end;
		IF ISNULL(@OTP, '') = '' begin
			RAISERROR(N'*INICIO*La contraseña de un solo uso es un campo requerido*FIN*', 16, 1);
			return 
		end;
		IF ISNULL(@FechaHora, '') = '' begin
			RAISERROR(N'*INICIO*La fecha y hora es un campo requerido*FIN*', 16, 1);
			return 
		end;

		INSERT INTO SisOTPPQ(NumeroCelular, OTP, FechaHora)
		VALUES (@NumeroTelefono, @OTP, @FechaHora)


	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

