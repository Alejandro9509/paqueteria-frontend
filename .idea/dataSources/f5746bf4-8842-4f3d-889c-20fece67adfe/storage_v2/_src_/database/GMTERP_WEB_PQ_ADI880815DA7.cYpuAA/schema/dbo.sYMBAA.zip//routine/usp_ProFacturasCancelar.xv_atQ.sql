CREATE PROCEDURE [dbo].[usp_ProFacturasCancelar]
	@IdFactura int,
	@Estatus tinyint,
	@MotivoCancelacion varchar(500),
	@CanceladoEl datetime,
	@CanceladoPor int,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@CancelacionExterna bit

/* ****************************************************************************************************************************************************************

Descripción: El procedimiento cancela la factura recibida junto con sus relaciones, ademas de liberar otros documentos.
13/08/2019   Se agregó una seccion para detectar si la factura tiene una relacion con una factura por anticipo, en caso de ser asi,
			 limpia dichas relacion, dejando libre a las facturas.
24/08/2019   Se cambio la sección donde se limpia la relación entre facturas ligadas a una factura por anticipo, en base a la tabla puente de ProFacturasRelacion

Modificada por: David Omar Cabrera Bernal
Fecha de mofidicacion: 13/08/2019
Versión:  8.0.45.13
Solicitud 000064

Modificada por: David Omar Cabrera Bernal
Fecha de mofidicacion: 13/10/2019
Versión:  8.0.47.11
Solicitud 000427

**************************************************************************************************************************************************************** */

AS
DECLARE
	@IdCliente int,
	@IdClienteViaje int,
	@IdFolio int,
	@IdMoneda int,
	@Total money,
    @ViajeConCP bit,
    @IdMonedaViajeAnt int,
    @TotalViajeAnt money,
    @FacturableViajeAnt bit,
    @IdViaje int,
    @FacturadoParcialmente bit,-- es una badera para identificar si la factura es tipo 3
    @TipoFactura tinyint,
    @FolioContraRecibo int,
    @ErrorContraRecibo Varchar(200),
    @FacturableRecorridoAnt bit,
    @IdMonedaRecorridoAnt int,
    @TotalRecorridoAnt money,
    @IdClienteRecorrido int,
    @IdRecorrido int,
    @IdFacturaLigada int,
    @ModificadoEl datetime,
	@IdRelacionLiquidacionPemex INT
    
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdFactura = 0
		RAISERROR(N'El identificador de la factura es un campo requerido',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM ProFacturas WHERE IdFactura = @IdFactura) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)

	IF (SELECT FechaHora FROM ProFacturas WHERE IdFactura = @IdFactura) > @CanceladoEl
		RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de elaboración',
			16,
			1
			)
			
	IF (SELECT ISNULL(Abonos,0) FROM ProFacturas WHERE IdFactura = @IdFactura) <> 0
		RAISERROR(N'No puede cancelar esta factura porque tiene abonos',
			16,
			1
			)

	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 1--pagada
		RAISERROR(N'No puede cancelar esta factura porque está pagada',
			16,
			1
			)

	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) = 2--cancelada
		RAISERROR(N'No puede cancelar esta factura porque está cancelada',
			16,
			1
			)
			
	IF (SELECT CanceladoEl FROM ProFacturas WHERE IdFactura = @IdFactura) IS NOT NULL --cancelado
		RAISERROR(N'No puede cancelar esta factura porque está cancelada',
			16,
			1
			)			

	IF LTRIM(RTRIM(@MotivoCancelacion)) = ''
		RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)
			
	IF (SELECT FacturaExterna FROM ProFacturas WHERE IdFactura = @IdFactura) = 1 AND ISNULL(@CancelacionExterna,0) = 0
	RAISERROR(N'No se puede cancelar esta factura por que es externa ',
		16,
		1
		)
			
	SET @ModificadoEl = (SELECT convert(datetime, convert(char(19), GETDATE(), 126) ))													
	UPDATE ProFacturas	
	SET Estatus = @Estatus,
	MotivoCancelacion = @MotivoCancelacion,	
	CanceladoEl = @CanceladoEl,
	CanceladoPor = @CanceladoPor,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @CanceladoPor
	WHERE IdFactura = @IdFactura
	
	-- se desminuye el saldo de cliente
	SET @Total = (SELECT Total FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @IdMoneda = (SELECT IdMoneda FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @IdCliente = (SELECT IdCliente FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @IdFolio = (SELECT IdFolio FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @TipoFactura = (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura)

	IF @IdMoneda = 1 OR @IdMoneda = 3
		UPDATE CatClientes SET SaldoCredito = SaldoCredito - @Total WHERE IdCliente = @IdCliente
	ELSE
		UPDATE CatClientes SET SaldoCreditoDLLS = SaldoCreditoDLLS - @Total WHERE IdCliente = @IdCliente	
	
	-- se cancela el movimiento de cobranza tipo factura
	UPDATE ProCobranza SET 
	CanceladoEl = @CanceladoEl,
	CanceladoPor = @CanceladoPor,
	CanceladoElSistema = GETDATE()
	WHERE IdFactura = @IdFactura AND IdConceptoCobranza = 1
	
	--cancela las ligas de facturas con viajes
	UPDATE ProViajesFacturas SET
	CanceladoEl = @CanceladoEl,
	CanceladoPor = @CanceladoPor
	WHERE IdFactura = @IdFactura
	
	DECLARE ProViajesCursor CURSOR LOCAL FOR 
	SELECT pv.Facturable,pv.IdMoneda,pv.ViajeConCP,pv.SubTotal,pv.IdViaje,pv.FacturadoParcialmente,pv.IdCliente	
	FROM ProViajes AS pv
	INNER JOIN ProViajesFacturas AS pvf ON pv.IdViaje = pvf.IdViaje
	WHERE pvf.IdFactura = @IdFactura
	
	OPEN ProViajesCursor
	FETCH NEXT FROM ProViajesCursor
	INTO @FacturableViajeAnt,@IdMonedaViajeAnt,@ViajeConCP,@TotalViajeAnt,@IdViaje,@FacturadoParcialmente,@IdClienteViaje
	
    WHILE @@FETCH_STATUS = 0
    BEGIN
		IF @ViajeConCP = 1
			SET @TotalViajeAnt = (SELECT Total FROM ProViajesCartasPorte WHERE CanceladoEl IS NULL AND IdViaje = @IdViaje)

        IF @FacturableViajeAnt = 1     
        BEGIN
            IF @IdMonedaViajeAnt = 1 OR @IdMonedaViajeAnt = 3
                UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0)  + @TotalViajeAnt WHERE IdCliente = @IdClienteViaje
            ELSE
                UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) + @TotalViajeAnt WHERE IdCliente = @IdClienteViaje
        END
        
        IF @TipoFactura = 3
        BEGIN
			UPDATE ProViajesConceptosFacturacion SET
			ImporteFacturado = ISNULL(ProViajesConceptosFacturacion.ImporteFacturado,0)-ProViajesConceptosFacturacionFacturadosParcialmente.ImporteFacturado
			FROM ProViajesConceptosFacturacion 
			INNER JOIN ProViajesConceptosFacturacionFacturadosParcialmente ON ProViajesConceptosFacturacion.IdConceptoFacturacion = ProViajesConceptosFacturacionFacturadosParcialmente.IdConceptoFacturacion AND ProViajesConceptosFacturacion.IdViaje = ProViajesConceptosFacturacionFacturadosParcialmente.IdViaje
			WHERE ProViajesConceptosFacturacion.IdViaje = @IdViaje AND ProViajesConceptosFacturacionFacturadosParcialmente.IdFactura = @IdFactura
			
			IF NOT EXISTS(SELECT * FROM ProViajesConceptosFacturacion WHERE IdViaje = @IdViaje AND ImporteFacturado != 0)
				SET @FacturadoParcialmente = 0				
        END
					
		UPDATE ProViajes SET 
		PendienteFacturar = 1,
		FacturadoParcialmente = @FacturadoParcialmente,
		ModificadoEl = @CanceladoEl, 
		ModificadoPor = @CanceladoPor 
		WHERE IdViaje = @IdViaje
		
		-- Se actualiza de la tabla de cp/viaje liberado por la utileria
	   IF EXISTS(SELECT IdFacturaAnterior FROM ProViajesCartasPorteLiberadas WHERE IdFacturaAnterior = @IdFactura AND IdViaje = @IdViaje)
		BEGIN
			UPDATE ProViajesCartasPorteLiberadas 
			SET IdFacturaAnterior = null,
			ModificadoEl = @CanceladoEl, 
			ModificadoPor = @CanceladoPor  
			WHERE IdFacturaAnterior = @IdFactura
			AND IdViaje = @IdViaje
		END
		ELSE
		BEGIN
			IF EXISTS(SELECT IdFacturaActual FROM ProViajesCartasPorteLiberadas WHERE IdFacturaActual = @IdFactura AND IdViaje = @IdViaje)
			BEGIN
				UPDATE ProViajesCartasPorteLiberadas 
				SET IdFacturaActual = null,
				ModificadoEl = @CanceladoEl, 
				ModificadoPor = @CanceladoPor 
				WHERE IdFacturaActual = @IdFactura
				AND IdViaje = @IdViaje
			END
		END 
		--------------------------------------------------------------------------------------				
		FETCH NEXT FROM ProViajesCursor
		INTO @FacturableViajeAnt,@IdMonedaViajeAnt,@ViajeConCP,@TotalViajeAnt,@IdViaje,@FacturadoParcialmente,@IdClienteViaje
	END
	
    CLOSE ProViajesCursor
    DEALLOCATE ProViajesCursor
    
    --cancela las ligas de facturas con recorridos
    
    UPDATE ProRecorridosFacturas SET
	CanceladoEl = @CanceladoEl,
	CanceladoPor = @CanceladoPor
	WHERE IdFactura = @IdFactura
    
    DECLARE ProRecorridosCursor CURSOR FOR 
	SELECT pr.Facturable,pr.IdMoneda,pr.SubTotal,pr.IdRecorrido,pr.IdCliente	
	FROM ProRecorridos AS pr
	INNER JOIN ProRecorridosFacturas AS prf ON pr.IdRecorrido = prf.IdRecorrido
	WHERE prf.IdFactura = @IdFactura
	
	OPEN ProRecorridosCursor
	FETCH NEXT FROM ProRecorridosCursor
	INTO @FacturableRecorridoAnt,@IdMonedaRecorridoAnt,@TotalRecorridoAnt,@IdRecorrido,@IdClienteRecorrido
	
    WHILE @@FETCH_STATUS = 0
    BEGIN

        IF @FacturableRecorridoAnt = 1     
        BEGIN
            IF @IdMonedaRecorridoAnt = 1 OR @IdMonedaRecorridoAnt = 3
                UPDATE CatClientes SET PendFacturar = ISNULL(PendFacturar,0)  + @TotalRecorridoAnt WHERE IdCliente = @IdClienteRecorrido
            ELSE
                UPDATE CatClientes SET PendFacturarDLLS = ISNULL(PendFacturarDLLS,0) + @TotalRecorridoAnt WHERE IdCliente = @IdClienteRecorrido
        END
					
		UPDATE ProRecorridos SET 
		PendienteFacturar = 1,
		ModificadoEl = @CanceladoEl, 
		ModificadoPor = @CanceladoPor 
		WHERE IdRecorrido = @IdRecorrido
						
		FETCH NEXT FROM ProRecorridosCursor
		INTO @FacturableRecorridoAnt,@IdMonedaRecorridoAnt,@TotalRecorridoAnt,@IdRecorrido,@IdClienteRecorrido
	END
	
    CLOSE ProRecorridosCursor
    DEALLOCATE ProRecorridosCursor

	-- Si es Factura Por Relación Pemex se libera la relación
	IF @TipoFactura = 10
	BEGIN
		-- Obtenemos el Id de la relación Pemex
		SET @IdRelacionLiquidacionPemex = (SELECT TOP 1 IdRelacionLiquidacionPemex FROM ProFacturasRelacionPemex WHERE IdFactura = @IdFactura)

		-- Actualizamos el estatus de la relación
		UPDATE ProRelacionLiquidacionesPemex SET Estatus = 1 
		WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex

		-- Cancelamos los registros de tabla
		UPDATE ProFacturasRelacionPemex SET CanceladoEl = @CanceladoEl, CanceladoPor = @CanceladoPor
		WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex

	END
	
	-- actualiza el estatus del folio
	UPDATE CatFolios SET Estatus = 3 WHERE IdFolio = @IdFolio

	-- CONTRARECIBO

	  DECLARE @IdContraReciboCliente  int 
   	  SELECT @IdContraReciboCliente = pcc.IdContraReciboCliente FROM ProFacturas As pfa
				INNER JOIN  ProContraRecibosClienteFacturas As pccf ON pfa.IdFactura = pccf.IdFactura
				INNER JOIN  ProContraRecibosCliente As pcc ON pccf.IdContraReciboCliente = pcc.IdContraReciboCliente
				WHERE  pfa.IdFactura = @IdFactura AND  Isnull(pcc.CanceladoEl,0) = 0 

   
      IF ISNULL(@IdContraReciboCliente,0) > 0 
        BEGIN
			DECLARE @DocFacturaContraRecibo varchar(50), 	
					@ImporteClienteDLLSContraRecibo money,
					@ImporteClientePESOSContraRecibo money

			SET @ImporteClienteDLLSContraRecibo = 0
			SET @ImporteClientePESOSContraRecibo = 0  
           
			IF @IdMoneda= 2
				SET @ImporteClienteDLLSContraRecibo   = @Total
			ELSE
				SET @ImporteClientePESOSContraRecibo  = @Total
			
			--UPDATE ProContraRecibosClienteFacturas set IdCobranza = @IdCobranza where IdFactura = @ATT_IdFactura
			UPDATE ProContraRecibosCliente 
					SET TotalDolares = TotalDolares- @ImporteClienteDLLSContraRecibo ,
						TotalPesos = TotalPesos - @ImporteClientePESOSContraRecibo
			WHERE ProContraRecibosCliente.IdContraReciboCliente =  	@IdContraReciboCliente 
			
		 -- Actualizar estatus		
			DECLARE @CantidadFacturas int, @CantidadFacturasPagadas int 
			SET @CantidadFacturas = (SELECT  count(ProFacturas.Estatus)
											FROM  ProContraRecibosClienteFacturas INNER JOIN
													ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
											WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @IdContraReciboCliente  AND ProFacturas.Estatus<> 2) )

			SET @CantidadFacturasPagadas =(SELECT  count(ProFacturas.Estatus)
											FROM  ProContraRecibosClienteFacturas INNER JOIN
													ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
											WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @IdContraReciboCliente  and ProFacturas.Estatus = 1 AND ProFacturas.Estatus<> 2 ))
			
			IF @CantidadFacturasPagadas > 0 
				IF @CantidadFacturas = @CantidadFacturasPagadas
					UPDATE ProContraRecibosCliente SET Estatus = 2, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
					WHERE IdContraReciboCliente = @IdContraReciboCliente   -- Pagada
				ELSE
					UPDATE ProContraRecibosCliente SET Estatus = 1, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
					WHERE IdContraReciboCliente = @IdContraReciboCliente  -- Parcialmente pagada
			--Se agrega seccion para actualizar los saldos del contrarecibo SOLICITUD 10087
			ELSE
				UPDATE ProContraRecibosCliente SET Estatus = 0, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
				WHERE IdContraReciboCliente = @IdContraReciboCliente   -- Pendiente de pagar
			END
			--Termina actualizar estatus de contrarecibos
			IF @CantidadFacturas  = 0
			begin
				UPDATE ProContraRecibosCliente SET Estatus = 0, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
				WHERE IdContraReciboCliente = @IdContraReciboCliente -- Pendiente de pagar
			end
			/*FACTURAS PARCIALES*/
			IF (SELECT  count(ProFacturas.Estatus) FROM  ProContraRecibosClienteFacturas 
				INNER JOIN ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
				WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @IdContraReciboCliente 
				AND EXISTS(SElECT pc.IdCobranza fROM ProCobranza pc WHERE pc.IdCobranza = ProContraRecibosClienteFacturas.IdCobranza 
				And pc.CanceladoEl is null)
				AND ProFacturas.Estatus = 0 AND ProFacturas.Estatus<> 2 )) > 0 
			BEGIN
				UPDATE ProContraRecibosCliente SET Estatus = 1, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
				WHERE IdContraReciboCliente = @IdContraReciboCliente -- Parcialmente pagada
			END
	-- FIN DE CONTRARECIBO

	--Se libera la relacion entre la factura y las facturas por anticipos ligadas
	DECLARE @FacturaRelacionPorAnticipo int
	SET @FacturaRelacionPorAnticipo = ( SELECT ISNULL( FacturaRelacionPadre, 0 ) FROM ProFacturas WHERE IdFactura = @IdFactura )
	
	--Se cambió la condicion para el borrado de la relacion entre facturas, ahora borrandose de la tabla de ProFacturasRelacion
	IF @FacturaRelacionPorAnticipo <> 0
	BEGIN
		DELETE FROM ProFacturasRelacion WHERE IdFactura = @IdFactura
	END

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

