CREATE PROCEDURE [dbo].[usp_CatTiposCambioEliminar]
@IdTipoCambio int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		DELETE CatTiposCambio
		WHERE IdTipoCambio = @IdTipoCambio
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

