CREATE PROCEDURE [dbo].[usp_CatDatosModificar]
	@Nombre varchar(50),
	@ConsultaSQL ntext,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@dsCatDatosParametros ntext,
	@IdDato int,
	@UltimaModificacion datetime
AS
DECLARE 
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

		IF ISNULL(@IdDato,0) <= 0
			RAISERROR(N'El identificador del dato es un campo requerido',
				16,
				1
				)

		IF NOT EXISTS(SELECT IdDato FROM CatDatos WHERE IdDato = @IdDato)
			RAISERROR(N'Este registro fue eliminado por otro usuario',
				16,
				1
				)		

		IF (SELECT ModificadoEl FROM CatDatos WHERE IdDato = @IdDato) <> @UltimaModificacion
			RAISERROR(N'Este dato fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
				16,
				1
				)								
				
		IF LTRIM(RTRIM(@Nombre)) = ''
			RAISERROR(N'El nombre del dato es un campo requerido',
				16,
				1
				)

		IF EXISTS(SELECT Nombre FROM CatDatos WHERE Nombre = @Nombre AND IdDato != @IdDato)
			RAISERROR(N'El nombre del dato ya esta registrado',
				16,
				1
				)

		IF @ConsultaSQL IS NULL
			RAISERROR(N'La consulta es un campo requerido',
				16,
				1
				)
				
		UPDATE CatDatos SET
			ConsultaSQL = @ConsultaSQL,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor,
			Nombre = @Nombre
		WHERE IdDato = @IdDato

		--SE AGREGA O ACTUALIZAN LA TABLA DE DATOS PARAMETROS
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatDatosParametros

		SELECT ATT_Parametro,ATT_Descripcion,ATT_TipoParametro,ATT_IdDatoParametro
		INTO #TempCatDatosParametros
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatDatosParametros',2) 
		WITH (ATT_Parametro varchar(15),ATT_Descripcion varchar(20),ATT_TipoParametro tinyint,ATT_IdDatoParametro int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatDatosParametros(Descripcion,Parametro,TipoParametro,CreadoEl,CreadoPor)
		SELECT ATT_Descripcion,ATT_Parametro,ATT_TipoParametro,@ModificadoEl,@ModificadoPor
		FROM #TempCatDatosParametros
		WHERE ATT_IdDatoParametro = 0
		
		UPDATE CatDatosParametros SET
			CatDatosParametros.Descripcion = #TempCatDatosParametros.ATT_Descripcion,
			CatDatosParametros.Parametro = #TempCatDatosParametros.ATT_Parametro,
			CatDatosParametros.TipoParametro = #TempCatDatosParametros.ATT_TipoParametro,
			CatDatosParametros.ModificadoEl = @ModificadoEl, 
			CatDatosParametros.ModificadoPor = @ModificadoPor
		FROM CatDatosParametros
		INNER JOIN #TempCatDatosParametros ON CatDatosParametros.IdDatoParametro = #TempCatDatosParametros.ATT_IdDatoParametro

		DELETE FROM CatDatosParametros WHERE (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

