CREATE PROCEDURE [dbo].[usp_CatFoliosGetIdFolioDisponiblePQ]
	@IdSucursal int,
	@Rfc varchar(13)
AS
declare @Serie varchar(50);
declare @IdTipoDocumento int;

select @Serie=isnull(SerieFolios,''),@IdTipoDocumento=IdTipoDocumento from SisParametrosPQ where RFC=@Rfc;

SELECT MIN(IdFolio) AS IdFolio FROM CatFolios WHERE IdTipoDocumento = @IdTipoDocumento AND Serie = @Serie AND Estatus = 1 and IdSucursal=@IdSucursal
go

