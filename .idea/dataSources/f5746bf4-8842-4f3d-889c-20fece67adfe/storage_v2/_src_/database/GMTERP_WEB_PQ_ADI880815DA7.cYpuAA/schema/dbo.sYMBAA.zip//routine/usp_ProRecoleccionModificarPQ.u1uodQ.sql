CREATE PROCEDURE [dbo].[usp_ProRecoleccionModificarPQ](
	@IdSucursal int,
	@IdEmbarque int,
	@IdInforme int,
	@IdGuia int,

	@Fecha varchar(82),
	@Hora varchar(82),
	@FechaRegistro varchar(80),
	@HoraRegistro varchar(80),
	@IdEstatusRecoleccion int,
	@Moneda int,
	@TipoCambio float,
	@IdTipoCobro int,

	@NombreRemitente varchar(80),
	@NombreDestinatario varchar(80),
	@RFCRemitente varchar(13),
	@RFCDestinatario varchar(13),
	@DomicilioRemitente varchar(80),

	@DomicilioDestinatario varchar(80),
	@IdCodigoPostalRemitente int,
	@IdCodigoPostalDestinatario int,
	@IdCiudadRemitente int,

	@IdCiudadDestinatario int,
	@CorreoRemitente varchar(80),
	@CorreoDestinatario varchar(80),
	@TelefonoRemitente varchar(13),

	@TelefonoDestinatario varchar(13),
	@ContactoRemitente varchar(80),
	@ContactoDestinatario varchar(80),
	@IdCiudadOrigen int,
	@IdCiudadDestino int,

	@NoPaquetes int,
	@NoSobres int,
	@IdOperador int,
	@IdUnidad int,
	@IdRemolque int,
	@FechaSalida date,
	@FechaLlegada date,
	@HoraSalida time,
	@HoraLlegada time,
	------- detalle recoleccion---------
	@FechaDetalleRecoleccion date,
	@HoraDetalleRecoleccion time,
	@IdCPDetalleRecoleccion int,
	@IdCiudadDetalleRecoleccion int,
	@IdZonaDetalleRecoleccion int,
	@DomicilioDetalleRecoleccion varchar(80),
	@RecogerEnDetalleRecoleccion varchar(80),
	@DatosAdicionalesDetalleRecoleccion varchar(400),
	---------detalle entrega------------
	@IdCPDetalleEntrega int,
	@IdCiudadDetalleEntrega int,
	@IdZonaDetalleEntrega int,
	@DomicilioDetalleEntrega varchar(80),
	@EntregarEnDetalleEntrega varchar(80),
	@DatosAdicionalesDetalleEntrega varchar(400),
	@IdRecoleccion int,
	@FolioRecoleccion varchar(80),
	@IdCliente int,
	@RecoleccionDiferenteDomicilio bit,
	@EntregaDiferenteDomicilio bit,
	@IdZonaRemitente int,
	@IdZonaDestinatario int,
	@IdRemitente int,
	@IdDestinatario int,
	@AliasRemitente varchar(100),
	@AliasDestinatario varchar(100),
	@RecoleccionConCita bit,


	@FechaCita varchar(50),
	@HoraCitaMinima varchar(50),
	@HoraCitaMaxima varchar(50),



	@CalleRemitente varchar(100),
	@NoIntRemitente varchar(20),
	@NoExtRemitente varchar(20),
	@ColoniaRemitente varchar(100),
	@CalleDestinatario varchar(100),
	@NoIntDestinatario varchar(20),
	@NoExtDestinatario varchar(20),
	@ColoniaDestinatario varchar(100),
	@Latitud text,
	@Longitud text,
	@IdZonaOperativa int,
	@IdZonaTarifa int,
	@IdEstadoRemitente int,
	@IdEstadoDestinatario int,
	@MunicipioRemitente varchar(50),
	@MunicipioDestinatario varchar(50),

	@IdZonaOperativaEntrega int,
	@IdZonaTarifaEntrega int,
	@IdEstadoRecoleccion int,
	@CodigoMunicipioRecoleccion varchar(100),
	@IdEstadoEntrega int,
	@CodigoMunicipioEntrega varchar(100),
	@ValorDeclarado float,
	@IdSucursalEntrega int,
	@EntregaSucursal bit,
    @IdTipoSeguro int,
    @PorcentajeSeguro float,
    @AplicaSeguro bit
	)
AS
BEGIN
	BEGIN TRANSACTION
	DECLARE @FOLIO int;
	DECLARE @FOLIOSTR varchar(10);
	DECLARE @FechaDetalleRecoleccionDate date;
	DECLARE @HoraDetalleRecoleccionTime time;
	DECLARE @FechaRegistroDate date;
	DECLARE @HoraRegistroTime time;
	DECLARE @FechaSalidaDate date;
	DECLARE @FechaLlegadaDate date;

	DECLARE @HoraSalidaTime time;
	DECLARE @HoraLlegadaTime time;

	DECLARE @FechaCitaDate date;
	DECLARE @HoraCitaMinimaTime time;
	DECLARE @HoraCitaMaximaTime time;


		IF ISNULL(@NombreRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre de remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NombreDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre de destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdSucursal, 0) <= 0 begin
			RAISERROR(N'*INICIO*El identificador de sucursal es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		IF ISNULL(@Moneda, 0) < 0 begin
			RAISERROR(N'*INICIO*El Moneda de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@TipoCambio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdTipoCobro, 0) < 0 begin
			RAISERROR(N'*INICIO*El Identificador de tipo de cobro es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NombreRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@RFCRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El RFC del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@DomicilioRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El Domicilio del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCodigoPostalRemitente, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Codigo del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		IF ISNULL(@IdCiudadRemitente, 0) <= 0 begin
			RAISERROR(N'*INICIO*La ciudad del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@ContactoRemitente, '') = '' begin
			RAISERROR(N'*INICIO*El contacto del remitente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCiudadOrigen, 0) <= 0 begin
			RAISERROR(N'*INICIO*La ciudad origen es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NombreDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El nombre del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@DomicilioDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El domicilio del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCodigoPostalDestinatario, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Codigo postal destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCiudadDestinatario, 0) <= 0 begin
			RAISERROR(N'*INICIO*La Ciudad del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@CorreoDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El correo del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@TelefonoDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El telefono del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@ContactoDestinatario, '') = '' begin
			RAISERROR(N'*INICIO*El contacto del destinatario es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCiudadDestino, 0) <= 0 begin
			RAISERROR(N'*INICIO*La ciudad destino es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoPaquetes, 0) < 0 begin
			RAISERROR(N'*INICIO*El numero de paquetes es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoSobres, 0) < 0 begin
			RAISERROR(N'*INICIO*El numero de sobres es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdOperador, 0) < 0 begin
			RAISERROR(N'*INICIO*El Id de operador es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdCliente, 0) < 0 begin
			RAISERROR(N'*INICIO*El responsable de pago es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdUnidad, 0) < 0 begin
			RAISERROR(N'*INICIO*El Id de unidad es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end;

		IF @FechaDetalleRecoleccion IS NOT NULL AND LEN(@FechaDetalleRecoleccion) > 1 begin
	set @FechaDetalleRecoleccionDate = CAST(@FechaDetalleRecoleccion as date)
	set @HoraDetalleRecoleccionTime = CAST(@HoraDetalleRecoleccion as time)
	end

	IF @FechaRegistro IS NOT NULL AND LEN(@FechaRegistro) > 1 begin
	set @FechaRegistroDate = CAST(@FechaRegistro as date)
	set @HoraRegistroTime= CAST(@HoraRegistro as time)
	end

	IF @FechaSalida IS NOT NULL AND LEN(@FechaSalida) > 1 begin
	set @FechaSalidaDate = CAST(@FechaSalida as date)
	set @HoraSalidaTime= CAST(@HoraSalida as time)
	end


	IF @FechaLlegada IS NOT NULL AND LEN(@FechaLlegada) > 1 begin
	set @FechaLlegadaDate= CAST(@FechaLlegada as date)
	set @HoraLlegadaTime= CAST(@HoraLlegada as time)
	end

	IF @FechaCita IS NOT NULL AND LEN(@FechaCita) > 1 begin
		set @FechaCitaDate= CAST(@FechaCita as date)
		set @HoraCitaMinimaTime= CAST(@HoraCitaMinima as time)
		set @HoraCitaMaximaTime= CAST(@HoraCitaMaxima as time)
	end


    Update ProRecoleccionPQ
    Set IdSucursal                    = @IdSucursal,
        IdEmbarque                    = @IdEmbarque,
        IdInforme                     = @IdInforme,
        IdGuia                        = @IdGuia,
        IdEstatusRecoleccion          = @IdEstatusRecoleccion,
        Moneda                        = @Moneda,
        TipoCambio                    = @TipoCambio,
        IdTipoDecobro                 = @IdTipoCobro,
        NoPaquetes                    = @NoPaquetes,
        NoSobres                      = @NoSobres,
        IdOperador                    = @IdOperador,
        IdUnidad                      = @IdUnidad,
        IdRemolque                    = @IdRemolque,
        FechaSalida                   = @FechaSalidaDate,
        FechaLlegada                  = @FechaLlegadaDate,
        HoraSalida                    = @HoraSalidaTime,
        HoraLlegada                   = @HoraLlegadaTime,
        IdCliente                     = @IdCliente,
        
        --remitente
        IdRemitente                   = @IdRemitente,
        AliasRemitente                = @AliasRemitente,
        CalleRemitente                = @CalleRemitente,
        NoIntRemitente                = @NoIntRemitente,
        NoExtRemitente                = @NoExtRemitente,
        ColoniaRemitente              = @ColoniaRemitente,
        NombreRemitente               = @NombreRemitente,
        RFCRemitente                  = @RFCRemitente,
        DomicilioRemitente            = @DomicilioRemitente,
        IdCodigoPostalRemitente       = @IdCodigoPostalRemitente,
        IdCiudadRemitente             = @IdCiudadRemitente,
        CorreoRemitente               = @CorreoRemitente,
        TelefonoRemitente             = @TelefonoRemitente,
        ContactoRemitente             = @ContactoRemitente,
        IdEstadoRemitente             =@IdEstadoRemitente,
        MunicipioRemitente=@MunicipioRemitente,
        IdZonaRemitente               = @IdZonaRemitente,
        --destinatario
        IdDestinatario                = @IdDestinatario,
        AliasDestinatario             = @AliasDestinatario,
        CalleDestinatario             = @CalleDestinatario,
        NoIntDestinatario             = @NoIntDestinatario,
        NoExtDestinatario             = @NoExtDestinatario,
        ColoniaDestinatario           = @ColoniaDestinatario,
        NombreDestinatario            = @NombreDestinatario,
        DomicilioDestinatario         = @DomicilioDestinatario,
        RFCDestinatario               = @RFCDestinatario,
        IdCodigoPostalDestinatario    = @IdCodigoPostalDestinatario,
        IdCiudadDestinatario          = @IdCiudadDestinatario,
        CorreoDestinatario            = @CorreoDestinatario,
        TelefonoDestinatario          = @TelefonoDestinatario,
        ContactoDestinatario          = @ContactoDestinatario,
        IdEstadoDestinatario=@IdEstadoDestinatario,
        MunicipioDestinatario=@MunicipioDestinatario,
        IdZonaDestinatario            = @IdZonaDestinatario,
        --recoleccion diferente domicilio
        RecoleccionDiferenteDomicilio = @RecoleccionDiferenteDomicilio,
        IdEstadoRecoleccion=@IdEstadoRecoleccion,
        CodigoMunicipioRecoleccion=@CodigoMunicipioRecoleccion,
        IdCPDetalleRecoleccion = @IdCPDetalleRecoleccion,
        DomicilioDetalleRecoleccion = @DomicilioDetalleRecoleccion,
        RecogerEnDetalleRecoleccion = @RecogerEnDetalleRecoleccion,
        DatosAdicionalesDetalleRecoleccion = @DatosAdicionalesDetalleRecoleccion,
        --entrega diferente domicilio
        EntregaDiferenteDomicilio     = @EntregaDiferenteDomicilio,
        IdEstadoEntrega=@IdEstadoEntrega,
        CodigoMunicipioEntrega=@CodigoMunicipioEntrega,
        IdCPDetalleEntrega = @IdCPDetalleEntrega,
        DomicilioDetalleEntrega = @DomicilioDetalleEntrega,
        EntregarEnDetalleEntrega = @EntregarEnDetalleEntrega,
        DatosAdicionalesDetalleEntrega = @DatosAdicionalesDetalleEntrega,
        
        --cita
        RecoleccionConCita            = @RecoleccionConCita,
        FechaCita                     = @FechaCitaDate,
        HoraCitaMinima                = @HoraCitaMinimaTime,
        HoraCitaMaxima                = @HoraCitaMaximaTime,
        --general
        IdZonaOperativa               = @IdZonaOperativa,
        IdZonaTarifa                  = @IdZonaTarifa,
        IdCiudadOrigen                = @IdCiudadOrigen,
        IdCiudadDestino               = @IdCiudadDestino,
        IdZonaOperativaEntrega=@IdZonaOperativaEntrega,
        IdZonaTarifaEntrega=@IdZonaTarifaEntrega,
        Latitud                       = @Latitud,
        Longitud                      = @Longitud,
		ValorDeclarado	              = @ValorDeclarado,
		IdSucursalEntrega			  = @IdSucursalEntrega,
		EntregaSucursal				  = @EntregaSucursal,
        IdTipoSeguro                  = @IdTipoSeguro,
        PorcentajeSeguro              = @PorcentajeSeguro,
        AplicaSeguro                  = @AplicaSeguro

    where IdRecoleccion = @IdRecoleccion

	IF @RecoleccionDiferenteDomicilio = 0 BEGIN
	update CatRemitentesDestinatarios SET Latitud = @Latitud, Longitud = @Longitud  Where IdRemitenteDestinatario = @IdRemitente
	END
		--
		--
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				--SET @id = SCOPE_IDENTITY() ;
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
		--RETURN @id;
end
go

