CREATE TRIGGER [dbo].[trg_CatRutasPersonal]
   ON  [dbo].[CatRutasPersonal]
   AFTER UPDATE
AS 
BEGIN
	IF EXISTS(Select Top 1 IdRutaPersonal from ProRecorridos Where IdRutaPersonal = (SELECT IdRutaPersonal FROM deleted))	
	BEGIN
		IF EXISTS(SELECT * FROM
        INSERTED I
        JOIN DELETED D ON D.IdCliente <> I.IdCliente OR D.IdOrigen <> I.IdOrigen OR D.IdDestino <> I.IdDestino)		
		RAISERROR(N'La ruta no puede modificarse porque tiene recorridos asignados',
			16,
			1
			)
	END	
	
END
go

