CREATE PROCEDURE [dbo].[usp_CatTablaValoresAgregar]
	@Descripcion VARCHAR(50),
	@IdGrupoCliente INT,
	@IdTipoUnidad INT,
	@ProcentajeSobreFlete DECIMAL(10, 6),
	@CreadoEl DATETIME,
	@CreadoPor INT,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Procedimiento usp_CatTablaValoresAgregar

Parámetros: 
	@Descripcion				(entrada, texto).	Descripcion del valor de calculo
	@IdGrupoCliente				(entrada, entero).	Id del grupo de cliente del valor de calculo
	@IdTipoUnidad				(entrada, entero).	Id tipo de unidad del valor de calculo
	@ProcentajeSobreFlete		(entrada, decimal).	Procentaje de valor sobre el flete
	@CreadoEl					(entrada, fecha hora). Fecha y hora de creacion
	@CreadoPor					(entrada, entero). Usuario que crea el activo fijo
	@IdPeticion					(entrada, string). Id de la Petición, generada en WEBDEV 	
 
Descripción: Procedimiento para modificar una valor de caluclo

22/05/2020 - Se cambio el parametro de cliente por Grupo de Cliente

Implementada por: Jesús Humberto Morales
Fecha de implementacion: 12/05/2020
Versión ERP: 8.0.52.05

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 22/05/2020
Versión ERP: 8.0.52.26

Invocada desde: PAGE_CatTablaValoresAM (Solicitud 1937)
***************************************************************************************************** */

AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Descripcion, '') = ''
				RAISERROR(N'La descripción del valor del calculo es un campo requerido', 16, 1)

		IF ISNULL(@IdGrupoCliente,0) <= 0 
				RAISERROR(N'El Id del grupo del cliente es un campo requerido', 16, 1)

		IF ISNULL(@IdTipoUnidad,0) <= 0 
				RAISERROR(N'El id de tipo de unidad es un campo requerido', 16, 1)

		IF ISNULL(@ProcentajeSobreFlete,0) <= 0 
				RAISERROR(N'El porcentaje sobre el flete es un campo requerido', 16, 1)

		IF EXISTS(SELECT TOP 1 IdTablaValores FROM CatTablaValores WHERE IdGrupoCliente = @IdGrupoCliente AND IdTipoUnidad = @IdTipoUnidad)
			RAISERROR(N'Ya existe un registro con el grupo de cliente y unidad seleccionada, favor de validar.', 16, 1)
	
		INSERT INTO CatTablaValores (Descripcion, CreadoPor, CreadoEl, IdGrupoCliente, IdTipoUnidad, ProcentajeSobreFlete)
		VALUES (@Descripcion, @CreadoPor, @CreadoEl, @IdGrupoCliente, @IdTipoUnidad, @ProcentajeSobreFlete)
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

