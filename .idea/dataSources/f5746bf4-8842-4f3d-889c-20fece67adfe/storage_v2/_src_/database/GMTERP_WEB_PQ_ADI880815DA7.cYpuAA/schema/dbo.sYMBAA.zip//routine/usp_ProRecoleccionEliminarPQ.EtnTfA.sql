CREATE PROCEDURE [dbo].[usp_ProRecoleccionEliminarPQ]
	@IdRecoleccion INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdRecoleccion,0) <= 0 
			RAISERROR(N'Identificador de recoleccion es un campo requerido', 16, 1)
		DELETE FROM ProRecoleccionPQ
		WHERE IdRecoleccion = @IdRecoleccion
		DELETE FROM ProRecoleccionComplementosSATPQ
		WHERE IdRecoleccion = @IdRecoleccion
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

