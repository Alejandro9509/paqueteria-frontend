
/* *************************************************************************************************
Script de agregar naviera para el catálogo de Navieras

Parámetros: 
	@IdNaviera int,					(entrada, int). Naviera asignada a control de tiempos
	@IdCliente int,					(entrada, int). Clienta asigado a control de tiempos
	@FreeDays int,					(entrada, int).
	@ChassisFreeDays int,			(entrada, int).
	@ContainerFreeDays int,			(entrada, int).
	@EffectiveDate datetime,		(entrada, fecha hora).
	@ServiceContract varchar(15),	(entrada, string).
	@IdPeticion varchar(100)		(entrada, string). Id de la Petición, generada en WEBDEV

Descripción: El procedimiento crea la información de los tiempos de las navieras previamente creadas
			 para el Catálogo de Navieras del módulo Operación Portuaria.

Implementada por: David Rivera Navarro
Fecha de implementación: 13/08/2019
Versión: 8.0.45.13

Modificada por:   
Fecha de mofidicación: 
Versión:  

Invocada desde: PAGE_CatNavierasTiemposPopUp (Solicitud 121)

Valor de retorno: NA.

Ejemplo de Uso: NA.

***************************************************************************************************** */


CREATE PROCEDURE [dbo].[usp_CatNavierasTiemposAgregar]
	@IdNaviera int,
	@IdCliente int,
	@FreeDays int,
	@ChassisFreeDays int,
	@ContainerFreeDays int,
	@EffectiveDate datetime,
	@ServiceContract varchar(15),
	@CreadoEl datetime,
	@CreadoPor int,
	@IdPeticion varchar(100)
AS

DECLARE
-- Id de Control de tiempos de naviera que se obtendrá después Agregar un nuevo registro de control de tiempos para asociarla con el historial de control de tiempos
	@IdNavieraTiempo int

BEGIN TRY
	BEGIN TRANSACTION

	-- Se verifica que los valores contengan información antes de ser agregados
	IF ISNULL(@IdNaviera,0)= 0
		RAISERROR(N'La naviera es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdCliente,0)= 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF ISNULL(@FreeDays,0)= 0
		RAISERROR(N'Free Days es un campo requerido',
			16,
			1
			)

	IF ISNULL(@ChassisFreeDays,0)= 0
		RAISERROR(N'Chassis Free Days es un campo requerido',
			16,
			1
			)

	IF ISNULL(@ChassisFreeDays,0)= 0
		RAISERROR(N'Chassis Free Days es un campo requerido',
			16,
			1
			)

	IF ISDATE(@EffectiveDate) = 0
		RAISERROR(N'Effective date es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@ServiceContract)) = ''
		RAISERROR(N'Service Contract es un campo requerido',
			16,
			1
			)

	-- Si no tiene valor se asignan valores por defecto
	IF @CreadoEl IS NULL
		SET @CreadoEl = SYSDATETIME()

	-- Se Crea un control de tiempos para la naviera y cliente
		INSERT INTO CatNavierasTiempos(IdNaviera, IdCliente, FreeDays, ChassisFreeDays, ContainerFreeDays, EffectiveDate, ServiceContract, CreadoEl, CreadoPor)
		VALUES(@IdNaviera, @IdCliente, @FreeDays, @ChassisFreeDays, @ContainerFreeDays, @EffectiveDate, @ServiceContract, @CreadoEl, @CreadoPor)

	--Se obtiene el ultimo registro del contro de tiempos previamente agregado
	SET @IdNavieraTiempo = SCOPE_IDENTITY()

	-- Se Crea un historial para el registro de control de tiempos
	IF @IdNavieraTiempo IS NOT NULL
	INSERT INTO CatNavierasTiemposHistorial(CreadoEl, CreadoPor, IdNavieraTiempo, IdNaviera, IdCliente, FreeDays, ChassisFreeDays, ContainerFreeDays, EffectiveDate, ServiceContract)
	VALUES(@CreadoEl, @CreadoPor, @IdNavieraTiempo, @IdNaviera, @IdCliente, @FreeDays, @ChassisFreeDays, @ContainerFreeDays, @EffectiveDate, @ServiceContract)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

