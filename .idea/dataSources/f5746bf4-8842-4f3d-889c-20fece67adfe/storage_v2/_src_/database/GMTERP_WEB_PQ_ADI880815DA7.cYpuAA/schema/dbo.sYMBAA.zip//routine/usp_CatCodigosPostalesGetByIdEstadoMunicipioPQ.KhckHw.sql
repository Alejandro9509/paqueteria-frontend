CREATE PROCEDURE [dbo].[usp_CatCodigosPostalesGetByIdEstadoMunicipioPQ]
	@IdEstado varchar(5),
	@CodeMunicipio varchar(5)
AS

SELECT IdCodigoPostal as m_nIdCP, CodigoPostal as m_sCP, Colonia as m_sColonia,IdEstado as m_nIdEstado, Localidad as m_sLocalidad FROM CatCodigosPostales WHERE IdEstado = @IdEstado and CodigoMunicipio = @CodeMunicipio order by CodigoPostal, Colonia
go

