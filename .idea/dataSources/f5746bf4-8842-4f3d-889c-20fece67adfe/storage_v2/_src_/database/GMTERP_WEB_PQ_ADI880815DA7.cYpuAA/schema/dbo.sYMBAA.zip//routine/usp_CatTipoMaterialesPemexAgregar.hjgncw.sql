CREATE PROC [dbo].[usp_CatTipoMaterialesPemexAgregar]
    @Codigo int,
    @Descripcion varchar(250),
    @Activo bit,
    @CreadoEl datetime,
    @CreadoPor int,
    @ModificadoEl datetime,
    @ModificadoPor int,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatTipoMaterialesPemexAgregar

Parámetros:
    @Codigo             (entrada, entero). Código del tipo de material PEMEX.
    @Descripcion        (entrada, texto). Descripción del tipo de material PEMEX.
    @Activo             (entrada, booleno). Bandera para saber si se encuentra activo el tipo de material PEMEX.
    @CreadoEl           (entrada, fecha hora). Fecha y hora en la que fue creado el registro.
    @CreadoPor          (entrada, entero). Id del usuario que creo el registro.
    @ModificadoEl       (entrada, fecha hora). Fecha y hora en la que fue modificado el registro.
    @ModificadoPor      (entrada, entero). Id del usuario que modifico el registro.
    @IdPeticion         (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para agregar un nuevo Tipo de Material PEMEX.

04/02/2020 - Se creó.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 04/02/2020
Versión ERP:

Invocada desde: PAGE_CatTipoMaterialPemexAM (Solicitud 997)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
    -- Validaciones
    IF @Codigo = 0
        RAISERROR(N'El código del tipo de material es un campo requerido', 16, 1)

	IF ISNULL(@Descripcion, '') = ''
        RAISERROR(N'El nombre del tipo de material es un campo requerido', 16, 1)

    IF EXISTS(SELECT Codigo FROM CatTipoMaterialesPemex WHERE Codigo = @Codigo)
        RAISERROR(N'Ya existe un tipo de material con el código ingresado, favor de ingresar otro código', 16, 1)

    -- Inserta el registro y aplica el cambio
    INSERT INTO CatTipoMaterialesPemex(Codigo, Descripcion, Activo, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
    VALUES(@Codigo, @Descripcion, @Activo, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor)

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

