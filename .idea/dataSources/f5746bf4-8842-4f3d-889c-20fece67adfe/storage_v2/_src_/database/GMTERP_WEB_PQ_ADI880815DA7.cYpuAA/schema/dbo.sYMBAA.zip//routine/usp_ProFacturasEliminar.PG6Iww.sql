CREATE PROCEDURE [dbo].[usp_ProFacturasEliminar]
	@IdFactura int,
	@IdPeticion varchar(100)
AS
DECLARE
	@IdFolio int,
	@IdFacturaRelacionada int

/*
MODIFICADO:
	Se agregaro un exec usp_ProPolizasActualizarSaldos
	para acutalizar los asientos contables del catalogo CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-30
SOLICITUD: 
	SOLICITUD 000266
*/

/*
MODIFICADO:
	Se agregaro la bitacora de tipo de cambio ( SisBitacoraTipoCambio )
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2021-04-06
SOLICITUD: 
	SOLICITUD 004067
*/
	/* *************************************************************************************************
	SOLICITUD 4861
	
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 22/09/2021
	Versión: Versión 8.0.65.03

	Se modifico para que permita el borraado de las facturas que se encuentran dentro de un contra recibo cliente

	Invocada desde: < ClsProFacturas Eliminar>
	************************************************************************************************ */

BEGIN TRY
	BEGIN TRANSACTION

	IF @IdFactura = 0
		RAISERROR(N'El identificador de la factura es un campo requerido',
			16,
			1
			)

	IF NOT EXISTS(SELECT IdFactura FROM ProFacturas WHERE IdFactura = @IdFactura) 
		RAISERROR(N'La factura ya fue eliminado por otro usuario',
			16,
			1
			)

	IF EXISTS(SELECT TimbrePruebas FROM ProFacturas WHERE IdFactura = @IdFactura AND TimbrePruebas = 0 AND FolioFiscalUUID <> '') -- si es timbre real y tiene uuid
		RAISERROR(N'No puede ser eliminar esta factura porque ya se timbró y esta registrada en el SAT',
			16,
			1
			)	


	IF (SELECT Estatus FROM ProFacturas WHERE IdFactura = @IdFactura) <> 2--No esta cancelada
		RAISERROR(N'No puede ser eliminar esta factura porque no está cancelada',
			16,
			1
			)
	--IF EXISTS(Select IdContraReciboClienteFactura from ProContraRecibosClienteFacturas Where IdFactura = @IdFactura) -- La factura Esta en un cotraRecibo
	IF EXISTS(Select pcrcf.IdContraReciboClienteFactura from ProContraRecibosClienteFacturas pcrcf Where pcrcf.IdFactura = @IdFactura AND pcrcf.IdContraReciboCliente = (SELECT pcrc1.IdContraReciboCliente FROM ProContraRecibosCliente pcrc1 WHERE pcrc1.IdContraReciboCliente =pcrcf.IdContraReciboCliente AND pcrc1.CanceladoEl is null)) -- La factura Esta en un cotraRecibo
		RAISERROR(N'No se puede eliminar esta factura porque está en un contrarecibo',
			16,
			1
			)		
	IF (SELECT FacturaExterna FROM ProFacturas WHERE IdFactura = @IdFactura) = 1 
	RAISERROR(N'No se puede eliminar esta facura por que es externa',
		16,
		1
		)

 --Desligar si es una factura sustituida
	SET @IdFacturaRelacionada = (SELECT IdFactura FROM ProFacturas WHERE IdFacturaAnterior = @IdFactura)
	IF @IdFacturaRelacionada IS NOT NULL 
	BEGIN
		UPDATE ProFacturas SET
			IdFacturaAnterior = NULL,
			FechaSustitucion = NULL,
			FolioSustitucion = NULL
		WHERE IdFactura = @IdFacturaRelacionada
	END

	--se borra de la tabla ProContraRecibosClienteFacturas el registro para que se borre la referencia de la factura con el conrarecibo cliente SOL 4861
	DELETE FROM ProContraRecibosClienteFacturas WHERE IdFactura = @IdFactura
	
-- Borra bitacora de tipo de cambio
	Declare  @TipoFactura int = 0, @IdProcesoPadre int = 0
	SET @TipoFactura = (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @IdFactura)
	SET @IdProcesoPadre = (SELECT
							CASE @TipoFactura
							WHEN 1 THEN '300100'	/*POR CONCEPTO*/
							WHEN 2 THEN '300200'	/*POR VIAJE*/	
							WHEN 3 THEN '300300'	/*POR VIAJE PARCIAL*/
							WHEN 4 THEN '300400'	/*POR PESO DESCARGA*/
							WHEN 5 THEN '300500'	/*POR KILOMETROS*/
							WHEN 6 THEN '300600'	/*POR RECORRIDO*/
							WHEN 7 THEN '300700'	/*GENERAL*/
							WHEN 8 THEN '300800'	/*POR COMBUSTIBLE*/
							--WHEN 9 THEN ''	/*POR ANTICIPO*/
							WHEN 10 THEN '300900'	/*POR RELACION PEMEX*/
							END
							)
	DELETE FROM SisBitacoraTipoCambio WHERE IdDocumento = @IdFactura AND IdProcesoPadre = @IdProcesoPadre

--Borrar y actualizar ProCobranza 
   Update ProCobranza set IdFactura = NULL where IdFactura = @IdFactura and IdNotaCredito is not NULL
   Delete From ProCobranza Where IdFactura = @IdFactura
--Se elimina de ProViajesFacturas
   Delete from ProViajesFacturas where IdFactura = @IdFactura
--Se elimina de ProRecorridosFacturas
   Delete from ProRecorridosFacturas where IdFactura = @IdFactura
   -- Se elimina de ProFacturasPorRelacionPemex
   DELETE FROM ProFacturasRelacionPemex WHERE IdFactura = @IdFactura
   
--Sacamos el IdFolio de ProFacturas
   Set @IdFolio = (Select IdFolio from ProFacturas Where IdFactura = @IdFactura)
--Liberamos el Folio de CatFolios
  Update CatFolios Set Estatus = 1 where IdFolio = @IdFolio
--Borremos ProViajesConceptosFacturacionFacturadosParcialmente
  Delete from ProViajesConceptosFacturacionFacturadosParcialmente where IdFactura = @IdFactura
  --Borramos campos adicionales de Facturas
  Delete from ProFacturasCamposAdicionales where IdFactura = @IdFactura
--Borramos ProFacturas
  Delete from ProFacturas where IdFactura = @IdFactura
	/*Antes de que se elimine la poliza, se van a quitar los asientos contables de CatCuentasContablesSaldos*/
	DECLARE @CondicionQuery nvarchar(max)  = ' pp.ProcesoLigado = ''ProFacturas'' AND pp.IdProcesoLigado IN ( '+CAST(@IdFactura AS varchar)+') ' 
	EXEC usp_ProPolizasActualizarSaldos @IdPeticion,0,@CondicionQuery
  --Borramos las Polizas Ligadas a la Factura. (Si tiene de cancelacion tambien se elimina)
  Delete From ProPolizas Where ProcesoLigado = 'ProFacturas' And IdProcesoLigado = @IdFactura

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

