CREATE TRIGGER [dbo].[trg_ProViajesConceptosFacturacionTimbreProduccion]
	ON [dbo].[ProViajesConceptosFacturacion]
	AFTER UPDATE,INSERT
AS
BEGIN
	IF ISNULL((SELECT TimbrePruebas FROM ProViajesCartasPorte WHERE IdViaje = (SELECT TOP 1 IdViaje FROM deleted)),1) = 0  AND (EXISTS (select * from ProViajesFacturas where IdViaje = (SELECT TOP 1 IdViaje FROM deleted) AND ISNULL(CanceladoEl,'') = ''))
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
        INNER JOIN DELETED D ON I.IdViajeConceptoFacturacion = D.IdViajeConceptoFacturacion
        WHERE D.Importe <> I.Importe OR
        D.TrasladaImpuesto <> I.TrasladaImpuesto OR 
        D.RetieneImpuesto <> I.RetieneImpuesto OR
        D.UnidadMedida <> I.UnidadMedida)
        RAISERROR(N'No puede modificarse los importes de los conceptos de facturación del viaje porque está timbrado y registrado en el SAT',
            16,
            1
            ) 

	END
END
go

