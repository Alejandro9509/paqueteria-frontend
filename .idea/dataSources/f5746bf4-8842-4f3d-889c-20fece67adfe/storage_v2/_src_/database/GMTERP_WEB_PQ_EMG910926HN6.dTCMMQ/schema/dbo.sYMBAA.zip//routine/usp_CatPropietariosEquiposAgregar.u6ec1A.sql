
CREATE PROCEDURE [dbo].[usp_CatPropietariosEquiposAgregar]
@Codigo	int,	
@Descripcion varchar(50),	
@CreadoEl	datetime,	
@CreadoPor	int,	
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del equipo es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Descripcion,'') = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)			
				
			
	IF EXISTS(SELECT Codigo FROM CatPropietariosEquipos WHERE Codigo = @Codigo)
		RAISERROR(N'El código del equipo ya existe',
			16,
			1
			)	
					
	IF EXISTS(SELECT Descripcion FROM CatPropietariosEquipos WHERE Descripcion = @Descripcion)
		RAISERROR(N'La descripción ya existe',
			16,
			1
			)


	INSERT INTO CatPropietariosEquipos(Codigo,Descripcion,CreadoEl,CreadoPor)
	VALUES(@Codigo,@Descripcion,@CreadoEl,@CreadoPor)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

