CREATE PROCEDURE [dbo].[usp_ProNominasModificacionesSalariosAgregar]
	@IdEmpleado int,	
	@TipoSueldo int,
	@Sueldo money,
	@FechaAplicacion date,
	@Aplicado bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@Mixto bit,
	@IdTipoPeriodo int,
	@FechaFin date,
	@IdPeticion varchar(100)
AS
DECLARE
	@IdNominaModificacionSalarios int,
	@TipoModificacion int,
	@FechaInicioPeriodoSiguiente date,
	@FechaFinPeriodoSiguiente date,
	@DiasPeriodo int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdEmpleado,'')= ''
		RAISERROR(N'El IdEmpleado es un campo requerido',
			16,
			1
			)	

	SET @DiasPeriodo= (Select DiasdelPeriodo from CatTiposPeriodos where IdTipoPeriodo=@IdTipoPeriodo)
	SET @FechaInicioPeriodoSiguiente = DATEADD(day, 1,@FechaFin)
	SET @FechaFinPeriodoSiguiente = DATEADD(day, @DiasPeriodo-1,@FechaInicioPeriodoSiguiente)

	IF @FechaAplicacion <= @FechaInicioPeriodoSiguiente OR @FechaAplicacion > @FechaFinPeriodoSiguiente
		BEGIN
		RAISERROR(N'La fecha de aplicación debe ser mayor a la fecha inicio del periodo siguiente o menor a la fecha fin del periodo siguiente',
			16,
			1
			)	
		END

	INSERT INTO ProNominasModificacionesSalarios(IdEmpleado,TipoSueldo,Sueldo,FechaAplicacion,Aplicado,CreadoPor,CreadoEl,Mixto)
	VALUES(@IdEmpleado,@TipoSueldo,@Sueldo,@FechaAplicacion,@Aplicado,@CreadoPor,@CreadoEl,@Mixto)
	
	SET @IdNominaModificacionSalarios =(SELECT IDENT_CURRENT('ProNominasModificacionesSalarios')) 

	--Comienza la aplicacion de los sueldos BaseCotizacion y Base Cotizacion Variable Solicitud 12152
	IF @TipoSueldo = 1 
		BEGIN
			SET @TipoModificacion= 2

			IF @Mixto= 1
				BEGIN
				   SET @TipoModificacion= 4
				END
			IF @FechaAplicacion >= @FechaInicioPeriodoSiguiente AND @FechaAplicacion<=@FechaFinPeriodoSiguiente AND @Aplicado=0
				BEGIN
					UPDATE CatEmpleados SET 
					SalarioBaseCotizacion= @Sueldo,
					FechaSalarioBaseCotizacion = @FechaAplicacion
					WHERE IdEmpleado=@IdEmpleado
					INSERT INTO CatEmpleadosHistorial(IdEmpleado,FechaEstatus,Estatus,CreadoPor,CreadoEl,Sueldo,FechaSueldo,IdentificadorDeHistoria,TipoModificacion)
					VALUES(@IdEmpleado,@FechaAplicacion,1,@CreadoPor,GETDATE(),@Sueldo,@FechaAplicacion,6,@TipoModificacion)	
					
					UPDATE ProNominasModificacionesSalarios SET 
					Aplicado = 1
					where IdNominaModificacionSalarios=@IdNominaModificacionSalarios
				END
		END

	IF @TipoSueldo = 2
		BEGIN
			SET @TipoModificacion= 3
			IF @Mixto= 1
			BEGIN
			   SET @TipoModificacion= 4
			END
			IF @FechaAplicacion >= @FechaInicioPeriodoSiguiente AND @FechaAplicacion<=@FechaFinPeriodoSiguiente AND @Aplicado=0
			BEGIN
				UPDATE CatEmpleados SET 
				SalarioBaseCotizacionVariable= @Sueldo,
				FechaSalarioBaseCotizacionVariable = @FechaAplicacion
				WHERE IdEmpleado=@IdEmpleado
				INSERT INTO CatEmpleadosHistorial(IdEmpleado,FechaEstatus,Estatus,CreadoPor,CreadoEl,Sueldo,FechaSueldo,IdentificadorDeHistoria,TipoModificacion)
				VALUES(@IdEmpleado,@FechaAplicacion,1,@CreadoPor,GETDATE(),@Sueldo,@FechaAplicacion,7,@TipoModificacion)	
				
				UPDATE ProNominasModificacionesSalarios SET 
				Aplicado = 1
				where IdNominaModificacionSalarios=@IdNominaModificacionSalarios
			END
		END
	--------

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

