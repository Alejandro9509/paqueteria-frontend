CREATE TRIGGER [dbo].[trg_ProMovimientosBancariosActualiazaBeneficiario]
	ON dbo.ProMovimientosBancarios
	AFTER INSERT,UPDATE
AS
BEGIN
	UPDATE ProMovimientosBancarios 
		SET TipoBeneficiario =
			 (SELECT TipoBeneficiario 
					 FROM ProCheques WHERE ProCheques.IdCheque= I.IdCheque),
			IdProveedor =
			 (SELECT IdProveedor 
					 FROM ProCheques WHERE ProCheques.IdCheque= I.IdCheque),
			IdBeneficiario =
			 (SELECT IdBeneficiario 
					 FROM ProCheques WHERE ProCheques.IdCheque= I.IdCheque),
			Beneficiario =
			 (SELECT Beneficiario 
					 FROM ProCheques WHERE ProCheques.IdCheque= I.IdCheque)			
		FROM ProMovimientosBancarios PM
		JOIN Inserted I ON PM.IdCheque= I.IdCheque
END
go

