CREATE TRIGGER [dbo].[trg_ProPasivosMovimientosBancariosImportePagado]
	ON [dbo].[ProPasivosMovimientosBancarios]
	AFTER INSERT,DELETE
AS
BEGIN
---Insertar en ProPasivosMovimientosBancarios 
---y actualizar importe pagado (Propasivo)
	UPDATE ProPasivos 
		SET ImportePagado  = 
		   ISNULL((
			SELECT Sum(Importe) 
			FROM ProPasivosMovimientosBancarios   
			WHERE ProPasivosMovimientosBancarios.IdPasivo = I.IdPasivo
			),0)
		FROM ProPasivos P
		JOIN Inserted I ON P.IdPasivo= I.IdPasivo
---y actualizar importe pagado (ProMovimientosBancarios)
	declare @IdMonedaMovimientoBancario int,
			@TipoCambioMovimientoBancario money
	Select @IdMonedaMovimientoBancario= cb.IdMoneda, @TipoCambioMovimientoBancario = pmb.TipoCambio From ProMovimientosBancarios as pmb inner join CatCuentasBancarias as cb on pmb.IdCuentaBancaria = cb.IdCuentaBancaria where IdMovimientoBancario in (Select IdMovimientoBancario from Inserted I )			

	UPDATE   ProMovimientosBancarios
	SET ImportePagado =
			   ISNULL((
				SELECT 
					sum(
					CASE @IdMonedaMovimientoBancario
					   WHEN 1 THEN -- PESOS
							CASE pp.IdMoneda
							 when 1 then  -- Pesos pasivo
									ProPasivosMovimientosBancarios.Importe 
							 WHEN 2 THEN  -- Dolares pasivo
									ProPasivosMovimientosBancarios.Importe * @TipoCambioMovimientoBancario
							END		
					   WHEN 2 THEN -- DOLARES	
					   	CASE pp.IdMoneda
							 when 1 then  -- Pesos pasivo
							  ProPasivosMovimientosBancarios.Importe /@TipoCambioMovimientoBancario
							 WHEN 2 THEN  -- Dolares pasivo
								 ProPasivosMovimientosBancarios.Importe 
						END
					END)
											 				
				FROM ProPasivosMovimientosBancarios inner join ProPasivos as pp ON ProPasivosMovimientosBancarios.IdPasivo = pp.IdPasivo   
				WHERE ProPasivosMovimientosBancarios.IdMovimientoBancario= I.IdMovimientoBancario
				),0)
	FROM  ProMovimientosBancarios PM INNER JOIN
		 Inserted I ON PM.IdMovimientoBancario= I.IdMovimientoBancario			
		  		
---Eliminar en ProPasivosMovimientosBancarios 
---y actualizar importe pagado (Propasivo)
	UPDATE ProPasivos 
		SET ImportePagado  = 
		   ISNULL((
			SELECT Sum(Importe) 
			FROM ProPasivosMovimientosBancarios   
			WHERE ProPasivosMovimientosBancarios.IdPasivo = D.IdPasivo
			),0)
		FROM ProPasivos P
		JOIN Deleted D ON P.IdPasivo= D.IdPasivo	
---y actualizar importe pagado (ProMovimientosBancarios)			
	Select @IdMonedaMovimientoBancario= cb.IdMoneda, @TipoCambioMovimientoBancario = pmb.TipoCambio From ProMovimientosBancarios as pmb inner join CatCuentasBancarias as cb on pmb.IdCuentaBancaria = cb.IdCuentaBancaria where IdMovimientoBancario in (Select IdMovimientoBancario from Deleted D )			

	UPDATE   ProMovimientosBancarios
	SET ImportePagado =
			   ISNULL((
				SELECT 
					sum(
					CASE @IdMonedaMovimientoBancario
					   WHEN 1 THEN -- PESOS
							CASE pp.IdMoneda
							 when 1 then  -- Pesos pasivo
									ProPasivosMovimientosBancarios.Importe 
							 WHEN 2 THEN  -- Dolares pasivo
									ProPasivosMovimientosBancarios.Importe * @TipoCambioMovimientoBancario
							END		
					   WHEN 2 THEN -- DOLARES	
					   	CASE pp.IdMoneda
							 when 1 then  -- Pesos pasivo
							  ProPasivosMovimientosBancarios.Importe /@TipoCambioMovimientoBancario
							 WHEN 2 THEN  -- Dolares pasivo
								 ProPasivosMovimientosBancarios.Importe 
						END
					END)
											 				
				FROM ProPasivosMovimientosBancarios inner join ProPasivos as pp ON ProPasivosMovimientosBancarios.IdPasivo = pp.IdPasivo   
				WHERE ProPasivosMovimientosBancarios.IdMovimientoBancario= D.IdMovimientoBancario
				),0)
	FROM  ProMovimientosBancarios PM INNER JOIN
		 Deleted D ON PM.IdMovimientoBancario= D.IdMovimientoBancario
END
go

