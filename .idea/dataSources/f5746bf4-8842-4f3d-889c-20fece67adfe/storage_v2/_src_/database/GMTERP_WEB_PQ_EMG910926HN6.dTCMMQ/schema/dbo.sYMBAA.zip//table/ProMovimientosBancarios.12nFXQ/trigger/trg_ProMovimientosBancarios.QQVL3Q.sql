CREATE TRIGGER [dbo].[trg_ProMovimientosBancarios]
   ON  [dbo].[ProMovimientosBancarios]
   AFTER UPDATE
AS 
BEGIN
    IF EXISTS(SELECT * FROM ProPolizas WHERE ProcesoLigado = 'ProMovimientosBancarios' AND IdProcesoLigado IN (SELECT IdMovimientoBancario FROM deleted))
        AND EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdMovimientoBancario = D.IdMovimientoBancario 
        WHERE D.Fecha <> I.Fecha)
        RAISERROR(N'La fecha no se puede modificar porque tiene una póliza contable ligada',
            16,
            1
            )

	IF EXISTS(SELECT * FROM ProPolizas WHERE ProcesoLigado = 'ProMovimientosBancariosTraspasos' AND IdProcesoLigado IN (SELECT IdMovimientoBancarioTraspaso FROM ProMovimientosBancariosTraspasos WHERE IdMovimientoBancarioOrigen IN (SELECT IdMovimientoBancario FROM deleted) OR IdMovimientoBancarioDestino  IN (SELECT IdMovimientoBancario FROM deleted)))
	        AND EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdMovimientoBancario = D.IdMovimientoBancario 
        WHERE D.Fecha <> I.Fecha)
        RAISERROR(N'La fecha no se puede modificar porque tiene una póliza contable ligada',
            16,
            1
            )
END
go

