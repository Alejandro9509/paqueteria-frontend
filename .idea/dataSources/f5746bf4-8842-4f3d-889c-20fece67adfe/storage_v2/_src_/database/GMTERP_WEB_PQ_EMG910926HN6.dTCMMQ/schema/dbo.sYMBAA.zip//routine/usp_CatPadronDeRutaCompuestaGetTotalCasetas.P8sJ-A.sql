
	
	CREATE PROCEDURE [dbo].[usp_CatPadronDeRutaCompuestaGetTotalCasetas]
		@FactorUnidad INT,
		@IdRutaDetalle INT
	AS
	declare @Ejes int = 0

	SET @Ejes = (SELECT Ejes FROM CatFactoresTiposUnidad WHERE IdFactorTipoUnidad = @FactorUnidad) 

	SELECT 
	CASE WHEN @Ejes = 2
			THEN SUM(CC.Camion2Ejes)
		WHEN @Ejes = 3
			THEN SUM(CC.Camion3Ejes)
		WHEN @Ejes = 4
			THEN SUM(CC.Camion4Ejes)
		WHEN @Ejes = 5
			THEN SUM(CC.Camion5Ejes)
		WHEN @Ejes = 6
			THEN SUM(CC.Camion6Ejes)
		WHEN @Ejes = 7
			THEN SUM(CC.Camion7Ejes)
		WHEN @Ejes = 8
			THEN SUM(CC.Camion8Ejes)
		WHEN @Ejes = 9
			THEN SUM(CC.Camion9Ejes)
	END AS 'Importe'
	FROM CatPatronRutasDetallesCasetas AS CPRDC
	INNER JOIN CatCasetas AS CC ON CPRDC.IdCaseta = CC.IdCaseta
	WHERE CPRDC.IdPatronRutaDetalle = @IdRutaDetalle
    go

