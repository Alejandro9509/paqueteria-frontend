CREATE TRIGGER [dbo].[trg_ProViajesTerminados]
	ON [dbo].[ProViajes]
	AFTER UPDATE
AS
BEGIN
	DECLARE @ViajeTerminado int, @Derecho int
	SET @ViajeTerminado = (SELECT ViajeTerminado FROM ProViajes WHERE IdViaje = (SELECT IdViaje FROM deleted))
	IF (SELECT TipoUsuario from CatUsuarios where IdUsuario = (SELECT ModificadoPor FROM inserted)) = 1
	BEGIN 
		SET @Derecho = 1
	END
	ELSE
	BEGIN
		SET @Derecho = ISNULL((SELECT Derecho FROM CatUsuariosDerechos WHERE IdUsuario =(SELECT ModificadoPor FROM inserted)  AND IdProceso = 502103),0)
	END
	
	IF @ViajeTerminado = 1
	BEGIN
	
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.FechaHora <> I.FechaHora)
        RAISERROR(N'No puede modificarse el viaje porque está terminado',
            16,
            1
            )        
                      
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.IdCliente <> I.IdCliente)
        RAISERROR(N'No puede modificarse el viaje porque está terminado',
            16,
            1
            )

		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.IdRuta <> I.IdRuta)
        RAISERROR(N'No puede modificarse el viaje porque está terminado',
            16,
            1
            )        
                    
		--IF EXISTS(SELECT * FROM INSERTED I
  --      JOIN DELETED D ON I.IdViaje = D.IdViaje
  --      WHERE D.IdRemitente <> I.IdRemitente)
  --      RAISERROR(N'No puede modificarse el viaje porque está terminado',
  --          16,
  --          1
  --          )        
        
		--IF EXISTS(SELECT * FROM INSERTED I
  --      JOIN DELETED D ON I.IdViaje = D.IdViaje
  --      WHERE D.IdDestinatario <> I.IdDestinatario)
  --      RAISERROR(N'No puede modificarse el viaje porque está terminado',
  --          16,
  --          1
  --          ) 
		IF @Derecho = 0
		BEGIN 	
		       
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (D.IdUnidadCarga1 <> I.IdUnidadCarga1)AND ISNULL(D.IdUnidadCarga1,0) <> 0)
		RAISERROR(N'No puede modificarse el viaje porque está terminado',
			16,
			1
			)
  
		

		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (D.IdUnidadCarga2 <> I.IdUnidadCarga2)AND ISNULL(D.IdUnidadCarga2,0) <> 0 )
		RAISERROR(N'No puede modificarse el viaje porque está terminado',
			16,
			1
			)
         
            
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.IdUnidadContenedor1 <> I.IdUnidadContenedor1)
        RAISERROR(N'No puede modificarse el viaje porque está terminado',
            16,
            1
            )        

		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.IdUnidadContenedor2 <> I.IdUnidadContenedor2)
        RAISERROR(N'No puede modificarse el viaje porque está terminado',
            16,
            1
            )        
            
   
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (D.IdUnidadDolly <> I.IdUnidadDolly)AND ISNULL(D.IdUnidadDolly,0) <> 0)
		RAISERROR(N'No puede modificarse el viaje porque está terminado',
			16,
			1
			) 
          
		
  
		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (D.CodigoUnidadCarga1 <> I.CodigoUnidadCarga1)AND D.CodigoUnidadCarga1 <> '')
		RAISERROR(N'No puede modificarse el viaje porque está terminado',
			16,
			1
			) 
 
        

		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (D.CodigoUnidadCarga2 <> I.CodigoUnidadCarga2)AND D.CodigoUnidadCarga2 <> '')
		RAISERROR(N'No puede modificarse el viaje porque está terminado',
			16,
			1
			)
         
            
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.CodigoUnidadContenedor1 <> I.CodigoUnidadContenedor1 )
        RAISERROR(N'No puede modificarse el viaje porque está terminado',
            16,
            1
            )        

		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.CodigoUnidadContenedor2 <> I.CodigoUnidadContenedor2)
        RAISERROR(N'No puede modificarse el viaje porque está terminado',
            16,
            1
            )   
                       

		IF EXISTS(SELECT * FROM INSERTED I
		JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (D.CodigoUnidadDolly <> I.CodigoUnidadDolly )AND D.CodigoUnidadDolly <> '')
		RAISERROR(N'No puede modificarse el viaje porque está terminado',
			16,
			1
			) 
		
		END

		--IF EXISTS(SELECT * FROM INSERTED I
  --      JOIN DELETED D ON I.IdViaje = D.IdViaje
  --      WHERE LTRIM(RTRIM(D.DatosDestinatario)) <> LTRIM(RTRIM(I.DatosDestinatario)))
  --      RAISERROR(N'No puede modificarse el viaje porque está terminado',
  --          16,
  --          1
  --          )                         

		--IF EXISTS(SELECT * FROM INSERTED I
  --      JOIN DELETED D ON I.IdViaje = D.IdViaje
  --      WHERE LTRIM(RTRIM(D.DatosRemitente)) <> LTRIM(RTRIM(I.DatosRemitente)))
  --      RAISERROR(N'No puede modificarse el viaje porque está terminado',
  --          16,
  --          1
  --          )              
	END
END
go

