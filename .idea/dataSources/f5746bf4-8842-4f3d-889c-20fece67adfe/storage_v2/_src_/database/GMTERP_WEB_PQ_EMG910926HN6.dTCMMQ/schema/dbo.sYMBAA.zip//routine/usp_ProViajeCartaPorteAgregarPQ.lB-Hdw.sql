CREATE PROCEDURE [dbo].[usp_ProViajeCartaPorteAgregarPQ](	
	@TipoCobro int,
	@FechaHora datetime,
	@NoViajeCliente varchar(30) ,
	@IdCliente int,
	@IdSucursal int,
	@IdRemitente int,
	@IdDestinatario int,
	@IdMoneda int,
	@GeneradoDesde int,
	@FechaEstatus datetime,
	@IdEstatusViaje int,
	@Secuencia int,
	@Origen int,
	@Destino int,
	@Kilometros int,
	@Horas decimal(15,2),
	@IdConcepto int,
	@Importe  decimal(20,6),
	@Viaje int,
	@IdGuia int,
	@Rfc varchar(13)

	)
AS
BEGIN
	BEGIN TRANSACTION
		
		DECLARE @FOLIO int;
		DECLARE @FOLIOSTR varchar(10);	
		DECLARE @FechaRegistroDate date;
		DECLARE @HoraRegistroTime time;
		DECLARE @TRACKINGSTR varchar(10);
		DECLARE @IdConceptoFactura int;
		DECLARE @ImporteConcepto decimal(20,6);
		DECLARE @IdImpuesto int;
		DECLARE @IdTipoCalculo int;
		DECLARE @Impuesto decimal(20,6);
		DECLARE @IdFolio int;
		DECLARE @IdCertificado int;
		DECLARE @PorcentajeImpuesto decimal(20,6);
		DECLARE @EsImpuestoFedera int;
		DECLARE @EsImpuestoLocal int;
		DECLARE @ImpuestosTrasladadosFederales decimal(20,6);
		DECLARE @ImpuestosTrasladadosLocal decimal(20,6);
		DECLARE @ImpuestosRetenidoFederales decimal(20,6);
		DECLARE @ImpuestosRetenidoLocal decimal(20,6);
		DECLARE @Serie varchar(50);
		DECLARE @IdTipoDocumento int;
		DECLARE @SubTotal decimal(20,6);
		DECLARE @Total decimal(20,6);
		DECLARE @IdViajeCartaPorteImpuesto int;
		DECLARE @ImporteAcumuladoImpuesto decimal(20,6);
		DECLARE @IdRuta int;
		DECLARE @TipoCambio decimal(20,6);
		DECLARE @MaterialDescripcion varchar(255);
		DECLARE @Peso decimal(20,6);
		DECLARE @Cantidad int;
		DECLARE @Embalaje varchar(100);
		DECLARE @IdUnidadMedida int;
		DECLARE @DatosRemitente varchar(255);
		DECLARE @DatosDestinatario varchar(255);
		DECLARE @IdClienteGenerico int;
		DECLARE @DescripcionRuta varchar (255);
		DECLARE @FolioRutaNueva int;
		DECLARE @IdRutaNueva int;
		DECLARE @TrasladaImpuesto int;
		DECLARE @RetieneImpuesto int;
		DECLARE @IdTipoViaje int;
        DECLARE @ImporteIva decimal(20,6);
        DECLARE @ImporteRetencion decimal(20,6);

		IF ISNULL(@IdSucursal, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoViajeCliente, '') = '' begin
			RAISERROR(N'*INICIO*El numero de viaje cliente es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdEstatusViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus del viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@FechaHora, '') = '' begin
			RAISERROR(N'*INICIO*La fecha de registro es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		

	set @SubTotal = 0;
	set @Total = 0;
	set @TipoCambio=21.5; --TODO: Obtener del embarque
	set @IdEstatusViaje=1; --DOCUMENTADO
	

		IF @@TRANCOUNT > 0
			BEGIN

	select @IdRuta=IdRuta from CatRutas where IdOrigen=@Origen and IdDestino=@Destino  and IdCliente=@IdCliente; --in (select IdCliente from CatClientes where NombreFiscal LIKE '%PUBLICO EN GENERAL%')
    select @IdTipoViaje=IdTipoViaje from CatTiposViajes where TipoViaje like '%CONSOLIDADO%';

	if isnull(@IdRuta,0) = 0
	begin
		select @IdClienteGenerico=IdCliente from CatClientes where NombreFiscal LIKE '%PUBLICO EN GENERAL%';

		select @IdRuta=ct.IdRuta,@Kilometros=ctrt.Kilometros,@Horas=ctrt.Horas,@DescripcionRuta=ct.DescripcionRuta from CatRutasTrayectos ctrt
					inner join CatRutas ct on ct.IdRuta=ctrt.IdRuta
					where ctrt.IdOrigen=@Origen and ctrt.IdDestino=@Destino
					and IdCliente=@IdClienteGenerico;

		select @FolioRutaNueva=max(FolioRuta)+1 from CatRutas;

		if isnull(@IdRuta,0) != 0
			begin
					INSERT INTO [dbo].[CatRutas]
					   ([FolioRuta]
					   ,[IdCliente]
					   ,[IdOrigen]
					   ,[IdDestino]
					   ,[DescripcionRuta]
					   ,[Activa]
					   ,[IdTipoUnidad]
					   ,[Kilometros]
					   ,[Horas]
					   ,[IdSucursal]
					   ,[Item]
					   ,[Planta]
					   ,[Convenio]
					   ,[IdRemitente]
					   ,[IdDestinatario]
					   ,[CreadoPor]
					   ,[CreadoEl]
					   ,[ModificadoPor]
					   ,[ModificadoEl]
					   ,[ViajeFacturable]
					   ,[EquivalenciaCuentaContable1]
					   ,[EquivalenciaCuentaContable2]
					   ,[EquivalenciaCuentaContable3]
					   ,[EquivalenciaCuentaContable4]
					   ,[EquivalenciaCuentaContable5]
					   ,[EquivalenciaCuentaContable6]
					   ,[EquivalenciaCuentaContable7]
					   ,[EquivalenciaCuentaContable8]
					   ,[EquivalenciaCuentaContable9]
					   ,[EquivalenciaCuentaContable10]
					   ,[ImporteBase]
					   ,[IdTipoViaje]
					   ,[IdClasificacionViaje]
					   ,[EquivalenciaCuentaContable11]
					   ,[EquivalenciaCuentaContable12]
					   ,[EquivalenciaCuentaContable13]
					   ,[EquivalenciaCuentaContable14]
					   ,[EquivalenciaCuentaContable15]
					   ,[Millas]
					   ,[ETA]
					   ,[ImportacionExportacion]
					   ,[ViajeInternacional]
					   ,[ViajeRepartoRecolecta])
					   select @FolioRutaNueva
					   ,@IdCliente
					   ,[IdOrigen]
					   ,[IdDestino]
					   ,[DescripcionRuta]
					   ,[Activa]
					   ,[IdTipoUnidad]
					   ,[Kilometros]
					   ,[Horas]
					   ,[IdSucursal]
					   ,[Item]
					   ,[Planta]
					   ,[Convenio]
					   ,[IdRemitente]
					   ,[IdDestinatario]
					   ,[CreadoPor]
					   ,[CreadoEl]
					   ,[ModificadoPor]
					   ,[ModificadoEl]
					   ,[ViajeFacturable]
					   ,[EquivalenciaCuentaContable1]
					   ,[EquivalenciaCuentaContable2]
					   ,[EquivalenciaCuentaContable3]
					   ,[EquivalenciaCuentaContable4]
					   ,[EquivalenciaCuentaContable5]
					   ,[EquivalenciaCuentaContable6]
					   ,[EquivalenciaCuentaContable7]
					   ,[EquivalenciaCuentaContable8]
					   ,[EquivalenciaCuentaContable9]
					   ,[EquivalenciaCuentaContable10]
					   ,[ImporteBase]
					   ,[IdTipoViaje]
					   ,[IdClasificacionViaje]
					   ,[EquivalenciaCuentaContable11]
					   ,[EquivalenciaCuentaContable12]
					   ,[EquivalenciaCuentaContable13]
					   ,[EquivalenciaCuentaContable14]
					   ,[EquivalenciaCuentaContable15]
					   ,[Millas]
					   ,[ETA]
					   ,[ImportacionExportacion]
					   ,[ViajeInternacional]
					   ,[ViajeRepartoRecolecta] from CatRutas where IdRuta=@IdRuta;

					   SET @IdRutaNueva= @@IDENTITY;					 
					   
				INSERT INTO [dbo].[CatRutasTrayectos]
					   ([IdRuta]
					   ,[Secuencia]
					   ,[IdOrigen]
					   ,[IdDestino]
					   ,[Kilometros]
					   ,[Horas]
					   ,[RutaGoogleMap]
					   ,[CreadoEl]
					   ,[CreadoPor]
					   ,[ModificadoEl]
					   ,[ModificadoPor]
					   ,[IdGeocercaDisparaSalida]
					   ,[GeocercaDisparaSalidaES]
					   ,[IdGeocercaDisparaLlegada]
					   ,[GeocercaDisparaLlegadaES]
					   ,[IdEstatuViajeSalida]
					   ,[IdEstatuViajeLlegada]
					   ,[FactorLiqKmsSencilloCargado]
					   ,[FactorLiqKmsSencilloVacio]
					   ,[FactorLiqKmsFullCargado]
					   ,[FactorLiqKmsFullVacio]
					   ,[FactorLiqKmsFullVacioCargado_CargadoVacio]
					   ,[SueldoBaseSencilloCargado]
					   ,[SueldoBaseSencilloVacio]
					   ,[SueldoBaseFullCargado]
					   ,[SueldoBaseFullVacio]
					   ,[SueldoBaseFullVacioCargado_CargadoVacio]
					   ,[SueldoBaseDllsFullCargado]
					   ,[SueldoBaseDllsFullVacio]
					   ,[SueldoBaseDllsFullVacioCargado_CargadoVacio]
					   ,[SueldoBaseDllsSencilloCargado]
					   ,[SueldoBaseDllsSencilloVacio]
					   ,[FactorLiqKmsDllsSencilloVacio]
					   ,[FactorLiqKmsDllsSencilloCargado]
					   ,[FactorLiqKmsDllsFullVacioCargado_CargadoVacio]
					   ,[FactorLiqKmsDllsFullVacio]
					   ,[FactorLiqKmsDllsFullCargado]
					   ,[TipoTrayecto]
					   ,[Millas]
					   ,[ETA])
					   select @IdRutaNueva
					   ,[Secuencia]
					   ,[IdOrigen]
					   ,[IdDestino]
					   ,[Kilometros]
					   ,[Horas]
					   ,[RutaGoogleMap]
					   ,[CreadoEl]
					   ,[CreadoPor]
					   ,[ModificadoEl]
					   ,[ModificadoPor]
					   ,[IdGeocercaDisparaSalida]
					   ,[GeocercaDisparaSalidaES]
					   ,[IdGeocercaDisparaLlegada]
					   ,[GeocercaDisparaLlegadaES]
					   ,[IdEstatuViajeSalida]
					   ,[IdEstatuViajeLlegada]
					   ,[FactorLiqKmsSencilloCargado]
					   ,[FactorLiqKmsSencilloVacio]
					   ,[FactorLiqKmsFullCargado]
					   ,[FactorLiqKmsFullVacio]
					   ,[FactorLiqKmsFullVacioCargado_CargadoVacio]
					   ,[SueldoBaseSencilloCargado]
					   ,[SueldoBaseSencilloVacio]
					   ,[SueldoBaseFullCargado]
					   ,[SueldoBaseFullVacio]
					   ,[SueldoBaseFullVacioCargado_CargadoVacio]
					   ,[SueldoBaseDllsFullCargado]
					   ,[SueldoBaseDllsFullVacio]
					   ,[SueldoBaseDllsFullVacioCargado_CargadoVacio]
					   ,[SueldoBaseDllsSencilloCargado]
					   ,[SueldoBaseDllsSencilloVacio]
					   ,[FactorLiqKmsDllsSencilloVacio]
					   ,[FactorLiqKmsDllsSencilloCargado]
					   ,[FactorLiqKmsDllsFullVacioCargado_CargadoVacio]
					   ,[FactorLiqKmsDllsFullVacio]
					   ,[FactorLiqKmsDllsFullCargado]
					   ,[TipoTrayecto]
					   ,[Millas]
					   ,[ETA] from CatRutasTrayectos where IdRuta=@IdRuta;

					   INSERT INTO [dbo].[CatRutasConceptosFacturacion]
						   ([IdRuta]
						   ,[IdConceptoFacturacion]
						   ,[Importe]
						   ,[ImporteDlls]
						   ,[CreadoPor]
						   ,[CreadoEl]
						   ,[ModificadoPor]
						   ,[ModificadoEl]
						   ,[IdTipoUnidad]
						   ,[IdTipoViaje]
						   ,[IdClasificacionViaje]
						   ,[RetieneImpuesto]
						   ,[TrasladaImpuesto])
					select @IdRutaNueva
						   ,[IdConceptoFacturacion]
						   ,[Importe]
						   ,[ImporteDlls]
						   ,[CreadoPor]
						   ,[CreadoEl]
						   ,[ModificadoPor]
						   ,[ModificadoEl]
						   ,[IdTipoUnidad]
						   ,[IdTipoViaje]
						   ,[IdClasificacionViaje]
						   ,[RetieneImpuesto]
						   ,[TrasladaImpuesto] from [CatRutasConceptosFacturacion] where IdRuta=@IdRuta;

					SET @IdRuta = @IdRutaNueva;
				end
	end
	

	if @IdRuta is not null or @IdRuta > 0
		begin
			select @DatosRemitente=concat(isnull(RFC,''),' ',isnull(Nombre,''),' ',isnull(Calle,''),' ',isnull(NoExterior,''),' ',isnull(Colonia,''),', ',isnull(Municipio,''),' C.P. ',isnull(CodigoPostal,''))
			from CatRemitentesDestinatarios where IdRemitenteDestinatario=@IdRemitente;

			select @DatosDestinatario=concat(isnull(RFC,''),' ',isnull(Nombre,''),' ',isnull(Calle,''),' ',isnull(NoExterior,''),' ',isnull(Colonia,''),', ',isnull(Municipio,''),' C.P. ',isnull(CodigoPostal,''))
			from CatRemitentesDestinatarios where IdRemitenteDestinatario=@IdDestinatario;

			insert into ProViajes(TipoCobroPorViaje, FechaHora, NoViajeCliente, IdCliente, IdSucursal, IdRemitente, IdDestinatario, IdMoneda, GeneradoDesde, Kilometros,
			FechaHoraEstatuViaje, IdEstatuViaje, Viaje,IdGuia,PendienteFacturar,FacturadoParcialmente,SubTotal,ViajeConCP,IdRuta,TipoCambio,CantidadMovimientos,DatosRemitente,DatosDestinatario,IdTipoViaje) values
			(@TipoCobro,@FechaHora ,@NoViajeCliente,@IdCliente,@IdSucursal,@IdRemitente,@IdDestinatario,@IdMoneda,@GeneradoDesde,@Kilometros,@FechaEstatus,@IdEstatusViaje,@Viaje,@IdGuia,1,0,0,1,@IdRuta,@TipoCambio,1,@DatosRemitente,@DatosDestinatario,@IdTipoViaje);

	
				Declare @id int
				SET @id= @@IDENTITY


				insert into ProViajesTrayectos (IdViaje,Secuencia,IdOrigen,IdDestino,Kilometros,Horas) values (@id,@Secuencia,@Origen,@Destino,@Kilometros,@Horas);					
	

				DECLARE ProdGuia CURSOR FOR select IdConceptoFacturacion,Importe,isnull(ImporteIva,0),isnull(ImporteRetiene,0) from ProGuiaConceptoPQ where IdGuia=@IdGuia
				OPEN ProdGuia
					FETCH NEXT FROM ProdGuia INTO @IdConceptoFactura,@ImporteConcepto,@ImporteIva,@ImporteRetencion
					WHILE @@fetch_status = 0
					BEGIN
                        set @TrasladaImpuesto=0;
                        set @RetieneImpuesto=0;

						--select @TrasladaImpuesto=TrasladaImpuesto,@RetieneImpuesto=RetieneImpuesto from CatConceptosFacturacion  where IdConceptoFacturacion=@IdConceptoFactura;
                        if @ImporteIva > 0 
                            begin
                                set @TrasladaImpuesto=1;
                            end

                        if @ImporteRetencion > 0 
                            begin
                                set @RetieneImpuesto=1;
                            end
    
						insert into ProViajesConceptosFacturacion(IdViaje, IdConceptoFacturacion, Importe, TrasladaImpuesto, RetieneImpuesto,UnidadMedida,IncluirCalculoIngresosLiquidacion,IncluirCalculoLiquidacionPorcentajeSobreImpFlete,CreadoEl) 
						values(@id,@IdConceptoFactura,@ImporteConcepto,@TrasladaImpuesto,@RetieneImpuesto,'SERVICIO',1,1,getdate())

						set @SubTotal = @SubTotal + @ImporteConcepto;

						FETCH NEXT FROM ProdGuia INTO @IdConceptoFactura,@ImporteConcepto,@ImporteIva,@ImporteRetencion
					END
				CLOSE ProdGuia
				DEALLOCATE ProdGuia

		

		select @IdTipoDocumento=IdTipoDocumento from SisParametrosPQ where RFC=@Rfc;

		select @IdFolio=MIN(IdFolio) from CatFolios where IdSucursal=@IdSucursal and IdTipoDocumento=@IdTipoDocumento and Estatus=1;

		select @IdCertificado=IdCertificado from CatCertificados where EstatusActivo=1;

		INSERT INTO [dbo].[ProViajesCartasPorte]
           ([IdViaje],[IdFolio],[SubTotal],[ImpuestosTrasladadosFederales],[ImpuestosRetenidosFederales],[ImpuestosTrasladadosLocales],[ImpuestosRetenidosLocales],[Total],[IdCertificado])
		VALUES (@id,@IdFolio,@SubTotal,0,0,0,0,0,@IdCertificado);

		Declare @idProViajesCartasPorte int
			SET @idProViajesCartasPorte= @@IDENTITY

		update CatFolios set Estatus=2 where IdFolio=@IdFolio;
		
		set @ImpuestosTrasladadosFederales = 0;
		set @ImpuestosRetenidoFederales = 0;
		set @ImpuestosTrasladadosLocal = 0;
		set @ImpuestosRetenidoLocal = 0;

			

					DECLARE ProdConceptosFacturacion CURSOR FOR select IdConceptoFacturacion,Importe from ProViajesConceptosFacturacion where IdViaje=@id
						OPEN ProdConceptosFacturacion
							FETCH NEXT FROM ProdConceptosFacturacion INTO @IdConceptoFactura,@ImporteConcepto
							WHILE @@fetch_status = 0
							BEGIN							

								DECLARE ProdImpuestos CURSOR FOR select imp.Porcentaje,imp.TipoCalculo,imp.IdImpuesto,isnull(imp.EsImpuestoFederal,0),isnull(imp.EsImpuestoLocal,0) from CatConceptosFacturacionImpuestos cfi 
															inner join CatImpuestos imp on imp.IdImpuesto=cfi.IdImpuesto
															where cfi.IdConceptoFacturacion=@IdConceptoFactura and cfi.Activo=1
								OPEN ProdImpuestos
									FETCH NEXT FROM ProdImpuestos INTO @PorcentajeImpuesto,@IdTipoCalculo,@IdImpuesto,@EsImpuestoFedera,@EsImpuestoLocal
									WHILE @@fetch_status = 0
									BEGIN

										if isnull(@PorcentajeImpuesto,0) > 0 
											begin
												set @Impuesto=(@ImporteConcepto * @PorcentajeImpuesto) / 100; 
											end
										else
											begin
												set @Impuesto=0;
											end

										select @IdViajeCartaPorteImpuesto=IdViajeCartaPorteImpuesto,@ImporteAcumuladoImpuesto=isnull(Importe,0) from ProViajesCartasPorteImpuestos where IdViajeCartaPorte=@idProViajesCartasPorte and IdImpuesto=@IdImpuesto;

										if isnull(@IdViajeCartaPorteImpuesto,0) = 0 
										begin
											INSERT INTO [dbo].[ProViajesCartasPorteImpuestos]
											   ([IdViajeCartaPorte]
											   ,[IdImpuesto]
											   ,[Importe]
											   ,[CreadoPor]
											   ,[CreadoEl]
											   ,[ModificadoPor]
											   ,[ModificadoEl]) VALUES (@idProViajesCartasPorte,@IdImpuesto ,@Impuesto ,1 ,GETDATE(),1 ,GETDATE());

										end 
										else if @Impuesto >0
											begin
												
											update ProViajesCartasPorteImpuestos set Importe=(@ImporteAcumuladoImpuesto + @Impuesto) where IdViajeCartaPorte=@idProViajesCartasPorte and IdImpuesto=@IdImpuesto;
											  
											end	

											 if @EsImpuestoFedera = 1 and @IdTipoCalculo=1
													begin
														set @ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales + @Impuesto;
													end
												else if @EsImpuestoFedera = 1 and @IdTipoCalculo=2
													begin
														set @ImpuestosRetenidoFederales = @ImpuestosRetenidoFederales + @Impuesto;
													end
										
											 if @EsImpuestoLocal = 1 and @IdTipoCalculo=1
													begin
														set @ImpuestosTrasladadosLocal = @ImpuestosTrasladadosLocal + @Impuesto;
													end
												else if @EsImpuestoLocal = 1 and @IdTipoCalculo=2
													begin
														set @ImpuestosRetenidoLocal = @ImpuestosRetenidoLocal + @Impuesto;
													end

										FETCH NEXT FROM ProdImpuestos INTO @PorcentajeImpuesto,@IdTipoCalculo,@IdImpuesto,@EsImpuestoFedera,@EsImpuestoLocal
									END
								CLOSE ProdImpuestos
								DEALLOCATE ProdImpuestos
				
								FETCH NEXT FROM ProdConceptosFacturacion INTO @IdConceptoFactura,@ImporteConcepto
							END
						CLOSE ProdConceptosFacturacion
						DEALLOCATE ProdConceptosFacturacion

						set @Total = @SubTotal + @ImpuestosTrasladadosFederales + @ImpuestosTrasladadosLocal - @ImpuestosRetenidoFederales - @ImpuestosRetenidoLocal;

						update [dbo].[ProViajesCartasPorte] set [ImpuestosTrasladadosFederales]=@ImpuestosTrasladadosFederales,[ImpuestosRetenidosFederales]=@ImpuestosRetenidoFederales,
						[ImpuestosTrasladadosLocales]=@ImpuestosTrasladadosLocal,[ImpuestosRetenidosLocales]=@ImpuestosRetenidoLocal,[Total]=@Total           
						where [IdViaje]=@id;

						DECLARE ProdMateriales CURSOR FOR select ped.Descripcion,ped.Peso,ped.ctd,cte.Nombre from ProEmbarqueDetallePQ ped
						inner join ProEmbarquePQ pe on pe.IdEmbarque=ped.IdEmbarque
						inner join ProGuiaPQ pg on pg.IdEmbarque=pe.IdEmbarque
						inner join CatEmbalajesPQ cte on cte.IdEmbalaje=ped.IdTipoEmpaque
						where pg.IdGuia=@IdGuia

								OPEN ProdMateriales
									FETCH NEXT FROM ProdMateriales INTO @MaterialDescripcion,@Peso,@Cantidad,@Embalaje
									WHILE @@fetch_status = 0
									BEGIN

									select top 1 @IdUnidadMedida=IdUnidadMedida from CatUnidadesMedida where UnidadMedida LIKE '%'+ @Embalaje +'%';
							
									INSERT INTO [dbo].[ProViajesDescripcionesCarga] ([IdViaje],[Cantidad] ,[IdUnidadMedidaEmbalaje],[DescripcionCarga],[Peso] ,[IdUnidadMedidaPeso])
									VALUES (@id,@Cantidad,@IdUnidadMedida,@MaterialDescripcion,@Peso,21);

									FETCH NEXT FROM ProdMateriales INTO @MaterialDescripcion,@Peso,@Cantidad,@Embalaje
									END
								CLOSE ProdMateriales
								DEALLOCATE ProdMateriales

		end -- IF @IdRuta 

				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

