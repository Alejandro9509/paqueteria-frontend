CREATE TRIGGER [dbo].[trg_ProMovimientosAlmacenConceptosValidarBloqueoAlmacen]
   ON  [dbo].[ProMovimientosAlmacenConceptos]
   AFTER INSERT
AS
DECLARE
@IdAlmacen int,
@MensajeError varchar(MAX)

BEGIN
 SET @IdAlmacen = (SELECT IdAlmacen FROM INSERTED)
 IF EXISTS
  (
   SELECT I.IdAlmacen FROM INSERTED I
   WHERE EXISTS
      (
     SELECT IdAlmacen FROM CatAlmacenes WHERE IdAlmacen = I.IdAlmacen AND Bloqueo = 1
      )
  )
 BEGIN
  
  SET @MensajeError = N'No es posible realizar la acción. Validar que el almacén seleccionado no tenga un ajuste de inventario pendiente, si no es así, posiblemente saliste del proceso de manera incorrecta sin aceptar la forma. Intenta nuevamente desde el botón Agregar.'
  RAISERROR(@MensajeError,
   16,
   1
   )
 END
  

END
go

