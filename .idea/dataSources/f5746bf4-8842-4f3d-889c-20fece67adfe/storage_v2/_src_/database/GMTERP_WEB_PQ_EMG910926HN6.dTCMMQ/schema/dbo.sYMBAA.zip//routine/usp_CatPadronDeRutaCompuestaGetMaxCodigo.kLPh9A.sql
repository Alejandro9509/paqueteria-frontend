

	CREATE PROCEDURE [dbo].[usp_CatPadronDeRutaCompuestaGetMaxCodigo]
	AS
	SELECT ISNULL(MAX(CodigoRuta),0)+1 AS Codigo FROM CatPadronDeRutaCompuesta
    go

