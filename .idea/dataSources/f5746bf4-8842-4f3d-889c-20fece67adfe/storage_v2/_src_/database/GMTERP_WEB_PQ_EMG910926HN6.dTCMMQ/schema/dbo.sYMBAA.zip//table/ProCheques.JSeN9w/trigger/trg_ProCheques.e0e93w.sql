CREATE TRIGGER [dbo].[trg_ProCheques]
   ON  [dbo].[ProCheques]
   AFTER UPDATE
AS 
BEGIN
    DECLARE @IdCheque int
    
    SET @IdCheque = (SELECT IdCheque FROM deleted)
    
    IF EXISTS(SELECT * FROM ProPolizas WHERE ProcesoLigado = 'ProCheques' AND IdProcesoLigado = @IdCheque)
        AND EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdCheque = D.IdCheque 
        WHERE D.Fecha <> I.Fecha OR D.NumeroCheque <> I.NumeroCheque)
        RAISERROR(N'La fecha y el numero no se puede modificar porque tiene una póliza contable ligada',
            16,
            1
            )
END
go

