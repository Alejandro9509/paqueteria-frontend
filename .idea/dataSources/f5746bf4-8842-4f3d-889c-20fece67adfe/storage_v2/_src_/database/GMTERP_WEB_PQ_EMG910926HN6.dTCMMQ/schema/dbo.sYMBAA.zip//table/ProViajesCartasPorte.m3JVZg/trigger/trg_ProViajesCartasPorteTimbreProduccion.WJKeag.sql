CREATE TRIGGER [dbo].[trg_ProViajesCartasPorteTimbreProduccion]
	ON [dbo].[ProViajesCartasPorte]
	AFTER UPDATE
AS
BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
        INNER JOIN DELETED D ON I.IdViajeCartaPorte = D.IdViajeCartaPorte
        WHERE (
        D.ImpuestosRetenidosFederales <> I.ImpuestosRetenidosFederales OR 
        D.ImpuestosRetenidosLocales <> I.ImpuestosRetenidosLocales OR 
        D.ImpuestosTrasladadosFederales <> I.ImpuestosTrasladadosFederales OR 
        D.ImpuestosTrasladadosLocales <> I.ImpuestosTrasladadosLocales OR 
        LTRIM(RTRIM(D.MetodoPago)) <> LTRIM(RTRIM(I.MetodoPago)) OR 
        D.NroCuentaPago <> I.NroCuentaPago OR 
        D.Total <> I.Total) 
        AND (EXISTS (select * from ProViajesFacturas where IdViaje = I.IdViaje and ISNULL(I.CanceladoEl,'')<>'') and (ISNULL(I.TimbrePruebas,1) = 0 OR ISNULL(D.TimbrePruebas,1) = 0))  
		) 
        RAISERROR(N'No puede modificarse el viaje con carta porte porque está timbrado',
            16,
            1
            )        
        	
END
go

