CREATE TRIGGER [dbo].[trg_ProComprasModificar]
	ON [dbo].[ProCompras]
	AFTER UPDATE
AS
BEGIN
	DECLARE @IdCompra int
	SET @IdCompra= (SELECT IdCompra FROM INSERTED I)
	


	IF EXISTS(SELECT * FROM INSERTED I
	INNER JOIN DELETED D ON I.IdCompra = D.IdCompra
	WHERE (I.FolioDocumento <> D.FolioDocumento OR 
	I.SerieDocumento <> D.SerieDocumento)
	 AND EXISTS(SELECT IdPasivo FROM ProPasivos WHERE IdCompra = I.IdCompra and ImportePagado > 0))
	RAISERROR(N'No puede modificarse la compra porque cuenta con un Pasivo ligado',
		16,
		1
		)

	IF EXISTS(SELECT * FROM INSERTED I
	INNER JOIN DELETED D ON I.IdCompra = D.IdCompra
	WHERE (I.FolioDocumento <> D.FolioDocumento OR 
	I.SerieDocumento <> D.SerieDocumento)
	 AND ISNULL(D.FolioFiscalUUID,'')<>'')
	RAISERROR(N'No puede modificarse la compra porque cuenta con UUID ',
		16,
		1
		)
		
	IF EXISTS(SELECT * FROM INSERTED I
	INNER JOIN DELETED D ON I.IdCompra = D.IdCompra
	WHERE (I.FolioDocumento <> D.FolioDocumento OR 
	I.SerieDocumento <> D.SerieDocumento)
	 AND EXISTS(SELECT IdPasivo FROM ProPasivos WHERE IdCompra = I.IdCompra and ISNULL (FolioFiscalUUID,'')<>''))
	RAISERROR(N'No puede modificarse la compra porque cuenta con un Pasivo ligado con UUID',
		16,
		1
		)				  
		   
END
go

