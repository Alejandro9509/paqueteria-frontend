CREATE PROCEDURE [dbo].[usp_Report_Nominas_IMSS_ExportarIDSE]
	@FechaDesde VARCHAR(100),
	@FechaHasta VARCHAR(100),
	@IdTipoPeriodo INT,
	@IdEmpleadoDesde INT,
	@IdEmpleadoHasta INT,
	@IdDepartamentoDesde INT,
	@IdDepartamentoHasta INT,
	@NumeroGuia INT,
	@TipoExportacion INT

/* *************************************************************************************************
Procedimiento usp_Report_Nominas_IMSS_ExportarIDSE

Parámetros: 
    @FechaDesde                  (entrada, string) Fecha inicial de busqueda
    @FechaHasta                  (entrada, string) Fecha final de busqueda
    @IdTipoPeriodo               (entrada, entero) Identificador del tipo de periodo
    @IdEmpleadoDesde             (entrada, entero) Identificador de empleado inicial de busqueda
    @IdEmpleadoHasta             (entrada, entero) Identificador de empleado final de busqueda
    @IdDepartamentoDesde         (entrada, entero) Identificador de departamento inicial de busqueda
    @IdDepartamentoHasta         (entrada, entero) Identificador de departamento final de busqueda
    @NumeroGuia                  (entrada, entero) Numero de referencia de 5 digitos
    @TipoExportacion             (entrada, entero) Bandera para saber que tipo de query ejecutar
 

Descripción: El procedimeinto regresa la coleccion de empleados con el filtro seleccionado segun el tipo de 
			 exportación (Modificacion de salario, Bajas y Reingresos)
09/08/2019   Se agrego a las consultas el retorno con la division de Apellidos Paternos, Maternos y Nombre(s)	 

Implementada por: Jesus Humberto Morales M.
Fecha de implementacion: 02/04/2019
Versión ERP: 8.0.41.26

Modificada por: Jesus Humberto Morales M.
Fecha de mofidicacion: 09/08/2019
Versión ERP: 8.0.45.XX

Invocada desde: PAGE_Report_Nominas_Exportar_a_IDSE (Solicitud 67)
***************************************************************************************************** */
AS

IF @TipoExportacion = 1 --Modificacion
	BEGIN
		SELECT
		DISTINCT(CEH.CreadoEl),
		'Mod. SBC' AS 'TipoMvto',
		CE.Codigo,
		(select RegistroPatronal from SisParametros) AS 'RegistroPatronal',
		REPLACE(REPLACE(REPLACE(REPLACE(CE.NSS, ' ',''),'-',''),'.',''),'/','') AS 'NSS',
		CE.Nombres,
		CE.ApellidoPaterno,
		CE.ApellidoMaterno,
		CEH.FechaEstatus AS 'FechaMvto',
		'07' AS 'TipoMvtoNo',
		@NumeroGuia AS 'NoGuia',
		'9' AS 'IdFormato',
		CE.CURP,
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN CEH.Sueldo
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN CEH.Sueldo 
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN 
					CASE WHEN (SELECT COUNT(*) FROM CatEmpleadosHistorial WHERE IdEmpleado = CE.IdEmpleado AND CreadoEl = CEH.CreadoEl AND (IdentificadorDeHistoria = 6 OR IdentificadorDeHistoria = 7)) > 1 
							THEN (SELECT SUM(Sueldo) FROM CatEmpleadosHistorial WHERE IdEmpleado = CE.IdEmpleado AND CreadoEl = CEH.CreadoEl AND (IdentificadorDeHistoria = 6 OR IdentificadorDeHistoria = 7))
						WHEN (SELECT COUNT(*) FROM CatEmpleadosHistorial WHERE IdEmpleado = CE.IdEmpleado AND CreadoEl = CEH.CreadoEl AND (IdentificadorDeHistoria = 6 OR IdentificadorDeHistoria = 7)) = 1
							THEN
								CASE WHEN (SELECT TOP 1 IdentificadorDeHistoria FROM CatEmpleadosHistorial WHERE IdEmpleado = CE.IdEmpleado AND CreadoEl = CEH.CreadoEl AND (IdentificadorDeHistoria = 6 OR IdentificadorDeHistoria = 7)) = 6
									THEN (SELECT SalarioBaseCotizacionVariable FROM CatEmpleados WHERE IdEmpleado = CE.IdEmpleado) + (SELECT Sueldo FROM CatEmpleadosHistorial WHERE IdEmpleado = CE.IdEmpleado AND CreadoEl = CEH.CreadoEl AND IdentificadorDeHistoria = 6)
								WHEN (SELECT TOP 1 IdentificadorDeHistoria FROM CatEmpleadosHistorial WHERE IdEmpleado = CE.IdEmpleado AND CreadoEl = CEH.CreadoEl AND (IdentificadorDeHistoria = 6 OR IdentificadorDeHistoria = 7)) = 7
									THEN (SELECT SalarioBaseCotizacion FROM CatEmpleados WHERE IdEmpleado = CE.IdEmpleado) + (SELECT Sueldo FROM CatEmpleadosHistorial WHERE IdEmpleado = CE.IdEmpleado AND CreadoEl = CEH.CreadoEl AND IdentificadorDeHistoria = 7)
								END
					END
		END AS 'SBC',
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN 'FIJO'
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN 'VARIABLE'
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN 'MIXTO'
		END AS 'TipoSalario',
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN 0
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN 1
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN 2
		END AS 'TipoSalarioNo',
		CE.TipoContrato AS 'TipoTrato',
		CASE 
			WHEN CE.TipoContrato = 'CONTRATO DE TRABAJO POR TIEMPO INDETERMINADO' THEN 1
			WHEN CE.TipoContrato = 'CONTRATO DE TRABAJO PARA OBRA DETERMINADA' THEN 3
			WHEN CE.TipoContrato = 'CONTRATO DE TRABAJO POR TEMPORADA' THEN 4
			ELSE 2
		END AS 'TipoTratoNo',
		'NORMAL' AS 'TipoJornada',
		CE.UMF
		FROM CatEmpleados AS CE
		INNER JOIN CatDepartamentos AS CD ON CE.IdDepartamento = CD.IdDepartamento
		INNER JOIN CatEmpleadosHistorial AS CEH ON CEH.IdEmpleado = CE.IdEmpleado
		WHERE CD.Codigo BETWEEN @IdDepartamentoDesde AND @IdDepartamentoHasta
		AND CE.Codigo BETWEEN @IdEmpleadoDesde AND @IdEmpleadoHasta
		AND CEH.CreadoEl BETWEEN CONVERT(DATE, @FechaDesde) AND CONVERT(DATE, @FechaHasta)
		AND (CEH.IdentificadorDeHistoria = 6 OR CEH.IdentificadorDeHistoria = 7)
		AND (CE.EstadoEmpleado = 3 OR CE.EstadoEmpleado = 1)
		AND CE.IdTipoPeriodo = @IdTipoPeriodo
		ORDER BY CE.ApellidoPaterno, CEH.CreadoEl
	END
ELSE IF @TipoExportacion = 2 --Bajas
	BEGIN
		SELECT 
		'Baja' As 'TipoMvto', 
		CE.Codigo,
		(select RegistroPatronal from SisParametros) AS 'RegistroPatronal', 
		REPLACE(REPLACE(REPLACE(REPLACE(CE.NSS, ' ',''),'-',''),'.',''),'/','') AS 'NSS',
		CE.Nombres,
		CE.ApellidoPaterno,
		CE.ApellidoMaterno,
		CE.FechaBaja AS 'FechaMvto',
		'02' AS 'TipoMvtoNo',
		@NumeroGuia AS 'NoGuia',
		'9' AS 'IdFormato',
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN CE.SalarioBaseCotizacion 
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN CE.SalarioBaseCotizacionVariable 
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN (CE.SalarioBaseCotizacion + CE.SalarioBaseCotizacionVariable) 
		END AS 'SBC',
		CE.TipoContrato AS 'TipoTrato',
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN 'FIJO'
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN 'VARIABLE'
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN 'MIXTO'
		END AS 'TipoSalario',
		'NORMAL' AS 'TipoJornada',
		CASE 
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%TÉRMINO DE CONTRATO%' THEN 1
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%SEPARACIÓN VOLUNTARIA%' THEN 2
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%ABANDONO DE EMPLEO%' THEN 3
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%DEFUNCIÓN%' THEN 4
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%CLAUSURA%' THEN 5
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%OTRA%' THEN 6
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%AUSENTISMO%' THEN 7
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%RESCISIÓN DE CONTRATO%' THEN 8
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%JUBILACIÓN%' THEN 9
			WHEN UPPER(CONVERT(VARCHAR(MAX), CE.MotivoDeBaja)) LIKE '%PENSIÓN%' THEN 'A'
			ELSE 6
		END AS 'CausaBaja'
		FROM CatEmpleados AS CE
		INNER JOIN CatDepartamentos AS CD ON CE.IdDepartamento = CD.IdDepartamento
		WHERE CD.Codigo BETWEEN @IdDepartamentoDesde AND @IdDepartamentoHasta
		AND CE.Codigo BETWEEN @IdEmpleadoDesde AND @IdEmpleadoHasta
		AND CE.FechaBaja BETWEEN CONVERT(DATE, @FechaDesde) AND CONVERT(DATE, @FechaHasta)
		AND CE.EstadoEmpleado = 2
		AND CE.IdTipoPeriodo = @IdTipoPeriodo
		ORDER BY CE.ApellidoPaterno
	END
ELSE IF @TipoExportacion = 3 --Reingresos
	BEGIN
		SELECT
		'Reingreso' AS 'TipoMvto',
		CE.Codigo,
		(select RegistroPatronal from SisParametros) AS 'RegistroPatronal',
		REPLACE(REPLACE(REPLACE(REPLACE(CE.NSS, ' ',''),'-',''),'.',''),'/','') AS 'NSS',
		CE.Nombres,
		CE.ApellidoPaterno,
		CE.ApellidoMaterno,
		CE.FechaAlta AS 'FechaMvto',
		'08' AS 'TipoMvtoNo',
		@NumeroGuia AS 'NoGuia',
		'9' AS 'IdFormato',
		CE.CURP,
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN CE.SalarioBaseCotizacion 
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN CE.SalarioBaseCotizacionVariable 
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN (CE.SalarioBaseCotizacion + CE.SalarioBaseCotizacionVariable) 
		END AS 'SBC',
		CE.TipoContrato AS 'TipoTrato',
		CASE 
			WHEN CE.TipoContrato = 'CONTRATO DE TRABAJO POR TIEMPO INDETERMINADO' THEN 1
			WHEN CE.TipoContrato = 'CONTRATO DE TRABAJO PARA OBRA DETERMINADA' THEN 3
			WHEN CE.TipoContrato = 'CONTRATO DE TRABAJO POR TEMPORADA' THEN 4
			ELSE 2
		END AS 'TipoTratoNo',
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN 'FIJO'
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN 'VARIABLE'
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN 'MIXTO'
		END AS 'TipoSalario',
		CASE WHEN CE.BaseCotizacionIMSS = 1 
				THEN 0
			WHEN CE.BaseCotizacionIMSS = 2 
				THEN 1
			WHEN CE.BaseCotizacionIMSS = 3 
				THEN 2
		END AS 'TipoSalarioNo',
		'NORMAL' AS 'TipoJornada',
		CE.UMF
		FROM CatEmpleados AS CE
		INNER JOIN CatDepartamentos AS CD ON CE.IdDepartamento = CD.IdDepartamento
		WHERE CD.Codigo BETWEEN @IdDepartamentoDesde AND @IdDepartamentoHasta
		AND CE.Codigo BETWEEN @IdEmpleadoDesde AND @IdEmpleadoHasta
		AND CE.FechaAlta BETWEEN CONVERT(DATE, @FechaDesde) AND CONVERT(DATE, @FechaHasta)
		AND CE.EstadoEmpleado = 3
		AND CE.IdTipoPeriodo = @IdTipoPeriodo
		ORDER BY CE.ApellidoPaterno
	END
go

