CREATE PROCEDURE [dbo].[usp_CatFormatosModificar]
	@IdFormato int,
	@FormatoWDE ntext,
	@NombreArchivo varchar(256),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@Activo bit,
	@Formato varchar(50),
	@dsCatFormatosImagenes ntext
AS
DECLARE	
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION
						
	IF (SELECT ModificadoEl FROM CatFormatos WHERE IdFormato = @IdFormato) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@NombreArchivo)) = ''
		RAISERROR(N'El Archivo es un campo requerido',
			16,
			1
			)			

	UPDATE CatFormatos SET
	FormatoWDE = @FormatoWDE,
	NombreArchivo = @NombreArchivo,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	Activo = @Activo,
	Formato = @Formato
	WHERE IdFormato = @IdFormato
	
	
	IF @dsCatFormatosImagenes  IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatFormatosImagenes 
		
		SELECT ATT_Imagen,ATT_ImagenNombreArchivo,ATT_IdFormatoImagen
		INTO #TempCatFormatosImagenes
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatFormatosImagenes',2) 
		WITH (ATT_Imagen ntext,ATT_ImagenNombreArchivo varchar(150),ATT_IdFormatoImagen int)
		
		EXEC sp_xml_removedocument @docHandle
		
		DELETE FROM CatFormatosImagenes WHERE IdFormato = @IdFormato AND IdFormatoImagen NOT IN(SELECT ATT_IdFormatoImagen FROM #TempCatFormatosImagenes WHERE ATT_IdFormatoImagen <> 0)
				
		INSERT INTO CatFormatosImagenes(IdFormato,Imagen,ImagenNombreArchivo)
		SELECT @IdFormato,ATT_Imagen,ATT_ImagenNombreArchivo
		FROM #TempCatFormatosImagenes
		WHERE ATT_IdFormatoImagen = 0		
	END
	ELSE
	BEGIN
		DELETE FROM CatFormatosImagenes WHERE IdFormato = @IdFormato
	END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

