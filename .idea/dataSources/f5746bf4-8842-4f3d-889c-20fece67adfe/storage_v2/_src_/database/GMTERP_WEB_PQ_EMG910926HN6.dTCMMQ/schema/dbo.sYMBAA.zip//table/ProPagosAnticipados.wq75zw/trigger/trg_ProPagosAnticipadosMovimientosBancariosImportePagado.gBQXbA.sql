CREATE TRIGGER [dbo].[trg_ProPagosAnticipadosMovimientosBancariosImportePagado]
	ON [dbo].[ProPagosAnticipados]
	AFTER INSERT,DELETE
AS
BEGIN
---Insertar en ProPagosPasivos
---y actualizar importe pagado (ProMovimientosBancarios)
	UPDATE ProMovimientosBancarios 
		SET ImportePagado  = 
		   ISNULL((
			SELECT Sum(Importe) 
			FROM ProPagosAnticipados
			WHERE ProPagosAnticipados.IdMovimientoBancario = I.IdMovimientoBancario
			),0)
		FROM ProMovimientosBancarios PMB
		JOIN Inserted I ON PMB.IdMovimientoBancario= I.IdMovimientoBancario
---Eliminar en ProPagosPasivos 
---y actualizar importe pagado (ProMovimientosBancarios)
	UPDATE ProMovimientosBancarios  
		SET ImportePagado  = 
		   ISNULL((
			SELECT Sum(Importe) 
			FROM ProPagosAnticipados
			WHERE ProPagosAnticipados.IdMovimientoBancario = D.IdMovimientoBancario
			),0)
		FROM ProMovimientosBancarios PMB
		JOIN Deleted D ON PMB.IdMovimientoBancario= D.IdMovimientoBancario
END
go

