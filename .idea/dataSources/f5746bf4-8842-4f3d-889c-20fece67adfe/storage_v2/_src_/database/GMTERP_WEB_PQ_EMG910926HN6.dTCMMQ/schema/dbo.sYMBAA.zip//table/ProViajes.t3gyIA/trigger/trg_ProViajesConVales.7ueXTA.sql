CREATE TRIGGER [dbo].[trg_ProViajesConVales]
	ON [dbo].[ProViajes]
	AFTER UPDATE
AS
BEGIN
		--------------------IdUnidadCarga1---------------------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadCarga1,0) <> D.IdUnidadCarga1)  
		AND EXISTS(Select pvc.IdValeCombustible from ProValesCombustible as pvc
					Inner Join ProViajesTrayectos as pvt On pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pvc.IdUnidad = D.IdUnidadCarga1 AND pvc.CanceladoEl IS NULL))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene vales de combustible registrados en el remolque',
			16,
			1
			)
		----------------------------IdUnidadDolly--------------------------	
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadDolly,0) <> D.IdUnidadDolly)  
		AND EXISTS(Select pvc.IdValeCombustible from ProValesCombustible as pvc
					Inner Join ProViajesTrayectos as pvt On pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pvc.IdUnidad = D.IdUnidadDolly AND pvc.CanceladoEl IS NULL))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene vales de combustible registrados en el dolly',
			16,
			1
			)			
		---------------------------IdUnidadCarga2--------------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadCarga2,0) <> D.IdUnidadCarga2)  
		AND EXISTS(Select pvc.IdValeCombustible from ProValesCombustible as pvc
					Inner Join ProViajesTrayectos as pvt On pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pvc.IdUnidad = D.IdUnidadCarga2 AND pvc.CanceladoEl IS NULL))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene vales de combustible registrados en el remolque',
			16,
			1
			)
		---------------------------IdUnidadContenedor1----------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadContenedor1,0) <> D.IdUnidadContenedor1)  
		AND EXISTS(Select pvc.IdValeCombustible from ProValesCombustible as pvc
					Inner Join ProViajesTrayectos as pvt On pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pvc.IdUnidad = D.IdUnidadContenedor1 AND pvc.CanceladoEl IS NULL))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene vales de combustible registrados en el contenedor',
			16,
			1
			)			
		---------------------------IdUnidadContenedor2-----------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadContenedor2,0) <> D.IdUnidadContenedor2)  
		AND EXISTS(Select pvc.IdValeCombustible from ProValesCombustible as pvc
					Inner Join ProViajesTrayectos as pvt On pvc.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pvc.IdUnidad = D.IdUnidadContenedor2 AND pvc.CanceladoEl IS NULL))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene vales de combustible registrados en el contenedor',
			16,
			1
			)			
			
							
END
go

