CREATE PROCEDURE [dbo].[usp_ProRecoleccionGetListadoFiltroPQ]
	@IdSucursal INT,
	@IdEstatus INT,
	@FechaInicial DATE,
	@FechaFinal DATE,
	@FolioRecoleccion VARCHAR(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT 	
				IdRecoleccion,
	FolioRecoleccion,
	Fecha,
	Hora,
	FechaDetalleRecoleccion,
	HoraDetalleRecoleccion,
	IdSucursal,
	IdZonaDetalleRecoleccion,
	RecogerEnDetalleRecoleccion,
	IdOperador,
	IdUnidad
	,(select Sucursal from CatSucursales su where su.IdSucursal = pr.IdSucursal) as Sucursal
	,(select Descripcion from CatZonasPQ cz where cz.IdZona = pr.IdZonaDetalleRecoleccion) as Zona
	,(select Nombre from CatOperadores op where op.IdOperador = pr.IdOperador) as Operador
	,(select Descripcion from CatUnidades un where un.IdUnidad = pr.IdUnidad) as UnidadDescripcion
	,(select TipoUnidad from CatTiposUnidades tu where tu.IdTipoUnidad = pr.IdRemolque) as TipoUnidad
	,(select Estatus from CatEstatusRecoleccionPQ er where er.IdEstatusRecoleccion = pr.IdEstatusRecoleccion) as EstatusRecoleccion
	,IdRemolque
	,pr.IdEstatusRecoleccion
	,IdCliente
	,(select cc.NombreFiscal from CatClientes cc where cc.IdCliente =pr.IdCliente ) as NombreCliente
	,(select cc.Ciudad from CatCiudades cc where cc.IdCiudad = pr.IdCiudadOrigen) AS CiudadOrigen
	,(select cc.Ciudad from CatCiudades cc where cc.IdCiudad = pr.IdCiudadDestino) AS CiudadDestino
	,(select Color from CatEstatusRecoleccionPQ er where er.IdEstatusRecoleccion = pr.IdEstatusRecoleccion) as ColorEstatusRecoleccion
	,pr.RecoleccionConCita
	,pr.FechaCita
	,pr.HoraCitaMaxima
	,pr.HoraCitaMinima
	FROM ProRecoleccionPQ pr
		WHERE (IdSucursal = @IdSucursal OR @IdSucursal IS NULL)
		AND (IdEstatusRecoleccion = @IdEstatus OR @IdEstatus IS NULL)
		AND (Fecha >= @FechaInicial OR @FechaInicial IS NULL)
		AND (Fecha <= @FechaFinal OR @FechaFinal IS NULL)
		AND (FolioRecoleccion LIKE '%'+@FolioRecoleccion+'%' OR @FolioRecoleccion IS NULL)
		ORDER BY Fecha DESC, Hora DESC
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

