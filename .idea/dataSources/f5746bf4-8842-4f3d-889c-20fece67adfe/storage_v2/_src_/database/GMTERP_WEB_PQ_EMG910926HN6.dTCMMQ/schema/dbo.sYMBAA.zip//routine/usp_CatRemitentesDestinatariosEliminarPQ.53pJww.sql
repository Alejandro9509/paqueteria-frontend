
CREATE PROCEDURE [dbo].[usp_CatRemitentesDestinatariosEliminarPQ]
	@IdRemitenteDestinatario INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdRemitenteDestinatario,0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador del Remitente/Destinatario es un campo requerido*FIN*', 16, 1)
			return
		end
		DELETE FROM CatRemitentesDestinatarios
		WHERE IdRemitenteDestinatario = @IdRemitenteDestinatario
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

