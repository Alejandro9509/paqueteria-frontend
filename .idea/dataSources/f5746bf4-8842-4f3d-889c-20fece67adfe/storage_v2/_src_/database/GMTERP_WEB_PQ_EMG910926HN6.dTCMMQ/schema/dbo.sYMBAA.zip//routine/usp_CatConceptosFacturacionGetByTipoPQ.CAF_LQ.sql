CREATE PROCEDURE [dbo].[usp_CatConceptosFacturacionGetByTipoPQ](
    @IdTipo int
)
AS
BEGIN
    BEGIN TRANSACTION
        SELECT
            IdTipoConceptoFacturacion,
            (Select Descripcion from CatTiposConceptosFacturacionPQ where IdTipoConceptoFacturacion = cfp.IdTipoConceptoFacturacion) as TipoConcepto,
            IdConceptoFacturacion as m_nIdConceptosFacturacion
             ,Codigo as m_sCodigo
             ,ConceptoFacturacion as m_sConcepto
             ,Activo as m_bActivo
             ,IncluirCalculoIngresosLiquidacion as m_bCalculoIngreso
             ,IncluirCalculoLiquidacionPorcentajeSobreImpFlete as m_bCalculoFlete
             ,(select IdCatUnidadMedidaSAT from CatUnidadMedidaSATPQ cs where cs.ClaveUnidad = ClaveSATUnidad COLLATE Modern_Spanish_CS_AS) as m_nIdUnidadMedidaSAT
             ,ClaveSATProducto as m_nIdProdServSAT
             ,UnidadMedida as m_sUnidadMedida
             ,CreadoEl as m_dtCreadoEl
             ,ModificadoEl as m_dtModificadoEl
             ,ModificadoPor as m_nModificadoPor
             ,CreadoPor as m_nCreadoPor
        FROM CatConceptosFacturacionPaqueteriaPQ cfp
                 join CatConceptosFacturacion cf on cfp.IdConceptosFacturacion = cf.IdConceptoFacturacion
        WHERE IdTipoConceptoFacturacion in (@IdTipo)

        IF @@TRANCOUNT > 0
            BEGIN
                COMMIT TRANSACTION
            END
        ELSE
            BEGIN
                GOTO CANCELAR_TRANSACCION


                CANCELAR_TRANSACCION:
                IF @@TRANCOUNT > 0
                    BEGIN
                        EXECUTE usp_GetErrorInfoPQ;
                        ROLLBACK TRANSACTION
                        RETURN -1
                    END
            END
end
go

