CREATE TRIGGER [dbo].[trg_ProViajesConSalida]
	ON [dbo].[ProViajes]
	AFTER UPDATE
AS
BEGIN
	DECLARE @ModificarRemolque bit,@Derecho int
	SET @ModificarRemolque = ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'PermitirAgregarRemolqueViajeTerminado'),0)
	IF (SELECT TipoUsuario from CatUsuarios where IdUsuario = (SELECT ModificadoPor FROM inserted)) = 1
	BEGIN 
		SET @Derecho = 1
	END
	ELSE
	BEGIN
		SET @Derecho = ISNULL((SELECT Derecho FROM CatUsuariosDerechos WHERE IdUsuario =(SELECT ModificadoPor FROM inserted)  AND IdProceso = 502103),0)
	END


	IF @ModificarRemolque = 0
	BEGIN
		IF EXISTS(SELECT IdViaje FROM ProViajesTrayectos WHERE Salida IS NOT NULL AND IdViaje = (SELECT IdViaje FROM deleted) AND @Derecho <> 1)
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON 
			D.IdCliente <> I.IdCliente OR 
			D.IdRuta <> I.IdRuta OR
			D.IdUnidadCarga1 <> I.IdUnidadCarga1 OR 
			D.IdUnidadCarga2 <> I.IdUnidadCarga2 OR 
			D.IdUnidadContenedor1 <> I.IdUnidadContenedor1 OR 
			D.IdUnidadContenedor2 <> I.IdUnidadContenedor2 OR 
			D.IdUnidadDolly <> I.IdUnidadDolly OR
			D.CodigoUnidadCarga1 <> I.CodigoUnidadCarga1 OR 
			D.CodigoUnidadCarga2 <> I.CodigoUnidadCarga2 OR 
			D.CodigoUnidadContenedor1 <> I.CodigoUnidadContenedor1 OR 
			D.CodigoUnidadContenedor2 <> I.CodigoUnidadContenedor2 OR
			D.CodigoUnidadDolly <> I.CodigoUnidadDolly)
			RAISERROR(N'No puede modificarse el viaje porque ya tiene registrada la salida',
				16,
				1
				)        
		END
	END
	ELSE
	BEGIN
		IF EXISTS(SELECT IdViaje FROM ProViajesTrayectos WHERE Salida IS NOT NULL AND IdViaje = (SELECT IdViaje FROM deleted)AND @Derecho <> 1)
		BEGIN
			IF EXISTS(SELECT * FROM INSERTED I
			JOIN DELETED D ON 
			D.IdCliente <> I.IdCliente OR 
			D.IdRuta <> I.IdRuta OR
			((D.IdUnidadCarga1 <> I.IdUnidadCarga1) AND ISNULL(D.IdUnidadCarga1,0) <> 0)  OR 
			((D.IdUnidadCarga2 <> I.IdUnidadCarga2) AND ISNULL(D.IdUnidadCarga2,0) <> 0)  OR 
			D.IdUnidadContenedor1 <> I.IdUnidadContenedor1 OR 
			D.IdUnidadContenedor2 <> I.IdUnidadContenedor2 OR 
			((D.IdUnidadDolly <> I.IdUnidadDolly) AND ISNULL(D.IdUnidadDolly,0)<> 0) OR
			((D.CodigoUnidadCarga1 <> I.CodigoUnidadCarga1) AND D.CodigoUnidadCarga1 <> '') OR 
			((D.CodigoUnidadCarga2 <> I.CodigoUnidadCarga2) AND D.CodigoUnidadCarga2 <> '') OR
			D.CodigoUnidadContenedor1 <> I.CodigoUnidadContenedor1 OR 
			D.CodigoUnidadContenedor2 <> I.CodigoUnidadContenedor2 OR
			((D.CodigoUnidadDolly <> I.CodigoUnidadDolly) AND D.CodigoUnidadDolly <> ''))
			RAISERROR(N'No puede modificarse el viaje porque ya tiene registrada la salida',
				16,
				1
				)        
		END
	END
END
go

