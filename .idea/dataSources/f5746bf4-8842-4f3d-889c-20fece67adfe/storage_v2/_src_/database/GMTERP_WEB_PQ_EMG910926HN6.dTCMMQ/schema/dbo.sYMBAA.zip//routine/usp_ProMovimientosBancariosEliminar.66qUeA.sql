CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosEliminar]
    @IdMovimientoBancario int,
	@IdPeticion varchar(100)	
AS
DECLARE
 @IdCheque int,
 @Conciliado bit ,
 -- SOLICITUD 010828
 @IdMovimientoBancarioAnterior int
/*
MODIFICADO:
	Se agregaro un exec usp_ProPolizasActualizarSaldos
	para acutalizar los asientos contables del catalogo CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-30
SOLICITUD: 
	SOLICITUD 000266
*/
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdMovimientoBancario,0)= 0
		RAISERROR(N'Identificador de movimiento bancario es un campo requerido',
			16,
			1
			)
	---- valida que el movimiento no exista en cobranza
	--IF EXISTS(SELECT IdMovimientoBancario FROM ProCobranza WHERE IdMovimientoBancario = @IdMovimientoBancario)
	--  BEGIN
	--	RAISERROR(N'No puede eliminar este movimiento los datos pertenecen a cobranza',
	--		16,
	--		1
	--		)
	--  END
	-- valida que el movimiento no exista en liquidaciones
	IF EXISTS(SELECT IdMovimientoBancario FROM ProLiquidaciones WHERE IdMovimientoBancario = @IdMovimientoBancario)
	  BEGIN
		RAISERROR(N'No puede eliminar este movimiento los datos pertenecen a liquidación',
			16,
			1
			)
	  END
	  
	
	IF EXISTS(SELECT IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdMovimientoBancario = @IdMovimientoBancario And CanceladoEl is null)
	  BEGIN
		RAISERROR(N'No puede eliminar este movimiento porque aun no esta Cancelado',
			16,
			1
			)
	  END

	-- valida que el movimiento no exista en liquidaciones
	IF EXISTS(SELECT IdMovimientoBancario FROM ProLiquidacionesFiscales WHERE IdMovimientoBancario = @IdMovimientoBancario)
	  BEGIN
		RAISERROR(N'No puede eliminar este movimiento los datos pertenecen a liquidación fiscal',
			16,
			1
			)
	  END	  
	-- valida que el movimiento no exista en cheques rapidos
	SET @IdCheque = (SELECT IdCheque FROM ProMovimientosBancarios WHERE IdMovimientoBancario = @IdMovimientoBancario)
	IF ISNULL(@IdCheque,0)> 0
	  BEGIN
		RAISERROR(N'No puede eliminar este movimiento los datos pertenecen a un cheque',
			16,
			1
			)
	  END
	  
	  IF EXISTS(SELECT IdMovimientoBancario FROM ProLiquidaciones WHERE IdMovimientoBancario = @IdMovimientoBancario)
	  BEGIN
		RAISERROR(N'No puede eliminar este movimiento, los datos pertenecen a liquidación',
			16,
			1
			)
	  END

	  IF EXISTS(SELECT IdMovimientoBancario FROM ProLiquidacionesFiscales WHERE IdMovimientoBancario = @IdMovimientoBancario)
	  BEGIN
		RAISERROR(N'No puede eliminar este movimiento, los datos pertenecen a liquidación fiscal',
			16,
			1
			)
	  END	  
	 SET @Conciliado = (SELECT Conciliado FROM ProMovimientosBancarios WHERE  IdMovimientoBancario = @IdMovimientoBancario) 
	 IF ISNULL(@Conciliado,0) = 1
	  BEGIN
		RAISERROR(N'El movimiento ya está conciliado no puede eliminar',
			16,
			1
			)
	  END
	  
	--Libera la cobranza de la tabla puente de contrarecibos si es que existe SOLICITUD 010143
	UPDATE ProContraRecibosClienteFacturas SET IdCobranza = NULL WHERE IdCobranza in (Select IdCobranza From ProCobranza Where IdMovimientoBancario = @IdMovimientoBancario)
	-- Elimina los Movimientos de Saldo a Favor usados
	DELETE from ProCobranza Where IdCobranzaSaldoAFavor in (Select IdCobranza From ProCobranza Where IdMovimientoBancario = @IdMovimientoBancario)	
	-- Elimina los Registros de Cobranza Ligados a Ese movimiento Bancario
	DELETE from ProCobranza Where IdMovimientoBancario = @IdMovimientoBancario

	-- ELIMINA LA RELACION CON EL MOVIMIENTO BANCARIO ANTERIOR YA QUE CAUSA CONFLICTOS EN PAGOS/ABONOS AL SUSTITUIR Y EL PAGO/ABONO NO ESTA TIMBRADO.
	-- REVISAR SOLICITUD 010828 DOCUMENTO REVISION03 PARA VER EL FLUJO.
	IF EXISTS(SELECT IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdMovimientoBancarioAnterior = @IdMovimientoBancario)
	BEGIN
		SET @IdMovimientoBancarioAnterior = (SELECT IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdMovimientoBancarioAnterior = @IdMovimientoBancario)
		UPDATE
		ProMovimientosBancarios
		SET
		IdMovimientoBancarioAnterior = null
		WHERE
		IdMovimientoBancario = @IdMovimientoBancarioAnterior
	END
	--- Eliminar Movimiento Bancario	
	DELETE FROM ProMovimientosBancarios 
	WHERE IdMovimientoBancario =  @IdMovimientoBancario
	
    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
   -- IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
   --  BEGIN
	/*Antes de que se elimine la poliza, se van a quitar los asientos contables de CatCuentasContablesSaldos*/
	DECLARE @CondicionQuery nvarchar(max) = ''
	SET @CondicionQuery = ' pp.ProcesoLigado = ''ProReposiciones'' AND pp.IdProcesoLigadoAux IN ( '+CAST(@IdMovimientoBancario AS varchar)+') ' 
	EXEC usp_ProPolizasActualizarSaldos @IdPeticion,0,@CondicionQuery

	DELETE FROM ProPolizas WHERE ProcesoLigado = 'ProReposiciones' AND IdProcesoLigadoAux = @IdMovimientoBancario

   /*Antes de que se elimine la poliza, se van a quitar los asientos contables de CatCuentasContablesSaldos*/
	SET @CondicionQuery = ' pp.ProcesoLigado = ''ProMovimientosBancarios'' AND pp.IdProcesoLigado IN ( '+CAST(@IdMovimientoBancario AS varchar)+') ' 
	EXEC usp_ProPolizasActualizarSaldos @IdPeticion,0,@CondicionQuery
   
    DELETE FROM ProPolizas 
    WHERE ProcesoLigado = 'ProMovimientosBancarios' AND IdProcesoLigado = @IdMovimientoBancario
   --  END		

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

