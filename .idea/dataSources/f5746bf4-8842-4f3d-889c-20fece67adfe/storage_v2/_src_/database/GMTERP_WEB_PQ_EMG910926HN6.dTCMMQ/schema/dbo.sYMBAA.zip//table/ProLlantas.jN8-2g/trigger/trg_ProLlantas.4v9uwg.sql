create TRIGGER [dbo].[trg_ProLlantas]
   ON  [dbo].[ProLlantas]
   AFTER UPDATE
AS 
BEGIN	
		-- valida que no modifique los campos 
		IF EXISTS(SELECT * FROM INSERTED I
				INNER JOIN DELETED D ON I.IdLlanta = D.IdLlanta
				WHERE  (D.VidaUtil <> I.VidaUtil)) 
 					BEGIN
 					IF EXISTS(SELECT  TOP 1 IdLlanta FROM  ProLlantasAuxiliar WHERE   (IdLlanta = (SELECT top 1 IdLlanta FROM DELETED ) ))   
									RAISERROR(N'Vida útil no se puede modificar porque ya tiene datos ligados en auxiliar de llantas ',
											 16,
											 1
											 )

 					END	
	
END
go

