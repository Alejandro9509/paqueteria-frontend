
CREATE PROCEDURE [dbo].[usp_ProViajesGetListadoFiltroPQ]
	@IdSucursal INT,
	@IdEstatus INT,
	@FechaInicial DATE,
	@FechaFinal DATE
AS
BEGIN TRY
	BEGIN TRANSACTION
			SELECT
		v.IdViaje
      ,v.IdSucursal
	  ,s.Sucursal
      ,v.FolioViaje
      ,v.NumViajeCliente
      ,v.Fecha
      ,v.Hora
      ,v.IdEstatusViaje
	  ,ev.Estatus
	  ,ev.Estatus AS Descripcion
	  ,ev.Abreviacion
      ,v.CandadoOficial
      ,v.Identificador
	  ,v.FechaRegistro
	  ,v.HoraRegistro
     
		FROM ProViajesPQ v inner join CatSucursales s on v.IdSucursal = s.IdSucursal inner join CatEstatusViajePQ ev on v.IdEstatusViaje= ev.IdEstatusViaje
		WHERE (v.IdSucursal = @IdSucursal OR @IdSucursal IS NULL)
		AND (v.IdEstatusViaje = @IdEstatus OR @IdEstatus IS NULL)
		AND (Fecha >= @FechaInicial OR @FechaInicial IS NULL)
		AND (Fecha <= @FechaFinal OR @FechaFinal IS NULL)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

