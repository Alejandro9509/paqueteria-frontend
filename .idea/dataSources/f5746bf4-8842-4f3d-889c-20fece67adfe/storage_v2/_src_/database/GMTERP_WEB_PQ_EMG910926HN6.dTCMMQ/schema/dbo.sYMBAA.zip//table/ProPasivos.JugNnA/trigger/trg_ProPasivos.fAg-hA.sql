CREATE TRIGGER [dbo].[trg_ProPasivos]
   ON  dbo.ProPasivos
   AFTER UPDATE
AS 
BEGIN
	IF EXISTS(SELECT * FROM ProPolizas WHERE ProcesoLigado = 'ProPasivos' AND IdProcesoLigado IN (SELECT IdPasivo FROM deleted))
        AND EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdPasivo = D.IdPasivo 
        WHERE CAST(D.Fecha As Date) <> CAST(I.Fecha As Date))
        RAISERROR(N'La fecha no se puede modificar porque tiene una póliza contable ligada',
            16,
            1
            )
END
go

