CREATE PROCEDURE [dbo].[usp_ProRequisicionAutorizar]
	@IdRequisicion int,
	@Estatus tinyint,
	@AutorizadoEl datetime,
	@AutorizadoPor int,
	@IdPeticion varchar(100),
	@FechaDeAutorizacion datetime,
	@IdProveedor int
AS
DECLARE @FolioOrdenCompra int,
		@IdOrdenCompra int 
BEGIN TRY
	BEGIN TRANSACTION

	IF Isnull(@IdRequisicion,0) = 0
		RAISERROR(N'El identificador de la requisición es un campo requerido',
			16,
			1
			)

	IF Isdate(@FechaDeAutorizacion) = 0
		RAISERROR(N'Fecha de autorización de la requisición es un campo requerido',
			16,
			1
			)

	
	IF (SELECT FechaHora FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) > @FechaDeAutorizacion
		RAISERROR(N'La fecha de autorización no puede ser menor a la fecha de elaboración',
			16,
			1
			)

	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) = 1--autorizada
		RAISERROR(N'No puede autorizar esta requisición porque está cerrada',
			16,
			1
			)

	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) = 2--cancelada
		RAISERROR(N'No puede autorizar esta requisición porque está cancelada',
			16,
			1
			)
			
	IF (SELECT AutorizadoEl FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) IS NOT NULL --cancelado
		RAISERROR(N'No puede autorizar esta requisición porque ya está autorizada',
			16,
			1
			)			
			
	IF ISNULL(@IdProveedor,0) = 0
		RAISERROR(N'El proveedor es un campo requerido',
			16,
			1
			)

	UPDATE ProRequisicion	
	SET Estatus = @Estatus,
		AutorizadoEl = @FechaDeAutorizacion,
		AutorizadoPor = @AutorizadoPor,
		ModificadoEl = @AutorizadoEl,
		ModificadoPor = @AutorizadoPor,
		IdProveedor = @IdProveedor
	WHERE IdRequisicion = @IdRequisicion
	
	---	Se guarda la OrdenCompra
	SELECT @FolioOrdenCompra = ISNULL(MAX(Folio),0)+1 FROM ProOrdenCompra

	INSERT INTO ProOrdenCompra(Descuento,Estatus,FechaHora,IdProveedor,Folio,IdMoneda,MotivoDescuento,Observaciones,SubTotal,TipoCambio,Total,IdImpuestosTrasladadosFederales,ImpuestosTrasladadosFederales,IdImpuestosRetenidosFederales,ImpuestosRetenidosFederales,IdImpuestosTrasladadosLocales,ImpuestosTrasladadosLocales,IdImpuestosRetenidosLocales,ImpuestosRetenidosLocales,IdAlmacen,CargarA,IdRequisicion,CreadoEl,CreadoPor)
	SELECT Descuento,0,@FechaDeAutorizacion,@IdProveedor,@FolioOrdenCompra,IdMoneda,MotivoDescuento,Observaciones,SubTotal,TipoCambio,Total,IdImpuestosTrasladadosFederales,ImpuestosTrasladadosFederales,IdImpuestosRetenidosFederales,ImpuestosRetenidosFederales,IdImpuestosTrasladadosLocales,ImpuestosTrasladadosLocales,IdImpuestosRetenidosLocales,ImpuestosRetenidosLocales,IdAlmacen,CargarA,IdRequisicion,@AutorizadoEl,@AutorizadoPor
	FROM ProRequisicion	WHERE IdRequisicion = @IdRequisicion
	
	SET @IdOrdenCompra = (SELECT IDENT_CURRENT('ProOrdenCompra'))		

	-- Sección donde se guarda el detalle de la orden de compra.
	
	INSERT INTO ProOrdenCompraConceptos(IdOrdenCompra,IdArticulo,Cantidad,Entregado,Pendiente,PrecioUnitario,Importe,Observaciones,UnidadMedida,CreadoPor,CreadoEl)
	SELECT @IdOrdenCompra, IdArticulo,Cantidad,Entregado,Pendiente,PrecioUnitario,Importe,Observaciones,UnidadMedida ,@AutorizadoPor,@AutorizadoEl  From ProRequisicionConceptos
	WHERE IdRequisicion = @IdRequisicion

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

