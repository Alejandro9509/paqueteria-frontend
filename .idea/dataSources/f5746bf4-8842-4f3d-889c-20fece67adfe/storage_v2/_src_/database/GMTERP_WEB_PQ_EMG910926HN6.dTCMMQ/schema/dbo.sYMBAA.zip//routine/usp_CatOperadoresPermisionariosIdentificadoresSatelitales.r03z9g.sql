
	CREATE PROCEDURE [dbo].[usp_CatOperadoresPermisionariosIdentificadoresSatelitales]
		@array varchar(max)
	AS
		if (CHARINDEX('|',@array,1) - 1) = -1
		begin
			set @array = @array+'|x&x'
		end;

		WITH rep (IdSatelitales,RFC,list) AS
		(
			SELECT SUBSTRING(@array,1,CHARINDEX('|',@array,1) - 1) as IdSatelitales,
			SUBSTRING(@array,1,CHARINDEX('&''',@array,1) - 1) as RFC,
			SUBSTRING(@array,CHARINDEX('|',@array,1) + 1, LEN(@array)) + '|' list

			UNION ALL

			SELECT SUBSTRING(list,1,CHARINDEX('|',list,1) - 1) as IdSatelitales,
			SUBSTRING(list,1,CHARINDEX('&',list,1) - 1) as RFC,
			SUBSTRING(list,CHARINDEX('|',list,1) + 1, LEN(list)) list
			FROM rep
			WHERE LEN(rep.list) > 0
		)

				SELECT
				CatOperadores.RFC,
				STUFF((SELECT ','+co.Nombre FROM CatOperadores AS co 
				WHERE co.RFC = CatOperadores.RFC 
				AND co.EsPermisionario = 1 AND co.HashGPS IS NOT NULL 
				AND CAST(co.HashGPS AS VARCHAR(MAX)) <> ''
				FOR XML PATH(''),TYPE).value('.','varchar(max)'),1,1,'') AS NombrePermisionario,
				HashGPS,
				IdSatelitales
				FROM
				CatOperadores
				INNER JOIN rep ON CatOperadores.RFC = rep.RFC
				WHERE
				EsPermisionario = 1
				AND
				HashGPS IS NOT NULL AND CAST(HashGPS AS VARCHAR(MAX)) <> ''
				GROUP BY CatOperadores.RFC,HashGPS,IdSatelitales
    go

