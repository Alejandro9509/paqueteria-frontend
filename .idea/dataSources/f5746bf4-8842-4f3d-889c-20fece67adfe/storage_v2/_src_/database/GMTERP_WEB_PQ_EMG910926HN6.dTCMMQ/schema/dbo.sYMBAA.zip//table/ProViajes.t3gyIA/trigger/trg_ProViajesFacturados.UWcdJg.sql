CREATE TRIGGER [dbo].[trg_ProViajesFacturados]
	ON [dbo].[ProViajes]
	AFTER UPDATE
AS
BEGIN
	DECLARE @PendienteFacturar bit
	DECLARE @FacturadoParcialmente bit
	SET @PendienteFacturar = (SELECT PendienteFacturar FROM ProViajes WHERE IdViaje = (SELECT IdViaje FROM deleted))
	SET @FacturadoParcialmente = (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = (SELECT IdViaje FROM deleted))
	
	IF @PendienteFacturar = 0 OR @FacturadoParcialmente = 1
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON I.IdViaje = D.IdViaje
        WHERE D.Facturable <> I.Facturable OR
		D.TipoCambio <> I.TipoCambio OR
        D.FechaHora <> I.FechaHora OR D.IdCliente <> I.IdCliente OR D.IdMoneda <> I.IdMoneda OR D.IdRuta <> I.IdRuta OR D.SubTotal <> I.SubTotal OR D.TipoCobroPorViaje <> I.TipoCobroPorViaje)
        RAISERROR(N'No puede modificarse el viaje porque está facturado',
            16,
            1
            )        
        END
END
go

