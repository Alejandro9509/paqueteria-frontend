CREATE PROCEDURE [dbo].[usp_CatProveedoresModificar]
	@IdProveedor int,
	@NumeroProveedor int,
	@RFC varchar(13),
	@NombreFiscal varchar(150),
	@NombreCorto varchar(12),
	@Calle varchar(100),
	@NoExterior varchar(20),
	@NoInterior varchar(20),
	@Colonia varchar(100),
	@Localidad varchar(100),
	@Municipio varchar(100),
	@IdEstado varchar(5),
	@CodigoPostal varchar(10),
	@Telefono varchar(20),
	@Celular varchar(20),
	@Nextel varchar(20),
	@CorreoElectronico varchar(100),
	@Activo bit,
	@Credito money,
	@CreditoDLLS money,
	@DiasCredito int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@ProveedorDeCombustible bit,
	@TipoProveedor int,
	@ProveedorDeBien bit,
    @ProveedorDeServicio bit,
    @IdGrupoProveedor int,
    @CuentaBancaria varchar(50),
    @IdBanco int,
    @ClabeInterBancaria varchar (18),
    @IdTipoDeOperacion int,
    @IdTipoDeTercero int
AS
	/* *************************************************************************************************
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 12/11/2020
	Versión 8.0.56.18
	SOLICITUD 002446

	-Se metio una validacion para la concurrencia de RFC y codigo postal

	Invocada desde: ClsProPasivos - modificar
	***************************************************************************************************** */
	/* *************************************************************************************************
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 26/01/2021
	Versión 8.0.58.08
	SOLICITUD 003792

	-se modifico para que la validacion de RFC y codigo postal solo la realice con proveedores de tipos nacionales

	Invocada desde: ClsProPasivos - Modificar

	Modificada por: Raymundo Espinoza Garcia
	Fecha de mofidicacion: 13/07/2021
	Versión 8.0.63.00
	SOLICITUD 004293

	***************************************************************************************************** */
DECLARE 
@RFCAux varchar(13),
@CodigoPostalAux varchar(10)

BEGIN TRY
	BEGIN TRANSACTION

	IF @IdProveedor = 0
		RAISERROR(N'El identificador del proveedor es un campo requerido',
			16,
			1
			)
	IF @TipoProveedor = 0
		RAISERROR(N'El tipo de proveedor es un campo requerido',
			16,
			1
			)
			
	IF NOT EXISTS(SELECT IdProveedor FROM CatProveedores WHERE IdProveedor = @IdProveedor)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)		

	IF (SELECT ModificadoEl FROM CatProveedores WHERE IdProveedor = @IdProveedor) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)		

	IF @NumeroProveedor = 0
		RAISERROR(N'El numero de cliente es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT NumeroProveedor FROM CatProveedores WHERE NumeroProveedor = @NumeroProveedor AND IdProveedor <> @IdProveedor)
		RAISERROR(N'El numero de proveedor ya existe',
			16,
			1
			)	
			
	IF LTRIM(RTRIM(@RFC)) = ''
		RAISERROR(N'El RFC es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@NombreFiscal)) = ''
		RAISERROR(N'El nombre es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@Calle)) = ''
		RAISERROR(N'La calle es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@Municipio)) = ''
		RAISERROR(N'El municipio es un campo requerido',
			16,
			1
			)		
			
	IF LTRIM(RTRIM(@IdEstado)) = ''
		RAISERROR(N'El estado es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@CodigoPostal)) = ''
		RAISERROR(N'El código postal es un campo requerido',
			16,
			1
			)

	--Sol 2446
	SELECT
	@RFCAux = RFC,
	@CodigoPostalAux = CodigoPostal
	FROM CatProveedores WHERE IdProveedor = @IdProveedor

	IF @RFCAux <> @RFC OR @CodigoPostalAux <> @CodigoPostal
	BEGIN
		IF EXISTS(SELECT TOP 1 IdProveedor FROM CatProveedores WHERE RFC = @RFC AND CodigoPostal = @CodigoPostal AND IdProveedor <> @IdProveedor AND TipoProveedor = 1)--3792 
			RAISERROR(N'El RFC y Codigo Postal a ha sido registrado anteriormente en el sistema, favor validar',
			16,
			1
			)
	END
	--

	IF @IdGrupoProveedor = 0 
	SET @IdGrupoProveedor = Null
	
	IF @IdBanco = 0
	SET @IdBanco = NULL
	
	IF @IdTipoDeOperacion = 0
	SET @IdTipoDeOperacion = NULL
	
	IF @IdTipoDeTercero = 0
	SET @IdTipoDeTercero = NULL
			
	UPDATE CatProveedores SET
	NumeroProveedor = @NumeroProveedor,
	RFC = @RFC,
	NombreFiscal = @NombreFiscal,
	NombreCorto = @NombreCorto,
	Calle = @Calle,
	NoExterior = @NoExterior,
	NoInterior = @NoInterior,
	Colonia = @Colonia,
	Localidad = @Localidad,
	Municipio = @Municipio,
	IdEstado = @IdEstado,
	CodigoPostal = @CodigoPostal,
	Telefono = @Telefono,
	Celular = @Celular,
	Nextel = @Nextel,
	CorreoElectronico = @CorreoElectronico,
	Activo = @Activo,
	Credito = @Credito,
	CreditoDLLS = @CreditoDLLS,
	DiasCredito = @DiasCredito,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	ProveedorDeCombustible=@ProveedorDeCombustible,
	TipoProveedor = @TipoProveedor,
	ProveedorDeBien = @ProveedorDeBien,
    ProveedorDeServicio =@ProveedorDeServicio,
    IdGrupoProveedor  = @IdGrupoProveedor,
    CuentaBancaria = @CuentaBancaria,
    IdBanco = @IdBanco,
    ClabeInterBancaria = @ClabeInterBancaria,
    IdTipoDeOperacion = @IdTipoDeOperacion,
    IdTipoDeTercero = @IdTipoDeTercero 
	WHERE IdProveedor = @IdProveedor

    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
        UPDATE CatCuentasContables SET
        Nombre = @NombreFiscal
        WHERE CatalogoLigado = 'CatProveedores' AND IdCatalogoLigado = @IdProveedor
    END
    	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

