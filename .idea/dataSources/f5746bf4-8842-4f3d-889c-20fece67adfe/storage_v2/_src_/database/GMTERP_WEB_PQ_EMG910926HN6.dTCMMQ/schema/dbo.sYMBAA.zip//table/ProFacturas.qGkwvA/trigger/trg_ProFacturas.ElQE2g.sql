CREATE TRIGGER [dbo].[trg_ProFacturas]
   ON  [dbo].[ProFacturas]
   AFTER UPDATE
AS 
BEGIN
    --DECLARE @IdFactura int
    
    --SET @IdFactura = (SELECT IdFactura FROM deleted)
    
	IF UPDATE(IdFolio)
		RAISERROR(N'No se puede modificar el folio de la factura',
		16,
		1
		)

	IF UPDATE(IdCliente)
		RAISERROR(N'No se puede modificar el cliente',
		16,
		1
		)
		
	IF UPDATE(IdSucursal)
		RAISERROR(N'No se puede modificar la sucursal',
		16,
		1
		)		

END
go

