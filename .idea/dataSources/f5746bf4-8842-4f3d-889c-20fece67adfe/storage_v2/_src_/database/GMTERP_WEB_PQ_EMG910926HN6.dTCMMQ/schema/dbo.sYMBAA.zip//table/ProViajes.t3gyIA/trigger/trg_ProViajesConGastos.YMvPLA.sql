CREATE TRIGGER [dbo].[trg_ProViajesConGastos]
	ON [dbo].[ProViajes]
	AFTER UPDATE
AS
BEGIN
		--------------------IdUnidadCarga1---------------------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadCarga1,0) <> D.IdUnidadCarga1)  
		AND EXISTS(Select * from ProGastosViaje as pgv
					Inner Join ProViajesTrayectos as pvt On pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pgv.IdUnidad = D.IdUnidadCarga1))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene gastos registrados en el remolque',
			16,
			1
			)
		----------------------------IdUnidadDolly--------------------------	
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadDolly,0) <> D.IdUnidadDolly)  
		AND EXISTS(Select * from ProGastosViaje as pgv
					Inner Join ProViajesTrayectos as pvt On pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pgv.IdUnidad = D.IdUnidadDolly))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene gastos registrados en el dolly',
			16,
			1
			)			
		---------------------------IdUnidadCarga2--------------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadCarga2,0) <> D.IdUnidadCarga2)  
		AND EXISTS(Select * from ProGastosViaje as pgv
					Inner Join ProViajesTrayectos as pvt On pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pgv.IdUnidad = D.IdUnidadCarga2))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene gastos registrados en el remolque',
			16,
			1
			)
		---------------------------IdUnidadContenedor1----------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadContenedor1,0) <> D.IdUnidadContenedor1)  
		AND EXISTS(Select * from ProGastosViaje as pgv
					Inner Join ProViajesTrayectos as pvt On pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pgv.IdUnidad = D.IdUnidadContenedor1))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene gastos registrados en el contenedor',
			16,
			1
			)			
		---------------------------IdUnidadContenedor2-----------------------
		IF EXISTS(SELECT * FROM INSERTED I
		INNER JOIN DELETED D ON I.IdViaje = D.IdViaje
		WHERE (ISNULL(I.IdUnidadContenedor2,0) <> D.IdUnidadContenedor2)  
		AND EXISTS(Select * from ProGastosViaje as pgv
					Inner Join ProViajesTrayectos as pvt On pgv.IdViajeTrayecto = pvt.IdViajeTrayecto
					Inner Join ProViajes AS pv on pvt.IdViaje = pv.IdViaje
					Where pv.IdViaje = I.IdViaje and pgv.IdUnidad = D.IdUnidadContenedor2))
		RAISERROR(N'No puede modificarse el viaje porque ya tiene gastos registrados en el contenedor',
			16,
			1
			)			
			
							
END
go

