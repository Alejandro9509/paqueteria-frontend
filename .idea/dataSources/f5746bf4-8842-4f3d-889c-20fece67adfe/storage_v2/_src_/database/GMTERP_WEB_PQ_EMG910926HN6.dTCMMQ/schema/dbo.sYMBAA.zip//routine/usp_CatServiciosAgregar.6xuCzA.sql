CREATE PROCEDURE [dbo].[usp_CatServiciosAgregar]
@Codigo int,
@Servicio varchar(100),
@CostoManoDeObra money,
@TiempoDeServicio decimal(15, 2),
@ProporcionaServicioPorDia int,
@ProporcionaServicioPorKilometro int,
@PreventivoCorrectivo int,
@IdClasificacionServicio int,
@IdTipoUnidad int,
@dsCatServiciosPartes ntext,
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100),
@ProporcionaServicioPorHora int,
@Activo bit

/***********************************************************************************************************************
SOLICITUD 1381

Descripcion: Se modifico ya que se agrego el campo activo a CatServicios

Modificada por:   Ignacio Perez
Fecha de mofidicacion: 24/03/2030
Versión: Versión 8.0.51.14

Invocada desde: <ClsCatServicios::Agregar>
********************************************************************************************************************* */

AS
DECLARE @IdServicio INT,@docHandle INT
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de servicio es un campo requerido',
			16,
			1
			)
			
   	IF EXISTS(SELECT Codigo FROM CatServicios WHERE Codigo = @Codigo)
		RAISERROR(N'El código de servicio ya existe',
			16,
			1
			) 
						
	IF ISNULL(@Servicio,'')= ''
		RAISERROR(N'Descripción es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdClasificacionServicio,0)= 0
		RAISERROR(N'Identificador de servicio es un campo requerido',
			16,
			1
			)

	IF ISNULL(@PreventivoCorrectivo,0)= 0
		RAISERROR(N'Tipo de servicio es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdTipoUnidad,0)= 0
	SET @IdTipoUnidad = NULL	
						
	INSERT INTO CatServicios(Codigo,Servicio,CostoManoDeObra,TiempoDeServicio,ProporcionaServicioPorDia,ProporcionaServicioPorKilometro,PreventivoCorrectivo,IdClasificacionServicio,IdTipoUnidad,CreadoEl,CreadoPor,ProporcionaServicioPorHora,Activo)
	VALUES(@Codigo,@Servicio,@CostoManoDeObra,@TiempoDeServicio,@ProporcionaServicioPorDia,@ProporcionaServicioPorKilometro,@PreventivoCorrectivo,@IdClasificacionServicio,@IdTipoUnidad,@CreadoEl,@CreadoPor,@ProporcionaServicioPorHora,@Activo)
	---Registrar partes(articulo) al servicio, Aplica si el servicio si es correctivo
	IF @PreventivoCorrectivo = 1 --1 = Preventivo
		BEGIN 
			SET @IdServicio= (SELECT IDENT_CURRENT('CatServicios'))
	
			IF @dsCatServiciosPartes IS NOT NULL
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatServiciosPartes
					SELECT ATT_IdArticulo,ATT_IdAlmacen,ATT_CantidadParte
					INTO #TempCatServiciosPartes
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatServiciosPartes',2) 
					WITH (ATT_IdArticulo int,ATT_IdAlmacen int ,ATT_CantidadParte decimal(15, 4))

					EXEC sp_xml_removedocument @docHandle
			-- Declara variables
					DECLARE @ATT_IdArticulo int,@ATT_IdAlmacen int ,@ATT_CantidadParte decimal(15, 4)
			-- Declaración del cursor
					DECLARE #TempCatServiciosPartes1 CURSOR FOR
					SELECT ATT_IdArticulo,ATT_IdAlmacen,ATT_CantidadParte From #TempCatServiciosPartes
			-- Apertura del cursor
					OPEN #TempCatServiciosPartes1
			-- Lectura de la primera fila del cursor
					FETCH #TempCatServiciosPartes1 INTO @ATT_IdArticulo,@ATT_IdAlmacen,@ATT_CantidadParte
					WHILE (@@FETCH_STATUS = 0 )
						BEGIN
							INSERT INTO CatServiciosPartes (IdAlmacen,IdArticulo,CantidadParte,IdServicio,CreadoEl,CreadoPor)
							VALUES (@ATT_IdAlmacen,@ATT_IdArticulo,@ATT_CantidadParte,@IdServicio,@CreadoEl,@CreadoPor)
			-- Lectura de la siguiente fila del cursor
							FETCH #TempCatServiciosPartes1 INTO @ATT_IdArticulo,@ATT_IdAlmacen,@ATT_CantidadParte
						END
			-- Cierre del cursor
						CLOSE #TempCatServiciosPartes1
			-- Liberar los recursos
						DEALLOCATE #TempCatServiciosPartes1
				END
		END 			
	COMMIT		
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

