
CREATE TRIGGER [dbo].[trg_ProViajesCartasPorteFacturados]
	ON [dbo].[ProViajesCartasPorte]
	AFTER UPDATE
AS
BEGIN
	DECLARE @PendienteFacturar bit
	DECLARE @FacturadoParcialmente bit
	SET @PendienteFacturar = (SELECT PendienteFacturar FROM ProViajes WHERE IdViaje = (SELECT IdViaje FROM deleted))
	SET @FacturadoParcialmente = (SELECT FacturadoParcialmente FROM ProViajes WHERE IdViaje = (SELECT IdViaje FROM deleted))
	
	IF @PendienteFacturar = 0 OR @FacturadoParcialmente = 1
	BEGIN
		IF EXISTS(SELECT * FROM INSERTED I
        JOIN DELETED D ON D.ImpuestosRetenidosFederales <> I.ImpuestosRetenidosFederales OR D.ImpuestosRetenidosLocales <> I.ImpuestosRetenidosLocales OR D.ImpuestosTrasladadosFederales <> I.ImpuestosTrasladadosFederales
        OR D.ImpuestosTrasladadosLocales <> I.ImpuestosTrasladadosLocales OR D.MetodoPago <> I.MetodoPago OR D.NroCuentaPago <> I.NroCuentaPago OR D.Total <> I.Total)
        RAISERROR(N'No puede modificarse el viaje con carta porte porque está facturado',
            16,
            1
            )        
        
	END
END
go

