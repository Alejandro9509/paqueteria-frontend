

CREATE PROCEDURE [dbo].[usp_CatPropietariosEquiposModificar]
@IdPropietarioEquipo int,
@Codigo	int,	
@Descripcion varchar(50),	
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdPropietarioEquipo,0)= 0
	RAISERROR(N'El identificador es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del equipo es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@Descripcion,'') = ''
		RAISERROR(N'La descripción es un campo requerido',
			16,
			1
			)
			
			
	IF EXISTS(SELECT Codigo FROM CatPropietariosEquipos WHERE Codigo = @Codigo And IdPropietarioEquipo <> @IdPropietarioEquipo)
		RAISERROR(N'El código del equipo ya existe',
			16,
			1
			)	
										

	IF EXISTS(SELECT Descripcion FROM CatPropietariosEquipos WHERE Descripcion = @Descripcion And IdPropietarioEquipo <> @IdPropietarioEquipo)
		RAISERROR(N'La descripción ya existe',
			16,
			1
			)

			
	UPDATE CatPropietariosEquipos SET
	Codigo = @Codigo,
	Descripcion = @Descripcion,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor
	WHERE IdPropietarioEquipo = @IdPropietarioEquipo
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

