

CREATE PROCEDURE [dbo].[usp_ProEmbarqueGetMaxFoliosPQ]
	(@tipo int)
	
	AS BEGIN 
		
		
		if @tipo = 1 
			select  max( FolioEmbarque )  from ProEmbarquePQ;
		else if @tipo =2 
			select  max( FolioRecoleccion )  from ProRecoleccionPQ;
		else if @tipo =3
			select  max( FolioGuia)  from ProGuiaPQ;
		else if @tipo =4
			select  max( FolioInforme)  from ProInformePQ;
		end


go

