
CREATE PROCEDURE [dbo].[usp_ProEmbarqueDetalleModificarPQ](
	
	@IdEmbarque int  ,@Tipo int ,@Descripcion varchar(500) ,@Peso float,
	@Largo float,@Ancho float,@Alto float,@Volumen float,
	@IdTipoEmpaque int,@ValorDeclarado money,@Observaciones varchar(500),@Activo bit,
	@IdEmbarqueDetalle int,@ctd float, @IdProducto int
	)
AS
BEGIN
	Declare @nExiste int;
	BEGIN TRANSACTION
		IF ISNULL(@IdEmbarqueDetalle, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificaodr del Detalle de Embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdEmbarque, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificaodr de Embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdEmbarque, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificaodr de Embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Tipo, 0) = 0 begin
			RAISERROR(N'*INICIO*El Tipo es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La descripcion es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		if @Tipo = 2 begin -- 2 es paquete, y estos campos solamente aparecen en paquete
	
			IF ISNULL(@Peso, 0) = 0 begin
				RAISERROR(N'*INICIO*El Peso es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Largo, 0) = 0 begin
				RAISERROR(N'*INICIO*El Largo es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Ancho, 0) = 0 begin
				RAISERROR(N'*INICIO*El Ancho es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Alto, 0) = 0 begin
				RAISERROR(N'*INICIO*El Ancho es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Volumen, 0) = 0 begin
				RAISERROR(N'*INICIO*El Volumen es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@IdTipoEmpaque, 0) = 0 begin
				RAISERROR(N'*INICIO*El Tipo de Empaque es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			/*IF ISNULL(@ValorDeclarado, 0) = 0 begin
				RAISERROR(N'*INICIO*El Valor declarado es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end*/
			IF ISNULL(@IdProducto, 0) = 0 begin
				RAISERROR(N'*INICIO*El Valor declarado es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
		end
		select @nExiste = count(*)
		from dbo.ProGuiaPQ
		where IdEmbarque = @IdEmbarque
		;
		if @nExiste > 0 begin
			RAISERROR(N'*INICIO*El Embarque ya cuenta con una guia, no es posible modificarlo*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		update dbo.ProEmbarqueDetallePQ
		set Descripcion = @Descripcion,
		Peso = @Peso,
		Largo = @Largo,
		Ancho = @Ancho,
		Alto = @Alto,
		Volumen = @Volumen,
		IdTipoEmpaque= @IdTipoEmpaque,
		ValorDeclarado = @ValorDeclarado,
		Observaciones = @Observaciones,
		Activo = @Activo,
		ctd = @ctd,
		IdProducto = @IdProducto
		where IdEmbarqueDetalle = @IdEmbarqueDetalle;
		
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

