
CREATE PROCEDURE [dbo].[usp_CatEstadosEliminarPQ]
	@IdEstado INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdEstado,0) <= 0 begin
			RAISERROR(N'*INICIO*La abreviación del estado es obligatoria*FIN*', 16, 1);
			return
		end;
		
		DELETE FROM CatEstados
		WHERE IdEstado = @IdEstado
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

