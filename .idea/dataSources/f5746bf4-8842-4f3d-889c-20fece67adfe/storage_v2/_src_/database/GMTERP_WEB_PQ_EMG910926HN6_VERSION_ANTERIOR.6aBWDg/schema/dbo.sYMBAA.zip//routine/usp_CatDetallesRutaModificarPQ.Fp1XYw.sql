CREATE PROCEDURE [dbo].[usp_CatDetallesRutaModificarPQ](
	@IdDetalleRuta int,
	@IdFolio int,
	@Descripcion varchar(400),
	@IdTipoViaje int,
	@IdClasificacionViaje int,
	@IdTipoUnidad int,
	@TipoProyecto bit,
	@Horas float,
	@ETA float,
	@KM float,
	@Millas float,
	@Activa bit)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdDetalleRuta, 0) <= 0 begin
				RAISERROR(N'*INICIO*El Id del Detalle de ruta es campo requerido*FIN*', 16, 1)
				return;
			end
		IF ISNULL(@IdFolio, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Folio es un campo requerido*FIN*', 16, 1)
			return;
		end
		
		IF ISNULL(@IdTipoViaje, 0) <= 0 begin
			RAISERROR(N'*INICIO*El tipo de viaje es un campo requerido*FIN*', 16, 1)
			return;
		end
		IF ISNULL(@IdClasificacionViaje, 0) <= 0 begin
			RAISERROR(N'*INICIO*La clasificacion es un campo requerido*FIN*', 16, 1)
			return;
		end
		IF ISNULL(@IdTipoUnidad, 0) <= 0 begin
			RAISERROR(N'*INICIO*El tipo de unidad es un campo requerido*FIN*', 16, 1)
			return;
		end
		IF ISNULL(@TipoProyecto, 0) < 0 begin
			RAISERROR(N'*INICIO*El tipo de trayecto es un campo requerido*FIN*', 16, 1)
			return;
		end
		IF ISNULL(@Activa, 0) < 0 begin
			RAISERROR(N'*INICIO*El estatus es un campo requerido*FIN*', 16, 1)
			return;
		end
		
Update CatDetalleRutas
set IdFolio = @IdFolio , 
	Descripcion= @Descripcion,
	IdTipoViaje=@IdTipoViaje,
	IdClasificacionViaje=@IdClasificacionViaje, 
	IdTipoUnidad=@IdTipoUnidad,
	TipoTrayecto=@TipoProyecto, 
	Horas=@Horas,
	ETA=@ETA, 
	KM=@KM, 
	Millas=@Millas, 
	Activa=@Activa WHERE IdDetalleRuta =@IdDetalleRuta;

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

