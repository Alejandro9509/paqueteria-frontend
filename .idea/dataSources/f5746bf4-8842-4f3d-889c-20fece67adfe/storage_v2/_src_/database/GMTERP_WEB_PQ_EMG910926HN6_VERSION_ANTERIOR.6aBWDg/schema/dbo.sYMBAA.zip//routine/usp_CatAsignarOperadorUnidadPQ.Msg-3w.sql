

CREATE PROCEDURE [dbo].[usp_CatAsignarOperadorUnidadPQ](
	@IdOperador int,
	@IdUnidad int
	)
AS
BEGIN
	BEGIN TRANSACTION
	
		IF ISNULL(@IdOperador, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador del operador es un campo requerido*FIN*', 16, 1)
			return
		end

		IF ISNULL(@IdUnidad, '') = '' begin
			RAISERROR(N'*INICIO*El Identificador del operador es un campo requerido*FIN*', 16, 1)
			return
		end
		
		
		UPDATE CatUnidades set IdOperador = @IdOperador where IdUnidad = @IdUnidad
		Update ProInventarioUnidades set IdEstatuUnidad = 4 where IdUnidad = @IdUnidad
	IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

