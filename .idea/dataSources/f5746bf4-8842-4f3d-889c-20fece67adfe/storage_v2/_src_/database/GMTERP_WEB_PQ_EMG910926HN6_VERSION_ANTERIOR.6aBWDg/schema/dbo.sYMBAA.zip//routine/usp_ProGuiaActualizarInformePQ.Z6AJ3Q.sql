CREATE PROCEDURE [dbo].[usp_ProGuiaActualizarInformePQ](	
	@IdInforme int,
	@IdGuia int
	
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdInforme, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de informe es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdGuia, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de guia es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		UPDATE dbo.ProGuiaPQ SET
	
	  IdInforme=@IdInforme WHERE IdGuia=@IdGuia
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

