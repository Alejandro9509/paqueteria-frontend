CREATE PROCEDURE [dbo].[usp_ProGuiaConceptosEliminarPQ]
	@IdGuiaConcepto INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdGuiaConcepto,0) <= 0 begin
			RAISERROR(N'Identificador de Concepto de la Guia es un campo requerido', 16, 1);
			return;
		end;
		
		DELETE FROM ProGuiaConceptoPQ
		WHERE IdGuiaConcepto = @IdGuiaConcepto
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END
go

