CREATE PROCEDURE [dbo].[usp_CatCasetasEliminarPQ]
	@IdCaseta INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdCaseta,0) <= 0 begin
			RAISERROR(N'Identificador de la Caseta es un campo requerido', 16, 1);
			return;
		end;
		
		DELETE FROM CatCasetas
		WHERE IdCaseta = @IdCaseta
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END


go

