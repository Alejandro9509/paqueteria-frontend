
CREATE PROCEDURE [dbo].[usp_CatOperadoresEliminarPQ]
	@IdOperador INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdOperador,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de la Ciudad es un campo requerido*FIN*', 16, 1)
			return;
		end
		DELETE FROM CatOperadores
		WHERE IdOperador = @IdOperador
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

