
CREATE PROCEDURE [dbo].[usp_ProInformeEliminarPQ](
	@IdInforme int
	)
AS

BEGIN
	BEGIN TRANSACTION
		declare @ExisteGuia int;

		IF ISNULL(@IdInforme, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador de informe es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		/*select @ExisteGuia = count(*)
		from dbo.ProEmbarque g
		where g.idguia = @IdGuia and (g.idinforme is not null and g.idinforme > 0);
		if @ExisteGuia > 0 begin
			RAISERROR(N'*INICIO*No es posible borrar la guia ya que tiene un informe asignado*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		*/
		select @ExisteGuia = count(*)
		from dbo.ProInformePQ g
		where g.IdInforme= @IdInforme and (g.IdEstatusInforme <> 9);
		if @ExisteGuia > 0 begin
			RAISERROR(N'*INICIO*Para eliminar el informe es necesario cancelarla primero*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		delete ProInformeDetallePQ
		where IdInforme = @IdInforme;


		IF @@TRANCOUNT > 0
			BEGIN
				delete ProInformePQ
				WHERE IdInforme = @IdInforme;

				IF @@TRANCOUNT > 0
				BEGIN
					COMMIT TRANSACTION
				end
				else
					GOTO CANCELAR_TRANSACCION
				end
			
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

