


CREATE PROCEDURE [dbo].[usp_CatCodigosPostalesGetMunicipiosByIdEstadoPQ]
	@IdEstado varchar(5)
AS

if LEN(@IdEstado) = 1 begin
		set @IdEstado = CONCAT('0',@IdEstado)
	end

SELECT DISTINCT CodigoMunicipio as m_sCodigoMunicipio, UPPER(Municipio) AS m_sMunicipio FROM CatCodigosPostales WHERE IdEstado = @IdEstado
go

