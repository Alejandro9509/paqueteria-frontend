CREATE PROCEDURE [dbo].[usp_ProInformeGetListadoFiltroPQ]
	@IdSucursal INT,
	@IdEstatus INT,
	@FechaInicial DATE,
	@FechaFinal DATE,
	@FolioEmbarque VARCHAR(100),
	@IdOrigen int,
	@IdDestino int
AS
BEGIN TRY
	BEGIN TRANSACTION
	SELECT
		cin.IdInforme,
		cin.FolioInforme,
		cin.Fecha,
		cin.Hora,
		cin.IdEstatusInforme,
		cin.IdViaje,
		
		(select FolioViaje from ProViajesPQ v where cin.IdViaje = v.IdViaje) as FolioViaje,
				cin.IdSucursalEmisora,
		(select Sucursal from CatSucursales cs where cin.IdSucursalEmisora = cs.IdSucursal) as SucursalEmisora,
		cin.IdSucursalReceptora,

		(select Sucursal from CatSucursales cs where cin.IdSucursalReceptora = cs.IdSucursal) as SucursalReceptora,
				cin.IdOperador,

		(select Nombre from CatOperadores co where cin.IdOperador = co.IdOperador) as NombreOperador,
		(select NumeroOperador from CatOperadores co where cin.IdOperador = co.IdOperador) as NumeroOperador,
		cin.IdDolly,
		(select Descripcion from CatUnidades ctu where cin.IdDolly = ctu.IdUnidad) as Dolly,
		(select Codigo from CatUnidades ctu where cin.IdDolly = ctu.IdUnidad) as Identificador,
				cin.IdRemolque1,
				cin.IdRemolque2,

		(select Descripcion from CatUnidades cu where cin.IdRemolque1 = cu.IdUnidad) as Remolque1,
		(select Descripcion from CatUnidades cu where cin.IdRemolque2 = cu.IdUnidad) as Remolque2,
		cin.PlacasRemolque1,
		cin.PlacasRemolque2,
		(select Ciudad from CatCiudades cc where cin.IdCiudadOrigen = cc.IdCiudad) as CiudadOrigen,
		(select Ciudad from CatCiudades cc where cin.IdCiudadDestino = cc.IdCiudad) as CiudadDestino,
		(select Descripcion from CatDetalleRutasPQ cr where cin.IdRuta = cr.IdDetalleRuta) as Ruta,
		cin.FechaCancelacion,
		cin.UsuarioCancelacion, 
		cus.Nombre,
		cus.APaterno,
		cus.AMaterno
		FROM ProInformePQ cin left JOIN CatUsuariosPQ cus on cin.UsuarioCancelacion= cus.IdUsuario
		WHERE (cin.IdSucursal = @IdSucursal OR @IdSucursal IS NULL)
		AND (IdEstatusInforme = @IdEstatus OR @IdEstatus IS NULL)
		AND (Fecha >= @FechaInicial OR @FechaInicial IS NULL)
		AND (Fecha <= @FechaFinal OR @FechaFinal IS NULL)
		AND (IdCiudadOrigen = @IdOrigen OR @IdOrigen IS NULL)
		AND (IdCiudadDestino = @IdDestino OR @IdDestino IS NULL)
		AND (FolioInforme LIKE '%'+@FolioEmbarque+'%' OR @FolioEmbarque IS NULL)
		ORDER BY Fecha DESC, Hora DESC
	--AND cin.IdViaje <= 0 


		
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

