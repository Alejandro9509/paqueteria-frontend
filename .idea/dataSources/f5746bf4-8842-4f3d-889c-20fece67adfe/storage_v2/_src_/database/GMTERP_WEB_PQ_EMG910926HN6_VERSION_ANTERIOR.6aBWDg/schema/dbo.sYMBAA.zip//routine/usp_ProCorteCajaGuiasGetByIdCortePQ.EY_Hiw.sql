CREATE PROCEDURE [dbo].[usp_ProCorteCajaGuiasGetByIdCortePQ](
@IdCorte int
)
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT 
		c.IdCorte,
		c.IdCorteGuia,
		g.IdEmbarque
		,(select FolioEmbarque from ProEmbarquePQ e where g.IdEmbarque = e.IdEmbarque) as FolioEmbarque
		,(select IdRecoleccion from ProRecoleccionPQ r where r.IdRecoleccion =  e.IdRecoleccion) as foliorecoleccion
		,g.FolioGuia
		,(select FolioInforme from ProInformePQ r where r.IdInforme =  g.IdInforme) as FolioInforme
		,e.Fecha
		,g.Hora
		,g.IdEstatusGuia
		
		,e.TipoCambio
		,e.IdTipoCobro
		,e.NombreRemitente
		,e.RFCRemitente
		,e.DomicilioRemitente
		,e.IdCodigoPostalRemitente
		,e.IdCiudadRemitente
		,e.CorreoRemitente
		,e.TelefonoRemitente
		,e.ContactoRemitente
		,e.IdCiudadOrigen
		,e.NombreDestinatario
		,e.RFCDestinatario
		,e.DomicilioDestinatario
		,e.IdCodigoPostalDestinatario
		,e.IdCiudadDestinatario
		,e.CorreoDestinatario
		,e.TelefonoDestinatario
		,e.ContactoDestinatario
		,e.IdCiudadDestino
		,e.FechaEntrega
		,e.HoraEntrega
		,e.NoPaquetes
		,e.NoSobres
		,e.IdOperador
		,e.IdUnidad
		,e.FechaSalida
		,e.HoraSalida
		,g.FechaCancelacion
		,g.UsuarioCancelacion
		,e.MotivoCancelacion
		,e.EntregarMismoDomicilio 
		,e.FechaLlegada 
		,e.HoraLlegada  
		,e.CodigoPostalEntrega  
		,e.IdCiudadEntrega 
		,e.IdZonaEntrega 
		,e.DomicilioEntrega  
		,e.EntregarEn  
		,DatosAdicionales 
		,g.Tracking,g.IdMoneda,g.CreadoPor,g.CreadoEl,g.ModificadoPor,g.ModificadoEl,g.IdGuia,g.IdSucursal,
		(select Sucursal from CatSucursales s where s.IdSucursal = g.IdSucursal ) as Sucursal,	
		(select Estatus from CatEstatusGuiasPQ eg where eg.IdEstatusGuias = g.IdEstatusGuia ) as estatusguia,
		(select Ciudad from CatCiudades c where c.IdCiudad = e.IdCiudadOrigen) as CiudadOrigen,
		(select Ciudad from CatCiudades c where c.IdCiudad = e.IdCiudadDestino) as CiudadDestino,

		(select Estado from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadRemitente)) as EstadoRemitente,
		(select Estado from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadDestinatario)) as EstadoDestinatario,
		(select Estado from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadEntrega)) as EstadoEntregaGuia,
		(select Pais from CatPaises pai where pai.IdPais = (select IdPais from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadRemitente))) as PaisRemitente,
		(select Pais from CatPaises pai where pai.IdPais = (select IdPais from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadDestinatario))) as PaisDestinatario,
		(select Pais from CatPaises pai where pai.IdPais = (select IdPais from CatEstados est where est.IdEstado = (select IdEstado from CatCiudades c where c.IdCiudad = e.IdCiudadEntrega))) as PaisEntregaGuia
		,g.ValorDeclarado,g.IdTipoServicio, g.qrValidado, g.utimaMillaOrden, g.pagado
		,e.IdCliente
		,(Select c.NombreFiscal from CatClientes c where c.IdCliente = e.IdCliente) as Cliente
		,(Select c.Bloqueado from CatClientes c where c.IdCliente = e.IdCliente) as ClienteBloqueado
		FROM ProCorteCajaGuiasPQ c 
		join ProGuiaPQ g on g.IdGuia = c.IdGuia 
		join  ProEmbarquePQ e on g.IdEmbarque= e.IdEmbarque
		WHERE c.IdCorte = @IdCorte
		
		/*join ProCorteCajaGuiasPQ cg on c.IdCorte = cg.IdCorte 
		join ProGuiaPQ g on g.IdGuia = cg.IdGuia*/
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

