
CREATE PROCEDURE [dbo].[usp_ProGuiaGenerarRutaPQ](
	@IdGuia int,
	@Longitud varchar(20),
	@Latitud varchar(20),
	@Orden int,
	@EsRecolecta bit,
	@HoraEstimada text
	)
AS
BEGIN
	BEGIN TRANSACTION
		declare @n_existe int;
		DECLARE @n_IdEmbarque int;
		IF ISNULL(@IdGuia, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador de la guia es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		BEGIN
		IF @EsRecolecta > 0 BEGIN
		
		UPDATE ProRecoleccionPQ 
			set /*Tracking = @Tracking,
			FolioGuia = @FolioGuia,*/
			IdEstatusRecoleccion = (case when IdEstatusRecoleccion = 1 then 3 else IdEstatusRecoleccion end),
			Longitud = @Longitud,
			Latitud = @Latitud,
			OrdenUltimaMilla = @Orden,
			IdEstatusUltimaMilla = (case when IdEstatusUltimaMilla is Null then 1 else IdEstatusUltimaMilla end),
			HoraEstimadaUltimaMilla = @HoraEstimada
			where IdRecoleccion = @IdGuia;
			
		END
		ELSE
		BEGIN
		
			UPDATE ProGuiaPQ 
			set /*Tracking = @Tracking,
			FolioGuia = @FolioGuia,*/
			IdEstatusGuia = (case when IdEstatusGuia = 14  then 17 else IdEstatusGuia end),
			Longitud = @Longitud,
			Latitud = @Latitud,
			utimaMillaOrden = @Orden,
			IdEstatusUltimaMilla = (case when IdEstatusUltimaMilla is Null then 1 else IdEstatusUltimaMilla end),
			HoraEstimadaUltimaMilla = @HoraEstimada
			where IdGuia = @IdGuia;
			
		END
		


		end

		end
		IF @@TRANCOUNT > 0
		BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END

go

