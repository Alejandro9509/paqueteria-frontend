

CREATE PROCEDURE [dbo].[usp_ProGuiaModificarPQ](
	
	@Tracking int ,
	@FolioGuia varchar(50) ,
	@IdEstatusGuia int,
	@IdEmbarque int,
	@IdMoneda int,
	@TipoCambio int ,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@IdGuia int,
	@IdSucursal int,
	@ValorDeclarado money,
	@IdTipoServicio int
	)
AS
BEGIN
	BEGIN TRANSACTION
		declare @n_existe int;
		IF ISNULL(@IdGuia, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador de la guia es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		select @n_existe =count(*)
		from dbo.ProEmbarquePQ 
		where IdGuia = @IdGuia
		and IdInforme is not null and IdInforme > 0
		if @n_existe > 0 begin
			RAISERROR(N'*INICIO*No es posible modificar la Guia ya que esta relacionada a un informe*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdSucursal, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@IdEmbarque, '') = '' begin
			RAISERROR(N'*INICIO*El identificador del embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		/*
		IF ISNULL(@FolioGuia, '') = '' begin
			RAISERROR(N'*INICIO*El Folio de guia es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
		IF ISNULL(@IdEstatusGuia, '') = '' begin
			RAISERROR(N'*INICIO*El identificador del estatus de la guia es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		/*
		IF ISNULL(@Fecha, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Hora, '') = '' begin
			RAISERROR(N'*INICIO*La hora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		*/
		IF ISNULL(@IdMoneda, 0) = 0 begin
			RAISERROR(N'*INICIO*El Moneda de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@TipoCambio, 0) = 0 begin
			RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF @IdEstatusGuia = 8 begin
			update dbo.ProGuiaPQ 
			set /*Tracking = @Tracking,
			FolioGuia = @FolioGuia,*/
			IdSucursal = @IdSucursal,
			IdEstatusGuia =@IdEstatusGuia,
			IdEmbarque = @IdEmbarque,
			IdMoneda = @IdMoneda,
			TipoCambio =@TipoCambio,
			--ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor,
			ValorDeclarado = @ValorDeclarado,
			IdTipoServicio = @IdTipoServicio,
			FechaCancelacion = SYSDATETIME()
			where IdGuia = @IdGuia;
			end
		else
		BEGIN
		update dbo.ProGuiaPQ 
			set /*Tracking = @Tracking,
			FolioGuia = @FolioGuia,*/
			IdSucursal = @IdSucursal,
			IdEstatusGuia =@IdEstatusGuia,
			IdEmbarque = @IdEmbarque,
			IdMoneda = @IdMoneda,
			TipoCambio =@TipoCambio,
			--ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor,
			ValorDeclarado = @ValorDeclarado,
			IdTipoServicio = @IdTipoServicio--,
			--FechaCancelacion = NULL
			where IdGuia = @IdGuia;			
		end
		IF @@TRANCOUNT > 0
		BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

