CREATE PROCEDURE [dbo].[usp_ProGuiaCancelarPQ]
	@IdGuia INT,
	@MotivoCancelacion VARCHAR(500),
	@UsuarioCancelacion INT,
	@FechaCancelacion DATETIME
AS
--BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdGuia,0) <= 0 
			RAISERROR(N'Identificador de Guia es un campo requerido', 16, 1)
			IF ISNULL(@MotivoCancelacion, '') = ''
			RAISERROR(N'El motivo de cancelacion es un campo requerido', 16, 1)
			IF ISNULL(@UsuarioCancelacion,0) <= 0 
			RAISERROR(N'Usuario que lo cancela es un campo requerido', 16, 1)
			IF ISNULL(@FechaCancelacion, '') = ''
			RAISERROR(N'La fecha de cancelacion es un campo requerido', 16, 1)
		UPDATE ProGuiaPQ
		SET MotivoCancelacion = @MotivoCancelacion,
		IdEstatusGuia = 8,
		FechaCancelacion = @FechaCancelacion,
		UsuarioCancelacion = @UsuarioCancelacion
		WHERE IdGuia = @IdGuia
	COMMIT TRANSACTION
	BEGIN TRANSACTION
		UPDATE ProEmbarquePQ
		SET IdGuia = NULL 
		WHERE IdGuia = @IdGuia
	COMMIT TRANSACTION
--END TRY
--BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
--END CATCH
go

