
	CREATE PROCEDURE [dbo].[usp_CatClasificacionViajeEliminarPQ]
	@IdClasificacionViaje int
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdClasificacionViaje, 0) <= 0 begin
			RAISERROR(N'*INICIO*El ID es un campo requerido*FIN*', 16, 1);
			return;
			end

			Delete from CatClasificacionViaje
			Where IdClasificacionViaje = @IdClasificacionViaje

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

