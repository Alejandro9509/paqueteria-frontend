
CREATE PROCEDURE [dbo].[usp_CatFoliosAgregarPQ](
	@IdSucursal int,
	@IdTipoDocumento int,
	@IdFormato int,
	@Serie varchar(10),
	@Folio int,
	@IdEstatusFolio int,
	@CreadoEl datetime,
	@CreadoPor int 
	)
AS
BEGIN TRY
	BEGIN TRANSACTION
	declare @FOLIOR varchar(50);

		IF ISNULL(@IdSucursal,0) <= 0 begin
			RAISERROR(N'*INICIO*La sucursal es campo requerido*FIN*', 16, 1);
			return
		end

		IF ISNULL(@Serie, '') = '' begin
			RAISERROR(N'*INICIO*La Serie es un campo requerido*FIN*', 16, 1);
			return
		end
			
		IF ISNULL(@IdTipoDocumento,0) <= 0 begin
			RAISERROR(N'*INICIO*El tipo de documento es campo requerido*FIN*', 16, 1);
			return
		end

		IF ISNULL(@Folio,0) <= 0 begin
			RAISERROR(N'*INICIO*El Folio es campo requerido*FIN*', 16, 1);
			return
		end
		IF ISNULL(@IdEstatusFolio,0) <= 0 begin
			RAISERROR(N'*INICIO*El estatus del folio es campo requerido*FIN*', 16, 1);
			return
		end
		
		IF  exists (Select IdFolio from CatFolios where Folio= @Folio and IdTipoDocumento= @IdTipoDocumento and Serie =@Serie) begin
		RAISERROR(N'*INICIO*Ese folio ya existe *FIN*', 16, 1);
			
			return
		end

		select @FOLIOR=format(@Folio,'0000000000');
		
		INSERT INTO CatFoliosPQ(IdSucursal,IdTipoDocumento, IdFormato,Serie,Folio,IdEstatusFolio,CreadoEl,CreadoPor)
		VALUES (@IdSucursal, @IdTipoDocumento, @IdFormato, @Serie,@FOLIOR,@IdEstatusFolio,@CreadoEl,@CreadoPor)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

