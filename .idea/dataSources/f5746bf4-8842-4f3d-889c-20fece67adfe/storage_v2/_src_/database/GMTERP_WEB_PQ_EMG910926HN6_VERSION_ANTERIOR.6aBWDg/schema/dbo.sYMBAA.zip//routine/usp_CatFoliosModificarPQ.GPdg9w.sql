
CREATE PROCEDURE [dbo].[usp_CatFoliosModificarPQ](
	@IdFolio int,
	@IdSucursal int,
	@IdFormato int,
	@Serie varchar(10) )

	AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdFolio,0) <= 0 begin
			RAISERROR(N'*INICIO*El Id del folio es un campo requerido*FIN*', 16, 1);			
			return
		end
		IF ISNULL(@IdSucursal,0) <= 0 begin
			RAISERROR(N'*INICIO*La sucursal es campo requerido*FIN*', 16, 1);
			return
		end

		IF ISNULL(@Serie, '') = '' begin
			RAISERROR(N'*INICIO*La Serie es un campo requerido*FIN*', 16, 1);
			return
		end
			
	
		
		UPDATE CatFoliosPQ SET
		IdSucursal=@IdSucursal,
		IdFormato=@IdFormato,
		Serie=@Serie
		
		WHERE IdFolio = @IdFolio
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

