CREATE PROCEDURE [dbo].[usp_ProGuiasGetListadoFechaEntregaPQ]
	@FechaEntrega DATE
	
AS
BEGIN TRY
	BEGIN TRANSACTION
	SELECT
		e.IdEmbarque,
		e.FolioEmbarque,
		(select idrecoleccion from dbo.prorecoleccionPQ r where r.idrecoleccion =  e.idrecoleccion) as foliorecoleccion,
		g.FolioGuia,
		(select folioinforme from dbo.proinformePQ r where r.idinforme =  e.idinforme) as folioinforme,
		e.Fecha,
		g.Hora,
		g.IdEstatusGuia,
		
		e.TipoCambio,
		e.IdTipoCobro,
		e.NombreRemitente,
		e.RFCRemitente,
		e.DomicilioRemitente,
		e.IdCodigoPostalRemitente,
		e.IdCiudadRemitente,
		e.CorreoRemitente,
		e.TelefonoRemitente,
		e.ContactoRemitente,
		e.IdCiudadOrigen,
		e.NombreDestinatario,
		e.RFCDestinatario,
		e.DomicilioDestinatario,
		e.IdCodigoPostalDestinatario,
		e.IdCiudadDestinatario,
		e.CorreoDestinatario,
		e.TelefonoDestinatario,
		e.ContactoDestinatario,
		e.IdCiudadDestino,
		e.FechaEntrega,
		e.HoraEntrega,
		e.NoPaquetes,
		e.NoSobres,
		e.IdOperador,
		e.IdUnidad,
		e.FechaSalida,
		e.HoraSalida,
		g.FechaCancelacion,
		g.UsuarioCancelacion,
		g.MotivoCancelacion,
		e.EntregarMismoDomicilio,
		e.FechaLlegada,
		e.HoraLlegada,
		e.CodigoPostalEntrega,
		e.IdCiudadEntrega,
		e.IdZonaEntrega,
		e.DomicilioEntrega,
		e.EntregarEn,
		DatosAdicionales,
		g.tracking,
		g.Idmoneda,
		g.IdGuia,
		g.idsucursal,
		g.CreadoPor,
		g.ModificadoPor,
		g.CreadoEl,
		g.ModificadoEL,
		(select sucursal from catsucursalesPQ s where s.idsucursal = g.idsucursal ) as Sucursal,
		(select estatus from catestatusguiasPQ eg where eg.idestatusguias = g.IdEstatusGuia ) as estatusguia,
		(select ciudad from catciudades c where c.idciudad = e.IdCiudadOrigen) as CiudadOrigen,
		(select ciudad from catciudades c where c.idciudad = e.IdCiudadDestino) as CiudadDestino,
		g.ValorDeclarado,g.idTipoServicio
		
		FROM proGuiaPQ g,ProEmbarquePQ e
		
		WHERE (g.FechaEntrega = @FechaEntrega)
		
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH


go

