
CREATE PROCEDURE [dbo].[usp_CatDepartamentoModificarPQ](
	@IdDepartamento INT,
	@Codigo VARCHAR(3),
	@Descripcion VARCHAR(100),
	@ModificadoEl DATETIME,
	@ModificadoPor INT)
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF ISNULL(@IdDepartamento, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Departament es un campo requerido*FIN*', 16, 1);
			return
		end

		IF ISNULL(@Codigo, '') = '' begin
			RAISERROR(N'*INICIO*El código del Departamento es un campo requerido*FIN*', 16, 1);
			return
		end
		IF ISNULL(@Descripcion, '') = '' begin 			
			RAISERROR(N'*INICIO*La descripción es un campo requerido*FIN*', 16, 1);
			return
		end
		UPDATE catDepartamento SET
		Codigo = @Codigo,
		Descripcion = @Descripcion,
		ModificadoEl = @ModificadoEl,
		ModificadoPor =@ModificadoPor
		WHERE IdDepartamento= @IdDepartamento
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

