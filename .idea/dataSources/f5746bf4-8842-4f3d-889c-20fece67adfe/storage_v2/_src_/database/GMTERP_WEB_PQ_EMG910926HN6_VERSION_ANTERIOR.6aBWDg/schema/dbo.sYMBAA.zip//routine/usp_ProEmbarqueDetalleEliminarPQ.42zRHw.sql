
CREATE PROCEDURE [dbo].[usp_ProEmbarqueDetalleEliminarPQ](
	@IdEmbarqueDetalle int
	)
AS

BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdEmbarqueDetalle, '') = '' begin
			RAISERROR(N'*INICIO*El identificador de detalle de embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		delete ProEmbarqueDetallePQ
		where IdEmbarqueDetalle = @IdEmbarqueDetalle;


		IF @@TRANCOUNT > 0
			BEGIN
		
				COMMIT TRANSACTION
			end
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

