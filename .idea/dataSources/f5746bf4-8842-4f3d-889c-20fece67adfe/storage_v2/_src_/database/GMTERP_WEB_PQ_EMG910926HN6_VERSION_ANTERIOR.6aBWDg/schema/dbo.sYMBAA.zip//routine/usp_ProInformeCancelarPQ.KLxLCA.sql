CREATE PROCEDURE [dbo].[usp_ProInformeCancelarPQ]
	@IdInforme INT,
	@IdUsuarioCancelacion INT,
	@FechaCancelacion DATETIME,
	@MotivoCancelacion VARCHAR(500)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdInforme,0) <= 0 
			RAISERROR(N'Identificador de Informe es un campo requerido', 16, 1)
			IF ISNULL(@MotivoCancelacion, '') = ''
			RAISERROR(N'El motivo de cancelacion es un campo requerido', 16, 1)
			IF ISNULL(@IdUsuarioCancelacion,0) <= 0 
			RAISERROR(N'El ussuario que cancela es un campo requerido', 16, 1)
			IF ISNULL(@FechaCancelacion, '') = ''
			RAISERROR(N'La fecha y hora de cancelacion es un campo requerido', 16, 1)
		UPDATE ProInformePQ
		SET MotivoCancelacion = @MotivoCancelacion,
		IdEstatusInforme = 9,
		UsuarioCancelacion = @IdUsuarioCancelacion,
		FechaCancelacion = @FechaCancelacion
		WHERE IdInforme = @IdInforme
	COMMIT TRANSACTION
	BEGIN TRANSACTION
		UPDATE ProGuiaPQ
		set IdInforme = NULL
		WHERE IdInforme = @IdInforme
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

