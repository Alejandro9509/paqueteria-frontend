
CREATE PROCEDURE [dbo].[usp_ProCorteCajaModificarPQ](
	@IdCorte int,
	@IdSucursal int,
	@IdDestino int,
	@IdTipoMoneda int,
	@IdTipoPago int,
	@Total float,
	@IdEstatusCorte int
)
AS
BEGIN
	BEGIN TRANSACTION
		
		Update ProCorteCajaPQ 
		set IdSucursal = @IdSucursal,
		IdDestino = @IdDestino,
		IdTipoMoneda = @IdTipoMoneda,
		IdTipoPago = @IdTipoPago,
		Total = @Total,
		IdEstatusCorte = @IdEstatusCorte
		where IdCorte = @IdCorte;

		Delete from ProCorteCajaGuiasPQ where IdCorte = @IdCorte;

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

