
CREATE PROCEDURE [dbo].[usp_CatFoliosEliminarPQ]
	@IdFolio INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdFolio,0) <= 0 begin
			RAISERROR(N'*INICIO*El Id del folio es un campo requerido*FIN*', 16, 1);			
			return
		end
		DELETE FROM CatFoliosPQ
		WHERE IdFolio = @IdFolio
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

