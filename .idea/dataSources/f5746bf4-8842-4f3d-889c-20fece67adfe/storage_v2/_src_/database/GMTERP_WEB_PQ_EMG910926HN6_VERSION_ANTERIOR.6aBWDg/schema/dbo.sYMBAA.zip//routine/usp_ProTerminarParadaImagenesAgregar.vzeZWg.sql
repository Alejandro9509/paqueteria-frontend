CREATE PROCEDURE [dbo].[usp_ProTerminarParadaImagenesAgregar]
	@IdGuia int,
	@EsRecoleccion int,
	@Imagen ntext,
	@ImagenNombreArchivo varchar(500),
	@Descripcion varchar(150),
	@CreadoPor int, 
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@Obs int = 0,
	@Tipo int
AS
/*************************************************************************************************************************************
	@IdViaje int id del proceso ,
	@Imagen ntext,
	@ImagenNombreArchivo varchar(500),
	@Descripcion varchar(150),
	@CreadoPor int, 
	@CreadoEl datetime,
	@IdPeticion varchar(100)

	
	Modificado por: Enrique Ramos Alvarez
	Fecha de Modificacion:  13/02/2020
	Versión: 8.0.51.05
	Solicitud 1514
	Se cambio el tamaño del los parametros recibidos, se agrego el campo del obs 1 al agregar el registro 
		Modificado por: Enrique Ramos Alvarez
	Fecha de Modificacion:  02/04/2020
	Versión: 8.0.51.31
	Solicitud 1514
	Se cambio el obs a un variable para los clientes con la ap movil desactualizada 
	
	***************************************/
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdGuia,0) = 0
		RAISERROR(N'Identificador de guia es un campo requerido',
			16,
			1
			)
	
		INSERT INTO CatParadasImagenes(IdGuia,EsRecoleccion,Imagen,ImagenNombreArchivo,Descripcion,CreadoPor,CreadoEl,Obs, Tipo)	
	VALUES(@IdGuia,@EsRecoleccion,@Imagen,@ImagenNombreArchivo,@Descripcion,@CreadoPor,@CreadoEl,@Obs, @Tipo)
	COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

