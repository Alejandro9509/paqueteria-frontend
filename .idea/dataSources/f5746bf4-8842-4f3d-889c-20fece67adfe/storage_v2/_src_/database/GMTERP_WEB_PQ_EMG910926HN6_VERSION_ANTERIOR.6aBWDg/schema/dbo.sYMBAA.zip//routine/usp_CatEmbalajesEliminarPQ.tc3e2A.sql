

CREATE PROCEDURE [dbo].[usp_CatEmbalajesEliminarPQ](
	@IdEmbalaje INT)
AS
	BEGIN TRANSACTION
	IF ISNULL(@IdEmbalaje, 0) <= 0 begin
		RAISERROR(N'*INICIO*El Id de embalaje es un campo requerido*FIN*', 16, 1);
		return;
	end;
		
	DELETE FROM CatEmbalajes
	WHERE IdEmbalaje = @IdEmbalaje
	IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
	ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    
		CANCELAR_TRANSACCION:
		IF @@TRANCOUNT > 0
		BEGIN
			EXECUTE usp_GetErrorInfo;
				ROLLBACK TRANSACTION
				RETURN -1
		END
	END
go

