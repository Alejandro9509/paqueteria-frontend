
CREATE PROCEDURE [dbo].[usp_CatEmbalajesModificarPQ](
	@IdEmbalaje int, 
	@Codigo varchar(10) ,
	@Nombre varchar(30) ,
	@Descripcion varchar(50),
	@ModificadoPor int,
	@ModificadoEl Datetime)
AS
BEGIN
	
	BEGIN TRANSACTION
--BEGIN TRY
		IF ISNULL(@IdEmbalaje, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Id de embalaje es un campo requerido*FIN*', 16, 1);
			return;
		end
		IF ISNULL(@Codigo, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Código de embalaje es un campo requerido*FIN*', 16, 1);
			return;
		end
		IF ISNULL(@Nombre, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Nombre es un campo requerido*FIN*', 16, 1);
			return;
		end
		UPDATE  CatEmbalajes set
		Codigo=@Codigo,
		Nombre=@Nombre,
		Descripcion =@Descripcion,
		ModificadoPor =@ModificadoPor,
		ModificadoEl=@ModificadoEl
		WHERE IdEmbalaje=@IdEmbalaje
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

