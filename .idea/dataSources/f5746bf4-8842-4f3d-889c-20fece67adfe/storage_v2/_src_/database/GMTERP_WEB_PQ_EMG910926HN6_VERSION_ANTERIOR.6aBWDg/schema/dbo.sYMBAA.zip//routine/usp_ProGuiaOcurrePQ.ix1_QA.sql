

CREATE PROCEDURE [dbo].[usp_ProGuiaOcurrePQ](
	@IdGuia int,
	@IdUsuarioEntregaOcurre int,
	@MontoRecibidoOcurre money,
	@FechaOcurre varchar(50),
	@HoraOcurre varchar(50),
	@ComentariosOcurre varchar(50),
	@IdTipoPago int
	)
AS
BEGIN
	BEGIN TRANSACTION
		declare @FechaOcurreDate date;
		declare @HoraOcurreTime time;
		IF ISNULL(@IdGuia, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador de la guia es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF @FechaOcurre IS NOT NULL AND LEN(@FechaOcurre) > 0 begin
			set @FechaOcurreDate = CAST(@FechaOcurre as date)
		end
		IF @HoraOcurre IS NOT NULL AND LEN(@HoraOcurre) > 0 begin
			set @HoraOcurreTime = CAST(@HoraOcurre as time)
		end
		BEGIN
		update dbo.ProGuiaPQ 
			set 
			IdUsuarioEntregaOcurre = @IdUsuarioEntregaOcurre,
			IdEstatusGuia = 18,
			FechaOcurre = @FechaOcurreDate,
			HoraOcurre = @HoraOcurreTime,
			ComentariosOcurre =@ComentariosOcurre,
			MontoRecibidoOcurre = @MontoRecibidoOcurre,
			TipoPago = @IdTipoPago,
			pagado = 1
			where IdGuia = @IdGuia;			
		end
		IF @@TRANCOUNT > 0
		BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

