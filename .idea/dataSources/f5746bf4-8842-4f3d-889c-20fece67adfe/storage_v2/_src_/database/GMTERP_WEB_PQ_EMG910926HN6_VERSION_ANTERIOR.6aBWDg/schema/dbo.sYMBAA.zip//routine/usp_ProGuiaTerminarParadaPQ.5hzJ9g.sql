CREATE PROCEDURE [dbo].[usp_ProGuiaTerminarParadaPQ](
	@IdGuia int,
	@Estatus int
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdGuia, 0) <= 0 begin
			RAISERROR(N'El id de la guía es campo requerido', 16, 1);
			return;
		end;
		IF ISNULL(@Estatus, 0) = '' begin
			RAISERROR(N'El estatus es un campo requerido', 16, 1)
			return;
		end
		
		UPDATE ProGuiaPQ set 
		IdEstatusGuia = @Estatus
		WHERE IdGuia = @IdGuia;

		DECLARE @IdInforme int;
		SELECT @IdInforme  = IdInforme FROM ProGuiaPQ WHERE IdGuia = @IdGuia

		DECLARE @Terminado int;
		SELECT @Terminado = COUNT (*) FROM ProGuiaPQ WHERE IdInforme = @IdInforme AND IdEstatusGuia = 6

		IF @Terminado < = 0
			UPDATE ProInformePQ SET
			IdEstatusInforme = 8
			WHERE IdInforme = @IdInforme;

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
end
go

