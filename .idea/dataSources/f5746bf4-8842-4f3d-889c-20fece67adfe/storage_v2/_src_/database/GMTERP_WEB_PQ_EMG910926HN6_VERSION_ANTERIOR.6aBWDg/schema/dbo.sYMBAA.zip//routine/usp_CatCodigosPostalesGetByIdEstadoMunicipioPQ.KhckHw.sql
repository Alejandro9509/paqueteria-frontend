
CREATE PROCEDURE [dbo].[usp_CatCodigosPostalesGetByIdEstadoMunicipioPQ]
	@IdEstado varchar(5),
	@CodeMunicipio varchar(5)
AS

SELECT * FROM CatCodigosPostales WHERE IdEstado = @IdEstado and CodigoMunicipio = @CodeMunicipio order by CodigoPostal, Colonia
go

