CREATE PROCEDURE [dbo].[usp_ProEmbarqueGetListadoFiltroPQ]
	@IdSucursal INT,
	@IdEstatus INT,
	@FechaInicial DATE,
	@FechaFinal DATE,
	@FolioEmbarque VARCHAR(100),
	@IdOrigen int,
	@IdDestino int
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT 	
			IdEmbarque
			,IdRecoleccion
	,FolioEmbarque
	,(select max(FolioRecoleccion) from ProRecoleccionPQ pg where pg.IdRecoleccion = pp.IdRecoleccion) as foliorecoleccion
    ,(select max(FolioGuia) from dbo.ProGuiaPQ pg where pg.IdEmbarque = pp.IdEmbarque) as folioguia
	,Fecha
	,Hora
	,IdEstatusEmbarque
	,IdMoneda
	,TipoCambio
	,IdTipoCobro
	,NombreRemitente
	,RFCRemitente
	,DomicilioRemitente
	,IdCodigoPostalRemitente
	,IdCiudadRemitente
	,CorreoRemitente
	,TelefonoRemitente
	,ContactoRemitente
	,IdCiudadOrigen
	,NombreDestinatario
	,RFCDestinatario
	,DomicilioDestinatario
	,IdCodigoPostalDestinatario
	,IdCiudadDestinatario
	,CorreoDestinatario
	,TelefonoDestinatario
	,ContactoDestinatario
	,IdCiudadDestino
	,FechaEntrega
	,HoraEntrega
	,NoPaquetes
	,NoSobres
	,IdOperador
	,IdUnidad
	,FechaSalida
	,HoraSalida
	,FechaCancelacion
	,UsuarioCancelacion
	,MotivoCancelacion
	,EntregarMismoDomicilio 
	,FechaLlegada 
	,HoraLlegada  
	,CodigoPostalEntrega  
	,IdCiudadEntrega 
	,IdZonaEntrega 
	,DomicilioEntrega  
	,EntregarEn  
	,DatosAdicionales
	,(select Sucursal from CatSucursales su where su.IdSucursal = pp.IdSucursal) as Sucursal
	,(select Estatus from CatEstatusEmbarquePQ ee where ee.IdEstatusEmbarque = pp.IdEstatusEmbarque) as EstatusEmbarque
	,(select Color from CatEstatusEmbarquePQ ee where ee.IdEstatusEmbarque = pp.IdEstatusEmbarque) as ColorEstatusEmbarque
    ,(select OrigenDestino from CatOrigenesDestinos cd where cd.IdOrigenDestino = pp.IdCiudadOrigen) as CiudadOrigen
    ,(select OrigenDestino from CatOrigenesDestinos cd where cd.IdOrigenDestino = pp.IdCiudadDestino) as CiudadDestino
    ,IdSucursal
	,IdCliente,
	(select cc.NombreFiscal from CatClientes cc WHERE pp.IdCliente =cc.IdCliente ) as NombreCliente
	FROM ProEmbarquePQ pp
		WHERE (IdSucursal = @IdSucursal OR @IdSucursal IS NULL)
		AND (IdEstatusEmbarque = @IdEstatus OR @IdEstatus IS NULL)
		AND (Fecha >= @FechaInicial OR @FechaInicial IS NULL)
		AND (Fecha <= @FechaFinal OR @FechaFinal IS NULL)
		AND (IdCiudadOrigen = @IdOrigen OR @IdOrigen IS NULL)
		AND (IdCiudadDestino = @IdDestino OR @IdDestino IS NULL)
		AND (FolioEmbarque LIKE '%'+@FolioEmbarque+'%' OR @FolioEmbarque IS NULL)
		ORDER BY Fecha DESC, Hora DESC
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

