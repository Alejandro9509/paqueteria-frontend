
CREATE PROCEDURE [dbo].[usp_CatDepartamentoAgregarPQ](
	@Codigo VARCHAR(3),
	@Descripcion VARCHAR(100),
	@CreadoEl DATETIME,
	@CreadoPor INT,
	@ModificadoEl DATETIME,
	@ModificadoPor INT)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@Codigo, '') = '' begin			
			RAISERROR(N'*INICIO*El código del Departamento es un campo requerido*FIN*', 16, 1);
			return
		end;
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La descripción es un campo requerido*FIN*', 16, 1);
			return 
		end;

		INSERT INTO CatDepartamento(Codigo, Descripcion, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
		VALUES (@Codigo, @Descripcion, @CreadoEl, @CreadoPor,@CreadoEl,@ModificadoPor)


	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

