
CREATE PROCEDURE [dbo].[usp_CatBitacoraAgregarPQ](
	@IdDerecho int,
	@IdUsuario int,
	@FechaBitacora datetime,
	@Referencia varchar(300)
	)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@IdDerecho, '') = '' begin			
			RAISERROR(N'*INICIO*El identificador de la Bitácora es un campo requerido*FIN*', 16, 1);
			return
		end;
		IF ISNULL(@IdUsuario, '') = '' begin
			RAISERROR(N'*INICIO*El identifiacdor del Usuario es un campo requerido*FIN*', 16, 1);
			return 
		end;
		IF ISNULL(@FechaBitacora, '') = '' begin
			RAISERROR(N'*INICIO*La fecha de la Bitácora es un campo requerido*FIN*', 16, 1);
			return 
		end;
		IF ISNULL(@Referencia, '') = '' begin
			RAISERROR(N'*INICIO*La Referencia es un campo requerido*FIN*', 16, 1);
			return 
		end;

		INSERT INTO SisBitacoraPQ(IdDerecho, IdUsuario, FechaBitacora, Referencia)
		VALUES (@IdDerecho, @IdUsuario, @FechaBitacora, @Referencia)


	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

