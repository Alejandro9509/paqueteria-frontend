
CREATE PROCEDURE [dbo].[usp_CatDepartamentoEliminarPQ](
	@IdDepartamento INT)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdDepartamento,0) <= 0 begin
			RAISERROR(N'*INICIO*El Identidicador de Departamento es un campo requerido*FIN*', 16, 1);
			return 
		end;
		DELETE FROM CatDepartamento
		WHERE IdDepartamento = @IdDepartamento
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

