CREATE PROCEDURE [dbo].[usp_ProInformeActualizarViajePQ](	
	@IdViaje int,
	@IdInforme int,
	@IdOPerador int,
	@IdUnidad int
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdInforme, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de informe es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		UPDATE ProInformePQ SET
	
	  IdViaje=@IdViaje, IdUnidad = @IdUnidad, IdOperador = @IdOPerador WHERE IdInforme=@IdInforme
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

