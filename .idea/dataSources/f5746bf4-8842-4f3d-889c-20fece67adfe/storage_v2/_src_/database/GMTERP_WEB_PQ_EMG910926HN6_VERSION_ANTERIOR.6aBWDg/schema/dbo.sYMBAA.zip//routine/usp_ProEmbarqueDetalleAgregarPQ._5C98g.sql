
CREATE PROCEDURE [dbo].[usp_ProEmbarqueDetalleAgregarPQ](
	@IdEmbarque int  ,
	@Tipo int NULL,
	@Descripcion varchar(500) ,
	@Peso float,
	@Largo float,
	@Ancho float,
	@Alto float,
	@Volumen float,
	@IdTipoEmpaque int,
	@ValorDeclarado money,
	@Observaciones varchar(500),
	@Activo bit,
	@Ctd float,
	@IdProducto int
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdEmbarque, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificaodr de Embarque es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Tipo, 0) = 0 begin
			RAISERROR(N'*INICIO*El Tipo es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La descripcion es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		if @Tipo = 2 begin -- 2 es paquete, y estos campos solamente aparecen en paquete
	
			IF ISNULL(@Peso, 0) = 0 begin
				RAISERROR(N'*INICIO*El Peso es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Largo, 0) = 0 begin
				RAISERROR(N'*INICIO*El Largo es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Ancho, 0) = 0 begin
				RAISERROR(N'*INICIO*El Ancho es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Alto, 0) = 0 begin
				RAISERROR(N'*INICIO*El Ancho es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@Volumen, 0) = 0 begin
				RAISERROR(N'*INICIO*El Volumen es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			IF ISNULL(@IdTipoEmpaque, 0) = 0 begin
				RAISERROR(N'*INICIO*El Tipo de Empaque es un campo requerido*FIN*', 16, 1)
				GOTO CANCELAR_TRANSACCION
				return;
			end
			--IF ISNULL(@ValorDeclarado, 0) = 0 begin
				--RAISERROR(N'*INICIO*El Valor declarado es un campo requerido*FIN*', 16, 1)
				--GOTO CANCELAR_TRANSACCION
				--return;
			--end
		end
		
		insert into ProEmbarqueDetallePQ (IdEmbarque,Tipo,Descripcion,Peso,
		Largo,Ancho,Alto,Volumen,IdTipoEmpaque,ValorDeclarado,Observaciones,Activo,ctd, IdProducto)
		values (@IdEmbarque,@Tipo,@Descripcion,@Peso,
		@Largo,@Ancho,@Alto,@Volumen,@IdTipoEmpaque,@ValorDeclarado,@Observaciones,@Activo,@Ctd, @IdProducto);
		
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

