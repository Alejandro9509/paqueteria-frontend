
	CREATE PROCEDURE [dbo].[usp_CatClasificacionViajeModificarPQ](
	@IdClasificacionViaje int,
	@Codigo int,
	@TipoViaje VARCHAR(50),
	@Activo bit,
	@ModificadoEl DATETIME,
	@ModificadoPor INT)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@Codigo, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Codigo es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@TipoViaje, '') = '' begin
			RAISERROR(N'*INICIO*El tipo de viaje es un campo requerido*FIN*', 16, 1);
			return
			end
		IF ISNULL(@Activo , 0) < 0 begin
			RAISERROR(N'*INICIO*El estado del tipo es un campo requerido*FIN*', 16, 1);
			return
			end

			UPDATE CatClasificacionViaje SET
			Codigo = @Codigo,
			TipoViaje = @TipoViaje,
			Activo = @Activo,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor
			WHERE IdClasificacionViaje = @IdClasificacionViaje

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

