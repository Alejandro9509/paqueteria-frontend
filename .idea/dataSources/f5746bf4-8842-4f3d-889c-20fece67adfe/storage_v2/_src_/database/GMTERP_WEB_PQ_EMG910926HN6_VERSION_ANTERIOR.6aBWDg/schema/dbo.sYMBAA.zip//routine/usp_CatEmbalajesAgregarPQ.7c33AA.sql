

	CREATE PROCEDURE [dbo].[usp_CatEmbalajesAgregarPQ](
	@Codigo varchar(10) ,
	@Nombre varchar(30) ,
	@Descripcion varchar(50),
	@CreadoPor int,
	@CreadoEl Datetime,
	@ModificadoPor int,
	@ModificadoEl Datetime)
AS
BEGIN
	
	BEGIN TRANSACTION
--BEGIN TRY
		IF ISNULL(@Codigo, '') = '' begin
			RAISERROR(N'*INICIO*El Código de embalaje es un campo requerido*FIN*', 16, 1);
			return;
		end
		IF ISNULL(@Nombre, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre es un campo requerido*FIN*', 16, 1);
			return;
		end
		
		INSERT INTO CatEmbalajesPQ(
		Codigo,
		Nombre,
		Descripcion,
		CreadoPor,
		CreadoEl,
		ModificadoPor,
		ModificadoEl
		)
		VALUES (
		@Codigo,
		@Nombre,
		@Descripcion,
		@CreadoPor,
		@CreadoEl,
		@ModificadoPor,
		@ModificadoEl)
	
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
    go

