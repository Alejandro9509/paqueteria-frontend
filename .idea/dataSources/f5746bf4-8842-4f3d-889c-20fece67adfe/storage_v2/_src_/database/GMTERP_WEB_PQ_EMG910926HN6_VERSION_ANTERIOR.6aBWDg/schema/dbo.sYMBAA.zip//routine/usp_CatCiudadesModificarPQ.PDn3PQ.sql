
CREATE PROCEDURE [dbo].[usp_CatCiudadesModificarPQ](
	@IdCiudad int,
	@Codigo int,
	@IdEstado int,
	@Ciudad varchar(50),
	@Abreviacion varchar(5),
	@Activo BIT,
	@ModificadoEl datetime,
	@ModificadoPor int)

	AS
BEGIN 
	BEGIN TRANSACTION
		IF ISNULL(@IdCiudad, 0) <= 0 begin
			RAISERROR(N'*INICIO*El id de la ciudad es campo requerido*FIN*', 16, 1);
			return;
		end;
		IF ISNULL(@Codigo, '') = '' begin
			RAISERROR(N'*INICIO*El código de ciudad es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		IF ISNULL(@IdEstado, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Estado es un campo requerido*FIN*', 16, 1);
			return;
		end;
		IF ISNULL(@Ciudad, '') = '' begin
			RAISERROR(N'*INICIO*El nombre de la ciudad es un campo requerido*FIN*', 16, 1);
			return;
		end;
		IF ISNULL(@Abreviacion , '') = '' begin
			RAISERROR(N'*INICIO*La abreviación es un campo requerido*FIN*', 16, 1);
			return;
		end;
		

		UPDATE CatCiudades SET
		Codigo=@Codigo ,
		IdEstado=@IdEstado ,
		Ciudad=@Ciudad ,
		Abreviacion=@Abreviacion ,
		Activo=@Activo ,
		ModificadoEl=@ModificadoEl ,
		ModificadoPor=@ModificadoPor 
		WHERE IdCiudad = @IdCiudad;
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
end
go

