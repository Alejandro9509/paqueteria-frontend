
CREATE PROCEDURE [dbo].[usp_CatClientesGetMaxNumeroClientePQ]
	
	AS BEGIN 
		
		select  max( NumeroCliente ) as NumeroCliente from CatClientes
	
END
go

