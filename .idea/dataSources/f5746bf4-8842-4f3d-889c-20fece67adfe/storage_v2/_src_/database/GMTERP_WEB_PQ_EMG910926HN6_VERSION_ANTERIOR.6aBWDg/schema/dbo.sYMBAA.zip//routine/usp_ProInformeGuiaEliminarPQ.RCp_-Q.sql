CREATE PROCEDURE [dbo].[usp_ProInformeGuiaEliminarPQ]
	@IdInforme INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdInforme,0) <= 0 begin
			RAISERROR(N'Identificador del informe un campo requerido', 16, 1);
			return;
		end;
		
		DELETE FROM ProInformePQ
		WHERE IdInforme = @IdInforme
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END
go

