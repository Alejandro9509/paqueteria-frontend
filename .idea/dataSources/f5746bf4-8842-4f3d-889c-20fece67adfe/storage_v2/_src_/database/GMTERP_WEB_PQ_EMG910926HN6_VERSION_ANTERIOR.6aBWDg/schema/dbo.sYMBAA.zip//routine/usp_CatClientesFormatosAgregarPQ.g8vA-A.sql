
CREATE PROCEDURE [dbo].[usp_CatClientesFormatosAgregarPQ](
	@IdCliente int,
	@IdFormato int,
	@Marcado bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100))
AS
BEGIN
--SET XACT_ABORT ON
--BEGIN TRANSACTION --TEST
----BEGIN TRY       ------------ 
	IF @IdCliente = 0 begin
		RAISERROR(N'*INICIO*El cliente es un campo requerido*FIN*', 16, 1);
		return;
	end;
	IF @IdFormato = 0 begin
		RAISERROR(N'*INICIO*El Formato es un campo requerido*FIN*', 16, 1);		
		return;
	end;
			PRINT N'desde clienteFormatos, abajo id Cliente'
			PRINT @IdCliente
			PRINT N'desde clienteFormatos, abajo id Formato'
			PRINT @IdFormato
	INSERT INTO CatClienteFormatos(IdCliente,IdFormato,Marcado,CreadoPor,CreadoEl)
	VALUES(@IdCliente,@IdFormato,@Marcado,@CreadoPor,@CreadoEl)
	--COMMIT TRANSACTION TEST          -------------------
--END TRY
--BEGIN CATCH
	--IF @@TRANCOUNT > 0 
	--BEGIN
	--COMMIT TRANSACTION
		--ROLLBACK TRANSACTION TEST
		--END
	--EXECUTE usp_GetErrorInfo;
--END CATCH

--IF @@TRANCOUNT > 0
--    BEGIN
--        COMMIT TRANSACTION
--        --RETURN @id_linea_estado_cuenta
--    END
--ELSE
--    BEGIN            
--        GOTO CANCELAR_TRANSACCION
--    END

--CANCELAR_TRANSACCION:
--        IF @@TRANCOUNT > 0
--        BEGIN
--		--EXECUTE usp_GetErrorInfo;
--                ROLLBACK TRANSACTION
--        --RAISERROR('Error al ejecutar el procedimiento',15,1)
--                RETURN -1
--        END
END
go

