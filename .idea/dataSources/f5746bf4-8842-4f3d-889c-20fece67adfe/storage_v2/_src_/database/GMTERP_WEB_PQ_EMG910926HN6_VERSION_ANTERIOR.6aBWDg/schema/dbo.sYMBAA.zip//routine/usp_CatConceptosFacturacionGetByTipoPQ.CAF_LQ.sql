
CREATE PROCEDURE [dbo].[usp_CatConceptosFacturacionGetByTipoPQ](
	@IdTipo int
)
AS
BEGIN
	BEGIN TRANSACTION
		SELECT
		IdTipoConceptoFacturacion,
		(Select Descripcion from CatTiposConceptosFacturacionPQ where IdTipoConceptoFacturacion = cfp.IdTipoConceptoFacturacion) as TipoConcepto,
		IdConceptoFacturacion as IdConceptosFacturacion
		,Codigo
		,ConceptoFacturacion as Concepto
		,Activo
		,IncluirCalculoIngresosLiquidacion as CalculoIngresos
		,IncluirCalculoLiquidacionPorcentajeSobreImpFlete as CalculoFlete
		 ,(select IdCatUnidadMedidaSAT from CatUnidadMedidaSATPQ cs where cs.ClaveUnidad = ClaveSATUnidad COLLATE Modern_Spanish_CS_AS) as IdUnidadMedidaSat
		,ClaveSATProducto as IdProdServSAT
		,UnidadMedida
		,CreadoEl
		,ModificadoEl
		,ModificadoPor
		,CreadoPor
		FROM CatConceptosFacturacionPaqueteriaPQ cfp
		join CatConceptosFacturacion cf on cfp.IdConceptosFacturacion = cf.IdConceptoFacturacion 
		WHERE IdTipoConceptoFacturacion in (@IdTipo)

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

