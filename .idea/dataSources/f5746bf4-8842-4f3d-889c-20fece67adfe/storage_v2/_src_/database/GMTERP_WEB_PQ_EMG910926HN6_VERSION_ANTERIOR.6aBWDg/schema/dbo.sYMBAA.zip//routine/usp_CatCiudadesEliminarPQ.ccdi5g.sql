
CREATE PROCEDURE [dbo].[usp_CatCiudadesEliminarPQ]
	@IdCiudad INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdCiudad,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de la Ciudad es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		DELETE FROM CatCiudades
		WHERE IdCiudad = @IdCiudad
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END


go

