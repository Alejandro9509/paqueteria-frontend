
	CREATE PROCEDURE [dbo].[usp_CatClasificacionViajeAgregarPQ](
	@Codigo int,
	@TipoViaje VARCHAR(50),
	@Activo bit,
	@CreadoEl DATETIME,
	@CreadoPor INT,
	@ModificadoEl DATETIME,
	@ModificadoPor INT)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@Codigo, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Codigo es un campo requerido*FIN*', 16, 1);
			return;
			end
		IF ISNULL(@TipoViaje, '') = '' begin
			RAISERROR(N'*INICIO*El tipo de viaje es un campo requerido*FIN*', 16, 1);
			return
			end
		IF ISNULL(@Activo , 0) < 0 begin
			RAISERROR(N'*INICIO*El estado del tipo es un campo requerido*FIN*', 16, 1);
			return
			end
INSERT INTO CatClasificacionViaje(Codigo, TipoViaje, Activo, CreadoEl, CreadoPor, 
ModificadoEl, ModificadoPor)

VALUES (@Codigo, @TipoViaje, @Activo, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor)

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END

    go

