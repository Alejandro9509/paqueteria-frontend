CREATE PROCEDURE [dbo].[usp_CatCoordenadaModificarPQ](
	@IdCoordenada int,
	@Latitud decimal(12,9),
	@Longitud decimal(12,9),
	@Descripcion varchar(400),
	@Permanente bit)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdCoordenada, 0) <= 0 begin
				RAISERROR(N'*INICIO*El Id de la coordenada es un campo requerido*FIN*', 16, 1)
				return;
			end
		IF ISNULL(@Latitud, 0) = 0 begin
			RAISERROR(N'*INICIO*La Latitud es requerida*FIN*', 16, 1)
						GOTO CANCELAR_TRANSACCION

			return;
		end

		IF ISNULL(@Longitud, 0) = 0 begin
			RAISERROR(N'*INICIO*La Longitud es requerida*FIN*', 16, 1)
						GOTO CANCELAR_TRANSACCION

			return;
		end
			IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La descripcion es requerida*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
			


		
		
UPDATE CatCoordenadasPQ SET Latitud=@Latitud , 
Longitud= @Longitud,
Descripcion=@Descripcion,
Permanente=@Permanente
WHERE IdCoordenada =@IdCoordenada;

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

