
CREATE PROCEDURE [dbo].[usp_ProGuiaActualizarEmbarquePQ](	
	@IdEmbarqueDetalle int
	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @FOLIO int;
		DECLARE @FOLIOSTR varchar(10);		
		EXEC @FOLIO = GenerarSecuenciaPQ @proceso=7;
		--	RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*' ,  -1, 1,@FOLIO )
		
		select @FOLIOSTR = [dbo].[GeneraFolioPQ](7, @FOLIO);
		update ProEmbarqueDetallePQ
		set Guia = @FOLIOSTR
		where IdEmbarqueDetalle = @IdEmbarqueDetalle
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

