
CREATE PROCEDURE [dbo].[usp_ProOrdenCompraDocumentosAgregarXML]
	@IdOrdenCompra INT,
	@dsOrdenCompraDocumentos XML,
	@CreadoPor INT,
	@CreadoEl DATETIME,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Parámetros
@IdOrdenCompra INT,
@dsOrdenCompraDocumentos XML,
@CreadoPor INT,
@CreadoEl DATETIME,
@IdPeticion VARCHAR(100)

Descripción: Procedimiento para guardar los archivos cargados en una orden de compra

Creado por: Jesús Humberto Morales Mojica
Fecha de Creacion: 31/08/2021
Versión 8.0.64.16
Solicitud 4711

Invocada desde: PAGE_ProOrdenesCompraAM
******************************************************************************************************/
AS 
	DECLARE @TemporalXML TABLE (Ruta NVARCHAR(2083), Descripcion NVARCHAR(50), Obs BIT)

BEGIN TRY
	BEGIN TRANSACTION
		
		IF ISNULL(@IdOrdenCompra, 0) = 0
			RAISERROR(N'El Identificador de la orden de compra es un campo requerido', 16, 1)

		INSERT INTO @TemporalXML (Ruta, Descripcion, Obs)
		SELECT 
		  Ruta = Node.Data.value('(ATT_ImagenNombreArchivo)[1]', 'VARCHAR(MAX)')
		, Descripcion = Node.Data.value('(ATT_Descripcion)[1]', 'VARCHAR(MAX)')
		, Obs = Node.Data.value('(ATT_Obs)[1]', 'BIT')
		FROM @dsOrdenCompraDocumentos.nodes('/WEBDEV_TABLE/Imagenes') Node(Data)

		DELETE FROM ProOrdenCompraDocumentos WHERE IdOrdenCompra = @IdOrdenCompra AND IdRequisicionDocumento IS NULL

		INSERT INTO ProOrdenCompraDocumentos (IdOrdenCompra, Ruta, Descripcion, Obs, CreadoPor, CreadoEl)
		SELECT @IdOrdenCompra, Ruta, Descripcion, Obs, @CreadoPor, @CreadoEl FROM @TemporalXML

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

