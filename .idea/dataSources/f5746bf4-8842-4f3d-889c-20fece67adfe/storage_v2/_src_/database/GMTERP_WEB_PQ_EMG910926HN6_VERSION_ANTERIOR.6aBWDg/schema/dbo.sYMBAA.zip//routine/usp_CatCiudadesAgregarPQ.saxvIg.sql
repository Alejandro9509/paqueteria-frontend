
CREATE PROCEDURE [dbo].[usp_CatCiudadesAgregarPQ](
	@Codigo int,
	@IdEstado int,
	@Ciudad varchar(50),
	@Abreviacion varchar(5),
	@Activo BIT,
	@CreadoEl datetime,
	@CreadoPor int ,
	@ModificadoEl datetime,
	@ModificadoPor int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@Codigo, '') = '' begin
			RAISERROR(N'*INICIO*El código de ciudad es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		IF ISNULL(@IdEstado, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Estado es un campo requerido*FIN*', 16, 1);
			return;
		end;
		IF ISNULL(@Ciudad, '') = '' begin
			RAISERROR(N'*INICIO*El nombre de la ciudad es un campo requerido*FIN*', 16, 1);
			return ;
		end;
		IF ISNULL(@Abreviacion , '') = '' begin
			RAISERROR(N'*INICIO*La abreviación es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		
		INSERT INTO CatCiudades(Codigo, IdEstado, Ciudad, Abreviacion, Activo,CreadoEl,CreadoPor,ModificadoEl,ModificadoPor)
		VALUES (@Codigo, @IdEstado, @Ciudad, @Abreviacion, @Activo,@CreadoEl,@CreadoPor,@ModificadoEl,@ModificadoPor)
	
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
end
go

