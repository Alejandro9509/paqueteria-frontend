CREATE PROCEDURE [dbo].[usp_ProSolicitudesViajesAgregar]
	@Consecutivo int,
	@IdCliente int,
	@IdContacto int,
	@FechaHora datetime,
	@Estatus tinyint,
	@Correo varchar(100),
	@Telefono varchar(20),
	@LoadNumber varchar(20),
	@IdOrigen int,
	@IdDestino int,
	@PesoEstimado decimal(15,4),
	@IdUnidadMedida int,
	@FechaHoraCarga datetime,
	@FechaHoraDescarga datetime,
	@SeRecogeraEn varchar(100),
	@SeEntregaraEn varchar(100),
	@Observaciones varchar(512),
	@IdOperador int,
	@IdUnidad int,
	@IdUnidadCarga1 int,
	@IdUnidadDolly int,
	@IdUnidadCarga2 int,
	@CantidadPedida smallint,
	@dsDetalleEquipo ntext,
	@IdPeticion varchar(100)
AS
DECLARE
	@IdSolicitudViaje int,
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION
	
	IF @IdContacto = 0 
		SET @IdContacto = NULL

	IF @IdOperador = 0 
		SET @IdOperador = NULL

	IF @IdUnidad = 0 
		SET @IdUnidad = NULL

	IF @IdUnidadCarga1 = 0 
		SET @IdUnidadCarga1 = NULL

	IF @IdUnidadDolly = 0 
		SET @IdUnidadDolly = NULL

	IF @IdUnidadCarga2 = 0 
		SET @IdUnidadCarga2 = NULL

	IF @Consecutivo = 0
		RAISERROR(N'El numero de solicitud es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Consecutivo FROM ProSolicitudesViajes WHERE Consecutivo = @Consecutivo AND IdCliente=@IdCliente)
		RAISERROR(N'El numero de solicitud ya existe',
			16,
			1
			)
		
	IF @CantidadPedida = 0
		RAISERROR(N'Es necesario seleccionar al menos un equipo',
			16,
			1
			)
				
	IF LTRIM(RTRIM(@SeRecogeraEn)) = ''
		RAISERROR(N'Se recogera en, es un campo requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@SeEntregaraEn)) = ''
		RAISERROR(N'Se entregara en, es un campo requerido',
			16,
			1
			)
	IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)
	IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)
	IF (LTRIM(RTRIM(@FechaHoraCarga)) = '' OR @FechaHoraCarga IS NULL)
		RAISERROR(N'La fecha de carga es un campo requerido',
			16,
			1
			)		
	
	---Insertamos en la tabla ProSolicitudesViajes
	INSERT INTO ProSolicitudesViajes(Consecutivo,IdCliente,IdContacto,FechaHora,Estatus,Correo,Telefono,LoadNumber,
	IdOrigen,IdDestino,PesoEstimado,IdUnidadMedida,FechaHoraCarga,FechaHoraDescarga,SeRecogeraEn,SeEntregaraEn,Observaciones, IdOperador,
	CantidadPedida,IdUnidad, IdUnidadCarga1, IdUnidadDolly, IdUnidadCarga2)
	VALUES(@Consecutivo,@IdCliente,@IdContacto,@FechaHora,@Estatus,@Correo,@Telefono,@LoadNumber,@IdOrigen,@IdDestino,@PesoEstimado,
	@IdUnidadMedida,@FechaHoraCarga,@FechaHoraDescarga,@SeRecogeraEn,@SeEntregaraEn,@Observaciones,@IdOperador,@CantidadPedida,@IdUnidad ,@IdUnidadCarga1, @IdUnidadDolly, @IdUnidadCarga2)
	
	
	SET @IdSolicitudViaje = (SELECT IDENT_CURRENT('ProSolicitudesViajes'))
	
	---Insertamos en la tabla ProSolicitudesViajesDetalleEquipo
	IF @dsDetalleEquipo IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsDetalleEquipo
		
		SELECT ATT_IDTipoEquipo,ATT_CantidadEquipo
		INTO #TempDetalleEquipo
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_DetalleEquipo',2) 
		WITH (ATT_IDTipoEquipo int,ATT_CantidadEquipo smallint)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProSolicitudesViajesDetalleEquipo(IdSolicitudViaje,IdTipoUnidad,CantidadPedida)
		SELECT @IdSolicitudViaje,ATT_IDTipoEquipo,ATT_CantidadEquipo FROM #TempDetalleEquipo WHERE ATT_CantidadEquipo > 0
	END
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

