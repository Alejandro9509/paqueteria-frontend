CREATE PROCEDURE [dbo].[usp_CatGruposProveedoresEliminar]
@IdGrupoProveedor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdGrupoProveedor,0)= 0
		RAISERROR(N'El identificador de grupo de proveedor es un campo requerido',
				16,
				1
				)
/*	IF EXISTS(SELECT TOP 1 * FROM CatProveedores WHERE IdGrupoProveedor = @IdGrupoProveedor)
				RAISERROR(N'La categoria tiene pasivos ligados, no es posible eliminarlo',
					16,
					1
					)

*/
		DELETE CatGruposProveedores
		WHERE 	IdGrupoProveedor=@IdGrupoProveedor
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

