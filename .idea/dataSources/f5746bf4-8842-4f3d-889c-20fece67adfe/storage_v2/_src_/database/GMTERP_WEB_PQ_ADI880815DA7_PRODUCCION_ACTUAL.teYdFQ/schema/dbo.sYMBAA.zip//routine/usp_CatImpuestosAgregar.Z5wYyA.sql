CREATE  PROCEDURE [dbo].[usp_CatImpuestosAgregar] 


@Impuesto varchar(50),
@Porcentaje decimal(15,4),
@TipoCalculo tinyint,
@Activo bit, 
@EsImpuestoLocal bit,
@CreadoEl datetime,
@CreadoPor int,
@NombreXML Varchar(10), 
@IdPeticion varchar(100)

	
AS 
declare @EsImpuestoFederal bit
declare @IdImpuesto int
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Impuesto,0)= ''
		RAISERROR(N'La Tarifa es un campo requerido',
			16,
			1
			)
						
	IF ISNULL(@Porcentaje,0)= 0
		RAISERROR(N'KMs es un campo requerido',
			16,
			1
			)

	IF @EsImpuestoLocal =1
      SET  @EsImpuestoFederal = 0
	ELSE 
	  SET @EsImpuestoFederal=  1

	  
	  SET @IdImpuesto = (SELECT ISNULL(MAX(IdImpuesto),0)+1 FROM CatImpuestos)

	INSERT INTO CatImpuestos(IdImpuesto,Impuesto,Porcentaje,TipoCalculo,Activo,EsImpuestoLocal,EsImpuestoFederal,CreadoEl,CreadoPor,DefinidoPorSistema,NombreImpuestoXML)
	VALUES(@IdImpuesto,@Impuesto,@Porcentaje,@TipoCalculo,@Activo,@EsImpuestoLocal,@EsImpuestoFederal,@CreadoEl,@CreadoPor,0,@NombreXML) 
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

