	CREATE PROCEDURE [dbo].[usp_SisCPAgregarPQ](
	@CP VARCHAR(400), @IdCiudad int,@IdEstado int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdCiudad, 0) <= 0 begin
			RAISERROR(N'El Identificador de ciudad es un campo requerido', 16, 1);
			return;
			end
		IF ISNULL(@IdEstado, 0) <= 0 begin
			RAISERROR(N'El Identificador de estado es un campo requerido', 16, 1); 
			return;
			end
		IF ISNULL(@CP, '') = '' begin
			RAISERROR(N'El CP es un campo requerido', 16, 1) 
			return
			end
		INSERT INTO CatCodigosPostalesPQ(
		CodigoPostal, IdEstado, IdCiudad 
		)
		VALUES (
		@CP,
		@IdEstado,
		@IdCiudad
		)

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
    go

