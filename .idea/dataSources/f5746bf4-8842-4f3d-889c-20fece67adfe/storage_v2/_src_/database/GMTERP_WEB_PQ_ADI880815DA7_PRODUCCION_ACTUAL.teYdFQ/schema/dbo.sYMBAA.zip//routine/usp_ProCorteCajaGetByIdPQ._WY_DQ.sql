CREATE PROCEDURE [dbo].[usp_ProCorteCajaGetByIdPQ](
@IdCorte int
)
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT 
		[IdCorte]
      ,[IdSucursal]
      ,[FechaRegistro]
      ,[HoraRegistro]
      ,[IdDestino]
      ,[IdTipoMoneda]
      ,[IdTipoPago]
      ,[Total]
      ,[IdEstatusCorte]
	  ,(Select Descripcion from CatEstatusCortePQ e WHERE e.IdEstatusCorte = c.IdEstatusCorte) as EstatusCorte
	  ,IdUsuario
	  ,(select Usuario from CatUsuariosPQ u where u.IdUsuario = c.IdUsuario) as Usuario
		FROM ProCorteCajaPQ c WHERE IdCorte = @IdCorte
		/*join ProCorteCajaGuiasPQ cg on c.IdCorte = cg.IdCorte 
		join ProGuiaPQ g on g.IdGuia = cg.IdGuia*/
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

