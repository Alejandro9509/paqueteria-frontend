-- =============================================
-- Author:		<Author,,Name>
-- ALTER date: <ALTER Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_ProTestPQ]
	@Id int
AS
BEGIN
	

    -- Insert statements for procedure here
	SELECT * from CatProductosPQ
END
go

