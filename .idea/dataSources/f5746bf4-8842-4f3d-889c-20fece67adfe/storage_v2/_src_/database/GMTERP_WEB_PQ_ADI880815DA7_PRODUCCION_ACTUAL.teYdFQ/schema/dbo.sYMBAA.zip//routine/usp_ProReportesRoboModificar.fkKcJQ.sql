CREATE PROCEDURE [dbo].[usp_ProReportesRoboModificar]
	@IdUnidad int,
	@IdViaje int,
	@NombreOperador varchar(100),
	@Licencia varchar (19),
	@Telefonos varchar (26),
	@TipoTractor varchar (26),
	@ModeloTractor varchar (26),
	@ColorTractor varchar (26),
	@SerieTractor varchar (100),
	@MarcaTractor varchar (26),
	@PlacasTractor varchar (20),
	@AnoTractor int,
	@CodigoTractor varchar (26),
	@TipoRemolque varchar (26),
	@ModeloRemolque varchar (26),
	@ColorRemolque varchar (26),
	@SerieRemolque varchar (100),
	@MarcaRemolque varchar (26),
	@PlacasRemolque varchar (20),
	@AnoRemolque int,
	@CodigoRemolque varchar (26),
	@NoCartaPorte varchar (50),
	@DescripcionMercancia varchar (100),
	@DetallesSiniestro varchar (200),
	@Ciudad varchar (26),
	@CarreteraAvenida varchar (60),
	@Kilometro varchar (60),
	@Coordenadas varchar (60),
	@Referencias varchar (100),
	@AutoridadesDependiencia varchar (50),
	@PersonaAtendioReporte varchar (100),
	@NoReporteAutoridades varchar (60),
	@Hora datetime,
	@AutoridadesTelefono varchar (26),
	@Aseguradora varchar (60),
	@NoPoliza varchar (60),
	@NoReporteAseguradora varchar (60),
	@NombreAjustador varchar (100),
	@TelefonoAjustador varchar (26),
	@NombreInformante varchar (100),
	@PuestoInformante varchar (60),
	@TelefonoInformante varchar (26),
	@DatosAdicionales varchar (MAX),
	@FechaHora  datetime,
	@IdPeticion varchar(100),
	@dsProReportesRoboVehiculosInvolucrados ntext,
	@dsProReportesRoboCondicionesOcupantes ntext,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdReportesRobo int,
	@UltimaModificacion datetime 	    	 
AS
DECLARE
	@docHandle int,
	@IdReportesRoboOcupantes int,  
	@ATT_IdReportesRobo int,
	@ATT_Marca Varchar(8000),
	@ATT_Placas Varchar(8000),
	@ATT_Color Varchar(8000),
	@ATT_NombreConductor Varchar(8000),
	@ATT_Ocupantes Varchar(8000),
	@ATT_IdReportesRoboOcupantes Varchar(8000),
	@ATT_Otros Varchar(8000),
	@ATT_NombreHerido Varchar(8000), 
	@ATT_Herido Varchar(8000), 
	@ATT_Comentarios Varchar(8000),
	@IdReportesRoboCondiconesOcupantes int,
	@IdReportesRoboVehiculosInvolucrados int,
	@ATT_Bandera int,
	@ATT_Bandera2 int,
	@ContadorImpresiones int 

BEGIN TRY
	BEGIN TRANSACTION
		IF LTRIM(RTRIM(@IdUnidad)) = ''
			RAISERROR(N'El IdUnidad es un campo requerido',
			16,
			1
			)
		IF (SELECT ModificadoEl FROM ProReportesRobo WHERE IdReportesRobo = @IdReportesRobo) <> @UltimaModificacion
			RAISERROR(N'Los datos de este Reporte fueron modificados por otro usuario. Salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)	

		SET @ContadorImpresiones = (SELECT ContadorImpresiones FROM ProReportesRobo WHERE IdReportesRobo = @IdReportesRobo) 

		IF (@ContadorImpresiones <> 0 ) 
			RAISERROR(N'No se puede Modificar el reporte porque el documento ya fue impreso.',
			16,
			1
			)			

		IF @IdViaje = 0 
			SET @IdViaje = NULL  

		UPDATE ProReportesRobo SET 
		IdViaje = @IdViaje,
		NombreOperador = @NombreOperador,
		Licencia = @Licencia,
		Telefonos = @Telefonos,
		TipoTractor = @TipoTractor,
		ModeloTractor = @ModeloTractor,
		ColorTractor = @ColorTractor,
		SerieTractor = @SerieTractor,
		MarcaTractor = @MarcaTractor,
		PlacasTractor= @PlacasTractor,
		AnoTractor = @AnoTractor,
		CodigoTractor = @CodigoTractor,
		TipoRemolque = @TipoRemolque,
		ModeloRemolque = @ModeloRemolque,
		ColorRemolque = @ColorRemolque,
		SerieRemolque = @SerieRemolque,
		MarcaRemolque = @MarcaRemolque,
		PlacasRemolque = @PlacasRemolque,
		AnoRemolque = @AnoRemolque,
		CodigoRemolque = @CodigoRemolque,
		NoCartaPorte = @NoCartaPorte,
		DescripcionMercancia = @DescripcionMercancia,
		DetallesSiniestro = @DetallesSiniestro,
		Ciudad = @Ciudad,
		CarreteraAvenida = @CarreteraAvenida,
		Kilometro = @Kilometro,
		Coordenadas = @Coordenadas,
		Referencias = @Referencias,
		AutoridadesDependiencia = @AutoridadesDependiencia,
		PersonaAtendioReporte = @PersonaAtendioReporte,
		NoReporteAutoridades = @NoReporteAutoridades,
		Hora = @Hora,
		AutoridadesTelefono = @AutoridadesTelefono,
		Aseguradora = @Aseguradora,
		NoPoliza = @NoPoliza,
		NoReporteAseguradora = @NoReporteAseguradora,
		NombreAjustador = @NombreAjustador,
		TelefonoAjustador = @TelefonoAjustador,
		NombreInformante = @NombreInformante,
		PuestoInformante = @PuestoInformante,
		TelefonoInformante = @TelefonoInformante,
		DatosAdicionales = @DatosAdicionales,
		FechaHora = @FechaHora,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl
		WHERE IdReportesRobo = @IdReportesRobo   
		
		--SECCION PARA ProReportesRoboVehiculosInvolucrados

		IF @dsProReportesRoboVehiculosInvolucrados IS NOT NULL 
		BEGIN 
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProReportesRoboVehiculosInvolucrados
	
			SELECT ATT_Marca,ATT_Placas,ATT_Color,ATT_NombreConductor,ATT_Ocupantes, ATT_Otros,ATT_IdReportesRobo,ATT_Bandera
				INTO #TempReportesRobo
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProReportesRobo',2) 
				WITH (ATT_Marca varchar(25),ATT_Placas varchar(25),ATT_Color varchar(25),ATT_NombreConductor varchar(25),ATT_Ocupantes int ,ATT_Otros varchar(25),ATT_IdReportesRobo int,ATT_Bandera int)	
			EXEC sp_xml_removedocument @docHandle
	
			DECLARE CursorReportesRobo CURSOR FOR
			SELECT * FROM #TempReportesRobo 
	
			OPEN CursorReportesRobo
			FETCH NEXT FROM CursorReportesRobo
			INTO @ATT_Marca,@ATT_Placas,@ATT_Color,@ATT_NombreConductor,@ATT_Ocupantes,@ATT_Otros,@ATT_IdReportesRobo,@ATT_Bandera

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @ATT_IdReportesRobo = 0
				BEGIN
					INSERT INTO ProReportesRoboVehiculosInvolucrados(IdReportesRobo,MarcaVehiculo,Placas,Color,NombreConductor,Ocupantes,Otros,ModificadoEl,ModificadoPor,CreadoEl,CreadoPor)
					VALUES(@IdReportesRobo,@ATT_Marca,@ATT_Placas,@ATT_Color,@ATT_NombreConductor,@ATT_Ocupantes,@ATT_Otros, @ModificadoEl,@ModificadoPor,@ModificadoEl,@ModificadoPor)		
				END
				ELSE
				BEGIN
					UPDATE ProReportesRoboVehiculosInvolucrados
					SET ModificadoEl = @ModificadoEl,
						ModificadoPor = @ModificadoPor,
						MarcaVehiculo = @ATT_Marca,
						Placas = @ATT_Placas,
						Color = @ATT_Color,
						NombreConductor = @ATT_NombreConductor,
						Ocupantes = @ATT_Ocupantes,
						Otros = @ATT_Otros 
					WHERE IdReportesRoboVehiculosInvolucrados = @ATT_Bandera
				END
				
		
				FETCH NEXT FROM CursorReportesRobo
				INTO @ATT_Marca,@ATT_Placas,@ATT_Color,@ATT_NombreConductor,@ATT_Ocupantes,@ATT_Otros,@ATT_IdReportesRobo,@ATT_Bandera
			END
			DELETE FROM ProReportesRoboVehiculosInvolucrados WHERE IdReportesRobo = @IdReportesRobo AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND isnull(CreadoEl,0) <> @ModificadoEl
		END 	

		--Seleccion para ProReportesRoboCondicionesOcupantes

		IF @dsProReportesRoboCondicionesOcupantes IS NOT NULL 
		BEGIN

			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProReportesRoboCondicionesOcupantes
	
			SELECT ATT_NombreHerido,ATT_Herido,ATT_Comentarios,ATT_IdReportesRoboOcupantes,ATT_Bandera2    
			INTO #TempProReportesRoboCondiciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CondicionesOcupantes',2) 
			WITH (ATT_NombreHerido varchar(25),ATT_Herido varchar(25),ATT_Comentarios varchar(25),ATT_IdReportesRoboOcupantes int,ATT_Bandera2 int)
			
			EXEC sp_xml_removedocument @docHandle
	
	
			DECLARE CursorReportesRoboOcupantes CURSOR FOR
			SELECT * FROM #TempProReportesRoboCondiciones   
	
			OPEN CursorReportesRoboOcupantes
			FETCH NEXT FROM CursorReportesRoboOcupantes
			INTO @ATT_NombreHerido,@ATT_Herido,@ATT_Comentarios,@ATT_IdReportesRoboOcupantes,@ATT_Bandera2  

			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @ATT_IdReportesRoboOcupantes = 0
				BEGIN
					INSERT INTO ProReportesRoboCondicionesOcupantes(IdReportesRobo,NombreOcupante,Herido,Comentarios,ModificadoEl,ModificadoPor)
					VALUES(@IdReportesRobo,@ATT_NombreHerido,@ATT_Herido,@ATT_Comentarios, @ModificadoEl,@ModificadoPor)		
				END
				ELSE
				BEGIN
					UPDATE ProReportesRoboCondicionesOcupantes
					SET ModificadoEl = @ModificadoEl,
						ModificadoPor = @ModificadoPor,
						NombreOcupante = @ATT_NombreHerido,
						Herido = @ATT_Herido,
						Comentarios = @ATT_Comentarios	
					WHERE IdReportesRoboCondicionesOcupantes = @ATT_Bandera2
				END		
		
				FETCH NEXT FROM CursorReportesRoboOcupantes
				INTO @ATT_NombreHerido,@ATT_Herido,@ATT_Comentarios,@ATT_IdReportesRoboOcupantes,@ATT_Bandera2 
				END
				DELETE FROM ProReportesRoboCondicionesOcupantes WHERE IdReportesRobo = @IdReportesRobo AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND isnull(CreadoEl,0) <> @ModificadoEl
			END 
	COMMIT

END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

