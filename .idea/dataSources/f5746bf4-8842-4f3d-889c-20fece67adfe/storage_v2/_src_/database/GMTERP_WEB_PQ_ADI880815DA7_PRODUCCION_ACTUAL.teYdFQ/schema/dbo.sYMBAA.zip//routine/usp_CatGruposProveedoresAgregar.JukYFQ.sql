CREATE PROCEDURE [dbo].[usp_CatGruposProveedoresAgregar]
@Codigo	int,	
@Grupo varchar(50),	
@CreadoEl	datetime,	
@CreadoPor	int,	
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de grupo de proveedor es un campo requerido',
			16,
			1
			)
	IF ISNULL(@Grupo,'')= ''
		RAISERROR(N'Descripción de grupo es un campo requerido',
			16,
			1
			)
	INSERT INTO CatGruposProveedores(Codigo,Grupo,CreadoEl,CreadoPor)
	VALUES(@Codigo,@Grupo,@CreadoEl,@CreadoPor)
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

