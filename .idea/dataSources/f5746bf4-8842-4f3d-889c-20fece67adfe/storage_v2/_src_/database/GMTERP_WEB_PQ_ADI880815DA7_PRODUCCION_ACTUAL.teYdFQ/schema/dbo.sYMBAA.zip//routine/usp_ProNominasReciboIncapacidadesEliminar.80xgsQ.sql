CREATE PROCEDURE [dbo].[usp_ProNominasReciboIncapacidadesEliminar]
@IdProNominaReciboIncapacidades int,
@IdPeticion varchar(100),
@IdEmpleado int,
@IdPeriodo int	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdProNominaReciboIncapacidades,0)= 0
	RAISERROR(N'La incapacidad es un campo requerido',
			16,
			1
			)
			
		DELETE ProNominasReciboIncapacidades WHERE IdProNominaReciboIncapacidades = @IdProNominaReciboIncapacidades

		UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

