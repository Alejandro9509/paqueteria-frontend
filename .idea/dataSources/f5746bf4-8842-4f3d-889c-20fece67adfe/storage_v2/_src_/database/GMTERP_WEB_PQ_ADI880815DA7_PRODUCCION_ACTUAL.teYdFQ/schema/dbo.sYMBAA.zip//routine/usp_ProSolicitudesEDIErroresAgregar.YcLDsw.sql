
CREATE PROCEDURE [dbo].[usp_ProSolicitudesEDIErroresAgregar]
@FechaHora	datetime,
@Descripcion varchar(100),
@CarrierPro	varchar(30),	
@Referencia	varchar(50),
@ArchivoXMLISA ntext,
@CreadoEl datetime,
@IdPeticion varchar(100)      
AS
DECLARE 
	@IdSolicitudEDI int
BEGIN TRY
    BEGIN TRANSACTION
		
		SET @IdSolicitudEDI = (SELECT TOP 1 IdSolicitudEDI FROM ProSolicitudesEDI WHERE IdentSolicitud=@Referencia)
		
		IF ISNULL(@IdSolicitudEDI,0) = 0
		RAISERROR(N'No se encontró la solicitud perteneciente al Number Carrier enviado',
			16,
			1
			)
		
		INSERT INTO	ProSolicitudesEDIErrores(IdSolicitudEDI,CarrierPro,FechaHora,Descripcion,Referencia,ArchivoXMLISA,CreadoEl)
		VALUES(@IdSolicitudEDI,@CarrierPro,@FechaHora,@Descripcion,@Referencia,@ArchivoXMLISA,@CreadoEl)
		
		--SET @IdSolicitudEDI = (SELECT IDENT_CURRENT('ProSolicitudesEDI'))
		
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

