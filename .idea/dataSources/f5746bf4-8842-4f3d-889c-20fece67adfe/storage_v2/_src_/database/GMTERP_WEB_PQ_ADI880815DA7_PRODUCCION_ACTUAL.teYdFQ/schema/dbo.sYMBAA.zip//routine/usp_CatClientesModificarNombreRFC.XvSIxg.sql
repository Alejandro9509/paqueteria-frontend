CREATE PROCEDURE [dbo].[usp_CatClientesModificarNombreRFC]
	@IdCliente int,
	@RFC varchar(13),
	@NombreFiscal varchar(150),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	IF @IdCliente = 0
		RAISERROR(N'El identificador del cliente es un campo requerido',
			16,
			1
			)
			
	IF NOT EXISTS(SELECT IdCliente FROM CatClientes WHERE IdCliente = @IdCliente)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)	

	IF (SELECT ModificadoEl FROM CatClientes WHERE IdCliente = @IdCliente) <> @UltimaModificacion
		RAISERROR(N'Los datos de este cliente fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)					

			
	IF LTRIM(RTRIM(@RFC)) = ''
		RAISERROR(N'El RFC es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@NombreFiscal)) = ''
		RAISERROR(N'El nombre es un campo requerido',
			16,
			1
			)


	UPDATE CatClientes SET
		RFC = @RFC,
		NombreFiscal = @NombreFiscal,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl
    WHERE IdCliente = @IdCliente



    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
        UPDATE CatCuentasContables SET
        Nombre = @NombreFiscal
        WHERE CatalogoLigado = 'CatClientes' AND IdCatalogoLigado = @IdCliente
    END
    		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

