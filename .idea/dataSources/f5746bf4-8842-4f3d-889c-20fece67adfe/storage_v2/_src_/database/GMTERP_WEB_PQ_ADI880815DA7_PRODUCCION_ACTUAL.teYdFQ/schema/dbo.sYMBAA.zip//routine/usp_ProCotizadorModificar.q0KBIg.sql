CREATE PROCEDURE [dbo].[usp_ProCotizadorModificar]
	@IdCotizacion INT,
	@ModificadoEl DATETIME,
	@ModificadoPor INT,
	@Folio VARCHAR(100),
	@Revision INT,
	@IdCliente INT,
	@IdSubCliente INT,
	@IdClienteContacto INT,
	@IdMoneda VARCHAR(50),
	@IdOrigen INT,
	@IdDestino INT,
	@Fecha DATETIME,
	@TipoCambio FLOAT,
	@dsCatRutasCompuestas NTEXT,
	@IdPeticion VARCHAR(100),
	@TipoCotizacion tinyint = NULL
AS

/* *************************************************************************************************

Descripción: El procedimiento Modifica un registro de Cotizacion con toda la informacion de las ruta compuesta y los valores de la cotizacion.

Implementada por: N/A
Fecha de implementacion: N/A
Versión ERP: N/A

Modificada por:  Raymundo Espinoza Garcia
Fecha de mofidicacion: 13/09/2019
Versión ERP:  8.0.46.05

Modificada por:  Raymundo Espinoza Garcia
Fecha de mofidicacion: 09/01/2020
Versión ERP:  Versión 8.0.48.67
--se agregaron los campos descripcion y especializado en el usp_CatPadronDeRutaCompuestaAgregar

Modificada por:  Adrian Varela Morales
Fecha de mofidicacion: 18/03/2020
Versión ERP:  Versión 8.0.51.09
Solicitud 1225
--Se agregan campos para guardar valores originales que afectan al calculo de liquidacion

Modificada por: Ricardo Sinai Miranda Pantoja
Fecha de mofidicación: 02/06/2020
Versión ERP: Versión 8.0.52.42
Solicitud: 2,302
-- Se aegragron validaciones para realizar las actualizaciones de la tabla Cotización en Cotizaciones y Cotizaciones por Trazo.

Invocada desde: PAGE_ProCotizadorGenerar(SOLICITUD 218)
***************************************************************************************************** */


DECLARE
	@RevisionAumento INT,
	@AgregoValorHistorico BIT,
	@IdCotizacionRutaTemp INT,
	@IdCotizacionRutaCargoAdicionalTemp INT,
	@docHandle INT,
	@COL_IdRutaCompuesta INT,
	@COL_Consecutivo INT,
	@COL_Concepto VARCHAR(100),
	@COL_IncDec FLOAT,
	@COL_PrecioNeto MONEY,
	@COL_CargosAdicionales MONEY,
	@COL_CargosAdicionalesDlls MONEY,
	@COL_TotalFlete MONEY,
	@COL_XMLCargosAdicionales VARCHAR(8000),
	@COL_Grupo BIT,
	@COL_Consolidar BIT,
	@COL_FolioConsolidar INT,
	@ATT_IdConceptoFacturacion INT, 
	@ATT_CodigoConceptoFacturacion INT, 
	@ATT_ConceptoFacturacion VARCHAR(100),
	@ATT_Cantidad FLOAT, 
	@ATT_PrecioUnitario MONEY, 
	@ATT_Importe MONEY,
	@valores nvarchar(255),
	@COL_XMLTrazos Varchar(8000),
	@COL_XMLGastosAutorizados Varchar(8000),
	@ATT_IdFactorTipoUnidad int,
	@RC int,
	@IdCatPadronDeRutaCompuesta int,
	@ATT_IdClasificacion int,
	@ATT_IdTipoViaje int,
	@ATT_Trazo Varchar(8000),
	@ATT_IdOrigen int,
	@ATT_IdDestino int,
	@ATT_KilometroTotalRuta decimal(15,6),
	@ATT_TiempoEnTransito decimal(15,6),
	@ATT_TotalCasetas money,
	@ATT_CostoRutaCP money,
	@ATT_PrecioFleteSP money,
	@ATT_IdTipoServicio int,
	@IdRutaCotizacion int,
	@COL_XMLCasetas  varchar(8000),
	@COL_FleteMN MONEY,
	@COL_FleteDLLS MONEY,
	@COL_xCostoDobleOP money,
	@COL_xEspecializado money,
	@COL_xPrecioKilometroNeto money,
	@COL_xPrecioSugerido money,
	@COL_xCostoKilometro money,
	@COL_Precio_Sugerido money,
	@COL_KMTotalRuta money,
	@COL_Autopistas money,
	@COL_UtilidadRuta money,
	@COL_Especializado money,
	@COL_Posicionamiento money,
	@COL_Precio_doble_op money,
	@COL_FleteMnOriginal money,
	@COL_xAutopistas money,
	@COL_xPosicionamiento money
BEGIN TRY
	BEGIN TRANSACTION Principal

		if isnull(@TipoCotizacion,0) = 0 -- si no trae tipo de cotizacion, se identificara como que se captura desde la forma de cotizacion que se hizo por primera ves
			SET @TipoCotizacion = 1      -- sino seta la cotizacion por Trazo.

		IF ISNULL(@IdCliente, 0) = 0
			RAISERROR(N'El Id del cliente es un campo requerido', 16, 1)
 /* //SOLICITUD 291, el campo subcliente no es obligatorio
		IF ISNULL(@IdSubCliente, 0) = 0
			RAISERROR(N'El Id del Subcliente es un campo requerido', 16, 1)
*/
		IF ISNULL(@IdClienteContacto, 0) = 0
			RAISERROR(N'El IdClienteContacto es un campo requerido', 16, 1)
		IF ISNULL(@IdMoneda,0)=0
			RAISERROR(N'El IdMoneda es un campo requerido', 16, 1)	
		IF @TipoCotizacion = 1
		begin
			IF ISNULL(@IdOrigen,0)=0
				RAISERROR(N'El IdOrigen es un campo requerido', 16, 1) 
			IF ISNULL(@IdDestino,0)=0
				RAISERROR(N'El IdOrigen es un campo requerido', 16, 1)			   
		end
		IF ISDATE(@Fecha) = 0
			RAISERROR(N'La fecha/hora de la Cotizacion es un campo requerido', 16, 1)
		IF @TipoCotizacion = 2
		begin		
			SET @IdOrigen = NULL
			SET @IdDestino = NULL
		end
		-- Verificar que la cotizacion no haya sido modificada o aceptada
		IF (SELECT COUNT(Estatus) from ProCotizaciones WHERE IdCotizacion = @IdCotizacion and Estatus = 1) = 0
		      RAISERROR(N'La Cotizacion ya fue Aceptada o Rechazada', 16, 1) 	

		--Se ejecuta el procedimiento para agregar un valor historico
		--Este regresa un BIT para saber si hacer un update de la cotizacion
		EXEC usp_ProCotizadorAgregarValorHistorico @IdCotizacion, @IdCliente, @IdSubCliente, @IdClienteContacto, @IdMoneda, 
		@IdOrigen, @IdDestino, @Fecha, @ModificadoEl, @ModificadoPor, @TipoCambio, @dsCatRutasCompuestas, @IdPeticion, @AgregoValorHistorico OUTPUT

		IF @AgregoValorHistorico = 1
			--BEGIN TRANSACTION Principal
			BEGIN
				SET @RevisionAumento = @Revision + 1

				UPDATE ProCotizaciones SET Revision = @RevisionAumento, Fecha = @Fecha, IdCliente = @IdCliente, IdSubCliente = @IdSubCliente,
				IdClienteContacto = @IdClienteContacto, IdMoneda = @IdMoneda, IdOrigen = @IdOrigen, IdDestino = @IdDestino, Folio = @Folio,
				TipoCambio = @TipoCambio, ModificadoEl = @ModificadoEl, ModificadoPor = @ModificadoPor
				WHERE IdCotizacion = @IdCotizacion
				
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasCompuestas

				IF object_id('#TempCatRutasCompuestas') > 0
					BEGIN
						DROP TABLE #TempCatRutasCompuestas
					END

				SELECT COL_IdRutaCompuesta, COL_Consecutivo, COL_Concepto, COL_IncDec, COL_PrecioNeto,
				COL_CargosAdicionales, COL_CargosAdicionalesDlls, COL_TotalFlete, COL_XMLCargosAdicionales, COL_Grupo, COL_Consolidar, COL_FolioConsolidar,
				COL_FleteMN,COL_FleteDLLS,COL_Precio_Sugerido,
				COL_KMTotalRuta,
				COL_Autopistas,
				COL_UtilidadRuta,
				COL_Especializado,
				COL_Posicionamiento,
				COL_Precio_doble_op,
				COL_FleteMnOriginal,
				COL_AutopistasX,
				COL_PosicionamientoX,
				COL_CostoDobleOPX,
				COL_EspecializadoX,
				COL_PrecioKilometroNetoX,
				COL_PrecioSugeridoX,
				COL_CostoKilometroX,
				COL_XMLTrazos,COL_XMLGastosAutorizados,COL_XMLCasetas
				INTO #TempCatRutasCompuestas FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_Cotizacion',2) 
				WITH (COL_IdRutaCompuesta float, COL_Consecutivo int, COL_Concepto varchar(100), COL_IncDec float,
				COL_PrecioNeto money, COL_CargosAdicionales money, COL_CargosAdicionalesDlls money, COL_TotalFlete money,
				COL_XMLCargosAdicionales varchar(8000), COL_Grupo BIT, COL_Consolidar BIT, COL_FolioConsolidar INT,
				COL_FleteMN money,COL_FleteDLLS MONEY,COL_Precio_Sugerido money,
				COL_KMTotalRuta money,
				COL_Autopistas money,
				COL_UtilidadRuta money,
				COL_Especializado money,
				COL_Posicionamiento money,
				COL_Precio_doble_op money,
				COL_FleteMnOriginal money,
				COL_AutopistasX money,
				COL_PosicionamientoX money,
				COL_CostoDobleOPX money,
				COL_EspecializadoX money,
				COL_PrecioKilometroNetoX money,
				COL_PrecioSugeridoX money,
				COL_CostoKilometroX money,
				COL_XMLTrazos Varchar(8000),COL_XMLGastosAutorizados Varchar(8000),COL_XMLCasetas  Varchar(8000))

				DECLARE CursorCatRutasCompuestas CURSOR FOR SELECT * FROM #TempCatRutasCompuestas

				OPEN CursorCatRutasCompuestas FETCH NEXT FROM CursorCatRutasCompuestas
				INTO @COL_IdRutaCompuesta, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, 
				@COL_CargosAdicionales, @COL_CargosAdicionalesDlls, @COL_TotalFlete, @COL_XMLCargosAdicionales, @COL_Grupo, @COL_Consolidar,@COL_FolioConsolidar,
				@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xAutopistas,
				@COL_xPosicionamiento,
				@COL_xCostoDobleOP,
				@COL_xEspecializado,
				@COL_xPrecioKilometroNeto,
				@COL_xPrecioSugerido,
				@COL_xCostoKilometro,
				@COL_XMLTrazos,@COL_XMLGastosAutorizados,@COL_XMLCasetas
				WHILE @@FETCH_STATUS = 0

				BEGIN
					IF EXISTS (SELECT IdCotizacionRuta FROM ProCotizacionesRutas WHERE IdRutaCompuesta = @COL_IdRutaCompuesta AND IdCotizacion = @IdCotizacion and Consecutivo = @COL_Consecutivo)
						BEGIN
							SET @IdCotizacionRutaTemp =  (SELECT IdCotizacionRuta FROM ProCotizacionesRutas WHERE IdRutaCompuesta = @COL_IdRutaCompuesta AND IdCotizacion = @IdCotizacion and Consecutivo = @COL_Consecutivo)
							IF EXISTS (SELECT IdCotizacionRuta FROM ProCotizacionesRutas WHERE IdRutaCompuesta = @COL_IdRutaCompuesta AND IdCotizacion = @IdCotizacion and Consecutivo = @COL_Consecutivo AND ( Concepto <> @COL_Concepto OR
							IncDec <> @COL_IncDec OR PrecioNeto <> @COL_PrecioNeto OR CargosAdicionales <> @COL_CargosAdicionales OR CargosAdicionalesDlls <> @COL_CargosAdicionalesDlls OR
							TotalFlete <> @COL_TotalFlete OR Consolidar <> @COL_Consolidar OR FolioConsolidar <> @COL_FolioConsolidar OR FleteMN <> @COL_FleteMN OR 
							FleteDLLS <> @COL_FleteDLLS OR Grupo <> @COL_Grupo))
							    BEGIN

								UPDATE ProCotizacionesRutas SET Consecutivo = @COL_Consecutivo, Concepto = @COL_Concepto, IncDec = @COL_IncDec, PrecioNeto = @COL_PrecioNeto, 
								CargosAdicionales = @COL_CargosAdicionales, CargosAdicionalesDlls = @COL_CargosAdicionalesDlls, TotalFlete = @COL_TotalFlete, Revision = @RevisionAumento, 
								Consolidar = @COL_Consolidar, FolioConsolidar = @COL_FolioConsolidar, FleteMN = @COL_FleteMN, FleteDLLS = @COL_FleteDLLS ,
								PrecioSugerido = @COL_Precio_Sugerido,
								KMTotalRuta = @COL_KMTotalRuta,
								TotalCasetas = @COL_Autopistas,
								UtilidadRuta = @COL_UtilidadRuta,
								Especializado = @COL_Especializado,
								Posicionamiento = @COL_Posicionamiento,
								CostoDobleOP = @COL_Precio_doble_op,
								FleteMnOriginal = @COL_FleteMnOriginal,
								AuxAutopistas = @COL_xAutopistas,
								AuxPosicionamiento = @COL_xPosicionamiento,
								AuxCostoDobleOP = @COL_xCostoDobleOP,
								AuxEspecializado = @COL_xEspecializado,
								AuxPrecioNeto = @COL_xPrecioKilometroNeto,
								AuxPrecioSugerido = @COL_xPrecioSugerido,
								AuxCostoKilometro = @COL_xCostoKilometro,
								Grupo = @COL_Grupo
								WHERE IdCotizacionRuta = @IdCotizacionRutaTemp	and Consecutivo = @COL_Consecutivo

								END

							ELSE
								UPDATE ProCotizacionesRutas SET Revision = @RevisionAumento WHERE IdCotizacionRuta = @IdCotizacionRutaTemp and Consecutivo = @COL_Consecutivo

							IF @COL_XMLCargosAdicionales <> ''
								BEGIN
									EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLCargosAdicionales

									IF object_id('#TempProCotizacionesRutasCargosAdicionalesTemp1') > 0
									BEGIN
										DROP TABLE #TempProCotizacionesRutasCargosAdicionalesTemp1
									END

									SELECT ATT_IdConceptoFacturacion, ATT_CodigoConceptoFacturacion, ATT_ConceptoFacturacion, 
									ATT_Cantidad, ATT_PrecioUnitario, ATT_Importe
									INTO #TempProCotizacionesRutasCargosAdicionalesTemp1
									FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CargosAdicionales',2) 
									WITH(ATT_IdConceptoFacturacion INT, ATT_CodigoConceptoFacturacion INT, ATT_ConceptoFacturacion VARCHAR(100),
									ATT_Cantidad FLOAT, ATT_PrecioUnitario MONEY, ATT_Importe MONEY)

									EXEC sp_xml_removedocument @docHandle

									DECLARE CursorProCotizacionCargosAdicionalesRuta CURSOR FOR SELECT * FROM #TempProCotizacionesRutasCargosAdicionalesTemp1

									OPEN CursorProCotizacionCargosAdicionalesRuta FETCH NEXT FROM CursorProCotizacionCargosAdicionalesRuta
									INTO @ATT_IdConceptoFacturacion, @ATT_CodigoConceptoFacturacion, @ATT_ConceptoFacturacion, @ATT_Cantidad,
									@ATT_PrecioUnitario, @ATT_Importe
									WHILE @@FETCH_STATUS = 0
									BEGIN
										IF NOT EXISTS (SELECT IdCotizacionRutaCargoAdicional FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @IdCotizacionRutaTemp AND IdConceptoFacturacion = @ATT_IdConceptoFacturacion)
											INSERT INTO ProCotizacionesRutasCargosAdicionales(CreadoEl, CreadoPor, IdCotizacionRuta, IdConceptoFacturacion, Cantidad, PrecioUnitario, Importe, Revision)
											VALUES (@ModificadoEl, @ModificadoPor, @IdCotizacionRutaTemp, @ATT_IdConceptoFacturacion, @ATT_Cantidad, @ATT_PrecioUnitario, @ATT_Importe, @RevisionAumento)
										ELSE
											BEGIN
												SET @IdCotizacionRutaCargoAdicionalTemp =  (SELECT IdCotizacionRutaCargoAdicional FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @IdCotizacionRutaTemp AND IdConceptoFacturacion = @ATT_IdConceptoFacturacion)

												IF EXISTS (SELECT IdCotizacionRutaCargoAdicional FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRutaCargoAdicional = @IdCotizacionRutaCargoAdicionalTemp AND (Cantidad <> @ATT_Cantidad OR PrecioUnitario <> @ATT_PrecioUnitario))
													BEGIN
														UPDATE ProCotizacionesRutasCargosAdicionales SET Revision = @RevisionAumento, Cantidad = @ATT_Cantidad, PrecioUnitario = @ATT_PrecioUnitario, Importe = @ATT_Importe
														WHERE IdCotizacionRutaCargoAdicional = @IdCotizacionRutaCargoAdicionalTemp
													END
												ELSE
													UPDATE ProCotizacionesRutasCargosAdicionales SET Revision = @RevisionAumento WHERE IdCotizacionRutaCargoAdicional = @IdCotizacionRutaCargoAdicionalTemp
											END

										FETCH NEXT FROM CursorProCotizacionCargosAdicionalesRuta
										INTO @ATT_IdConceptoFacturacion, @ATT_CodigoConceptoFacturacion, @ATT_ConceptoFacturacion, @ATT_Cantidad,
										@ATT_PrecioUnitario, @ATT_Importe
									END
									CLOSE CursorProCotizacionCargosAdicionalesRuta
									DEALLOCATE CursorProCotizacionCargosAdicionalesRuta

									DROP TABLE #TempProCotizacionesRutasCargosAdicionalesTemp1
								END
							ELSE
								BEGIN
									IF (SELECT COUNT(*) FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @IdCotizacionRutaTemp) > 0
										DELETE FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @IdCotizacionRutaTemp
								END
						END
					ELSE
						BEGIN
							--RAISERROR('NO EXISTO',16,1)
							--/*AQUI VAN LAS VALIDACIONES*/	
							IF @COL_XMLTrazos <> '' 
							BEGIN	
				
								EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLTrazos
	
								SELECT ATT_IdFactorTipoUnidad,
										ATT_IdClasificacion,
										ATT_IdTipoViaje,
										ATT_Trazo,
										ATT_IdOrigen,
										ATT_IdDestino,
										ATT_KilometroTotalRuta,
										ATT_TiempoEnTransito,
										ATT_TotalCasetas,
										ATT_CostoRutaCP,
										ATT_PrecioFleteSP,
										ATT_IdTipoServicio
								INTO #TempTrazos2
								FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Trazo',2) 
								WITH (ATT_IdFactorTipoUnidad int,
											ATT_IdClasificacion int,
											ATT_IdTipoViaje int,
											ATT_Trazo varchar(8000),
											ATT_IdOrigen int,
											ATT_IdDestino int,
											ATT_KilometroTotalRuta decimal(15,6),
											ATT_TiempoEnTransito decimal(15,6),
											ATT_TotalCasetas money,
											ATT_CostoRutaCP money,
											ATT_PrecioFleteSP money,
											ATT_IdTipoServicio int)

										EXEC sp_xml_removedocument @docHandle

										Declare Trazos_Cursor Cursor For
										Select * from #TempTrazos2
										Open Trazos_Cursor
									Fetch Next From Trazos_Cursor
									Into @ATT_IdFactorTipoUnidad,
										@ATT_IdClasificacion,
										@ATT_IdTipoViaje,
										@ATT_Trazo,
										@ATT_IdOrigen,
										@ATT_IdDestino,
										@ATT_KilometroTotalRuta,
										@ATT_TiempoEnTransito,
										@ATT_TotalCasetas,
										@ATT_CostoRutaCP,
										@ATT_PrecioFleteSP,
										@ATT_IdTipoServicio
									While @@Fetch_Status = 0
									Begin
									 select @ATT_IdFactorTipoUnidad
										EXECUTE @RC = [dbo].[usp_CatPadronDeRutaCompuestaAgregar] 
											   @COL_IdRutaCompuesta
											  ,@ModificadoEl
											  ,@ModificadoPor
											  ,NULL
											  ,NULL
											  ,@ATT_IdFactorTipoUnidad
											  ,@ATT_IdTipoViaje
											  ,@ATT_IdClasificacion
											  ,@ATT_KilometroTotalRuta
											  ,@ATT_TiempoEnTransito
											  ,@ATT_TotalCasetas
											  ,@ATT_CostoRutaCP
											  ,@ATT_PrecioFleteSP
											  ,NULL
											  ,NULL
											  ,@ATT_PrecioFleteSP
											  ,1
											  ,@ATT_IdTipoServicio
											  ,@IdPeticion,1,@ATT_IdOrigen,@ATT_IdDestino,
											  NULL,
											  NULL

											  Fetch Next From Trazos_Cursor
											  Into  @ATT_IdFactorTipoUnidad,
										@ATT_IdClasificacion,
										@ATT_IdTipoViaje,
										@ATT_Trazo,
										@ATT_IdOrigen,
										@ATT_IdDestino,
										@ATT_KilometroTotalRuta,
										@ATT_TiempoEnTransito,
										@ATT_TotalCasetas,
										@ATT_CostoRutaCP,
										@ATT_PrecioFleteSP,
										@ATT_IdTipoServicio
									END
									Close Trazos_Cursor
									Deallocate Trazos_Cursor

								SET @IdCatPadronDeRutaCompuesta = (SELECT IDENT_CURRENT('CatPadronDeRutaCompuesta'))
								drop table #TempTrazos2
							END
							if @TipoCotizacion = 2
							begin
								IF ISNULL(@IdCatPadronDeRutaCompuesta,0) = 0
								BEGIN
									INSERT INTO ProCotizacionesRutas(IdRutaCompuesta, IdCotizacion, Consecutivo, Concepto, IncDec, PrecioNeto, CargosAdicionales, CargosAdicionalesDlls, TotalFlete, Revision, Grupo,Consolidar,FolioConsolidar,RutaTrazo,IdOrigen,IdDestino,CasetasAutorizadas,FleteMN,FleteDLLS,PrecioSugerido,
												KMTotalRuta,
												TotalCasetas,
												UtilidadRuta,
												Especializado,
												Posicionamiento,
												CostoDobleOP,
												FleteMnOriginal,
												AuxAutopistas,
												AuxPosicionamiento,
												AuxCostoDobleOP,
												AuxEspecializado,
												AuxPrecioNeto,
												AuxPrecioSugerido,
												AuxCostoKilometro)
									VALUES(@COL_IdRutaCompuesta, @IdCotizacion, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales, @COL_CargosAdicionalesDlls, @COL_TotalFlete, @RevisionAumento, @COL_Grupo,@COL_Consolidar,@COL_FolioConsolidar,@ATT_Trazo,@ATT_IdOrigen,@ATT_IdDestino,@COL_XMLCasetas,@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,@COL_KMTotalRuta,@COL_Autopistas,
											@COL_UtilidadRuta,
											@COL_Especializado,
											@COL_Posicionamiento,
											@COL_Precio_doble_op,
											@COL_FleteMnOriginal,
											@COL_xAutopistas,
											@COL_xPosicionamiento,
											@COL_xCostoDobleOP,
											@COL_xEspecializado,
											@COL_xPrecioKilometroNeto,
											@COL_xPrecioSugerido,
											@COL_xCostoKilometro)
								END
								ELSE
								BEGIN
									INSERT INTO ProCotizacionesRutas(IdRutaCompuesta, IdCotizacion, Consecutivo, Concepto, IncDec, PrecioNeto, CargosAdicionales, CargosAdicionalesDlls, TotalFlete, Revision, Grupo,Consolidar,FolioConsolidar,RutaTrazo,IdOrigen,IdDestino,CasetasAutorizadas,FleteMN,FleteDLLS,PrecioSugerido,
												KMTotalRuta,
												TotalCasetas,
												UtilidadRuta,
												Especializado,
												Posicionamiento,
												CostoDobleOP,
												FleteMnOriginal,
												AuxAutopistas,
												AuxPosicionamiento,
												AuxCostoDobleOP,
												AuxEspecializado,
												AuxPrecioNeto,
												AuxPrecioSugerido,
												AuxCostoKilometro)
									VALUES(@IdCatPadronDeRutaCompuesta, @IdCotizacion, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales, @COL_CargosAdicionalesDlls, @COL_TotalFlete, @RevisionAumento, @COL_Grupo,@COL_Consolidar,@COL_FolioConsolidar,@ATT_Trazo,@ATT_IdOrigen,@ATT_IdDestino,@COL_XMLCasetas,@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,@COL_KMTotalRuta,@COL_Autopistas,
											@COL_UtilidadRuta,
											@COL_Especializado,
											@COL_Posicionamiento,
											@COL_Precio_doble_op,
											@COL_FleteMnOriginal,
											@COL_xAutopistas,
											@COL_xPosicionamiento,
											@COL_xCostoDobleOP,
											@COL_xEspecializado,
											@COL_xPrecioKilometroNeto,
											@COL_xPrecioSugerido,
											@COL_xCostoKilometro)
								END
								
							end
							else
							begin
								INSERT INTO ProCotizacionesRutas(IdRutaCompuesta, IdCotizacion, Consecutivo, Concepto, IncDec, PrecioNeto, CargosAdicionales, CargosAdicionalesDlls, TotalFlete, Revision, Grupo,Consolidar,FolioConsolidar,RutaTrazo,IdOrigen,IdDestino,FleteMN,FleteDLLS,PrecioSugerido,
												KMTotalRuta,
												TotalCasetas,
												UtilidadRuta,
												Especializado,
												Posicionamiento,
												CostoDobleOP,
												FleteMnOriginal,
												AuxAutopistas,
												AuxPosicionamiento,
												AuxCostoDobleOP,
												AuxEspecializado,
												AuxPrecioNeto,
												AuxPrecioSugerido,
												AuxCostoKilometro)
								VALUES(@COL_IdRutaCompuesta, @IdCotizacion, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales, @COL_CargosAdicionalesDlls, @COL_TotalFlete, @RevisionAumento, @COL_Grupo,@COL_Consolidar,@COL_FolioConsolidar,@ATT_Trazo,@ATT_IdOrigen,@ATT_IdDestino,@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,
										@COL_KMTotalRuta,
										@COL_Autopistas,
										@COL_UtilidadRuta,
										@COL_Especializado,
										@COL_Posicionamiento,
										@COL_Precio_doble_op,
										@COL_FleteMnOriginal,
										@COL_xAutopistas,
										@COL_xPosicionamiento,
										@COL_xCostoDobleOP,
										@COL_xEspecializado,
										@COL_xPrecioKilometroNeto,
										@COL_xPrecioSugerido,
										@COL_xCostoKilometro)
							end
							SET @IdCotizacionRutaTemp = (SELECT IDENT_CURRENT('ProCotizacionesRutas'))

							IF @COL_XMLGastosAutorizados <> ''
							BEGIN
								EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLGastosAutorizados
								SELECT  ATT_TipoGasto,	
										ATT_IdConceptoGastoViaje,
										ATT_Litros,
										ATT_Importe,	
										ATT_Credito

								INTO #TempGastosAutorizados
								FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_GastosAutorizados',2) 
								WITH(ATT_TipoGasto tinyint,	
										ATT_IdConceptoGastoViaje int,
										ATT_Litros decimal(15,6),
										ATT_Importe money,	
										ATT_Credito bit)
			
								EXEC sp_xml_removedocument @docHandle
			
								INSERT INTO ProCotizacionesRutasCompuestasGatosPorTrazo(TipoGasto,	
																						IdConceptoGastoViaje,	
																						Litros,	
																						Importe,	
																						Credito,	
																						CreadoEl,	
																						CreadoPor,	
																						IdRutaCotizacion)
								SELECT ATT_TipoGasto,
										ATT_IdConceptoGastoViaje,
										ATT_Litros,
										ATT_Importe,
										ATT_Credito,
										@ModificadoEl,
										@ModificadoPor,
										@IdCotizacionRutaTemp
								FROM #TempGastosAutorizados
			
								DROP TABLE #TempGastosAutorizados
							END

							IF @COL_XMLCargosAdicionales <> ''
								BEGIN --Se agregan los cargos adicionales a la ruta nueva
									EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLCargosAdicionales

									IF object_id('#TempProCotizacionesRutasCargosAdicionalesTemp2') > 0
									BEGIN
										DROP TABLE #TempProCotizacionesRutasCargosAdicionalesTemp2
									END

									SELECT ATT_IdConceptoFacturacion, ATT_CodigoConceptoFacturacion, ATT_ConceptoFacturacion, ATT_Cantidad, ATT_PrecioUnitario, ATT_Importe
									INTO #TempProCotizacionesRutasCargosAdicionalesTemp2
									FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CargosAdicionales',2) 
									WITH(ATT_IdConceptoFacturacion INT, ATT_CodigoConceptoFacturacion INT, ATT_ConceptoFacturacion VARCHAR(100), ATT_Cantidad FLOAT, 
									ATT_PrecioUnitario MONEY, ATT_Importe MONEY)
			
									EXEC sp_xml_removedocument @docHandle

									INSERT INTO ProCotizacionesRutasCargosAdicionales(CreadoEl, CreadoPor, IdCotizacionRuta, IdConceptoFacturacion, Cantidad, PrecioUnitario, Importe, Revision)
									SELECT @ModificadoEl, @ModificadoPor, @IdCotizacionRutaTemp, ATT_IdConceptoFacturacion, ATT_Cantidad, ATT_PrecioUnitario, ATT_Importe, @RevisionAumento
									FROM #TempProCotizacionesRutasCargosAdicionalesTemp2
			
									DROP TABLE #TempProCotizacionesRutasCargosAdicionalesTemp2
								END
						END

				FETCH NEXT FROM CursorCatRutasCompuestas
				INTO @COL_IdRutaCompuesta, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, 
				@COL_CargosAdicionales, @COL_CargosAdicionalesDlls, @COL_TotalFlete, @COL_XMLCargosAdicionales, @COL_Grupo, @COL_Consolidar, @COL_FolioConsolidar,
				@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xAutopistas,
				@COL_xPosicionamiento,
				@COL_xCostoDobleOP,
				@COL_xEspecializado,
				@COL_xPrecioKilometroNeto,
				@COL_xPrecioSugerido,
				@COL_xCostoKilometro,
				@COL_XMLTrazos,@COL_XMLGastosAutorizados,@COL_XMLCasetas
				
				END

				CLOSE CursorCatRutasCompuestas
				DEALLOCATE CursorCatRutasCompuestas

				DROP TABLE #TempCatRutasCompuestas

				--Se elimina los cargos adicionales que pertenecen a la revision anterior
				DELETE FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRutaCargoAdicional IN (SELECT PCRCA.IdCotizacionRutaCargoAdicional FROM ProCotizaciones AS PC 
				INNER JOIN ProCotizacionesRutas AS PCR ON PCR.IdCotizacion = PC.IdCotizacion
				INNER JOIN ProCotizacionesRutasCargosAdicionales AS PCRCA ON PCR.IdCotizacionRuta = PCRCA.IdCotizacionRuta
				WHERE PC.IdCotizacion = @IdCotizacion AND PCRCA.Revision = @Revision)

				--Se elimina las rutas que pertenecen a la revision anterior
				DELETE FROM ProCotizacionesRutas WHERE IdCotizacionRuta IN (SELECT PCR.IdCotizacionRuta FROM ProCotizaciones AS PC 
				INNER JOIN ProCotizacionesRutas AS PCR ON PCR.IdCotizacion = PC.IdCotizacion
				WHERE PC.IdCotizacion = @IdCotizacion AND PCR.Revision = @Revision)
			END

			COMMIT TRANSACTION Principal
END TRY
BEGIN CATCH
	IF (SELECT CURSOR_STATUS('global','CursorCatRutasCompuestas')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('global','CursorCatRutasCompuestas')) > -1
			BEGIN
				CLOSE CursorCatRutasCompuestas
			END
		DEALLOCATE CursorCatRutasCompuestas
	END

	IF (SELECT CURSOR_STATUS('global','CursorProCotizacionCargosAdicionalesRuta')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('global','CursorProCotizacionCargosAdicionalesRuta')) > -1
			BEGIN
				CLOSE CursorProCotizacionCargosAdicionalesRuta
			END
		DEALLOCATE CursorProCotizacionCargosAdicionalesRuta
	END

	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK TRANSACTION Principal
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

