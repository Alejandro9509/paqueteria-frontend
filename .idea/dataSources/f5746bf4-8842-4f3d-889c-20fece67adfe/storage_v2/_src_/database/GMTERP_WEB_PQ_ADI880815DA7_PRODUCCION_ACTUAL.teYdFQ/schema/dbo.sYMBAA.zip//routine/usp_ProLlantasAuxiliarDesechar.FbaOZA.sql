CREATE PROCEDURE [dbo].[usp_ProLlantasAuxiliarDesechar]
@IdLlanta int,
@FechaHora datetime,
@IdEstatuLlanta int,
@IdProcesoLlanta int,
@IdMotivoDesecharLlanta int,
@Observaciones varchar(500),
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100),
@IdTipoLlanta INT
AS
DECLARE 
	@IdProcesoLlantaAuxiliar INT,
	@MessageError varchar(8000),
	@PresionActual decimal (10, 2),
	@ProfundidadRodamiento decimal(10, 2),
	@KilometrajeHistorico int
BEGIN TRY
	BEGIN TRANSACTION
	
	SET @MessageError =''
	IF ISDATE(@FechaHora)= 0 
		RAISERROR(N'Fecha de Desasignación es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdLlanta,0)= 0 
		RAISERROR(N'Identificador de llanta es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdTipoLlanta ,0)= 0 
		RAISERROR(N'Identificador tipo de llanta es un campo requerido',
			16,
			1
			)		
							
	IF ISNULL(@IdEstatuLlanta,0)= 0 
		RAISERROR(N'Identificador estatus de llanta es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdProcesoLlanta,0)= 0 
		RAISERROR(N'Identificador de proceso de llanta es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdMotivoDesecharLlanta,0)= 0 
		RAISERROR(N'Identificador de desechar llanta es un campo requerido',
			16,
			1
			)


			
									
	IF EXISTS(SELECT top 1  IdProcesoLlanta FROM ProLlantasAuxiliar WHERE IdLlanta = @IdLlanta  And IdProcesoLlanta = (SELECT IdProcesoLLanta FROM CatProcesosLlantas WHERE ProcesoLlanta = 'DESECHADA') ORDER BY FechaHora DESC)
			RAISERROR(N'Llanta ya fue desechada por otro usuario, revisar información ',
			16,
			1
			)
														
	SET @IdProcesoLlantaAuxiliar= (SELECT top 1 (CASE IdProcesoLlanta 
		WHEN 1 THEN 0
		WHEN 2 THEN 1
		WHEN 3 THEN 1
		WHEN 4 THEN 0
		WHEN 5 THEN 0
	END)	FROM ProLlantasAuxiliar WHERE IdLlanta = @IdLlanta
	ORDER BY FechaHora DESC)
	
	IF  ISNULL(@IdProcesoLlantaAuxiliar,0) = 0
				RAISERROR(N'Llanta no esta disponible para desechar, revisar información ',
			16,
			1
			)

	--  Cargar datos de la llanta
		
	SELECT @PresionActual = PresionActual,@ProfundidadRodamiento=ProfundidadActual, @KilometrajeHistorico= KilometrajeLLanta FROM ProLlantas WHERE IdLlanta = @IdLlanta 
		
	-- Actualizar ProLlantas
	UPDATE ProLlantas SET IdEstatuLlanta = @IdEstatuLlanta,
			IdProcesoLlanta = @IdProcesoLlanta,	
			IdTipoLlanta = 	@IdTipoLlanta			  
	WHERE IdLlanta = @IdLlanta								   
		  
	-- Registrar en Auxiliar de Llantas															
	INSERT INTO ProLlantasAuxiliar (IdLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta,IdMotivoDesecharLlanta,Observaciones) 
		   VALUES (@IdLlanta,@FechaHora,@IdEstatuLlanta,@PresionActual,@ProfundidadRodamiento,0,@KilometrajeHistorico,0,@CreadoPor,@CreadoEl,@IdProcesoLlanta,@IdMotivoDesecharLlanta,@Observaciones) 	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

