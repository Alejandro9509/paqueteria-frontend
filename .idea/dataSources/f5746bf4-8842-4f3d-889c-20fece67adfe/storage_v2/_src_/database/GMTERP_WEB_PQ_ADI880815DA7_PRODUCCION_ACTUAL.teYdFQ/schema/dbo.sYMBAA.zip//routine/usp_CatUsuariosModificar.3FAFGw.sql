CREATE PROCEDURE [dbo].[usp_CatUsuariosModificar]	
	@IdUsuario Int,
	@Usuario varchar(16),
	@Nombre varchar(100),
	@NombreCorto varchar(12),
	@Contrasena varchar (20),
	@TipoUsuario tinyint,
	@CorreoElectronico varchar(100),
	@IdSucursal int,
	@Activo bit,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@FiltrarAcceso bit,
	@FiltrarAccesoPorLaIP varchar(15),
	@FiltrarAccesoPorHora bit,
	@Hora0 bit,
	@Hora1 bit,	
	@Hora2 bit,
	@Hora3 bit,
	@Hora4 bit,
	@Hora5 bit,
	@Hora6 bit,
	@Hora7 bit,
	@Hora8 bit,
	@Hora9 bit,
	@Hora10 bit,
	@Hora11 bit,	
	@Hora12 bit,
	@Hora13 bit,
	@Hora14 bit,
	@Hora15 bit,
	@Hora16 bit,
	@Hora17 bit,
	@Hora18 bit,
	@Hora19 bit,
	@Hora20 bit,
	@Hora21 bit,	
	@Hora22 bit,
	@Hora23 bit,
	@Lunes bit,
	@Martes bit,
	@Miercoles bit,
	@Jueves bit,
	@Viernes bit,
	@Sabado bit,
	@Domingo bit,					
	@IdPeticion varchar(100),
	@UltimaModificacion datetime,
	@MostrarCatalogosOtrasSucursales bit,
	@dsUsuarioSucursales ntext,
	@dsUsuarioAlmacenes ntext,
	@TraficoNotificacion bit,
	@TraficoNotificacionAsistencia bit,
	@OpPortuariaNotificacion bit,
	@VencimientoCertificadosNotificacion bit,
	@CambioContrasenaSolicitada bit

	/* *************************************************************************************************
	Modificado por:   EDGAR RAMOS
	Solicitud:4124
	Fecha de Modificado: 05/04/2021
	Versión: 8.0.59.27

	Modificado por:   Julio Hermosillo
	Fecha de Modificacion: 16/06/2020
	Versión: 8.0.53.10

	Modificado por:   Julio Hermosillo
	Fecha de Modificacion: 04/08/2020
	Versión: 8.0.54.28

	Invocada desde: <PAGE_CatUsuariosAM>
	************************************************************************************************ */
AS
DECLARE
	@docHandle int,
	@ATT_IdUsuarioSucursal int,
	@ATT_IdSucursal int,
	@ATT_NumeroProceso int,
	@ATT_IdUsuarioAlmacen int,
	@ATT_IdAlmacen int,
	@ContrasenaAnterior varchar(50),
	@FechaSolicitarCambioContrasena datetime,
	@SolicitarCambioContrasena bit,
	@CantidadDiasSolicitarContrasena int

	SET @SolicitarCambioContrasena = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'SolicitarCambioContrasena')
	SET @ContrasenaAnterior = (SELECT Contrasena FROM CatUsuarios WHERE IdUsuario = @IdUsuario)

BEGIN TRY
	BEGIN TRANSACTION
	
	IF (SELECT ModificadoEl FROM CatUsuarios WHERE IdUsuario = @IdUsuario) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
	IF LTRIM(RTRIM(@Usuario)) = ''
		RAISERROR(N'El campo de usuario es requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El campo nombre de usuario es requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@NombreCorto)) = ''
		RAISERROR(N'El campo nombre corto de usuario es requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@Contrasena)) = ''
		RAISERROR(N'El campo contraseña es requerido',
			16,
			1
			)			
	IF @TipoUsuario = 0 
		RAISERROR(N'El campo tipo de usuario es requerido',
			16,
			1
			)			
	IF @IdSucursal = 0
		RAISERROR(N'El campo sucursal es requerido',
			16,
			1
			)
	IF (SELECT TOP 1 Usuario FROM CatUsuarios WHERE IdUsuario <> @IdUsuario AND Usuario = @Usuario) <> ''
		RAISERROR(N'El nombre de usuario ya esta registrado, favor de validar',
			16,
			1
			)
	IF @SolicitarCambioContrasena = 1 AND @CambioContrasenaSolicitada = 1
		BEGIN
			IF @ContrasenaAnterior = @Contrasena
				RAISERROR(N'La contraseña no puede ser igual a la contraseña actual',
				16,
				1
				)
		END

	UPDATE CatUsuarios SET  Usuario = @Usuario,
						    Nombre=@Nombre,
							NombreCorto=@NombreCorto,
							Contrasena=@Contrasena,
							TipoUsuario=@TipoUsuario,
							CorreoElectronico=@CorreoElectronico,
							IdSucursal=@IdSucursal,
							Activo=@Activo,
							ModificadoEl=@ModificadoEl,
							ModificadoPor =@ModificadoPor,
							FiltrarAcceso = @FiltrarAcceso,
							FiltrarAccesoPorLaIP = @FiltrarAccesoPorLaIP,
							FiltrarAccesoPorHora = @FiltrarAccesoPorHora,
							Hora0 = @Hora0,
							Hora1 = @Hora1,
							Hora2 = @Hora2,
							Hora3 = @Hora3,
							Hora4 = @Hora4,
							Hora5 = @Hora5,
							Hora6 = @Hora6,
							Hora7 = @Hora7,
							Hora8 = @Hora8,
							Hora9 = @Hora9,
							Hora10 = @Hora10,
							Hora11 = @Hora11,
							Hora12 = @Hora12,
							Hora13 = @Hora13,
							Hora14 = @Hora14,
							Hora15 = @Hora15,
							Hora16 = @Hora16,
							Hora17 = @Hora17,
							Hora18 = @Hora18,
							Hora19 = @Hora19,
							Hora20 = @Hora20,
							Hora21 = @Hora21,
							Hora22 = @Hora22,
							Hora23 = @Hora23,
							Lunes = @Lunes,
							Martes = @Martes,
							Miercoles = @Miercoles,
							Jueves = @Jueves,
							Viernes = @Viernes,
							Sabado = @Sabado,
							Domingo = @Domingo,
							MostrarCatalogosOtrasSucursales = @MostrarCatalogosOtrasSucursales,
							TraficoNotificaciones = @TraficoNotificacion,
							TraficoNotificacionesAsistencia = @TraficoNotificacionAsistencia,
							OpPortuariaNotificaciones = @OpPortuariaNotificacion,
							VencimientoCertificadosNotificaciones = @VencimientoCertificadosNotificacion,
							Menu = NULL,/*Solicitud:4124 se reinicia para que se vuelva generar al momento de iniciar sesion*/
							XMLAutoCompleteMenu = NULL,/*Solicitud:4124 se reinicia para que se vuelva generar al momento de iniciar sesion*/
							AccesosDirectos = NULL/*Solicitud:4124 se reinicia para que se vuelva generar al momento de iniciar sesion*/
	WHERE IdUsuario = @IdUsuario
	
	-- Sección para registrar fecha solicitar cambio de contraseña
	
	IF @ContrasenaAnterior <> @Contrasena
		BEGIN
			IF @SolicitarCambioContrasena = 1 AND (SELECT Usuario FROM CatUsuarios WHERE IdUsuario = @IdUsuario) <> 'GM' AND (SELECT TipoUsuario FROM CatUsuarios WHERE IdUsuario = @IdUsuario) <> 5
				BEGIN
					SET @CantidadDiasSolicitarContrasena = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'CantidadDiasSolicitarContrasena')			

					IF @CantidadDiasSolicitarContrasena > 0
						BEGIN
							SET @FechaSolicitarCambioContrasena = (Getdate() + @CantidadDiasSolicitarContrasena)
					
							UPDATE CatUsuarios SET
								SolicitarCambioContrasena = @FechaSolicitarCambioContrasena
							WHERE IdUsuario = @IdUsuario
						END
				END
		END

	--SECCION PARA AGREGAR LOS PEMISOS QUE SE LE DAN A CADA USUARIO DE HACER PROCESOS AL ALGUNA SUCURSAL.
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsUsuarioSucursales
	
	SELECT ATT_IdUsuarioSucursal,ATT_IdSucursal,ATT_NumeroProceso
	INTO #TempCatUsuarioSucursales
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_UsuariosSucursales',2) 
	WITH (ATT_IdUsuarioSucursal int,ATT_IdSucursal int,ATT_NumeroProceso int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatUsuarioSucursales CURSOR FOR
	SELECT * FROM #TempCatUsuarioSucursales
	
	OPEN CursorCatUsuarioSucursales
	FETCH NEXT FROM CursorCatUsuarioSucursales
	INTO @ATT_IdUsuarioSucursal,@ATT_IdSucursal,@ATT_NumeroProceso
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdUsuarioSucursal = 0
		BEGIN				
			INSERT INTO CatUsuariosSucursales(IdUsuario,IdSucursal,Proceso,CreadoEl,CreadoPor)
			VALUES(@IdUsuario,@ATT_IdSucursal,@ATT_NumeroProceso,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			UPDATE CatUsuariosSucursales
			SET ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdUsuarioSucursal= @ATT_IdUsuarioSucursal
		END

		FETCH NEXT FROM CursorCatUsuarioSucursales
		INTO @ATT_IdUsuarioSucursal,@ATT_IdSucursal,@ATT_NumeroProceso
	END

	CLOSE CursorCatUsuarioSucursales
	DEALLOCATE CursorCatUsuarioSucursales						
	
	--SECCION PARA AGREGAR LOS PEMISOS QUE SE LE DAN A CADA USUARIO DE HACER PROCESOS AL ALGUN ALMACEN.
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsUsuarioAlmacenes
	
	SELECT ATT_IdUsuarioAlmacen,ATT_IdAlmacen
	INTO #TempCatUsuarioAlmacenes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_UsuariosAlmacenes',2) 
	WITH (ATT_IdUsuarioAlmacen int,ATT_IdAlmacen int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatUsuarioAlmacenes CURSOR FOR
	SELECT * FROM #TempCatUsuarioAlmacenes
	
	OPEN CursorCatUsuarioAlmacenes
	FETCH NEXT FROM CursorCatUsuarioAlmacenes
	INTO @ATT_IdUsuarioAlmacen,@ATT_IdAlmacen
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdUsuarioAlmacen = 0
		BEGIN				
			INSERT INTO CatUsuariosAlmacenes(IdUsuario,IdAlmacen,CreadoEl,CreadoPor)
			VALUES(@IdUsuario,@ATT_IdAlmacen,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			UPDATE CatUsuariosAlmacenes
			SET ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdUsuarioAlmacen= @ATT_IdUsuarioAlmacen
		END

		FETCH NEXT FROM CursorCatUsuarioAlmacenes
		INTO @ATT_IdUsuarioAlmacen,@ATT_IdAlmacen
	END

	CLOSE CursorCatUsuarioAlmacenes
	DEALLOCATE CursorCatUsuarioAlmacenes
		
	DELETE FROM CatUsuariosSucursales WHERE IdUsuario = @IdUsuario AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	DELETE FROM CatUsuariosAlmacenes WHERE IdUsuario = @IdUsuario AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

