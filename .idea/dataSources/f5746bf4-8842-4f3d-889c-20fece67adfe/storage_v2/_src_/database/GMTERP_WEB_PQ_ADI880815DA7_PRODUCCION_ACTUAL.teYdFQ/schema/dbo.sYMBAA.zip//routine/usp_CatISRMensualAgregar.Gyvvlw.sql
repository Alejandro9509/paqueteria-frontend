

CREATE PROCEDURE [dbo].[usp_CatISRMensualAgregar]
@dsCatISRMensual ntext,
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100)
AS
DECLARE
@docHandle int, 
@CursorT_Ejercicio int,
@CursorT_FechaVigencia datetime,
@CursorT_LimiteInferior decimal(15, 3),
@CursorT_LimiteSuperior decimal(15, 3),
@CursorT_CuotaFija decimal(15, 3),
@CursorT_Porcentaje decimal(15, 3)
BEGIN TRY
	BEGIN TRANSACTION

	IF @dsCatISRMensual IS NULL
		RAISERROR(N'Los ISR Mensuales son requeridos',
			16,
			1
			)

	IF @dsCatISRMensual IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatISRMensual

		SELECT ATT_Ejercicio,ATT_FechaVigencia,ATT_LimiteInferior,ATT_LimiteSuperior,ATT_CuotaFija,ATT_Porcentaje
		INTO #CatISRMensual
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CATISRMensuales',2) 
		WITH ( ATT_Ejercicio int,ATT_FechaVigencia datetime, ATT_LimiteInferior decimal(15, 2),ATT_LimiteSuperior decimal(15, 2),ATT_Porcentaje decimal(15, 2),ATT_CuotaFija decimal(15, 2) )

		EXEC sp_xml_removedocument @docHandle

		DECLARE CatISRMensualCursor CURSOR LOCAL SCROLL FOR
		SELECT * FROM #CatISRMensual

		OPEN CatISRMensualCursor
		FETCH NEXT FROM CatISRMensualCursor
		INTO @CursorT_Ejercicio, @CursorT_FechaVigencia,@CursorT_LimiteInferior,@CursorT_LimiteSuperior,@CursorT_CuotaFija,@CursorT_Porcentaje

		WHILE @@FETCH_STATUS = 0
		BEGIN
			INSERT INTO CatISRMensual (LimiteInferior,CuotaFija,Porcentaje,CreadoEl,CreadoPor,LimiteSuperior,Ejercicio,FechaVigencia)
			VALUES ( @CursorT_LimiteInferior, @CursorT_CuotaFija,  @CursorT_Porcentaje, @CreadoEl, @CreadoPor ,@CursorT_LimiteSuperior,  @CursorT_Ejercicio, @CursorT_FechaVigencia)
			

			FETCH NEXT FROM CatISRMensualCursor
			INTO @CursorT_Ejercicio, @CursorT_FechaVigencia,@CursorT_LimiteInferior,@CursorT_LimiteSuperior,@CursorT_CuotaFija,@CursorT_Porcentaje
		END
		CLOSE CatISRMensualCursor
		DEALLOCATE CatISRMensualCursor

	END
  COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

