CREATE PROCEDURE [dbo].[usp_ProRecubrimientosModificar]  
 @IdRecubrimiento int,
 @Folio int,  
 @FechaHora datetime,  
 @QuienEntrego varchar(50),  
 @QuienRecibe varchar(50),  
 @FechaHoraEnvio datetime,  
 @FechaHoraProximoRetorno datetime,  
 @FechaHoraRetorno datetime,  
 @dsProRecubrimientosLlantas ntext,
 @Conseptos ntext,  
 @GeneraOrdenDeCompra bit,
 @FolioOC int,
 @FechaOC dateTime,
 @IdProveedor int,  
 @IdAlmacen int,
 @TipoCambio money,  
 @IdMoneda int,     
 @SubTotal money,
 @Total money,  
 @IdEstatusOC int,
 @ModificadoPor int,  
 @ModificadoEl datetime,   
 @IdPeticion varchar(100),
 @IdImpuestosTrasladadosFederales int,  
 @ImpuestosTrasladadosFederales money,  
 @IdImpuestosRetenidosFederales int,  
 @ImpuestosRetenidosFederales money,  
 @IdImpuestosTrasladadosLocales int,  
 @ImpuestosTrasladadosLocales money,  
 @IdImpuestosRetenidosLocales int,  
 @ImpuestosRetenidosLocales money,
 @UltimaModificacion datetime,
 @IdOrdenCompraSP int
 
 /* *************************************************************************************************
Procedimiento usp_ProRecubrimientosModificar

Parámetros: 
@IdRecubrimiento int  (entrada, numero). id del registro
@Folio int,		   (Entrada,numero). es el consecutivo de los procesos de recubrimientos.	
 @FechaHora datetime,  (Entrada,fecha) es la fecha cuando se realizo el proceso.
 @QuienEntrego varchar(50),  (Entrada,cadena) es el nombre de la persona envia el material a recubrir.
 @QuienRecibe varchar(50),   (Entrada,cadena) es la persona que recoge el material a compostura.
 @FechaHoraEnvio datetime,	 (Entrada,fecha) es la fecha que se enviara el material a procesar.	
 @FechaHoraProximoRetorno datetime,  (Entrada,fecha) es la fecha llegara el material que se envio a compostura.
 @FechaHoraRetorno datetime,	     (Entrada,fecha) es la fecha que llego el material.
 @dsProRecubrimientosLlantas ntext,  (Entrada,cadena) es la informacion del material a procesar.
 @Conseptos ntext,  
 @GeneraOrdenDeCompra bit,	(Entrada,boolean) si el proceso requiere una orden de compra
 @FolioOC int,				(Entrada,entero) es el folio de la orden de compra	
 @FechaOC dateTime,			(Entraa,fecha) la fecha de la creacion de la orden de compra
 @IdProveedor int,			(Entrada,numero) es el id del codigo del proveedor
 @IdAlmacen int,			(Entrada,numero) es el id del almacen de salida
 @TipoCambio money,			(Entrada,numero) el valor del tipo de cambio del dia en la orden de compra.
 @IdMoneda int,				(Entrada,numero) es el id del tipo de moneda usado en la orden de compra.
 @SubTotal money,			(Entrada,numero) es el importe sin impuestos de la orden de compra.
 @Total money,				(Entrada,numero) es el importe total con impuestos.
 @IdEstatusOC int,			(Estrada,numero) es el estatus actual del proceso de cada material
 @ModificadoPor int,		(Entrada,entero) es el id del usuario que modifico.	
 @ModificadoEl datetime,    (Entrada,fecha) es la fecha que se modifico el registro.
 @IdPeticion varchar(100),  (Entrada,numero) es la cadena de peticion del proceso webdev.
 @IdImpuestosTrasladadosFederales int,  (Entrada,numero) clave del impuesto trasladado federal.
 @ImpuestosTrasladadosFederales money,  (Entrada,numero) monto de los impuestos trasladados federales
 @IdImpuestosRetenidosFederales int,    (Entrada,numero) clave de los impuestos retenidos federales
 @ImpuestosRetenidosFederales money,    (Entrada,numero) monto de los impuestos retenidos federales.
 @IdImpuestosTrasladadosLocales int,    (Entrada,numero) clave de impuestos locales
 @ImpuestosTrasladadosLocales money,    (Entrada,numero) monto de los impuestos locales
 @IdImpuestosRetenidosLocales int,      (Entrada,numero) clave de impuestos retenidos locales
 @ImpuestosRetenidosLocales money,      (Entrada,numero) monto de los impuestos retenidos locales
 @UltimaModificacion datetime,	        (Entrada,fecha) fecha de la modificacion anterior 
 @IdOrdenCompraSP int					
 

Modificada por:   Raymundo Espnoza Garcia
Fecha de mofidicacion: 12/07/2021
Versión ERP: 8.0.62.30

Invocada desde: PAGE_ProRecubrimientosAM (Solicitud 4536)
***************************************************************************************************** */



 AS  
DECLARE  
 @docHandle int,  
 --@Estatus int,
 @IdOrdenCompra int,
 @ATT_IdLLanta int,
 @ATT_IdArticulo int,
 @ATT_Costo decimal(15,2),
 @ATT_IdRecubimientosLlantas int,
 @IdRecubrimientoLlantaCursor int,
 @IdLlantaCursor int,
 @EconomicosError varchar(max),
 @EconomicosError2 varchar(max),
 @MsgError varchar(max)
 
SET XACT_ABORT ON 	
BEGIN TRY  
 BEGIN TRANSACTION  
	IF @IdRecubrimiento = 0
			RAISERROR(N'El identificador es un campo requerido',
				16,
				1
				)
	IF (SELECT ModificadoEl FROM ProRecubrimientos WHERE IdRecubrimiento = @IdRecubrimiento) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
		
	IF ISDATE(@FechaHora) = 0
			RAISERROR(N'La fecha es un campo requerido',
				16,
				1
				)
	IF Isnull(@Folio,0) = 0  
		  RAISERROR(N'El folio de la orden de compra es un campo requerido',  
		   16,  
		   1  
		   )     
           
					   
	IF @GeneraOrdenDeCompra  = 1
	Begin
		IF Isnull(@IdProveedor,0) = 0  
			RAISERROR(N'El proveedor de la ordn de compra es un campo requerido',  
			16,  
			1  
			)  
		IF Isnull(@SubTotal,0) = 0  
			RAISERROR(N'El subtotal de la orden de compra es un campo requerido',  
			16,  
			1  
			)  
		IF ISDATE(@FechaOC) = 0  
			RAISERROR(N'La fecha de la Orden de compra es un campo requerido',  
			16,  
			1  
			)  
  
		IF Isnull(@IdMoneda,0) = 0  
			RAISERROR(N'La moneda es un campo requerido',  
			16,  
			1  
			)
	End 
       
 IF CAST(@dsProRecubrimientosLlantas AS VARCHAR(MAX))=''
	   RAISERROR(N'Los conceptos de la orden de compra son requeridos',  
	   16,  
	   1  
	   )      
         
	--Set @Estatus = (Select IdEstatuLlanta from CatEstatusLlantas Where EstatusLLanta = 'EN RECUBRIMIENTO' And DefinidoPorSistema = 1)
 
	UPDATE ProRecubrimientos 
	SET Fecha =@FechaHora
		,QuienEntrego=@QuienEntrego
		,QuienRecibe=@QuienRecibe
		,FechaEnvio=@FechaHoraEnvio
		,FechaProximaRetorno=@FechaHoraProximoRetorno
		,FechaRetorno=@FechaHoraRetorno		
		,ModificadoPor=@ModificadoPor
		,ModificadoEl=@ModificadoEl
	WHERE IdRecubrimiento = @IdRecubrimiento
	
 --===========================================================   
 --SECCION PARA AGREGAR EL DETALLE DE LAS LLANTAS ENVIADAS----
 --===========================================================
	   
 IF @dsProRecubrimientosLlantas IS NOT NULL
 BEGIN
	 EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProRecubrimientosLlantas
	 
	 SELECT ATT_Economico,ATT_IdArticulo,ATT_Costo,ATT_IdRecubimientosLlantas
	 INTO #TempProRecubrimientosLlantas  
	 FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProLlantasEnviarRecubrimiento',2)   
	 WITH (ATT_Economico int,ATT_IdArticulo int,ATT_Costo decimal(15,4),ATT_IdRecubimientosLlantas int)  
	 
	 EXEC sp_xml_removedocument @docHandle  
	 
	 DECLARE ProRecubrimientosLlantasCursor CURSOR FOR
	 SELECT * FROM #TempProRecubrimientosLlantas  

	 OPEN ProRecubrimientosLlantasCursor
	 FETCH NEXT FROM ProRecubrimientosLlantasCursor
	 INTO @ATT_IdLLanta,@ATT_IdArticulo,@ATT_Costo,@ATT_IdRecubimientosLlantas
		
	 SET @EconomicosError = ''
	 SET @EconomicosError2 	= ''
	 WHILE @@FETCH_STATUS = 0
	 BEGIN
	 	IF @ATT_IdArticulo = 0
		SET @ATT_IdArticulo = NULL
		
		IF ((Select IdProcesoLlanta from ProLlantas Where IdLlanta = @ATT_IdLLanta) <> (Select IdProcesoLLanta from CatProcesosLlantas Where ProcesoLlanta = 'DESASIGNADO'))
		And (Select IdRecubrimiento from ProRecubrimientosLlantas Where IdLlanta = @ATT_IdLLanta And Isnull(FechaRetorno,0) = 0) <> @IdRecubrimiento
		Begin
			If @EconomicosError = ''
				Set @EconomicosError = (Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
			else
				Set @EconomicosError = @EconomicosError +', '+(Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
		end
		IF Exists(Select * from ProRecubrimientosLlantas 
				  Where IdLlanta = @ATT_IdLLanta 
				    And IsNull(FechaRetorno,0) = 0
		            And IdRecubrimiento <> @IdRecubrimiento)
		Begin
			If @EconomicosError2 = ''
				Set @EconomicosError2 = (Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
			else
				Set @EconomicosError2 = @EconomicosError2 +', '+(Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
		End
		
		IF @ATT_IdRecubimientosLlantas = 0
		BEGIN
			INSERT INTO ProRecubrimientosLlantas(IdRecubrimiento,IdLlanta,IdArticulo,Costo,CreadoPor,CreadoEl)  
			Values (@IdRecubrimiento,@ATT_IdLLanta,@ATT_IdArticulo,@ATT_Costo,@ModificadoPor,@ModificadoEl)
			
			INSERT INTO ProLlantasAuxiliar(IdLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CreadoEl,CreadoPor,IdProcesoLlanta)
			Values(@ATT_IdLLanta
               ,@FechaHora
               ,(Select IdEstatuLlanta from CatEstatusLlantas Where EstatusLLanta = 'EN RECUBRIMIENTO' And DefinidoPorSistema = 1)
               ,(Select PresionActual from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,(Select ProfundidadOriginal from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,(Select KilometrajeLLanta from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,(Select KilometrajeLLanta from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,@ModificadoEl,@ModificadoPor
               ,(Select IdProcesoLLanta from CatProcesosLlantas Where ProcesoLlanta = 'EN RECUBRIMIENTO')
               )
        
			Update ProLlantas Set IdEstatuLlanta = (Select IdEstatuLlanta from CatEstatusLlantas Where EstatusLLanta = 'EN RECUBRIMIENTO' And DefinidoPorSistema = 1),
							  IdProcesoLlanta = (Select IdProcesoLLanta from CatProcesosLlantas Where ProcesoLlanta = 'EN RECUBRIMIENTO')
			Where IdLlanta = @ATT_IdLLanta
		END
		ELSE
		BEGIN
			UPDATE ProRecubrimientosLlantas
			SET IdLlanta = @ATT_IdLLanta,
			IdArticulo = @ATT_IdArticulo,
			Costo = @ATT_Costo,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor
			Where IdRecubrimientoLlanta = @ATT_IdRecubimientosLlantas And IdLlanta = @ATT_IdLLanta
		END		                                       
        
		FETCH NEXT FROM ProRecubrimientosLlantasCursor
		INTO @ATT_IdLLanta,@ATT_IdArticulo,@ATT_Costo,@ATT_IdRecubimientosLlantas
	 END
	 CLOSE ProRecubrimientosLlantasCursor
	 DEALLOCATE ProRecubrimientosLlantasCursor
 END
 IF @EconomicosError <> '' 
 begin
	Set @MsgError = 'La(s) llanta(s) No. '+@EconomicosError+' no se pueden enviar a recubrir porque estan asignadas a un recubrimiento'
	RAISERROR(@MsgError ,  
	16,  
	1  
	) 
end 
IF @EconomicosError2 <> '' 
 begin
	Set @MsgError = 'La(s) llanta(s) No. '+@EconomicosError2+' ya fueron asignadas a otro Recubrimiento'
	RAISERROR(@MsgError ,  
	16,  
	1  
	) 
end       
 --Borra los registros que fueron quitados del Recubrimiento
	Declare LLANTASELIMINADASRECUBRIMIENTOSCursor Cursor For
	SELECT IdRecubrimientoLlanta,IdLlanta FROM ProRecubrimientosLlantas WHERE IdRecubrimiento = @IdRecubrimiento AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	Open LLANTASELIMINADASRECUBRIMIENTOSCursor
	Fetch Next From LLANTASELIMINADASRECUBRIMIENTOSCursor
	Into @IdRecubrimientoLlantaCursor,@IdLlantaCursor

	While @@Fetch_Status = 0
	Begin
		Delete from ProLlantasAuxiliar Where IdLlantaAuxiliar = (Select top 1 IdLlantaAuxiliar from ProLlantasAuxiliar Where IdLlanta = @IdLlantaCursor order by CreadoEl desc)
		
		Update ProLlantas Set IdEstatuLlanta = (Select top 1 IdEstatuLlanta from ProLlantasAuxiliar Where IdLlanta = @IdLlantaCursor order by CreadoEl desc),
		IdProcesoLlanta = (Select IdProcesoLLanta from CatProcesosLlantas where ProcesoLlanta = 'DESASIGNADO')
		Where IdLlanta = @IdLlantaCursor

		Delete ProRecubrimientosLlantas Where IdRecubrimientoLlanta = @IdRecubrimientoLlantaCursor
		
		Fetch Next From LLANTASELIMINADASRECUBRIMIENTOSCursor
		Into @IdRecubrimientoLlantaCursor,@IdLlantaCursor
	End
	Close LLANTASELIMINADASRECUBRIMIENTOSCursor
	Deallocate LLANTASELIMINADASRECUBRIMIENTOSCursor
--Fin del Cursor para Borra los registros que fueron quitados del Recubrimiento 
 
 If @GeneraOrdenDeCompra = 1
 Begin
	If @IdOrdenCompraSP <> 0
		exec usp_ProOrdenCompraModificar @IdOrdenCompraSP,@IdProveedor,@FechaOC,@SubTotal,NULL,NULL,@IdImpuestosTrasladadosFederales,@ImpuestosTrasladadosFederales,@IdImpuestosRetenidosFederales,@ImpuestosRetenidosFederales,@IdImpuestosTrasladadosLocales,@ImpuestosTrasladadosLocales,@IdImpuestosRetenidosLocales,@ImpuestosRetenidosLocales,@Total,@TipoCambio,@IdMoneda,@IdEstatusOC,NULL,@ModificadoPor,@ModificadoEl,@Conseptos,@IdPeticion,@IdAlmacen,NULL,@FolioOC
	Else
	begin
		exec @IdOrdenCompra = usp_ProOrdenCompraAgregar @FolioOC,@IdProveedor,@FechaOC,@SubTotal,NULL,NULL,@IdImpuestosTrasladadosFederales,@ImpuestosTrasladadosFederales,@IdImpuestosRetenidosFederales,@ImpuestosRetenidosFederales,@IdImpuestosTrasladadosLocales,@ImpuestosTrasladadosLocales,@IdImpuestosRetenidosLocales,@ImpuestosRetenidosLocales,@Total,@TipoCambio,@IdMoneda,@IdEstatusOC,NULL,@ModificadoPor,@ModificadoEl,@Conseptos,@IdPeticion,@IdAlmacen,NULL
		Update ProRecubrimientos Set IdOrdenCompra = @IdOrdenCompra Where IdRecubrimiento = @IdRecubrimiento
	End
 End     
    
 COMMIT  
END TRY  
BEGIN CATCH  
 IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

