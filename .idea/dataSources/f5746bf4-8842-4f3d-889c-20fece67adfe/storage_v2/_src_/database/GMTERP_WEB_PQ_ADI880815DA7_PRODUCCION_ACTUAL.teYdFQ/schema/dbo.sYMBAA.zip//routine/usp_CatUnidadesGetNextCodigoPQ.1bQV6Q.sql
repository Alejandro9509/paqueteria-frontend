CREATE PROCEDURE [dbo].[usp_CatUnidadesGetNextCodigoPQ]
	
	AS BEGIN 
		
		SELECT TOP 1 * FROM (
    SELECT t1.Codigo+1 AS NextCodigo
    FROM CatUnidades t1
    WHERE NOT EXISTS(SELECT * FROM CatUnidades t2 WHERE t2.Codigo = t1.Codigo + 1 )
    UNION 
    SELECT 1 AS NextCodigo
    WHERE NOT EXISTS (SELECT * FROM CatUnidades t3 WHERE t3.Codigo = 1)) ot
ORDER BY 1
	
END
go

