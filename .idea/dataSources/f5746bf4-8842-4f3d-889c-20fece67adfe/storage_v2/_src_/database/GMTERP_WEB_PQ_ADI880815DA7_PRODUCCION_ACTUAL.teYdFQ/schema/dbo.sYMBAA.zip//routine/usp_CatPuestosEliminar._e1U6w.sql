CREATE PROCEDURE [dbo].[usp_CatPuestosEliminar]
@IdPuesto int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdPuesto,0)= 0
		RAISERROR(N'El identificador del puesto es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT TOP 1 * FROM CatEmpleados WHERE IdPuesto = @IdPuesto)
		RAISERROR(N'El puesto esta ligado a un empleado, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM CatOperadores WHERE IdPuesto = @IdPuesto)
		RAISERROR(N'El puesto esta ligado a un operador, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM CatRutasPersonalPuntuaciones WHERE IdPuesto = @IdPuesto)
		RAISERROR(N'El puesto esta ligado a una ruta, no es posible eliminarlo',
			16,
			1
			) 
				
	IF EXISTS(SELECT TOP 1 * FROM ProRecorridos WHERE IdPuesto = @IdPuesto)
		RAISERROR(N'El puesto esta ligado a un recorrido, no es posible eliminarlo',
			16,
			1
			)
	
		DELETE CatPuestos		
		WHERE 	IdPuesto=@IdPuesto
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

