CREATE PROCEDURE [dbo].[usp_ProCobranzaRegistrarPagosAbonosConSaldoAFavor]
	@FechaHora datetime,
	@IdCobranzaSaldoAFavor int,
	@IdConceptoCobranza int,	
	@IdCliente int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProFacturas ntext,
	@IdPeticion varchar(100),
	@IdCertificado int,
	@SecuenciaAnterior int
AS
DECLARE
	@docHandle int,		
	@ImporteFacturas money,
	@ImporteClienteDLLS money,
	@ImporteClientePESOS money,
	@IdFactura int,
	@DoctoFactura varchar(50),
	@MensajeError varchar(250),
	@ATT_IdFactura int,
	@ATT_IdMoneda int,
	@ATT_IdSucursal int,
	@ATT_Importe money,
	@ATT_Referencia varchar(50),
	@IdCobranza int,
	@Porcentaje decimal(15,7),
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosGenerales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@IdFacturaConceptoFacturacion int,
	@AbonoConcepto money,
	@Retiene bit,
	@Traslada bit,
	@Beneficiario varchar(150),
	@IdBeneficiario int,	
	@NumeroBeneficiario int,
	@ATT_IdContraReciboCliente int,
	@ImporteClienteDLLSContraRecibo money,
	@ImporteClientePESOSContraRecibo money,
	@Importe money,
	@TipoCambio money,	
	@IdMonedaSaldoAFavor int,
	@SiguienteSecuencia tinyint,
	@SaldoActual money,
	@Sustituto bit = 0,
	@SiguienteFoilo int,
	@TipoFactura int,
	@ATT_ImporteImpuestoFactura money

	/*
MODIFICADO:
	Se agrego cambio el tipo de calculo de los impuestos que se guardan en procobranzaimpuestos
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-05-14
INVOCADA DESDE:
	ClsProCobranza::Agregar
SOLICITUD: 
	SOLICITUD 001534
	*/
BEGIN TRY
	BEGIN TRANSACTION
		
	IF ISDATE(@FechaHora) = 0
		RAISERROR(N'La fecha del movimiento es un campo requerido',
			16,
			1
			)
			
	IF @FechaHora < (Select cast(FechaHora as date) from ProCobranza Where IdCobranza = @IdCobranzaSaldoAFavor) 
		RAISERROR(N'La fecha de aplicación del saldo a favor no puede ser menor a la fecha del saldo a favor',
			16,
			1
			)	
								
	IF Exists(Select * from ProCobranza Where IdCobranza = @IdCobranzaSaldoAFavor And Isnull(CanceladoEl,0) <> 0 )
		RAISERROR(N'El Saldo a favor se encuentra cancelado',
			16,
			1
			)									

	IF ISNULL(@IdCobranzaSaldoAFavor,0) <= 0
		RAISERROR(N'El identificador del Saldo a Favor es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdConceptoCobranza,0) <= 0
		RAISERROR(N'El concepto de cobranza es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdCliente,0) <= 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
			
	IF @dsProFacturas IS NULL
		RAISERROR(N'Las facturas que se estan pagando son requeridos',
			16,
			1
			)
	If @SecuenciaAnterior = 0
	SET @SecuenciaAnterior = NULL
	
	If @SecuenciaAnterior IS NOT NULL
		SET @Sustituto = 1
	
	IF @IdCertificado = 0  -- Esta sección se agrega por que reportaron error para los cliente extrajeros.
		SET @IdCertificado = NULL

	--se obtiene la moneda,Importe y TC del Saldo a Favor
	SET @Importe =(SELECT Importe FROM ProCobranza WHERE IdCobranza= @IdCobranzaSaldoAFavor)
	SET @TipoCambio = (SELECT TipoCambio FROM ProCobranza WHERE IdCobranza= @IdCobranzaSaldoAFavor)
	SET @IdMonedaSaldoAFavor = (SELECT IdMoneda FROM ProCobranza WHERE IdCobranza= @IdCobranzaSaldoAFavor)
	
	--se carga las facturas a una tabla temporal
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturas
	
	SELECT ATT_IdFactura,ATT_Importe,ATT_IdMoneda,ATT_Referencia,ATT_IdSucursal,ATT_IdContraReciboCliente
	INTO #TempProFacturas
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturas',2) 
	WITH (ATT_IdFactura int,ATT_Importe money,ATT_IdMoneda int,ATT_Referencia varchar(50),ATT_IdSucursal int,ATT_IdContraReciboCliente int)
	
	EXEC sp_xml_removedocument @docHandle

	--SI ALGUNA FACTURA    
	SET @IdFactura = (SELECT TOP 1 IdFactura FROM ProFacturas WHERE (IdCliente != @IdCliente OR Estatus != 0 OR CanceladoEl IS NOT NULL OR ISNULL(Abonos,0) = Total) AND IdFactura IN(SELECT ATT_IdFactura FROM #TempProFacturas))
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)

		SET @MensajeError = 'La factura '+@DoctoFactura+' que esta intentando pagar no cumple con los criterios; Ya sea que no es de ese cliente, No tiene el estatus de pendiente de pago, Este cancelada o Ya fue pagada por otro usuario'

		RAISERROR(@MensajeError,
			16,
			1
			)
	END

		--SI ALGUNA FACTURA ESTA DENTRO DE UN CONTRA RECIBO SOLICITUD 10118
	SET @IdFactura = (select top 1 pcrcf.IdFactura from ProContraRecibosClienteFacturas as pcrcf
	inner join ProContraRecibosCliente as pcrc on pcrc.IdContraReciboCliente = pcrcf.IdContraReciboCliente
	where pcrcf.IdFactura IN (select ATT_IdFactura from #TempProFacturas) and pcrc.CanceladoEl is null)
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)

		--Se cambia mensaje de validacion para la solicitud 10118
		--SET @MensajeError = 'La factura '+@DoctoFactura+' que esta intentando pagar no cumple con los criterios; Ya sea que no es de ese cliente, No tiene el estatus de pendiente de pago, Este cancelada o Ya fue pagada por otro usuario'
		SET @MensajeError = 'No es posible aplicar el saldo a favor a la '+@DoctoFactura+', ya que se encuentra dentro de un contra recibo.'
		RAISERROR(@MensajeError,
			16,
			1
			)
	END
	--FIN DE VALIDACION PARA SABER SI LA FACTURA ESTA DENTRO DE UN CONTRA RECIBO



	SET @ImporteFacturas = 0
	--OBTIENE LOS IMPORTES DE LA FACTURAS PAGADAS PARA ACTULIAZAR SALDO DE CLIENTE
	SET @ImporteClienteDLLS = (SELECT ISNULL(SUM(ATT_Importe),0) FROM #TempProFacturas WHERE ATT_IdMoneda = 2)
	SET @ImporteClientePESOS = (SELECT ISNULL(SUM(ATT_Importe),0) FROM #TempProFacturas WHERE ATT_IdMoneda != 2)  
		
	IF @IdMonedaSaldoAFavor = 2 --DOLARES
	BEGIN
		IF @ImporteClientePESOS = 0
		BEGIN
			SET @ImporteFacturas = @ImporteClienteDLLS
		END
		ELSE
		BEGIN
			SET @ImporteFacturas = (@ImporteClientePESOS / @TipoCambio) + @ImporteClienteDLLS		
		END
	END
	ELSE
	BEGIN
		IF @ImporteClienteDLLS = 0
		BEGIN
			SET @ImporteFacturas = @ImporteClientePESOS
		END
		ELSE
		BEGIN
			SET @ImporteFacturas = (@ImporteClienteDLLS * @TipoCambio) + @ImporteClientePESOS			
		END		
	END
	
	-- Valida que el importe de las facturas a pagar no sea mayor que el saldo remanente del SALDO A FAVOR
	SET @SaldoActual = (SELECT ISNULL(Saldo,0) FROM ProCobranza WHERE IdCobranza = @IdCobranzaSaldoAFavor)
	SET @MensajeError = 'El Saldo a favor ya fue aplicado por otro usuario. Su saldo actual es: $ '+ CAST(@SaldoActual as varchar(20))
	IF (@SaldoActual - @ImporteFacturas) < -1
			RAISERROR(@MensajeError,
			16,
			1
			)
	
	-- Actualizar el Saldo remanente del SALDO A FAVOR
	UPDATE ProCobranza SET 
		Saldo = ISNULL(Saldo,0) - @ImporteFacturas
	WHERE IdCobranza = @IdCobranzaSaldoAFavor
	
	--- Registrar Beneficiario 
	SELECT @Beneficiario = NombreFiscal FROM CatClientes WHERE IdCliente = @IdCliente
	Select @IdBeneficiario = (Select IdBeneficiario  from CatBeneficiarios where RTRIM(LTRIM(Nombre)) = RTRIM(LTRIM(@Beneficiario)))
	IF  ISNULL(@IdBeneficiario ,0) = 0 
	BEGIN
		SELECT @NumeroBeneficiario = (SELECT ISNULL(MAX(NumeroBeneficiario),0)+1 AS Codigo FROM CatBeneficiarios)
		
		INSERT INTO CatBeneficiarios(NumeroBeneficiario,Nombre,CreadoEl,CreadoPor,Activo)
		VALUES(@NumeroBeneficiario,RTRIM(LTRIM(@Beneficiario)),@CreadoEl,@CreadoPor,1)
		
		SET @IdBeneficiario = (SELECT IDENT_CURRENT('CatBeneficiarios'))	   
	END
		
	DECLARE ProFacturasCursor CURSOR FOR
	SELECT ATT_IdFactura,ATT_IdMoneda,ATT_IdSucursal,ATT_Importe,ATT_Referencia, ATT_IdContraReciboCliente FROM #TempProFacturas WHERE ATT_Importe != 0
	OPEN ProFacturasCursor
	FETCH NEXT FROM ProFacturasCursor
	INTO @ATT_IdFactura,@ATT_IdMoneda,@ATT_IdSucursal,@ATT_Importe,@ATT_Referencia,@ATT_IdContraReciboCliente
	
	-- se obtiene el numero de la siguiente secuencia para la aplicacion del saldo a favor
	SET @SiguienteSecuencia = (SELECT Secuencia FROM ProCobranza WHERE IdCobranza = @IdCobranzaSaldoAFavor) + 1
	IF NOT EXISTS (SELECT IdParametroPagina from SisParametrosPagina where Pagina = 'ProCobranzaSaldosAFavorSecuencia' AND IdUsuario = @CreadoPor)
	BEGIN
		INSERT INTO SisParametrosPagina (Pagina,Parametros,IdUsuario) values ('ProCobranzaSaldosAFavorSecuencia',@SiguienteSecuencia,@CreadoPor)
	END
	ELSE
	BEGIN
		UPDATE SisParametrosPagina SET Parametros = @SiguienteSecuencia WHERE Pagina = 'ProCobranzaSaldosAFavorSecuencia' AND IdUsuario = @CreadoPor
	END
	
	--Actualiza el movimiento anterior (sustituido) Solicitud 8555
    IF @SecuenciaAnterior IS NOT NULL
		UPDATE ProCobranzaSaldosAFavorTimbrados SET IdSaldoAFavorAnterior = @IdCobranzaSaldoAFavor,SecuenciaAnterior = @SiguienteSecuencia  WHERE IdCobranzaSaldoAFavor = @IdCobranzaSaldoAFavor AND Secuencia = @SecuenciaAnterior
	
	--Se inserta en el auxiliar de ProCobranzaSaldosAFavorTimbrado
	
	INSERT INTO ProCobranzaSaldosAFavorTimbrados (IdCobranzaSaldoAFavor,Secuencia,IdMovimientoBancario,IdCertificado,Sustituto) VALUES (@IdCobranzaSaldoAFavor,@SiguienteSecuencia,(Select Top 1 IdMovimientoBancario From ProCobranza where IdCobranza = @IdCobranzaSaldoAFavor),@IdCertificado,@Sustituto)
	
	--Se obtiene el siguiente folio de aplicacion
	SET @SiguienteFoilo = (select max(FolioAplicacionSaldoAFavor)+1 from ProCobranza)
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdMovimientoBancario,IdSucursal,Importe,Referencia,TipoCambio,IdCobranzaSaldoAFavor,Secuencia,IdCertificado,FolioAplicacionSaldoAFavor)
		VALUES(@CreadoEl,@CreadoPor,@FechaHora,@IdCliente,@IdConceptoCobranza,@ATT_IdFactura,@ATT_IdMoneda,NULL,@ATT_IdSucursal,@ATT_Importe,@ATT_Referencia,@TipoCambio,@IdCobranzaSaldoAFavor,@SiguienteSecuencia,@IdCertificado,@SiguienteFoilo)
		
		SET @IdCobranza = (SELECT IDENT_CURRENT('ProCobranza'))
		--Se guarda @IdCobranza en parametros Pagina para obtenerlo del lado del web
		IF NOT EXISTS (SELECT IdParametroPagina from SisParametrosPagina where Pagina = 'ProCobranzaSaldosAFavorIdCobranza' AND IdUsuario = @CreadoPor)
		BEGIN
			INSERT INTO SisParametrosPagina (Pagina,Parametros,IdUsuario) values ('ProCobranzaSaldosAFavorIdCobranza',@IdCobranza,@CreadoPor)
		END
		ELSE
		BEGIN
			UPDATE SisParametrosPagina SET Parametros = @IdCobranza WHERE Pagina = 'ProCobranzaSaldosAFavorIdCobranza' AND IdUsuario = @CreadoPor
		END
		
		--valida si la factura es una factura general
        DECLARE @EsFactGeneral bit=0
        IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @ATT_IdFactura) = 7
			SET @EsFactGeneral = 1			
			
		--se obtiene el porcentaje del abono sobre el saldo antes de aplicarle el abono del movimiento
		SET @Porcentaje = (SELECT (CAST(@ATT_Importe AS decimal(15,7))/CAST((Total-ISNULL(Abonos,0)) AS decimal(15,7))) FROM ProFacturas WHERE IdFactura = @ATT_IdFactura)
			
			
		--actualizo el abono en facturas
		IF (SELECT FacturaExterna FROM ProFacturas WHERE  IdFactura  = @ATT_IdFactura )  = 1 
			RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
			16,
			1
			)
		UPDATE ProFacturas SET
			ProFacturas.Abonos = ISNULL(ProFacturas.Abonos,0) + @ATT_Importe,
			ProFacturas.Estatus = CASE WHEN (ISNULL(ProFacturas.Abonos,0)+ @ATT_Importe)= ProFacturas.Total THEN 1 ELSE ProFacturas.Estatus END,
			ProFacturas.ModificadoEl = @CreadoEl,
			ProFacturas.ModificadoPor = @CreadoPor
		WHERE IdFactura = @ATT_IdFactura                
					   
		--hago un cursor para afectar el abono a cada concepto de facturacion y obtener los importes base para el calculo de los impuestos                       
		DECLARE ProFacturasConceptosFacturacion CURSOR FOR
		SELECT IdFacturaConceptoFacturacion,RetieneImpuesto,TrasladaImpuesto FROM ProFacturasConceptosFacturacion WHERE IdFactura = @ATT_IdFactura
		
		OPEN ProFacturasConceptosFacturacion
		FETCH NEXT FROM ProFacturasConceptosFacturacion
		INTO @IdFacturaConceptoFacturacion,@Retiene,@Traslada
		
		SET @ImpuestosTrasladadosFederales = 0
		SET @ImpuestosRetenidosFederales = 0
		SET @ImpuestosGenerales = 0
		SET @ImpuestosTrasladadosLocales = 0
		SET @ImpuestosRetenidosLocales = 0

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @AbonoConcepto = (SELECT (Importe-ISNULL(Descuento,0)-ISNULL(Abonos,0))*@Porcentaje FROM ProFacturasConceptosFacturacion WHERE IdFacturaConceptoFacturacion = @IdFacturaConceptoFacturacion)
				
			UPDATE ProFacturasConceptosFacturacion SET
				Abonos = ISNULL(Abonos,0)+ROUND(@AbonoConcepto,4)
			WHERE IdFacturaConceptoFacturacion = @IdFacturaConceptoFacturacion
			
			INSERT INTO ProCobranzaFacturaConceptosFacturacion(IdFacturaConceptoFacturacion,IdCobranza,Importe)
			VALUES(@IdFacturaConceptoFacturacion,@IdCobranza,ROUND(@AbonoConcepto,4))
			
			IF @EsFactGeneral = 1
				SET @ImpuestosGenerales = @ImpuestosGenerales + @AbonoConcepto
			
			IF @Retiene = 1
				SET @ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales+@AbonoConcepto
				
			IF @Traslada = 1
				SET @ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales+@AbonoConcepto
		
			FETCH NEXT FROM ProFacturasConceptosFacturacion
			INTO @IdFacturaConceptoFacturacion,@Retiene,@Traslada
		END
		
		CLOSE ProFacturasConceptosFacturacion
		DEALLOCATE ProFacturasConceptosFacturacion
		
		IF @EsFactGeneral = 1
		BEGIN   
			DECLARE @IdImpuestoConcepto int,
			@PorcentajeImpuesto decimal(15,2)
			
			DECLARE ProFacturasImpuestosCursor CURSOR FOR
			SELECT IdImpuesto, Porcentaje,Importe FROM ProFacturasImpuestos WHERE IdFactura = @ATT_IdFactura
			
			OPEN ProFacturasImpuestosCursor
			FETCH NEXT FROM ProFacturasImpuestosCursor INTO @IdImpuestoConcepto, @PorcentajeImpuesto, @ATT_ImporteImpuestoFactura
			WHILE @@FETCH_STATUS = 0
			BEGIN
			
				DECLARE @PorcentajeIVA decimal(15,2),
				@TipoCalculo int,
				@NombreImpuestoXML varchar(10),
				@ImporteIVATraslado money, @ImporteImpuesto money
				
				SET @PorcentajeIVA = (SELECT Porcentaje FROM CatImpuestos WHERE IdImpuesto = @IdImpuestoConcepto)
				SET @TipoCalculo= (SELECT TipoCalculo FROM CatImpuestos WHERE IdImpuesto = @IdImpuestoConcepto)
				SET @NombreImpuestoXML = (SELECT NombreImpuestoXML FROM CatImpuestos WHERE IdImpuesto = @IdImpuestoConcepto)
				
				IF @TipoCalculo = 2 AND @NombreImpuestoXML = 'IVA'
					SET @ImporteImpuesto = (@ATT_ImporteImpuestoFactura * (@Porcentaje)) - ISNULL((Select
																										SUM(pci.Importe) AS Abonos
																										FROM
																										ProCobranzaImpuestos pci
																										WHERE pci.IdCobranza IN (
																											SELECT
																											pc.IdCobranza
																											FROM ProCobranza pc
																											WHERE
																											pc.IdFactura = @ATT_IdFactura /**/
																											AND pc.CanceladoEl IS NULL
																											AND pc.IdConceptoCobranza <> 1
																										) AND pci.IdImpuesto = @IdImpuestoConcepto/**/ ),0)
				ELSE
					BEGIN
						IF @TipoCalculo = 1 AND @NombreImpuestoXML = 'IVA'
						BEGIN
							SET @ImporteIVATraslado = (@ATT_ImporteImpuestoFactura * (@Porcentaje)) - ISNULL((Select
																										SUM(pci.Importe) AS Abonos
																										FROM
																										ProCobranzaImpuestos pci
																										WHERE pci.IdCobranza IN (
																											SELECT
																											pc.IdCobranza
																											FROM ProCobranza pc
																											WHERE
																											pc.IdFactura = @ATT_IdFactura /**/
																											AND pc.CanceladoEl IS NULL
																											AND pc.IdConceptoCobranza <> 1
																										) AND pci.IdImpuesto = @IdImpuestoConcepto/**/ ),0)
							SET @ImporteImpuesto = @ImporteIVATraslado
						END
						ELSE
							SET @ImporteImpuesto = (@ATT_ImporteImpuestoFactura * (@Porcentaje)) - ISNULL((Select
																										SUM(pci.Importe) AS Abonos
																										FROM
																										ProCobranzaImpuestos pci
																										WHERE pci.IdCobranza IN (
																											SELECT
																											pc.IdCobranza
																											FROM ProCobranza pc
																											WHERE
																											pc.IdFactura = @ATT_IdFactura /**/
																											AND pc.CanceladoEl IS NULL
																											AND pc.IdConceptoCobranza <> 1
																										) AND pci.IdImpuesto = @IdImpuestoConcepto/**/ ),0)
					END
					
				INSERT INTO ProCobranzaImpuestos(IdCobranza,IdImpuesto,Importe,CreadoPor,CreadoEl)
				VALUES(@IdCobranza,@IdImpuestoConcepto,@ImporteImpuesto,@CreadoPor,@CreadoEl)	
				
				FETCH NEXT FROM ProFacturasImpuestosCursor INTO @IdImpuestoConcepto, @PorcentajeImpuesto, @ATT_ImporteImpuestoFactura
			END
			
			CLOSE ProFacturasImpuestosCursor
			DEALLOCATE ProFacturasImpuestosCursor
		END
		ELSE
		BEGIN   		
				INSERT INTO ProCobranzaImpuestos(IdCobranza,IdImpuesto,Importe,CreadoPor,CreadoEl)
				SELECT @IdCobranza,pfi.IdImpuesto,
				((pfi.Importe*@Porcentaje)) - ISNULL((Select
					SUM(pci.Importe) AS Abonos
					FROM
					ProCobranzaImpuestos pci
					WHERE pci.IdCobranza IN (
						SELECT
						pc.IdCobranza
						FROM ProCobranza pc
						WHERE
						pc.IdFactura = pfi.IdFactura /**/
						AND pc.CanceladoEl IS NULL
						AND pc.IdConceptoCobranza <> 1
					) AND pci.IdImpuesto = ci.IdImpuesto/**/ ),0) AS ImporteT
				,@CreadoPor,@CreadoEl
				FROM ProFacturasImpuestos AS pfi
				INNER JOIN CatImpuestos AS ci ON pfi.IdImpuesto = ci.IdImpuesto
				WHERE pfi.IdFactura = @ATT_IdFactura                
		END
		
		IF @EsFactGeneral = 1
			BEGIN
				SET @ImpuestosTrasladadosFederales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 1 AND CatImpuestos.EsImpuestoFederal = 1)
				SET @ImpuestosRetenidosFederales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 2 AND CatImpuestos.EsImpuestoFederal = 1)
				SET @ImpuestosTrasladadosLocales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 1 AND CatImpuestos.EsImpuestoLocal = 1)
				SET @ImpuestosRetenidosLocales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 2 AND CatImpuestos.EsImpuestoLocal = 1)
				IF (SELECT CobranzaExterna FROM ProCobranza WHERE  IdCobranza  = @IdCobranza )  = 1
					RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
					16,
					1
					)
				--actualizo impuestos/importe sin iva en cobranza para el reporte de pagos
				UPDATE ProCobranza SET
					ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales,
					ImpuestosRetenidosLocales = @ImpuestosRetenidosLocales,
					ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales,
					ImpuestosTrasladadosLocales = @ImpuestosTrasladadosLocales,
					ImporteSinImpuestos = Importe - @ImpuestosTrasladadosFederales + @ImpuestosRetenidosFederales - @ImpuestosRetenidosLocales + @ImpuestosTrasladadosLocales
				WHERE IdCobranza = @IdCobranza
			END
        ELSE
			BEGIN
				SET @ImpuestosTrasladadosFederales = (SELECT sum(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 1)
				SET @ImpuestosRetenidosFederales = (SELECT sum(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 2)
				IF (SELECT CobranzaExterna FROM ProCobranza WHERE  IdCobranza  = @IdCobranza )  = 1 
					RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
					16,
					1
					)
				--actualizo impuestos/importe sin iva en cobranza para el reporte de pagos
				UPDATE ProCobranza SET
					ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales,
					ImpuestosRetenidosLocales = 0,
					ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales,
					ImpuestosTrasladadosLocales = 0,
					ImporteSinImpuestos = Importe - @ImpuestosTrasladadosFederales + @ImpuestosRetenidosFederales
				WHERE IdCobranza = @IdCobranza	
			END	
		
		FETCH NEXT FROM ProFacturasCursor
		INTO @ATT_IdFactura,@ATT_IdMoneda,@ATT_IdSucursal,@ATT_Importe,@ATT_Referencia,@ATT_IdContraReciboCliente
	END        
	
	CLOSE ProFacturasCursor
	DEALLOCATE ProFacturasCursor
	
	UPDATE ProCobranza SET 
		Secuencia = @SiguienteSecuencia 
	WHERE IdCobranza = @IdCobranzaSaldoAFavor
	
	--verificar que la suma de cobranza por factura sea igual a los abonos
	SET @IdFactura = 
	(SELECT TOP 1 pf.IdFactura FROM ProFacturas AS pf 
	INNER JOIN #TempProFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura 
	WHERE ISNULL(pf.Abonos,0) != 
		(SELECT ISNULL(SUM(pc.Importe),0) FROM ProCobranza AS pc 
			INNER JOIN CatConceptosCobranza AS ccc ON pc.IdConceptoCobranza = ccc.IdConceptoCobranza 
			LEFT JOIN ProMovimientosBancarios AS pmb ON pc.IdMovimientoBancario = pmb.IdMovimientoBancario
			WHERE ccc.TipoConcepto = 2 
			AND pc.IdFactura = pf.IdFactura 
			AND ((pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NULL AND pmb.CanceladoEl IS NULL) 
				OR (pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NOT NULL AND pmb.FechaCancelacionSAT IS NULL) 
				OR (pc.IdConceptoCobranza IN(3) AND pc.CanceladoEl IS NULL) 
				OR (pc.IdConceptoCobranza IN(6) AND pc.CanceladoEl IS NULL AND NOT EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor)) 
				OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND Secuencia=pc.Secuencia AND FolioFiscalUUIDPagos IS NOT NULL AND FechaCancelacionSAT IS NULL))
				OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND FolioFiscalUUIDPagos IS NULL AND pc.CanceladoEl IS NULL))
				)
		)
	)

	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
		WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
		ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)

		SET @MensajeError =    'El saldo de la factura1 '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago a esta factura.'
					
		RAISERROR(@MensajeError,
			16,
			1
			)            
	END

	--verificar que la suma de cobranza por factura sea igual a los abonos 
	--se agrega redondeo a 2 decimales
	SET @IdFactura = (SELECT TOP 1 pf.IdFactura FROM ProFacturasConceptosFacturacion AS pf INNER JOIN #TempProFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura WHERE (pf.Importe > 0 AND ISNULL(pf.Abonos,0) > round(pf.Importe,2)) OR (pf.Importe < 0 AND ISNULL(pf.Abonos,0) < round(pf.Importe,2)))
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)
	
		SET @MensajeError =    'El saldo de un concepto de la factura2 '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago o una nota de crédito a esta factura.'
					
		RAISERROR(@MensajeError,
			16,
			1
			)
	END
	
	--verificar que la suma de cobranza por factura sea igual a los abonos
	SET @IdFactura = (SELECT TOP 1 pf.IdFactura FROM ProFacturas AS pf INNER JOIN #TempProFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura WHERE ISNULL(pf.Abonos,0) > pf.Total)
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)
	
		SET @MensajeError =    'El saldo de la factura '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago a esta factura.'
					
		RAISERROR(@MensajeError,
			16,
			1
			)
	END       
	
	UPDATE CatClientes SET 
		SaldoCredito = SaldoCredito - @ImporteClientePESOS,
		SaldoCreditoDLLS = SaldoCreditoDLLS - @ImporteClienteDLLS
	WHERE IdCliente = @IdCliente

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

