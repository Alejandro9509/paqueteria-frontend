
CREATE PROCEDURE [dbo].[usp_CatPuestosEliminarPQ](
	@IdPuesto INT)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdPuesto,0) <= 0 begin
			RAISERROR(N'*INICIO*El Identidicador de Puesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		DELETE FROM CatPuestos
		WHERE IdPuesto = @IdPuesto
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

