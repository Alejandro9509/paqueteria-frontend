CREATE PROCEDURE [dbo].[usp_ProReportesFallasImagenesAgregarXML]
	@IdReporteFalla  int,
	@dsReporteFalla XML,
	@IdPeticion varchar(100)
	/*************************************************************************************************************************************
	@IdReporteFalla int  Id del proceso ,
	@dsXMl XML  XMl , Archivo con los datos de la imagen/documento,
	@IdPeticion varchar(100)

	Creado por:  Enrique Ramos Alvarez
	Fecha de Creacion: 31/01/2020
	Versión: V8 8.0.49.23
	Solicitud 633

	Modificado por: Enrique 
	Fecha de Modificacion:  13/02/2020
	Versión: 8.0.49.35

	Modificado por: Enrique Ramos Alvarez
	Fecha de Modificacion:  19/02/2020
	Versión: 8.0.50.06 

	Se creo para guardar los datos de los archivos en base de datos 
	***************************************/
AS
DECLARE @TemporalXML TABLE
(	
NombreArchivo varchar(300) ,
DescripcionArchivo varchar(150),
Obs bit 
)

BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL( @IdReporteFalla,0) = 0
		RAISERROR(N'Identificador de la orden de servicio es un campo requerido',
			16,
			1
			)

INSERT INTO @TemporalXML (NombreArchivo,DescripcionArchivo,Obs)
Select  
 NombreArchivo = Node.Data.value('(ATT_ImagenNombreArchivo)[1]', 'VARCHAR(MAX)')
,DescripcionArchivo =Node.Data.value('(ATT_Descripcion)[1]', 'VARCHAR(MAX)') 
,Obs =Node.Data.value('(ATT_Obs)[1]', 'BIT') 
FROM   @dsReporteFalla.nodes('/WEBDEV_TABLE/Imagenes') Node(Data) 


Update @TemporalXML
set Obs = 0
where NombreArchivo not like '%GMTRPV8/Permanentes%'

Update @TemporalXML
set Obs = 1
where NombreArchivo like '%GMTRPV8/Permanentes%'

DELETE FROM ProReportesFallasImagenes where IdReporteFalla =  @IdReporteFalla

INSERT into ProReportesFallasImagenes(IdReporteFalla,ImagenNombreArchivo,Descripcion,Obs) 
Select  

 @IdReporteFalla,
NombreArchivo
,DescripcionArchivo 
,Obs
FROM @TemporalXML

COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

