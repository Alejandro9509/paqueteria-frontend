create PROCEDURE [dbo].[usp_ProServiciosProgramadosGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProServiciosProgramados
go

