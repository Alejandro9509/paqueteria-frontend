CREATE  PROCEDURE [dbo].[usp_ProMovimientosBancariosTraspasosRegistrar]  
	@IdCuentaBancariaOrigen int,  
	@NumeroMovimientoOrigen int,  
	@IdCuentaBancariaDestino int,  
	@NumeroMovimientoDestino int,   
	@Fecha datetime,
	@TipoCambio money,  
	@Importe money,  
	@ReferenciaBancaria varchar(150),  
	@CreadoPor int,  
	@CreadoEl datetime,  
	@IdPeticion varchar(100),   
	@Beneficiario varchar(150),
	@ImporteDestino money,
	@TipoPago INT,
	@FechaCobro datetime

/* *************************************************************************************************
Procedimiento usp_ProMovimientosBancariosTraspasosRegistrar

Parámetros: 
	@IdCuentaBancariaOrigen (entrada, entero). Identificador de la cuenta bancaria origen
	@IdMovimientoBancarioDestino (entrada, entero). Identificador de la cuenta destino 
	@IdCuentaBancariaDestino (entrada, entero). Identificador de la cuenta destino
	@Fecha (entrada, Fecha). Fecha del traspaso  
	@TipoCambio (entrada, moneda). Tipo de cambio
	@Importe (entrada, moneda). Importe del traspaso
	@ReferenciaBancaria (entrada, texto). Referencia del traspaso 
	@CreadoPor (entrada, entero). Usuario que crea
	@CreadoEl (entrada, fecha hora). Fecha y hora de creacion
	@IdPeticion (entrada, string). Id de la Petición, generada en WEBDEV
	@ImporteDestino (entrada, moneda). Importe del traspaso destino
	@TipoPago (entrada, entero). Tipo de pago
	@FechaCobro (entrada, fecha). Fecha de cobro

Descripción: Procedimiento para registrar un traspaso

06/11/2020 - Se agrego el flujo de asignarle una fecha de cobro a los movimientos bancarios y cheques

Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 06/11/2020
Versión ERP: 8.0.56.12

Invocada desde: PAGE_ProMovimientosBancariosTraspasosRM (Solicitud 3393)
***************************************************************************************************** */
AS  
DECLARE   
	@IdTipoMovimientoBancarioOrigen int,  
	@IdTipoMovimientoBancarioDestino int,   
	@IdMonedaOrigen int,
	@IdMonedaDestino int,  
	@IdDolar int,   
	@NoCuntaBancariaOrigen varchar(15),  
	@NoCuntaBancariaDestino varchar(15),  
	@IdMovimientoBancarioOrigen int,  
	@IdMovimientoBancarioDestino int,  
	@IdBeneficiario int,  
	@NumeroBeneficiario int,
	@IdMovimientoBancarioTraspaso   int
BEGIN TRY  
	BEGIN TRANSACTION
	
	SET @IdDolar = 2  
	IF ISNULL(@IdCuentaBancariaOrigen,0) = 0  
	RAISERROR(N'El identificador de cuenta bancaria origen es un campo requerido', 16, 1)  

	IF ISNULL(@NumeroMovimientoOrigen,0) = 0  
	RAISERROR(N'El número de movimiento origen es un campo requerido', 16, 1)  
  
	IF ISNULL(@IdCuentaBancariaDestino,0) = 0  
	RAISERROR(N'El identificador de cuenta bancaria origen es un campo requerido', 16, 1)  
  
	IF ISNULL(@NumeroMovimientoDestino,0) = 0  
	RAISERROR(N'El número de movimiento destino es un campo requerido', 16, 1)  
  
	IF @IdCuentaBancariaOrigen = @IdCuentaBancariaDestino   
	RAISERROR(N'Las cuentas no pueden ser iguales', 16, 1)  
      
	IF ISNULL(@Fecha,'')= ''  
	RAISERROR(N'Fecha es un campo requerido', 16, 1)  

	IF ISNULL(@FechaCobro,'')= ''  
	RAISERROR(N'Fecha de cobro es un campo requerido', 16, 1)  
  
	IF ISNULL(@TipoCambio,0)= 0  
	RAISERROR(N'Tipo de cambio es un campo requerido', 16, 1)  
   
	IF ISNULL(@ReferenciaBancaria,'')= ''  
	RAISERROR(N'El Referencia bancaria es un campo requerido', 16, 1)  
  
	IF ISNULL(@Importe,0)= 0  
	RAISERROR(N'El Importe es un campo requerido', 16, 1)  

	 --- Registrar Beneficiario   
	SELECT @IdBeneficiario = (Select IdBeneficiario  from CatBeneficiarios where RTRIM(LTRIM(Nombre)) = RTRIM(LTRIM(@Beneficiario)))
	IF ISNULL(@IdBeneficiario ,0) = 0   
	BEGIN  
		SELECT @NumeroBeneficiario = (SELECT ISNULL(MAX(NumeroBeneficiario),0)+1 AS Codigo FROM CatBeneficiarios)  
		INSERT INTO CatBeneficiarios(NumeroBeneficiario,Nombre,CreadoEl,CreadoPor,Activo)  
		VALUES(@NumeroBeneficiario,RTRIM(LTRIM(@Beneficiario)),@CreadoEl,@CreadoPor,1)  
		SET @IdBeneficiario = (SELECT IDENT_CURRENT('CatBeneficiarios'))      
	END  
  
	--- Se traslada a la cuenta   
	SET @NoCuntaBancariaDestino = (Select NumeroCuenta from CatCuentasBancarias where IdCuentaBancaria = @IdCuentaBancariaDestino)  
   
	-- Si el tipo de pago es por transferencia tiene que generar el Movimiento Bancario. Si es por cheque ya fue generado en su procedimiento
	IF @TipoPago = 1
	BEGIN
		--- Registrar Movimiento Bancario Traspaso Origen  
		SET @IdMonedaOrigen =(SELECT IdMoneda FROM CatCuentasBancarias WHERE  CatCuentasBancarias.IdCuentaBancaria =@IdCuentaBancariaOrigen)  
		SET @IdTipoMovimientoBancarioOrigen = (SELECT IdTipoMovimientoBancario FROM  CatTiposMovimientosBancarios WHERE Codigo = 3)   
		IF ISNULL(@IdTipoMovimientoBancarioOrigen, 0) = 0  
			RAISERROR(N'Tipo de movimiento bancario origen es un campo requerido', 16, 1)

		INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,TipoCambio,ReferenciaBancaria,IdTipoMovimientoBancario,CreadoPor,CreadoEl,TipoBeneficiario,IdBeneficiario,Beneficiario,FechaCobro)
		VALUES (@NumeroMovimientoOrigen,@Fecha,@IdCuentaBancariaOrigen,@Importe,@TipoCambio,@ReferenciaBancaria,@IdTipoMovimientoBancarioOrigen,@CreadoPor,@CreadoEl,2,@IdBeneficiario,RTRIM(LTRIM(@Beneficiario)),@FechaCobro)

		SET @IdMovimientoBancarioOrigen = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))
	END
	ELSE
	BEGIN
		-- Se obtiene el Id del movimiento bancario generado por Cheque
		SET @IdMovimientoBancarioOrigen = (SELECT TOP 1 IdMovimientoBancario FROM ProMovimientosBancarios WHERE NumeroMovimiento = @NumeroMovimientoOrigen ORDER BY CreadoEl DESC)
	END

	--- Se recibe  de la cuenta  
	SET @NoCuntaBancariaOrigen = (Select NumeroCuenta from CatCuentasBancarias where IdCuentaBancaria = @IdCuentaBancariaOrigen)  
  
	--- Registrar Movimiento Bancario Traspaso Destino  
	SET @IdMonedaDestino =(SELECT IdMoneda FROM CatCuentasBancarias WHERE  CatCuentasBancarias.IdCuentaBancaria = @IdCuentaBancariaDestino)  
	SET @IdTipoMovimientoBancarioDestino =(SELECT IdTipoMovimientoBancario FROM  CatTiposMovimientosBancarios WHERE Codigo = 4)  
	IF ISNULL(@IdTipoMovimientoBancarioDestino,0) = 0  
	RAISERROR(N'Tipo de movimiento bancario destino es un campo requerido', 16, 1) 
	
	INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,TipoCambio,ReferenciaBancaria,IdTipoMovimientoBancario,CreadoPor,CreadoEl,TipoBeneficiario,IdBeneficiario,Beneficiario,FechaCobro)  
	VALUES (@NumeroMovimientoDestino,@Fecha,@IdCuentaBancariaDestino,@ImporteDestino,@TipoCambio,@ReferenciaBancaria,@IdTipoMovimientoBancarioDestino,@CreadoPor,@CreadoEl,2,@IdBeneficiario,RTRIM(LTRIM(@Beneficiario)),@FechaCobro)
   
	SET @IdMovimientoBancarioDestino= (SELECT IDENT_CURRENT('ProMovimientosBancarios'))       
   
	 --- Se registra translado  
	INSERT INTO ProMovimientosBancariosTraspasos (IdMovimientoBancarioOrigen,IdMovimientoBancarioDestino,CreadoPor,CreadoEl,TipoPago)  
	VALUES (@IdMovimientoBancarioOrigen,@IdMovimientoBancarioDestino,@CreadoPor,@CreadoEl,@TipoPago)  

	SET @IdMovimientoBancarioTraspaso = (SELECT IDENT_CURRENT('ProMovimientosBancariosTraspasos'))

	--seccion para agregar el IdMovimientoBancarioTraspaso a paremtros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancarioTraspaso' AND IdUsuario = @CreadoPor)
		INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoBancarioTraspaso',@IdMovimientoBancarioTraspaso,@CreadoPor)
	ELSE
		UPDATE SisParametrosPagina SET Parametros = @IdMovimientoBancarioTraspaso WHERE Pagina = 'IdMovimientoBancarioTraspaso' AND IdUsuario = @CreadoPor  
	
	COMMIT  
END TRY  
BEGIN CATCH  
	ROLLBACK  
	EXECUTE usp_SisErrorsGrabar @IdPeticion  
END CATCH
go

