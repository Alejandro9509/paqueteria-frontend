

CREATE PROCEDURE [dbo].[usp_CatSalariosMinimosAgregar]
@Ejercicio datetime,
@SalarioMinimo decimal(10,4),
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100)
AS
BEGIN TRY
    BEGIN TRANSACTION
    --Validar si el ejercicio ya está registrado 
	IF EXISTS(Select * FROM CatSalariosMinimos where YEAR(Ejercicio) = YEAR(@Ejercicio))
			RAISERROR(N'No se permiten registros con el ejercicio duplicado',
				16,
				1
				)	
								
    INSERT INTO CatSalariosMinimos(Ejercicio,SalarioMinimo,CreadoPor,CreadoEl)
    VALUES(@Ejercicio,@SalarioMinimo,@CreadoPor,@CreadoEl)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

