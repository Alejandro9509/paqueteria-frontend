CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosGrabarAckCancelacion]
	@IdMovimientoBancario int,
	@AckCancelacion ntext,
	@FechaCancelacionSAT datetime,
	@EstatusUUID varchar(50),
	@IdPeticion varchar(100),
	@CanceladoPor int,
	@SATComprobanteEsCancelable varchar(30) = NULL,
	@SATComprobanteEstado varchar(20) = NULL,
	@SATComprobanteEstatusCancelacion varchar(30) = NULL,
	@SATComprobanteFechaHoraEnvioSolicitud datetime = NULL

AS
DECLARE
	@CanceladoEl datetime,
	@SATCanceladoPor int,
	@MotivoCancelacion varchar(500),
	@CanceladoElSistema datetime,
	@EsContrarecibo bit = 0

BEGIN TRY
	BEGIN TRANSACTION
		
	IF EXISTS(SELECT IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdMovimientoBancario = @IdMovimientoBancario AND EstatusUUID IS NOT NULL AND AckCancelacionSAT IS NOT NULL AND FechaCancelacionSAT IS NOT NULL)
		RAISERROR(N'No se puede cancelar este recibo de pago porque ya está cancelado en el SAT',
			16,
			1
			)
				

	UPDATE ProMovimientosBancarios
	SET AckCancelacionSAT = @AckCancelacion,
	FechaCancelacionSAT = @FechaCancelacionSAT,
	EstatusUUID = @EstatusUUID,
	SATComprobanteEsCancelable = @SATComprobanteEsCancelable,
	SATComprobanteEstado = @SATComprobanteEstado,
	SATComprobanteEstatusCancelacion = @SATComprobanteEstatusCancelacion,
	SATComprobanteFechaHoraEnvioSolicitud = @SATComprobanteFechaHoraEnvioSolicitud
	WHERE IdMovimientoBancario = @IdMovimientoBancario
	
	IF @SATComprobanteEstatusCancelacion = 'En proceso'
	BEGIN
		IF NOT EXISTS (SELECT IdProcesoLigado FROM ProDocumentosEnProcesoCancelacionSAT Where IdProcesoLigado = @IdMovimientoBancario AND ProcesoLigado = 'ProMovimientosBancarios' AND EnProceso = 1)
		INSERT INTO ProDocumentosEnProcesoCancelacionSAT(IdProcesoLigado,ProcesoLigado,EnProceso,SATCanceladoPor) VALUES (@IdMovimientoBancario,'ProMovimientosBancarios',1,@CanceladoPor)
	END
	
	BEGIN
		IF @SATComprobanteEstatusCancelacion IN ('Cancelado con aceptación','Plazo vencido','Solicitud rechazada')
		BEGIN
			UPDATE ProDocumentosEnProcesoCancelacionSAT SET EnProceso = 0 Where IdProcesoLigado = @IdMovimientoBancario AND ProcesoLigado = 'ProMovimientosBancarios'

			IF 	@SATComprobanteEstatusCancelacion = ('Solicitud Rechazada')
			BEGIN
				UPDATE ProMovimientosBancarios SET 
				CanceladoEl = NULL,
				CanceladoPor = NULL,
				MotivoCancelacion = NULL --Se agregó el motivo de cancelación dentro del Movimineto Bancario
				WHERE IdMovimientoBancario = @IdMovimientoBancario	
		
				UPDATE ProCobranza SET
				CanceladoEl = NULL,
				CanceladoPor = NULL,
				CanceladoElSistema = NULL,
				MotivoCancelacion = NULL
				WHERE IdMovimientoBancario = @IdMovimientoBancario	
			END
		END
	END

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

