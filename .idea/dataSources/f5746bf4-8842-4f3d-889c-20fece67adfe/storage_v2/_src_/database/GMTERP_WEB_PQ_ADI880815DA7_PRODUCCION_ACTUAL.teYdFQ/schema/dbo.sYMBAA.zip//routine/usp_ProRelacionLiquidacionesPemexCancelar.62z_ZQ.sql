
CREATE PROC [dbo].[usp_ProRelacionLiquidacionesPemexCancelar]
	@IdRelacionLiquidacionPemex int,
	@Estatus int,
	@CanceladoEl datetime,
	@CanceladoPor int,
	@Motivo varchar(50),
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_ProRelacionLiquidacionesPemexCancelar

Parámetros:
	@IdRelacionLiquidacionPemex    (entrada, entero). Id de la Relación Liquidación PEMEX.
	@Estatus                       (entrada, entero). Indica el estado de la Relación.
    @CanceladoEl				   (entrada, fecha hora). Fecha y hora en la que fue cancelado el registro.
    @CanceladoPor				   (entrada, entero). Id del usuario que cancelado el registro.
	@Motivo                        (entrada, string). Descripción del motivo de la cancelación.
    @IdPeticion				       (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para cancelar una nueva Relación Liquidación PEMEX.

06/03/2020 - Se creó.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 06/03/2020
Versión ERP: 8.0.50.32

Invocada desde: PAGE_ProRelacionLiquidacionPemexListado (Solicitud 922)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
	-- Validaciones
	IF @IdRelacionLiquidacionPemex = 0
		RAISERROR(N'El Id de la relación de liquidación es un campo requerido', 16, 1)

	IF @Estatus IN (2,3)
		RAISERROR(N'El número de relación se encuentra facturado, no es posible cancelar', 16, 1)

	IF ISNULL(@Motivo, '') = ''
		RAISERROR(N'El motivo de cancelación es un campo requerido', 16, 1)

	-- Actualiza los registros de la tabla puente para desligar las carta porte
	UPDATE ProRelacionLiquidacionesPemexDetalle SET
	CanceladoEl = @CanceladoEl,
	CanceladoPor = @CanceladoPor
	WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex

	-- Actualiza el registro de relación liquidación
	UPDATE ProRelacionLiquidacionesPemex SET 
	Estatus = 4,
	ModificadoEl = @CanceladoEl,
	ModificadoPor = @CanceladoPor,
	FechaCancelacion = @CanceladoEl,
	MotivoCancelacion = @Motivo
	WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

