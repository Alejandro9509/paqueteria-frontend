CREATE PROCEDURE [dbo].[usp_ProComprasCancelar]
@IdCompra int,
@Estatus tinyint,
@FechaCancelacion datetime,
@MotivoCancelacion varchar(500),
@CanceladoEl datetime,
@CanceladoPor int,
@IdPeticion varchar(100)

/* **********************************************************************
SOLICITUD 99

Descripcion: Se modifico para permitir la cancelacion de compras con articulos de tipo llanta

Modificada por: Ignacio Perez
Fecha de modificacion: 20/08/2019
Version: Versión 8.0.45.25

Invocada desde: ClsProCompras Metodo Cancelar()
************************************************************************* */
AS
DECLARE 
@IdTipoMovimientoAlmacen int,
@ATT_IdOrdenCompraConcepto int,
@CostoPromedioActual money,
@CostoPromedioActualDlls money,
@IdMovimientoAlmacen int, 
@IdMoneda int,
@TipoCambio money,
@ExistenciaActual decimal(15,4),
@ImporteTotalPromedioActual money,
@ImporteTotalPromedioActualDlls money,
@FolioMovimientoAlmacen int,
@IdPasivo int,
@EstatusParcialmenteSurtida int,
@EstatusAutorizada int,
@EsLlanta bit,
@ReferenciaCompra varchar(500)
BEGIN TRY
	BEGIN TRANSACTION
	SET @EstatusParcialmenteSurtida = 3
	SET @EstatusAutorizada = 9
	SET @EsLlanta = 1
	
	IF ISNULL(@IdCompra,0) = 0
		RAISERROR(N'El identificador de la compra es un campo requerido',
			16,
			1
			)

	IF (SELECT FechaHora FROM ProCompras WHERE IdCompra = @IdCompra) > @FechaCancelacion
		RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de elaboración',
			16,
			1
			)

	IF (SELECT Estatus FROM ProCompras WHERE IdCompra = @IdCompra) = 1--cerrada
		RAISERROR(N'No puede cancelar esta compra porque está cerrada',
			16,
			1
			)

	IF (SELECT Estatus FROM ProCompras WHERE IdCompra = @IdCompra) = 2--cancelada
		RAISERROR(N'No puede cancelar esta compra porque está cancelada',
			16,
			1
			)
			
	IF (SELECT CanceladoEl FROM ProCompras WHERE IdCompra = @IdCompra) IS NOT NULL --cancelado
		RAISERROR(N'No puede cancelar esta compra porque está cancelada',
			16,
			1
			)			

	IF LTRIM(RTRIM(@MotivoCancelacion)) = ''
		RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)
	-- Validar movimiento de salida registrada partidas de la orden de compra
	IF (SELECT SUM(pmacpeps.Cantidad) As Cantidad
			FROM ProMovimientosAlmacen As pma
				INNER JOIN ProMovimientosAlmacenConceptos  As pmac
				ON pma.IdMovimientoAlmacen = pmac.IdMovimientoAlmacen 
				INNER JOIN ProMovimientosAlmacenConceptosPEPS as pmacpeps 
				ON pmac.IdMovimientoAlmacenConcepto = pmacpeps.IdMovimientoAlmacenConceptoEntrada
				WHERE pma.IdCompra = @IdCompra) > 0
		RAISERROR(N'No puede cancelar esta compra porque tiene registrado movimiento de salida de almacén',
				16,
				1
				)					
	
	SELECT @IdMoneda=IdMoneda,@TipoCambio=TipoCambio FROM ProCompras WHERE IdCompra = @IdCompra
					
	-- Registrar cancelación de compra
	UPDATE ProCompras
	SET Estatus = @Estatus,
		FechaCancelacion = @FechaCancelacion, 
		MotivoCancelacion = @MotivoCancelacion,	
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		ModificadoEl = @CanceladoEl,
		ModificadoPor = @CanceladoPor
	WHERE IdCompra = @IdCompra
	
	-- Tipo Movimiento almacen [11] = Entrada por Devolución.
	SELECT @IdTipoMovimientoAlmacen = IdTipoMovimientoAlmacen 
		FROM CatTiposMovimientosAlmacen WHERE Codigo = 11
	
	DECLARE @IdMovimientoAlmacenPorCompra int
	SET @IdMovimientoAlmacenPorCompra = (Select IdMovimientoAlmacen From ProMovimientosAlmacen where IdCompra = @IdCompra And IdTipoMovimientoAlmacen =  1)	
	--SE ELIMINA LOS ARTICULOS DETALLADOS SOLICITUD 12324
	DELETE ProMovimientosAlmacenDetallado WHERE IdMovimientoAlmacen = @IdMovimientoAlmacenPorCompra

	--SE ELIMINA LOS ARTICULOS LLANTA SOLICITUD 99
	DELETE ProLlantas WHERE IdCompra = @IdCompra

	-- Registrar movimiento de almacen 
	SET @FolioMovimientoAlmacen  = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)
	SET @ReferenciaCompra ='SE CANCELA EL MOVIMIENTO DE ALMACEN, FOLIO: '+cast((@FolioMovimientoAlmacen) AS VARCHAR(10))+', DE LA FECHA '+CONVERT(varchar, CONVERT(datetime, (select FechaHora FROM ProMovimientosAlmacen where IdMovimientoAlmacen = @IdMovimientoAlmacenPorCompra)), 103)
	INSERT INTO ProMovimientosAlmacen(
		Estatus,FechaHora,
		IdProveedor,Folio,
		IdMoneda,Observaciones,SubTotal,
		SubTotalDlls,TipoCambio,
		Total,TotalDlls,
		IdImpuestosTrasladadosFederales,
		ImpuestosTrasladadosFederales,
		ImpuestosTrasladadosFederalesDlls,
		IdImpuestosRetenidosFederales,
		ImpuestosRetenidosFederales,
		ImpuestosRetenidosFederalesDlls,
		IdImpuestosTrasladadosLocales,
		ImpuestosTrasladadosLocales,
		ImpuestosTrasladadosLocalesDlls,
		IdImpuestosRetenidosLocales,
		ImpuestosRetenidosLocales,
		ImpuestosRetenidosLocalesDlls,
		IdTipoMovimientoAlmacen,IdCompra,CreadoEl,CreadoPor,Referencia)
	SELECT 
		Estatus,
		FechaHora,
		IdProveedor,
		@FolioMovimientoAlmacen,
		IdMoneda,
		Observaciones,
		-ISNULL(SubTotal,0),
		-ISNULL(SubTotalDlls,0),
		TipoCambio,
		-ISNULL(Total,0),
		-ISNULL(TotalDlls,0),
		IdImpuestosTrasladadosFederales,
		-ISNULL(ImpuestosTrasladadosFederales,0), 
		-ISNULL(ImpuestosTrasladadosFederalesDlls,0), 
		IdImpuestosRetenidosFederales,
		-ISNULL(ImpuestosRetenidosFederales,0), 
		-ISNULL(ImpuestosRetenidosFederalesDlls,0), 
		IdImpuestosTrasladadosLocales,
		-ISNULL(ImpuestosTrasladadosLocales,0), 
		-ISNULL(ImpuestosTrasladadosLocalesDlls,0), 
		IdImpuestosRetenidosLocales,
		-ISNULL(ImpuestosRetenidosLocales,0),
		-ISNULL(ImpuestosRetenidosLocalesDlls,0),
		@IdTipoMovimientoAlmacen,@IdCompra,@CanceladoEl,@CanceladoPor,@ReferenciaCompra
     FROM ProMovimientosAlmacen where IdMovimientoAlmacen = @IdMovimientoAlmacenPorCompra
	
	SET @IdMovimientoAlmacen = (SELECT IDENT_CURRENT('ProMovimientosAlmacen'))
	
	-- Registrar detalle de movimiento
	-- Crear cursor
	DECLARE @ATT_IdArticulo int,
			@ATT_Cantidad decimal(15,4),
			@ATT_Entregado decimal(15,4),
			@ATT_Pendiente decimal(15,4),
			@ATT_PrecioUnitario decimal(19,6),
			@ATT_PrecioUnitarioDlls decimal(19,6),
			@ATT_Importe money,
			@ATT_ImporteDlls money,
			@ATT_UnidadMedida varchar(30),
			@ATT_IdOrdenCompra int,
			@ATT_IdAlmacen int,
			@ATT_Observacion varchar(256)
	DECLARE TempProComprasConceptos CURSOR Local FOR 
	SELECT  IdArticulo,
			Cantidad,
			Entregado,
			Pendiente,
			CASE @IdMoneda WHEN 1 THEN PrecioUnitario WHEN 2 THEN PrecioUnitario * @TipoCambio END As PrecioUnitario,
			CASE @IdMoneda WHEN 1 THEN PrecioUnitario/@TipoCambio WHEN 2 THEN PrecioUnitario END As PrecioUnitarioDlls,
			CASE @IdMoneda WHEN 1 THEN Importe WHEN 2 THEN Importe* @TipoCambio END As Importe,
			CASE @IdMoneda WHEN 1 THEN Importe/@TipoCambio WHEN 2 THEN Importe END As  ImporteDlls,
			UnidadMedida,IdOrdenCompra,IdAlmacen,Observacion 	
	FROM ProComprasConceptos  WHERE ProComprasConceptos.IdCompra =  @IdCompra

	OPEN TempProComprasConceptos
	FETCH NEXT FROM TempProComprasConceptos INTO 
		@ATT_IdArticulo,
		@ATT_Cantidad,
		@ATT_Entregado,
		@ATT_Pendiente,
		@ATT_PrecioUnitario,
		@ATT_PrecioUnitarioDlls,
		@ATT_Importe,
		@ATT_ImporteDlls,
		@ATT_UnidadMedida,
		@ATT_IdOrdenCompra,
		@ATT_IdAlmacen,
		@ATT_Observacion

	WHILE @@fetch_status = 0
		BEGIN

		SELECT @ATT_IdOrdenCompraConcepto = IdOrdenCompraConcepto
				FROM ProOrdenCompraConceptos 
				WHERE ProOrdenCompraConceptos.IdOrdenCompra =  @ATT_IdOrdenCompra
					  AND ProOrdenCompraConceptos.IdArticulo =	@ATT_IdArticulo
					  
			-- Actualizar cantidad de conceptos de la orden de compra	
		UPDATE ProOrdenCompraConceptos 
				SET Entregado = Entregado-@ATT_Entregado,
					Pendiente = Pendiente + @ATT_Entregado
				WHERE ProOrdenCompraConceptos.IdOrdenCompraConcepto = @ATT_IdOrdenCompraConcepto
				  
			-- Cambiar de estatus de la orden de compra
		IF exists(SELECT * FROM (  
									SELECT SUM(Cantidad) AS Cantidad, SUM(Pendiente) AS Pendiente
									FROM ProOrdenCompraConceptos
									WHERE ProOrdenCompraConceptos.IdOrdenCompra = @ATT_IdOrdenCompra) 
							AS TEMP WHERE TEMP.Cantidad=TEMP.Pendiente)
					 UPDATE ProOrdenCompra SET Estatus = @EstatusAutorizada WHERE IdOrdenCompra = @ATT_IdOrdenCompra
					ELSE
					 UPDATE ProOrdenCompra SET Estatus = @EstatusParcialmenteSurtida WHERE IdOrdenCompra = @ATT_IdOrdenCompra

		-- Registrar costo y existencia.
		SELECT  @ExistenciaActual = Existencia ,
						@ImporteTotalPromedioActual = ImporteTotalPromedio,
						--Dolares
						@ImporteTotalPromedioActualDlls = ImporteTotalPromedioDlls
				FROM ProInventarioAlmacen
				WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo			
				
				SET @ExistenciaActual = @ExistenciaActual-@ATT_Entregado
				IF @ExistenciaActual =0 
					BEGIN
						SET @CostoPromedioActual = 0
						SET @ImporteTotalPromedioActual = 0
						--Dolares
						SET @CostoPromedioActualDlls = 0
						SET @ImporteTotalPromedioActualDlls = 0
					END
					ELSE
					BEGIN
						SET @CostoPromedioActual = (@ImporteTotalPromedioActual-@ATT_Importe)/@ExistenciaActual
						SET @ImporteTotalPromedioActual = @ExistenciaActual*@CostoPromedioActual 
						--Dolares
						SET @CostoPromedioActualDlls = (@ImporteTotalPromedioActualDlls-@ATT_ImporteDlls)/@ExistenciaActual
						SET @ImporteTotalPromedioActualDlls = @ExistenciaActual*@CostoPromedioActualDlls
					END	
		   -- Registrar costo
					UPDATE ProInventarioAlmacen
							 SET  Existencia = @ExistenciaActual,
								  CostoPromedio=@CostoPromedioActual,
								  ImporteTotalPromedio=@ImporteTotalPromedioActual,
								  --Dolares
								  CostoPromedioDlls=@CostoPromedioActualDlls,
								  ImporteTotalPromedioDlls=@ImporteTotalPromedioActualDlls,
								  ModificadoEl= @CanceladoEl,
								  ModificadoPor = @CanceladoPor
						WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo	
				
			--  Registrar detalle de movimiento
			INSERT INTO ProMovimientosAlmacenConceptos (IdArticulo,
							Cantidad,PrecioUnitario,PrecioUnitarioDlls,Importe,ImporteDlls,
							UnidadMedida,IdAlmacen,CreadoPor,CreadoEl,IdMovimientoAlmacen,ExistenciaControlPEPS,
							CostoPromedio,CostoPromedioDlls)
				VALUES	(@ATT_IdArticulo,-@ATT_Entregado,@ATT_PrecioUnitario,
							 @ATT_PrecioUnitarioDlls,-@ATT_Importe,-@ATT_ImporteDlls,@ATT_UnidadMedida,
							 @ATT_IdAlmacen,@CanceladoPor,
							 @CanceladoEl,@IdMovimientoAlmacen,
							 0,@CostoPromedioActual,@CostoPromedioActualDlls)
			--
		   FETCH NEXT FROM TempProComprasConceptos INTO @ATT_IdArticulo,
														@ATT_Cantidad,
														@ATT_Entregado,
														@ATT_Pendiente,
														@ATT_PrecioUnitario,
														@ATT_PrecioUnitarioDlls,
														@ATT_Importe,
														@ATT_ImporteDlls,
														@ATT_UnidadMedida,
														@ATT_IdOrdenCompra,
														@ATT_IdAlmacen,
														@ATT_Observacion
		END
	CLOSE TempProComprasConceptos
	DEALLOCATE TempProComprasConceptos
	
	-- Limpiar control peps
	UPDATE    ProMovimientosAlmacenConceptos
	SET              ExistenciaControlPEPS =  0
	FROM         ProMovimientosAlmacen INNER JOIN
						  ProMovimientosAlmacenConceptos ON ProMovimientosAlmacen.IdMovimientoAlmacen = ProMovimientosAlmacenConceptos.IdMovimientoAlmacen
	WHERE  ProMovimientosAlmacen.IdCompra = @IdCompra

	
	-- SECCION  CANCELAR PASIVO ligado a la compra.
	 SELECT @IdPasivo = IdPasivo  FROM ProPasivos WHERE IdCompra = @IdCompra
	 IF ISNULL(@IdPasivo,0) > 0
		BEGIN
		--- Valida que no tenga abonos
		IF (SELECT COUNT(IdPasivo) From ProPasivosMovimientosBancarios  where ProPasivosMovimientosBancarios.IdPasivo =  @IdPasivo)>=1
			RAISERROR(N'El pasivo tiene movimientos bancarios, no se puede cancelar ',
				16,
				1
				)
				
		IF (SELECT COUNT(IdPasivo) FROM ProPasivosMovimientosBancarios WHERE IdPasivo = @IdPasivo)>=1
			RAISERROR(N'El pasivo ya tiene pagos, no se puede cancelar',
				16,
				1
				)

		 UPDATE ProPasivos 
			SET CanceladoPor = @CanceladoPor,
				CanceladoEl  = @CanceladoEl,
				MotivoCancelacion  ='Se cancela desde compras :'+CHAR(13)+ @MotivoCancelacion  
			WHERE IdPasivo = @IdPasivo		
		END
	-- FIN DE SECCION

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

