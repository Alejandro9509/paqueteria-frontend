CREATE PROCEDURE [dbo].[usp_ProNominasReciboIncapacidadesAgregar]	
	@IdEmpleado int,
	@Folio Varchar(10),
	@IdTipoIncidencia int,
	@DiasAutorizados int,
	@FechaInicio datetime,
	@RamoSeguridad int,
	@TipoRiesgo int,
	@PorcientoIncapacidad decimal (7,2),
	@SecuelaConsecuencia int,
	@ControlIncapacidad int,
	@Observaciones ntext,
	@CreadoEl datetime,
	@CreadoPor int,
	@IdPeriodo int,
	@IdPeticion varchar(100),
	@xmlIncedenciaValor ntext,--@IdIncidencia int,@Valor decimal(15,2),@IdProNominaDiaHora int,@Estado varchar(40),
	@TipoIncidencia int
AS
DECLARE 
	@IdProNominaReciboIncapacidades int,
	@FechaFInal date, 
	@FechaRepetida int 
SET XACT_ABORT ON
BEGIN TRY
    BEGIN TRANSACTION  
		
		SET @FechaFInal = (SELECT CONVERT (DATE ,DATEADD(DD,@DiasAutorizados,@FechaInicio )))
		
		SET @FechaRepetida = (SELECT TOP 1 IdNominaDiaHora FROM ProNominasDiasHoras WHERE IdEmpleado = @IdEmpleado AND Fecha BETWEEN @FechaInicio AND @FechaFInal)
		
		IF ISNULL(@FechaRepetida,0) = 0 
			SET @FechaRepetida = 0

		IF  @FechaRepetida > 0 
        RAISERROR(N'Ya existen movimientos registrados para esta fecha',
            16,
            1
            )
            
		IF ISNULL(@IdEmpleado,0) = 0
        RAISERROR(N'El empleado es un campo requerido',
            16,
            1
            )
            
        IF @FechaInicio < (SELECT FechaAlta FROM CatEmpleados WHERE IdEmpleado = @IdEmpleado)
        RAISERROR(N'La fecha de inicio no puede ser menor a la fecha de contratacion del empleado',
            16,
            1
            )
        
		IF @FechaInicio < (SELECT FechaInicio FROM CatPeriodos WHERE IdPeriodo = @IdPeriodo)
        RAISERROR(N'La fecha de inicio no puede ser menor a la fecha de inicio del periodo',
            16,
            1
            )

		IF EXISTS (SELECT FechaInicio FROM ProNominasReciboIncapacidades WHERE FechaInicio = @FechaInicio AND IdEmpleado = @IdEmpleado)
        RAISERROR(N'La fecha ya existe',
            16,
            1
            )
    
    
    	IF ISNULL(@Folio,'') = ''
        RAISERROR(N'El folio es un campo requerido',
            16,
            1
            )
		
		IF EXISTS(SELECT @Folio FROM ProNominasReciboIncapacidades WHERE Folio = @Folio)
		RAISERROR(N'El folio ya existe',
			16,
			1
			)
			
		IF ISNULL(@IdTipoIncidencia,0) = 0
        RAISERROR(N'El tipo de incidencia es un campo requerido',
            16,
            1
            )	
            
        IF ISNULL(@TipoRiesgo,0) = -1
        RAISERROR(N'El tipo de riesgo es un campo requerido',
            16,
            1
            )	
        
        IF ISNULL(@ControlIncapacidad,0) = -1
        RAISERROR(N'El control de incapacidad es un campo requerido',
            16,
            1
            )	

		INSERT INTO ProNominasReciboIncapacidades(IdEmpleado,Folio,IdTipoIncidencia,DiasAutorizados,FechaInicio,RamoSeguridad,TipoRiesgo,PorcientoIncapacidad,SecuelaConsecuencia,ControlIncapacidad,Observaciones,CreadoEl,CreadoPor)
	    VALUES(@IdEmpleado,@Folio,@IdTipoIncidencia,@DiasAutorizados,@FechaInicio,@RamoSeguridad,@TipoRiesgo,@PorcientoIncapacidad,@SecuelaConsecuencia,@ControlIncapacidad,@Observaciones,@CreadoEl,@CreadoPor)
		
		SET  @IdProNominaReciboIncapacidades = (SELECT IDENT_CURRENT('ProNominasReciboIncapacidades'))
		
		IF @DiasAutorizados > 1 
		BEGIN 
			SET @FechaFInal = (SELECT CONVERT (DATE ,DATEADD(DD,@DiasAutorizados,@FechaInicio)))
		END 
		ELSE 
		BEGIN 
			SET @FechaFInal = @FechaInicio
		END 
		SET @FechaRepetida = (SELECT TOP 1 IdNominaDiaHora FROM ProNominasDiasHoras WHERE IdEmpleado = @IdEmpleado AND Fecha BETWEEN @FechaInicio AND @FechaFInal AND IdProNominaReciboIncapacidades <> @IdProNominaReciboIncapacidades)
		
		IF ISNULL(@FechaRepetida,0) = 0 
			SET @FechaRepetida = 0

		IF  @FechaRepetida > 0 
        RAISERROR(N'Ya existen movimientos registrados para esta fecha',
            16,
            1
            )

		UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

		EXEC  usp_ProNominasDiasHorasModificar
		@IdPeticion,
		@IdEmpleado,
		@xmlIncedenciaValor,
		@FechaInicio,
		@CreadoPor,
		@CreadoEl,
		@TipoIncidencia,
		@IdProNominaReciboIncapacidades,
		@IdPeriodo,
		NULL
COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

