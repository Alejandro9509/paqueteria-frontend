
CREATE PROCEDURE [dbo].[usp_CatGruposClientesModificarPQ](
	@IdGrupoCliente int,
	@Codigo int,
	@Grupo varchar(50),
	@ModificadoEl datetime,
	@ModificadoPor int)

	AS
BEGIN 
	BEGIN TRANSACTION
		IF ISNULL(@IdGrupoCliente, 0) <= 0 begin
			RAISERROR(N'*INICIO*El id de la ciudad es campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;		
		end
		IF ISNULL(@Codigo,  0) <= 0 begin
			RAISERROR(N'*INICIO*El código del grupo es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;			
		end
		IF ISNULL(@Grupo, '') = '' begin
			RAISERROR(N'*INICIO*El nombre del Grupo es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;	
		end

		UPDATE CatGruposClientes SET
		Codigo=@Codigo ,
		Grupo=@Grupo ,
		ModificadoEl=@ModificadoEl ,
		ModificadoPor=@ModificadoPor 
		WHERE IdGrupoCliente = @IdGrupoCliente
	IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

