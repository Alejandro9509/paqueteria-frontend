
CREATE PROCEDURE [dbo].[usp_CatUsuariosGrabarMenuAccesosDirectos]	
	@IdUsuario Int,	
	@Menu ntext,
	@XMLAutoCompleteMenu ntext,
	@AccesosDirectos ntext,
	@IdPeticion varchar(100)

	/* *************************************************************************************************

	Creado por:   EDGAR RAMOS
	Solicitud : 4124
	Fecha de Creacion: 05/04/2021
	Versión: 1.0.0.0

	Invocada desde: 
	GMTERPV8_API	-- GrabarMenuAccesosDirectosByIdUsuario
	GMTERPV8		-- ClsCatUsuarios -- VerificarUsuarioContraseña
	************************************************************************************************ */
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF @IdUsuario = 0
		RAISERROR(N'El identificador del usuario es un campo requerido',
			16,
			1
			)

	UPDATE CatUsuarios SET 
	Menu= @Menu,
	XMLAutoCompleteMenu = @XMLAutoCompleteMenu,
	AccesosDirectos = @AccesosDirectos
	WHERE IdUsuario = @IdUsuario
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

