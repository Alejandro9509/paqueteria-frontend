CREATE PROCEDURE [dbo].[usp_CatContenedoresModificar]
@IdContenedor int,
@Codigo int,
@Contenedor varchar(50),
@Capacidad decimal(15, 4),
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdContenedor,0)= 0
	RAISERROR(N'El identificador de contenedor es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de contenedor es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT Codigo FROM CatContenedores WHERE Codigo = @Codigo And IdContenedor <> @IdContenedor)
		RAISERROR(N'El código del contenedor ya existe',
			16,
			1
			)
					
	IF ISNULL(@Contenedor,'')= ''
		RAISERROR(N'Descripción de contenedor es un campo requerido',
			16,
			1
			)

	UPDATE CatContenedores SET
			Codigo= @Codigo,
			Contenedor= @Contenedor,
			Capacidad = @Capacidad,
			ModificadoEl= @ModificadoEl,
			ModificadoPor= @ModificadoPor
	WHERE 	IdContenedor=@IdContenedor

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

