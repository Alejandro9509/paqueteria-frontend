CREATE PROCEDURE [dbo].[usp_CatRutaAgregarPQ](
	@IdCoordenadaOrigen int,
	@IdCoordenadaDestino int,
	@IdDetalle int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdCoordenadaOrigen, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Id de coordenada de Origen es requerido*FIN*', 16, 1)
			return;
		end

		IF ISNULL(@IdCoordenadaDestino, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Id de coordenada de Destino es requerido*FIN*', 16, 1)
			return;
		end
		IF ISNULL(@IdDetalle, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Id de Detalle de ruta o es requerido*FIN*', 16, 1)
			return;
		end
		
		
INSERT INTO CatRutasPQ

VALUES (@IdCoordenadaOrigen , @IdCoordenadaDestino,@IdDetalle)

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

