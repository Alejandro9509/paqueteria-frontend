   
CREATE PROCEDURE [dbo].[usp_ProSolicitudesEDIActualizarShipment]   
@IdViaje int,   
@IdPeticion varchar(100),   
@JsonShipment varchar(MAX)   
/* *************************************************************************************************
Procedimiento usp_ProSolicitudesEDIActualizarShipment

Parámetros: 
    @IdViaje                ( entrada, int ). Id del viaje
    @IdPeticion             ( entrada, string ). Id de la Petición, generada en WEBDEV 
    @JsonShipment       ( entrada, string ). dato a actualizar

Descripción: El procedimiento actualiza el shipment que haya retornado el servicio de retransmision del
             API de FreightVerify.

Implementada por: Francisco Villela
Fecha de implementacion: 11/02/2021
Versión ERP: 8.0.58.23

Invocada desde: PAGE_ProSolictudesEDIRecepcion   (Solicitud 3715)
***************************************************************************************************** */
AS
BEGIN TRY
    BEGIN TRANSACTION
        
        --Se valida que se haya recibido un IdViaje
        IF ISNULL(@IdViaje,0) = 0
            RAISERROR(N'El identificador del viaje es un campo requerido',
                16,
                1
                )
    
        --Se guarda el error en la tabla de ProViajes
        UPDATE ProViajes SET
            EstructuraJSONShipment = @JsonShipment
        WHERE IdViaje = @IdViaje

    COMMIT

END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

