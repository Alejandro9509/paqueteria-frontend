
CREATE PROCEDURE [dbo].[usp_CatUnidadesEliminarPQ]
	@IdUnidad INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdUnidad,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de la Unidad es un campo requerido*FIN*', 16, 1)
			RETURN
		end
		DELETE FROM CatUnidades
		WHERE IdUnidad = @IdUnidad
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

