CREATE PROCEDURE [dbo].[usp_Report_SalidasDiariasConImportes]
	-- Add the parameters for the stored procedure here
@FechaDesde date,
@FechaHasta date,
@FiltroUnidades NVARCHAR(MAX),
@FiltroSucursal NVARCHAR(MAX),
@IdSucursal int

AS
DECLARE @cols AS NVARCHAR(MAX)='';
DECLARE @descripciones AS NVARCHAR(MAX)='';
DECLARE @query AS NVARCHAR(MAX)='';
DECLARE @Parametros NVARCHAR(max),
		@IdUnidad NVARCHAR(255),
		@pos INT
CREATE TABLE #TempReportSalidasDiariasConImportes( IdUnidad INT)

IF CHARINDEX(',', @FiltroUnidades) > 0 
	BEGIN

	--ciclo para realizar un split e insertar los identificadores en la tabla temporal
		 WHILE CHARINDEX(',', @FiltroUnidades) > 0
		 BEGIN
		  SELECT @pos  = CHARINDEX(',', @FiltroUnidades)  
		  SELECT @IdUnidad = SUBSTRING(@FiltroUnidades, 1, @pos-1)
	 
		  INSERT INTO #TempReportSalidasDiariasConImportes
		  SELECT @IdUnidad

		  SELECT @FiltroUnidades = SUBSTRING(@FiltroUnidades, @pos+1, LEN(@FiltroUnidades)-@pos)
		 END
		  IF @FiltroUnidades <> ''
		  BEGIN
			INSERT INTO #TempReportSalidasDiariasConImportes
			SELECT @FiltroUnidades
		  END
	END
 ELSE
	 BEGIN
		 INSERT INTO #TempReportSalidasDiariasConImportes
		 SELECT @FiltroUnidades
	 END

IF @IdSucursal = 0 
	SELECT @cols = @cols + QUOTENAME(IdConceptoFacturacion) + ',' FROM (
		SELECT CCF.IdConceptoFacturacion FROM ProViajes  AS PV
		INNER JOIN ProViajesTrayectos AS PVT ON PV.IdViaje = PVT.IdViaje
		INNER JOIN ProViajesConceptosFacturacion AS PVCF ON PV.IdViaje = PVCF.IdViaje
		INNER JOIN CatConceptosFacturacion AS CCF ON PVCF.IdConceptoFacturacion = CCF.IdConceptoFacturacion
		WHERE 
		PV.CanceladoEl IS NULL
		AND CAST(PVT.Salida AS date) >= @FechaDesde AND CAST(PVT.Salida AS date) <= @FechaHasta
		AND PVT.IdUnidadCamion IN( SELECT IdUnidad FROM #TempReportSalidasDiariasConImportes )
		GROUP BY CCF.IdConceptoFacturacion,CCF.Codigo
	) AS TMP
ELSE
	SELECT @cols = @cols + QUOTENAME(IdConceptoFacturacion) + ',' FROM (
		SELECT CCF.IdConceptoFacturacion FROM ProViajes  AS PV
		INNER JOIN ProViajesTrayectos AS PVT ON PV.IdViaje = PVT.IdViaje
		INNER JOIN ProViajesConceptosFacturacion AS PVCF ON PV.IdViaje = PVCF.IdViaje
		INNER JOIN CatConceptosFacturacion AS CCF ON PVCF.IdConceptoFacturacion = CCF.IdConceptoFacturacion
		WHERE 
		PV.CanceladoEl IS NULL
		AND CAST(PVT.Salida AS date) >= @FechaDesde AND CAST(PVT.Salida AS date) <= @FechaHasta
		AND PVT.IdUnidadCamion IN( SELECT IdUnidad FROM #TempReportSalidasDiariasConImportes )
		AND PV.IdSucursal = @IdSucursal
		GROUP BY CCF.IdConceptoFacturacion,CCF.Codigo
	) AS TMP

IF @IdSucursal = 0 
	SELECT @descripciones = @descripciones + QUOTENAME(IdConceptoFacturacion) + ' ''' + REPLACE(ConceptoFacturacion, '''', '''''') + ''',' FROM (
		SELECT CCF.IdConceptoFacturacion, CCF.ConceptoFacturacion FROM ProViajes  AS PV
		INNER JOIN ProViajesTrayectos AS PVT ON PV.IdViaje = PVT.IdViaje
		INNER JOIN ProViajesConceptosFacturacion AS PVCF ON PV.IdViaje = PVCF.IdViaje
		INNER JOIN CatConceptosFacturacion AS CCF ON PVCF.IdConceptoFacturacion = CCF.IdConceptoFacturacion
		WHERE 
		PV.CanceladoEl IS NULL
		AND CAST(PVT.Salida AS date) >= @FechaDesde AND CAST(PVT.Salida AS date) <= @FechaHasta
		AND PVT.IdUnidadCamion IN( SELECT IdUnidad FROM #TempReportSalidasDiariasConImportes )
		GROUP BY CCF.IdConceptoFacturacion, CCF.ConceptoFacturacion,CCF.Codigo
	) AS TMP
ELSE
	SELECT @descripciones = @descripciones + QUOTENAME(IdConceptoFacturacion) + ' ''' + REPLACE(ConceptoFacturacion, '''', '''''') + ''',' FROM (
		SELECT CCF.IdConceptoFacturacion, CCF.ConceptoFacturacion FROM ProViajes  AS PV
		INNER JOIN ProViajesTrayectos AS PVT ON PV.IdViaje = PVT.IdViaje
		INNER JOIN ProViajesConceptosFacturacion AS PVCF ON PV.IdViaje = PVCF.IdViaje
		INNER JOIN CatConceptosFacturacion AS CCF ON PVCF.IdConceptoFacturacion = CCF.IdConceptoFacturacion
		WHERE 
		PV.CanceladoEl IS NULL
		AND CAST(PVT.Salida AS date) >= @FechaDesde AND CAST(PVT.Salida AS date) <= @FechaHasta
		AND PVT.IdUnidadCamion IN( SELECT IdUnidad FROM #TempReportSalidasDiariasConImportes )
		AND PV.IdSucursal = @IdSucursal
		GROUP BY CCF.IdConceptoFacturacion, CCF.ConceptoFacturacion,CCF.Codigo
	) AS TMP

SELECT @cols = substring(@cols, 0, len(@cols)) --trim "," at end
SELECT @descripciones = substring(@descripciones, 0, len(@descripciones)) --trim "," at end

set @query = 
N';WITH CTE_Viajes AS 
	(
	SELECT 
	/*Viaje*/
	pv.IdViaje,
	cs.Abreviacion AS Sucursal,
	pv.Viaje,
	pv.FechaHora,
	cc.NumeroCliente,
	cc.NombreFiscal,
	pv.CodigoUnidadCarga1,
	crd.Nombre AS Destinatario,
	pv.IdMoneda,
	pv.SubTotal,
	pv.TipoCambio,
	pvcp.IdViajeCartaPorte,
	ctd.Documento,
	cf.Folio,
	cf.Serie,
	CASE pv.ViajeConCP 
	WHEN 1 THEN pvcp.Total
	ELSE pv.SubTotal
	END AS Total,
	pvcp.ImpuestosTrasladadosFederales,
	pvcp.ImpuestosRetenidosFederales,
	pvcp.IdFormatoImpresion,
	pv.IdSucursal,
	pv.NoViajeCliente,
	cr.FolioRuta,
	cr.DescripcionRuta,
	ctv.TipoViaje,
	ccv.ClasificacionViaje,
	pv.Facturable,
	pv.Observaciones,
	(
	CASE 
	WHEN (SELECT  MAX(IdViajeImagen) FROM ProViajesImagenes AS pvi WHERE pvi.IdViaje = pv.IdViaje) is not null then ''SI''
	ELSE ''NO''
	END 
	)as TieneDocumento,
	/*Trayecto*/
	pvt.Salida,
	cor.OrigenDestino AS Origen,
	cde.OrigenDestino AS Destino,
	pvt.Kilometros,
	pvt.IdOperador,
	co.NumeroOperador,
	co.Nombre,
	pvt.NombreOperador,
	pvt.IdUnidadCamion,
	cu.Codigo,
	pvt.CodigoUnidadCamion,
	(SELECT SUM(pvt1.Kilometros)
	FROM ProViajesTrayectos AS pvt1
	WHERE pvt1.IdViaje = pvt.IdViaje
	AND pvt1.Salida IS NOT NULL
	AND pvt1.IdOperador IS NOT NULL) AS KmsTotales,
	ctu.TipoUnidad,
	pl.Folio as Liquidacion,
	PVCF.Importe,
	CCF.IdConceptoFacturacion
	FROM ProViajes  AS pv
	INNER JOIN ProViajesConceptosFacturacion AS PVCF ON pv.IdViaje = PVCF.IdViaje
	INNER JOIN CatConceptosFacturacion AS CCF ON PVCF.IdConceptoFacturacion = CCF.IdConceptoFacturacion
	INNER JOIN CatSucursales AS cs ON pv.IdSucursal = cs.IdSucursal
	INNER JOIN CatClientes AS cc ON pv.IdCliente = cc.IdCliente
	INNER JOIN ProViajesTrayectos AS pvt ON pv.IdViaje = pvt.IdViaje
	INNER JOIN CatOrigenesDestinos AS cor ON pvt.IdOrigen = cor.IdOrigenDestino
	INNER JOIN CatOrigenesDestinos AS cde ON pvt.IdDestino = cde.IdOrigenDestino
	LEFT JOIN CatOperadores AS co ON pvt.IdOperador = co.IdOperador
	LEFT JOIN CatUnidades AS cu ON pvt.IdUnidadCamion = cu.IdUnidad
	LEFT JOIN CatRemitentesDestinatarios AS crd ON pv.IdDestinatario = crd.IdRemitenteDestinatario
	LEFT JOIN ProViajesCartasPorte AS pvcp ON pv.IdViaje = pvcp.IdViaje
	LEFT JOIN CatFolios AS cf ON pvcp.IdFolio = cf.IdFolio
	LEFT JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
	LEFT JOIN CatRutas as cr on pv.IdRuta = cr.IdRuta
	LEFT JOIN CatTiposViajes as ctv on pv.IdTipoViaje = ctv.IdTipoViaje
	LEFT JOIN CatTiposUnidades as ctu on cu.IdTipoUnidad =ctu.IdTipoUnidad
	LEFT JOIN ProLiquidaciones as pl on pvt.IdLiquidacion = pl.IdLiquidacion
	LEFT JOIN CatClasificacionesViajes as ccv on pv.IdClasificacionViaje = ccv.IdClasificacionViaje
	WHERE  pv.CanceladoEl IS NULL
	AND CAST(pvt.Salida AS date) >= @FechaD AND CAST(pvt.Salida AS date) <= @FechaH
	'+@FiltroSucursal+'
	AND pvt.IdUnidadCamion IN( SELECT IdUnidad FROM #TempReportSalidasDiariasConImportes )
	)

SELECT ROW_NUMBER() OVER(ORDER BY Salida,Sucursal,Viaje) AS Row#,
	IdViaje,
	Sucursal,
	Viaje,
	FechaHora,
	NumeroCliente,
	NombreFiscal,
	CodigoUnidadCarga1,
	Destinatario,
	IdMoneda,
	SubTotal,
	TipoCambio,
	IdViajeCartaPorte,
	Documento,
	Folio,
	Serie,
	Total,
	ImpuestosTrasladadosFederales,
	ImpuestosRetenidosFederales,
	IdFormatoImpresion,
	IdSucursal,
	NoViajeCliente,
	FolioRuta,
	DescripcionRuta,
	TipoViaje,
	ClasificacionViaje,
	Facturable,
	Observaciones,
	TieneDocumento,
	Salida,
	Origen,
	Destino,
	Kilometros,
	IdOperador,
	NumeroOperador,
	Nombre,
	NombreOperador,
	IdUnidadCamion,
	Codigo,
	CodigoUnidadCamion,
	KmsTotales,
	TipoUnidad,
	Liquidacion,
	Serie,
	Factura,
	FechaPago,
	'+@descripciones+'
FROM (
	SELECT 
	CTE_Viajes.*,
	CASE facturas.Serie
	WHEN  '''' THEN facturas.Documento+'' ''+SUBSTRING(''00000000'',1,8-len(CAST(facturas.Folio as varchar)))+CAST(facturas.Folio as varchar)
	ELSE  facturas.Documento+'' ''+SubString(''00000000'',1,8-len(CAST(facturas.Folio as varchar)))+CAST(facturas.Folio as varchar)+''-''+facturas.Serie
	END AS Factura,
	facturas.FechaPago
	FROM CTE_Viajes 
	LEFT JOIN 
	(
	SELECT 
	pvf.IdViaje, ctd1.Documento,cf1.Folio,cf1.Serie,pc.FechaHora as FechaPago
	FROM ProFacturas AS pf
	INNER JOIN CatFolios AS cf1 ON pf.IdFolio = cf1.IdFolio
	INNER JOIN CatTiposDocumentos AS ctd1 ON cf1.IdTipoDocumento = ctd1.IdTipoDocumento
	INNER JOIN ProViajesFacturas AS pvf ON pf.IdFactura = pvf.IdFactura
	INNER JOIN (SELECT DISTINCT CTE_Viajes.IdViaje FROM CTE_Viajes) AS pv1 on pvf.IdViaje = pv1.IdViaje
	LEFT JOIN ProCobranza AS pc ON pc.IdCobranza = (SELECT MAX(IdCobranza) FROM ProCobranza as pc1
	WHERE pc1.IdFactura = pf.IdFactura and pc1.IdConceptoCobranza = 2 
	)
	WHERE 
	pvf.IdViajeFactura = (SELECT MAX(pvf1.IdViajeFactura) FROM ProViajesFacturas as pvf1 WHERE pvf1.CanceladoEl IS NULL AND pvf1.IdViaje = pv1.IdViaje) 
	AND pvf.CanceladoEl IS NULL
	) AS facturas ON facturas.IdViaje = CTE_Viajes.IdViaje
) DATA
PIVOT 
(
		SUM(Importe) FOR IdConceptoFacturacion IN ('+@cols+')
) PI
';
SET @Parametros = N'@FechaD date,@FechaH date';
EXEC sp_executesql @query, @Parametros, @FechaD = @FechaDesde, @FechaH = @FechaHasta

--si existe la tabla temporal se elimina
IF OBJECT_ID('#TempReportSalidasDiariasConImportes') IS NOT NULL
BEGIN
DROP TABLE #TempReportSalidasDiariasConImportes
END
go

