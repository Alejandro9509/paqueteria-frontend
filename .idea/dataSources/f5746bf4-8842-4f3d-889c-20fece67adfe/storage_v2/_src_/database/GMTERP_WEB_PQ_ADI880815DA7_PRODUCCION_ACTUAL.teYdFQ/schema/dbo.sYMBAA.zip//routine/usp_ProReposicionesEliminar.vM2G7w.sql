CREATE PROCEDURE [dbo].[usp_ProReposicionesEliminar]
	@IdReposicion int,
	@IdPeticion varchar(100)
AS
/*
MODIFICADO:
	Se agregaro un exec usp_ProPolizasActualizarSaldos
	para acutalizar los asientos contables del catalogo CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-30
SOLICITUD: 
	SOLICITUD 000266
*/
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdReposicion,0) = 0
		RAISERROR(N'Identificador de reposición es un campo requerido',
			16,
			1
			)

	IF NOT EXISTS(SELECT IdReposicion FROM ProReposiciones WHERE IdReposicion = @IdReposicion)
		RAISERROR(N'El reposicion fue eliminado por otro usuario',
			16,
			1
			)
						
     IF (SELECT COUNT(IdMovimientoBancario) FROM ProReposiciones WHERE ProReposiciones.IdReposicion = @IdReposicion)>0 
		RAISERROR(N'No se puede eliminar el reposicion porque esta cerrada',
			16,
			1
			)
--- Eliminar Pasivos
    Declare @IdPasivo int
	DECLARE ProReposicionesPasivosCursor CURSOR FOR
			SELECT IdPasivo FROM  ProReposicionesPasivos WHERE IdReposicion=@IdReposicion
			
			OPEN ProReposicionesPasivosCursor
			FETCH NEXT FROM ProReposicionesPasivosCursor INTO @IdPasivo
			WHILE (@@FETCH_STATUS = 0 )
			BEGIN			
			-------------------Borra los pasivos de la reposicion si no estan vinculados en otra reposicion---------------------
			IF NOT EXISTS(SELECT * FROM ProReposicionesPasivos WHERE IdPasivo=@IdPasivo AND IdReposicion!=@IdReposicion)
			DELETE FROM ProPasivos WHERE IdPasivo = @IdPasivo AND ISNULL(DesdeReposicion,0) = 1
			
			FETCH NEXT FROM ProReposicionesPasivosCursor INTO @IdPasivo
	END
	CLOSE ProReposicionesPasivosCursor
	DEALLOCATE ProReposicionesPasivosCursor
	
	DELETE FROM ProReposicionesPasivos WHERE ProReposicionesPasivos.IdReposicion= @IdReposicion
--- Eliminar Reposición
	DELETE FROM ProReposiciones WHERE ProReposiciones.IdReposicion = @IdReposicion
	/*Antes de que se elimine la poliza, se van a quitar los asientos contables de CatCuentasContablesSaldos*/
	DECLARE @CondicionQuery nvarchar(max)  = ' pp.ProcesoLigado = ''ProReposiciones'' AND pp.IdProcesoLigado IN ( '+CAST(@IdReposicion AS varchar)+') ' 
	EXEC usp_ProPolizasActualizarSaldos @IdPeticion,0,@CondicionQuery
--- Eliminar Polizas
	DELETE FROM ProPolizas WHERE IdProcesoLigado = @IdReposicion AND ProcesoLigado = 'ProReposiciones'	
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

