
CREATE PROCEDURE [dbo].[usp_CatProductosEliminarPQ]
	@IdProducto INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdProducto,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del Producto es un campo requerido*FIN*', 16, 1);
			return
		end;
		
		DELETE FROM CatProductosPQ
		WHERE @IdProducto = @IdProducto
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

