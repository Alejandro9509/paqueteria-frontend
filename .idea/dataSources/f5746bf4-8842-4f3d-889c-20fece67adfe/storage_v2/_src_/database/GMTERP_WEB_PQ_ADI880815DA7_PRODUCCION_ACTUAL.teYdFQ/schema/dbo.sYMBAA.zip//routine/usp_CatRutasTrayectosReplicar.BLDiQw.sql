CREATE PROCEDURE [dbo].[usp_CatRutasTrayectosReplicar]
    @Kilometros int,
    @Horas decimal(15,2),
    @RutaGoogleMap ntext,
    @IdGeocercaDisparaSalida int,
    @GeocercaDisparaSalidaES tinyint,
    @IdGeocercaDisparaLlegada int,
    @GeocercaDisparaLlegadaES tinyint,
    @IdEstatuViajeSalida int,
    @IdEstatuViajeLlegada int,
    @dsCatRutasTrayectos ntext,
    @dsCatRutasTrayectosGeocercas ntext,
    @ModificadoPor int,
    @ModificadoEl datetime,    
    @IdPeticion varchar(100),
	@Millas decimal(15,2)
AS
DECLARE
    @docHandle int,
    @COL_IdRutaTrayecto int,
    @IdRuta int,
    @KilometrosTotales int,
    @HorasTotales decimal(15,2),
	@MillasTotales decimal(15,2)  
BEGIN TRY
    BEGIN TRANSACTION

        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectosGeocercas

        SELECT COL_IdEstatuViajeEntrar,COL_IdEstatuViajeSalir,COL_IdGeocerca
        INTO #TempCatRutasTrayectosGeocercas
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosGeocercas',2) 
        WITH(COL_IdEstatuViajeEntrar int,COL_IdEstatuViajeSalir int,COL_IdGeocerca int)
    
        EXEC sp_xml_removedocument @docHandle

        --SECCION PARA AGREGAR LOS trayectos
        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectos
    
        SELECT COL_IdRutaTrayecto
        INTO #TempCatRutasTrayectos
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectos',2) 
        WITH (COL_IdRutaTrayecto int)
    
        EXEC sp_xml_removedocument @docHandle
    
        DECLARE CursorCatRutasTrayectos CURSOR FOR
        SELECT * FROM #TempCatRutasTrayectos
    
        OPEN CursorCatRutasTrayectos
        FETCH NEXT FROM CursorCatRutasTrayectos
        INTO @COL_IdRutaTrayecto
    
        WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @IdEstatuViajeSalida = 0
                SET @IdEstatuViajeSalida = NULL

            IF @IdEstatuViajeLlegada = 0
                SET @IdEstatuViajeLlegada = NULL
            
            UPDATE CatRutasTrayectos SET 
                CatRutasTrayectos.Horas = @Horas,
                CatRutasTrayectos.Kilometros = @Kilometros,
                CatRutasTrayectos.RutaGoogleMap = @RutaGoogleMap,
                CatRutasTrayectos.ModificadoEl = @ModificadoEl,
                CatRutasTrayectos.ModificadoPor = @ModificadoPor,
                CatRutasTrayectos.IdGeocercaDisparaSalida = @IdGeocercaDisparaSalida,
                CatRutasTrayectos.GeocercaDisparaSalidaES = @GeocercaDisparaSalidaES,
                CatRutasTrayectos.IdGeocercaDisparaLlegada = @IdGeocercaDisparaLlegada,
                CatRutasTrayectos.GeocercaDisparaLlegadaES = @GeocercaDisparaLlegadaES,
                CatRutasTrayectos.IdEstatuViajeSalida = @IdEstatuViajeSalida,
                CatRutasTrayectos.IdEstatuViajeLlegada = @IdEstatuViajeLlegada,
				CatRutasTrayectos.Millas = @Millas
            WHERE IdRutaTrayecto = @COL_IdRutaTrayecto
        
            INSERT INTO CatRutasTrayectosGeocercas(IdRutaTrayecto,IdEstatuViajeEntrada,IdEstatuViajeSalida,IdGeocerca,CreadoEl,CreadoPor)
            SELECT @COL_IdRutaTrayecto,
            CASE COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE COL_IdEstatuViajeEntrar END,
            CASE COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE COL_IdEstatuViajeSalir END,
            COL_IdGeocerca,@ModificadoEl,@ModificadoPor
            FROM #TempCatRutasTrayectosGeocercas
        
            DELETE FROM CatRutasTrayectosGeocercas WHERE IdRutaTrayecto = @COL_IdRutaTrayecto AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
            
            SET @IdRuta = (SELECT IdRuta FROM CatRutasTrayectos WHERE IdRutaTrayecto = @COL_IdRutaTrayecto)
            SET @KilometrosTotales = ISNULL((SELECT SUM(Kilometros) FROM CatRutasTrayectos WHERE IdRuta = @IdRuta),0)
            SET @HorasTotales = ISNULL((SELECT SUM(Horas) FROM CatRutasTrayectos WHERE IdRuta = @IdRuta),0)
			SET @MillasTotales = ISNULL((SELECT SUM(Millas) FROM CatRutasTrayectos WHERE IdRuta = @IdRuta),0)
            
            UPDATE CatRutas SET 
                Kilometros = @KilometrosTotales, 
                Horas = @HorasTotales, 
                ModificadoEl = @ModificadoEl, 
                ModificadoPor = @ModificadoPor,
				Millas = @MillasTotales
            WHERE IdRuta = @IdRuta
        
            --next del cursor ultima linea en el while
            FETCH NEXT FROM CursorCatRutasTrayectos
            INTO @COL_IdRutaTrayecto
        END

        CLOSE CursorCatRutasTrayectos
        DEALLOCATE CursorCatRutasTrayectos                        
    



    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

