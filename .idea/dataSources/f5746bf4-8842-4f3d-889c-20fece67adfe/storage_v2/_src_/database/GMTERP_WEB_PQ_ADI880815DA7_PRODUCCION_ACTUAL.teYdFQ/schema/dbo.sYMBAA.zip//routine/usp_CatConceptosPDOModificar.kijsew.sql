CREATE PROCEDURE [dbo].[usp_CatConceptosPDOModificar]
	    @IdConceptoPDO int,
		@NumeroConcepto int,
		@TipoConcepto int,
		@Descripcion varchar(40),
		@Especie bit,
		@AutomaticoGlobal bit,
		@AutomaticoLiquidacion bit,
		@Imprimir bit,
		@LeyendaImporte1 varchar(40),
		@LeyendaImporte2 varchar(40),
		@LeyendaImporte3 varchar(40),
		@LeyendaImporte4 varchar(40),
		@LeyendaValor varchar(40),
		@FormulaImporteTotal ntext,
		@FormulaImporte1 ntext,
		@FormulaImporte2 ntext,
		@FormulaImporte3 ntext,
		@FormulaImporte4 ntext,
		@FormulaValor ntext,		
		@ClaveAgrupadoraSAT varchar(20),
		@ModificadoEl    datetime,    
		@ModificadoPor    int,    
		@IdPeticion varchar(100),
		@dsTiposAcumulados ntext,
		@IdFormulaImporteTotal int,
		@IdFormulaImporte1 int,
		@IdFormulaImporte2 int,
		@IdFormulaImporte3 int,
		@IdFormulaImporte4 int,
		@IdFormulaValor int,
		@LeyendaImporteTotal Varchar(40),
		@ClaveOtrosPagos varchar(5),
		@GravaISRArt142 bit,
		@MantenerValores bit
		

/* *************************************************************************************************
Procedimiento usp_CatRutasActualizarConceptosyMateriales

Parámetros: 
	@IdConceptoPDO int,				(Entrada, Entero), es el valor interno del concepto PDO.
		@NumeroConcepto int,		(Entrada, Entero), Es el codigo del concepto PDO que utiliza el usuario
		@TipoConcepto int,			(Entrada, Entero), es el valor que determina si es 1=Percepcion, 2=Deduccion, 3=Otros
		@Descripcion varchar(40),	(Entrada, Cadena), es la descripcion del concepto PDO. 
		@Especie bit,				(Entrada, Boolean), este valor identifica si no se suma o resta la percepcion/deduccion/otros
		@AutomaticoGlobal bit,		(Entrada, Boolean), este valor determina si un concepto PDO se aplica a todos los empleados.
		@AutomaticoLiquidacion bit,	(Entrada, Boolean), este valor determina si el concepto proveniente de las liquidaciones se aplicara a los empleados.
		@Imprimir bit,				(Entrada, Boolean), determina si se genera una impresion.
		@LeyendaImporte1 varchar(40),(Entrada, Cadena), Descripcion de la formula que se aplicara al importe 1 del concepto PDO.
		@LeyendaImporte2 varchar(40),(Entrada, Cadena), Descripcion de la formula que se aplicara al importe 2 del concepto PDO.
		@LeyendaImporte3 varchar(40),(Entrada, Cadena), Descripcion de la formula que se aplicara al importe 2 del concepto PDO.
		@LeyendaImporte4 varchar(40),(Entrada, Cadena), Descripcion de la formula que se aplicara al importe 4 del concepto PDO.
		@LeyendaValor varchar(40),
		@FormulaImporteTotal ntext,	(Entrada, Cadena), es la descripcion de la formula que se utilizara para obtener el importe total del Cocnepto PDO.
		@FormulaImporte1 ntext,		(Entrada, Cadena), es la descripcion de la formula que se utilizara para obtener el importe Gravado ISR del Concepto PDO.
		@FormulaImporte2 ntext,		(Entrada, Cadena), es la descripcion de la formula que se utilizara para obtener el importe Exento ISR del Concepto PDO.
		@FormulaImporte3 ntext,		(Entrada, Cadena), es la descripcion de la formula que se utilizara para obtener el importe Gravado IMSS del Concepto PDO.
		@FormulaImporte4 ntext,		(Entrada, Cadena), es la descripcion de la formula que se utilizara para obtener el importe Exento IMSS del Concepto PDO.
		@FormulaValor ntext,		(Entrada, Entero), el el identificador de la formula que determina los dias y/o veces a descontar un percepcion/deduccion.
		@ClaveAgrupadoraSAT varchar(20), (Entrada, Cadena), es la clave asignada por el SAT para identificar el producto o servicio que vas a facturar.
		@ModificadoEl    datetime,  (Entrada, Fecha), es la fecha en que se realizo la modificacion del concepto PDO por parte del usuario.  
		@ModificadoPor    int,		(Entrada, Entero), es la clave interna del usuario que modifico el conceptos PDO.
		@IdPeticion varchar(100),	(Entrada, Cadena), id de la Petición, generada en WEBDEV 
		@dsTiposAcumulados ntext,	(Entrada, Cadena),
		@IdFormulaImporteTotal int, (Entrada, Entero), es el id de la formula que se utilizara para obtener el importe total del Cocnepto PDO.
		@IdFormulaImporte1 int,		(Entrada, Entero), es el id de la formula que se utilizara para obtener el importe Gravado ISR del Concepto PDO.
		@IdFormulaImporte2 int,		(Entrada, Entero), es el id de la formula que se utilizara para obtener el importe Exento ISR del Concepto PDO.
		@IdFormulaImporte3 int,		(Entrada, Entero), es el id de la formula que se utilizara para obtener el importe Gravado IMSS del Concepto PDO.
		@IdFormulaImporte4 int,		(Entrada, Entero), es el id de la formula que se utilizara para obtener el importe Exento IMSS del Concepto PDO.
		@IdFormulaValor int,		(Entrada, Entero), es el id de la formula que se utilizara para obtener el valor/veces aplicar un importe.
		@LeyendaImporteTotal Varchar(40), (Entrada, Cadena)
		@ClaveOtrosPagos varchar(5), (Entrada, cadena), es la clave del concepto PDO si pertenece a Otros PAgos.
		@GravaISRArt142 bit,		(Entrada, Boolean), determina si el concepto PDO aplica al articulo 142 (Aguinaldo, PTU)
		@MantenerValores bit		(Entrada, Booleaan), determina durante el calculo si se deben aplicar las formulas asignadas segun si el usuario modifico importes/valores.
	

Descripción: El procedimiento actualiza las tarifas de Conceptos de facturación y Materiales seleccionados para 
             un conjunto de Rutas (vigentes). Verificando la concurrencia para evitar transacciones perdidas en el 
			 caso de lecturas sucias durante el proceso de modificar tarifas para Conceptos de facturacion y Materiales.
14/05/2019   Se habia omitido el manejo de valores nulos en el campo que indica la concurrencia, se agregó lógica para 
             el manejo de los nulos.

Implementada por: N/A
Fecha de implementacion: N/A
Versión ERP: x.x.xx.xx

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 11/Dic/2020
Versión ERP: 8.0.57.11
Solicitud 3499

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 18/Dic/2020
Versión ERP: 8.0.57.17

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 21/Dic/2020
Versión ERP: 8.0.57.18


Invocada desde: PAGE_CatConceptosPDOAM (Solicitud 3499)
***************************************************************************************************** */


AS
DECLARE	
	@docHandle int,
	@ATT_IdTipoAcumulado int,
	@ATT_Pestania int,
	@ATT_AcumuladoFiscal bit,
	@ATT_IdConceptoPDOTiposAcumulados int,
	@IdFormulaValorNueva int= NULL,
	@NombreFormula varchar(50),
	@IdFormulaCeros INT

BEGIN TRY
    BEGIN TRANSACTION
    
    
    IF @IdConceptoPDO <= 0
        RAISERROR(N'El identificador del Concepto es un campo requerido',
            16,
            1
            )
    IF @NumeroConcepto <= 0
        RAISERROR(N'El Número de Concepto es un campo requerido',
            16,
            1
            )
            
    IF ISNULL(@Descripcion,'')= ''
        RAISERROR(N'La Descripción es un campo requerido',
            16,
            1
            )

	IF EXISTS(SELECT Descripcion FROM CatConceptosPDO WHERE Descripcion=@Descripcion And IdConceptoPDO<>@IdConceptoPDO)
		RAISERROR(N'La descripción del concepto ya existe',
			16,
			1
			)

           
	 
	IF EXISTS(SELECT NumeroConcepto FROM CatConceptosPDO WHERE NumeroConcepto = @NumeroConcepto And IdConceptoPDO <> @IdConceptoPDO)
		RAISERROR(N'El Código del tipo de periodo ya existe',
			16,
			1
			)                     
   	 	 --Sección para actualizar el campo ClaveOtrosPagos en caso de que el tipo de concepto sea deducción
	IF @TipoConcepto = 3 --con el número 3 se hacer referencia a las obligaciones
	BEGIN
		SET @ClaveOtrosPagos = null
	END       
	
	--solicitud 3499 se modifica el id de la formula del valor  nueva/anterior del sueldo
	IF @Descripcion = 'SUELDO' 
	  BEGIN
			SET @IdFormulaValorNueva = ( 
			SELECT  
			  CASE cfn.Nombre 
			  WHEN 'SUELDO_V2' THEN (SELECT IdFormulaNomina FROM CatFormulasNominas WHERE Nombre = 'VVALORSUELDO_V2' )
			  WHEN 'SUELDO'   THEN (SELECT IdFormulaNomina FROM CatFormulasNominas WHERE Nombre = 'VVALORSUELDO' )
			  END AS IdValor
			FROM CatFormulasNominas cfn 
			WHERE cfn.IdFormulaNomina = @IdFormulaImporteTotal
			)
			 SET @IdFormulaValor = @IdFormulaValorNueva
			 SET @NombreFormula = (SELECT TOP 1 Nombre FROM CatFormulasNominas where IdFormulaNomina = @IdFormulaImporteTotal) 
			 IF @NombreFormula = 'SUELDO_V2' 
			    BEGIN
				  IF EXISTS(SELECT TOP 1 IdFormulaNomina FROM CatFormulasNominas WHERE Nombre = 'CERO' )
					   BEGIN
					     SET @IdFormulaCeros = (SELECT TOP 1 IdFormulaNomina FROM CatFormulasNominas WHERE Nombre = 'CERO')
					   END
				  ELSE
				  IF EXISTS(SELECT TOP 1 IdFormulaNomina FROM CatFormulasNominas WHERE Nombre = 'RESULT 0' )   
					   BEGIN
					     SET @IdFormulaCeros = (SELECT TOP 1 IdFormulaNomina FROM CatFormulasNominas WHERE Nombre = 'RESULT 0')
					   END
					   
				  SET @IdFormulaImporte1 = @IdFormulaImporteTotal
			      SET @IdFormulaImporte3 = @IdFormulaImporteTotal
				  SET @FormulaImporte1 = @FormulaImporteTotal
				  SET @FormulaImporte3 = @FormulaImporteTotal

				      --sol 3499, buscar formula de exentos en cero para el sueldo V2
					  IF ISNULL(@IdFormulaCeros,0) > 0 
						 BEGIN
						   SET @IdFormulaImporte2 = @IdFormulaCeros
						   SET @IdFormulaImporte4 = @IdFormulaCeros
						 END
				END
	    END

/*
  SOLICITUD 3499 REV 4, se solicita que al cambiar la formula del sueldo automaticamente cambie la formula del importe Gravado/Exento
  del ISR/IMSS 
*/  
            
Update CatConceptosPDO Set 
	NumeroConcepto=@NumeroConcepto,
	TipoConcepto=@TipoConcepto,
	Descripcion=@Descripcion,
	Especie=@Especie,
	AutomaticoGlobal=@AutomaticoGlobal,
	AutomaticoLiquidacion=@AutomaticoLiquidacion,
	Imprimir=@Imprimir,
	LeyendaImporte1=@LeyendaImporte1,
	LeyendaImporte2=@LeyendaImporte2,
	LeyendaImporte3=@LeyendaImporte3,
	LeyendaImporte4=@LeyendaImporte4,
	LeyendaValor=@LeyendaValor,
	LeyendaImporteTotal = @LeyendaImporteTotal,
	FormulaImporteTotal=@FormulaImporteTotal,
	FormulaImporte1=@FormulaImporte1,
	FormulaImporte2=@FormulaImporte2,
	FormulaImporte3=@FormulaImporte3,
	FormulaImporte4=@FormulaImporte4,
	FormulaValor=@FormulaValor,	
	ClaveAgrupadoraSAT=@ClaveAgrupadoraSAT,
	ModificadoEl=@ModificadoEl,
	ModificadoPor=@ModificadoPor,
	IdFormulaImporteTotal=@IdFormulaImporteTotal,
	IdFormulaImporte1=@IdFormulaImporte1,
	IdFormulaImporte2=@IdFormulaImporte2,
	IdFormulaImporte3=@IdFormulaImporte3,
	IdFormulaImporte4=@IdFormulaImporte4,
	IdFormulaValor=@IdFormulaValor,
	ClaveOtrosPagos=@ClaveOtrosPagos,
	GravaISRArt142=@GravaISRArt142,
	MantenerValores=@MantenerValores
Where IdConceptoPDO = @IdConceptoPDO

--SECCION PARA AGREGAR LOS Acumulados
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsTiposAcumulados
	
	SELECT ATT_IdTipoAcumulado,ATT_Pestania,ATT_AcumuladoFiscal,ATT_IdConceptoPDOTiposAcumulados
	INTO #TempCatTiposAcumulados
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_TiposAcumulados',2) 
	WITH (ATT_IdTipoAcumulado int,ATT_Pestania int,ATT_AcumuladoFiscal bit,ATT_IdConceptoPDOTiposAcumulados int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatTiposAcumulados CURSOR FOR
	SELECT * FROM #TempCatTiposAcumulados
	
	OPEN CursorCatTiposAcumulados
	FETCH NEXT FROM CursorCatTiposAcumulados
	INTO @ATT_IdTipoAcumulado ,@ATT_Pestania,@ATT_AcumuladoFiscal,@ATT_IdConceptoPDOTiposAcumulados
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdConceptoPDOTiposAcumulados = 0
		BEGIN			
			INSERT INTO CatConceptosPDOTiposAcumulados(IdConceptoPDO,IdTipoAcumulado,Pestania,AcumuladoFiscal,CreadoEl,CreadoPor)
			VALUES(@IdConceptoPDO,@ATT_IdTipoAcumulado,@ATT_Pestania,@ATT_AcumuladoFiscal,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			UPDATE CatConceptosPDOTiposAcumulados
			SET ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdConceptoPDOTiposAcumulados = @ATT_IdConceptoPDOTiposAcumulados
		END		
		
		FETCH NEXT FROM CursorCatTiposAcumulados
		INTO @ATT_IdTipoAcumulado ,@ATT_Pestania,@ATT_AcumuladoFiscal,@ATT_IdConceptoPDOTiposAcumulados
	END

	CLOSE CursorCatTiposAcumulados
	DEALLOCATE CursorCatTiposAcumulados						
	
	DELETE FROM CatConceptosPDOTiposAcumulados WHERE IdConceptoPDO = @IdConceptoPDO AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	IF @AutomaticoGlobal=1
	BEGIN
		INSERT INTO CatEmpleadosConceptosPDO(IdEmpleado,IdConceptoPDO,CreadoEl,CreadoPor) 
		SELECT IdEmpleado,@IdConceptoPDO,@ModificadoEl,@ModificadoPor FROM CatEmpleados WHERE FechaBaja IS NULL
	END
	ELSE
	BEGIN 
		DELETE FROM CatEmpleadosConceptosPDO WHERE IdConceptoPDO = @IdConceptoPDO
	END

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

