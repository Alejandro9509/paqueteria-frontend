CREATE PROCEDURE [dbo].[usp_ProCobranzaRegistrarPagosAbonos]
	@FechaHora datetime,	
	@IdCuentaBancaria int,
	@Importe money,
	@TipoCambio money,
	@ReferenciaBancaria varchar(50),    
	@IdConceptoCobranza int,
	@IdCliente int,
	@ImporteSaldoFavor money,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProFacturas ntext,
	@IdPeticion varchar(100),
	@PagoConContraRecibo bit, -- Bandera de pago con contra recibo 0= Pago normal / 1 = pago con contra recibo
	@CobranzaExterna bit,
	@IdCertificado int,
	@ClaveMetodoPago varchar(8),
	@RfcEmisorCtaOrd varchar(15),
	@NomBancoOrdExt varchar(100),
	@CtaOrdenante varchar(20),
	@TipoCodPago varchar(3),
	@CertPago varchar(MAX),
	@CadPago varchar(MAX),
	@SelloPago varchar(MAX),
	@IdMovimientoAnterior int = NULL,
	@MovimientoCFDI33 bit = NULL,
	@FolioFiscalUUIDFactor varchar(36) = NULL,
	@Compensacion money = NULL,
	@XMLArchivoOdenante ntext = NULL,
	@PagoConsolidado bit = NULL,
	@CuentaBancaria bit = 0,
	@dsArchivosFactoraje ntext = NULL,
	@FechaSustitucion datetime = NULL,
	@FechaCobro datetime = NULL
AS
DECLARE
	@docHandle int,
	@IdMovimientoBancario int,
	@IdMonedaCtaBancaria int,
	@ImporteFacturas money,
	@ImporteClienteDLLS money,
	@ImporteClientePESOS money,
	@IdFactura int,
	@IdFacturaPedienteCobrar int, -- para afectar el saldo pendiente de cobrar 
	@DoctoFactura varchar(50),
	@MensajeError varchar(250),
	@ATT_IdFactura int,
	@ATT_IdMoneda int,
	@ATT_IdSucursal int,
	@ATT_Importe money,
	@ATT_Referencia   varchar(50),
	@ATT_MetodoPago varchar(50),
	@IdCobranza int,
	@Porcentaje decimal(38,10), --Se modifico la escala de 7 a 10 por parte de la solicitud 681 
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosGenerales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@IdFacturaConceptoFacturacion int,
	@AbonoConcepto money,
	@Retiene bit,
	@Traslada bit,
	@NumeroMovimiento int,
	@Beneficiario varchar(150),
	@IdBeneficiario int,	
	@NumeroBeneficiario int,
	@ATT_IdContraReciboCliente int,
	@ImporteClienteDLLSContraRecibo money,
	@ImporteClientePESOSContraRecibo money,
	@IdConceptoCobranzaSaldoAFavor int,
	@Sustituto bit = 0,
	@ATT_EsFactoraje bit,
	@ATT_ImporteCompensacion money,
	@ATT_DocumentoConFactoraje int,
	@IdConceptoCobranzaFactoraje int,
	@IdContraReciboClienteFactura int,
	@IdClienteFactura int,
	@ATT_ImporteImpuestoFactura money,
	@ATT_IdCliente int ,
	@EsFactGeneral bit=0 /*Se agrego*/
	
	/*Varibles para facturas*/
	DECLARE @TotalFacturas int = 0, @ContadorFacturas int = 0
	DECLARE @VarProFacturas TABLE  
	(Registro int UNIQUE,
	IdFactura int ,
	Importe money,
	IdMoneda int,
	Referencia varchar(50),
	IdSucursal int,
	IdContraReciboCliente int,
	EsFactoraje bit,
	ImporteCompensacion money,
	DocumentoConFactoraje int,
	IdCliente int,
	MetodoPago varchar(50),
	Porcentaje float,
	PorcentajeImp float,
	EsFactGeneral bit,
	PRIMARY KEY (IdFactura)
	)

	/*Varibles para los registros en cobranza*/
	DECLARE @VarProCobranza TABLE  
	(IdCobranza int, 
	IdFactura int ,
	PRIMARY KEY (IdCobranza))

	/*variables para conceptos de facturacion*/
	DECLARE @VarProFacturasConceptosFacturacion TABLE  
	(IdFactura int,
	IdFacturaConceptoFacturacion int,
	RetieneImpuesto bit,
	TrasladaImpuesto bit, 
	PRIMARY KEY (IdFactura,IdFacturaConceptoFacturacion))
/*CAMBIO:
	Se cambiaron los cursosres por sentecias DML y variables tipo tabla.
	para generar pagos/abonos con mas de 1000 facturas y no dure mas de una hora.
VERSIÓN:
	8.0.55.48
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-08-18
INVOCADA DESDE:
	Regostrar: 
		pagos/abonos
		pagos/abonos consolidados
		Contra recibos
		Contra recibos consolidados
		Saldos a favor generados desde pagos/abonos
		Sustituir
SOLICITUD: 
	SOLICITUD 002280*/

/*CAMBIO:
	Se agregó un nuevo campo para obtener el porcentaje de impuestos que le toca del
	abono a cada factura, ademas de quitar la resta de los abonos al calculo del 
	importe de impuestos para cada uno y para las tablas de cobranza
MODIFICADA POR:
	David Omar Cabrera Bernal
FECHA DE MODIFICACIÓN:
	2020-09-29
INVOCADA DESDE:
	ClsProCobranza::Agregar
SOLICITUD: 
	SOLICITUD 003176*/

--Modificada por:  Yarazeth Isila Lemus Hernandez 
--Fecha de modificación: 02/11/2020
--Versión:  8.0.56.04
--Solicitud: 3305

--Modificada por:  Yarazeth Isila Lemus Hernandez 
--Version: 8.0.56.19
--Fecha de modificación: 12/11/2020
--Versión:  8.0.56.19
--Solicitud: 3401

--Modificada por:  Jesús Humberto Morales Mojica 
--Fecha de modificación: 22/12/2020
--Versión: 8.0.57.20
--Solicitud: 3601

/*CAMBIO:
	Se quito el redonde a 4 decimales del update para actualizar los abonos a los conceptos de facturacion.
VERSIÓN:
	Versión 8.0.58.06
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2021-01-22
SOLICITUD: 
	SOLICITUD 003601*/

BEGIN TRY
	BEGIN TRANSACTION
	    
	IF ISDATE(@FechaHora) = 0
		RAISERROR(N'La fecha del movimiento es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdCuentaBancaria,0) <= 0
		RAISERROR(N'El concepto de cobranza es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Importe,0) <= 0
		RAISERROR(N'El importe es un campo requerido',
			16,
			1
			)    

	IF ISNULL(@TipoCambio,0) <= 0
		RAISERROR(N'El tipo de cambio es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@ReferenciaBancaria)) = ''
		RAISERROR(N'La referencia bancaria es un campo requerido',
			16,
			1
			)                
    
	IF ISNULL(@IdConceptoCobranza,0) <= 0
		RAISERROR(N'El concepto de cobranza es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdCliente,0) <= 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
            
	IF @dsProFacturas IS NULL
		RAISERROR(N'Las facturas que se estan pagando son requeridos',
			16,
			1
			)
	
	IF ISNULL(@CuentaBancaria,0) = 0
	BEGIN
		IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdMovimientoAnterior AND IdCobranzaNoBancarizadoAnterior  IS NOT NULL)
		RAISERROR(N'El pago que intenta relacionar ya fue sustituído',
			16,
			1
			)
	END
	ELSE
	BEGIN
		IF EXISTS(SELECT IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdMovimientoBancario = @IdMovimientoAnterior AND IdMovimientoBancarioAnterior IS NOT NULL)
		RAISERROR(N'El pago que intenta relacionar ya fue sustituído',
			16,
			1
			)
	END
					
	IF NOT EXISTS(SELECT Ejercicio FROM ProEjerciciosPeriodos WHERE Ejercicio = YEAR(@FechaHora)) AND (Select isnull(Valor,0) From SisParametrosValores where Parametro = 'DeshabiltarContabilidadIntegrada')<> 1
		RAISERROR(N'El ejercicio contable no está abierto y por lo tanto no se puede registrar la información, contacte a su contador o al personal encargado de abrir el ejercicio contable',
			16,
			1
			)
			
	If @IdCertificado = 0
		SET @IdCertificado = NULL
		
	If @IdMovimientoAnterior = 0
		SET @IdMovimientoAnterior = NULL
	
	If @IdMovimientoAnterior IS NOT NULL
		SET @Sustituto = 1

	--se obtiene la moneda de la cuenta bancaria         
	SET @IdMonedaCtaBancaria = (SELECT IdMoneda FROM CatCuentasBancarias WHERE IdCuentaBancaria = @IdCuentaBancaria)
    
	--se carga las facturas a una tabla temporal
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturas
	
	SELECT ATT_IdFactura,ATT_Importe,ATT_IdMoneda,ATT_Referencia,ATT_IdSucursal,ATT_IdContraReciboCliente,ATT_EsFactoraje,ATT_ImporteCompensacion,ATT_DocumentoConFactoraje,ATT_IdCliente,ATT_MetodoPago
	INTO #TempProFacturas
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturas',2) 
	WITH (ATT_IdFactura int,ATT_Importe money,ATT_IdMoneda int,ATT_Referencia varchar(50),ATT_IdSucursal int,ATT_IdContraReciboCliente int,ATT_EsFactoraje bit,ATT_ImporteCompensacion money,ATT_DocumentoConFactoraje int,ATT_IdCliente int,ATT_MetodoPago varchar(50))
    
	EXEC sp_xml_removedocument @docHandle
	/*Facturas*/
	/*se inserta el loop en la variable tabla varprofacturas*/
	INSERT INTO @VarProFacturas (Registro,IdFactura,Importe ,IdMoneda ,Referencia,IdSucursal ,IdContraReciboCliente ,EsFactoraje ,ImporteCompensacion ,
	DocumentoConFactoraje ,	IdCliente ,	MetodoPago, Porcentaje,PorcentajeImp,EsFactGeneral)
	SELECT 
	ROW_NUMBER() OVER (ORDER BY CASE WHEN Temp.ATT_IdCliente = @IdCliente THEN 0 ELSE Temp.ATT_IdCliente END),
	Temp.ATT_IdFactura,
	Temp.ATT_Importe ,
	Temp.ATT_IdMoneda ,
	Temp.ATT_Referencia,
	Temp.ATT_IdSucursal ,
	Temp.ATT_IdContraReciboCliente ,
	Temp.ATT_EsFactoraje ,
	Temp.ATT_ImporteCompensacion ,
	Temp.ATT_DocumentoConFactoraje ,
	Temp.ATT_IdCliente ,	 
	Temp.ATT_MetodoPago, /*NULLIF regresa null si total-abonos= 0; entonces isNULL = true, se divide el importe entre el total para que de 1*/
						/*Para que no marque eror divizicion by zero*/
	(SELECT ( CAST(Temp.ATT_Importe AS float)/ ISNULL(NULLIF( CAST((Total-ISNULL(Abonos,0)) AS float) ,0) ,Total)  ) FROM ProFacturas WHERE IdFactura = Temp.ATT_IdFactura),/*@Porcentaje*/
	(SELECT ( CAST(Temp.ATT_Importe AS float)/ CAST(Total AS float)) FROM ProFacturas WHERE IdFactura = Temp.ATT_IdFactura) ,/*@Porcentaje Impuestos*/
	(SELECT CASE subpf.TipoFactura WHEN 7 THEN 1 ELSE 0 END FROM ProFacturas subpf WHERE subpf.IdFactura = Temp.ATT_IdFactura) /*@EsFactGeneral*/
		
	FROM #TempProFacturas AS Temp WHERE Temp.ATT_Importe != 0 --ORDER BY CASE WHEN ATT_IdCliente = @IdCliente THEN 0 ELSE ATT_IdCliente END
	
	SET @TotalFacturas = @@ROWCOUNT /*Se obtiene el total de registros*/

	/*Conceptos de facturacion*/
	INSERT INTO @VarProFacturasConceptosFacturacion (IdFactura ,IdFacturaConceptoFacturacion ,RetieneImpuesto ,TrasladaImpuesto)
	SELECT IdFactura ,IdFacturaConceptoFacturacion,RetieneImpuesto,TrasladaImpuesto 
	FROM ProFacturasConceptosFacturacion 
	WHERE IdFactura IN (Select IdFactura FROM @VarProFacturas)


	--SI ALGUNA FACTURA
	/*Facturacion externa*/
	/*Se cambio la validacion de facturacion externa al inicio , antes de relizar procesos mdl , eta validacion se hacia despues de registrar el movimiento de cobranza por factoraje*/
	/*Esta validacion era por factura 1:1 , se cambio por una validacion global de todas las facturas*/
	IF (SELECT TOP 1 FacturaExterna FROM ProFacturas WHERE  IdFactura IN (Select IdFactura FROM @VarProFacturas) AND FacturaExterna = 1 )  = 1 AND @CobranzaExterna <> 1
		RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
		16,
		1
		)
	 
	SET @IdFactura = (SELECT TOP 1 IdFactura FROM ProFacturas WHERE ( Estatus != 0 OR CanceladoEl IS NOT NULL OR ISNULL(Abonos,0) = Total) AND IdFactura IN(SELECT IdFactura FROM @VarProFacturas))
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)

		SET @MensajeError = 'La factura '+@DoctoFactura+' que esta intentando pagar no cumple con los criterios; Ya sea que no es de ese cliente, No tiene el estatus de pendiente de pago, Este cancelada o Ya fue pagada por otro usuario'

		RAISERROR(@MensajeError,
			16,
			1
			)
	END

	--SI ALGUNA FACTURA ESTA DENTRO DE UN CONTRA RECIBO SOLICITUD 10118
	SET @IdFactura = (select top 1 pcrcf.IdFactura from ProContraRecibosClienteFacturas as pcrcf
	inner join ProContraRecibosCliente as pcrc on pcrc.IdContraReciboCliente = pcrcf.IdContraReciboCliente
	where pcrcf.IdFactura IN (select IdFactura from @VarProFacturas) and pcrc.CanceladoEl is null)

	IF @IdFactura IS NOT NULL AND @IdFactura <> 0 AND @PagoConContraRecibo = 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
							WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
							ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
							END
							FROM ProFacturas AS pf
							INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
							INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
							WHERE IdFactura = @IdFactura)

		SET @MensajeError = 'No es posible aplicar el pago/abono a la '+@DoctoFactura+', ya que se encuentra dentro de un contra recibo.'
		RAISERROR(@MensajeError,
			16,
			1
			)
	END
	--FIN DE VALIDACION PARA SABER SI LA FACTURA ESTA DENTRO DE UN CONTRA RECIBO

	SET @ImporteFacturas = 0
	--OBTIENE LOS IMPORTES DE LA FACTURAS PAGADAS PARA ACTULIAZAR SALDO DE CLIENTYE
	SET @ImporteClienteDLLS = (SELECT ISNULL(SUM(Importe),0) FROM @VarProFacturas WHERE IdMoneda = 2)
	SET @ImporteClientePESOS = (SELECT ISNULL(SUM(Importe),0) FROM @VarProFacturas WHERE IdMoneda != 2)  
	
    IF @PagoConContraRecibo = 1  OR @ImporteSaldoFavor <= 0
    BEGIN
		IF @IdMonedaCtaBancaria = 2 --DOLARES
		BEGIN
			IF @ImporteClientePESOS = 0
			BEGIN
				IF @Importe <> (@ImporteClienteDLLS+@ImporteSaldoFavor)
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)
			END
			ELSE
			BEGIN
				SET @ImporteFacturas = @Importe - ((@ImporteClientePESOS / @TipoCambio) + @ImporteClienteDLLS)
				IF @ImporteFacturas > 1 OR @ImporteFacturas < -1
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)			
			END
		END
		ELSE
		BEGIN
			IF @ImporteClienteDLLS = 0
			BEGIN
				IF @Importe <> (@ImporteClientePESOS+@ImporteSaldoFavor)
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)
			END
			ELSE
			BEGIN
				SET @ImporteFacturas = @Importe - ((@ImporteClienteDLLS * @TipoCambio) + @ImporteClientePESOS)
				IF @ImporteFacturas > 1 OR @ImporteFacturas < -1
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)			
			END		
		END
	END
	
	SET @NumeroMovimiento = (Select ISNULL(MAX(NumeroMovimiento),0)+1 FROM ProMovimientosBancarios where IdCuentaBancaria = @IdCuentaBancaria)
	
	--- Registrar Beneficiario 
	SELECT @Beneficiario = NombreFiscal FROM CatClientes WHERE IdCliente = @IdCliente
	Select @IdBeneficiario = (Select IdBeneficiario  from CatBeneficiarios where RTRIM(LTRIM(Nombre)) = RTRIM(LTRIM(@Beneficiario)))
	IF  ISNULL(@IdBeneficiario ,0) = 0 
	BEGIN
		SELECT @NumeroBeneficiario = (SELECT ISNULL(MAX(NumeroBeneficiario),0)+1 AS Codigo FROM CatBeneficiarios)
		
		INSERT INTO CatBeneficiarios(NumeroBeneficiario,Nombre,CreadoEl,CreadoPor,Activo)
		VALUES(@NumeroBeneficiario,RTRIM(LTRIM(@Beneficiario)),@CreadoEl,@CreadoPor,1)
		
		SET @IdBeneficiario = (SELECT IDENT_CURRENT('CatBeneficiarios'))	   
	END
		
	--- Registrar Movimiento Bancario
	INSERT INTO ProMovimientosBancarios(CreadoEl,CreadoPor,Fecha,IdCuentaBancaria,Importe,ReferenciaBancaria,TipoCambio,IdTipoMovimientoBancario,NumeroMovimiento,TipoBeneficiario,IdBeneficiario,Beneficiario,IdCertificado,ClaveMetodoPago,RfcEmisorCtaOrd,NomBancoOrdExt,CtaOrdenante,TipoCodPago,CertPago,CadPago,SelloPago,Sustituto,MovimientoCFDI33,FolioFiscalUUIDFactor,Compensacion,XMLArchivoOdenante,PagoConsolidado,FechaSustitucion,FechaCobro)
	VALUES(@CreadoEl,@CreadoPor,@FechaHora,@IdCuentaBancaria,@Importe,@ReferenciaBancaria,@TipoCambio,1,@NumeroMovimiento,2,@IdBeneficiario,RTRIM(LTRIM(@Beneficiario)),@IdCertificado,@ClaveMetodoPago,@RfcEmisorCtaOrd,@NomBancoOrdExt,@CtaOrdenante,@TipoCodPago,@CertPago,@CadPago,@SelloPago,@Sustituto,@MovimientoCFDI33,@FolioFiscalUUIDFactor,@Compensacion,@XMLArchivoOdenante,@PagoConsolidado,@FechaSustitucion,@FechaCobro)
    
	SET @IdMovimientoBancario = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))
	
	/*Documentos de pago/abono con factoraje*/
	IF @dsArchivosFactoraje IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsArchivosFactoraje
		
		SELECT ATT_FolioFiscal,ATT_ArchivoNombre, ATT_Compensacion ,ATT_XMLArchivo
		INTO #TempArchivosFactoraje
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ArchivosFactoraje',2) 
		WITH (ATT_FolioFiscal varchar(36),ATT_ArchivoNombre ntext, ATT_Compensacion money,ATT_XMLArchivo ntext)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProMovimientosBancariosDocumentosFactoraje(IdMovimientoBancario,FolioFiscalUUIDFactor,Compensacion,XMLArchivoOrdenante,NombreArchivo)
		SELECT @IdMovimientoBancario,ATT_FolioFiscal,ATT_Compensacion,ATT_XMLArchivo,ATT_ArchivoNombre
		FROM #TempArchivosFactoraje
	END

	--seccion para agregar el idmovimientobancario a paremtros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = @IdPeticion AND IdUsuario = @CreadoPor)
	BEGIN
		INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES(@IdPeticion,@IdMovimientoBancario,@CreadoPor)
	END
	ELSE
	BEGIN
		UPDATE SisParametrosPagina SET Parametros = @IdMovimientoBancario WHERE Pagina = @IdPeticion AND IdUsuario = @CreadoPor
	END
    
    --Actualiza el movimiento anterior (sustituido) Solicitud 8555
	IF ISNULL(@CuentaBancaria,0) = 1 /* solicitud 011473 -  pagos/abonos sin cuenta bancaria*/
	BEGIN
		IF @IdMovimientoAnterior IS NOT NULL
		BEGIN
			UPDATE ProMovimientosBancarios SET IdMovimientoBancarioAnterior = @IdMovimientoBancario WHERE IdMovimientoBancario = @IdMovimientoAnterior
		END
	END
	ELSE
	BEGIN
		IF @IdMovimientoAnterior IS NOT NULL
		BEGIN
			--UPDATE ProMovimientosBancarios SET IdCobranzaNoBancarizado = @IdMovimientoBancario WHERE IdMovimientoBancario = @IdMovimientoAnterior
			UPDATE ProCobranzaNoBancarizado SET IdMovimientoBancario = @IdMovimientoBancario WHERE IdCobranzaNoBancarizado = @IdMovimientoAnterior /* actualiza el movimiento sin cuenta bancaria*/
		END
	END

	/*Genera el registro en cobranza*/
	/*Se registran todas las facturas en cobranza*/
	INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdMovimientoBancario,IdSucursal,Importe,Referencia,TipoCambio,CobranzaExterna,IdCertificado,ClaveMetodoPago,FechaSustitucion)
	SELECT
	@CreadoEl, --parametro
	@CreadoPor, --parametro
	@FechaHora, --parametro
	CASE WHEN ISNULL(pf.IdCliente,0)= 0 THEN @IdCliente ELSE @IdCliente END,
	@IdConceptoCobranza,--parametro
	pf.IdFactura ,---@ATT_IdFactura,
	pf.IdMoneda ,---@ATT_IdMoneda,
	@IdMovimientoBancario, --Movimiento bancario generado del pago/abono
	pf.IdSucursal ,---@ATT_IdSucursal,
	pf.Importe ,---@ATT_Importe,
	pf.Referencia ,---@ATT_Referencia,
	@TipoCambio, --parametro
	@CobranzaExterna, --parametro
	@IdCertificado, --parametro
	pf.MetodoPago ,---@ATT_MetodoPago,
	@FechaSustitucion --parametro
	FROM @VarProFacturas as pf

	/*Se guardan en una varaible tabla (@VarProCobranza) los registros que se acaban de insertar en procobranza*/
	/*Estos se buscan por medio del movimiento bancario que se creo para cobranza, el usuario y el concepto de cobranza*/
	INSERT INTO @VarProCobranza(IdCobranza,IdFactura)
	SELECT
	IdCobranza,IdFactura
	FROM ProCobranza
	WHERE
	IdMovimientoBancario = @IdMovimientoBancario
	AND CreadoPor = @CreadoPor	
	AND IdConceptoCobranza = @IdConceptoCobranza


	/*Cobranza facturacion externa*/
	/*Se cambio la validacion de facturacion externa al inicio , antes de relizar procesos mdl , esta validacion se hacia despues de registrar los impuestos de cobranza*/
	/*Esta validacion era cobranza 1:1 , se cambio por una validacion global*/
	IF (SELECT TOP 1 CobranzaExterna FROM ProCobranza WHERE IdCobranza IN (SELECT IdCobranza FROM @VarProCobranza) AND CobranzaExterna = 1 )  = 1 AND @CobranzaExterna <> 1
	BEGIN
		RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
		16,
		1
		)
	END

	/*Factoraje*/
	-- se inserta el registro por compensacion
	INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdMovimientoBancario,IdSucursal,Importe,Referencia,TipoCambio,CobranzaExterna,IdCertificado,ClaveMetodoPago,IdCobranzaOrigen,FechaSustitucion)        
    SELECT
	@CreadoEl,
	@CreadoPor,
	@FechaHora,
	vpf.IdCliente ,
	--DOCUMENTO CON FACTORJAE (0) - SIGNIFICA QUE ES LA PRIMERA VEZ QUE SE VA AREGISTRAR EL PAGO POR FACTORAJE Y TOMARA EL CONCEPTO DE COBRANZA DE HONORARIOS
	--DOCUMENTO CON FACTORAJE (1) - SIGNIFIA QUE ES EL 2DO PAGO CON FACTORAJE , Y TENDRA EL CONCEPTO DE INTERESES. EN TEORIA ESTE ES EL ULTIMO PAGO Y SE ESTAN PAGANDO LOS INTERESES SEGUN LA GUIA DE COMPLEMENTO DE PAGO 
	CASE
	ISNULL(vpf.DocumentoConFactoraje,0)
	WHEN 1 THEN 
		(SELECT IdConceptoCobranza FROM CatConceptosCobranza WHERE ConceptoCobranza = 'HONORARIOS' AND DefinidoPorSistema = 1)
	ELSE 
		CASE
		WHEN NOT EXISTS (SELECT IdConceptoCobranza FROM ProCobranza 
						WHERE CanceladoEl IS NULL 
						AND 
						IdConceptoCobranza = (SELECT IdConceptoCobranza FROM CatConceptosCobranza WHERE ConceptoCobranza = 'HONORARIOS' AND DefinidoPorSistema = 1)
						AND
						IdFactura = vpf.IdFactura----@ATT_IdFactura 
						AND IdCobranzaOrigen IS NOT NULL)
		THEN
			(SELECT IdConceptoCobranza FROM CatConceptosCobranza WHERE ConceptoCobranza = 'HONORARIOS' AND DefinidoPorSistema = 1)
		ELSE 
			(SELECT IdConceptoCobranza FROM CatConceptosCobranza WHERE ConceptoCobranza = 'INTERESES' AND DefinidoPorSistema = 1)
		END
	END AS IdConceptoCobranzaFactoraje,
	vpf.IdFactura ,				--	@ATT_IdFactura = 
	vpf.IdMoneda ,				--	@ATT_IdMoneda = 
	@IdMovimientoBancario,		--	Movimiento bancario generado del pago/abono
	vpf.IdSucursal ,			--	@ATT_IdSucursal = 
	vpf.ImporteCompensacion ,	--	@ATT_ImporteCompensacion =
	vpf.Referencia ,			--	@ATT_Referencia = 
	@TipoCambio,				--	parametro
	@CobranzaExterna,			--	parametro
	@IdCertificado,				--	parametro
	vpf.MetodoPago,				--	@ATT_MetodoPago =
	vpc.IdCobranza,				-- Id Cobranza Origen 
	@FechaSustitucion			--parametro
	FROM @VarProFacturas as vpf
	INNER JOIN @VarProCobranza vpc ON vpf.IdFactura = vpc.IdFactura  
	WHERE  
	vpf.EsFactoraje = 1 /*Factoraje*/

	

	/*Se actualiza el pago/abono de las facturas*/
	/*
		EsFactoraje[1] pago/abono de factura con factoraje
		EsFactoraje[0] pago/abono de factura
	*/
	UPDATE pf 
	SET
		pf.Abonos = CASE ISNULL(vpf.EsFactoraje,0)
					WHEN 1 THEN ISNULL(pf.Abonos,0) + vpf.Importe + vpf.ImporteCompensacion
					WHEN 0 THEN ISNULL(pf.Abonos,0) + vpf.Importe
					END,
		pf.Estatus = CASE ISNULL(vpf.EsFactoraje,0)
					WHEN 1 THEN CASE WHEN (ISNULL(pf.Abonos,0)+ vpf.Importe + vpf.ImporteCompensacion) = pf.Total THEN 1 ELSE pf.Estatus END
					WHEN 0 THEN CASE WHEN (ISNULL(pf.Abonos,0)+ vpf.Importe)= pf.Total THEN 1 ELSE pf.Estatus END
					END,
		pf.ModificadoEl = @CreadoEl,
		pf.ModificadoPor = @CreadoPor,
		pf.EsFactoraje = vpf.EsFactoraje --@ATT_EsFactoraje
	FROM ProFacturas pf
	INNER JOIN @VarProFacturas vpf ON pf.IdFactura = vpf.IdFactura

	
	/*Conceptos de facturacion impuestos*/
	/*Se inserta el pago/abono en ProCobranzaFacturaConceptosFacturacion*/
	INSERT INTO ProCobranzaFacturaConceptosFacturacion(IdFacturaConceptoFacturacion,IdCobranza,Importe)
	SELECT 
	AbonoConceptosFacturacion.IdFacturaConceptoFacturacion,
	AbonoConceptosFacturacion.IdCobranza, -----@IdCobranza,
	(SELECT 
		(pfcf.Importe-ISNULL(pfcf.Descuento,0)-ISNULL(pfcf.Abonos,0))*AbonoConceptosFacturacion.Porcentaje --@Porcentaje 
		FROM ProFacturasConceptosFacturacion pfcf
		WHERE pfcf.IdFacturaConceptoFacturacion IN(AbonoConceptosFacturacion.IdFacturaConceptoFacturacion) /*concepto facturacion*/) AS AbonoConcepto

	FROM (
		SELECT /*Conceptos facturacion*/
		IdFacturaConceptoFacturacion,
		vpf.Porcentaje,
		vpc.IdCobranza
		FROM ProFacturasConceptosFacturacion pf
		INNER JOIN @VarProFacturas vpf ON pf.IdFactura = vpf.IdFactura
		INNER JOIN @VarProCobranza vpc ON pf.IdFactura = vpc.IdFactura
		--WHERE IdFactura IN (@ATT_IdFactura)
	) AbonoConceptosFacturacion



	/*Se actulizan los abonos de los conceptos de facturacion*/
	UPDATE pfcf							    /*-Abono del concepto de facturacion segun la parte proporcionar que le corresponde (porcentaje) importe-descuento-bonos*porcentaje -*/
	SET pfcf.Abonos = ISNULL(pfcf.Abonos,0)+((pfcf.Importe-ISNULL(pfcf.Descuento,0)-ISNULL(pfcf.Abonos,0))*vpf.Porcentaje) /*Abono Concepto*/
	FROM
	ProFacturasConceptosFacturacion pfcf
	INNER JOIN @VarProFacturas vpf ON pfcf.IdFactura = vpf.IdFactura

	

	/*Impuestos de cobranza segun el tipo de fatura*/  
	/*Impuestos calculados de facturacion general TipoFactura = 7 , EsFactGeneral = 1*/
	/*Se registran los impuestos en cobranza*/
	INSERT INTO ProCobranzaImpuestos(IdCobranza,IdImpuesto,Importe,CreadoPor,CreadoEl)
	SELECT
	FacturasImpuestos.IdCobranza, /*@IdCobranza*/
	FacturasImpuestos.IdImpuesto,
	(/*@ATT_ImporteImpuestoFactura*/
	(FacturasImpuestos.Importe * (FacturasImpuestos.PorcentajeAbono /*@Porcentaje*/))
	) AS ImporteImpuesto,
	@CreadoPor, -- parametro
	@CreadoEl	-- parametro
	FROM(SELECT 
		pfi.IdFactura,
		pfi.IdImpuesto, 
		pfi.Porcentaje, 
		pfi.Importe,
		(SELECT Porcentaje FROM CatImpuestos WHERE IdImpuesto = pfi.IdImpuesto) AS PorcentajeIVA,
		(SELECT TipoCalculo FROM CatImpuestos WHERE IdImpuesto = pfi.IdImpuesto) As TipoCalculo,
		(SELECT NombreImpuestoXML FROM CatImpuestos WHERE IdImpuesto = pfi.IdImpuesto) AS NombreImpuestoXML,
		vpc.IdCobranza,
		vpf.PorcentajeImp AS PorcentajeAbono

		FROM ProFacturasImpuestos pfi
		INNER JOIN @VarProFacturas vpf ON pfi.IdFactura = vpf.IdFactura
		INNER JOIN @VarProCobranza vpc ON pfi.IdFactura = vpc.IdFactura
		WHERE 
		vpf.EsFactGeneral = 1 /*Factura tipo general*/
	) FacturasImpuestos



	/*Impuestos calculados de facturacion que no son de tipo general EsFactGeneral = 0*/
	/*Se registran los impuestos en cobranza*/
	INSERT INTO ProCobranzaImpuestos(IdCobranza,IdImpuesto,Importe,CreadoPor,CreadoEl)
	SELECT 
	vpc.IdCobranza, --@IdCobranza,
	pfi.IdImpuesto,
	((pfi.Importe*vpf.PorcentajeImp/*@Porcentaje*/))  AS ImporteT,
	@CreadoPor, -- parametro
	@CreadoEl	-- parametro
	FROM ProFacturasImpuestos AS pfi
	INNER JOIN CatImpuestos AS ci ON pfi.IdImpuesto = ci.IdImpuesto
	INNER JOIN @VarProFacturas vpf ON pfi.IdFactura = vpf.IdFactura
	INNER JOIN @VarProCobranza vpc ON pfi.IdFactura = vpc.IdFactura
	WHERE vpf.EsFactGeneral = 0 /*NO es Factura tipo general*/

	/*Cobranza Importes sin simpuestos en ProCobranza para el reporte de pagos*/
	/*EsFactGeneral= 1; es factura tipo general*/
	UPDATE ProCobranza SET
		ProCobranza.ImpuestosRetenidosFederales = ImpuestosCobranza.ImpuestosRetenidosFederales,
		ProCobranza.ImpuestosRetenidosLocales =	ImpuestosCobranza.ImpuestosRetenidosLocales,
		ProCobranza.ImpuestosTrasladadosFederales = ImpuestosCobranza.ImpuestosTrasladadosFederales,
		ProCobranza.ImpuestosTrasladadosLocales =	ImpuestosCobranza.ImpuestosTrasladadosLocales,
		ProCobranza.ImporteSinImpuestos = ProCobranza.Importe - ImpuestosCobranza.ImpuestosTrasladadosFederales + ImpuestosCobranza.ImpuestosRetenidosFederales - ImpuestosCobranza.ImpuestosRetenidosLocales + ImpuestosCobranza.ImpuestosTrasladadosLocales
	FROM ProCobranza 
	INNER JOIN
	(SELECT /*Se hace el calculo de los impuestos*/
		pc.IdCobranza,
		ISNULL((CASE ISNULL(vpf.EsFactGeneral,0)
		WHEN 1 THEN (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = pc.IdCobranza /*@IdCobranza*/ AND CatImpuestos.TipoCalculo = 2 AND CatImpuestos.EsImpuestoFederal = 1)
		WHEN 0 THEN (SELECT Sum(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = pc.IdCobranza /*@IdCobranza*/ AND CatImpuestos.TipoCalculo = 2)
		END),0) AS ImpuestosRetenidosFederales,

		ISNULL((CASE ISNULL(vpf.EsFactGeneral,0)
		WHEN 1 THEN (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = pc.IdCobranza /*@IdCobranza*/ AND CatImpuestos.TipoCalculo = 2 AND CatImpuestos.EsImpuestoLocal = 1)
		WHEN 0 THEN 0
		END),0) AS ImpuestosRetenidosLocales,

		ISNULL((CASE ISNULL(vpf.EsFactGeneral,0)
		WHEN 1 THEN (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = pc.IdCobranza /*@IdCobranza*/ AND CatImpuestos.TipoCalculo = 1 AND CatImpuestos.EsImpuestoFederal = 1)
		WHEN 0 THEN (SELECT sum(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = pc.IdCobranza /*@IdCobranza*/ AND CatImpuestos.TipoCalculo = 1)
		END),0) AS ImpuestosTrasladadosFederales,

		ISNULL((CASE ISNULL(vpf.EsFactGeneral,0)
		WHEN 1 THEN (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = pc.IdCobranza /*@IdCobranza*/ AND CatImpuestos.TipoCalculo = 1 AND CatImpuestos.EsImpuestoLocal = 1)
		WHEN 0 THEN 0
		END),0) AS ImpuestosTrasladadosLocales

		FROM ProCobranza pc
		INNER JOIN @VarProCobranza vpc ON pc.IdCobranza = vpc.IdCobranza
		INNER JOIN @VarProFacturas vpf on vpc.IdFactura = vpf.IdFactura
	) ImpuestosCobranza ON ProCobranza.IdCobranza = ImpuestosCobranza.IdCobranza



	-- Inicio alctualizar estatus de contra recibo de cliente
	DECLARE @FolioContraRecibo int, @DocFacturaContraRecibo varchar(50)
    IF @PagoConContraRecibo = 1 -- Bandera activa de pago con contra recibo
    BEGIN
		-- valida que el contra recibo no este cancelado
		SET @FolioContraRecibo = (Select TOP 1 Folio from ProContraRecibosCliente WHERE IdContraReciboCliente IN (SELECT IdContraReciboCliente FROM @VarProFacturas) /*= @ATT_IdContraReciboCliente*/)
	
		IF EXISTS(Select TOP 1 IdContraReciboCliente from ProContraRecibosCliente where Estatus = 3 AND IdContraReciboCliente IN (SELECT IdContraReciboCliente FROM @VarProFacturas) /*= @ATT_IdContraReciboCliente*/)	
		BEGIN					
			SET @MensajeError = 'El contra recibo de cliente '+CAST(RIGHT('00000' + Ltrim(Rtrim(@FolioContraRecibo)),5) AS VARCHAR(MAX))+' que esta intentando pagar ya fue cancelada por otro usuario, verificar información'
			RAISERROR(@MensajeError,
						16,
						1
						)
		END	
						
		-- valida que la factura sea la que pertenece al contrarecibo 
		IF EXISTS(
		Select TOP 1 vpf.IdFactura 
		FROM @VarProFacturas vpf
		WHERE NOT EXISTS (
			Select pcrcf.IdFactura 
			from ProContraRecibosClienteFacturas pcrcf
			where pcrcf.IdFactura = vpf.IdFactura 
			AND pcrcf.IdContraReciboCliente = vpf.IdContraReciboCliente)
		)
		BEGIN		
			SET @DocFacturaContraRecibo  = (SELECT 
											CASE cf.Serie
											WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
											ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie END
											FROM ProFacturas AS pf
											INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
											INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
											WHERE IdFactura IN ((Select TOP 1 vpf.IdFactura 
																FROM @VarProFacturas vpf
																WHERE NOT EXISTS (
																	Select pcrcf.IdFactura 
																	from ProContraRecibosClienteFacturas pcrcf
																	where pcrcf.IdFactura = vpf.IdFactura 
																	AND pcrcf.IdContraReciboCliente = vpf.IdContraReciboCliente)
																)
											/*= @IdFactura*/))
						
			SET @MensajeError = 'La factura '+@DocFacturaContraRecibo+' que esta intentando pagar ya no pertenece al contra recibo '+CAST(RIGHT('00000' + Ltrim(Rtrim(@FolioContraRecibo)),5) AS VARCHAR(MAX))+', verificar información'

			RAISERROR(@MensajeError,
						16,
						1
						)
		END			
			
		-- Actualiza la información en la tabla puente, asignando el IdCobranza si es nulo, o agregando un nuevo registro si ya tiene registrado un pago 
		--IF (SELECT TOP 1 ISNULL(IdCobranza,0) FROM ProContraRecibosClienteFacturas WHERE IdFactura IN (SELECT IdFactura FROM @VarProFacturas) ORDER BY IdContraReciboClienteFactura DESC) = 0
		----Se agrega el top 1 para evitar IdCobranza duplicado en caso de que existan mas registros de la factura con IdCobranza NULL SOLICITUD 010143
		--BEGIN
			UPDATE ProContraRecibosClienteFacturas 
			SET IdCobranza = vpc.IdCobranza --@IdCobranza 
			FROM ProContraRecibosClienteFacturas
			INNER JOIN @VarProFacturas vpf ON ProContraRecibosClienteFacturas.IdFactura = vpf.IdFactura
			INNER JOIN @VarProCobranza vpc ON vpf.IdFactura = vpc.IdFactura
			WHERE
			ISNULL(ProContraRecibosClienteFacturas.IdCobranza,0) = 0
			AND ProContraRecibosClienteFacturas.IdContraReciboCliente = vpf.IdContraReciboCliente
		--END
		--ELSE
		--BEGIN
			INSERT INTO ProContraRecibosClienteFacturas (IdContraReciboCliente,IdFactura,Importe,IdCobranza) 
			SELECT
			vpf.IdContraReciboCliente,
			vpf.IdFactura,
			vpf.Importe,
			vpc.IdCobranza
			FROM @VarProFacturas vpf
			INNER JOIN @VarProCobranza vpc On vpf.IdFactura = vpc.IdFactura
			WHERE
			NOT EXISTS(SELECT TOP 1 pcrcf.IdFactura 
						FROM ProContraRecibosClienteFacturas pcrcf
						WHERE pcrcf.IdCobranza = vpc.IdCobranza	AND pcrcf.IdFactura = vpc.IdFactura )
		--END 
		
		/*Actualiza el total de abonos de los contrarecibos segun el tipo de moneda de la factura*/		
		UPDATE ProContraRecibosCliente SET 
		TotalAbonoDolares = TotalAbonoDolares + ISNULL(vpfDolares.ImporteClienteDLLSContraRecibo,0), 
		TotalAbonoPesos = TotalAbonoPesos + ISNULL(vpfPesos.ImporteClientePESOSContraRecibo,0)
		FROM ProContraRecibosCliente
		LEFT JOIN (
			SELECT
			IdContraReciboCliente, 
			SUM(Importe) /*Pesos*/ AS ImporteClientePESOSContraRecibo

			FROM @VarProFacturas
			WHERE
			IdMoneda = 1
			GROUP BY IdContraReciboCliente,IdMoneda
		) vpfPesos ON ProContraRecibosCliente.IdContraReciboCliente = vpfPesos.IdContraReciboCliente
		LEFT JOIN (
			SELECT
			IdContraReciboCliente, 
			SUM(Importe) /*Dolares*/ AS ImporteClienteDLLSContraRecibo

			FROM @VarProFacturas
			WHERE
			IdMoneda = 2
			GROUP BY IdContraReciboCliente,IdMoneda
		) vpfDolares ON ProContraRecibosCliente.IdContraReciboCliente = vpfDolares.IdContraReciboCliente
		--WHERE ProContraRecibosCliente.IdContraReciboCliente =  	@ATT_IdContraReciboCliente
			
		/*Actualiza estatus ContraRecibo del cliente*/
		UPDATE pcrc SET 
		pcrc.Estatus =	CASE 
						--WHEN CantidadFacturasPagadas > 0 THEN 
						--	CASE
							WHEN CantidadFacturas = CantidadFacturasPagadas THEN
								2	-- Pagada
							ELSE
								1	-- Pendiente de pagar
						--	END
						--ELSE
						--		0	-- Pendiente de pagar
						END, 
		pcrc.TotalSaldoPesos = pcrc.TotalPesos - pcrc.TotalAbonoPesos, 
		pcrc.TotalSaldoDolares = pcrc.TotalDolares-pcrc.TotalAbonoDolares 
		FROM ProContraRecibosCliente pcrc
		INNER JOIN ( 
			SELECT
			vpf.IdContraReciboCliente,
			(SELECT  count(ProFacturas.Estatus)
			FROM  ProContraRecibosClienteFacturas 
			INNER JOIN	ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
			WHERE 
			(ProContraRecibosClienteFacturas.IdContraReciboCliente = vpf.IdContraReciboCliente/*@ATT_IdContraReciboCliente*/  
			AND ProFacturas.Estatus<> 2) ) AS CantidadFacturas,

			(SELECT  count(ProFacturas.Estatus)
			FROM  ProContraRecibosClienteFacturas 
			INNER JOIN 	ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
			WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = vpf.IdContraReciboCliente/*@ATT_IdContraReciboCliente*/   
			and ProFacturas.Estatus = 1 AND ProFacturas.Estatus<> 2 )) AS CantidadFacturasPagadas

			FROM
			@VarProFacturas vpf
			GROUP BY vpf.IdContraReciboCliente
		) FacturasContraRecibosCliente ON pcrc.IdContraReciboCliente = FacturasContraRecibosCliente.IdContraReciboCliente
			

	END	 -- Bandera activa de pago con contra recibo
		

	/*Se registra el saldo a favor generado desde pagos/abonos*/
	IF @ImporteSaldoFavor > 0
	BEGIN
		SET @IdConceptoCobranzaSaldoAFavor = (Select IdConceptoCobranza from CatConceptosCobranza Where ConceptoCobranza = 'SALDO A FAVOR' And DefinidoPorSistema = 1)
			
		INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdMovimientoBancario,IdSucursal,Importe,Referencia,TipoCambio,Saldo,Secuencia,FechaSustitucion)
		VALUES(@CreadoEl,@CreadoPor,@FechaHora,@IdCliente,@IdConceptoCobranzaSaldoAFavor,NULL,@IdMonedaCtaBancaria,@IdMovimientoBancario,NULL,@ImporteSaldoFavor,'SALDO A FAVOR',@TipoCambio,@ImporteSaldoFavor,0,@FechaSustitucion)        
	END


	/*verificar que la suma de cobranza por factura sea igual a los abonos*/
	SET @IdFactura = 
	(SELECT TOP 1 pf.IdFactura 
	FROM ProFacturas AS pf 
	INNER JOIN @VarProFacturas AS tpf ON pf.IdFactura = tpf.IdFactura 
	WHERE ISNULL(pf.Abonos,0) != 
		(
			SELECT
			SUM(Importe) 
			FROM (
				SELECT 
				ISNULL(SUM(pc.Importe),0) as Importe
				FROM ProCobranza AS pc 
				INNER JOIN CatConceptosCobranza AS ccc ON pc.IdConceptoCobranza = ccc.IdConceptoCobranza 
				LEFT JOIN ProMovimientosBancarios AS pmb ON pc.IdMovimientoBancario = pmb.IdMovimientoBancario
				WHERE ccc.TipoConcepto = 2 
				AND pc.IdFactura = tpf.IdFactura 
				AND 
				(
				(pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NULL AND pmb.CanceladoEl IS NULL AND pc.IdCobranzaNoBancarizado is null) 
					OR (pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NOT NULL AND pmb.FechaCancelacionSAT IS NULL) 
					OR (pc.IdConceptoCobranza IN(3) AND pc.CanceladoEl IS NULL) 
					OR (pc.IdConceptoCobranza IN(6) AND pc.CanceladoEl IS NULL AND NOT EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor)) 
					OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND Secuencia=pc.Secuencia AND FolioFiscalUUIDPagos IS NOT NULL AND FechaCancelacionSAT IS NULL))
					OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND FolioFiscalUUIDPagos IS NULL AND pc.CanceladoEl IS NULL))
					)
				--AND (pc.IdMovimientoBancario IS NOT NULL OR pc.IdNotaCredito IS NOT NULL OR pc.IdCobranzaSaldoAFavor IS NOT NULL)
				--/*SOLICITUD 011473 - PAGO/ABONO SIN CUENTA BANCARIA*/
				--OR (pc.IdCobranzaNoBancarizado <> 0 AND pc.CanceladoEl is NULL AND pc.IdFactura = tpf.IdFactura)
				UNION ALL
				SELECT 
				ISNULL(SUM(pc.Importe),0) as Importe
				FROM ProCobranza AS pc 
				INNER JOIN CatConceptosCobranza AS ccc ON pc.IdConceptoCobranza = ccc.IdConceptoCobranza 
				LEFT JOIN ProMovimientosBancarios AS pmb ON pc.IdMovimientoBancario = pmb.IdMovimientoBancario
				WHERE ccc.TipoConcepto = 2 
				AND pc.IdFactura = tpf.IdFactura 
				/*SOLICITUD 011473 - PAGO/ABONO SIN CUENTA BANCARIA*/
				AND (pc.IdCobranzaNoBancarizado <> 0 AND pc.CanceladoEl is NULL AND pc.IdFactura = tpf.IdFactura)
				AND (pc.IdMovimientoBancario IS NULL AND pc.IdNotaCredito IS NULL AND pc.IdCobranzaSaldoAFavor IS NULL)
			)ImporteTotal
		)
	)/*IdFactura*/

	


	IF @IdFactura IS NULL /*Solicitud: 002685*/
	BEGIN
		SET @IdFactura = 0
	END
		
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
							WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
							ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie END
							FROM ProFacturas AS pf
							INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
							INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
							WHERE IdFactura = @IdFactura)

		SET @MensajeError =    'El saldo de la factura* '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago a esta factura.'
                    
		RAISERROR(@MensajeError,
			16,
			1
			)            
	END

		

	/*verificar que la suma de cobranza por factura sea igual a los abonos*/
	--Se comenta este codigo por error presentado en el cliente comandos
	SET @IdFactura = (SELECT 
	TOP 1 pf.IdFactura 
	FROM ProFacturasConceptosFacturacion AS pf 
	INNER JOIN @VarProFacturas AS tpf ON pf.IdFactura = tpf.IdFactura 
	WHERE (round(pf.Importe,2) > 0 
	AND round(ISNULL(pf.Abonos,0),2)> round(pf.Importe,2)) OR (pf.Importe < 0 AND round(ISNULL(pf.Abonos,0),0) < round(pf.Importe,2)))
	
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
							WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
							ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie END
							FROM ProFacturas AS pf
							INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
							INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
							WHERE IdFactura = @IdFactura)
    
		SET @MensajeError =    'El saldo de un concepto de la factura '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago o una nota de crédito a esta factura.'
                    
		RAISERROR(@MensajeError,
			16,
			1
			)
	END
    
	/*verificar que la suma de cobranza por factura sea igual a los abonos*/
	SET @IdFactura = (SELECT TOP 1 pf.IdFactura 
						FROM ProFacturas AS pf 
						INNER JOIN @VarProFacturas AS tpf ON pf.IdFactura = tpf.IdFactura 
						WHERE ISNULL(pf.Abonos,0) > pf.Total)

	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
							WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
							ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
							END
							FROM ProFacturas AS pf
							INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
							INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
							WHERE IdFactura = @IdFactura)
    
		SET @MensajeError =    'El saldo de la factura '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago a esta factura.'
                    
		RAISERROR(@MensajeError,
			16,
			1
			)
	END       

	/*Se encarga de actualizar los saldos de los clientes , segun la moneda de la factura*/
	UPDATE ca 
	SET 
	ca.SaldoCreditoDLLS = ca.SaldoCreditoDLLS - ISNULL(varProfacturasDolares.ImporteClienteDLLS,0) - ISNULL(varProfacturasDolares.ImporteCompensacion,0)  ,--se agrego isnull para evitar calcular errores al calcular el saldo 
	ca.SaldoCredito = ca.SaldoCredito - ISNULL(varProfacturasPesos.ImporteClientePESOS,0) - ISNULL(varProfacturasPesos.ImporteCompensacion,0) --se agrego isnull para evitar calcular errores al calcular el saldo
	FROM  CatClientes ca 
	LEFT JOIN(
		SELECT		
		pf.IdCliente ,
		SUM(ISNULL(pf.Importe,0)) AS ImporteClientePESOS,
		SUM(ISNULL(pf.ImporteCompensacion,0)) AS ImporteCompensacion
		FROM @VarProFacturas as pf
		where pf.IdMoneda = 1
		GROUP BY pf.IdCliente,pf.IdMoneda
	) varProfacturasPesos ON ca.IdCliente = varProfacturasPesos.IdCliente
	LEFT JOIN(
		SELECT		
		pf.IdCliente ,
		SUM(ISNULL(pf.Importe,0)) AS ImporteClienteDLLS,
		SUM(ISNULL(pf.ImporteCompensacion,0)) AS ImporteCompensacion
		FROM @VarProFacturas as pf
		where pf.IdMoneda = 2
		GROUP BY pf.IdCliente,pf.IdMoneda
	) varProfacturasDolares ON ca.IdCliente = varProfacturasDolares.IdCliente  
	WHERE
	ISNULL(varProfacturasDolares.ImporteClienteDLLS,0) <> 0 OR ISNULL(varProfacturasPesos.ImporteClientePESOS,0) <> 0

	

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK

	EXECUTE usp_SisErrorsGrabar @IdPeticion

END CATCH
go

