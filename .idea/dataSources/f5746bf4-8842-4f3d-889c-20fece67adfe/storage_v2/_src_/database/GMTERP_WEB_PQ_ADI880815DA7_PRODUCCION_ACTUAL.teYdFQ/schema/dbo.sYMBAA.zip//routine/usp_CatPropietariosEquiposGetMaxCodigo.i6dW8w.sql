CREATE PROCEDURE [dbo].[usp_CatPropietariosEquiposGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatPropietariosEquipos
go

