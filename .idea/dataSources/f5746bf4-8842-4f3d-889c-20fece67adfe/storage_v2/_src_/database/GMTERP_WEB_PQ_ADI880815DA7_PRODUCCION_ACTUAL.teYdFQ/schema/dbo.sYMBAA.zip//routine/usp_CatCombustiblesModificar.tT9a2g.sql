CREATE PROCEDURE [dbo].[usp_CatCombustiblesModificar]
@IdCombustible int,
@Codigo	varchar(50),	
@Combustible varchar(50),	
@ModificadoEl datetime,
@ActivoEtiqueta1_1 bit,
@ActivoEtiqueta1_2 bit,
@ActivoEtiqueta1_3 bit,
@ActivoEtiqueta1_4 bit,
@ActivoEtiqueta1_5 bit,
@ActivoEtiqueta2_1 bit,
@ActivoEtiqueta2_2 bit,
@ActivoEtiqueta2_3 bit,
@ActivoEtiqueta2_4 bit,
@ActivoEtiqueta2_5 bit,
@ActivoEtiqueta3_1 bit,
@ActivoEtiqueta3_2 bit,
@ActivoEtiqueta3_3 bit,
@ActivoEtiqueta3_4 bit,
@ActivoEtiqueta3_5 bit,
@Etiqueta1_1 varchar(30),
@Etiqueta1_2 varchar(30),
@Etiqueta1_3 varchar(30),
@Etiqueta1_4 varchar(30),
@Etiqueta1_5 varchar(30),
@Etiqueta2_1 varchar(30),
@Etiqueta2_2 varchar(30),
@Etiqueta2_3 varchar(30),
@Etiqueta2_4 varchar(30),
@Etiqueta2_5 varchar(30),
@Etiqueta3_1 varchar(30),
@Etiqueta3_2 varchar(30),
@Etiqueta3_3 varchar(30),
@Etiqueta3_4 varchar(30),
@Etiqueta3_5 varchar(30),
@ImporteEtiqueta1_1 decimal(15,6),
@ImporteEtiqueta1_2 decimal(15,6),
@ImporteEtiqueta1_3 decimal(15,6),
@ImporteEtiqueta1_4 decimal(15,6),
@ImporteEtiqueta1_5 decimal(15,6),
@ImporteEtiqueta2_1 decimal(15,6),
@ImporteEtiqueta2_2 decimal(15,6),
@ImporteEtiqueta2_3 decimal(15,6),
@ImporteEtiqueta2_4 decimal(15,6),
@ImporteEtiqueta2_5 decimal(15,6),
@ImporteEtiqueta3_1 decimal(15,6),
@ImporteEtiqueta3_2 decimal(15,6),
@ImporteEtiqueta3_3 decimal(15,6),
@ImporteEtiqueta3_4 decimal(15,6),
@ImporteEtiqueta3_5 decimal(15,6),
@RelacionCosto1_1 int,
@RelacionCosto1_2 int,
@RelacionCosto1_3 int,
@RelacionCosto1_4 int,
@RelacionCosto1_5 int,
@RelacionCosto2_1 int,
@RelacionCosto2_2 int,
@RelacionCosto2_3 int,
@RelacionCosto2_4 int,
@RelacionCosto2_5 int,
@RelacionCosto3_1 int,
@RelacionCosto3_2 int,
@RelacionCosto3_3 int,
@RelacionCosto3_4 int,
@RelacionCosto3_5 int,
@Activo bit,
@IdSucursal int,
@CostoMoleculaEtiqueta varchar(30),
@CostoMoleculaImporte decimal(15,6),
@CostoMoleculaMasImpuestoEtiqueta varchar(30),
@CostoMoleculaMasImpuestoImporte decimal(15,6),
@MargenComercialEtiqueta varchar(30),
@MargenComercialImporte decimal(15,6),
@CostoProductoEtiqueta varchar(30),
@CostoProductoImporte decimal(15,6),
@PrecioComercialEtiqueta varchar(30),
@PrecioComercialImporte decimal(15,6),
@PrecioVentaConImpuesto decimal(15,6),
@PrecioVentaSinImpuesto decimal(15,6),
@ClaveSATProducto varchar(8),
@ClaveSATUnidad varchar(8),
@IdImpuesto int,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	DECLARE @AgregarValorHistorico bit
	BEGIN TRANSACTION
	
	IF ISNULL(@IdCombustible,0)= 0
	RAISERROR(N'El identificador de combustible es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,'')= ''
		RAISERROR(N'El código de combustible es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@Combustible,'')= ''
		RAISERROR(N'La descripción de combustible es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT Codigo FROM CatCombustibles WHERE Codigo = @Codigo AND IdCombustible <> @IdCombustible AND IdSucursal = @IdSucursal)
		RAISERROR(N'El código de combustible no puede registrarse con la misma sucursal.',
			16,
			1
			)
	SET @AgregarValorHistorico = 0	
	IF EXISTS (Select IdCombustible From CatCombustibles WHERE
	IdCombustible = @IdCombustible AND  
	(ImporteEtiqueta1_1 <> @ImporteEtiqueta1_1 OR
	ImporteEtiqueta1_2 <> @ImporteEtiqueta1_2 OR
	ImporteEtiqueta1_3 <> @ImporteEtiqueta1_3 OR
	ImporteEtiqueta1_4 <> @ImporteEtiqueta1_4 OR
	ImporteEtiqueta1_5 <> @ImporteEtiqueta1_5 OR
	ImporteEtiqueta2_1 <> @ImporteEtiqueta2_1 OR
	ImporteEtiqueta2_2 <> @ImporteEtiqueta2_2 OR
	ImporteEtiqueta2_3 <> @ImporteEtiqueta2_3 OR
	ImporteEtiqueta2_4 <> @ImporteEtiqueta2_4 OR
	ImporteEtiqueta2_5 <> @ImporteEtiqueta2_5 OR
	ImporteEtiqueta3_1 <> @ImporteEtiqueta3_1 OR
	ImporteEtiqueta3_2 <> @ImporteEtiqueta3_2 OR
	ImporteEtiqueta3_3 <> @ImporteEtiqueta3_3 OR
	ImporteEtiqueta3_4 <> @ImporteEtiqueta3_4 OR
	ImporteEtiqueta3_5 <> @ImporteEtiqueta3_5 OR
	CostoMoleculaImporte <> @CostoMoleculaImporte OR
	CostoMoleculaMasImpuestoImporte <> @CostoMoleculaMasImpuestoImporte OR
	MargenComercialImporte <> @MargenComercialImporte OR
	CostoProductoImporte <> @CostoProductoImporte OR
	PrecioComercialImporte <> @PrecioComercialImporte))
	SET @AgregarValorHistorico = 1	
			
	UPDATE CatCombustibles SET
	Codigo= @Codigo,
	Combustible= @Combustible,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor,
	ActivoEtiqueta1_1 = @ActivoEtiqueta1_1,
	ActivoEtiqueta1_2 = @ActivoEtiqueta1_2,
	ActivoEtiqueta1_3 = @ActivoEtiqueta1_3,
	ActivoEtiqueta1_4 = @ActivoEtiqueta1_4,
	ActivoEtiqueta1_5 = @ActivoEtiqueta1_5,
	ActivoEtiqueta2_1 = @ActivoEtiqueta2_1,
	ActivoEtiqueta2_2 = @ActivoEtiqueta2_2,
	ActivoEtiqueta2_3 = @ActivoEtiqueta2_3,
	ActivoEtiqueta2_4 = @ActivoEtiqueta2_4,
	ActivoEtiqueta2_5 = @ActivoEtiqueta2_5,
	ActivoEtiqueta3_1 = @ActivoEtiqueta3_1,
	ActivoEtiqueta3_2 = @ActivoEtiqueta3_2,
	ActivoEtiqueta3_3 = @ActivoEtiqueta3_3,
	ActivoEtiqueta3_4 = @ActivoEtiqueta3_4,
	ActivoEtiqueta3_5 = @ActivoEtiqueta3_5,
	Etiqueta1_1 = @Etiqueta1_1,
	Etiqueta1_2 = @Etiqueta1_2,
	Etiqueta1_3 = @Etiqueta1_3,
	Etiqueta1_4 = @Etiqueta1_4,
	Etiqueta1_5 = @Etiqueta1_5,
	Etiqueta2_1 = @Etiqueta2_1,
	Etiqueta2_2 = @Etiqueta2_2,
	Etiqueta2_3 = @Etiqueta2_3,
	Etiqueta2_4 = @Etiqueta2_4,
	Etiqueta2_5 = @Etiqueta2_5,
	Etiqueta3_1 = @Etiqueta3_1,
	Etiqueta3_2 = @Etiqueta3_2,
	Etiqueta3_3 = @Etiqueta3_3,
	Etiqueta3_4 = @Etiqueta3_4,
	Etiqueta3_5 = @Etiqueta3_5,
	ImporteEtiqueta1_1 = @ImporteEtiqueta1_1,
	ImporteEtiqueta1_2 = @ImporteEtiqueta1_2,
	ImporteEtiqueta1_3 = @ImporteEtiqueta1_3,
	ImporteEtiqueta1_4 = @ImporteEtiqueta1_4,
	ImporteEtiqueta1_5 = @ImporteEtiqueta1_5,
	ImporteEtiqueta2_1 = @ImporteEtiqueta2_1,
	ImporteEtiqueta2_2 = @ImporteEtiqueta2_2,
	ImporteEtiqueta2_3 = @ImporteEtiqueta2_3,
	ImporteEtiqueta2_4 = @ImporteEtiqueta2_4,
	ImporteEtiqueta2_5 = @ImporteEtiqueta2_5,
	ImporteEtiqueta3_1 = @ImporteEtiqueta3_1,
	ImporteEtiqueta3_2 = @ImporteEtiqueta3_2,
	ImporteEtiqueta3_3 = @ImporteEtiqueta3_3,
	ImporteEtiqueta3_4 = @ImporteEtiqueta3_4,
	ImporteEtiqueta3_5 = @ImporteEtiqueta3_5,
	RelacionCosto1_1 = @RelacionCosto1_1,
	RelacionCosto1_2 = @RelacionCosto1_2,
	RelacionCosto1_3 = @RelacionCosto1_3,
	RelacionCosto1_4 = @RelacionCosto1_4,
	RelacionCosto1_5 = @RelacionCosto1_5,
	RelacionCosto2_1 = @RelacionCosto2_1,
	RelacionCosto2_2 = @RelacionCosto2_2,
	RelacionCosto2_3 = @RelacionCosto2_3,
	RelacionCosto2_4 = @RelacionCosto2_4,
	RelacionCosto2_5 = @RelacionCosto2_5,
	RelacionCosto3_1 = @RelacionCosto3_1,
	RelacionCosto3_2 = @RelacionCosto3_2,
	RelacionCosto3_3 = @RelacionCosto3_3,
	RelacionCosto3_4 = @RelacionCosto3_4,
	RelacionCosto3_5 = @RelacionCosto3_5,
	Activo = @Activo,
	IdSucursal = @IdSucursal,
	CostoMoleculaEtiqueta = @CostoMoleculaEtiqueta,
	CostoMoleculaImporte = @CostoMoleculaImporte,
	CostoMoleculaMasImpuestoEtiqueta = @CostoMoleculaMasImpuestoEtiqueta,
	CostoMoleculaMasImpuestoImporte = @CostoMoleculaMasImpuestoImporte,
	MargenComercialEtiqueta = @MargenComercialEtiqueta,
	MargenComercialImporte = @MargenComercialImporte,
	CostoProductoEtiqueta = @CostoProductoEtiqueta,
	CostoProductoImporte = @CostoProductoImporte,
	PrecioComercialEtiqueta = @PrecioComercialEtiqueta,
	PrecioComercialImporte = @PrecioComercialImporte,
	PrecioVentaConImpuesto = @PrecioVentaConImpuesto,
	PrecioVentaSinImpuesto = @PrecioVentaSinImpuesto,
	ClaveSATProducto = @ClaveSATProducto,
	ClaveSATUnidad = @ClaveSATUnidad,
	IdImpuesto = @IdImpuesto
	WHERE 	IdCombustible=@IdCombustible
	
	IF @AgregarValorHistorico = 1
	INSERT INTO CatCombustiblesValoresHistoricos(IdCombustible,Codigo,Combustible,CreadoEl,CreadoPor,ActivoEtiqueta1_1,ActivoEtiqueta1_2,ActivoEtiqueta1_3,ActivoEtiqueta1_4,ActivoEtiqueta1_5,ActivoEtiqueta2_1,ActivoEtiqueta2_2,ActivoEtiqueta2_3,ActivoEtiqueta2_4,ActivoEtiqueta2_5,ActivoEtiqueta3_1,ActivoEtiqueta3_2,ActivoEtiqueta3_3,ActivoEtiqueta3_4,ActivoEtiqueta3_5,Etiqueta1_1,Etiqueta1_2,Etiqueta1_3,Etiqueta1_4,Etiqueta1_5,Etiqueta2_1,Etiqueta2_2,Etiqueta2_3,Etiqueta2_4,Etiqueta2_5,Etiqueta3_1,Etiqueta3_2,Etiqueta3_3,Etiqueta3_4,Etiqueta3_5,
	ImporteEtiqueta1_1,ImporteEtiqueta1_2,ImporteEtiqueta1_3,ImporteEtiqueta1_4,ImporteEtiqueta1_5,ImporteEtiqueta2_1,ImporteEtiqueta2_2,ImporteEtiqueta2_3,ImporteEtiqueta2_4,ImporteEtiqueta2_5,ImporteEtiqueta3_1,ImporteEtiqueta3_2,ImporteEtiqueta3_3,ImporteEtiqueta3_4,ImporteEtiqueta3_5,RelacionCosto1_1,RelacionCosto1_2,RelacionCosto1_3,RelacionCosto1_4,RelacionCosto1_5,RelacionCosto2_1,RelacionCosto2_2,RelacionCosto2_3,RelacionCosto2_4,RelacionCosto2_5,RelacionCosto3_1,RelacionCosto3_2,RelacionCosto3_3,RelacionCosto3_4,RelacionCosto3_5,
	Activo,IdSucursal,CostoMoleculaEtiqueta,CostoMoleculaImporte,CostoMoleculaMasImpuestoEtiqueta,CostoMoleculaMasImpuestoImporte,MargenComercialEtiqueta,MargenComercialImporte,CostoProductoEtiqueta,CostoProductoImporte,PrecioComercialEtiqueta,PrecioComercialImporte,PrecioVentaConImpuesto,PrecioVentaSinImpuesto,ClaveSATProducto,ClaveSATUnidad,IdImpuesto)
	VALUES(@IdCombustible,@Codigo,@Combustible,@ModificadoEl,@ModificadoPor,@ActivoEtiqueta1_1,@ActivoEtiqueta1_2,@ActivoEtiqueta1_3,@ActivoEtiqueta1_4,@ActivoEtiqueta1_5,@ActivoEtiqueta2_1,@ActivoEtiqueta2_2,@ActivoEtiqueta2_3,@ActivoEtiqueta2_4,@ActivoEtiqueta2_5,@ActivoEtiqueta3_1,@ActivoEtiqueta3_2,@ActivoEtiqueta3_3,@ActivoEtiqueta3_4,@ActivoEtiqueta3_5,@Etiqueta1_1,@Etiqueta1_2,@Etiqueta1_3,@Etiqueta1_4,@Etiqueta1_5,@Etiqueta2_1,@Etiqueta2_2,@Etiqueta2_3,@Etiqueta2_4,@Etiqueta2_5,@Etiqueta3_1,@Etiqueta3_2,@Etiqueta3_3,@Etiqueta3_4,@Etiqueta3_5,
	@ImporteEtiqueta1_1,@ImporteEtiqueta1_2,@ImporteEtiqueta1_3,@ImporteEtiqueta1_4,@ImporteEtiqueta1_5,@ImporteEtiqueta2_1,@ImporteEtiqueta2_2,@ImporteEtiqueta2_3,@ImporteEtiqueta2_4,@ImporteEtiqueta2_5,@ImporteEtiqueta3_1,@ImporteEtiqueta3_2,@ImporteEtiqueta3_3,@ImporteEtiqueta3_4,@ImporteEtiqueta3_5,@RelacionCosto1_1,@RelacionCosto1_2,@RelacionCosto1_3,@RelacionCosto1_4,@RelacionCosto1_5,@RelacionCosto2_1,@RelacionCosto2_2,@RelacionCosto2_3,@RelacionCosto2_4,@RelacionCosto2_5,@RelacionCosto3_1,@RelacionCosto3_2,@RelacionCosto3_3,@RelacionCosto3_4,@RelacionCosto3_5,
	@Activo,@IdSucursal,@CostoMoleculaEtiqueta,@CostoMoleculaImporte,@CostoMoleculaMasImpuestoEtiqueta,@CostoMoleculaMasImpuestoImporte,@MargenComercialEtiqueta,@MargenComercialImporte,@CostoProductoEtiqueta,@CostoProductoImporte,@PrecioComercialEtiqueta,@PrecioComercialImporte,@PrecioVentaConImpuesto,@PrecioVentaSinImpuesto,@ClaveSATProducto,@ClaveSATUnidad,@IdImpuesto)
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

