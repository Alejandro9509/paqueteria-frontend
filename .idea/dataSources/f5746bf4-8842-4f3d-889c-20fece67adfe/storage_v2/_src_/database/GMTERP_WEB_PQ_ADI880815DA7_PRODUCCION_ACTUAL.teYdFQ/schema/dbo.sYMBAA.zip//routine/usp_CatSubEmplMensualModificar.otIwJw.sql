CREATE PROCEDURE [dbo].[usp_CatSubEmplMensualModificar]
@dsCatSubEmplMensual ntext,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)
AS
DECLARE
@docHandle int, 
@CursorT_IdSubEmpMensual int,
@CursorT_LimiteInferior decimal(15, 2),
@CursorT_LimiteSuperior decimal(15, 2),
@CursorT_SubsAlEmpleado decimal(15, 2),
@CursorT_Ejercicio int,
@CursorT_FechaVigencia datetime

/* *************************************************************************************************
Procedimiento [usp_CatSubEmplMensualModificar]

Parámetros: 
    @@dsCatSubEmplMensual (entrada, texto).   Es la tabla de registros.
    @ModificadoEl                (entrada, fecha hora). Fecha en la que se realiza la modificación
    @ModificadoPor               (entrada, entero). Quien solicita la modificación
    @IdPeticion varchar(100)     (entrada, string). Id de la Petición, generada en WEBDEV   
 

Descripción: El procedimiento actualiza las tarifas del Subsidio otorgado a el empleado en base a los ingresos,
             percibidos durante el Periodo.

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 11/06/2020
Versión ERP: 8.0.53.04

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 17/02/2021
Versión ERP: 8.0.58.29
Solicitud: 3746


Invocada desde: PAGE_CatSubEmplMensual_AM (Solicitud 3746)
***************************************************************************************************** */


BEGIN TRY
    BEGIN TRANSACTION

    IF @dsCatSubEmplMensual IS NULL
        RAISERROR(N'Los Subs Mensuales son requeridos',
            16,
            1
            )

    IF @dsCatSubEmplMensual IS NOT NULL
    BEGIN
        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatSubEmplMensual

        SELECT ATT_IdSubEmpMensual,ATT_LimiteInferior,ATT_LimiteSuperior, ATT_SubsAlEmpleado, ATT_Ejercicio, ATT_FechaVigencia 
        INTO #CatSubEmpMensual
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CATSubEmpMensual',2) 
        WITH ( ATT_IdSubEmpMensual int,ATT_LimiteInferior decimal(15, 2), ATT_LimiteSuperior decimal(15, 2), ATT_SubsAlEmpleado decimal(15, 2), ATT_Ejercicio int, ATT_FechaVigencia datetime )

        EXEC sp_xml_removedocument @docHandle

        DECLARE CatSubEmpMensualCursor CURSOR LOCAL SCROLL FOR
        SELECT * FROM #CatSubEmpMensual

        OPEN CatSubEmpMensualCursor
        FETCH NEXT FROM CatSubEmpMensualCursor
        INTO @CursorT_IdSubEmpMensual ,@CursorT_LimiteInferior, @CursorT_LimiteSuperior , @CursorT_SubsAlEmpleado, @CursorT_Ejercicio, @CursorT_FechaVigencia

        WHILE @@FETCH_STATUS = 0
        BEGIN
            UPDATE CatSubEmpMensual
            SET LimiteInferior = @CursorT_LimiteInferior,
            LimiteSuperior = @CursorT_LimiteSuperior,
            SubAlEmpleado = @CursorT_SubsAlEmpleado,
            Ejercicio = @CursorT_Ejercicio,
            FechaVigencia = @CursorT_FechaVigencia,
            ModificadoEl = @ModificadoEl,
            ModificadoPor = @ModificadoPor
            WHERE IdSubEmpMensual = @CursorT_IdSubEmpMensual

            FETCH NEXT FROM CatSubEmpMensualCursor
            INTO @CursorT_IdSubEmpMensual ,@CursorT_LimiteInferior , @CursorT_LimiteSuperior,  @CursorT_SubsAlEmpleado, @CursorT_Ejercicio, @CursorT_FechaVigencia
        END
        CLOSE CatSubEmpMensualCursor
        DEALLOCATE CatSubEmpMensualCursor

  END 

  COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

