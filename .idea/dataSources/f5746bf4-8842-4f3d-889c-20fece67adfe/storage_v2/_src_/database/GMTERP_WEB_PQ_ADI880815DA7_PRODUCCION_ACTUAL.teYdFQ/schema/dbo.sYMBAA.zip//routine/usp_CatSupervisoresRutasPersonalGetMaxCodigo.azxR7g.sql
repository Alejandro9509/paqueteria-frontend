CREATE PROCEDURE [dbo].[usp_CatSupervisoresRutasPersonalGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatSupervisoresRutasPersonal
go

