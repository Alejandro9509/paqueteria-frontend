
-- =============================================
-- Author:		<Author,,Name>
-- ALTER date: <ALTER Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_CatFormatoAgregarPQ]
	@Formato VARCHAR(50),
	@TipoProceso INT,
	@FormatoWDE VARCHAR(250),
	@NombreArchivo VARCHAR(256),
	@CreadoPor INT,
	@CreadoEl Datetime,
	@ModificadoPor INT,
	@ModificadoEl Datetime,
	@Activo Bit
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Formato, '') = '' BEGIN			
			RAISERROR(N'*INICIO*El nombre del formato es un campo requerido*FIN*', 16, 1);		
			return
		end
		
		IF ISNULL(@NombreArchivo, '') = '' begin
			RAISERROR(N'*INICIO*El nombre de archivo del formato es un campo requerido*FIN*', 16, 1);		
			return
		end
		
		INSERT INTO CatFormatos (Formato, TipoProceso, FormatoWDE, NombreArchivo, CreadoPor, CreadoEl, ModificadoPor, ModificadoEl, Activo)
		VALUES (@Formato, @TipoProceso, @FormatoWDE, @NombreArchivo, @CreadoPor, @CreadoEl, @ModificadoPor, @ModificadoEl, @Activo)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

