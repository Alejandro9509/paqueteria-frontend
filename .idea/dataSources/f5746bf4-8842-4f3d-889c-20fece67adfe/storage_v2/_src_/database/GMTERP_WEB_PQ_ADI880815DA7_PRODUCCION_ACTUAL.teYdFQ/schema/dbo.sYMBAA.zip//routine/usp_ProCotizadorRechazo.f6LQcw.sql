	
	
	CREATE PROCEDURE [dbo].[usp_ProCotizadorRechazo]
	@IdCotizacion int,
	@Estatus int,
	@ContactoRechazo varchar(100),
	@MotivoRechazo varchar(100),
	@RechazadoEl datetime,
	@RechazadoPor int,
	@IdPeticion varchar(100)


	AS

	BEGIN TRY
		BEGIN TRANSACTION

	  IF LTRIM(RTRIM(@ContactoRechazo))= ''
		RAISERROR(N'El campo ContactoRechazo de la Cotizacion es un campo requerido',
				16,
				1
				) 
	   IF LTRIM(RTRIM(@MotivoRechazo))= ''
		RAISERROR(N'El campo MotivoRechazo de la Cotizacion es un campo requerido',
				16,
				1
				)				  
		IF ISDATE(@RechazadoEl) = 0
			RAISERROR(N'La fecha/hora RechazadoEl es un campo requerido',
				16,
				1
				)	
		IF ISNull(@RechazadoPor,0) = 0
		   RAISERROR(N'El Campo RechazadoPor es un campo requerido',
				16,
				1
				) 							  
		
			--1 PENDIENTE
			--2 ACEPTADO
			--3 RECHAZADO

			--verificar si ya fue modificada antes de Guardar Cambios
			IF (SELECT COUNT(Estatus) FROM ProCotizaciones WHERE IdCotizacion = @IdCotizacion and Estatus = 1) = 0 
				RAISERROR(N'La Solicitud ya fue Aceptada o Rechazada',
				16,
				1
				)	
		
		
			UPDATE ProCotizaciones
			SET
				Estatus = @Estatus,
				MotivoRechazo =  @MotivoRechazo,
				RechazadoEl =  @RechazadoEl,
				RechazadoPor = @RechazadoPor,
				ContactoRechazo = @ContactoRechazo
			WHERE IdCotizacion = @IdCotizacion
					
	  
		COMMIT
	END TRY
	BEGIN CATCH    
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion	
	END CATCH
    go

