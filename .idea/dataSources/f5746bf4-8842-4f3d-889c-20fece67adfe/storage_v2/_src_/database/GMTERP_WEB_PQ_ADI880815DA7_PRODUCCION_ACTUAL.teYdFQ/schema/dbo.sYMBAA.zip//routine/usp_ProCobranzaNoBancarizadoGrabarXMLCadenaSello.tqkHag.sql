
	create PROCEDURE [dbo].[usp_ProCobranzaNoBancarizadoGrabarXMLCadenaSello]
		@IdCobranzaNoBancarizado int,
		@XMLArchivoPagos ntext,
		@CadenaOriginal ntext,
		@SelloDigital ntext,
		@IdPeticion varchar(100)
	AS
	BEGIN TRY
		BEGIN TRANSACTION

		UPDATE ProCobranzaNoBancarizado
		SET SelloDigital = @SelloDigital,
			CadenaOriginal = @CadenaOriginal,
			XMLArchivo = @XMLArchivoPagos		
		WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado

		--El commit debe ser la ultima linea para garantizar que se grabe todo
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

