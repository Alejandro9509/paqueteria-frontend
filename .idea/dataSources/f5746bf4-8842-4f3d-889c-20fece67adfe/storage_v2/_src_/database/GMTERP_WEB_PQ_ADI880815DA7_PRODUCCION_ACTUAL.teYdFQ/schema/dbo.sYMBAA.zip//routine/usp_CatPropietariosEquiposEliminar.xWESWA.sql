
CREATE PROCEDURE [dbo].[usp_CatPropietariosEquiposEliminar]
@IdPropietarioEquipo int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdPropietarioEquipo,0)= 0
		RAISERROR(N'El identificador es un campo requerido',
				16,
				1
				)
				
	IF EXISTS(SELECT TOP 1 IdPropietarioEquipo FROM CatUnidades WHERE IdPropietarioEquipo = @IdPropietarioEquipo)
			RAISERROR(N'No se puede eliminar el registro esta asignado a una unidad',
				16,
				1
				)
				
	

		DELETE CatPropietariosEquipos		
		WHERE 	IdPropietarioEquipo=@IdPropietarioEquipo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

