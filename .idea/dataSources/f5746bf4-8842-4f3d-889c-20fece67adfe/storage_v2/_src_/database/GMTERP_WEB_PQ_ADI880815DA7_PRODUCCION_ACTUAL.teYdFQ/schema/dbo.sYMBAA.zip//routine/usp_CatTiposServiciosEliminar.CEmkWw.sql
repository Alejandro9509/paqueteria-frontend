CREATE PROCEDURE [dbo].[usp_CatTiposServiciosEliminar]
@IdTipoServicio int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF EXISTS(SELECT IdTipoServicio FROM CatPatronRutas WHERE IdTipoServicio = @IdTipoServicio)
			RAISERROR(N'El tipo de servicio no se puede eliminar porque se encuentra ligado a un padrón de rutas.',
				16,
				1
				)

	IF ISNULL(@IdTipoServicio,0)= 0
		RAISERROR(N'El identificador del Tipo de Servicio es un campo requerido',
				16,
				1
				)

		DELETE CatTiposServicios	
		WHERE 	IdTipoServicio=@IdTipoServicio
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

