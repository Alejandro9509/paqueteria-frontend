CREATE PROCEDURE [dbo].[usp_CatISRMensualModificar]
@dsCatISRMensual ntext,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)
AS
DECLARE
@docHandle int, 
@CursorT_IdISRMensual int,
@CursorT_LimiteInferior decimal(15, 3),
@CursorT_LimiteSuperior decimal(15, 3),
@CursorT_CuotaFija decimal(15, 3),
@CursorT_Porcentaje decimal(15, 3),
@CursorT_Ejercicio int,
@CursorT_FechaVigencia datetime

/* *************************************************************************************************
Procedimiento [usp_CatISRMensualAgregar]
r
Parámetros: 
    @@dsCatISRMensual            (entrada, texto).   Es la tabla de registros del ISR.
    @ModificadoEl                (entrada, fecha hora). Fecha en la que se realiza la modificación
    @ModificadoPor               (entrada, entero). Quien solicita la modificación
    @IdPeticion varchar(100)     (entrada, string). Id de la Petición, generada en WEBDEV   
 

Descripción: El procedimiento Modifica las tarifas mensuales del ISR para realizar el calculo de impuestos del periodo  .

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 11/06/2020
Versión ERP: 8.0.53.04

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 17/02/2021
Versión ERP: 8.0.58.29
Solicitud: 3745


Invocada desde: PAGE_CatSubEmplMensual_AM (Solicitud 3745)
***************************************************************************************************** */


BEGIN TRY
    BEGIN TRANSACTION

    IF @dsCatISRMensual IS NULL
        RAISERROR(N'Los ISR Mensuales son requeridos',
            16,
            1
            )

    IF @dsCatISRMensual IS NOT NULL
    BEGIN
        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatISRMensual

        SELECT ATT_IdISRMensual,ATT_LimiteInferior,ATT_LimiteSuperior,ATT_CuotaFija,ATT_Porcentaje, ATT_Ejercicio, ATT_FechaVigencia
        INTO #CatISRMensual
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CATISRMensuales',2) 
        WITH ( ATT_IdISRMensual int,ATT_LimiteInferior decimal(15, 3),ATT_LimiteSuperior decimal(15, 3),ATT_Porcentaje decimal(15, 3),ATT_CuotaFija decimal(15, 3), ATT_Ejercicio int, ATT_FechaVigencia datetime )

        EXEC sp_xml_removedocument @docHandle

        DECLARE CatISRMensualCursor CURSOR LOCAL SCROLL FOR
        SELECT * FROM #CatISRMensual

        OPEN CatISRMensualCursor
        FETCH NEXT FROM CatISRMensualCursor
        INTO @CursorT_IdISRMensual,@CursorT_LimiteInferior,@CursorT_LimiteSuperior,@CursorT_CuotaFija,@CursorT_Porcentaje, @CursorT_Ejercicio, @CursorT_FechaVigencia

        WHILE @@FETCH_STATUS = 0
        BEGIN
            UPDATE CatISRMensual 
            SET LimiteInferior = @CursorT_LimiteInferior,
            LimiteSuperior = @CursorT_LimiteSuperior,
            CuotaFija = @CursorT_CuotaFija,
            Porcentaje = @CursorT_Porcentaje,
            Ejercicio = @CursorT_Ejercicio,
            FechaVigencia = @CursorT_FechaVigencia,
            ModificadoEl = @ModificadoEl,
            ModificadoPor = @ModificadoPor
            WHERE IdISRMensual = @CursorT_IdISRMensual

            FETCH NEXT FROM CatISRMensualCursor
            INTO @CursorT_IdISRMensual,@CursorT_LimiteInferior,@CursorT_LimiteSuperior,@CursorT_CuotaFija,@CursorT_Porcentaje, @CursorT_Ejercicio, @CursorT_FechaVigencia
        END
        CLOSE CatISRMensualCursor
        DEALLOCATE CatISRMensualCursor

    END
  COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

