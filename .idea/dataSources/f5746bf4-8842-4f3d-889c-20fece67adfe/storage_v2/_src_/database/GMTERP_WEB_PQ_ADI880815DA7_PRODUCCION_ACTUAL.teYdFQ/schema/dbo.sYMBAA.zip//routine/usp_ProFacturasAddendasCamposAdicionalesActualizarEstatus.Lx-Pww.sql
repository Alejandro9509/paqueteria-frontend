
CREATE PROCEDURE [dbo].[usp_ProFacturasAddendasCamposAdicionalesActualizarEstatus]
@IdFactura int,
@ResultadosEnvios ntext,
@EstatusEnvios varchar(100),
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdFactura,0)= 0
	RAISERROR(N'El identificador de factura/addenda es un campo requerido',
			16,
			1
			)

	UPDATE ProFacturasAddendasCamposAdicionales SET
			ResultadosEnvios = ISNULL(cast(ResultadosEnvios as varchar(max)),'')+char(13)+char(10)+cast(@ResultadosEnvios as varchar(max)),
			EstatusEnvios = @EstatusEnvios,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor
	WHERE 	IdFactura = @IdFactura

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

