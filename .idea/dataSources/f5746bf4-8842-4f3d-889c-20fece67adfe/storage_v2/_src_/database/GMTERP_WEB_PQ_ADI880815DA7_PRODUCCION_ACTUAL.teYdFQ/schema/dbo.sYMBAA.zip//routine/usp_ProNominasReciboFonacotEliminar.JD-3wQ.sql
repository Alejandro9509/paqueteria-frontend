
CREATE PROCEDURE [dbo].[usp_ProNominasReciboFonacotEliminar]
	@IdNominaReciboFonacot int,
	@IdPeticion varchar(100),
	@IdEmpleado int, 
	@IdPeriodo int
/* *************************************************************************************************
Procedimiento usp_ProNominasReciboFonacotEliminar

Parámetros: 
	@IdNominaReciboFonacot int, (Entrada, Entero), Identificador del Concepto PDO, asociado al credito.
	@IdPeticion varchar(100),	(Entrada, Entero), Identificador del periodo de registro en nomina.
	@IdEmpleado int,			(Entrada, Entero), Id de la Petición, generada en WEBDEV.  
	@IdPeriodo int				(Entrada, Entero), Identificador del empleado.		


Descripción: El procedimiento elimina el registro de la informacion de los creditos Fonacot que son solicitados por el empleado, siempre y cuando no exista un descuento previo en sistema.

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 23/02/2020
Versión ERP: 8.0.59.05
Solicitud: 3947

Modificada por:   
Fecha de mofidicacion: 
Versión ERP: 

Invocada desde: PAGE_ProNominasReciboFONACOTAM (Solicitud 3947)
***************************************************************************************************** */
	AS
	DECLARE
	@IdConceptoPDOFijoFonacot int
	
	BEGIN TRY
		BEGIN TRANSACTION
		
		SET @IdConceptoPDOFijoFonacot = (SELECT IdConceptoPDOFijoFonacot FROM ProNominasReciboFonacot WHERE IdNominaReciboFonacot = @IdNominaReciboFonacot)
		--SET @IdConceptoPDOFijoSeguro = (SELECT IdConceptoPDOFijoSeguro FROM ProNominasReciboInfonavit WHERE IdNominaReciboInfonavit = @IdNominaReciboInfonavit)
		
		IF ISNULL(@IdNominaReciboFonacot,0)= 0
		RAISERROR(N'El identificador de Fonacot es un campo requerido',
				16,
				1
				)
				
		IF EXISTS(SELECT IdConceptoPDOFijo FROM ProNominasReciboConceptos WHERE IdConceptoPDOFijo=@IdConceptoPDOFijoFonacot ) --OR EXISTS(SELECT IdConceptoPDOFijo FROM ProNominasReciboConceptos WHERE IdConceptoPDOFijo=@IdConceptoPDOFijoSeguro ) 
		RAISERROR(N'No es posible eliminar el Fonacot, porque ya se asoció al recibo. ',
				16,
				1	
				)		
			
			DELETE	ProNominasReciboFonacot
			WHERE 	IdNominaReciboFonacot = @IdNominaReciboFonacot

			IF ISNULL(@IdConceptoPDOFijoFonacot,0) <> 0
			BEGIN
				DELETE	CatConceptosPDOFijos
				WHERE 	IdConceptoPDOFijo=@IdConceptoPDOFijoFonacot
			END

			UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
go

