
CREATE PROCEDURE [dbo].[usp_ProCobranzaRegistrar]
	@IdConceptoCobranza int,
	@IdCliente int,
	@IdFactura int,
	@FechaHora datetime,
	@Importe money,
	@TipoCambio money,
	@IdMoneda int,
	@Referencia varchar(50),
	@IdSucursal int,
	@IdMovimientoBancario int,	
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	IF @IdConceptoCobranza = 0
		RAISERROR(N'El concepto de cobranza es un campo requerido',
			16,
			1
			)

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF @Importe = 0
		RAISERROR(N'El importe es un campo requerido',
			16,
			1
			)	

	IF @IdMoneda = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)								
			
	IF @IdFactura = 0
		SET @IdFactura = NULL
		
	IF @IdMovimientoBancario = 0
		SET @IdMovimientoBancario = NULL		
	
	INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdMovimientoBancario,IdSucursal,Importe,Referencia,TipoCambio)
	VALUES(@CreadoEl,@CreadoPor,@FechaHora,@IdCliente,@IdConceptoCobranza,@IdFactura,@IdMoneda,@IdMovimientoBancario,@IdSucursal,@Importe,@Referencia,@TipoCambio)
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

