
CREATE PROCEDURE [dbo].[usp_CatClientesEliminarPQ]
	@IdCliente INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdCliente,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del Cliente es un campo requerido*FIN*', 16, 1);
			return
		end;
		
		DELETE FROM CatClientes
		WHERE IdCliente = @IdCliente
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

