CREATE PROCEDURE [dbo].[usp_CatTurnosModificar]
@IdTurno	int,
@Codigo	int,	
@Turno	varchar(40),	
@ModificadoEl datetime,
@ModificadoPor int,
@Horas decimal(15,2),
@ClaveSAT varchar(5),
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdTurno,0)= 0
	RAISERROR(N'El identificador del Turno es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del Turno es un campo requerido',
			16,
			1
			)
	
	 IF EXISTS(SELECT Codigo FROM CatTurnos WHERE Codigo = @Codigo And IdTurno <> @IdTurno)
		RAISERROR(N'El código del Turno ya existe',
			16,
			1
			)  
							
	IF ISNULL(@Turno,'')= ''
		RAISERROR(N'El nombre del Turno es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Turno FROM CatTurnos WHERE Turno = @Turno And IdTurno <> @IdTurno)
		RAISERROR(N'La Descripción del Turno ya existe',
			16,
			1
			) 
			
	IF ISNULL(@Horas,0)= 0
		RAISERROR(N'El número del Horas es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@ClaveSAT,'')= ''
        RAISERROR(N'La Clave SAT es un campo requerido',
            16,
            1
            )
			
	UPDATE CatTurnos SET
	Codigo= @Codigo,
	Turno= @Turno,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor,
	Horas=@Horas,
	ClaveTipoJornada= @ClaveSAT
	WHERE 	IdTurno=@IdTurno
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

