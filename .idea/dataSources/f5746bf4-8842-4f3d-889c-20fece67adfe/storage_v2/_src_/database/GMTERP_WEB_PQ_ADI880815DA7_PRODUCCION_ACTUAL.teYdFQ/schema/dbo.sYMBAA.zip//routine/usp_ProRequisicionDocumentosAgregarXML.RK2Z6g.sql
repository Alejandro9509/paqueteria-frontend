
CREATE PROCEDURE [dbo].[usp_ProRequisicionDocumentosAgregarXML]
	@IdRequisicion INT,
	@dsRequisicionesDocumentos XML,
	@CreadoPor INT,
	@CreadoEl DATETIME,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Parámetros
@IdRequisicion INT,
@dsRequisicionesDocumentos XML,
@CreadoPor INT,
@CreadoEl DATETIME,
@IdPeticion VARCHAR(100)

Descripción: Procedimiento para guardar los archivos cargados en una requisición

Creado por: Jesús Humberto Morales Mojica
Fecha de Creacion: 16/08/2021
Versión 8.0.63.21
Solicitud 4598

Invocada desde: PAGE_ProRequisicionAM
******************************************************************************************************/
AS 
	DECLARE @TemporalXML TABLE (Ruta NVARCHAR(2083), Descripcion NVARCHAR(50), Obs BIT)

BEGIN TRY
	BEGIN TRANSACTION
		
		IF ISNULL(@IdRequisicion, 0) = 0
			RAISERROR(N'El Identificador de la requisición es un campo requerido', 16, 1)

		INSERT INTO @TemporalXML (Ruta, Descripcion, Obs)
		SELECT 
		  Ruta = Node.Data.value('(ATT_ImagenNombreArchivo)[1]', 'VARCHAR(MAX)')
		, Descripcion = Node.Data.value('(ATT_Descripcion)[1]', 'VARCHAR(MAX)')
		, Obs = Node.Data.value('(ATT_Obs)[1]', 'BIT')
		FROM @dsRequisicionesDocumentos.nodes('/WEBDEV_TABLE/Imagenes') Node(Data)

		DELETE FROM ProRequisicionDocumentos WHERE IdRequisicion = @IdRequisicion

		INSERT INTO ProRequisicionDocumentos (IdRequisicion, Ruta, Descripcion, Obs, CreadoPor, CreadoEl)
		SELECT @IdRequisicion, Ruta, Descripcion, Obs, @CreadoPor, @CreadoEl FROM @TemporalXML

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

