CREATE PROCEDURE [dbo].[usp_CatLayoutsCargasCombustibleModificar]
	@Layout	varchar(50),
	@TipoArchivo tinyint,
	@Separador	varchar(1),
	@RenglonInicial	tinyint,
	@ColumnaKmECM Varchar(150),
    @ColumnaLtsECM Varchar(150),
    @ColumnaLtsRalenti Varchar(150),
    @ColumnasPorcLtsRalenti Varchar(150),
    @ColumnaLtsAutRalenti Varchar(150),
    @ColumnaLtsExcedidos Varchar(150),
    @ColumnaRendimientoECM Varchar(150),
    @ColumnaPorcUltimoCambio Varchar(150),
    @ColumnaPorcPenultimoCambio Varchar(150),
    @ColumnaVelocidadMaxMotor Varchar(150),
    @ColumnaVelocidadMaxUnidad Varchar(150),
    @ColumnaPorcVelMaxUnidad Varchar(150),
    @ColumnaTiempoVelocudadMaxUnidad Varchar(150),
    @ColumnaVelocidadPromedio Varchar(150),
    @ColumnaNeutralizaciones Varchar(150),
    @ColumnaFrenadosBruscos Varchar(150),
    @ColumnaCargaDeAceleracion Varchar(150),
    @ColumnaAccionamientoPedalDeFreno Varchar(150),
	@ModificadoEl	datetime,
	@ModificadoPor	int,
	@IdPeticion varchar(100),
	@IdLayoutCargaCombustible	int,
	@ColumnaContineValor int,
	@ColumnaUnidad varchar(150),
	@ColumnaFechaReseteo Varchar(150)
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF @IdLayoutCargaCombustible = 0
			RAISERROR(N'El identificador del layout es un campo requerido',
				16,
				1
				)

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
	
		UPDATE CatLayoutsCargasCombustible SET 
		Layout = @Layout,
		TipoArchivo = @TipoArchivo,
		Separador = @Separador,
		RenglonInicial = @RenglonInicial,		
		ColumnaKmECM= @ColumnaKmECM,
		ColumnaLtsECM= @ColumnaLtsECM,
		ColumnaLtsRalenti= @ColumnaLtsRalenti,
		ColumnasPorcLtsRalenti= @ColumnasPorcLtsRalenti,
		ColumnaLtsAutRalenti= @ColumnaLtsAutRalenti,
		ColumnaLtsExcedidos= @ColumnaLtsExcedidos,
		ColumnaRendimientoECM= @ColumnaRendimientoECM,
		ColumnaPorcUltimoCambio= @ColumnaPorcUltimoCambio,
		ColumnaPorcPenultimoCambio= @ColumnaPorcPenultimoCambio,
		ColumnaVelocidadMaxMotor= @ColumnaVelocidadMaxMotor,
		ColumnaVelocidadMaxUnidad= @ColumnaVelocidadMaxUnidad,
		ColumnaPorcVelMaxUnidad= @ColumnaPorcVelMaxUnidad,
		ColumnaTiempoVelocudadMaxUnidad= @ColumnaTiempoVelocudadMaxUnidad,
		ColumnaVelocidadPromedio= @ColumnaVelocidadPromedio,
		ColumnaNeutralizaciones= @ColumnaNeutralizaciones,
		ColumnaFrenadosBruscos= @ColumnaFrenadosBruscos,
		ColumnaCargaDeAceleracion= @ColumnaCargaDeAceleracion,
		ColumnaAccionamientoPedalDeFreno= @ColumnaAccionamientoPedalDeFreno,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		ColumnaContineValor = @ColumnaContineValor,
		ColumnaUnidad = @ColumnaUnidad,
		ColumnaFechaReseteo = @ColumnaFechaReseteo
		WHERE IdLayoutCargaCombustible = @IdLayoutCargaCombustible
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

