CREATE PROCEDURE [dbo].[usp_ProCobranzaSaldosAFavorGrabarAckCancelacion]
	@IdMovimientoBancario int,
	@AckCancelacion ntext,
	@FechaCancelacionSAT datetime,
	@EstatusUUID varchar(50),
	@IdPeticion varchar(100),
	@IdCobranzaSaldoAFavor int,
	@Secuencia int
AS
BEGIN TRY
	BEGIN TRANSACTION
		
	IF EXISTS(SELECT IdCobranzaSaldoAFavor FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor = @IdCobranzaSaldoAFavor AND Secuencia = @Secuencia AND EstatusUUID IS NOT NULL AND AckCancelacionSAT IS NOT NULL AND FechaCancelacionSAT IS NOT NULL)
		RAISERROR(N'No se puede cancelar este recibo de pago porque ya está cancelado en el SAT',
			16,
			1
			)
				

	UPDATE ProCobranzaSaldosAFavorTimbrados
	SET AckCancelacionSAT = @AckCancelacion,
	FechaCancelacionSAT = @FechaCancelacionSAT,
	EstatusUUID = @EstatusUUID
	WHERE IdCobranzaSaldoAFavor = @IdCobranzaSaldoAFavor AND Secuencia = @Secuencia

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

