
CREATE PROCEDURE [dbo].[usp_CatRutasPersonalParadasAgregar]
	@IdRutaPersonal int,
	@IdOrigen int,
	@IdDestino int,	
	@Kilometros int,
	@Horas decimal(15,2),
	@RutaGoogleMap ntext,
	@IdGeocercaDisparaSalida int,
	@GeocercaDisparaSalidaES tinyint,
	@IdGeocercaDisparaLlegada int,
	@GeocercaDisparaLlegadaES tinyint,
	@IdEstatuViajeSalida int,
	@IdEstatuViajeLlegada int,
	@SueldoBase money,
	@SueldoBaseDlls money,
	@dsCatRutasTrayectosGeocercas ntext,
	@dsCatRutasTrayectosGastos ntext,
	@dsCatRutasPersonalPuntuaciones ntext,
	@CreadoPor int,
	@CreadoEl datetime,	
	@IdPeticion varchar(100),
	@TipoParada tinyint,
	@HoraReporte datetime,
	@HoraSalida datetime
/*
Solicitud 001370
Procedimiento usp_CatRutasPersonalParadasAgregar
Descripción:	Se creo el procedimiento para poder agregar mas paradas a la ruta desde la creacion de un recorrido.
Creadopor:	Gustavo Partida Nevarez
Fecha de creacion:	014/05/2020
*/
AS
DECLARE
	@docHandle int,
	@KilometrosTotales int,
	@HorasTotales decimal(15,2),
	@IdRutaPersonalParada int ,
	@Secuencia int
BEGIN TRY
	BEGIN TRANSACTION

		IF @IdRutaPersonal = 0
			RAISERROR(N'El identificador de la ruta es un campo requerido',
				16,
				1
				)	

		IF @IdOrigen = 0
			RAISERROR(N'El origen de la ruta/parada es un campo requerido',
				16,
				1
				)	

		IF @IdDestino = 0
			RAISERROR(N'El destino de la ruta/parada es un campo requerido',
				16,
				1
				)	

		IF @IdEstatuViajeSalida = 0
			SET @IdEstatuViajeSalida = NULL

		IF @IdEstatuViajeLlegada = 0
			SET @IdEstatuViajeLlegada = NULL
		
		IF ISNULL(@Kilometros,0) <= 0	
		RAISERROR(N'El kilometraje de la parada es un campo requerido',
			16,
			1
			)
				
		IF ISNULL(@Horas,0) <= 0	
		RAISERROR(N'Las horas para la parada es un campo requerido',
			16,
			1
			)
			
		SET @Secuencia = (SELECT ISNULL(MAX(Secuencia),0)+1 FROM CatRutasPersonalParadas WHERE IdRutaPersonal = @IdRutaPersonal)	

		IF @Secuencia > 999
		BEGIN
		RAISERROR(N'No es posible agregar más de 999 paradas en una ruta, favor de eliminar las rutas que no estén en uso para continuar.',
					16,
					1)
		END

		INSERT INTO CatRutasPersonalParadas(IdRutaPersonal,IdEstatuViajeEntrada,IdEstatuViajeSalida,CreadoPor,CreadoEl,IdOrigen,IdDestino,Kilometros,Horas,RutaGoogleMap,HoraReporte
      ,HoraSalida,IdGeocercaDisparaSalida,GeocercaDisparaSalidaES,IdGeocercaDisparaLlegada,GeocercaDisparaLlegadaES,SueldoBase,SueldoBaseDlls,TipoParada,Secuencia)
		VALUES(@IdRutaPersonal,@IdEstatuViajeLlegada,@IdEstatuViajeSalida,@CreadoPor,@CreadoEl,@IdOrigen,@IdDestino,@Kilometros,@Horas,@RutaGoogleMap,@HoraReporte,@HoraSalida
		,@IdGeocercaDisparaSalida,@GeocercaDisparaSalidaES,@IdGeocercaDisparaLlegada,@GeocercaDisparaLlegadaES,@SueldoBase,@SueldoBaseDlls,@TipoParada,@Secuencia)
		
		SET @IdRutaPersonalParada = (SELECT IDENT_CURRENT('CatRutasPersonalParadas'))
		
	
		/*SECCION PARA AGREGAR LAS GEOCERCAS/ESTATUS AUTOMATICOS*/
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectosGeocercas

		SELECT COL_IdEstatuViajeEntrar,COL_IdEstatuViajeSalir,COL_IdGeocerca
		INTO #TempCatRutasTrayectosGeocercas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosGeocercas',2) 
		WITH(COL_IdEstatuViajeEntrar int,COL_IdEstatuViajeSalir int,COL_IdGeocerca int)
    
		EXEC sp_xml_removedocument @docHandle
			
		INSERT INTO CatRutasPersonalParadasGeocercas(IdRutaPersonalParada,IdEstatuViajeEntrada,IdEstatuViajeSalida,IdGeocerca,CreadoEl,CreadoPor)
		SELECT @IdRutaPersonalParada,
		CASE COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE COL_IdEstatuViajeEntrar END,
		CASE COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE COL_IdEstatuViajeSalir END,
		COL_IdGeocerca,@CreadoEl,@CreadoPor
		FROM #TempCatRutasTrayectosGeocercas

		/*SECCION PARA AGREGAR LOS GASTOS AUTORIZADOS*/
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectosGastos
		
		SELECT ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_LitrosAutorizados,ATT_ImporteAutorizadoState,ATT_LitrosAutorizadosState,ATT_GalonesAutorizados
		INTO #TempCatRutasTrayectosGastos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosGastos',2) 
		WITH(ATT_IdConceptoGastoViaje int,ATT_ImporteAutorizado money,ATT_LitrosAutorizados decimal(15,2),ATT_ImporteAutorizadoState int,ATT_LitrosAutorizadosState int,ATT_GalonesAutorizados decimal(15,2))
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatRutasPersonalParadasGastos(IdRutaPersonalParada,IdConceptoGastoViaje,ImporteAutorizado,ImporteAutorizadoState,LitrosAutorizados,LitrosAutorizadosState,CreadoEl,CreadoPor,GalonesAutorizados)
		SELECT @IdRutaPersonalParada,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_ImporteAutorizadoState,ATT_LitrosAutorizados,ATT_LitrosAutorizadosState,@CreadoEl,@CreadoPor,ATT_GalonesAutorizados
		FROM #TempCatRutasTrayectosGastos

		/*SECCION PARA AGREGAR LA PUNTUACION*/
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalPuntuaciones

		SELECT ATT_IdRutaPersonalPuntuacion,ATT_IdPuesto,ATT_Puntos
		INTO #TempCatRutasPersonalPuntuaciones
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalPuntuaciones',2) 
		WITH(ATT_IdRutaPersonalPuntuacion int,ATT_IdPuesto int,ATT_Puntos int)
			
		EXEC sp_xml_removedocument @docHandle
			
		INSERT INTO CatRutasPersonalPuntuaciones(IdRutaPersonalParada,IdPuesto,Puntos,CreadoEl,CreadoPor)
		SELECT @IdRutaPersonalParada,ATT_IdPuesto,ATT_Puntos,@CreadoEl,@CreadoPor
		FROM #TempCatRutasPersonalPuntuaciones
			
		SET @KilometrosTotales = ISNULL((SELECT SUM(Kilometros) FROM CatRutasTrayectos WHERE IdRuta = @IdRutaPersonal),0)
		SET @HorasTotales = ISNULL((SELECT SUM(Horas) FROM CatRutasTrayectos WHERE IdRuta = @IdRutaPersonal),0)
				 
		 IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdRutaPersonalParada' AND IdUsuario = @CreadoPor)
			INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdRutaPersonalParada',CAST(@IdRutaPersonalParada as varchar(10)),@CreadoPor )
		 ELSE
			UPDATE SisParametrosPagina SET Parametros = CAST(@IdRutaPersonalParada as varchar(10)) WHERE Pagina = 'IdRutaPersonalParada' AND IdUsuario = @CreadoPor

 	COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

