CREATE PROCEDURE [dbo].[usp_CatLayoutsConveniosPQ]
AS
BEGIN
	BEGIN TRANSACTION
		
		DECLARE @NumeroCliente int;
		DECLARE @vigencia date;
		DECLARE @Origen varchar(20);
        DECLARE @Destino varchar(20);
		DECLARE @Concepto varchar(20);
		DECLARE @PesoMinimo decimal(20,6);
        DECLARE @PesoMaximo decimal(20,6);
        DECLARE @Importe decimal(20,6);
		DECLARE @TipoCalculo varchar(20);
        DECLARE @Producto varchar(150);
        DECLARE @IdCliente int;
        DECLARE @IdOrigen int;
        DECLARE @IdDestino int;
        DECLARE @IdTarifa int;
        DECLARE @IdConceptoFacturacion int;
        DECLARE @IdTarifaTipoCalculo int;
        DECLARE @IdProducto int;
        DECLARE @IdProductoTarifaConvenio int;

        DECLARE @IdCatConveniosPQ int;
        DECLARE @IdCatTarifaConvenioPQ int;

        DECLARE @tempConvenio TABLE
                               (     
                                    IdConvenio int,
                                   IdCliente int
                               );

        DECLARE @tempConvenioTarifa TABLE
                               (  
                                IdTarifaConvenio int,
                                   IdConvenio int,
                                   IdTarifa int,
                                   IdProducto int
                               );

        DECLARE @tempProductosTarifaConvenio TABLE
                               (  
                                IdProductoTarifaConvenio int,
                                   IdTarifaConvenio int,
                                   IdProducto int
                               );   




		IF @@TRANCOUNT > 0
			BEGIN

                DECLARE ProdLayoutConvenioCliente CURSOR FOR select distinct NumeroCliente from CarLayoutsConvenioPQ --where NumeroCliente=783
                        OPEN ProdLayoutConvenioCliente
                            FETCH NEXT FROM ProdLayoutConvenioCliente INTO @NumeroCliente
                            WHILE @@fetch_status = 0
                            BEGIN
                                set @IdCliente=0;
                                
                                Select @IdCliente=IdCliente from CatClientes where NumeroCliente=@NumeroCliente;

                    DECLARE ProdLayoutConvenioProducto CURSOR FOR select Producto from CarLayoutsConvenioPQ where Concepto='FLETE' and NumeroCliente=@NumeroCliente group by Producto
                        OPEN ProdLayoutConvenioProducto
                            FETCH NEXT FROM ProdLayoutConvenioProducto INTO @Producto
                            WHILE @@fetch_status = 0
                            BEGIN								
	
                                        DECLARE ProdLayoutConvenio CURSOR FOR select NumeroCliente,vigencia,Origen,Destino,Concepto,PesoMinimo,PesoMaximo,Importe,TipoCalculo,Producto from CarLayoutsConvenioPQ where Concepto='FLETE' and NumeroCliente=@NumeroCliente and Producto=@Producto
                                        OPEN ProdLayoutConvenio
                                            FETCH NEXT FROM ProdLayoutConvenio INTO @NumeroCliente,@vigencia,@Origen,@Destino,@Concepto,@PesoMinimo,@PesoMaximo,@Importe,@TipoCalculo,@Producto
                                            WHILE @@fetch_status = 0
                                            BEGIN
                                                    set @IdTarifa=0;
                                                    set @IdCatTarifaConvenioPQ=0;
                                                    set @IdProductoTarifaConvenio=0; 
                                                    set @IdOrigen=0;
                                                    set @IdDestino=0;
                                                    set @IdCatConveniosPQ=0;

                                                    
                                                    select @IdOrigen=isnull(catr.IdOrigen,0),@IdDestino=isnull(catr.IdDestino,0) from CatRutas catr
                                                    inner join CatClientes catc on catc.IdCliente=catr.IdCliente
                                                    inner join CatOrigenesDestinos catori on catori.IdOrigenDestino=catr.IdOrigen
                                                    inner join CatOrigenesDestinos catdest on catdest.IdOrigenDestino=catr.IdDestino
                                                    where catc.NombreFiscal like '%PUBLICO EN GENERAL%' 
                                                    and catori.OrigenDestino=@Origen and catdest.OrigenDestino=@Destino;

                                                    
                                                    select top 1 @IdTarifa=isnull(ctpq.IdTarifa,0) from CatTarifaPQ ctpq
                                                    inner join CatTarifaDestinosPQ ctpqd on ctpqd.IdTarifa=ctpq.IdTarifa
                                                    where ctpq.IdOrigen=@IdOrigen and ctpqd.IdDestino=@IdDestino;

                                                    select @IdConceptoFacturacion=IdConceptoFacturacion from CatConceptosFacturacion where ConceptoFacturacion=@Concepto and Activo=1;
                                                    select @IdTarifaTipoCalculo=IdTarifaTipoCalculo from CatTarifaTipoCalculoPQ where TarifaTipoCalculo=@TipoCalculo;
                                                    select @IdProducto=IdProducto from CatProductosPQ where Descripcion=@Producto;

                                                    select @IdCatConveniosPQ=isnull(IdConvenio,0) from @tempConvenio where IdCliente=@IdCliente;

                                                    if (@IdCatConveniosPQ > 0) and ( @IdTarifa > 0) 
                                                        begin

                                                            select @IdCatTarifaConvenioPQ=isnull(IdTarifaConvenio,0) from @tempConvenioTarifa where IdTarifa=@IdTarifa and IdConvenio in (@IdCatConveniosPQ) and IdProducto=@IdProducto;

                                                            if @IdCatTarifaConvenioPQ = 0
                                                                begin                         

                                                                    INSERT INTO [dbo].[CatTarifaConvenioPQ]([IdConvenio], [IdTarifa]) 
                                                                        VALUES(@IdCatConveniosPQ, @IdTarifa);                                          

                                                                    SET @IdCatTarifaConvenioPQ= @@IDENTITY;

                                                                    INSERT INTO @tempConvenioTarifa ([IdTarifaConvenio],[IdConvenio], [IdTarifa],IdProducto) 
                                                                        VALUES(@IdCatTarifaConvenioPQ,@IdCatConveniosPQ, @IdTarifa,@IdProducto);

                                                                end                                                                                                                                  
                                                        end
                                                        else
                                                            begin
                                                                 
                                                                    if @IdCatConveniosPQ = 0
                                                                        begin
                                                                                INSERT INTO [dbo].[CatConveniosPQ]([IdCliente], [Vigencia], [activo], [CuotaMensual]) 
                                                                                    VALUES(@IdCliente, '2022-03-31', 1, 1)

                                                                                SET @IdCatConveniosPQ= @@IDENTITY;  

                                                                                INSERT INTO @tempConvenio (IdConvenio, IdCliente) VALUES(@IdCatConveniosPQ,@IdCliente);                                             

                                                                                INSERT INTO [dbo].[CatTarifaConvenioPQ]([IdConvenio], [IdTarifa]) 
                                                                                    VALUES(@IdCatConveniosPQ, @IdTarifa);

                                                                                SET @IdCatTarifaConvenioPQ= @@IDENTITY;

                                                                                INSERT INTO @tempConvenioTarifa ([IdTarifaConvenio],[IdConvenio], [IdTarifa],IdProducto) 
                                                                                    VALUES(@IdCatTarifaConvenioPQ,@IdCatConveniosPQ, @IdTarifa,@IdProducto);
                                                                       end     

                                                            end




                                                    if ( @IdCatTarifaConvenioPQ > 0) 
                                                        begin
                                                            if @Concepto = 'FLETE'
                                                                       begin
                                                                           INSERT INTO [dbo].[CatTarifaConvenioConceptosPQ]( [IdConceptoFacturacion], [IdTarifaConvenio], [Importe], 
                                                                           [IdImpuestoTraslada], [ImporteIva], [IdImpuestoRetiene], [ImporteRetiene], 
                                                                           [IdTipoCalculo], [RangoMinimo], [RangoMaximo], [IdAgregadoDesde], [IdTipoMedida]) 
                                                                               VALUES(1, @IdCatTarifaConvenioPQ, @Importe, 3, (@Importe * 0.16),5 ,(@Importe * 0.04), @IdTarifaTipoCalculo, @PesoMinimo, @PesoMaximo, 2, 2);
                                                                       end 


                                                           select @IdProductoTarifaConvenio=isnull(IdProductoTarifaConvenio,0) from @tempProductosTarifaConvenio where IdTarifaConvenio=@IdCatTarifaConvenioPQ and IdProducto=@IdProducto; 

                                                           if @IdProductoTarifaConvenio=0
                                                               begin

                                                                   INSERT INTO [dbo].[CatProductosTarifaConvenioPQ]( [IdProducto], [IdTarifaConvenio], [Importe], [IdImpuestoTraslada], [ImporteIva], [IdImpuestoRetiene], [ImporteRetiene]) 
                                                                       VALUES(@IdProducto, @IdCatTarifaConvenioPQ, 0, 0, 0, 0, 0);

                                                                       set @IdProductoTarifaConvenio=@@IDENTITY;

                                                                  INSERT INTO @tempProductosTarifaConvenio (IdProductoTarifaConvenio,IdTarifaConvenio,IdProducto) VALUES (@IdProductoTarifaConvenio,@IdCatTarifaConvenioPQ,@IdProducto);

                                                               end
                                                        end


                                                FETCH NEXT FROM ProdLayoutConvenio INTO @NumeroCliente,@vigencia,@Origen,@Destino,@Concepto,@PesoMinimo,@PesoMaximo,@Importe,@TipoCalculo,@Producto
                                            END
                                        CLOSE ProdLayoutConvenio
                                        DEALLOCATE ProdLayoutConvenio

                                    FETCH NEXT FROM ProdLayoutConvenioProducto INTO @Producto
                                   END
                                 CLOSE ProdLayoutConvenioProducto
                              DEALLOCATE ProdLayoutConvenioProducto                                        



                        DECLARE ProdLayoutConvenioManiobra CURSOR FOR select NumeroCliente,vigencia,Concepto,PesoMinimo,PesoMaximo,Importe,TipoCalculo,Producto from CarLayoutsConvenioPQ where Concepto!='FLETE' and NumeroCliente=@NumeroCliente
                        OPEN ProdLayoutConvenioManiobra
                            FETCH NEXT FROM ProdLayoutConvenioManiobra INTO @NumeroCliente,@vigencia,@Concepto,@PesoMinimo,@PesoMaximo,@Importe,@TipoCalculo,@Producto
                            WHILE @@fetch_status = 0
                            BEGIN

                                DECLARE ProdLayoutConvenioManiobraOD CURSOR FOR select IdTarifaConvenio from @tempConvenioTarifa where IdConvenio in (select IdConvenio from @tempConvenio where IdCliente=@IdCliente);
                                    OPEN ProdLayoutConvenioManiobraOD
                                        FETCH NEXT FROM ProdLayoutConvenioManiobraOD INTO @IdCatTarifaConvenioPQ
                                        WHILE @@fetch_status = 0
                                        BEGIN
                                                                                      
                                            select @IdConceptoFacturacion=IdConceptoFacturacion from CatConceptosFacturacion where ConceptoFacturacion=@Concepto and Activo=1;
                                            select @IdTarifaTipoCalculo=IdTarifaTipoCalculo from CatTarifaTipoCalculoPQ where TarifaTipoCalculo=@TipoCalculo;

                                            

                                            if (@IdCatTarifaConvenioPQ > 0) 
                                                begin

                                                                   INSERT INTO [dbo].[CatTarifaConvenioConceptosPQ]( [IdConceptoFacturacion], [IdTarifaConvenio], [Importe], 
                                                                   [IdImpuestoTraslada], [ImporteIva], [IdImpuestoRetiene], [ImporteRetiene], 
                                                                   [IdTipoCalculo], [RangoMinimo], [RangoMaximo], [IdAgregadoDesde], [IdTipoMedida]) 
                                                                       VALUES(@IdConceptoFacturacion, @IdCatTarifaConvenioPQ, @Importe, 3, (@Importe * 0.16),4,0, @IdTarifaTipoCalculo, @PesoMinimo, @PesoMaximo, 1, 2);

                                                end


                                       FETCH NEXT FROM ProdLayoutConvenioManiobraOD INTO @IdCatTarifaConvenioPQ
                                     END
                                   CLOSE ProdLayoutConvenioManiobraOD
                                   DEALLOCATE ProdLayoutConvenioManiobraOD

                                FETCH NEXT FROM ProdLayoutConvenioManiobra INTO @NumeroCliente,@vigencia,@Concepto,@PesoMinimo,@PesoMaximo,@Importe,@TipoCalculo,@Producto
                            END
                        CLOSE ProdLayoutConvenioManiobra
                        DEALLOCATE ProdLayoutConvenioManiobra

                   FETCH NEXT FROM ProdLayoutConvenioCliente INTO @NumeroCliente
                   END
                CLOSE ProdLayoutConvenioCliente
                DEALLOCATE ProdLayoutConvenioCliente


				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

