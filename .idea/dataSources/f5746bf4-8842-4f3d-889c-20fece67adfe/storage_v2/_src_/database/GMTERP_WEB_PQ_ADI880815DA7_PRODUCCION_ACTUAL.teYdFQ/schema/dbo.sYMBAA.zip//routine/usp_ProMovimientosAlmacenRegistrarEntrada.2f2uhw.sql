CREATE PROCEDURE [dbo].[usp_ProMovimientosAlmacenRegistrarEntrada]
	 @Folio int ,
	 @FechaHora datetime,
	 @IdTipoMovimientoAlmacen int ,
	 @IdProveedor int ,
	 @Referencia varchar(500),
	 @Estatus tinyint,
	 @Observaciones varchar(512),
	 @SubTotal money,
	 @Total money ,
 	 @IdImpuestosTrasladadosFederales int,
	 @ImpuestosTrasladadosFederales money,
 	 @IdImpuestosRetenidosFederales int,
	 @ImpuestosRetenidosFederales money,
	 @CreadoEl datetime,
	 @CreadoPor int,
	 @dsProMovimientosAlmacenConceptos ntext,
	 @IdPeticion varchar(100),
	 @IdMoneda int,
	 @TipoCambio money,
	 @IdCompra int,
	 @dsProArticulosDetallados ntext = NULL,
	 @dsProArticulosLlantas ntext = NULL,  --Se Agrego por parte de la solicitusd 12730
	 @EsTraspaso bit = 0, --Se agrego por parte de la solicitud 168
	 @EsDevolucion bit = 0, --SOLICITUD 466
	 @IdMovimientoAlmacenActual int = NULL --SOLICITUD 466
 	/* *************************************************************************************************
	SOLICITUD 12730

	Descripcion: Se agrego validacion de concurrencia y se modifico el cursor TempProLlantas para que reciva el ATT_PrecionUnitarioLlanta
	

	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 16/07/2019
	Versión: Versión 8.0.44.38

	Invocada desde: <PAGE_ProMovimientosAlmacenEntradaR, ClsProMovimientosAlmacen, EXEC usp_ProMovimientosAlmacenRegistrarEntrada>
	************************************************************************************************ */
	/* *************************************************************************************************
	SOLICITUD 168

	Descripcion: Se agrego para detectar si se utiliza el procedimiento desde un traspaso
	
	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 25/09/2019
	Versión: Versión 8.0.46.21

	Invocada desde: <PAGE_ProMovimientosAlmacenTraspasoR >
	************************************************************************************************ */
	/* *************************************************************************************************
	SOLICITUD 466

	Descripcion: Se modifico para funcionar con el nuevo boton de devolucion en inventario
	
	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 06/11/2019
	Versión: Versión 8.0.47.31

	Invocada desde: <PAGE_ProMovimientosAlmacenDevolucionR >
	************************************************************************************************ */
	/* *************************************************************************************************
	SOLICITUD 1160

	Descripcion: Se modifico para que las observaciones en las entradas de almacen se guarden de manera correcta
	
	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 26/03/2020
	Versión: Versión 8.0.47.31

	Invocada desde: <PAGE_ProMovimientosAlmacenEntradaR Agregar() >
	************************************************************************************************ */
AS
DECLARE
	@docHandle int,
	@FolioMovimientoAlmacen int,
	@ErrorMsg varchar(8000),
	@ExistenciaActual decimal(15,4),
	@CostoPromedioActual money,
	@ImporteTotalPromedioActual money,
	@IdMovimientoAlmacen int, 	
	@IdMovimientoAlmacenConcepto int,
---
	@SubTotalDlls money,
	@TotalDlls money ,
	@ImpuestosTrasladadosFederalesDlls money,
	@ImpuestosRetenidosFederalesDlls money,
---
	@CostoPromedioActualDlls money,
	@ImporteTotalPromedioActualDlls money,
---
	@return_value int,
	@CostoLlantaPesos money,
	@CostoLlantaDlls money

BEGIN TRY
	BEGIN TRANSACTION
	--SET  @IdMoneda = 1

	IF ISNULL(@IdMoneda ,0)=0
			RAISERROR(N'La moneda es un campo requerido',
				16,
				1
				)	

	IF ISNULL(@TipoCambio,0) = 0		 
				RAISERROR(N'El tipo de cambio es un campo requerido',
					16,
					1
					)	

	IF ISNULL(@Folio,0) = 0
		RAISERROR(N'El folio del movimiento es un campo requerido',
			16,
			1
			)		
			
	--Se realizo la validacion para la concurrencia por parte de la solicitud 12730
	IF EXISTS(SELECT Folio FROM ProMovimientosAlmacen WHERE Folio = @Folio)
	BEGIN
		RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar.',
			16,
			1
			)
	END

	IF ISDATE(@FechaHora) = 0			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdTipoMovimientoAlmacen,0)=0
			RAISERROR(N'El tipo de movimiento de almacén es un campo requerido',
				16,
				1
				)			
				
	-- Valida cuando el tipo de movimiento es por compra.
	IF @IdProveedor = 0		
		SET @IdProveedor = NULL
	--
			
	IF @dsProMovimientosAlmacenConceptos is null 
		RAISERROR(N'Los conceptos del movimiento de almacén son requeridos',
			16,
			1
			)
							
	 IF ISNULL(@Folio,0)=0	 
		 SET @Folio = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)
	 

	IF @IdMoneda = 2 -- (2 DOLARES)
			BEGIN
				--Importes en dolares
				SET @SubTotalDlls = @SubTotal  
				SET @TotalDlls	  = @Total
				SET @ImpuestosTrasladadosFederalesDlls = @ImpuestosTrasladadosFederales 
				SET @ImpuestosRetenidosFederalesDlls   = @ImpuestosRetenidosFederales 
				--Importes en pesos
				SET @SubTotal	= @SubTotalDlls * @TipoCambio
				SET @Total		= @TotalDlls * @TipoCambio
				SET @ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederalesDlls * @TipoCambio
				SET @ImpuestosRetenidosFederales = @ImpuestosRetenidosFederalesDlls * @TipoCambio
			END
		ELSE
			BEGIN
				--Importes en dolares
				SET @SubTotalDlls = @SubTotal  / @TipoCambio
				SET @TotalDlls	  = @Total	   / @TipoCambio
				SET @ImpuestosTrasladadosFederalesDlls = @ImpuestosTrasladadosFederales  / @TipoCambio 
				SET @ImpuestosRetenidosFederalesDlls   = @ImpuestosRetenidosFederales / @TipoCambio
			END

	IF ISNULL(@IdCompra,0) = 0
	 SET @IdCompra = NULL

	INSERT INTO ProMovimientosAlmacen
				(Folio,
				FechaHora,
				IdTipoMovimientoAlmacen,
				IdProveedor,
				Referencia,
				Estatus,
				Observaciones,
				SubTotal,
				Total,
				IdImpuestosTrasladadosFederales,
				ImpuestosTrasladadosFederales,
				IdImpuestosRetenidosFederales,
				ImpuestosRetenidosFederales,
				IdMoneda,
				CreadoEl,
				CreadoPor,
				TipoCambio,
				SubTotalDlls,
				TotalDlls,				
				ImpuestosTrasladadosFederalesDlls,
				ImpuestosRetenidosFederalesDlls,
				IdCompra,
				IdMovimientoSalida)
			VALUES(@Folio,
				   @FechaHora,
				   @IdTipoMovimientoAlmacen,
				   @IdProveedor,
				   @Referencia,
				   @Estatus,
				   @Observaciones,
				   @SubTotal,
				   @Total,
				   @IdImpuestosTrasladadosFederales,
				   @ImpuestosTrasladadosFederales,
				   @IdImpuestosRetenidosFederales,
				   @ImpuestosRetenidosFederales,
				   @IdMoneda,
				   @CreadoEl,
				   @CreadoPor,
				   @TipoCambio,
				   @SubTotalDlls,
		   		   @TotalDlls,				
				   @ImpuestosTrasladadosFederalesDlls,
				   @ImpuestosRetenidosFederalesDlls,
				   @IdCompra,
				   @IdMovimientoAlmacenActual)

	SET @IdMovimientoAlmacen = (SELECT IDENT_CURRENT('ProMovimientosAlmacen'))		

	--seccion para agregar el idViaje a paremtros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoAlmacenEntrada' AND IdUsuario = @CreadoPor)
	INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoAlmacenEntrada',@IdMovimientoAlmacen,@CreadoPor)
	ELSE
	UPDATE SisParametrosPagina SET Parametros = @IdMovimientoAlmacen WHERE Pagina = 'IdMovimientoAlmacenEntrada' AND IdUsuario = @CreadoPor
	

	-------------------------------------------------------------------------------------------------------
	-- SECCION PARA AGREGAR LOS CONCEPTOS DE MOVIMIENTO DE ALMACEN
	--si modifican la estructura del xml actualizar en el store procedure [usp_ProOrdenesServiciosPartesDevolucionAplicar]
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProMovimientosAlmacenConceptos
	SELECT  ATT_IdArticulo,
			ATT_IdAlmacen,
			ATT_Cantidad,
			ATT_PrecioUnitario,
			ATT_Importe,
			ATT_UnidadMedida,
			ATT_Observaciones,
			ATT_IdOrdenServicioParteDevolucionPEPS,
			ATT_IdMovimientoAlmacenConcepto
	INTO #TempProMovimientosAlmacenConceptos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProMovimientosAlmacenConceptos',2) 
	WITH (ATT_IdArticulo int,
		  ATT_IdAlmacen int,
		  ATT_Cantidad decimal(15,4),
		  ATT_PrecioUnitario money,
		  ATT_Importe money,
		  ATT_UnidadMedida varchar(30),
		  ATT_Observaciones varchar(256),
		  ATT_IdOrdenServicioParteDevolucionPEPS int,
		  ATT_IdMovimientoAlmacenConcepto int)
	EXEC sp_xml_removedocument @docHandle

	-- Crear cursor
	DECLARE @ATT_IdArticulo int,
			@ATT_IdAlmacen int,
			@ATT_Cantidad decimal(15,4),
			@ATT_PrecioUnitario money,
			@ATT_Importe money,
			@ATT_UnidadMedida varchar(30),
			@ATT_Observaciones varchar(256),
			@ATT_IdOrdenServicioParteDevolucionPEPS int,
			@ATT_IdMovimientoAlmacenConcepto int,
			---
			@ATT_PrecioUnitarioDlls money,
			@ATT_ImporteDlls money

	DECLARE TempProMovimientosAlmacenConceptos CURSOR FOR 
	SELECT ATT_IdArticulo,
		   ATT_IdAlmacen,
		   ATT_Cantidad,
		   ATT_PrecioUnitario,
		   ATT_Importe,
		   ATT_UnidadMedida,
		   ATT_Observaciones,
		   ATT_IdOrdenServicioParteDevolucionPEPS, 
		   ATT_IdMovimientoAlmacenConcepto
	From #TempProMovimientosAlmacenConceptos
	SET @ErrorMsg =''
	OPEN TempProMovimientosAlmacenConceptos
	FETCH NEXT FROM TempProMovimientosAlmacenConceptos INTO 
		@ATT_IdArticulo,
		@ATT_IdAlmacen,
		@ATT_Cantidad,
		@ATT_PrecioUnitario,
		@ATT_Importe,
		@ATT_UnidadMedida,
		@ATT_Observaciones,
		@ATT_IdOrdenServicioParteDevolucionPEPS,
		@ATT_IdMovimientoAlmacenConcepto
	
	WHILE @@fetch_status = 0
	BEGIN

	IF @IdMoneda = 2 -- (2 DOLARES)
		BEGIN 

			SET @ATT_PrecioUnitarioDlls = @ATT_PrecioUnitario
			SET @ATT_ImporteDlls = @ATT_Importe 

			SET @ATT_PrecioUnitario =  @ATT_PrecioUnitarioDlls  * @TipoCambio
			SET @ATT_Importe		=  @ATT_ImporteDlls  * @TipoCambio
		END
	ELSE
		BEGIN
			SET @ATT_PrecioUnitarioDlls = @ATT_PrecioUnitario  / @TipoCambio
			SET @ATT_ImporteDlls		= @ATT_Importe  / @TipoCambio
		END

			-- Registrar costo y existencia.
			    IF  NOT EXISTS(SELECT Existencia FROM ProInventarioAlmacen WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo)

					INSERT INTO ProInventarioAlmacen(IdArticulo,
													 IdAlmacen,
													 Existencia,
													 CostoPromedio,
													 ImporteTotalPromedio,
													 CreadoEl,
													 CreadoPor,
													 CostoPromedioDlls,
													 ImporteTotalPromedioDlls)
					VALUES(@ATT_IdArticulo,@ATT_IdAlmacen,@ATT_Cantidad,@ATT_PrecioUnitario,@ATT_Importe,@CreadoEl,@CreadoPor,@ATT_PrecioUnitarioDlls,@ATT_ImporteDlls)
				  ELSE
					-- Calcular costos	  
					BEGIN
						SELECT  @ExistenciaActual = Existencia ,
								@ImporteTotalPromedioActual = isnull(ImporteTotalPromedio,0),
								@ImporteTotalPromedioActualDlls = isnull(ImporteTotalPromedioDlls,0)
						FROM ProInventarioAlmacen
						WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo			
						IF @ExistenciaActual = 0
							BEGIN
								SET @ExistenciaActual				= @ATT_Cantidad
								SET @CostoPromedioActual			= @ATT_PrecioUnitario
								SET @ImporteTotalPromedioActual		= @ATT_Importe

								SET @CostoPromedioActualDlls		= @ATT_PrecioUnitarioDlls
								SET @ImporteTotalPromedioActualDlls = @ATT_ImporteDlls
							END
						ELSE
							BEGIN 
								SET @ExistenciaActual				= @ExistenciaActual+@ATT_Cantidad
								SET @CostoPromedioActual			= (@ImporteTotalPromedioActual+@ATT_Importe)/@ExistenciaActual
								SET @ImporteTotalPromedioActual		= @ExistenciaActual*@CostoPromedioActual 

								SET @CostoPromedioActualDlls		= (@ImporteTotalPromedioActualDlls+@ATT_ImporteDlls)/@ExistenciaActual
								SET @ImporteTotalPromedioActualDlls = @ExistenciaActual*@CostoPromedioActualDlls 

							END
							
					-- Registrar costo calculado			
						UPDATE ProInventarioAlmacen
							 SET  Existencia				= @ExistenciaActual,
								  CostoPromedio				= @CostoPromedioActual,
								  ImporteTotalPromedio		= @ImporteTotalPromedioActual,
								  ModificadoEl				= @CreadoEl,
							      ModificadoPor				= @CreadoPor,
								  CostoPromedioDlls			= @CostoPromedioActualDlls,
								  ImporteTotalPromedioDlls	= @ImporteTotalPromedioActualDlls
						WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo	
					END
				SELECT @CostoPromedioActual = CostoPromedio, @CostoPromedioActualDlls = CostoPromedioDlls FROM ProInventarioAlmacen WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo	
				
			--  Registrar detalle de movimiento
				INSERT INTO ProMovimientosAlmacenConceptos (IdArticulo,
							Cantidad,
							PrecioUnitario,
							Importe,
							UnidadMedida,
							IdAlmacen,
							CreadoPor,
							CreadoEl,
							IdMovimientoAlmacen,
							ExistenciaControlPEPS,
							CostoPromedio,
							PrecioUnitarioDlls,
							ImporteDlls,
							CostoPromedioDlls,
							Observaciones) --Se agrego en solicitud 466
					VALUES (@ATT_IdArticulo,@ATT_Cantidad,@ATT_PrecioUnitario,@ATT_Importe,@ATT_UnidadMedida,@ATT_IdAlmacen,@CreadoPor,@CreadoEl,
							@IdMovimientoAlmacen,
							@ATT_Cantidad,
							@CostoPromedioActual,
							@ATT_PrecioUnitarioDlls,
							@ATT_ImporteDlls,
							@CostoPromedioActualDlls,
							@ATT_Observaciones)--Se agrego en solicitud 466
		--		
				--se obtiene el id que registro agregado
				SET @IdMovimientoAlmacenConcepto = (SELECT IDENT_CURRENT('ProMovimientosAlmacenConceptos'))

				IF @EsDevolucion = 1
				BEGIN 
					UPDATE ProMovimientosAlmacenConceptos SET CantidadDevolucion = ((SELECT CantidadDevolucion FROM ProMovimientosAlmacenConceptos WHERE IdMovimientoAlmacenConcepto = @ATT_IdMovimientoAlmacenConcepto) - @ATT_Cantidad) WHERE IdMovimientoAlmacenConcepto = @ATT_IdMovimientoAlmacenConcepto
				END
				
				--se actualizar la referecnia en devoluciones de partes 
				UPDATE ProOrdenesServiciosPartesDevolucionPEPS 
				SET IdMovimientoAlmacenConcepto = @IdMovimientoAlmacenConcepto
				WHERE IdOrdenServicioParteDevolucionPEPS = @ATT_IdOrdenServicioParteDevolucionPEPS
				
		FETCH NEXT FROM TempProMovimientosAlmacenConceptos INTO 
		@ATT_IdArticulo,@ATT_IdAlmacen,@ATT_Cantidad,@ATT_PrecioUnitario,@ATT_Importe,@ATT_UnidadMedida,@ATT_Observaciones,@ATT_IdOrdenServicioParteDevolucionPEPS,@ATT_IdMovimientoAlmacenConcepto
	END
	CLOSE TempProMovimientosAlmacenConceptos
	DEALLOCATE TempProMovimientosAlmacenConceptos
	
	
	
	-- SECCION PARA AGREGAR LOS CONCEPTOS DE MOVIMIENTO DE ALMACEN DETALLADOS	SOLICITUD 12325
	IF @dsProArticulosDetallados IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProArticulosDetallados
		
		SELECT  ATT_IdArticuloDetallado ,ATT_IdMovimientoAlmacen,ATT_NumeroSerie,ATT_CreadoPor,ATT_CreadoEl,ATT_Activo,ATT_IdOrdenCompra,ATT_IdAlmacen
		INTO #TempProArticulosDetallados
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProArticulosDetallados',2) 
		WITH (ATT_IdArticuloDetallado  int,ATT_IdMovimientoAlmacen  int,ATT_NumeroSerie varchar(25) COLLATE Modern_Spanish_CS_AS,ATT_CreadoPor int, ATT_CreadoEl datetime,ATT_Activo bit,ATT_IdOrdenCompra int,ATT_IdAlmacen int )
		
		EXEC sp_xml_removedocument @docHandle
		
		IF @EsTraspaso = 0 AND @EsDevolucion = 0-- Se agrego por parte de la solicitud 168, Si es traspaso no agrege los numeros de serie.
		BEGIN
			INSERT INTO ProMovimientosAlmacenDetallado (IdArticulo,IdMovimientoAlmacen,NumeroSerie,CreadoPor,CreadoEl,Activo,IdOrdenCompra,IdAlmacen)
			SELECT ATT_IdArticuloDetallado,@IdMovimientoAlmacen,ATT_NumeroSerie,ATT_CreadoPor,ATT_CreadoEl,ATT_Activo,ATT_IdOrdenCompra,ATT_IdAlmacen FROM #TempProArticulosDetallados
		END

		IF @EsDevolucion = 1 --SOLICITUD 466
		BEGIN
			Update ProMovimientosAlmacenDetallado set Activo = 0 
			WHERE IdProMovimientodetallado = (SELECT ATT_IdArticuloDetallado FROM #TempProArticulosDetallados WHERE IdProMovimientodetallado = #TempProArticulosDetallados.ATT_IdArticuloDetallado)
		END

		INSERT INTO ProMovimientosAlmacenDetalladoHistorico (IdProMovimientoDetallado,CreadoEl,CreadoPor,IdMovimientoAlmacen,IdTipoMovimientoAlmacen)
		SELECT pmad1.IdProMovimientodetallado,ATT_CreadoEl,ATT_CreadoPor,@IdMovimientoAlmacen,@IdTipoMovimientoAlmacen FROM #TempProArticulosDetallados 
		inner join ProMovimientosAlmacenDetallado pmad1 on  pmad1.NumeroSerie = #TempProArticulosDetallados.ATT_NumeroSerie
	END

	--SECCION PARA AGREGAR LOS NUMEROS ECONOMICOS DE LLANTAS
		IF @dsProArticulosLlantas IS NOT NULL
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProArticulosLlantas
				SELECT ATT_IdArticuloLlanta, ATT_NumeroEconomico, ATT_PerdienteEtiqueta, ATT_CreadoPor, ATT_CreadoEl, ATT_PrecioUnitarioLlanta
				INTO #TempProLlantas
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProLlantas',2) 
				WITH (ATT_IdArticuloLlanta int, ATT_NumeroEconomico varchar(20), ATT_PerdienteEtiqueta bit, ATT_CreadoPor int, ATT_CreadoEl datetime,ATT_PrecioUnitarioLlanta money)
				EXEC sp_xml_removedocument @docHandle
						
				-- Crear cursor
				DECLARE @ATT_IdArticuloLlanta int, @ATT_NumeroEconomico varchar(20),@ATT_PerdienteEtiqueta bit, @ATT_CreadoPor int, @ATT_CreadoEl datetime, @ATT_PrecioUnitarioLlanta money
				DECLARE TempProLlantas CURSOR FOR 
				SELECT 	ATT_IdArticuloLlanta, ATT_NumeroEconomico, ATT_PerdienteEtiqueta, ATT_CreadoPor, ATT_CreadoEl, ATT_PrecioUnitarioLlanta From #TempProLlantas

				OPEN TempProLlantas 
				FETCH NEXT FROM TempProLlantas INTO @ATT_IdArticuloLlanta, @ATT_NumeroEconomico, @ATT_PerdienteEtiqueta, @ATT_CreadoPor, @ATT_CreadoEl, @ATT_PrecioUnitarioLlanta
				WHILE @@fetch_status = 0
					BEGIN
						--- Valida número económico
						IF EXISTS(SELECT TOP 1 NumeroEconomico FROM ProLlantas WHERE  NumeroEconomico = @ATT_NumeroEconomico)
							BEGIN
							SET @ErrorMsg = 'El número económico '+CAST(@ATT_NumeroEconomico as varchar(20))+' ya esta registrado en llantas '
								RAISERROR(@ErrorMsg,
									16,
									1
									)
							END
						    
						--- Seccion guardar
						DECLARE @IdModeloLlanta int,
							@IdMarcaLlanta int,
							@IdMedidaLlanta int,
							@IdTipoLlanta int,
							@ProfundidadOriginal decimal (10, 2),
							@ProfundidadMinima  decimal (10, 2),
							@PresionMaxima  decimal (10, 2),
							@PresionMinima  decimal (10, 2),
							@ProfundidadActual  decimal (10, 2),
							@PresionActual  decimal (10, 2),
							@IdEstatuLlanta int,
							@CostoLlanta money,
							@VidaUtil int
						SELECT 
							@IdModeloLlanta  =CatArticulos.IdModeloLlanta,
							@IdMarcaLlanta  = CatArticulos.IdMarcaLlanta,
							@IdMedidaLlanta  = CatArticulos.IdMedidaLlanta,
							@IdTipoLlanta  =CatArticulos.IdTipoLlanta,
							@ProfundidadOriginal  = CatArticulos.ProfundidadOriginalLlanta,
							@ProfundidadMinima   = CatArticulos.ProfundidadMinimaLlanta,
							@PresionMaxima   = CatArticulos.PresionMaximaLlanta,
							@PresionMinima   = CatArticulos.PresionMinimaLlanta,
							@ProfundidadActual  = CatArticulos.ProfundidadOriginalLlanta,
							@PresionActual   =	CatArticulos.PresionMinimaLlanta,
							@IdEstatuLlanta  = null,
							@CostoLlanta  = 0,
							@VidaUtil = CatArticulos.VidaUtilLlanta
						FROM CatArticulos where IdArticulo = @ATT_IdArticuloLlanta
									
							IF @IdMoneda  =  1
								BEGIN
									SET @CostoLlantaPesos  = @ATT_PrecioUnitarioLlanta
									SET @CostoLlantaDlls   = @ATT_PrecioUnitarioLlanta / @TipoCambio
								END
								ELSE
									BEGIN
										SET @CostoLlantaPesos  = @ATT_PrecioUnitarioLlanta * @TipoCambio
										SET @CostoLlantaDlls   = @ATT_PrecioUnitarioLlanta
									END
							

						-- Agregar llantas
						EXEC @return_value = usp_ProLlantasRegistrar @ATT_NumeroEconomico,
						  											@IdModeloLlanta,
																	@IdMarcaLlanta,
																	@IdMedidaLlanta,
																	@IdTipoLlanta,
																	@ProfundidadOriginal,
																	@ProfundidadMinima,
																	@PresionMaxima,
																	@PresionMinima,
																	@ProfundidadActual,
																	@PresionActual,
																	@IdEstatuLlanta,
																	@CreadoEl,
																	@CreadoPor,
																	@CreadoEl,
																	@IdPeticion ,
																	@CostoLlantaPesos, 
																	@VidaUtil,
																	@ATT_IdArticuloLlanta,
																	@ATT_PerdienteEtiqueta,
																	@IdCompra,
																	@CostoLlantaDlls,  
																	@TipoCambio,
																	@CreadoEl


							IF @return_value <> 0
								RAISERROR(N'Ocurrió un error',
										16,
										1
										)   
							
							-------
							FETCH NEXT FROM TempProLlantas INTO @ATT_IdArticuloLlanta, @ATT_NumeroEconomico, @ATT_PerdienteEtiqueta, @ATT_CreadoPor, @ATT_CreadoEl,@ATT_PrecioUnitarioLlanta
					END
				DROP TABLE #TempProLlantas
				CLOSE TempProLlantas
				DEALLOCATE TempProLlantas			   
			END
		-----
		
	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

