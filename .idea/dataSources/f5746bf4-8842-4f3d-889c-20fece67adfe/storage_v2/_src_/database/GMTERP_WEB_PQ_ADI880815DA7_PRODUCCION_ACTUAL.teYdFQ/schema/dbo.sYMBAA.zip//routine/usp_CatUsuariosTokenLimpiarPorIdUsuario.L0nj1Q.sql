CREATE PROCEDURE [dbo].[usp_CatUsuariosTokenLimpiarPorIdUsuario]	
	@IdUsuario varchar(max),
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

		UPDATE CatUsuarios SET
		Token = NULL,
		TokenIOS = NULL,
		TipoServicio = NULL
		WHERE IdUsuario = @IdUsuario

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

