

CREATE PROCEDURE [dbo].[usp_CatUsuariosAgregarPQ](
	@Usuario varchar(16),
	@Nombre varchar(100),
	@Contraseña varchar(20),
	@TipoUsuario Tinyint,
	@CorreoElectronico varchar(100),
	@IdSucursal int,
	@Activo Bit,
	@CreadoEl datetime,
	@CreadoPor int,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@FiltrarAcceso bit,
	@FiltrarAccesoPorIP varchar(15),
	@FiltrarAccesoPorHora BIT ,
	@Hora0 bit,
	@Hora1 bit,
	@Hora2 bit ,
	@Hora3 bit ,
	@Hora4 bit ,
	@Hora5 bit,
	@Hora6 bit,
	@Hora7 bit,
	@Hora8 bit,
	@Hora9 bit,
	@Hora10 bit,
	@Hora11 bit ,
	@Hora12 bit,
	@Hora13 bit,
	@Hora14 bit,
	@Hora15 bit,
	@Hora16 bit,
	@Hora17 bit,
	@Hora18 bit,
	@Hora19 bit,
	@Hora20 bit,
	@Hora21 bit,
	@Hora22 bit,
	@Hora23 bit,
	@Lunes bit,
	@Martes bit,
	@Miercoles bit,
	@Jueves bit,
	@Viernes bit,
	@Sabado bit,
	@Domingo bit,
	@VencimientoCertificadoNotificaciones  bit,
	@APaterno varchar(25),
	@AMaterno varchar(25))
AS
--BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Nombre, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre es un campo requerido*FIN*', 16, 1)
			return
		end
		
		IF ISNULL(@Contraseña, '') = '' begin
			RAISERROR(N'*INICIO*La Contraseña es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@TipoUsuario,0) <= 0  begin
			RAISERROR(N'*INICIO*El Tipo de usuario es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@CorreoElectronico , '') = '' begin
			RAISERROR(N'*INICIO*El correo eléctronico es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@IdSucursal,0) <= 0 begin
			RAISERROR(N'*INICIO*La sucursal es un campo requerido*FIN*', 16, 1)
			return
		end
		INSERT INTO CatUsuariosPQ(Usuario, Nombre,Contraseña,TipoUsuario,CorreoElectronico,IdSucursal,Activo,CreadoEl,CreadoPor,ModificadoEl,ModificadoPor,FiltrarAcceso,FiltrarAccesoPorIP,FiltrarAccesoPorHora,
		Hora0,Hora1,Hora2,Hora3,Hora4,Hora5,Hora6,Hora7,Hora8,Hora9,Hora10,Hora11,Hora12,Hora13,Hora14,Hora15,Hora16,Hora17,Hora18,Hora19,Hora20,Hora21,Hora22,Hora23,Lunes,Martes,Miercoles,Jueves,Viernes,Sabado,Domingo,
		VencimientoCertificadoNotificaciones,APaterno,AMaterno)
		VALUES (@Usuario, @Nombre, @Contraseña, @TipoUsuario,@CorreoElectronico,@IdSucursal,@Activo,@CreadoEl,@CreadoPor,@ModificadoEl,@ModificadoPor,@FiltrarAcceso,@FiltrarAccesoPorIP,@FiltrarAccesoPorHora,
		@Hora0,@Hora1,@Hora2,@Hora3,@Hora4,@Hora5,@Hora6,@Hora7,@Hora8,@Hora9,@Hora10,@Hora11,@Hora12,@Hora13,@Hora14,@Hora15,@Hora16,@Hora17,@Hora18,@Hora19,@Hora20,@Hora21,@Hora22,@Hora23,@Lunes,@Martes,@Miercoles,@Jueves,@Viernes,@Sabado,@Domingo,
		@VencimientoCertificadoNotificaciones,@APaterno,@AMaterno)
	COMMIT TRANSACTION
--END TRY
--BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
--END CATCH
go

