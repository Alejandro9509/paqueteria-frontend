
CREATE PROCEDURE [dbo].[usp_ProViajeLlegadaEliminarPQ](
	@IdViajeLlegada int
	)
AS

BEGIN
	BEGIN TRANSACTION
		declare @ExisteSalida int;

		IF ISNULL(@IdViajeLlegada, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador de Llegada del viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		delete ProViajeLlegadaPQ
		where IdViajeLlegada = @IdViajeLlegada;


		IF @@TRANCOUNT > 0			
					COMMIT TRANSACTION
		else
		BEGIN
			
			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END

end
go

