
create PROCEDURE [dbo].[usp_CatTiposIncidenciasGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTiposIncidencias
go

