
CREATE PROCEDURE [dbo].[usp_CatImpuestosEliminarPQ]
	@IdImpuesto INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdImpuesto,0) <= 0 begin
			RAISERROR(N'Identificador de Impuesto es un campo requerido', 16, 1);
			return;
		end;
		
		DELETE FROM CatImpuestos
		WHERE IdImpuesto = @IdImpuesto
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END
go

