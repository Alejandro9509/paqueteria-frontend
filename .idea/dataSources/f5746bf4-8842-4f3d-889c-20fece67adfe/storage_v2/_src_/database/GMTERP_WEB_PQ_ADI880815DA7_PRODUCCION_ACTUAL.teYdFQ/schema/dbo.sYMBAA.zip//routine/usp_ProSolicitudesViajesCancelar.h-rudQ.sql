CREATE PROCEDURE [dbo].[usp_ProSolicitudesViajesCancelar]
	@IdSolicitudViaje int,
	@Estatus int,
	@FechaHoraCancelado datetime,
	@UsuarioCancelo int,
	@MotivoCancelacion varchar(100),
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF (SELECT Estatus FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje) <> 2
		RAISERROR(N'La solicitud no se puede cancelar debido a que fue cambiado su estatus',
			16,
			1
			)
	IF (SELECT IsNULL(FechaHoraCancelado,'') FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje) <> ''
		RAISERROR(N'La solicitud no se puede cancelar debido a que ya fue cancelada',
			16,
			1
			)	
	IF NOT EXISTS(SELECT IdSolicitudViaje FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)
			
	IF ISNULL(@FechaHoraCancelado,'')= ''
		RAISERROR(N'Fecha de cancelación de solicitud es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@MotivoCancelacion,'')= ''
		RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)
				
	---Actualizamos los datos de cancelacion
	UPDATE ProSolicitudesViajes SET
	Estatus = @Estatus,
	FechaHoraCancelado = @FechaHoraCancelado,
	UsuarioCancelo = @UsuarioCancelo,
	MotivoCancelacion = @MotivoCancelacion
	WHERE IdSolicitudViaje = @IdSolicitudViaje
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

