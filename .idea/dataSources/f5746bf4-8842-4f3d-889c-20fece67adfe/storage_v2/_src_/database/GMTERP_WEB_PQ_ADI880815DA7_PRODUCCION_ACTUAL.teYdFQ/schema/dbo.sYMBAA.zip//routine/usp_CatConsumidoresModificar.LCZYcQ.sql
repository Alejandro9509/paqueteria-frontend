
	CREATE PROCEDURE [dbo].[usp_CatConsumidoresModificar]
	@IdConsumidor	int,
	@Codigo	int,	
	@Consumidor	varchar(50),
	@Activo bit,	
	@ModificadoEl datetime,
	@ModificadoPor int,
	@IdPeticion varchar(100)	
	AS
	BEGIN TRY
		BEGIN TRANSACTION
		
		IF ISNULL(@IdConsumidor,0)= 0
		RAISERROR(N'El identificador del Consumidor es un campo requerido',
				16,
				1
				)

		IF ISNULL(@Codigo,0)= 0
			RAISERROR(N'El código del Consumidor es un campo requerido',
				16,
				1
				)
				
		IF EXISTS(SELECT Codigo FROM CatConsumidores WHERE Codigo = @Codigo And IdConsumidor <> @IdConsumidor)
			RAISERROR(N'El código del Consumidor ya existe',
				16,
				1
				)	
											
		IF ISNULL(@Consumidor,'')= ''
			RAISERROR(N'El nombre del Consumidores un campo requerido',
				16,
				1
				)
				
		UPDATE CatConsumidores SET
		Codigo= @Codigo,
		Consumidor= @Consumidor,
		Activo= @Activo,
		ModificadoEl= @ModificadoEl,
		ModificadoPor= @ModificadoPor
		WHERE 	IdConsumidor=@IdConsumidor
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

