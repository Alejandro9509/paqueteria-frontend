CREATE PROCEDURE [dbo].[usp_CatProveedoresIEPSMaxFolio]    
AS    
Select ISNULL(MAX(Folio),0)+1 AS Folio from CatProveedoresIEPS
go

