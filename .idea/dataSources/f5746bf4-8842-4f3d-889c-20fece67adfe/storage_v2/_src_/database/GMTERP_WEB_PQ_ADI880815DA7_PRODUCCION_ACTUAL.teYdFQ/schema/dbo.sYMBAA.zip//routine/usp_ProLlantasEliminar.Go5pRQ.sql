CREATE PROCEDURE [dbo].[usp_ProLlantasEliminar]
	@IdLlanta int,
	@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdLlanta,0)= 0
			RAISERROR(N'El identificador de llanta es un campo requerido',
					16,
					1
					)
	IF EXISTS(SELECT IdCompra FROM ProLlantas WHERE IdLlanta = @IdLlanta And IdCompra is not null) 
			RAISERROR(N'La llanta viene de una compra no se puede eliminar',
					16,
					1
					)
					
	IF NOT EXISTS(SELECT IdLlanta FROM ProLlantas WHERE IdLlanta = @IdLlanta) 
			RAISERROR(N'La llanta ya fue eliminado por otro usuario',
					16,
					1
					)	
	
	IF EXISTS(SELECT top 1 IdLlanta FROM ProLlantasAuxiliar WHERE IdLlanta = @IdLlanta) 
			RAISERROR(N'La Llanta tiene registros en auxiliar de llantas, no es posible eliminarlo',
				16,
				1
				)	
            
	-- Eliminar 
	DELETE FROM ProLlantas where IdLlanta = @IdLlanta

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

