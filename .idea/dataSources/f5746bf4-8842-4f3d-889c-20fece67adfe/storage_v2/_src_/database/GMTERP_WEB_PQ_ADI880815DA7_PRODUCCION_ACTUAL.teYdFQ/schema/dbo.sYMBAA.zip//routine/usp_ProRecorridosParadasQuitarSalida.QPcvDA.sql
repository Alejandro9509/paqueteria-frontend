
CREATE PROCEDURE [dbo].[usp_ProRecorridosParadasQuitarSalida]
	@IdRecorrido int,
	@IdRecorridoParada int,
	@IdEstatuViaje int,
	@FechaHoraEstatusViaje datetime,
	@IdEstatuUnidadCamion int,
	@IdUbicacion int,
	@ModificadoPor  int,
	@ModificadoEl datetime,	
	@IdPeticion varchar(100)

	/*
	CREADO POR:  GUSTAVO PARTIDA NEVAREZ.
	FECHA DE CREACION: 29/05/20206.
	VERSION: V8 8.0.52.36.
	SOLICITUD: 2250.

	SE CREO PARA QUITAR LA SALIDA DE LA PARADA. 
	*/
AS
DECLARE 

	@return_value int,
	@IdCliente int,
	@IdUnidadCamion int

BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdRecorrido,0) = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdRecorridoParada,0) = 0
		RAISERROR(N'El identificador del recorrido parada es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdEstatuViaje,0) = 0
		RAISERROR(N'El estatus del recorrido es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT CanceladoEl FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido AND CanceladoEl IS NOT NULL)--cancelado
		RAISERROR(N'No se puede quitar la salida a este recorrido porque está cancelado',
			16,
			1
			)				

	IF EXISTS(SELECT prp.IdRecorridoParada FROM ProRecorridoParadas AS prp INNER JOIN ProLiquidaciones AS pl ON prp.IdLiquidacion = pl.IdLiquidacion WHERE prp.IdRecorrido = @IdRecorrido AND pl.CerradaEl IS NOT NULL AND prp.IdRecorridoParada = @IdRecorridoParada)
		RAISERROR(N'No se puede quitar la salida porque tiene la liquidación cerrada',
			16,
			1
			)
			
	IF EXISTS(SELECT prp.IdRecorridoParada FROM ProRecorridoParadas AS prp WHERE prp.IdRecorrido = @IdRecorrido AND prp.IdRecorridoParada = @IdRecorridoParada AND prp.Llegada IS NOT NULL)
		RAISERROR(N'No se puede quitar la salida porque tiene llegada el recorrido/parada, debe quitarle la llegada primero para poder quitarle la salida',
			16,
			1
			)				

	SET @IdCliente = (SELECT IdCliente FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido)	
	SET @IdUnidadCamion = (SELECT IdUnidadCamion FROM ProRecorridoParadas WHERE IdRecorridoParada = @IdRecorridoParada)

	/* SE ACTUALIZA EL RECORRIDO */
	UPDATE ProRecorridos SET
		IdEstatuViaje = @IdEstatuViaje,
		FechaHoraRecorridoEstatus = @FechaHoraEstatusViaje,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor		
	WHERE IdRecorrido = @IdRecorrido

	/* SE AGREGA EL ESTATUS AL RECORRIDO PARADA */
	INSERT INTO ProRecorridosEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatusViaje,IdRecorrido,IdRecorridoParada)
	VALUES(@ModificadoEl,@ModificadoPor,@FechaHoraEstatusViaje,@IdEstatuViaje,@IdRecorrido,@IdRecorridoParada)

	/* SE ACTUALIZA RECORRIDOS PARADAS */
	UPDATE ProRecorridoParadas SET
		Salida = NULL,
		Llegada = NULL,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdRecorridoParada = @IdRecorridoParada

	/* SE ACTUALIZA LA UNIDAD */
	IF @IdUnidadCamion IS NOT NULL
	BEGIN
		EXEC @return_value = usp_ProInventarioUnidadesActualizar @IdUnidadCamion,'',@IdEstatuUnidadCamion,@IdCliente,0,@IdUbicacion,@FechaHoraEstatusViaje,@ModificadoPor,@ModificadoEl,@IdPeticion,0,''

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al actualizar el inventario de equipo camión',
			16,
			1
			)
	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

