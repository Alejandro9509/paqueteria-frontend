CREATE PROCEDURE [dbo].[usp_CatReportesDefinidosPorClienteModificar]
/* *************************************************************************************************
Procedimiento usp_CatReportesDefinidosPorClienteModificar

Parámetros: Fueron agregados a los ya existentes los parametros necesarios para le ejecucion de reportes definidos por el cliente en le modulo portuario
            y para que los reportes se puedan ejecutar de forma automática en segundo plano. Todos los paarmetros son de entrada.

            @ModuloPortuario Bit.     Indica si el reporte es del modulo portuario            
            @EnviarCada int.          Indica la acntidad de horas a las que será enviada el reporte se quedo fija en 8 hrs              
            @EnviarEn   date.         Indica cuando se inicia el envio                
            @Frecuencia int.          Indica la frecuencia (1 Semanal, 2 mensual)              
            @FiltroFechas int.        Indica si las fechas a tomar en el filtro son por viaje (1) o son por Orden de entrega (2)              
            @FiltroMonedas int.       Indica si son (1 pesos, 2 Dolares o 3 Ambas)               
            @ReporteAutomatico Bit.   Indica si es reporte automático             
 

Descripción: 
07/11/2019   Adaptacion para reportes porturaios y la implementacion del centinela de realizacion y envio de reportes automaticos
03/12/2019   Se agregó un check box llamado Fijar Estatus. Solicitud: 578.             

Implementada por: No tengo idea
Fecha de implementacion: ??/??/????
Versión ERP: ????????

Modificada por:   Amado Navarro.
Fecha de mofidicacion: 11/06/2020
Versión ERP: 8.0.53.04
Se agrego el parametro @MostrarPor para generar el reporte en el modulo de portuarios por viaje.

Modificada por:   José Luis Cisneros G.
Fecha de mofidicacion: 07/11/2019
Versión ERP: 8.0.47.35

Modificada por:   Ricardo Sinai Miranda P.
Fecha de mofidicacion: 03/12/2019
Versión ERP: 8.0.48.11

Invocada desde: PAGE_CatReportesPortuariosDefinidosPorClienteAM
***************************************************************************************************** */
	@IdCatReportesDefinidosPorCliente int,	     --  1
	@Nombre Varchar(150),                        --  2
	@IdCliente int,                              --  3
	@CorreosDestinatarios varchar(8000),         --  4   
	@FiltroActivoClasificacionViaje bit,         --  5
	@FiltroActivoGrupoUnidades bit,              --  6
	@FiltroActivoTipoViaje Bit,                  --  7
    @ModuloPortuario Bit,                        --  8
    @EnviarCada int,                             --  9     
    @EnviarEn   date,                            -- 10
    @Frecuencia int,                             -- 11
    @FiltroFechas int,                           -- 12
    @FiltroMonedas int,                          -- 13
    @ReporteAutomatico Bit,                      -- 14
	@dsClasificacionesViajes ntext,              -- 15
	@dsEstatusViajes ntext,                      -- 16
	@dsGruposUnidades ntext,                     -- 17 
	@dsTiposViajes ntext,                        -- 18
	@dsDatosViaje ntext,	                     --	19
    @dsDatosOrdenContenedores ntext,             -- 20
	@ModificadoPor int,                          -- 21
	@ModificadoEl datetime,                      -- 22
	@UltimaModificacion datetime,		         -- 23
	@IdPeticion varchar(100),                    -- 24
	@FijarEstatus bit,                           -- 25
	@MostrarPor bit                              -- 26
AS
DECLARE
	@docHandle int,
	@ATT_IdClasificacionViaje int,
	@ATT_IdReporteDefinidoPorCliente_ClasificacionViaje int,
	@ATT_IdEstatusViaje int,
	@ATT_IdCatReportesDefinidosPorClientes_EstatusViaje int,
	@ATT_Orden tinyint,
	@ATT_IdDatoViaje int,
	@ATT_IdCatReportesDefinidosPorClienteDatosViaje int,
	@ATT_NombreEnTabla Varchar(8000),
	@ATT_Etiqueta Varchar(30),
	@ATT_EsFecha Bit,
	@ATT_IdTipoViaje int,
	@ATT_IdReporteDefinidoPorCliente_TiposViajes int,
	@ATT_IdGruposUnidades int,
	@ATT_IdReporteDefinidoPorCliente_GruposUnidades int
	
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdCatReportesDefinidosPorCliente  = 0
		RAISERROR(N'El identificador del reporte es un campo requerido', 16, 1)
			
	IF (SELECT ModificadoEl FROM CatReportesDefinidosPorCliente WHERE IdReporteDefinidoPorCliente = @IdCatReportesDefinidosPorCliente) <> @UltimaModificacion
		RAISERROR(N'Los datos de este reporte fueron modificados por otro usuario.', 16, 1)				

	IF LTrim(Rtrim(@Nombre)) = ''
		RAISERROR(N'El nombre es un campo requerido', 16, 1)	

						
	UPDATE CatReportesDefinidosPorCliente SET	
	Nombre = @Nombre,
	IdCliente =	@IdCliente,
	CorreosDestinatarios =@CorreosDestinatarios,
	FiltroActivoTipoViaje =@FiltroActivoTipoViaje,
	FiltroActivoClasificacionViaje =@FiltroActivoClasificacionViaje,
	FiltroActivoGrupoUnidades =@FiltroActivoGrupoUnidades,
    ModuloPortuario = @ModuloPortuario,            
    EnviarCada = @EnviarCada,     
    EnviarEn = @EnviarEn,
    Frecuencia = @Frecuencia,
    FiltroFechas = @FiltroFechas,     
    FiltroMonedas = @FiltroMonedas,       
    ReporteAutomatico = @ReporteAutomatico,   
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	FijarEstatus = @FijarEstatus,
	MostrarPor = @MostrarPor
	WHERE IdReporteDefinidoPorCliente = @IdCatReportesDefinidosPorCliente
		
	
	--SECCION PARA AGREGAR LOS CatClasificacionesViajes
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsClasificacionesViajes
	
	SELECT ATT_IdClasificacionViaje,ATT_IdReporteDefinidoPorCliente_ClasificacionViaje
	INTO #TempCatClasificacionesViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ClasificacionesViaje',2) 
	WITH (ATT_IdClasificacionViaje int,ATT_IdReporteDefinidoPorCliente_ClasificacionViaje int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatClasificacionesViajes CURSOR FOR
	SELECT * FROM #TempCatClasificacionesViajes
	
	OPEN CursorCatClasificacionesViajes
	FETCH NEXT FROM CursorCatClasificacionesViajes
	INTO @ATT_IdClasificacionViaje,@ATT_IdReporteDefinidoPorCliente_ClasificacionViaje
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdReporteDefinidoPorCliente_ClasificacionViaje = 0
		BEGIN
			INSERT INTO CatReportesDefinidosPorClienteClasificacionViajes(IdReporteDefinidoPorCliente,IdClasificacionViaje,CreadoEl,CreadoPor)
			VALUES(@IdCatReportesDefinidosPorCliente,@ATT_IdClasificacionViaje,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			UPDATE CatReportesDefinidosPorClienteClasificacionViajes
			SET ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdReporteDefinidoPorClienteClasificacionViaje = @ATT_IdReporteDefinidoPorCliente_ClasificacionViaje
		END		
		
		FETCH NEXT FROM CursorCatClasificacionesViajes
		INTO @ATT_IdClasificacionViaje,@ATT_IdReporteDefinidoPorCliente_ClasificacionViaje
	END

	CLOSE CursorCatClasificacionesViajes
	DEALLOCATE CursorCatClasificacionesViajes						
	
	DELETE FROM CatReportesDefinidosPorClienteClasificacionViajes WHERE IdReporteDefinidoPorCliente = @IdCatReportesDefinidosPorCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	--SECCION PARA AGREGAR LOS CatTiposViajes
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsTiposViajes
	
	SELECT ATT_IdTipoViaje,ATT_IdReporteDefinidoPorCliente_TiposViajes
	INTO #TempCatTiposViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_TiposViajes',2) 
	WITH (ATT_IdTipoViaje int,ATT_IdReporteDefinidoPorCliente_TiposViajes int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatTiposViajes CURSOR FOR
	SELECT * FROM #TempCatTiposViajes
	
	OPEN CursorCatTiposViajes
	FETCH NEXT FROM CursorCatTiposViajes
	INTO @ATT_IdTipoViaje,@ATT_IdReporteDefinidoPorCliente_TiposViajes
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdReporteDefinidoPorCliente_TiposViajes = 0
		BEGIN				
			INSERT INTO CatReportesDefinidosPorClienteTiposViajes(IdReporteDefinidoPorCliente,IdTipoViaje,CreadoEl,CreadoPor)
			VALUES(@IdCatReportesDefinidosPorCliente,@ATT_IdTipoViaje,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			UPDATE CatReportesDefinidosPorClienteTiposViajes
			SET ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdReporteDefinidoPorClienteTiposViajes = @ATT_IdReporteDefinidoPorCliente_TiposViajes
		END

		FETCH NEXT FROM CursorCatTiposViajes
		INTO @ATT_IdTipoViaje,@ATT_IdReporteDefinidoPorCliente_TiposViajes
	END

	CLOSE CursorCatTiposViajes
	DEALLOCATE CursorCatTiposViajes						
	
	DELETE FROM CatReportesDefinidosPorClienteTiposViajes WHERE IdReporteDefinidoPorCliente = @IdCatReportesDefinidosPorCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	--SECCION PARA AGREGAR LOS CatGrupoUnidades
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsGruposUnidades
	
	SELECT ATT_IdGrupo,ATT_IdReporteDefinidoPorCliente_GruposUnidades
	INTO #TempCatGruposUnidades
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_GruposUnidades',2) 
	WITH (ATT_IdGrupo int,ATT_IdReporteDefinidoPorCliente_GruposUnidades int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatGruposUnidades CURSOR FOR
	SELECT * FROM #TempCatGruposUnidades
	
	OPEN CursorCatGruposUnidades
	FETCH NEXT FROM CursorCatGruposUnidades
	INTO @ATT_IdGruposUnidades,@ATT_IdReporteDefinidoPorCliente_GruposUnidades
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdReporteDefinidoPorCliente_GruposUnidades = 0
		BEGIN				
			INSERT INTO CatReportesDefinidosPorClienteGruposUnidades(IdReporteDefinidoPorCliente,IdGrupoUnidad,CreadoEl,CreadoPor)
			VALUES(@IdCatReportesDefinidosPorCliente,@ATT_IdGruposUnidades,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			UPDATE CatReportesDefinidosPorClienteGruposUnidades
			SET ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdReporteDefinidoPorClienteGruposUnidades = @ATT_IdReporteDefinidoPorCliente_GruposUnidades
		END

		FETCH NEXT FROM CursorCatGruposUnidades
		INTO @ATT_IdGruposUnidades,@ATT_IdReporteDefinidoPorCliente_GruposUnidades 
	END

	CLOSE CursorCatGruposUnidades
	DEALLOCATE CursorCatGruposUnidades						
		
	DELETE FROM CatReportesDefinidosPorClienteGruposUnidades WHERE IdReporteDefinidoPorCliente = @IdCatReportesDefinidosPorCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	--SECCION PARA AGREGAR LOS CatEstatusViaje
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsEstatusViajes
	
	SELECT ATT_IdEstatusViaje,ATT_Orden,ATT_IdCatReportesDefinidosPorClientes_EstatusViaje
	INTO #TempCatEstatusViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_EstatusViaje',2) 
	WITH (ATT_IdEstatusViaje int,ATT_Orden tinyint,ATT_IdCatReportesDefinidosPorClientes_EstatusViaje int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatEstatusViajes CURSOR FOR
	SELECT * FROM #TempCatEstatusViajes
	
	OPEN CursorCatEstatusViajes
	FETCH NEXT FROM CursorCatEstatusViajes
	INTO @ATT_IdEstatusViaje,@ATT_Orden,@ATT_IdCatReportesDefinidosPorClientes_EstatusViaje
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdCatReportesDefinidosPorClientes_EstatusViaje = 0
		BEGIN
			INSERT INTO CatReportesDefinidosPorClienteEstatusViajes(IdReporteDefinidoPorCliente,IdEstatusViaje,Orden,CreadoEl,CreadoPor)
			VALUES(@IdCatReportesDefinidosPorCliente,@ATT_IdEstatusViaje,@ATT_Orden,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			UPDATE CatReportesDefinidosPorClienteEstatusViajes
			SET Orden = @ATT_Orden,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor			 
			WHERE IdCatReportesDefinidosPorClientesEstatusViaje = @ATT_IdCatReportesDefinidosPorClientes_EstatusViaje
		END
		FETCH NEXT FROM CursorCatEstatusViajes
		INTO @ATT_IdEstatusViaje,@ATT_Orden,@ATT_IdCatReportesDefinidosPorClientes_EstatusViaje
	END

	CLOSE CursorCatEstatusViajes
	DEALLOCATE CursorCatEstatusViajes
	
	DELETE FROM CatReportesDefinidosPorClienteEstatusViajes WHERE IdReporteDefinidoPorCliente = @IdCatReportesDefinidosPorCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	--SECCION PARA AGREGAR LOS CatDatosViaje
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsDatosViaje
	
	SELECT ATT_IdDatoViaje,ATT_Orden,ATT_IdCatReportesDefinidosPorClienteDatosViaje,ATT_NombreEnTabla,ATT_Etiqueta,ATT_EsFecha
	INTO #TempCatDatosViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_DatosViajes',2) 
	WITH (ATT_IdDatoViaje int,ATT_Orden tinyint,ATT_IdCatReportesDefinidosPorClienteDatosViaje int,ATT_NombreEnTabla Varchar(8000),ATT_Etiqueta varchar(30),ATT_EsFecha bit)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatDatosViajes CURSOR FOR
	SELECT * FROM #TempCatDatosViajes
	
	OPEN CursorCatDatosViajes
	FETCH NEXT FROM CursorCatDatosViajes
	INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_IdCatReportesDefinidosPorClienteDatosViaje,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdCatReportesDefinidosPorClienteDatosViaje = 0
		BEGIN
			INSERT INTO CatReportesDefinidosPorClienteDatosViajes(IdCatReportesDefinidosPorCliente,IdDatoViaje,Orden,CreadoEl,CreadoPor,NombreEnTabla,Etiqueta,EsFecha)
			VALUES(@IdCatReportesDefinidosPorCliente,@ATT_IdDatoViaje,@ATT_Orden,@ModificadoEl,@ModificadoPor,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha)		
		END
		ELSE
		BEGIN
			Update CatReportesDefinidosPorClienteDatosViajes
			SET Orden = @ATT_Orden,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor,
				NombreEnTabla =@ATT_NombreEnTabla,
				Etiqueta =@ATT_Etiqueta,
				EsFecha = @ATT_EsFecha
			WHERE IdCatReportesDefinidosPorClienteDatosViaje = @ATT_IdCatReportesDefinidosPorClienteDatosViaje
		END
		FETCH NEXT FROM CursorCatDatosViajes
		INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_IdCatReportesDefinidosPorClienteDatosViaje,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	END

	CLOSE CursorCatDatosViajes
	DEALLOCATE CursorCatDatosViajes
	
	DELETE FROM CatReportesDefinidosPorClienteDatosViajes WHERE IdCatReportesDefinidosPorCliente = @IdCatReportesDefinidosPorCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
    ---- Agregado en solictud 246 el 23/10/2019 adaptando para modulo portuario se agregan los datos del tablero de contenedores
	--SECCION PARA AGREGAR LOS CatDatosViaje
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsDatosOrdenContenedores
	
	SELECT ATT_IdDatoViaje,ATT_Orden,ATT_IdCatReportesDefinidosPorClienteDatosViaje,ATT_NombreEnTabla,ATT_Etiqueta,ATT_EsFecha
	INTO #TempCatDatosOrdenContenedores
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_DatosOrdenContenedores',2) 
	WITH (ATT_IdDatoViaje int,ATT_Orden tinyint,ATT_IdCatReportesDefinidosPorClienteDatosViaje int,ATT_NombreEnTabla Varchar(8000),ATT_Etiqueta varchar(30),ATT_EsFecha bit)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatDatosOrdenContenedores CURSOR FOR
	SELECT * FROM #TempCatDatosOrdenContenedores
	
	OPEN CursorCatDatosOrdenContenedores
	FETCH NEXT FROM CursorCatDatosOrdenContenedores
	INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_IdCatReportesDefinidosPorClienteDatosViaje,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdCatReportesDefinidosPorClienteDatosViaje = 0
		BEGIN
			INSERT INTO CatReportesDefinidosPorClienteOrdenEntrega(IdCatReportesDefinidosPorCliente,IdDatoOrden,Orden,CreadoEl,CreadoPor,NombreEnTabla,Etiqueta,EsFecha)
			VALUES(@IdCatReportesDefinidosPorCliente,@ATT_IdDatoViaje,@ATT_Orden,@ModificadoEl,@ModificadoPor,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha)		
		END
		ELSE
		BEGIN
			UPDATE CatReportesDefinidosPorClienteOrdenEntrega
			SET Orden = @ATT_Orden,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor,
				NombreEnTabla =@ATT_NombreEnTabla,
				Etiqueta =@ATT_Etiqueta,
				EsFecha = @ATT_EsFecha
            WHERE IdCatReportesDefinidosPorClienteOrdenEntrega = @ATT_IdCatReportesDefinidosPorClienteDatosViaje
		END
		FETCH NEXT FROM CursorCatDatosOrdenContenedores
		INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_IdCatReportesDefinidosPorClienteDatosViaje,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	END

	CLOSE CursorCatDatosOrdenContenedores
	DEALLOCATE CursorCatDatosOrdenContenedores
	
	DELETE FROM CatReportesDefinidosPorClienteOrdenEntrega WHERE IdCatReportesDefinidosPorCliente = @IdCatReportesDefinidosPorCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	


    ----
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

