
CREATE PROCEDURE [dbo].[usp_ProViajeSalidaEliminarPQ](
	@IdViajeSalida int
	)
AS

BEGIN
	BEGIN TRANSACTION
		declare @ExisteSalida int;

		IF ISNULL(@IdViajeSalida, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador de salida del viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		delete ProViajeSalidaPQ
		where IdViajeSalida = @IdViajeSalida;


		IF @@TRANCOUNT > 0			
					COMMIT TRANSACTION
		else
		BEGIN
			
			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END

end
go

