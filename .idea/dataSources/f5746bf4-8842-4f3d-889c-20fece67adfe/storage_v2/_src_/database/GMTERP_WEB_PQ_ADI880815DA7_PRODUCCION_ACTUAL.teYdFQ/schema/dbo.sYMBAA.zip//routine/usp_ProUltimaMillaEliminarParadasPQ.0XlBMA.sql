

CREATE PROCEDURE [dbo].[usp_ProUltimaMillaEliminarParadasPQ]
	@IdParada int
AS

BEGIN TRY

	BEGIN TRANSACTION
	IF ISNULL(@IdParada,0) <= 0
		RAISERROR(N'El identificador es un campo requerido',
			16,
			1
			)	
							
	IF NOT EXISTS(SELECT @IdParada FROM ParadaUltimaMillaPQ WHERE m_nIdProParadaUltimaMilla = @IdParada)
		RAISERROR(N'El registro ya fue eliminado por otro usuario',
			16,
			1
			)
			

			UPDATE ProRecoleccionPQ SET IdEstatusRecoleccion = (case when IdEstatusRecoleccion = 3 then 1 else IdEstatusRecoleccion end), IdEstatusUltimaMilla = (case when IdEstatusUltimaMilla = 2 then 1 else IdEstatusUltimaMilla end) where IdRecoleccion IN (select m_nIdGuia from ProParadaUltimaMillaGuiasPQ where  EsRecoleccion = 1 )
			
			UPDATE ProGuiaPQ SET IdEstatusGuia =  (case when IdEstatusGuia = 17  then 11 else IdEstatusGuia end), IdEstatusUltimaMilla = (case when IdEstatusUltimaMilla = 2 then 1 else IdEstatusUltimaMilla end) where IdGuia IN (select m_nIdGuia from ProParadaUltimaMillaGuiasPQ where  EsRecoleccion = 0 )

			DELETE FROM ProParadaUltimaMillaGuiasPQ WHERE m_nIdParadaUltimaMilla = @IdParada
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdParada
END CATCH
go

