CREATE PROCEDURE [dbo].[usp_ProLiquidacionesTPersonalRegistrarPago]
@IdLiquidacion int,
@Fecha datetime,
@IdCuentaBancaria int,
@TipodeMovimiento int,
@NumeroMovimiento int,
@NumeroCheque int ,
@IdOperador int,
@TipoCambio money,
@NetoAPagar money,
@IdBancoOperador int,
@NumeroCuentaBancariaOperador varchar(21),
@ReferenciaPago varchar(150),
@CodigoEstatuCheque int,
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100),
@IdCertificado int,
@XMLLiquidaciones text,
@FechaDeCobro datetime
AS
Declare @IdCheque int,
		@Concepto varchar(150),
		@Beneficiario varchar(150),
		@IdMovimientoBancario  int,
		@IdTipoMovimientoBancario int,
		@IdEstatuCheque int,
		@NumeroBeneficiario int,
		@IdBeneficiario int,
		@NroCuentaPago varchar(50),
		@MetodoPago varchar(50),
		@FolioLiquidacion varchar(150),
		@ClaveMetodoPago varchar(5),
		@ATT_IdLiquidacion int,
		@ATT_Folio varchar(150),
		@docHandle int,
		@Contador int = 1,
		@Mensaje varchar(150)
		
BEGIN TRY
	BEGIN TRANSACTION
	SET @IdCheque = Null
	
	
	IF @XMLLiquidaciones IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLLiquidaciones
             
			SELECT ATT_IdLiquidacion, ATT_Folio
			INTO #TempLiquidaciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Liquidaciones',3) 
			WITH (ATT_IdLiquidacion int, ATT_Folio varchar(150))

			EXEC sp_xml_removedocument @docHandle
			DECLARE LiquidacionesPagarCursor CURSOR FOR
			SELECT * FROM #TempLiquidaciones

			OPEN LiquidacionesPagarCursor
			FETCH NEXT FROM LiquidacionesPagarCursor
			INTO @ATT_IdLiquidacion, @ATT_Folio
		
			WHILE @@FETCH_STATUS = 0
			BEGIN
			
			-----validaciones
				IF ISDATE((Select AutorizadaEl From ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @ATT_IdLiquidacion)) = 0
				begin
					set @Mensaje = 'La liquidación '+@ATT_Folio+' no esta autorizada para registrar pago'
					RAISERROR(@Mensaje,
						16,
						1)
				end	
				IF  ISNULL((Select IdMovimientoBancario  from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion),0) > 0 OR ISDATE((Select PagadoEl  from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion)) <> 0 
				begin
					set @Mensaje = 'La liquidación '+@ATT_Folio+' ya fue pagada por otro usuario'
					RAISERROR(@Mensaje,
						16,
						1)
				end

			FETCH NEXT FROM LiquidacionesPagarCursor
				INTO @ATT_IdLiquidacion, @ATT_Folio
			END

			CLOSE LiquidacionesPagarCursor
			DEALLOCATE LiquidacionesPagarCursor
			
		END
	ELSE --SOLO UN REGISTRO
	BEGIN
		IF ISDATE((Select AutorizadaEl From ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion)) = 0
		RAISERROR(N'Liquidación no esta autorizada para registrar pago',
			16,
			1
			)	
    
		IF  ISNULL((Select IdMovimientoBancario  from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion),0) > 0 OR ISDATE((Select PagadoEl  from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion)) <> 0 
			RAISERROR(N'La liquidación ya fue pagada por otro usuario',
				16,
				1
				)	    
		
		IF ISNULL(@IdLiquidacion,0) <= 0
			RAISERROR(N'El identificador de liquidación es un campo requerido',
				16,
				1
				)
	END
	
	IF ISDATE(@Fecha) = 0
		RAISERROR(N'Fecha es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@IdOperador,0) <= 0
			RAISERROR(N'El identificador de operador es un campo requerido',
			16,
			1
			)	
			
	IF ISNULL(@IdCuentaBancaria,0) <= 0
		RAISERROR(N'El identificador de cuenta bancaria es un campo requerido',
			16,
			1
			)	
	
	IF ISNULL(@TipodeMovimiento,0) <= 0
		RAISERROR(N'Tipo de movimiento es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@TipoCambio,0)= 0
		RAISERROR(N'Tipo de cambio es un campo requerido',
			16,
			1
			)
			
	
	--SE PIDIO 2812 QUE YA NO SEA OBLIGATORIO
	--IF ISNULL(@NumeroCuentaBancariaOperador ,'') = ''
	--		RAISERROR(N'No cuenta bancaria del operador es un campo requerido',
	--		16,
	--		1
	--		)	
						
	--- Registrar Beneficiario 
		Select  @Beneficiario = Nombre  from CatOperadores where IdOperador = @IdOperador
		Select @IdBeneficiario = (Select IdBeneficiario  from CatBeneficiarios where RTRIM(LTRIM(Nombre)) = RTRIM(LTRIM(@Beneficiario)))
		IF  ISNULL(@IdBeneficiario ,0) = 0 
			BEGIN
			    SELECT @NumeroBeneficiario = (SELECT ISNULL(MAX(NumeroBeneficiario),0)+1 AS Codigo FROM CatBeneficiarios)
				INSERT INTO CatBeneficiarios(NumeroBeneficiario,Nombre,CreadoEl,CreadoPor,Activo)
					   VALUES(@NumeroBeneficiario,RTRIM(LTRIM(@Beneficiario)),@CreadoEl,@CreadoPor,1)
				SET @IdBeneficiario = (SELECT IDENT_CURRENT('CatBeneficiarios'))	   
			END
									
    --- Generar cheque
    IF @TipodeMovimiento = 1 --- CHEQUE 
	BEGIN
		
		Select @IdTipoMovimientoBancario = 2 -- Cheque
		Select @IdEstatuCheque = IdEstatuCheque From CatEstatusCheques where Codigo = @CodigoEstatuCheque 
		--  Folio Liquidación
		IF @XMLLiquidaciones IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLLiquidaciones

			SELECT ATT_IdLiquidacion, ATT_Folio
			INTO #TempLiquidaciones3
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Liquidaciones',3) 
			WITH (ATT_IdLiquidacion int, ATT_Folio varchar)

			EXEC sp_xml_removedocument @docHandle
			DECLARE LiquidacionesPagarCursor3 CURSOR FOR
			SELECT * FROM #TempLiquidaciones3

			OPEN LiquidacionesPagarCursor3
			FETCH NEXT FROM LiquidacionesPagarCursor3
			INTO @ATT_IdLiquidacion, @ATT_Folio
		
			WHILE @@FETCH_STATUS = 0
			BEGIN
				
			    if @FolioLiquidacion is null 
			    begin
					if @Contador = 1
					begin
						set @FolioLiquidacion = ( Select cast(Folio as varchar) From ProLiquidacionesTPersonal Where IdLiquidacionTPersonal = @ATT_IdLiquidacion )
					end
				end
				else
				begin
			
					if @Contador <= 10
					begin
						set @FolioLiquidacion += ( Select ','+cast(Folio as varchar) From ProLiquidacionesTPersonal Where IdLiquidacionTPersonal = @ATT_IdLiquidacion )
					end
				end
				set @Contador += 1
				
			FETCH NEXT FROM LiquidacionesPagarCursor3
				INTO @ATT_IdLiquidacion, @ATT_Folio
			END

			CLOSE LiquidacionesPagarCursor3
			DEALLOCATE LiquidacionesPagarCursor3
			
		END
		ELSE --SOLO UN REGISTRO
		BEGIN
			Select @FolioLiquidacion = Folio From ProLiquidacionesTPersonal Where IdLiquidacionTPersonal = @IdLiquidacion
		END
		
		
		IF ISNULL(@NumeroCheque,0) = 0
			RAISERROR(N'Número de cheque es un campo requerido',
			16,
			1
			)


		-- valida que el número de cheque no este usado
		IF EXISTS(Select NumeroCheque from ProCheques where NumeroCheque  = @NumeroCheque AND IdCuentaBancaria = @IdCuentaBancaria)
					RAISERROR(N'El Número de cheque ya fue utilizado por otro usuario, se le asignará el siguiente número de cheque disponible, revise la información y vuelva hacer click en aceptar',					
						16,
						1
						)
					

		--- Registrar cheque		
		Set @Concepto = 'LIQ: '+CONVERT(VARCHAR(150),@FolioLiquidacion)+' '+@Beneficiario
		INSERT INTO ProCheques (NumeroCheque,Fecha,IdCuentaBancaria,TipoCambio,Concepto,Beneficiario,Importe,IdEstatuCheque,TipoBeneficiario,IdBeneficiario,FechaCobro,CreadoPor,CreadoEl)
		VALUES(@NumeroCheque,@Fecha,@IdCuentaBancaria,@TipoCambio,@Concepto,RTRIM(LTRIM(@Beneficiario)),@NetoAPagar,@IdEstatuCheque,2,@IdBeneficiario,@Fecha,@CreadoPor,@CreadoEl)
		--- Registrar Movimiento Bancario
		SET @IdCheque= (SELECT IDENT_CURRENT('ProCheques'))
		
		SET @MetodoPago = 'CHEQUE NOMINATIVO'
		SET @ClaveMetodoPago = '02'
		SET @NumeroMovimiento =(Select ISNULL(MAX(NumeroMovimiento),0)+1 AS NumeroMovimiento from ProMovimientosBancarios where IdCuentaBancaria = @IdCuentaBancaria)
	END
	ELSE
	BEGIN -- TRANSFERENCIA
	
		print N' trans';
		SET @MetodoPago = 'TRANSFERENCIA ELECTRÓNICA DE FONDOS'	
		Select @IdTipoMovimientoBancario = 3 -- Retiro por transferencia
		SET @ClaveMetodoPago = '03'
			IF ISNULL(@NumeroMovimiento,0) = 0
			RAISERROR(N'Número de movimiento bancario es un campo requerido',
			16,
			1
			)

			-- valida que el número de mov. bancario no este usado
		IF EXISTS(Select NumeroMovimiento from ProMovimientosBancarios where NumeroMovimiento = @NumeroMovimiento AND IdCuentaBancaria = @IdCuentaBancaria)
					RAISERROR(N'El Número de movimiento bancario ya fue utilizado por otro usuario, se le asignará el siguiente número de movimiento bancario disponible, revise la información y vuelva hacer click en aceptar',					
						16,
						1
						)
		-- si el importe a pagar es negativo poner cero
		IF @NetoAPagar < 0
			SET @NetoAPagar = 0
	END
	
	--- Registrar Movimiento Bancario 

		INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,TipoCambio,ReferenciaBancaria,IdTipoMovimientoBancario,CreadoPor,CreadoEl,IdCheque,TipoBeneficiario,IdBeneficiario,Beneficiario,FechaCobro)
		VALUES (@NumeroMovimiento,@Fecha,@IdCuentaBancaria,@NetoAPagar,@TipoCambio, @ReferenciaPago+' -CTA:'+@NumeroCuentaBancariaOperador,@IdTipoMovimientoBancario,@CreadoPor,@CreadoEl,@IdCheque,2,@IdBeneficiario,RTRIM(LTRIM(@Beneficiario)),@FechaDeCobro)
		
		SET @IdMovimientoBancario = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))
		--- Registrar número de movimiento bancario en anticipo 	
		IF @IdCertificado = 0
			SET @IdCertificado = NULL	
		
		SET @NroCuentaPago = (SELECT NumeroCuenta FROM CatCuentasBancarias WHERE IdCuentaBancaria = @IdCuentaBancaria)		   
		
		
		IF @XMLLiquidaciones IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLLiquidaciones

			SELECT ATT_IdLiquidacion, ATT_Folio
			INTO #TempLiquidaciones2
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Liquidaciones',3) 
			WITH (ATT_IdLiquidacion int, ATT_Folio varchar)

			EXEC sp_xml_removedocument @docHandle
			DECLARE LiquidacionesPagarCursor CURSOR FOR
			SELECT * FROM #TempLiquidaciones2

			OPEN LiquidacionesPagarCursor
			FETCH NEXT FROM LiquidacionesPagarCursor
			INTO @ATT_IdLiquidacion, @ATT_Folio
		
			WHILE @@FETCH_STATUS = 0
			BEGIN
			
			UPDATE ProLiquidacionesTPersonal SET
			   IdMovimientoBancario =  	@IdMovimientoBancario,
			   IdBancoOperador = @IdBancoOperador, 
			   NumeroCuentaBancariaOperador =@NumeroCuentaBancariaOperador,
			   IdCertificado = @IdCertificado,
			   MetodoPago = @MetodoPago,
			   NroCuentaPago = @NroCuentaPago,
			   ClaveMetodoPago = @ClaveMetodoPago
		   WHERE  IdLiquidacionTPersonal =  @ATT_IdLiquidacion
		   
		   
			
			FETCH NEXT FROM LiquidacionesPagarCursor
				INTO @ATT_IdLiquidacion, @ATT_Folio
			END

			CLOSE LiquidacionesPagarCursor
			DEALLOCATE LiquidacionesPagarCursor
			
		END
	ELSE --SOLO UN REGISTRO
	BEGIN
		UPDATE ProLiquidacionesTPersonal SET
			   IdMovimientoBancario =  	@IdMovimientoBancario,
			   IdBancoOperador = @IdBancoOperador, 
			   NumeroCuentaBancariaOperador =@NumeroCuentaBancariaOperador,
			   IdCertificado = @IdCertificado,
			   MetodoPago = @MetodoPago,
			   NroCuentaPago = @NroCuentaPago,
			   ClaveMetodoPago = @ClaveMetodoPago
		WHERE  IdLiquidacionTPersonal =  @IdLiquidacion
	END
		


	
    --seccion para agregar el idmovimientobancario a paremtros y poder obtenerlo de lado del web
    IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancario' AND IdUsuario = @CreadoPor)
    INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoBancario',@IdMovimientoBancario,@CreadoPor)
    ELSE
    UPDATE SisParametrosPagina SET Parametros = @IdMovimientoBancario WHERE Pagina = 'IdMovimientoBancario' AND IdUsuario = @CreadoPor
	
	Delete from ProLiquidacionesCancelacionCFDI Where IdLiquidacion = @IdLiquidacion -- se elimina la Cancelacion 

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

