
CREATE PROCEDURE [dbo].[usp_SisAtajoEliminarPQ](
	@IdUsuario INT
	)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@IdUsuario, '') = '' begin			
			RAISERROR(N'*INICIO*El identificador del Usuario es un campo requerido*FIN*', 16, 1);
			return
		end;

		DELETE FROM SisAtajosPQ WHERE IdUsuario = @IdUsuario


	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

