CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosGrabarEstatusImpresoEnviadoCliente]
	@IdMovimientoBancario int,
	@IdFormatoImpresion int,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@IdPeticion varchar(100),
	@FechaDeEnvio datetime
AS
	
BEGIN TRY		
	BEGIN TRANSACTION	
	Declare 
		@HayError bit
	If @FechaDeEnvio is null
	begin
		UPDATE ProMovimientosBancarios
		SET EstatusImpresoEnviadoCliente = 1,
		IdFormatoImpresion = @IdFormatoImpresion,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
		WHERE IdMovimientoBancario = @IdMovimientoBancario
	end
	else
	Begin
			UPDATE ProMovimientosBancarios
			SET FechaDeEnvio = @FechaDeEnvio,
			EstatusImpresoEnviadoCliente = 1,
			IdFormatoImpresion = @IdFormatoImpresion,		
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor
			WHERE IdMovimientoBancario = @IdMovimientoBancario
	end

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

