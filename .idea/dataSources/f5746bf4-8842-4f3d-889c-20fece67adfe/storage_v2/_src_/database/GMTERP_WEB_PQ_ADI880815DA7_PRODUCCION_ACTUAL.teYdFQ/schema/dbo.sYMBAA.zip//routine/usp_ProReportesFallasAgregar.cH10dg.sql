CREATE PROCEDURE [dbo].[usp_ProReportesFallasAgregar]
@Folio int, 
@Fecha datetime,
@IdUnidad int,
@IdOperador int,
@DescripcionFalla Text,
@IdSucursal int,
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100),
@IdClasificacionServicio int,
@dsProReportesFallasImagenes ntext,
@Codigo nvarchar(50),
@Movil bit
AS
DECLARE 
@docHandle int,
@IdReporteFalla int 
BEGIN TRY
	BEGIN TRANSACTION
IF ISNULL(@Folio,0)= 0
		RAISERROR(N'El folio de reporte de falla es un campo requerido',
			16,
			1
			)
			
IF EXISTS(SELECT TOP 1 Folio FROM ProReportesFallas WHERE ProReportesFallas.Folio = @Folio) 
        RAISERROR(N'EL folio de Reporte de Falla, ya existe',
           16,
            1
            )
			
IF ISNULL(@IdUnidad,0)= 0
		RAISERROR(N'Identificador de unidad es un campo requerido',
			16,
			1
			)

IF ISNULL(@IdOperador,0)= 0
	SET @IdOperador = NULL

IF ISNULL(@IdClasificacionServicio,0) =0
	SET @IdClasificacionServicio = NULL

	INSERT INTO ProReportesFallas(Folio,Fecha,IdUnidad,IdOperador,DescripcionFalla,IdSucursal,CreadoEl,CreadoPor,IdClasificacionServicio,Codigo,Movil)
	VALUES(@Folio,@Fecha,@IdUnidad,@IdOperador,@DescripcionFalla,@IdSucursal,@CreadoEl,@CreadoPor,@IdClasificacionServicio,@Codigo,@Movil)
	
	SET @IdReporteFalla = (SELECT IDENT_CURRENT('ProReportesFallas'))

	--Seccion para agregar el IdReporteFalla a parametros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdReporteFalla' AND IdUsuario = @CreadoPor)
	INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdReporteFalla',@IdReporteFalla,@CreadoPor)
	ELSE
	UPDATE SisParametrosPagina SET Parametros = @IdReporteFalla WHERE Pagina = 'IdReporteFalla' AND IdUsuario = @CreadoPor

	--AGREGAMOS IMAGENES A ProReportesFallasImagenes
	IF @dsProReportesFallasImagenes IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProReportesFallasImagenes
		
		SELECT ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes
		INTO #TempProReportesFallasImagenes
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProReportesFallasImagenes',2) 
		WITH (ATT_Imagen ntext,ATT_ImagenNombreArchivo varchar(150),ATT_Descripcion varchar(50),ATT_PesoBytes int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProReportesFallasImagenes(CreadoEl,CreadoPor,IdReporteFalla,Imagen,ImagenNombreArchivo,Descripcion,PesoBytes)
		SELECT @CreadoEl,@CreadoPor,@IdReporteFalla,ATT_Imagen,ATT_ImagenNombreArchivo,ATT_Descripcion,ATT_PesoBytes 
		FROM #TempProReportesFallasImagenes
	END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

