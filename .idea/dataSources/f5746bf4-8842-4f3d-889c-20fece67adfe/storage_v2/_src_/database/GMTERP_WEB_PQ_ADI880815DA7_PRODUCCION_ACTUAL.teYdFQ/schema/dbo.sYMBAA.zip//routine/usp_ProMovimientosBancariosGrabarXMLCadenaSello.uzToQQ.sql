
CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosGrabarXMLCadenaSello]
	@IdMovimientoBancario int,
	@XMLArchivoPagos ntext,
	@CadenaOriginal ntext,
	@SelloDigital ntext,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

	UPDATE ProMovimientosBancarios
	SET SelloDigital = @SelloDigital,
		CadenaOriginal = @CadenaOriginal,
		XMLArchivoPagos = @XMLArchivoPagos		
	WHERE IdMovimientoBancario = @IdMovimientoBancario

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

