CREATE PROCEDURE [dbo].[usp_ProLlantasModificar]
@IdLlanta int,
@NumeroEconomico varchar(20),
@IdModeloLlanta int,
@IdMarcaLlanta int,
@IdMedidaLlanta int,
@IdTipoLlanta int,
@ProfundidadOriginal decimal (10, 2),
@ProfundidadMinima  decimal (10, 2),
@PresionMaxima  decimal (10, 2),
@PresionMinima  decimal (10, 2),
@ProfundidadActual  decimal (10, 2),
@PresionActual  decimal (10, 2),
@IdEstatuLlanta int,
@DisponibleDesde datetime,
@UltimaModificacion datetime,
@ModificadoPor int,
@ModificadoEl datetime,
@IdPeticion varchar(100),
@CostoLlanta money,
@VidaUtil int,
@CostoLlantaDlls money,
@TipoCambio money
AS
DECLARE	
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdLlanta= 0
		RAISERROR(N'El identificador del llanta es un campo requerido',
			16,
			1
			)

	IF NOT EXISTS(SELECT IdLlanta FROM ProLlantas WHERE IdLlanta = @IdLlanta)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)				
	
	IF (SELECT ModificadoEl FROM ProLlantas  WHERE IdLlanta = @IdLlanta) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta llanta fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)	
				
	IF isnull(@NumeroEconomico,'') = ''
		RAISERROR(N'El numero económico de la llanta es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT NumeroEconomico  FROM ProLlantas WHERE NumeroEconomico  = @NumeroEconomico  AND IdLlanta<> @IdLlanta)
		RAISERROR(N'El numero económico de la llanta ya existe',
			16,
			1
			)
			
	IF isnull(@IdModeloLlanta,0) = 0 
		RAISERROR(N'Identificador de modelo es un campo requerido',
			16,
			1
			)	
	
	IF isnull(@IdMarcaLlanta,0) = 0 
		RAISERROR(N'Identificador de marca es un campo requerido',
			16,
			1
			)

	IF isnull(@IdMedidaLlanta,0) = 0 
		RAISERROR(N'Identificador de medida es un campo requerido',
			16,
			1
			)
			
	-- valida no guardar pendiente de etiquetar
	IF (SELECT ISNULL(PendienteEtiqueta,0)  FROM ProLlantas WHERE  IdLlanta = @IdLlanta) = 1
			BEGIN 
				IF LEFT(@NumeroEconomico,4)='PEND'
						  RAISERROR(N'Llanta pendiente de etiquetar no es posible modificar',
							16,
							1
							) 
				
			END
								
	UPDATE ProLlantas 
		SET	 NumeroEconomico = @NumeroEconomico,
			IdModeloLlanta = @IdModeloLlanta,
			IdMarcaLlanta = @IdMarcaLlanta,
			IdMedidaLlanta = @IdMedidaLlanta,
			IdTipoLlanta = @IdTipoLlanta,
			ProfundidadOriginal = @ProfundidadOriginal,
			ProfundidadMinima = @ProfundidadMinima ,
			PresionMaxima = @PresionMaxima,
			PresionMinima = @PresionMinima,
			ProfundidadActual = @ProfundidadActual,
			PresionActual = @PresionActual,
			IdEstatuLlanta = @IdEstatuLlanta,
			DisponibleDesde = @DisponibleDesde,
			ModificadoPor = @ModificadoPor,
			ModificadoEl = @ModificadoEl,
			CostoLlanta=@CostoLlanta,
			VidaUtil=@VidaUtil,
			PendienteEtiqueta = 0,
			CostoLlantaDlls=@CostoLlantaDlls,
			TipoCambio = @TipoCambio
	WHERE IdLlanta = @IdLlanta
	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

