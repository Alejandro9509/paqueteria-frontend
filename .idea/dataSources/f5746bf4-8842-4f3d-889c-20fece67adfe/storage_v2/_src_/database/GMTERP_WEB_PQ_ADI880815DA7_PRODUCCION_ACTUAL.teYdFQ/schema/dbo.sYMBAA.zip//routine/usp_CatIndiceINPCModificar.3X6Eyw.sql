
CREATE PROCEDURE [dbo].[usp_CatIndiceINPCModificar]
	@IdIndiceINPC INT,
	@Enero DECIMAL(10,6),
	@Febrero DECIMAL(10,6),
	@Marzo DECIMAL(10,6),
	@Abril DECIMAL(10,6),
	@Mayo DECIMAL(10,6),
	@Junio DECIMAL(10,6),
	@Julio DECIMAL(10,6),
	@Agosto DECIMAL(10,6),
	@Septiembre DECIMAL(10,6),
	@Octubre DECIMAL(10,6),
	@Noviembre DECIMAL(10,6),
	@Diciembre DECIMAL(10,6),
	@ModificadoEl DATETIME,
	@ModificadoPor INT,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Procedimiento usp_CatIndiceINPCModificar

Parámetros: 
	@IdIndiceINPC		(entrada, entero). Id del Indice INPC
	@Enero				(entrada, decimal). Valor del ejercicio del mes de Enero
	@Febrero			(entrada, decimal). Valor del ejercicio del mes de Febrero
	@Marzo				(entrada, decimal). Valor del ejercicio del mes de Marzo
	@Abril				(entrada, decimal). Valor del ejercicio del mes de Abril
	@Mayo				(entrada, decimal). Valor del ejercicio del mes de Mayo
	@Junio				(entrada, decimal). Valor del ejercicio del mes de Junio
	@Julio				(entrada, decimal). Valor del ejercicio del mes de Julio
	@Agosto				(entrada, decimal). Valor del ejercicio del mes de Agosto
	@Septiembre			(entrada, decimal). Valor del ejercicio del mes de Septiembre
	@Octubre			(entrada, decimal). Valor del ejercicio del mes de Octubre
	@Noviembre			(entrada, decimal). Valor del ejercicio del mes de Noviembre
	@Diciembre			(entrada, decimal). Valor del ejercicio del mes de Diciembre
	@ModificadoEl		(entrada, fecha hora). Fecha y hora de modificacion
	@ModificadoPor		(entrada, entero). Usuario que modifica el indice INPC
	@IdPeticion			(entrada, string). Id de la Petición, generada en WEBDEV 		
 
Descripción: Procedimiento para modificar el Indice INPC

Implementada por: Jesús Humberto Morales
Fecha de implementacion: 10/12/2019
Versión ERP: 8.0.48.22

Modificada por:   XXXXX
Fecha de mofidicacion: XXXXX
Versión ERP: XXXXX

Invocada desde: PAGE_CatIndiceINPCAM (Solicitud 648)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF ISNULL(@IdIndiceINPC,0) <= 0 
			RAISERROR(N'Identificador del índice INPC es un campo requerido', 16, 1)
	
		UPDATE CatIndiceINPC SET
		Enero = @Enero, 
		Febrero = @Febrero, 
		Marzo = @Marzo, 
		Abril = @Abril, 
		Mayo = @Mayo, 
		Junio = @Junio, 
		Julio = @Julio, 
		Agosto = @Agosto, 
		Septiembre = @Septiembre, 
		Octubre = @Octubre,
		Noviembre = @Noviembre, 
		Diciembre = @Diciembre,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
		WHERE IdIndiceINPC = @IdIndiceINPC
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

