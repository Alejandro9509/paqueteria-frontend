CREATE PROCEDURE [dbo].[usp_CatRutasActualizarConceptosyMateriales]
@dsCatRutasConceptosTarifas	text,   
@dsCatRutasMaterialesTarifas text,  
@ModificadoEl	datetime,	
@ModificadoPor	int,	
@IdPeticion varchar(100)	
AS
DECLARE 
@docHandletarifas int,
@ATT_IdRutaConceptoFacturacion int,
@ATT_ModificadoEl datetime,
@ATT_ModificadoPor int,
@ATT_ImportePesos money,
@ATT_ImporteDolares money,
@docHandlemateriales int,
@ATT_IdRutaDescripcionCarga int,
@ATT_Tarifa float,
@ATT_TarifaDlls float,
@DBT_ModificadoEl datetime,
@DBT_ModificadoPor int,
@DBT_IdObjeto      int

/*

Modificada por: Jesús Humberto Morales
Fecha de mofidicacion: 22/02/2021
Versión ERP: 8.0.59.03
Solicitud 3899
Descripción: Se modifico el tipo de dato money a float en las tarifas pesos y dolares de los materiales

*/

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ((@dsCatRutasConceptosTarifas IS NULL) AND (@dsCatRutasMaterialesTarifas IS NULL))
		RAISERROR(N'No hay Conceptos, ni Materiales, para las rutas señaladas, a los cuales aplicar la actualización de tarifas.', 16, 1)
	
    --- Aqui inicia la actualizacion de conceptos
	
	IF @dsCatRutasConceptosTarifas IS NOT NULL
		BEGIN
		   

		    --- Preparamos el terreno para procesar el xml, y  se crea una tabla temporal con el contenido			
			EXEC sp_xml_preparedocument @docHandletarifas OUTPUT, @dsCatRutasConceptosTarifas
			SELECT ATT_IdRutaConceptoFacturacion, ATT_ModificadoEl, ATT_ModificadoPor, ATT_ImportePesos, ATT_ImporteDolares			
			INTO #TempRutasConceptosTarifas		
			FROM OPENXML(@docHandletarifas, N'/WINDEV_TABLE/TABLE_CatRutasConceptosFacturacion',3) 			
			WITH (ATT_IdRutaConceptoFacturacion int, ATT_ModificadoEl datetime, ATT_ModificadoPor int, ATT_ImportePesos money, ATT_ImporteDolares money)	
			EXEC sp_xml_removedocument @docHandletarifas
			
			--- se crea un cursor sobre la tabla temporal para reccorrela secuencialmente
			DECLARE RutasConceptosFacturacionCursor CURSOR FOR
			SELECT * FROM #TempRutasConceptosTarifas
			OPEN RutasConceptosFacturacionCursor
			FETCH NEXT FROM RutasConceptosFacturacionCursor
			INTO @ATT_IdRutaConceptoFacturacion, @ATT_ModificadoEl, @ATT_ModificadoPor, @ATT_ImportePesos, @ATT_ImporteDolares


			WHILE @@FETCH_STATUS = 0
			BEGIN	
			    --- Consulta la Tabla de la DB para obtener los datos del registro y su última actualizacion
				SELECT @DBT_IdObjeto=IdRutaConceptoFacturacion, @DBT_ModificadoEl = ModificadoEl
                FROM CatRutasConceptosFacturacion WHERE IdRutaConceptoFacturacion = @ATT_IdRutaConceptoFacturacion
				
				--- Si no ha sido modificado la fecha es identica a la del xml (el xml trae la fecha de la computadora del usuario)
				IF @DBT_ModificadoEl IS NULL
				  SET @DBT_ModificadoEl =  @ATT_ModificadoEl
				 
			    --- si existe (no fue borrado) y la fecha de modificacion en la BD es igual a la que tenemos entonces actualizamos
                IF ((@DBT_IdObjeto = @ATT_IdRutaConceptoFacturacion) AND (DATEDIFF(second,@DBT_ModificadoEl,@ATT_ModificadoEl)=0) )
					BEGIN	
						UPDATE CatRutasConceptosFacturacion
						SET
						Importe = @ATT_ImportePesos,
						ImporteDlls = @ATT_ImporteDolares,
						ModificadoPor = @ModificadoPor,
						ModificadoEl = @ModificadoEl
						WHERE
						IdRutaConceptoFacturacion = @ATT_IdRutaConceptoFacturacion
					END	
				ELSE			
				-- si no entonces el proceso debe abortarse
				    BEGIN
					   CLOSE RutasConceptosFacturacionCursor
			           DEALLOCATE RutasConceptosFacturacionCursor
				  	   RAISERROR(N'No se realizaron los cambios debido a la concurrencia en el proceso, valide e intente de nuevo.', 16, 1)
                    END 
			FETCH NEXT FROM RutasConceptosFacturacionCursor
				INTO @ATT_IdRutaConceptoFacturacion, @ATT_ModificadoEl, @ATT_ModificadoPor, @ATT_ImportePesos, @ATT_ImporteDolares
			END --- WHILE @@FETCH_STATUS = 0
			CLOSE RutasConceptosFacturacionCursor
			DEALLOCATE RutasConceptosFacturacionCursor
		END
---- Aqui inicia la actualizacion de materiales
	IF @dsCatRutasMaterialesTarifas IS NOT NULL
		BEGIN
		    
		    --- Preparamos el terreno para procesar el xml, y  se crea una tabla temporal con el contenido		
			EXEC sp_xml_preparedocument @docHandlemateriales OUTPUT, @dsCatRutasMaterialesTarifas
			SELECT ATT_IdRutaDescripcionCarga, ATT_ModificadoEl, ATT_ModificadoPor, ATT_Tarifa, ATT_TarifaDlls			
			INTO #TempRutasMaterialesTarifas		
			FROM OPENXML(@docHandlemateriales, N'/WINDEV_TABLE/TABLE_CatRutasCargaTarifas',3) 			
			WITH (ATT_IdRutaDescripcionCarga int, ATT_ModificadoEl datetime, ATT_ModificadoPor int, ATT_Tarifa float, ATT_TarifaDlls float)	
			EXEC sp_xml_removedocument @docHandlemateriales

			--- se crea un cursor sobre la tabla temporal para reccorrela secuencialmente
			DECLARE RutasCargaTarifasCursor CURSOR FOR
			SELECT * FROM #TempRutasMaterialesTarifas
			OPEN RutasCargaTarifasCursor
			FETCH NEXT FROM RutasCargaTarifasCursor
			INTO @ATT_IdRutaDescripcionCarga, @ATT_ModificadoEl, @ATT_ModificadoPor, @ATT_Tarifa, @ATT_TarifaDlls

			WHILE @@FETCH_STATUS = 0
			BEGIN		
			
			    --- Consulta la Tabla de la DB para obtener los datos del registro y su última actualizacion
				SELECT @DBT_IdObjeto = IdRutaDescripcionCarga, @DBT_ModificadoEl = ModificadoEl
                FROM CatRutasDescripcionesCargaTarifas  WHERE IdRutaDescripcionCarga = @ATT_IdRutaDescripcionCarga

				--- Si no ha sido modificado la fecha es identica a la del xml (el xml trae la fecha de la computadora del usuario)
				IF @DBT_ModificadoEl IS NULL
				  SET @DBT_ModificadoEl =  @ATT_ModificadoEl				
			
			    --- si existe (no fue borrado) y la fecha de modificacion en la BD es igual a la que tenemos entonces actualizamos				 
               IF ((@DBT_IdObjeto = @ATT_IdRutaDescripcionCarga) AND (DATEDIFF(second,@DBT_ModificadoEl,@ATT_ModificadoEl)=0))			 
				BEGIN
					UPDATE CatRutasDescripcionesCargaTarifas
					SET
					Tarifa = @ATT_Tarifa,
					TarifaDlls = @ATT_TarifaDlls,
					ModificadoPor = @ModificadoPor,
					ModificadoEl = @ModificadoEl
					WHERE
					IdRutaDescripcionCarga = @ATT_IdRutaDescripcionCarga
				END	
				ELSE
				-- si no entonces el proceso debe abortarse				
				    BEGIN
					   CLOSE RutasCargaTarifasCursor
			           DEALLOCATE RutasCargaTarifasCursor
				  	   RAISERROR(N'No se realizaron los cambios debido a la concurrencia en el proceso, valide e intente de nuevo.', 16, 1)
                    END 

			FETCH NEXT FROM RutasCargaTarifasCursor
				INTO @ATT_IdRutaDescripcionCarga, @ATT_ModificadoEl, @ATT_ModificadoPor, @ATT_Tarifa, @ATT_TarifaDlls
			END --  @@FETCH_STATUS = 0
			CLOSE RutasCargaTarifasCursor
			DEALLOCATE RutasCargaTarifasCursor
		END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	
	----- Retirar esto despues de depurar
	---SELECT ERROR_NUMBER() AS [ErrorNumber],
	---       ERROR_SEVERITY() AS [ErrorSeverity],  
	---       ERROR_STATE() AS [ErrorState], 
	---       ERROR_PROCEDURE() AS [ErrorProcedure], 
	---       ERROR_LINE() AS [ErrorLine], 
	---       ERROR_MESSAGE() AS [ErrorMessage]; 
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

