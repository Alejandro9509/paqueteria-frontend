create PROCEDURE [dbo].[usp_CatProveedoresModificarNombreFiscal]
	@IdProveedor int,
	@NombreFiscal varchar(150),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	IF @IdProveedor = 0
		RAISERROR(N'El identificador del proveedor es un campo requerido',
			16,
			1
			)
			
	IF NOT EXISTS(SELECT IdProveedor FROM CatProveedores WHERE IdProveedor = @IdProveedor)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)	

	IF (SELECT ModificadoEl FROM CatProveedores WHERE IdProveedor = @IdProveedor) <> @UltimaModificacion
		RAISERROR(N'Los datos de este proveedor fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)					

			

	IF LTRIM(RTRIM(@NombreFiscal)) = ''
		RAISERROR(N'El nombre fiscal es un campo requerido',
			16,
			1
			)


	UPDATE CatProveedores SET
		NombreFiscal = @NombreFiscal,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl
    WHERE IdProveedor = @IdProveedor

    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
        UPDATE CatCuentasContables SET
        Nombre = @NombreFiscal
        WHERE CatalogoLigado = 'CatProveedores' AND IdCatalogoLigado = @IdProveedor
    END
    		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

