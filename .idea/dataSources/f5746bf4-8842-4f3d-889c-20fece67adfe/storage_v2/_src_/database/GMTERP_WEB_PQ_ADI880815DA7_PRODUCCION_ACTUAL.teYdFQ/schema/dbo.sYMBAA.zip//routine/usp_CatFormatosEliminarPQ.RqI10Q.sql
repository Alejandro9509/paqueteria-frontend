
-- =============================================
-- Author:		<Author,,Name>
-- ALTER date: <ALTER Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_CatFormatosEliminarPQ]
	@IdFormato INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdFormato,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del formato es un campo requerido*FIN*', 16, 1);
			return
		end
		DELETE FROM CatFormatos
		WHERE IdFormato = @IdFormato
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

