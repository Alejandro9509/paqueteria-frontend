CREATE PROCEDURE [dbo].[usp_CatRecorridosEliminar]  
	@IdRecorrido int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdRecorrido,0) <= 0	
		RAISERROR(N'La ruta es un campo requerido',
			16,
			1
			)	
	IF EXISTS(SELECT TOP 1 * FROM ProRecorridosDespacho WHERE IdRecorrido = @IdRecorrido)   
		RAISERROR(N'La ruta tiene recorridos ligados, no es posible eliminarlo',
			16,
			1
			)
					
	DELETE FROM CatRecorridos
	WHERE IdRecorrido = @IdRecorrido  
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

