
CREATE PROCEDURE [dbo].[usp_CatZonasEliminarPQ]
	@IdZona INT
AS
--BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdZona,0) <= 0 
			RAISERROR(N'*INICIO*Identificador de Zona es un campo requerido*FIN*', 16, 1)
		DELETE FROM CatZonasPQ
		WHERE IdZona = @IdZona
	COMMIT TRANSACTION
--END TRY
--BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
--END CATCH
go

