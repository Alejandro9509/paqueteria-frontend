CREATE PROCEDURE [dbo].[usp_ProCorteCajaGetListadoFiltrosPQ]
@FechaRegistro DATE,
@IdDestino int
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT 
		IdCorte,
		IdSucursal, 
		FechaRegistro,
		HoraRegistro,
		IdDestino,
		IdTipoMoneda,
		IdTipoPago,
		Total,
		(Select Ciudad from CatCiudades c WHERE c.IdCiudad = IdDestino) as Destino,
		IdEstatusCorte,
		(Select Descripcion from CatEstatusCortePQ e WHERE e.IdEstatusCorte = cc.IdEstatusCorte) as EstatusCorte
		,IdUsuario
	  ,(select Usuario from CatUsuariosPQ u where u.IdUsuario = cc.IdUsuario) as Usuario
		FROM ProCorteCajaPQ cc 
		WHERE (IdDestino = @IdDestino OR @IdDestino IS NULL)
		AND (FechaRegistro = @FechaRegistro OR @FechaRegistro IS NULL)
	
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

