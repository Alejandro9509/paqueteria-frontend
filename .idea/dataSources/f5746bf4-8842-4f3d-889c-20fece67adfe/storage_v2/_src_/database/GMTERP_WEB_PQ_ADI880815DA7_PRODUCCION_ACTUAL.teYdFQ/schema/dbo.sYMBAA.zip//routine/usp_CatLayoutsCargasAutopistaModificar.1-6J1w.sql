CREATE PROCEDURE [dbo].[usp_CatLayoutsCargasAutopistaModificar]
	@IdLayoutCargaAutopista int,
	@Layout	varchar(50),
	@Separador	varchar(1),
	@TieneEncabezado	bit,
	@RenglonInicial	tinyint,
	@ColumnaTarjeta	tinyint,
	@ColumnaFecha	tinyint,
	@FormatoFecha	varchar(15),
	@ColumnaHora	tinyint,
	@FormatoHora	varchar(15),
	@ColumnaClase	tinyint,
	@ColumnaImporte	tinyint,
	@ColumnaCaseta	tinyint,
	@ColumnaCasetaIncluyeCarril	bit,
	@ColumnaCarril	tinyint,
	@ModificadoEl	datetime,
	@ModificadoPor	int,
	@IdPeticion varchar(100),
	@TipoArchivo tinyint,
	@FechaHoraJuntas bit,
	@ColumnaFechaHora tinyint,
	@FormatoFechaHora varchar(26),
	@ColumnaCasetaLayoutVPAS bit
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
		Update CatLayoutsCargasAutopista Set
		ColumnaCarril=@ColumnaCarril,
		ColumnaCaseta=@ColumnaCaseta,
		ColumnaCasetaIncluyeCarril=@ColumnaCasetaIncluyeCarril,
		ColumnaClase=@ColumnaClase,
		ColumnaFecha=@ColumnaFecha,
		ColumnaHora=@ColumnaHora,
		ColumnaImporte=@ColumnaImporte,
		ColumnaTarjeta=@ColumnaTarjeta,
		ModificadoEl=@ModificadoEl,
		ModificadoPor=@ModificadoPor,
		FormatoFecha=@FormatoFecha,
		FormatoHora=@FormatoHora,
		Layout=@Layout,
		RenglonInicial=@RenglonInicial,
		Separador=@Separador,
		TieneEncabezado =@TieneEncabezado,
		TipoArchivo = @TipoArchivo,
		FechaHoraJuntas = @FechaHoraJuntas,
		ColumnaFechaHora = @ColumnaFechaHora,
		FormatoFechaHora = @FormatoFechaHora,
		ColumnaCasetaLayoutVPAS = @ColumnaCasetaLayoutVPAS
		Where IdLayoutCargaAutopista = @IdLayoutCargaAutopista						
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

