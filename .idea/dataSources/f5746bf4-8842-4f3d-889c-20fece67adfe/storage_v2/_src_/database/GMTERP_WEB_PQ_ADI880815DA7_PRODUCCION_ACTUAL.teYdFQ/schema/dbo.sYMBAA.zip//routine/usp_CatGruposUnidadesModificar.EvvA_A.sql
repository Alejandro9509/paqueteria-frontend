
CREATE PROCEDURE [dbo].[usp_CatGruposUnidadesModificar]
	@IdGrupoUnidad int,
	@Codigo int,
	@GrupoUnidad varchar(50),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@Color varchar(6),
	@ColorLetra int
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdGrupoUnidad,0) <= 0
		RAISERROR(N'El identificador del grupo de unidad es un campo requerido',
			16,
			1
			)	

	IF NOT EXISTS(SELECT IdGrupoUnidad FROM CatGruposUnidades WHERE IdGrupoUnidad = @IdGrupoUnidad)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)						

	IF (SELECT ModificadoEl FROM CatGruposUnidades WHERE IdGrupoUnidad = @IdGrupoUnidad) <> @UltimaModificacion
		RAISERROR(N'Los datos de este grupo de unidades fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)				

	IF ISNULL(@Codigo,0) <= 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)	

	IF EXISTS(SELECT Codigo FROM CatGruposUnidades WHERE Codigo = @Codigo AND IdGrupoUnidad <> @IdGrupoUnidad)
		RAISERROR(N'El código ya existe',
			16,
			1
			)

	IF LTRIM(RTRIM(@GrupoUnidad)) = ''
		RAISERROR(N'El campo deducción es requerido',
			16,
			1
			)
			

	UPDATE CatGruposUnidades SET
		Codigo = @Codigo,
		GrupoUnidad = @GrupoUnidad,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		Color = @Color,
		ColorLetra = @ColorLetra
	WHERE IdGrupoUnidad = @IdGrupoUnidad
			
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

