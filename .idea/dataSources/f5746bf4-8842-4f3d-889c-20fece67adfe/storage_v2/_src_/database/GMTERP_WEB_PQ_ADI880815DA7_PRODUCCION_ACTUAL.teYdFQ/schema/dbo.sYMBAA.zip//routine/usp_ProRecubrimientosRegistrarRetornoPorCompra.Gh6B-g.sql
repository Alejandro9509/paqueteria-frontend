CREATE PROCEDURE [dbo].[usp_ProRecubrimientosRegistrarRetornoPorCompra]
@Folio int,
@IdProveedor int,
@FechaHora datetime,
@SubTotal money,
@Descuento money,
@MotivoDescuento varchar(100),
@IdImpuestosTrasladadosFederales int,
@ImpuestosTrasladadosFederales money,
@IdImpuestosRetenidosFederales int,
@ImpuestosRetenidosFederales money,
@IdImpuestosTrasladadosLocales int,
@ImpuestosTrasladadosLocales money,
@IdImpuestosRetenidosLocales int,
@ImpuestosRetenidosLocales money,
@Total money,
@TipoCambio money,
@IdMoneda int,
@Estatus tinyint,
@Observaciones varchar(512),
@CreadoPor int,
@CreadoEl datetime,
@dsProComprasConceptos ntext,
@IdPeticion varchar(100),
@IdAlmacen int,
@FechaHoraRecibido datetime,
@FechaHoraVencimiento datetime,
@FolioDocumento varchar(40),
@SerieDocumento varchar(25),
@XMLArchivo ntext,
@FolioFiscalUUID varchar(36),
@QuienRecibe varchar(50),
@dsProMovimientosAlmacenConceptos ntext

/*********************************

Modificada por:   Gilberto Garcia
Fecha de modificación: 15/12/2020
Versión: 8.0.57.13
Solicitud 3546
Se agregó la validación de folio duplicado

**********************************/
AS

SET XACT_ABORT ON 	

DECLARE
	@docHandle int,
	@IdCompra int,
	@FolioMovimientoAlmacen int,
	@FolioOrdenCompra Varchar(6), 
	@AutorizadoElOrdenCompra datetime,
	@EstatusOrdenCompra  int,
	@CantidadPendienteOrdenCompra decimal(15,4),
	@ErrorMsg varchar(150),
	@IdMovimientoAlmacen int,
	@ExistenciaActual decimal(15,4),
	@CostoPromedioActual money,
	@ImporteTotalPromedioActual money,
	@IdTipoMovimientoAlmacen int, 
	@EsLlanta bit,
	@return_value int,
	@CodigoArticulo Varchar(20),
	@IdProcesoLlantaRecubierta int,
	@IdEstatusLLantaRecubierta int, 
	@IdProcesoLlantaEnRecubrimiento int,
	@IdEstatusLLantaEnRecubrimiento int,
	@FolioRecubrimiento int, 
	@IdRecubrimiento int,
	@CostoLlantaPesos money,
	@CostoLlantaDlls money

SET XACT_ABORT ON
	
BEGIN TRY
	BEGIN TRANSACTION
	SET @ErrorMsg=''
	SET @EsLlanta = 1
	
	SET @IdProcesoLlantaEnRecubrimiento = (SELECT IdProcesoLLanta FROM CatProcesosLlantas WHERE ProcesoLlanta = 'EN RECUBRIMIENTO')
	SET @IdEstatusLLantaEnRecubrimiento = (SELECT IdEstatuLlanta FROM CatEstatusLlantas WHERE EstatusLLanta = 'EN RECUBRIMIENTO' AND DefinidoPorSistema = 1) 

	SET @IdProcesoLlantaRecubierta = (SELECT IdProcesoLLanta FROM CatProcesosLlantas WHERE ProcesoLlanta = 'RECUBIERTA')
	SET @IdEstatusLLantaRecubierta = (SELECT IdEstatuLlanta FROM CatEstatusLlantas WHERE EstatusLLanta = 'RECUBIERTA' AND DefinidoPorSistema = 1) 
		
	IF isnull(@Folio,0) = 0
		RAISERROR(N'El folio de la oompra es un campo requerido',
			16,
			1
			)			

	IF EXISTS(SELECT Folio FROM ProCompras WHERE Folio = @Folio)
		RAISERROR(N'El folio de la compra ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar',
			16,
			1
			)

	IF ISNULL(@IdProveedor,0) = 0
		RAISERROR(N'El proveedor es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaHora) = 0			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF ISNULL(@SubTotal,0) = 0
		RAISERROR(N'El subtotal es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdMoneda,0) = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)
			
	--IF ISNULL(@IdMoneda,0) = 2
	--	BEGIN
	IF ISNULL(@TipoCambio,0)=0 
		RAISERROR(N'El tipo de cambio es un campo requerido',
				16,
				1
				)
		--END
			
	IF ISDATE(@FechaHoraVencimiento ) = 0
		RAISERROR(N'La fecha vencimiento es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaHoraRecibido) = 0
		RAISERROR(N'La fecha recibido es un campo requerido',
			16,
			1
			)
	IF @FechaHoraVencimiento < @FechaHora
		RAISERROR(N'Fecha de vencimiento no puede ser menor a la fecha de elaboración',
			16,
			1
			)
			
	IF @FechaHoraRecibido < @FechaHora
		RAISERROR(N'Fecha recibido no puede ser menor a la fecha de elaboración',
			16,
			1
			)		
	--IF isnull(@FolioDocumento,0) = 0
	--	RAISERROR(N'El folio del documento de compra es un campo requerido',
	--		16,
	--		1
	--		)		
	

	 IF EXISTS(SELECT  IdProveedor From ProCompras WHERE IdProveedor = @IdProveedor AND FolioDocumento =@FolioDocumento AND SerieDocumento = @SerieDocumento)
		RAISERROR(N'El documento de compra ya existe',
			16,
			1
			) 
					
	IF @dsProComprasConceptos IS NULL
		RAISERROR(N'Los conceptos de la compra son requeridos',
			16,
			1
			)	
	

		
	INSERT INTO ProCompras(CreadoEl,CreadoPor,Descuento,Estatus,FechaHora,FechaHoraRecibido,FechaHoraVencimiento,IdProveedor,Folio,IdMoneda,MotivoDescuento,Observaciones,SubTotal,TipoCambio,Total,IdImpuestosTrasladadosFederales,ImpuestosTrasladadosFederales,IdImpuestosRetenidosFederales,ImpuestosRetenidosFederales,IdImpuestosTrasladadosLocales,ImpuestosTrasladadosLocales,IdImpuestosRetenidosLocales,ImpuestosRetenidosLocales,FolioDocumento,SerieDocumento,XMLArchivo,FolioFiscalUUID)
	VALUES(@CreadoEl,@CreadoPor,@Descuento,@Estatus,@FechaHora,@FechaHoraRecibido,@FechaHoraVencimiento,@IdProveedor,@Folio,@IdMoneda,@MotivoDescuento,@Observaciones,@SubTotal,@TipoCambio,@Total,@IdImpuestosTrasladadosFederales,@ImpuestosTrasladadosFederales,@IdImpuestosRetenidosFederales,@ImpuestosRetenidosFederales,@IdImpuestosTrasladadosLocales,@ImpuestosTrasladadosLocales,@IdImpuestosRetenidosLocales,@ImpuestosRetenidosLocales,@FolioDocumento,@SerieDocumento,@XMLArchivo,@FolioFiscalUUID)
	
	SET @IdCompra = (SELECT IDENT_CURRENT('ProCompras'))	

	SET @FolioMovimientoAlmacen  = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)
	Select @IdTipoMovimientoAlmacen = IdTipoMovimientoAlmacen From CatTiposMovimientosAlmacen where Codigo = 1

	------------------------------------------------
	-- SECCION PARA AGREGAR LOS CONCEPTOS DE LA COMPRA
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProComprasConceptos
	SELECT ATT_IdArticulo,ATT_Cantidad,ATT_Entregado,ATT_Pendiente,ATT_PrecioUnitario,ATT_Importe,ATT_UnidadMedida,ATT_IdOrdenCompraConcepto,ATT_IdOrdenCompra,ATT_IdAlmacen,ATT_Observacion,
	ATT_dsProLlantasNumerosEconomicos 
	INTO #TempProComprasConceptos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProOrdenCompraConceptos',2) 
	WITH (ATT_IdArticulo int,ATT_Cantidad decimal(15,4),ATT_Entregado decimal(15,4),ATT_Pendiente decimal(15,4),ATT_PrecioUnitario decimal(19,6),ATT_Importe money,ATT_UnidadMedida varchar(30),ATT_IdOrdenCompraConcepto int,ATT_IdOrdenCompra int,ATT_IdAlmacen int,ATT_Observacion varchar(256),
	ATT_dsProLlantasNumerosEconomicos varchar(max))
	EXEC sp_xml_removedocument @docHandle
	
	-- Crear cursor
	DECLARE @ATT_IdArticulo int,@ATT_Cantidad decimal(15,4),@ATT_Entregado decimal(15,4),@ATT_Pendiente decimal(15,4),@ATT_PrecioUnitario decimal(19,6),@ATT_Importe money,@ATT_UnidadMedida varchar(30),@ATT_IdOrdenCompraConcepto int,@ATT_IdOrdenCompra int,@ATT_IdAlmacen int,@ATT_Observacion varchar(256),
	@dsProLlantasNumerosEconomicos varchar(max)
	DECLARE TempProComprasConceptos CURSOR FOR 
	SELECT ATT_IdArticulo,ATT_Cantidad,ATT_Entregado,ATT_Pendiente,ATT_PrecioUnitario,ATT_Importe,ATT_UnidadMedida,ATT_IdOrdenCompraConcepto,ATT_IdOrdenCompra,ATT_IdAlmacen,ATT_Observacion, ATT_dsProLlantasNumerosEconomicos From #TempProComprasConceptos

	OPEN TempProComprasConceptos
	FETCH NEXT FROM TempProComprasConceptos INTO @ATT_IdArticulo,@ATT_Cantidad,@ATT_Entregado,@ATT_Pendiente,@ATT_PrecioUnitario,@ATT_Importe,@ATT_UnidadMedida,@ATT_IdOrdenCompraConcepto,@ATT_IdOrdenCompra,@ATT_IdAlmacen,@ATT_Observacion, @dsProLlantasNumerosEconomicos 
	WHILE @@fetch_status = 0
		BEGIN
			SELECT @FolioOrdenCompra= right('000000' + CAST(Folio As nvarchar),6), 
				   @AutorizadoElOrdenCompra = AutorizadoEl,
				   @EstatusOrdenCompra=Estatus 
				   FROM ProOrdenCompra 
							WHERE ProOrdenCompra.IdOrdenCompra = @ATT_IdOrdenCompra 
			
			SELECT @FolioRecubrimiento= Folio, @IdRecubrimiento = IdRecubrimiento  FROM ProRecubrimientos where IdOrdenCompra = @ATT_IdOrdenCompra
			
			 IF NOT EXISTS(SELECT  IdOrdenCompra  FROM ProRecubrimientos where IdOrdenCompra = @ATT_IdOrdenCompra)
			 BEGIN
			 		SET @ErrorMsg ='La orden de compra folio '+@FolioOrdenCompra+ ' ya no tiene liga con ningún recubrimiento, verificar información'
							RAISERROR(@ErrorMsg,
								16,
								1
								)
			 END								
			 						
			 IF exists(SELECT  Folio  FROM ProRecubrimientos where IdOrdenCompra = @ATT_IdOrdenCompra and Estatus = 2)	
			 			BEGIN
			 			SET @ErrorMsg ='El recubrimiento de folio '+@FolioRecubrimiento + ' ya tiene llantas en retorno completa '
								RAISERROR(@ErrorMsg,
									16,
									1
									)
						END		
							
			
						
			--- Validar estatus de orden compra no este cerrada			
			SET @ErrorMsg ='La orden de compra esta cerrada, nro de folio '+@FolioOrdenCompra
			IF ISNULL(@EstatusOrdenCompra,0) = 1
					RAISERROR(@ErrorMsg,
						16,
						1
						)
						
			--- Validar estatus de orden compra no este cancelada
			SET @ErrorMsg ='La orden de compra esta cancelada, nro de folio '+@FolioOrdenCompra
			IF ISNULL(@EstatusOrdenCompra,0) = 2
					RAISERROR(@ErrorMsg,
						16,
						1
						)
			
			--- Valida Cantidad pendiente de orden de compra 
			SELECT @CantidadPendienteOrdenCompra  = isnull(Pendiente,0) FROM ProOrdenCompraConceptos
			WHERE ProOrdenCompraConceptos.IdOrdenCompraConcepto = @ATT_IdOrdenCompraConcepto
			
			SET @ErrorMsg ='No se puede recibir cantidad mayor a la solicitada, folio de orden de compra '+@FolioOrdenCompra
			IF @ATT_Entregado > @CantidadPendienteOrdenCompra 
					RAISERROR(@ErrorMsg,
						16,
						1
						)
									
			INSERT INTO ProComprasConceptos(IdCompra,IdArticulo,Cantidad,Entregado,Pendiente,PrecioUnitario,Importe,UnidadMedida,IdOrdenCompra,IdAlmacen,CreadoPor,CreadoEl,Observacion)
			VALUES(@IdCompra,@ATT_IdArticulo,@ATT_Cantidad,@ATT_Entregado,@ATT_Pendiente,@ATT_PrecioUnitario,@ATT_Importe,@ATT_UnidadMedida,@ATT_IdOrdenCompra,@ATT_IdAlmacen,@CreadoPor,@CreadoEl,@ATT_Observacion)

			-- Actualizar cantidad de conceptos de la orden de compra	
			UPDATE ProOrdenCompraConceptos 
				SET Entregado = Entregado+@ATT_Entregado,
						Pendiente = Pendiente - @ATT_Entregado
				WHERE ProOrdenCompraConceptos.IdOrdenCompraConcepto = @ATT_IdOrdenCompraConcepto
				
			-- Validar orden de compra Completa.
				DECLARE @Diferencia INT
				SET @Diferencia  = (SELECT COUNT(*)
									  FROM ProOrdenCompraConceptos
									   WHERE ProOrdenCompraConceptos.Cantidad<>ProOrdenCompraConceptos.Entregado
											AND ProOrdenCompraConceptos.IdOrdenCompra = @ATT_IdOrdenCompra)
											
			-- Se completa la entrega de la orden de compra	(1=Completa 3=Parcialmente surtida)	
				IF @Diferencia = 0 
				  UPDATE ProOrdenCompra SET Estatus = 1 WHERE IdOrdenCompra = @ATT_IdOrdenCompra				
				ELSE
				  UPDATE ProOrdenCompra SET Estatus = 3 WHERE IdOrdenCompra = @ATT_IdOrdenCompra				
			
			-- SECCION DE REGISTRO DE RETORNO DE LLANTAS

			-- Valida que el articulo sea de tipo llanta
			   IF NOT EXISTS(SELECT ISNULL(EsLlanta,0) FROM CatArticulos WHERE EsLlanta = @EsLlanta AND IdArticulo = @ATT_IdArticulo) 
				  BEGIN
			  		  SELECT @CodigoArticulo= Codigo
					   FROM CatArticulos  
							WHERE CatArticulos.IdArticulo= @ATT_IdArticulo
							SET @ErrorMsg ='El artículo código '+@CodigoArticulo+ 'no es de tipo llanta'
							RAISERROR(@ErrorMsg ,
										16,
										1
										)
			   END
			  
			-- Sección agregar número económico --			
			   IF (SELECT ISNULL(EsLlanta,0) FROM CatArticulos WHERE EsLlanta = @EsLlanta AND IdArticulo = @ATT_IdArticulo)  = @EsLlanta
			   BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProLlantasNumerosEconomicos
					SELECT ATT_IdLlanta,ATT_NumeroEconomico, ATT_FechaRetorno, ATT_VidaUtil, ATT_Marcar 
					INTO #TempProLlantas
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProLlantas',2) 
					WITH (ATT_IdLlanta int, ATT_NumeroEconomico varchar(20), ATT_FechaRetorno datetime,ATT_VidaUtil INT, ATT_Marcar INT)
					EXEC sp_xml_removedocument @docHandle
						
					-- Crear cursor
					DECLARE @ATT_IdLlanta int, @ATT_NumeroEconomico varchar(20), @ATT_FechaRetorno datetime,@ATT_VidaUtil INT, @ATT_Marcar INT
					DECLARE TempProLlantas CURSOR FOR 
					SELECT 	ATT_IdLlanta , ATT_NumeroEconomico , ATT_FechaRetorno ,ATT_VidaUtil , ATT_Marcar  From #TempProLlantas WHERE ATT_Marcar = 1

					OPEN TempProLlantas 
					FETCH NEXT FROM TempProLlantas INTO @ATT_IdLlanta,@ATT_NumeroEconomico, @ATT_FechaRetorno ,@ATT_VidaUtil , @ATT_Marcar
					WHILE @@fetch_status = 0
					 BEGIN
					 	---Valida que la llanta no tenga fecha de recubrimiento					
						IF  exists(SELECT ProRecubrimientos.Folio
							FROM  ProRecubrimientos INNER JOIN
										   ProRecubrimientosLlantas ON ProRecubrimientos.IdRecubrimiento = ProRecubrimientosLlantas.IdRecubrimiento 
										   where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento 
										   And  ProRecubrimientosLlantas.IdLlanta  =@ATT_IdLlanta and  ProRecubrimientosLlantas.IdArticulo = @ATT_IdArticulo and ProRecubrimientosLlantas.FechaRetorno is not null)
								BEGIN
									SET @ErrorMsg ='Llanta con número económico '+@ATT_NumeroEconomico+ ' ya tiene fecha de retorno, verificar información'
									RAISERROR(@ErrorMsg ,
												16,
												1
												)
								END	
								
						---Valida recubrimiento que no este cancelada

						IF not exists(SELECT ProRecubrimientos.Folio
							FROM  ProRecubrimientos INNER JOIN
										   ProRecubrimientosLlantas ON ProRecubrimientos.IdRecubrimiento = ProRecubrimientosLlantas.IdRecubrimiento 
										   where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento 
										   And  ProRecubrimientosLlantas.IdLlanta  =@ATT_IdLlanta
										   and ProRecubrimientosLlantas.IdArticulo = @ATT_IdArticulo)
						BEGIN			     
							SET @ErrorMsg ='Llanta con número económico '+@ATT_NumeroEconomico+ ' fue modificado asignación de artículo, verificar información'
							RAISERROR(@ErrorMsg ,
										16,
										1
										)	               
						END
               
						-- Valida que la llanta este en recubrimiento
						IF NOT EXISTS(SELECT  IdLlanta from ProLlantas WHERE IdEstatuLlanta = @IdEstatusLLantaEnRecubrimiento AND IdProcesoLlanta = @IdProcesoLlantaEnRecubrimiento and IdLlanta = @ATT_IdLlanta)
						BEGIN
							SET @ErrorMsg ='Llanta con número económico '+@ATT_NumeroEconomico+ ' no esta en proceso de en recubrimieto, verificar información'
							RAISERROR(@ErrorMsg ,
										16,
										1
										)
						END
						 

						-- Valida que la llanta este en recubrimiento
						IF ISDATE(@ATT_FechaRetorno ) = 0
						BEGIN			
							SET @ErrorMsg ='Fecha de retorno de llanta con número económico '+@ATT_NumeroEconomico+ ' es requerido'
							RAISERROR(@ErrorMsg ,
										16,
										1
										)
						END				
						 												 
							--- Sección declaración de variables para actualizar llanta
							
							DECLARE @IdModeloLlanta int,
								@IdMarcaLlanta int,
								@IdMedidaLlanta int,
								@IdTipoLlanta int,
								@ProfundidadOriginal decimal (10, 2),
								@ProfundidadMinima  decimal (10, 2),
								@PresionMaxima  decimal (10, 2),
								@PresionMinima  decimal (10, 2),
								@ProfundidadActual  decimal (10, 2),
								@PresionActual  decimal (10, 2),
								@IdEstatuLlanta int,
								@CostoLlanta money,
								@VidaUtil int,								
								@DisponibleDesde datetime,
								@UltimaModificacion datetime
								
							SELECT 
								@IdModeloLlanta  =CatArticulos.IdModeloLlanta,
								@IdMarcaLlanta  = CatArticulos.IdMarcaLlanta,
								@IdMedidaLlanta  = CatArticulos.IdMedidaLlanta,
								@IdTipoLlanta  =CatArticulos.IdTipoLlanta,
								@ProfundidadOriginal  = CatArticulos.ProfundidadOriginalLlanta,
								@ProfundidadMinima   = CatArticulos.ProfundidadMinimaLlanta,
								@PresionMaxima   = CatArticulos.PresionMaximaLlanta,
								@PresionMinima   =CatArticulos.PresionMinimaLlanta,
								@ProfundidadActual  = 0,
								@PresionActual   = 0,
								@IdEstatuLlanta  = @IdEstatusLLantaRecubierta,
								@CostoLlanta  = 0,
								@VidaUtil  = CatArticulos.VidaUtilLlanta
							FROM CatArticulos where IdArticulo = @ATT_IdArticulo
						
						
						
							-- Modificar llanta
							SELECT @UltimaModificacion= ModificadoEl FROM ProLlantas where IdLlanta = @ATT_IdLlanta
							SELECT @DisponibleDesde = @ATT_FechaRetorno --GETDATE() 
							
							
							ALTEr TABLE ProLlantas DISABLE TRIGGER trg_ProLlantas 

				 			IF @IdMoneda  =  1 --- PESOS
								BEGIN
										SET @CostoLlantaPesos  = @ATT_PrecioUnitario
										SET @CostoLlantaDlls   = @ATT_PrecioUnitario / @TipoCambio
								END
								ELSE
									BEGIN
										SET @CostoLlantaPesos  = @ATT_PrecioUnitario * @TipoCambio
										SET @CostoLlantaDlls   = @ATT_PrecioUnitario
									END
																	
							EXEC @return_value = usp_ProLlantasModificar @ATT_IdLlanta,
																		 @ATT_NumeroEconomico,
						  												 @IdModeloLlanta,
																		 @IdMarcaLlanta,
																		 @IdMedidaLlanta,
																		 @IdTipoLlanta,
																		 @ProfundidadOriginal,
																		 @ProfundidadMinima,
																		 @PresionMaxima,
																		 @PresionMinima,
																		 @ProfundidadActual,
																		 @PresionActual,
																		 @IdEstatuLlanta,
																		 @DisponibleDesde , -- datetime,
																		 @UltimaModificacion, -- datetime,
																		 @CreadoPor,
																		 @CreadoEl,
																		 @IdPeticion,
																		 @CostoLlantaPesos,--@ATT_PrecioUnitario, -- Costo llanta
																		 @ATT_VidaUtil,
																		 @CostoLlantaDlls, 
																		 @TipoCambio
							 IF @return_value <> 0
									RAISERROR(N'Ocurrió un error al modificar llanta',
											16,
											1
											)  
						
						
						  UPDATE ProRecubrimientosLlantas Set FechaRetorno =  @ATT_FechaRetorno 
											WHERE ProRecubrimientosLlantas.IdRecubrimiento =@IdRecubrimiento 
											    AND  ProRecubrimientosLlantas.IdLlanta  =@ATT_IdLlanta
											    AND ProRecubrimientosLlantas.IdArticulo = @ATT_IdArticulo

						  						 
						  UPDATE ProLlantas SET IdArticulo = @ATT_IdArticulo , IdCompra =@IdCompra WHERE IdLlanta = @ATT_IdLlanta
						  
						 --  Registrar en auxiliar de llantas
						 --  Cargar datos de la llanta
						 DECLARE 	@ProfundidadRodamiento INT, @KilometrajeHistorico INT,	@VecesRecubierta INT
						 SELECT @VecesRecubierta=isnull(VecesRecubierta,0), @PresionActual = PresionActual,@ProfundidadRodamiento=ProfundidadActual, @KilometrajeHistorico= KilometrajeLLanta FROM ProLlantas WHERE IdLlanta = @ATT_IdLlanta 
							
						 --  Actualizar ProLlantas
						 UPDATE ProLlantas SET IdEstatuLlanta = @IdEstatusLLantaRecubierta ,
								IdProcesoLlanta = @IdProcesoLlantaRecubierta,
								VidaUtil =@ATT_VidaUtil,
								VecesRecubierta = @VecesRecubierta + 1,	
								KilometrajeLLanta = 0					  
						 WHERE IdLlanta = @ATT_IdLlanta
							  
						 --  Registrar en Auxiliar de Llantas															
						 INSERT INTO ProLlantasAuxiliar (IdLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta) 
							   VALUES (@ATT_IdLlanta,@ATT_FechaRetorno,@IdEstatuLlanta,@PresionActual,@ProfundidadRodamiento,0,0,@ATT_PrecioUnitario,@CreadoPor,@CreadoEl,@IdProcesoLlantaRecubierta) 	
						
						ALTER table ProLlantas enable TRIGGER trg_ProLlantas
											  
					FETCH NEXT FROM TempProLlantas INTO @ATT_IdLlanta,@ATT_NumeroEconomico, @ATT_FechaRetorno,@ATT_VidaUtil , @ATT_Marcar
					END
					DROP TABLE #TempProLlantas
					CLOSE TempProLlantas
					DEALLOCATE TempProLlantas		
				END
			
			-- FIN DE SECCION DE RETORNO DE LLANTAS 
			-- Actualiza estatus de prorecubierta
			  DECLARE @CantidadLlantasARecubrir int, @CantidadRecubiertas int
			   
			  SET @CantidadLlantasARecubrir= (SELECT COUNT(ProRecubrimientosLlantas.IdLlanta) AS CantidadLlantas
					FROM  ProRecubrimientosLlantas INNER JOIN
								   ProRecubrimientos ON ProRecubrimientosLlantas.IdRecubrimiento = ProRecubrimientos.IdRecubrimiento
					where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento )
			
			  SET @CantidadRecubiertas= (SELECT COUNT(ProRecubrimientosLlantas.IdLlanta) AS CantidadLlantas
					FROM  ProRecubrimientosLlantas INNER JOIN
								   ProRecubrimientos ON ProRecubrimientosLlantas.IdRecubrimiento = ProRecubrimientos.IdRecubrimiento
					where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento AND ProRecubrimientosLlantas.FechaRetorno IS NOT NULL)
		
					 IF @CantidadLlantasARecubrir = @CantidadRecubiertas
						UPDATE ProRecubrimientos SET Estatus =2 , QuienRecibe = @QuienRecibe where IdRecubrimiento= @IdRecubrimiento --Completa
					 ELSE
						UPDATE ProRecubrimientos SET Estatus =3 ,QuienRecibe = @QuienRecibe  where IdRecubrimiento= @IdRecubrimiento  --parcialmente surtida
		
			-- fin Actualiza estatus de prorecubierta
			
		   FETCH NEXT FROM TempProComprasConceptos INTO @ATT_IdArticulo,@ATT_Cantidad,@ATT_Entregado,@ATT_Pendiente,@ATT_PrecioUnitario,@ATT_Importe,@ATT_UnidadMedida,@ATT_IdOrdenCompraConcepto,@ATT_IdOrdenCompra,@ATT_IdAlmacen,@ATT_Observacion ,@dsProLlantasNumerosEconomicos
		END
	CLOSE TempProComprasConceptos
	DEALLOCATE TempProComprasConceptos

	----------------------------------------------------------------------------------------------------------------
	--Registrar entrada al almacén !! manda llamar el store procedure de registrar entrada movimientos de almacen
	---------------------------------------------------------------------------------------------------------------
	DECLARE @ReferenciaCompra  varchar(50)
	SET @ReferenciaCompra =	@SerieDocumento+'-'+RIGHT(REPLICATE('0', 10)+@FolioDocumento,10)
	EXEC @return_value	  = usp_ProMovimientosAlmacenRegistrarEntrada   @FolioMovimientoAlmacen,
																		@FechaHora,
																		@IdTipoMovimientoAlmacen,
																		@IdProveedor,
																		@ReferenciaCompra, 
																		@Estatus,
																		@Observaciones,
																		@SubTotal,
																		@Total,
																		@IdImpuestosTrasladadosFederales,
																		@ImpuestosTrasladadosFederales,
																		@IdImpuestosRetenidosFederales,
																		@ImpuestosRetenidosFederales,
																		@CreadoEl,
																		@CreadoPor,
																		@dsProMovimientosAlmacenConceptos,
																		@IdPeticion,
																		@IdMoneda,
																		@TipoCambio,
																		@IdCompra
			
	IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al registrar la entrada al almacén',
				16,
				1
				)


	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

