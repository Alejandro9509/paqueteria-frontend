
CREATE PROCEDURE [dbo].[usp_CatUsuariosContactosEliminar]
	@IdUsuarioContacto int,
	@IdPeticion varchar(100)	
	/* *************************************************************************************************
	Procedimiento [usp_CatUsuariosContactosEliminar]
	Descripción: El procedimiento se encarga de eliminar el contacto del usuario para eliminar la informacion. 
	Implementada por: Angel Espinoza.
	Fecha de implementacion: 11/10/2019
	Versión GMTERP: No cuenta con version

	Invocada desde: <GMTERPMOVIL, SERVERPROCEDURES, Eliminar(Execute [usp_CatUsuariosContactosEliminar])

	Solicitud 434
	***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdUsuarioContacto,0)= 0
		RAISERROR(N'El IdUsuarioContacto es un campo requerido',
			16,
			1
			)
	Delete from CatUsuariosContactos where IdUsuarioContacto = @IdUsuarioContacto
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

