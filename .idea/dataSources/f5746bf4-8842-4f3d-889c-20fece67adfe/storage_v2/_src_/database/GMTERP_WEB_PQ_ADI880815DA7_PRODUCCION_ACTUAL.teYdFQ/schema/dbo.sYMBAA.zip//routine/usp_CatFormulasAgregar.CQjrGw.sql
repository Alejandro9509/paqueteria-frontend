Create PROCEDURE [dbo].[usp_CatFormulasAgregar]
@Descripcion    varchar(50), 
@Formula  varchar(8000),   
@CreadoEl    datetime,    
@CreadoPor    int,    
@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION            
    IF ISNULL(@Descripcion,'')= ''
        RAISERROR(N'El nombre de la Formula es un campo requerido',
            16,
            1
            )
	IF ISNULL(@Formula,'')= ''
        RAISERROR(N'La definición de la Formula es un campo requerido',
            16,
            1
            )    
    INSERT INTO CatFormulas(Descripcion,Formula,CreadoEl,CreadoPor)
    VALUES(@Descripcion,@Formula,@CreadoEl,@CreadoPor)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

