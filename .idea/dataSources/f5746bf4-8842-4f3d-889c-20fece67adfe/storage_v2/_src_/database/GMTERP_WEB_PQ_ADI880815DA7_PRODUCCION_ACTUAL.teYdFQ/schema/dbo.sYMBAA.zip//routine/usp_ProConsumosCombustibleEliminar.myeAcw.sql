CREATE PROCEDURE [dbo].[usp_ProConsumosCombustibleEliminar]
	@IdConsumoCombustible int,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION	
	
	IF ISNULL(@IdConsumoCombustible,0)= 0
			RAISERROR(N'El identificador del registro del combustible es un campo requerido',
					16,
					1
					)
	
	IF EXISTS(SELECT IdConsumoCombustible FROM ProConsumosCombustible WHERE IdGastoViaje IS NOT NULL AND IdConsumoCombustible = @IdConsumoCombustible)
		RAISERROR(N'Registro convertido a gasto, no es posible eliminar.',
			16,
			1
			)
			
	IF NOT EXISTS(SELECT IdConsumoCombustible FROM ProConsumosCombustible WHERE IdConsumoCombustible = @IdConsumoCombustible)
		RAISERROR(N'El registro del combustible fue eliminado por otro usuario',
			16,
			1
			)
			
	IF EXISTS(SELECT pl.IdLiquidacion FROM ProConsumosCombustible AS pcc
				LEFT JOIN ProViajesTrayectos AS pvt ON pvt.IdViajeTrayecto = pcc.IdViajeTrayecto
				INNER JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
				LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion			
				WHERE pv.CanceladoEl IS NOT NULL AND pcc.IdConsumoCombustible = @IdConsumoCombustible)
		RAISERROR(N'No se puede eliminar el registro porque el viaje/trayecto tiene una liquidación referenciada',
			16,
			1
			)		

	--Eliminamos de ProConsumosCombustible
	Delete From ProConsumosCombustible where IdConsumoCombustible = @IdConsumoCombustible

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

