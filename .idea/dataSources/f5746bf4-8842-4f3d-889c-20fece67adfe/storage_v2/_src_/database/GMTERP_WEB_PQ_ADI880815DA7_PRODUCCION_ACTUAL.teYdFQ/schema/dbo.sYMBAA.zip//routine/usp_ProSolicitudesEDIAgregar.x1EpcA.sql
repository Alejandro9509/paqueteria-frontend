CREATE PROCEDURE [dbo].[usp_ProSolicitudesEDIAgregar]
    @IdentSolicitud varchar(100),
    @CarrierPro varchar(30),
    @Customer   varchar(30),    
    @Origen varchar(500),
    @Destino    varchar(500),
    @Cliente    varchar(150),
    @DireccionCliente   varchar(150),
    @EspecificacionesUnidad varchar(150),
    @EspecificacionesCarga  varchar(150),
    @FechaHoraSalida    datetime,
    @FechaHoraLlegada   datetime,
    @dsProSolicitudesEDIDetalles ntext,
    @CreadoEl   datetime,
    @CreadoPor  int,
    @IdPeticion varchar(100),
    @InterchangeReceiverID Varchar(50),
    @InterchangeIDQualifier Varchar(5),
    @IdentificadorSCAC Varchar(20),
    @RunNumber Varchar(20),
    @ManifestNumber Varchar(20),
    @CarrierAplicacion int,
    @SCACAplicacion varchar(20)

/*************************************************************************************************************************************
Descripción: Se agrego el paramtro @CarrierAplicacion y @SCACAplicacion

Modificada por:  Francisco Villela
Fecha de modificación: 10/12/2020

Invocada desde: ClsProSolicitudesEDI

Procedimiento almacenado usp_ProSolicitudesEDIAgregar
Parámetros: 
    @IdentSolicitud varchar(100),
    @CarrierPro varchar(30),
    @Customer   varchar(30),    
    @Origen varchar(500),
    @Destino    varchar(500),
    @Cliente    varchar(150),
    @DireccionCliente   varchar(150),
    @EspecificacionesUnidad varchar(150),
    @EspecificacionesCarga  varchar(150),
    @FechaHoraSalida    datetime,
    @FechaHoraLlegada   datetime,
    @dsProSolicitudesEDIDetalles ntext,
    @CreadoEl   datetime,
    @CreadoPor  int,
    @IdPeticion varchar(100),
    @InterchangeReceiverID Varchar(50),
    @InterchangeIDQualifier Varchar(5),
    @IdentificadorSCAC Varchar(20)
    @IdentL11 Varchar(5)

Descripción: Agrega las Solicitudes EDI

Modificada por:  Francisco Villela
Fecha de modificación: 23/09/2020

Descripción: Se agrego paramtro para grabar el identL11

Invocada desde: ClsProSolicitudesEDI


*************************************************************************************************************************************/
AS
DECLARE 
    @DoNotShipBefore varchar(100),--Nueva variable para la fecha del mensaje de aviso
    @docHandle int,
    @IdSolicitudEDI int,
    @IdentSolicitudYaExistente varchar(100)
BEGIN TRY
    BEGIN TRANSACTION
        Set @IdentSolicitudYaExistente =(Select Top 1 IdentSolicitud From ProSolicitudesEDI Where IdentSolicitud = @IdentSolicitud)
        
        IF ISNULL(@IdentSolicitudYaExistente,'') = ''
        BEGIN
        -----------------INSERTAR-------------------
            INSERT INTO ProSolicitudesEDI(CarrierPro,CreadoEl,CreadoPor,Customer,Destino,
            EspecificacionesCarga,EspecificacionesUnidad,FechaHoraLlegada,FechaHoraSalida,
            IdentSolicitud,Origen,Cliente,DireccionCliente,InterchangeReceiverID,InterchangeIDQualifier,IdentificadorSCAC,RunNumber,ManifestNumber,CarrierAplicacion,SCACAplicacion)
            VALUES(@CarrierPro,@CreadoEl,@CreadoPor,@Customer,dbo.fn_ConversionUTF8(@Destino),
            @EspecificacionesCarga,@EspecificacionesUnidad,@FechaHoraLlegada,@FechaHoraSalida,
            @IdentSolicitud,dbo.fn_ConversionUTF8(@Origen),dbo.fn_ConversionUTF8(@Cliente),dbo.fn_ConversionUTF8(@DireccionCliente),@InterchangeReceiverID,@InterchangeIDQualifier,@IdentificadorSCAC,@RunNumber,@ManifestNumber,@CarrierAplicacion,@SCACAplicacion)
            
            SET @IdSolicitudEDI = (SELECT IDENT_CURRENT('ProSolicitudesEDI'))
            
            IF @dsProSolicitudesEDIDetalles IS NOT NULL
            BEGIN
                EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProSolicitudesEDIDetalles

                SELECT ATT_IdentSolicitud,ATT_TransactionID,ATT_AccountingID,ATT_Purpose,ATT_Type,ATT_StopNum,
                ATT_StopReason,ATT_StopWeight,ATT_StopVolume,ATT_BOL,ATT_PONumber,ATT_TrackingNum,ATT_DockNum,
                ATT_CustomerOrder,ATT_RequestedPickupDate,ATT_RequestedPickupTime,ATT_RequestedDeliveryDate,
                ATT_RequestedDeliveryTime,ATT_DoNotShipBefore,ATT_ShipNoLaterThan,ATT_Weight,ATT_Pieces,ATT_Volume,
                ATT_PalletsShipped,ATT_PalletExchangeCode,ATT_ShipFromName,ATT_ShipFromAddress1,ATT_ShipFromAddress2,
                ATT_ShipFromCity,ATT_ShipFromState,ATT_ShipFromZip,ATT_ShipFromCountry,ATT_ShipFromAddressCode,
                ATT_ShipToName,ATT_ShipToAddress1,ATT_ShipToAddress2,ATT_ShipToCity,ATT_ShipToState,ATT_ShipToZip,
                ATT_ShipToCountry,ATT_ShipToAddressCode,ATT_ContactName,ATT_ContactPhone,ATT_LadingDecription,
                ATT_ReportRemarks,ATT_PaymentMethod,ATT_MustRespondByDate,ATT_MustRespondByTime,ATT_SCAC,ATT_ContinuousMove,
                ATT_CarrierID,ATT_MilesTotalDistance,ATT_Customer,ATT_Equipment,ATT_EquipmentDescription,ATT_TemperatureControl,
                ATT_EquipmentLength,ATT_TotalFreightWeight,ATT_TotalFreightCost,ATT_TotalFreightVolumeCube,ATT_BillToName,
                ATT_BillToAddress1,ATT_BillToCity,ATT_BillToState,ATT_BillToZip,ATT_BillToCountry,ATT_BillToCode,
                ATT_ContactName1,ATT_ContactPhone1,ATT_ReportRemarks1,ATT_Reference,ATT_PO,ATT_Quantity,ATT_UOM,
                ATT_Weight1,ATT_WeightUOM,ATT_VolumeCubicFeet,ATT_PaymentMethod1,ATT_LocationIdValue,ATT_Latitude,ATT_Longitude,
                ATT_WeightQualifier,ATT_WeightUnitCode,ATT_LadingQuantity
                INTO #TempProSolicitudesEDIDetalles
                FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProSolicitudesEDIDetalles',2) 
                WITH (ATT_IdentSolicitud    varchar(100),ATT_TransactionID  varchar(100),ATT_AccountingID   varchar(100),
                ATT_Purpose varchar(100),ATT_Type   varchar(150),ATT_StopNum    varchar(100),ATT_StopReason varchar(100),
                ATT_StopWeight  varchar(100),ATT_StopVolume varchar(100),ATT_BOL    varchar(100),ATT_PONumber   varchar(100),
                ATT_TrackingNum varchar(100),ATT_DockNum    varchar(100),ATT_CustomerOrder  varchar(100),ATT_RequestedPickupDate    varchar(100),
                ATT_RequestedPickupTime varchar(100),ATT_RequestedDeliveryDate  varchar(100),ATT_RequestedDeliveryTime  varchar(100),
                ATT_DoNotShipBefore varchar(100),ATT_ShipNoLaterThan    varchar(100),ATT_Weight varchar(100),ATT_Pieces varchar(100),
                ATT_Volume  varchar(100),ATT_PalletsShipped varchar(100),ATT_PalletExchangeCode varchar(100),ATT_ShipFromName   varchar(100),
                ATT_ShipFromAddress1    varchar(100),ATT_ShipFromAddress2   varchar(100),ATT_ShipFromCity   varchar(100),ATT_ShipFromState  varchar(100),
                ATT_ShipFromZip varchar(100),ATT_ShipFromCountry    varchar(100),ATT_ShipFromAddressCode    varchar(100),ATT_ShipToName varchar(100),
                ATT_ShipToAddress1  varchar(100),ATT_ShipToAddress2 varchar(100),ATT_ShipToCity varchar(100),ATT_ShipToState    varchar(100),
                ATT_ShipToZip   varchar(100),ATT_ShipToCountry  varchar(100),ATT_ShipToAddressCode  varchar(100),ATT_ContactName    varchar(100),
                ATT_ContactPhone    varchar(100),ATT_LadingDecription   varchar(100),ATT_ReportRemarks  varchar(100),ATT_PaymentMethod  varchar(100),
                ATT_MustRespondByDate   varchar(100),ATT_MustRespondByTime  varchar(100),ATT_SCAC   varchar(100),ATT_ContinuousMove varchar(100),
                ATT_CarrierID   varchar(100),ATT_MilesTotalDistance varchar(100),ATT_Customer   varchar(100),ATT_Equipment  varchar(100),
                ATT_EquipmentDescription    varchar(100),ATT_TemperatureControl varchar(100),ATT_EquipmentLength    varchar(100),ATT_TotalFreightWeight varchar(100),
                ATT_TotalFreightCost    varchar(100),ATT_TotalFreightVolumeCube varchar(100),ATT_BillToName varchar(100),ATT_BillToAddress1 varchar(100),
                ATT_BillToCity  varchar(100),ATT_BillToState    varchar(100),ATT_BillToZip  varchar(100),ATT_BillToCountry  varchar(100),ATT_BillToCode varchar(100),
                ATT_ContactName1    varchar(100),ATT_ContactPhone1  varchar(100),ATT_ReportRemarks1 varchar(100),ATT_Reference  varchar(100),
                ATT_PO  varchar(100),ATT_Quantity   varchar(100),ATT_UOM    varchar(100),ATT_Weight1    varchar(100),ATT_WeightUOM  varchar(100),
                ATT_VolumeCubicFeet varchar(100),ATT_PaymentMethod1 varchar(100),ATT_LocationIdValue varchar(30),ATT_Latitude Varchar (50),ATT_Longitude Varchar(50),
                ATT_WeightQualifier varchar(100),ATT_WeightUnitCode varchar(100),ATT_LadingQuantity varchar(100))

                EXEC sp_xml_removedocument @docHandle
                
                INSERT INTO ProSolicitudesEDIDetalles(CreadoEl,CreadoPor,IdSolicitudEDI,[IdentSolicitud],[TransactionID],[AccountingID],[Purpose],[Type]
                ,[StopNum],[StopReason],[StopWeight],[StopVolume],[BOL],[PONumber],[TrackingNum]
                ,[DockNum],[CustomerOrder],[RequestedPickupDate],[RequestedPickupTime],[RequestedDeliveryDate],[RequestedDeliveryTime]
                ,[DoNotShipBefore],[ShipNoLaterThan],[Weight],[Pieces],[Volume],[PalletsShipped],[PalletExchangeCode],[ShipFromName]
                ,[ShipFromAddress1],[ShipFromAddress2],[ShipFromCity],[ShipFromState],[ShipFromZip],[ShipFromCountry],[ShipFromAddressCode]
                ,[ShipToName],[ShipToAddress1],[ShipToAddress2],[ShipToCity],[ShipToState],[ShipToZip],[ShipToCountry],[ShipToAddressCode]
                ,[ContactName],[ContactPhone],[LadingDecription],[ReportRemarks],[PaymentMethod],[MustRespondByDate],[MustRespondByTime]
                ,[SCAC],[ContinuousMove],[CarrierID],[MilesTotalDistance],[Customer],[Equipment],[EquipmentDescription]
                ,[TemperatureControl],[EquipmentLength],[TotalFreightWeight],[TotalFreightCost],[TotalFreightVolumeCube]
                ,[BillToName],[BillToAddress1],[BillToCity],[BillToState],[BillToZip],[BillToCountry],[BillToCode],[ContactName1]
                ,[ContactPhone1],[ReportRemarks1],[Reference],[PO],[Quantity],[UOM],[Weight1],[WeightUOM],[VolumeCubicFeet],[PaymentMethod1],[LocationIdValue]
                ,[Latitude],[Longitude],[WeightQualifier],[WeightUnitCode],[LadingQuantity])
                SELECT @CreadoEl,@CreadoPor,@IdSolicitudEDI,[ATT_IdentSolicitud],[ATT_TransactionID],[ATT_AccountingID],[ATT_Purpose],[ATT_Type]
                ,[ATT_StopNum],[ATT_StopReason],[ATT_StopWeight],[ATT_StopVolume],[ATT_BOL],[ATT_PONumber],[ATT_TrackingNum]
                ,[ATT_DockNum],[ATT_CustomerOrder],[ATT_RequestedPickupDate],[ATT_RequestedPickupTime],[ATT_RequestedDeliveryDate],[ATT_RequestedDeliveryTime]
                ,[ATT_DoNotShipBefore],[ATT_ShipNoLaterThan],[ATT_Weight],[ATT_Pieces],[ATT_Volume],[ATT_PalletsShipped],[ATT_PalletExchangeCode],dbo.fn_ConversionUTF8([ATT_ShipFromName])
                ,dbo.fn_ConversionUTF8([ATT_ShipFromAddress1]),[ATT_ShipFromAddress2],dbo.fn_ConversionUTF8([ATT_ShipFromCity]),[ATT_ShipFromState],[ATT_ShipFromZip],dbo.fn_ConversionUTF8([ATT_ShipFromCountry]),[ATT_ShipFromAddressCode]
                ,dbo.fn_ConversionUTF8([ATT_ShipToName]),dbo.fn_ConversionUTF8([ATT_ShipToAddress1]),[ATT_ShipToAddress2],dbo.fn_ConversionUTF8([ATT_ShipToCity]),dbo.fn_ConversionUTF8([ATT_ShipToState]),[ATT_ShipToZip],dbo.fn_ConversionUTF8([ATT_ShipToCountry]),[ATT_ShipToAddressCode]
                ,[ATT_ContactName],[ATT_ContactPhone],[ATT_LadingDecription],[ATT_ReportRemarks],[ATT_PaymentMethod],[ATT_MustRespondByDate],[ATT_MustRespondByTime]
                ,[ATT_SCAC],[ATT_ContinuousMove],[ATT_CarrierID],[ATT_MilesTotalDistance],[ATT_Customer],[ATT_Equipment],[ATT_EquipmentDescription]
                ,[ATT_TemperatureControl],[ATT_EquipmentLength],[ATT_TotalFreightWeight],[ATT_TotalFreightCost],dbo.fn_ConversionUTF8([ATT_TotalFreightVolumeCube])
                ,dbo.fn_ConversionUTF8([ATT_BillToName]),dbo.fn_ConversionUTF8([ATT_BillToAddress1]),[ATT_BillToCity],[ATT_BillToState],[ATT_BillToZip],[ATT_BillToCountry],[ATT_BillToCode],[ATT_ContactName1]
                ,[ATT_ContactPhone1],[ATT_ReportRemarks1],[ATT_Reference],[ATT_PO],[ATT_Quantity],[ATT_UOM],[ATT_Weight1],[ATT_WeightUOM],[ATT_VolumeCubicFeet]
                ,[ATT_PaymentMethod1],dbo.fn_ConversionUTF8([ATT_LocationIdValue]),[ATT_Latitude],[ATT_Longitude],
                [ATT_WeightQualifier],[ATT_WeightUnitCode],[ATT_LadingQuantity]
                FROM #TempProSolicitudesEDIDetalles
            END
    
        --se hace un Select para traer la fecha que mostrara el aviso de la solicitud EDI
        SET @DoNotShipBefore=(SELECT TOP 1 [DoNotShipBefore] FROM [ProSolicitudesEDIDetalles]WHERE IdSolicitudEDI = @IdSolicitudEDI AND ISNULL(DoNotShipBefore,'') <> '')
        -----------------FIN DE INSERTAR------------
        -----------------AVISO----------------------
        Insert into SisAvisos(Asunto,Aviso,CreadoEl,CreadoPor,EnviarEl,RecordarCadaMin,AtendidoPor,AtendidoEl,ComentariosAtendio,EnviarTodosLosUsuarios)
        values('','Has recibido una solicitud de Viaje del cliente '+dbo.fn_ConversionUTF8(@Cliente)+', dentro de tu Modulo EDI. Se pide respuesta antes de '+@DoNotShipBefore,@CreadoEl,@CreadoPor,@CreadoEl,5,NULL,NULL,NULL,1)
        
        END
        ELSE
        BEGIN
        -----------------MODIFICAR------------------
            SET  @IdSolicitudEDI= (Select Top 1 IdSolicitudEDI From ProSolicitudesEDI Where IdentSolicitud = @IdentSolicitud)
            
            UPDATE ProSolicitudesEDI SET 
                CarrierPro=@CarrierPro,
                ModificadoEl = @CreadoEl,
                ModificadoPor = @CreadoPor,
                Customer = @Customer,
                Destino = dbo.fn_ConversionUTF8(@Destino),
                EspecificacionesCarga = @EspecificacionesCarga,
                EspecificacionesUnidad = @EspecificacionesUnidad,
                FechaHoraLlegada=@FechaHoraLlegada,
                FechaHoraSalida=@FechaHoraSalida,
                Origen=dbo.fn_ConversionUTF8(@Origen),
                Cliente=dbo.fn_ConversionUTF8(@Cliente),
                DireccionCliente=dbo.fn_ConversionUTF8(@DireccionCliente),
                InterchangeReceiverID =@InterchangeReceiverID,
                InterchangeIDQualifier=@InterchangeIDQualifier,
                IdentificadorSCAC = @IdentificadorSCAC,
                RunNumber = @RunNumber,
                ManifestNumber =@ManifestNumber,
                CarrierAplicacion = @CarrierAplicacion,
                SCACAplicacion = @SCACAplicacion
            WHERE IdSolicitudEDI = @IdSolicitudEDI 
            
            --Borrar el detalle existente para agregar el nuevo
            Delete ProSolicitudesEDIDetalles where IdSolicitudEDI = @IdSolicitudEDI
            --Se agrega de nuevo 
            IF @dsProSolicitudesEDIDetalles IS NOT NULL
            BEGIN
                EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProSolicitudesEDIDetalles

                SELECT ATT_IdentSolicitud,ATT_TransactionID,ATT_AccountingID,ATT_Purpose,ATT_Type,ATT_StopNum,
                ATT_StopReason,ATT_StopWeight,ATT_StopVolume,ATT_BOL,ATT_PONumber,ATT_TrackingNum,ATT_DockNum,
                ATT_CustomerOrder,ATT_RequestedPickupDate,ATT_RequestedPickupTime,ATT_RequestedDeliveryDate,
                ATT_RequestedDeliveryTime,ATT_DoNotShipBefore,ATT_ShipNoLaterThan,ATT_Weight,ATT_Pieces,ATT_Volume,
                ATT_PalletsShipped,ATT_PalletExchangeCode,ATT_ShipFromName,ATT_ShipFromAddress1,ATT_ShipFromAddress2,
                ATT_ShipFromCity,ATT_ShipFromState,ATT_ShipFromZip,ATT_ShipFromCountry,ATT_ShipFromAddressCode,
                ATT_ShipToName,ATT_ShipToAddress1,ATT_ShipToAddress2,ATT_ShipToCity,ATT_ShipToState,ATT_ShipToZip,
                ATT_ShipToCountry,ATT_ShipToAddressCode,ATT_ContactName,ATT_ContactPhone,ATT_LadingDecription,
                ATT_ReportRemarks,ATT_PaymentMethod,ATT_MustRespondByDate,ATT_MustRespondByTime,ATT_SCAC,ATT_ContinuousMove,
                ATT_CarrierID,ATT_MilesTotalDistance,ATT_Customer,ATT_Equipment,ATT_EquipmentDescription,ATT_TemperatureControl,
                ATT_EquipmentLength,ATT_TotalFreightWeight,ATT_TotalFreightCost,ATT_TotalFreightVolumeCube,ATT_BillToName,
                ATT_BillToAddress1,ATT_BillToCity,ATT_BillToState,ATT_BillToZip,ATT_BillToCountry,ATT_BillToCode,
                ATT_ContactName1,ATT_ContactPhone1,ATT_ReportRemarks1,ATT_Reference,ATT_PO,ATT_Quantity,ATT_UOM,
                ATT_Weight1,ATT_WeightUOM,ATT_VolumeCubicFeet,ATT_PaymentMethod1,ATT_LocationIdValue,ATT_Latitude,ATT_Longitude,
                ATT_WeightQualifier,ATT_WeightUnitCode,ATT_LadingQuantity
                INTO #TempProSolicitudesEDIDetalles2
                FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProSolicitudesEDIDetalles',2) 
                WITH (ATT_IdentSolicitud    varchar(100),ATT_TransactionID  varchar(100),ATT_AccountingID   varchar(100),
                ATT_Purpose varchar(100),ATT_Type   varchar(150),ATT_StopNum    varchar(100),ATT_StopReason varchar(100),
                ATT_StopWeight  varchar(100),ATT_StopVolume varchar(100),ATT_BOL    varchar(100),ATT_PONumber   varchar(100),
                ATT_TrackingNum varchar(100),ATT_DockNum    varchar(100),ATT_CustomerOrder  varchar(100),ATT_RequestedPickupDate    varchar(100),
                ATT_RequestedPickupTime varchar(100),ATT_RequestedDeliveryDate  varchar(100),ATT_RequestedDeliveryTime  varchar(100),
                ATT_DoNotShipBefore varchar(100),ATT_ShipNoLaterThan    varchar(100),ATT_Weight varchar(100),ATT_Pieces varchar(100),
                ATT_Volume  varchar(100),ATT_PalletsShipped varchar(100),ATT_PalletExchangeCode varchar(100),ATT_ShipFromName   varchar(100),
                ATT_ShipFromAddress1    varchar(100),ATT_ShipFromAddress2   varchar(100),ATT_ShipFromCity   varchar(100),ATT_ShipFromState  varchar(100),
                ATT_ShipFromZip varchar(100),ATT_ShipFromCountry    varchar(100),ATT_ShipFromAddressCode    varchar(100),ATT_ShipToName varchar(100),
                ATT_ShipToAddress1  varchar(100),ATT_ShipToAddress2 varchar(100),ATT_ShipToCity varchar(100),ATT_ShipToState    varchar(100),
                ATT_ShipToZip   varchar(100),ATT_ShipToCountry  varchar(100),ATT_ShipToAddressCode  varchar(100),ATT_ContactName    varchar(100),
                ATT_ContactPhone    varchar(100),ATT_LadingDecription   varchar(100),ATT_ReportRemarks  varchar(100),ATT_PaymentMethod  varchar(100),
                ATT_MustRespondByDate   varchar(100),ATT_MustRespondByTime  varchar(100),ATT_SCAC   varchar(100),ATT_ContinuousMove varchar(100),
                ATT_CarrierID   varchar(100),ATT_MilesTotalDistance varchar(100),ATT_Customer   varchar(100),ATT_Equipment  varchar(100),
                ATT_EquipmentDescription    varchar(100),ATT_TemperatureControl varchar(100),ATT_EquipmentLength    varchar(100),ATT_TotalFreightWeight varchar(100),
                ATT_TotalFreightCost    varchar(100),ATT_TotalFreightVolumeCube varchar(100),ATT_BillToName varchar(100),ATT_BillToAddress1 varchar(100),
                ATT_BillToCity  varchar(100),ATT_BillToState    varchar(100),ATT_BillToZip  varchar(100),ATT_BillToCountry  varchar(100),ATT_BillToCode varchar(100),
                ATT_ContactName1    varchar(100),ATT_ContactPhone1  varchar(100),ATT_ReportRemarks1 varchar(100),ATT_Reference  varchar(100),
                ATT_PO  varchar(100),ATT_Quantity   varchar(100),ATT_UOM    varchar(100),ATT_Weight1    varchar(100),ATT_WeightUOM  varchar(100),
                ATT_VolumeCubicFeet varchar(100),ATT_PaymentMethod1 varchar(100),ATT_LocationIdValue Varchar(30),ATT_Latitude Varchar(50),ATT_Longitude Varchar(50),
                ATT_WeightQualifier varchar(100),ATT_WeightUnitCode varchar(100),ATT_LadingQuantity varchar(100))

                EXEC sp_xml_removedocument @docHandle
                
                INSERT INTO ProSolicitudesEDIDetalles(CreadoEl,CreadoPor,IdSolicitudEDI,[IdentSolicitud],[TransactionID],[AccountingID],[Purpose],[Type]
                ,[StopNum],[StopReason],[StopWeight],[StopVolume],[BOL],[PONumber],[TrackingNum]
                ,[DockNum],[CustomerOrder],[RequestedPickupDate],[RequestedPickupTime],[RequestedDeliveryDate],[RequestedDeliveryTime]
                ,[DoNotShipBefore],[ShipNoLaterThan],[Weight],[Pieces],[Volume],[PalletsShipped],[PalletExchangeCode],[ShipFromName]
                ,[ShipFromAddress1],[ShipFromAddress2],[ShipFromCity],[ShipFromState],[ShipFromZip],[ShipFromCountry],[ShipFromAddressCode]
                ,[ShipToName],[ShipToAddress1],[ShipToAddress2],[ShipToCity],[ShipToState],[ShipToZip],[ShipToCountry],[ShipToAddressCode]
                ,[ContactName],[ContactPhone],[LadingDecription],[ReportRemarks],[PaymentMethod],[MustRespondByDate],[MustRespondByTime]
                ,[SCAC],[ContinuousMove],[CarrierID],[MilesTotalDistance],[Customer],[Equipment],[EquipmentDescription]
                ,[TemperatureControl],[EquipmentLength],[TotalFreightWeight],[TotalFreightCost],[TotalFreightVolumeCube]
                ,[BillToName],[BillToAddress1],[BillToCity],[BillToState],[BillToZip],[BillToCountry],[BillToCode],[ContactName1]
                ,[ContactPhone1],[ReportRemarks1],[Reference],[PO],[Quantity],[UOM],[Weight1],[WeightUOM],[VolumeCubicFeet],[PaymentMethod1],[LocationIdValue]
                ,[Latitude],[Longitude],[WeightQualifier],[WeightUnitCode],[LadingQuantity])
                SELECT @CreadoEl,@CreadoPor,@IdSolicitudEDI,[ATT_IdentSolicitud],[ATT_TransactionID],[ATT_AccountingID],[ATT_Purpose],[ATT_Type]
                ,[ATT_StopNum],[ATT_StopReason],[ATT_StopWeight],[ATT_StopVolume],[ATT_BOL],[ATT_PONumber],[ATT_TrackingNum]
                ,[ATT_DockNum],[ATT_CustomerOrder],[ATT_RequestedPickupDate],[ATT_RequestedPickupTime],[ATT_RequestedDeliveryDate],[ATT_RequestedDeliveryTime]
                ,[ATT_DoNotShipBefore],[ATT_ShipNoLaterThan],[ATT_Weight],[ATT_Pieces],[ATT_Volume],[ATT_PalletsShipped],[ATT_PalletExchangeCode],dbo.fn_ConversionUTF8([ATT_ShipFromName])
                ,dbo.fn_ConversionUTF8([ATT_ShipFromAddress1]),[ATT_ShipFromAddress2],dbo.fn_ConversionUTF8([ATT_ShipFromCity]),[ATT_ShipFromState],[ATT_ShipFromZip],dbo.fn_ConversionUTF8([ATT_ShipFromCountry]),[ATT_ShipFromAddressCode]
                ,dbo.fn_ConversionUTF8([ATT_ShipToName]),dbo.fn_ConversionUTF8([ATT_ShipToAddress1]),[ATT_ShipToAddress2],dbo.fn_ConversionUTF8([ATT_ShipToCity]),dbo.fn_ConversionUTF8([ATT_ShipToState]),[ATT_ShipToZip],dbo.fn_ConversionUTF8([ATT_ShipToCountry]),[ATT_ShipToAddressCode]
                ,[ATT_ContactName],[ATT_ContactPhone],[ATT_LadingDecription],[ATT_ReportRemarks],[ATT_PaymentMethod],[ATT_MustRespondByDate],[ATT_MustRespondByTime]
                ,[ATT_SCAC],[ATT_ContinuousMove],[ATT_CarrierID],[ATT_MilesTotalDistance],[ATT_Customer],[ATT_Equipment],[ATT_EquipmentDescription]
                ,[ATT_TemperatureControl],[ATT_EquipmentLength],[ATT_TotalFreightWeight],[ATT_TotalFreightCost],dbo.fn_ConversionUTF8([ATT_TotalFreightVolumeCube])
                ,dbo.fn_ConversionUTF8([ATT_BillToName]),dbo.fn_ConversionUTF8([ATT_BillToAddress1]),[ATT_BillToCity],[ATT_BillToState],[ATT_BillToZip],[ATT_BillToCountry],[ATT_BillToCode],[ATT_ContactName1]
                ,[ATT_ContactPhone1],[ATT_ReportRemarks1],[ATT_Reference],[ATT_PO],[ATT_Quantity],[ATT_UOM],[ATT_Weight1],[ATT_WeightUOM],[ATT_VolumeCubicFeet]
                ,[ATT_PaymentMethod1],dbo.fn_ConversionUTF8([ATT_LocationIdValue]),[ATT_Latitude],[ATT_Longitude],
                [ATT_WeightQualifier],[ATT_WeightUnitCode],[ATT_LadingQuantity]
                FROM #TempProSolicitudesEDIDetalles2
            END

        
        -----------------FIN DE MODIFICAR-----------
        -----------------AVISO----------------------
        SET @DoNotShipBefore=(SELECT TOP 1 [DoNotShipBefore] FROM [ProSolicitudesEDIDetalles]WHERE IdSolicitudEDI = @IdSolicitudEDI AND ISNULL(DoNotShipBefore,'') <> '')

        Insert into SisAvisos(Asunto,Aviso,CreadoEl,CreadoPor,EnviarEl,RecordarCadaMin,AtendidoPor,AtendidoEl,ComentariosAtendio,EnviarTodosLosUsuarios)
        values('','Has recibido una solicitud de Viaje del cliente '+dbo.fn_ConversionUTF8(@Cliente)+', dentro de tu Modulo EDI. Se pide respuesta antes de '+@DoNotShipBefore,@CreadoEl,@CreadoPor,@CreadoEl,5,NULL,NULL,NULL,1)
        END 
        
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

