
Create PROCEDURE [dbo].[usp_CatFormulasModificar]
@IdFormula	int,
@Descripcion	varchar(50),	
@Formula	varchar(8000),	
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdFormula,0)= 0
	RAISERROR(N'El identificador de la formula es un campo requerido',
			16,
			1
			)	
							
	IF ISNULL(@Descripcion,'')= ''
		RAISERROR(N'El nombre de la formula es un campo requerido',
			16,
			1
			)
	IF ISNULL(@Formula,'')= ''
		RAISERROR(N'La definición de ll formula es un campo requerido',
			16,
			1
			)			
			
	UPDATE CatFormulas SET
	Descripcion= @Descripcion,
	Formula= @Formula,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor
	WHERE 	IdFormula=@IdFormula
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

