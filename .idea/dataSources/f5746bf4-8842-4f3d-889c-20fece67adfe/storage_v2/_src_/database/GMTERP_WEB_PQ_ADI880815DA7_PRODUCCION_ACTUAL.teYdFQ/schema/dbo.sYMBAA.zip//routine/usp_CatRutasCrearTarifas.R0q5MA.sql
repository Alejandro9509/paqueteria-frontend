CREATE PROCEDURE [dbo].[usp_CatRutasCrearTarifas]
@dsCatRutasTrayectosPermisionarios	text,
@CreadoEl	datetime,	
@CreadoPor	int,	
@IdPeticion varchar(100)	,
@Sesion varchar(100)
AS DECLARE
@docHandle int,
@ATT_IdRutaTrayecto int,
@ATT_IdOperador int,
@ATT_FolioRuta varchar(10),
@ATT_Cliente varchar(150),
@ATT_Secuencia int,
@ATT_Operador varchar(100),
@ATT_SueldoBaseFullCargado money,
@ATT_SueldoBaseFullVacio money, 
@ATT_SueldoBaseFullVacioCargado_CargadoVacio money,
@ATT_SueldoBaseSencilloCargado money,
@ATT_SueldoBaseSencilloVacio money,
@ATT_SueldoBaseDllsFullCargado money,
@ATT_SueldoBaseDllsFullVacio money,
@ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio money,
@ATT_SueldoBaseDllsSencilloCargado money,
@ATT_SueldoBaseDllsSencilloVacio money,
@Resultado varchar(100)
BEGIN TRY
	BEGIN TRANSACTION
	
	IF @dsCatRutasTrayectosPermisionarios IS NULL
		RAISERROR(N'No hay Operadores Permisionarios/Trayectos asignados.',
			16,
			1
			)
			
	IF OBJECT_ID('#ResultadoCatRutasTrayectosPermisionarios') IS NOT NULL
	BEGIN
		DROP TABLE #ResultadoCatRutasTrayectosPermisionarios
	END
	ELSE
	BEGIN
		CREATE TABLE #ResultadoCatRutasTrayectosPermisionarios(FolioRuta varchar(10),Cliente varchar(150),Operador varchar(100),Resultado varchar(100),CreadoPor int)		
	END

	IF @dsCatRutasTrayectosPermisionarios IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectosPermisionarios
             
			SELECT ATT_IdRutaTrayecto,ATT_IdOperador,ATT_FolioRuta,ATT_Cliente,ATT_Secuencia,ATT_Operador,
			ATT_SueldoBaseDllsFullVacio,ATT_SueldoBaseDllsSencilloVacio,ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,
			ATT_SueldoBaseDllsFullCargado,ATT_SueldoBaseDllsSencilloCargado,ATT_SueldoBaseFullVacio,ATT_SueldoBaseSencilloVacio,
			ATT_SueldoBaseFullVacioCargado_CargadoVacio,ATT_SueldoBaseFullCargado,ATT_SueldoBaseSencilloCargado
			INTO #TempRutasTrayectosPermisionarios
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosPermisionarios',3) 
			WITH (ATT_IdRutaTrayecto int,ATT_IdOperador int,ATT_FolioRuta varchar(19),ATT_Cliente varchar(150),ATT_Secuencia int,ATT_Operador varchar(100),
			ATT_SueldoBaseDllsFullVacio money,ATT_SueldoBaseDllsSencilloVacio money,ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio money,
			ATT_SueldoBaseDllsFullCargado money,ATT_SueldoBaseDllsSencilloCargado money,ATT_SueldoBaseFullVacio money,ATT_SueldoBaseSencilloVacio money,
			ATT_SueldoBaseFullVacioCargado_CargadoVacio money,ATT_SueldoBaseFullCargado money,ATT_SueldoBaseSencilloCargado money)

			EXEC sp_xml_removedocument @docHandle
			DECLARE RutasTrayectosPermisionariosCursor CURSOR FOR
			SELECT * FROM #TempRutasTrayectosPermisionarios

			OPEN RutasTrayectosPermisionariosCursor
			FETCH NEXT FROM RutasTrayectosPermisionariosCursor
			INTO @ATT_IdRutaTrayecto,@ATT_IdOperador,@ATT_FolioRuta,@ATT_Cliente,@ATT_Secuencia,@ATT_Operador,
			@ATT_SueldoBaseDllsFullVacio ,@ATT_SueldoBaseDllsSencilloVacio,@ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,
			@ATT_SueldoBaseDllsFullCargado ,@ATT_SueldoBaseDllsSencilloCargado ,@ATT_SueldoBaseFullVacio,@ATT_SueldoBaseSencilloVacio,
			@ATT_SueldoBaseFullVacioCargado_CargadoVacio ,@ATT_SueldoBaseFullCargado ,@ATT_SueldoBaseSencilloCargado
		
			WHILE @@FETCH_STATUS = 0
			BEGIN
			
				IF EXISTS((Select IdRutaTrayectoPermisionario From CatRutasTrayectosPermisionarios WHERE IdRutaTrayecto = @ATT_IdRutaTrayecto AND IdOperador = @ATT_IdOperador))
				BEGIN
						SET @Resultado = 'El Operador Permisionario ya está asignado en la Ruta.'+' Secuencia:'+cast(@ATT_Secuencia as varchar)
				END	
				ELSE
				BEGIN
					INSERT INTO CatRutasTrayectosPermisionarios(IdRutaTrayecto,IdOperador,SueldoBaseFullCargado,SueldoBaseFullVacio,
					SueldoBaseFullVacioCargado_CargadoVacio,SueldoBaseSencilloCargado,SueldoBaseSencilloVacio,SueldoBaseDllsFullCargado,
					SueldoBaseDllsFullVacio,SueldoBaseDllsFullVacioCargado_CargadoVacio,SueldoBaseDllsSencilloCargado,
					SueldoBaseDllsSencilloVacio,CreadoEl,CreadoPor,PorcentajeComisionPermisionario,CuotaPorKilometro,CuotaDiaria,ImporteSeguro)
					VALUES(@ATT_IdRutaTrayecto,@ATT_IdOperador,@ATT_SueldoBaseFullCargado,@ATT_SueldoBaseFullVacio,
					@ATT_SueldoBaseFullVacioCargado_CargadoVacio,@ATT_SueldoBaseSencilloCargado,@ATT_SueldoBaseSencilloVacio,@ATT_SueldoBaseDllsFullCargado,
					@ATT_SueldoBaseDllsFullVacio,@ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,@ATT_SueldoBaseDllsSencilloCargado,
					@ATT_SueldoBaseDllsSencilloVacio,@CreadoEl,@CreadoPor,0,0,0,0)
					/*bitacora*/
					INSERT INTO SisBitacoras (IdUsuario,IdSesion,IdProceso,FechaHora,Referencia, Adicional)
					VALUES(@CreadoPor,@Sesion,510208,@CreadoEl,'Ruta:'+@ATT_FolioRuta+' Operador:'+@ATT_Operador+' Cliente:'+@ATT_Cliente+' Secuencia:'+cast(@ATT_Secuencia as varchar), '')
					SET @Resultado = 'El Operador Permisionario se asigno en la Ruta.'+' Secuencia:'+cast(@ATT_Secuencia as varchar)
				END

				INSERT INTO #ResultadoCatRutasTrayectosPermisionarios(FolioRuta,Cliente,Operador,Resultado,CreadoPor)	
				VALUES(@ATT_FolioRuta,@ATT_Cliente,@ATT_Operador,@Resultado,@CreadoPor)

			FETCH NEXT FROM RutasTrayectosPermisionariosCursor
				INTO @ATT_IdRutaTrayecto,@ATT_IdOperador,@ATT_FolioRuta,@ATT_Cliente,@ATT_Secuencia,@ATT_Operador,
				@ATT_SueldoBaseDllsFullVacio ,@ATT_SueldoBaseDllsSencilloVacio,@ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,
				@ATT_SueldoBaseDllsFullCargado ,@ATT_SueldoBaseDllsSencilloCargado ,@ATT_SueldoBaseFullVacio,@ATT_SueldoBaseSencilloVacio,
				@ATT_SueldoBaseFullVacioCargado_CargadoVacio ,@ATT_SueldoBaseFullCargado ,@ATT_SueldoBaseSencilloCargado
			END

			CLOSE RutasTrayectosPermisionariosCursor
			DEALLOCATE RutasTrayectosPermisionariosCursor
			
		END

		SELECT * FROM #ResultadoCatRutasTrayectosPermisionarios WHERE CreadoPor = @CreadoPor

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

