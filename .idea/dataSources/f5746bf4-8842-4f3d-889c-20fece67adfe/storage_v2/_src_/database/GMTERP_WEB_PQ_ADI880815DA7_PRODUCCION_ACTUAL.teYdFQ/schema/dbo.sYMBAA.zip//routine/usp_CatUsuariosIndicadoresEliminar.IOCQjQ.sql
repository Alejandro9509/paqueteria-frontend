
CREATE PROCEDURE [dbo].[usp_CatUsuariosIndicadoresEliminar]
	@IdUsuario int,
	@Iframe tinyint,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
		
		DELETE FROM CatUsuariosIndicadores WHERE IdUsuario = @IdUsuario AND Iframe = @Iframe
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

