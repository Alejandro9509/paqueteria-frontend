CREATE PROCEDURE [dbo].[usp_CatCombustiblesEliminar]
@IdCombustible int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdCombustible,0)= 0
	RAISERROR(N'El identificador de combustible es un campo requerido',
			16,
			1
			)
	IF Exists(Select * From CatProveedoresIEPS Where IdCombustible = @IdCombustible)
	RAISERROR(N'No se puede eliminar el combustible porque tiene Proveedores IEPS ligados',
			16,
			1
			)
	IF Exists(Select * From ProFacturas Where IdCombustible = @IdCombustible)
	RAISERROR(N'No se puede eliminar el combustible porque tiene Documentos ligados',
			16,
			1
			)
	IF Exists(Select * From ProViajes Where IdCombustible = @IdCombustible)
	RAISERROR(N'No se puede eliminar el combustible porque tiene Viajes ligados',
			16,
			1
			)
			
		DELETE CatCombustibles
		WHERE 	IdCombustible=@IdCombustible
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

