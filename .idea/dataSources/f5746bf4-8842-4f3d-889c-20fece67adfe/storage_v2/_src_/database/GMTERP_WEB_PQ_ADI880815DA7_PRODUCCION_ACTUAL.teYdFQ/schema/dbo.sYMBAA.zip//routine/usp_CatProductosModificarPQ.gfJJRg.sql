
CREATE PROCEDURE [dbo].[usp_CatProductosModificarPQ](
	@IdProducto int,
	@ID int,
	@Descripcion varchar(50))

	AS
BEGIN 
	BEGIN TRANSACTION

	IF ISNULL(@IdProducto, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Producto requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
			IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La Descripción es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@ID, 0) <= 0 begin
			RAISERROR(N'*INICIO*El ID del producto es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
		

		UPDATE CatProductosPQ SET
		IdEmbalaje=@ID , --antes era ID pero parece que no existe una columna 
		--que se llame asi por lo que supongo era IdEmbalaje porque IdProducto no se puede actualizar
		Descripcion=@Descripcion 
		 
		WHERE IdProducto = @IdProducto;
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
end
go

