CREATE PROCEDURE [dbo].[usp_ProMovimientosAlmacenRegistrarTraspaso]  
	@FechaHoraTraspaso Datetime,
	@IdAlmacenOrigen Int,
	@IdAlmacenDestino Int,
	@IdTipoMovimientoAlmacenOrigen int,  
	@IdTipoMovimientoAlmacenDestino int,  
	@Referencia varchar(500),
	@Estatus tinyint,
	@Observaciones varchar(512),
	@dsProMovimientosAlmacenConceptosSalida ntext,
	@CreadoPor int,  
	@CreadoEl datetime,  
	@IdPeticion varchar(100),
	@dsProMovimientosAlmacenConceptosEntrada ntext,
	@IdMoneda int,
	@TipoCambio money,
	@dsProArticulosDetallados ntext = NULL, --SOL 168
	@Folio int = 0 --SOL 168
	/* *************************************************************************************************
	SOLICITUD 168

	Descripcion: Se agrego @dsProMovimientosAlmacenConceptosEntrada que trae los numeros economicos de los articulos para su traspaso a otro almacen
	
	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 25/09/2019
	Versión: Versión 8.0.46.21

	Invocada desde: <PAGE_ProMovimientosAlmacenTraspasoR >
	************************************************************************************************ */
AS  
SET XACT_ABORT ON 	
DECLARE   
	@IdMovimientoAlmacenSalida int,
	@IdMovimientoAlmacenEntrada int,
	@FolioMovimientoAlmacenSalida int,
	@FolioMovimientoAlmacenEntrada int,
	@IdMovimientoAlmacenConceptoSalida int,
	@return_value int,
	@IdMovimientoAlmacenTraspaso int,
	@docHandle int,

	@CursorIdProMovimientoDetallado int,
	@CursorIdAlmacen int
	
BEGIN TRY  
 BEGIN TRANSACTION  

	IF ISDATE(@FechaHoraTraspaso) = 0			
			RAISERROR(N'La fecha de traspaso es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@IdAlmacenOrigen,0)=0
		RAISERROR(N'Identificador de almacén origen es un campo requerido',
			16,
			1
			)		
			
	IF ISNULL(@IdAlmacenDestino,0)=0
		RAISERROR(N'Identificador de almacén destino es un campo requerido',
			16,
			1
			)	
			
	IF 	@IdAlmacenOrigen = @IdAlmacenDestino	
			RAISERROR(N'Almacén origen y destino deben ser diferentes',
			16,
			1
			)	

			
	---14 Tipo salida por traspaso
	IF ISNULL(@IdTipoMovimientoAlmacenOrigen,0)=0
		RAISERROR(N'El tipo de movimiento de almacén de salida por traspaso es un campo requerido',
			16,
			1
			)		

	---15 Tipo entrada por traspaso
	IF ISNULL(@IdTipoMovimientoAlmacenDestino,0)=0
		RAISERROR(N'El tipo de movimiento de almacén de entrada por traspaso es un campo requerido',
			16,
			1
			)		
		
	IF @dsProMovimientosAlmacenConceptosSalida IS NULL OR @dsProMovimientosAlmacenConceptosEntrada IS NULL
		RAISERROR(N'Los conceptos del movimiento de almacén son requeridos',
			16,
			1
			)	

	IF ISNULL(@IdMoneda ,0)=0
			RAISERROR(N'La moneda es un campo requerido',
				16,
				1
				)	

	IF ISNULL(@TipoCambio,0) = 0		 
			RAISERROR(N'El tipo de cambio es un campo requerido',
				16,
				1
				)

	IF EXISTS(SELECT Folio FROM ProMovimientosAlmacen WHERE Folio = @Folio) --SOLICITUD 168 Se valida la concurrencia
		RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar.',
			16,
			1
			)
								
	-- GENERA SALIDA
	SET @FolioMovimientoAlmacenSalida = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)

	--SALIDA
	 EXEC @return_value = usp_ProMovimientosAlmacenRegistrarSalida 
						 @FolioMovimientoAlmacenSalida,
						 @FechaHoraTraspaso,
						 @IdTipoMovimientoAlmacenOrigen,
						 0,  -- Proveedor
						 @Referencia , -- Referencia
						 @Estatus,  -- Estatus
						 @Observaciones, -- Observaciones
						 @CreadoEl,
						 @CreadoPor,
						 @dsProMovimientosAlmacenConceptosSalida ,
						 @IdPeticion,
						 @IdMoneda,
						 @TipoCambio,
						 @dsProArticulosDetallados,
						 NULL, -- IdConsumidor
						 1 -- EsTraspaso


			 IF @return_value <> 0
					RAISERROR(N'Ocurrió un error al registrar la salida de almacén origen',
							16,
							1
							)
	
	-- GENERA ENTRADA							
	SET @FolioMovimientoAlmacenEntrada = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)
	--manda llamar el store procedure de registrar entrada movimientos de almacen
	EXEC @return_value = usp_ProMovimientosAlmacenRegistrarEntrada 
						@FolioMovimientoAlmacenEntrada,
						@FechaHoraTraspaso,
						@IdTipoMovimientoAlmacenDestino,
						0, -- Proveedor
						@Referencia, -- Referencia
						@Estatus,    -- Estatus
						@Observaciones,   --- Observaciones
						0,  --Subtotal
						0,  --Tottal
						NULL,     
						NULL,
						NULL,
						NULL,
						@CreadoEl,
						@CreadoPor,
						@dsProMovimientosAlmacenConceptosEntrada,
						@IdPeticion,
						@IdMoneda, -- IdMoneda PESOS
						@TipoCambio, -- Tipo de cambio
						NULL, -- IdCompra
						@dsProArticulosDetallados,
						NULL,	-- dsProArticulosLlantas
						1	--EsTraspaso
			
	IF @return_value <> 0
			RAISERROR(N'Ocurrió un error al registrar la entrada de almacén destino',
						16,
						1
						)
					
	SET @IdMovimientoAlmacenSalida  = (SELECT IdMovimientoAlmacen From ProMovimientosAlmacen where Folio = @FolioMovimientoAlmacenSalida)
	SET @IdMovimientoAlmacenEntrada = (SELECT IdMovimientoAlmacen From ProMovimientosAlmacen where Folio = @FolioMovimientoAlmacenEntrada)

	-- GUARDAR EN LA TABLA TRASPASO
	INSERT INTO ProMovimientosAlmacenTraspasos(IdMovimientoAlmacenSalida,IdMovimientoAlmacenEntrada,IdAlmacenOrigen,IdAlmacenDestino,FechaHoraTraspaso,CreadoPor,CreadoEl,IdMoneda,TipoCambio) 
	VALUES (@IdMovimientoAlmacenSalida,@IdMovimientoAlmacenEntrada,@IdAlmacenOrigen,@IdAlmacenDestino,@FechaHoraTraspaso,@CreadoPor,@CreadoEl,@IdMoneda,@TipoCambio)
	
	SET @IdMovimientoAlmacenTraspaso = (SELECT IDENT_CURRENT('ProMovimientosAlmacenTraspasos'))
	--seccion para agregar el idViaje a paremtros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoAlmacenTraspaso' AND IdUsuario = @CreadoPor)
	INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoAlmacenTraspaso',@IdMovimientoAlmacenTraspaso,@CreadoPor)
	ELSE
	UPDATE SisParametrosPagina SET Parametros = @IdMovimientoAlmacenTraspaso WHERE Pagina = 'IdMovimientoAlmacenTraspaso' AND IdUsuario = @CreadoPor
	
	
	-- Registrar importes 
	DECLARE @ImporteTotalSalida money, 	@ImporteTotalSalidaDlls money
	SET @ImporteTotalSalida = (SELECT round(SUM(Importe),2) From ProMovimientosAlmacenConceptos where IdMovimientoAlmacen = @IdMovimientoAlmacenSalida)
	SET @ImporteTotalSalidaDlls = (SELECT round(SUM(ImporteDlls),2) From ProMovimientosAlmacenConceptos where IdMovimientoAlmacen = @IdMovimientoAlmacenSalida)

		 UPDATE ProMovimientosAlmacen
			SET SubTotal = @ImporteTotalSalida ,
				Total =    @ImporteTotalSalida, 
				SubTotalDlls = @ImporteTotalSalidaDlls ,
				TotalDlls =    @ImporteTotalSalidaDlls 
			WHERE ProMovimientosAlmacen.IdMovimientoAlmacen = @IdMovimientoAlmacenSalida
	--

	IF @dsProArticulosDetallados IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProArticulosDetallados
		
		SELECT  ATT_IdProMovimientoDetallado ,ATT_IdAlmacen
		INTO #TempProArticulosDetallados
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProArticulosDetallados',2) 
		WITH (ATT_IdProMovimientoDetallado  int,ATT_IdAlmacen int )
		
		EXEC sp_xml_removedocument @docHandle

		DECLARE dsProArticulosDetalladosCursor CURSOR FOR
		SELECT ATT_IdProMovimientoDetallado ,ATT_IdAlmacen FROM #TempProArticulosDetallados

		OPEN dsProArticulosDetalladosCursor
		FETCH NEXT FROM dsProArticulosDetalladosCursor
		INTO @CursorIdProMovimientoDetallado, @CursorIdAlmacen

		WHILE @@FETCH_STATUS = 0
		BEGIN
			UPDATE ProMovimientosAlmacenDetallado SET IdAlmacen = @CursorIdAlmacen WHERE IdProMovimientodetallado = @CursorIdProMovimientoDetallado
			FETCH NEXT FROM dsProArticulosDetalladosCursor
			INTO @CursorIdProMovimientoDetallado, @CursorIdAlmacen
		END
		CLOSE dsProArticulosDetalladosCursor
		DEALLOCATE dsProArticulosDetalladosCursor

		--UPDATE ProMovimientosAlmacenDetallado SET IdAlmacen = ATT_IdAlmacen WHERE IdProMovimientodetallado = ATT_IdProMovimientoDetallado
	END


 COMMIT  
END TRY  
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

