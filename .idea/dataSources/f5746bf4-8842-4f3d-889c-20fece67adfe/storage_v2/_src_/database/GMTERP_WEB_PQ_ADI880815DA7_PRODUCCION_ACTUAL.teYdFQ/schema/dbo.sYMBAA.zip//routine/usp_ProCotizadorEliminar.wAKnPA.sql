
	CREATE PROCEDURE [dbo].[usp_ProCotizadorEliminar]
	@IdCotizacion int,
	@IdPeticion varchar(100)	
	AS
	BEGIN TRY
		BEGIN TRANSACTION
		
		IF ISNULL(@IdCotizacion,0)= 0
		RAISERROR(N'El identificador de la cotizacion es un campo requerido',
				16,
				1
				)
				
			DELETE ProCotizaciones
			WHERE IdCotizacion = @IdCotizacion
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

