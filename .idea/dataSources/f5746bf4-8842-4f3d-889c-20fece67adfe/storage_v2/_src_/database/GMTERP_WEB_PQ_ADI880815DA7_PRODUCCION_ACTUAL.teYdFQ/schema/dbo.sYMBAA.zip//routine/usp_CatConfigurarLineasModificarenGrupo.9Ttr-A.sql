CREATE PROC [dbo].[usp_CatConfigurarLineasModificarenGrupo]
    @IdConfigurarLineas          int,
    @Codigo                      int,
    @IdTipoUnidad                int,
    @Ejercicio                   int,
    @Periodo                     int,
    @IngresoxKMMinimo            money,
    @IngresoxKmMaximo            money,
    @IngresoxKmMeta              money,
    @CostoxKMMinimo              money,
    @CostoxKmMaximo              money,
    @CostoxKmMeta                money,
    @UtilidadxKMMinimo           money,
    @UtilidadxKmMaximo           money,
    @UtilidadxKmMeta             money,
    @RendimientoxKMMinimo        money,
    @RendimientoxKmMaximo        money,
    @RendimientoxKmMeta          money,
    @PorcentajeUtilidadxKMMinimo money,
    @PorcentajeUtilidadxKmMaximo money,
    @PorcentajeUtilidadxKmMeta   money,
    @ModificadoEl                datetime,
    @ModificadoPor               int,
    @IdPeticion                  varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatCatConfigurarLineasModificar

Parámetros:
    @Codigo                      (entrada, entero). Código de la configuración a las lineas.
    @IdTipoUnidad                (entrada, entero). La llave referencial del tipo de unidades para las que se especifica la configuración
    @Ejercicio                   (entrada, entero). Año para el cual se especifica la configuración
    @Periodo                     (entrada, entero). Mes para el cual se especifica la configuración

    ***** Los sigguientes valores se establecen para la configuración de los controles de 5 calibradores en el reporte de Power BI ***** 

    @IngresoxKMMinimo            (entrada, money). Relacion de Ingreso/Km que será establecido como mínimo en el calibrador.
    @IngresoxKmMaximo            (entrada, money). Relacion de Ingreso/Km que será establecido como máximo en el calibrador.
    @IngresoxKmMeta              (entrada, money). Relacion de Ingreso/Km que será establecido como meta en el calibrador.
    @CosoxKMMinimo               (entrada, money). Relacion de Costo/Km que será establecido como mínimo en el calibrador.
    @CostoxKmMaximo              (entrada, money). Relacion de Costo/Km que será establecido como máximo en el calibrador.
    @CostoxKmMeta                (entrada, money). Relacion de Costo/Km que será establecido como meta en el calibrador.
    @UtilidadxKMMinimo           (entrada, money). Relacion de Utilidad/Km que será establecido como mínimo en el calibrador.
    @UtilidadxKmMaximo           (entrada, money). Relacion de Utilidad/Km que será establecido como máximo en el calibrador.
    @UtilidadxKmMeta             (entrada, money). Relacion de Utilidad/Km que será establecido como meta en el calibrador.
    @RendimientoxKMMinimo        (entrada, money). Relacion de Rendimiento/Km que será establecido como mínimo en el calibrador.
    @RendimientoxKmMaximo        (entrada, money). Relacion de Rendimiento/Km que será establecido como máximo en el calibrador.
    @RendimientoxKmMeta          (entrada, money). Relacion de Rendimiento/Km que será establecido como meta en el calibrador.
    @PorcentajeUtilidadxKMMinimo (entrada, money). % Utilidad/Km que será establecido como mínimo en el calibrador.
    @PorcentajeUtilidadxKmMaximo (entrada, money). % Utilidad/Km que será establecido como máximo en el calibrador.
    @PorcentajeUtilidadxKmMeta   (entrada, money). % Utilidad/Km que será establecido como meta en el calibrador.
    @ModificadoEl                (entrada, fecha hora). Fecha y hora en la que fue modificado el registro.
    @ModificadoPor               (entrada, entero). Id del usuario que modifico el registro.
    @IdPeticion                  (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para modificar una nueva configuración a las lineas de KPI's.

12/03/2020 - Se creó.

Implementada por: José Luis Cisneros González.
Fecha de implementacion: 07/02/2020
Versión ERP:

Invocada desde: PAGE_CatConfigurarLineasAM (Solicitud 1400)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
    -- Validaciones
	--IF @IdTipoUnidad = 0
       -- RAISERROR(N'El tipo de unidad es un campo requerido.', 16, 1)
  
	IF @Ejercicio = 0
		RAISERROR(N'El ejercicio es un campo requerido.', 16, 1)

    -- Modifica el registro
    UPDATE [dbo].[CatConfigurarLineas]
                SET [IngresoxKMMinimo]            = @IngresoxKMMinimo,
                    [IngresoxKmMaximo]            = @IngresoxKmMaximo,
                    [IngresoxKmMeta]              = @IngresoxKmMeta,
                    [CostoxKMMinimo]              = @CostoxKMMinimo,
                    [CostoxKmMaximo]              = @CostoxKmMaximo,
                    [CostoxKmMeta]                = @CostoxKmMeta,
                    [UtilidadxKMMinimo]           = @UtilidadxKMMinimo,
                    [UtilidadxKmMaximo]           = @UtilidadxKmMaximo,
                    [UtilidadxKmMeta]             =  @UtilidadxKmMeta,
                    [RendimientoxKMMinimo]        = @RendimientoxKMMinimo,
                    [RendimientoxKmMaximo]        = @RendimientoxKmMaximo,
                    [RendimientoxKmMeta]          = @RendimientoxKmMeta,
                    [PorcentajeUtilidadxKMMinimo] = @PorcentajeUtilidadxKMMinimo,
                    [PorcentajeUtilidadxKmMaximo] = @PorcentajeUtilidadxKmMaximo,
                    [PorcentajeUtilidadxKmMeta]   = @PorcentajeUtilidadxKmMeta,
                    [ModificadoEl]                = @ModificadoEl,
                    [ModificadoPor]               = @ModificadoPor
                WHERE ([IdTipoUnidad] = @IdTipoUnidad AND [Ejercicio] = @Ejercicio AND [Periodo] >= @Periodo)

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

