CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosTraspasoCancelar]
	@IdMovimientoBancarioTraspaso int,
	@IdMovimientoBancarioOrigen int,
	@IdMovimientoBancarioDestino int,
	@MotivoCancelacion varchar(150),	
	@CanceladoPor int,
    @CanceladoEl Datetime,
	@IdPeticion varchar(100)	
AS
DECLARE @ConciliadoOrigen int, 
		@ConciliadoDestino int,
		@IdCheque int
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdMovimientoBancarioTraspaso,0)= 0
		RAISERROR(N'Identificador de movimiento bancario de traspaso es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdMovimientoBancarioOrigen,0)= 0
		RAISERROR(N'Identificador de movimiento bancario origen es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdMovimientoBancarioDestino,0)= 0
		RAISERROR(N'Identificador de movimiento bancario destino es un campo requerido',
			16,
			1
			)
		
	IF ISNULL(@CanceladoEl,'')= ''
		RAISERROR(N'Fecha de cancelación es un campo requerido',
			16,
			1
			)

	-- valida que el movimiento origen exista en ProMovimientosBancariosTraspaso
	IF NOT EXISTS(SELECT IdMovimientoBancarioOrigen 
	                 FROM ProMovimientosBancariosTraspasos 
	                  WHERE IdMovimientoBancarioOrigen = @IdMovimientoBancarioOrigen 
	                    AND IdMovimientoBancarioDestino= @IdMovimientoBancarioDestino )
	  BEGIN
		RAISERROR(N'No puede cancelar los movimiento origen y destino por que no pertenece a una operación de traspaso',
			16,
			1
			)
	  END
	  
	--- valida conciliado movimiento origen
	 SET @ConciliadoOrigen = (SELECT Conciliado FROM ProMovimientosBancarios WHERE  IdMovimientoBancario = @IdMovimientoBancarioOrigen) 
	 IF ISNULL(@ConciliadoOrigen,0) = 1
	  BEGIN
		RAISERROR(N'El movimiento origen ya está conciliado no puede eliminar',
			16,
			1
			)
	  END
	--- valida conciliado movimiento destino 
	 SET @ConciliadoDestino = (SELECT Conciliado FROM ProMovimientosBancarios WHERE  IdMovimientoBancario = @IdMovimientoBancarioDestino) 
	 IF ISNULL(@ConciliadoDestino,0) = 1
	  BEGIN
		RAISERROR(N'El movimiento origen ya está conciliado no puede eliminar',
			16,
			1
			)
	  END
	  	  
	  
	--- Actualizar Movimiento Movimiento Bancario
	Update ProMovimientosBancarios SET 
	 	CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		MotivoCancelacion = @MotivoCancelacion
	   where ProMovimientosBancarios.IdMovimientoBancario in (@IdMovimientoBancarioOrigen,@IdMovimientoBancarioDestino)

	SET @IdCheque = (Select IdCheque from ProMovimientosBancarios Where IdMovimientoBancario = @IdMovimientoBancarioOrigen)

	Update ProCheques 
	SET 
	 	CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		MotivoCancelacion = @MotivoCancelacion
	Where IdCheque = @IdCheque

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

