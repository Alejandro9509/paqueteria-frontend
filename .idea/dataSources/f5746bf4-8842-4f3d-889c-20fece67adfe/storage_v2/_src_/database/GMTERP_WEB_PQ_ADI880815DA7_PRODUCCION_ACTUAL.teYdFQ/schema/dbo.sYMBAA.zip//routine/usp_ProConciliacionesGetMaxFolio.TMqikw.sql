	
	Create PROCEDURE [dbo].[usp_ProConciliacionesGetMaxFolio]

	AS

	SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProConciliaciones
    go

