CREATE PROCEDURE [dbo].[usp_CatConceptosGastosViajeModificar]
	@IdConceptoGastoViaje int,
	@Codigo int,
	@ConceptoGastoViaje varchar(30),
	@Activo bit,
	@ConsiderarCalculoISPT bit,
	@ConsiderarCalculoRendimiento bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@GastoACredito bit
AS

BEGIN TRY
	BEGIN TRANSACTION	
	
	IF (SELECT ModificadoEl FROM CatConceptosGastosViaje WHERE IdConceptoGastoViaje = @IdConceptoGastoViaje) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)	

	IF ISNULL(@Codigo,0) <= 0
		RAISERROR(N'El codigo es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT IdConceptoGastoViaje FROM CatConceptosGastosViaje WHERE IdConceptoGastoViaje <> @IdConceptoGastoViaje AND Codigo = @Codigo)
		RAISERROR(N'El código del concepto ya esta registrado',
			16,
			1
			)	
			
	IF LTRIM(RTRIM(@ConceptoGastoViaje)) = ''
		RAISERROR(N'El concepto de gasto de viaje es un campo requerido',
			16,
			1
			)
			
	UPDATE CatConceptosGastosViaje SET
		Codigo = @Codigo,
		ConceptoGastoViaje = @ConceptoGastoViaje,
		Activo = @Activo,
		ConsiderarCalculoISPT = @ConsiderarCalculoISPT,
		ConsiderarCalculoRendimiento = @ConsiderarCalculoRendimiento,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl,
		GastoACredito = @GastoACredito
	WHERE IdConceptoGastoViaje = @IdConceptoGastoViaje
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

