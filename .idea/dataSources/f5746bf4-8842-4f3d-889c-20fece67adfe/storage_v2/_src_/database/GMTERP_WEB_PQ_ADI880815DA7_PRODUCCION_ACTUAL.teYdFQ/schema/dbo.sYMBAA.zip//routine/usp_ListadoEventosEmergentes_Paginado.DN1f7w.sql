CREATE PROCEDURE [dbo].[usp_ListadoEventosEmergentes_Paginado]
--DECLARE
@Xml XML,
@IdUsuario INT,
@TipoUsuario INT, 
@Pagina INT, 
@Elemento INT,
@FechaHoraSucursal datetime,
@Ordenamiento varchar   
AS
DECLARE
@Sql NVARCHAR(MAX),
@Where NVARCHAR(MAX),
@Parametros NVARCHAR(MAX),
@Administrador int = 1,
@UsuarioEspejo int = 5,
@UsuarioUsuario int = 3, 
@GrupoUnidades NVARCHAR(MAX),
@AplicarFiltroGrupoUnidades bit = 1,--bandera para aplicar filtro en el query
@FiltrarPorGrupoUnidadesParametro bit = ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'FiltrarPorGrupoUnidades'),0)--valor del parametro
	
--SE EVALUA CRITERIOS PARA APLICAR FILTRO DE GRUPOS DE UNIDADES
	IF EXISTS(SELECT * FROM CatUsuarios AS cu WHERE cu.IdUsuario = @IdUsuario AND cu.TipoUsuario IN(1,5)) 
	OR @FiltrarPorGrupoUnidadesParametro = 0
		SET @AplicarFiltroGrupoUnidades = 0

--Se valida que si el tipo de usuario es Administrador pueda ver todos los grupos de unidades 
IF (@TipoUsuario = @Administrador) 
	BEGIN
		;WITH Ubicaciones AS( SELECT FechaHoraPaquete = Node.Data.value('(FechaHora)[1]', 'VARCHAR(MAX)')
		, IdentificadorSatelitalXml = Node.Data.value('(NoSerie)[1]', 'VARCHAR(MAX)')
		, Ubicacion = Node.Data.value('(Ubicacion)[1]', 'VARCHAR(MAX)')
		, NombreEvento = Node.Data.value('(NombreEvento)[1]', 'VARCHAR(MAX)')
		, ImagenGPS = Node.Data.value('(ImagenGPS)[1]', 'VARCHAR(MAX)')
		FROM    @Xml.nodes('/Ubicacion/ubicacion') Node(Data))
		,listadoEventosEmergentes as (SELECT ROW_NUMBER() OVER (ORDER BY @Ordenamiento   ) AS rownumber,ub.FechaHoraPaquete,ub.IdentificadorSatelitalXml,ub.ImagenGPS,ub.NombreEvento, ub.Ubicacion FROM Ubicaciones AS ub
		inner join CatUnidades as cu on ub.IdentificadorSatelitalXml = cu.IdentificadorSatelital
		LEFT join CatGruposUnidades as cgu on cu.IdGrupoUnidad = cgu.IdGrupoUnidad)
		select (SELECT MAX(rownumber) FROM  listadoEventosEmergentes) AS  TotalRows,* from listadoEventosEmergentes where
		rownumber >= (CASE @Pagina   
		WHEN 1 THEN 1 
		ELSE (@Elemento*(@Pagina-1))+1   
		END)AND rownumber <= (@Elemento*@Pagina)
	END
ELSE
	BEGIN

		;WITH Ubicaciones AS( SELECT FechaHoraPaquete = Node.Data.value('(FechaHora)[1]', 'VARCHAR(MAX)')
		, IdentificadorSatelitalXml = Node.Data.value('(NoSerie)[1]', 'VARCHAR(MAX)')
		, Ubicacion = Node.Data.value('(Ubicacion)[1]', 'VARCHAR(MAX)')
		, NombreEvento = Node.Data.value('(NombreEvento)[1]', 'VARCHAR(MAX)')
		, ImagenGPS = Node.Data.value('(ImagenGPS)[1]', 'VARCHAR(MAX)')
		FROM    @Xml.nodes('/Ubicacion/ubicacion') Node(Data))
		,listadoEventosEmergentes as (SELECT ROW_NUMBER() OVER (ORDER BY @Ordenamiento   ) AS rownumber,ub.FechaHoraPaquete,ub.IdentificadorSatelitalXml,ub.ImagenGPS,ub.NombreEvento, ub.Ubicacion FROM Ubicaciones AS ub
		inner join CatUnidades as cu on ub.IdentificadorSatelitalXml = cu.IdentificadorSatelital
		INNER join CatGruposUnidades as cgu on cu.IdGrupoUnidad = cgu.IdGrupoUnidad
		inner join CatUsuarios as ca on ca.IdUsuario = @IdUsuario
		WHERE ca.IdUsuario = @IdUsuario AND
			(
		(cu.IdGrupoUnidad IN(SELECT IdGrupoUnidad 
		FROM CatGruposUnidadesUsuarios AS cguu 
		WHERE cguu.IdUsuario = @IdUsuario ) AND @AplicarFiltroGrupoUnidades = 1 )
		OR @AplicarFiltroGrupoUnidades = 0 
			)
		AND cu.Activa = 1
		AND ((ca.TipoUsuario = 5 AND cu.IdUnidad IN(SELECT cueu.IdUnidad 
		FROM CatUsuariosEspejosUnidades  AS cueu 
		WHERE cueu.IdUsuarioEspejo = @IdUsuario AND cueu.FechaVencimiento > @FechaHoraSucursal)) 
		OR(ca.TipoUsuario != 5)) OR cgu.IdGrupoUnidad IN(SELECT cguu.IdGrupoUnidad FROM CatGruposUnidadesUsuarios AS cguu WHERE cguu.IdUsuario = @IdUsuario))
		select (SELECT MAX(rownumber) FROM  listadoEventosEmergentes) AS  TotalRows,* from listadoEventosEmergentes where
		rownumber >= (CASE @Pagina   
		WHEN 1 THEN 1 
		ELSE (@Elemento*(@Pagina-1))+1   
		END)AND rownumber <= (@Elemento*@Pagina)

	END
go

