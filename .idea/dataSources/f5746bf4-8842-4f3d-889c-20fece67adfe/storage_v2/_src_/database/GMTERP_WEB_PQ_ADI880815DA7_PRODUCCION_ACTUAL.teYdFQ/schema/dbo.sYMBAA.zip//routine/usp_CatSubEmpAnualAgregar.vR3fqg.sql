
CREATE PROCEDURE [dbo].[usp_CatSubEmpAnualAgregar]
@dsCatSubEmplAnual ntext,
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100)
AS
DECLARE
@docHandle int, 
@CursorT_IdSubEmpAnual int,
@CursorT_LimiteInferior decimal(15, 2),
@CursorT_SubsAlEmpleado decimal(15, 2),
@CursorT_Ejercicio int,
@CursorT_FechaVigencia datetime

/* *************************************************************************************************
Procedimiento [usp_CatSubEmpAnualAgregar]
r
Parámetros: 
	@dsCatSubEmplAnual			 (entrada, texto).   Es la tabla de registros.
	@ModificadoEl	             (entrada, fecha hora). Fecha en la que se realiza la modificación
	@ModificadoPor	             (entrada, entero). Quien solicita la modificación
	@IdPeticion varchar(100)	 (entrada, string). Id de la Petición, generada en WEBDEV 	
 

Descripción: El procedimiento agrega las tarifas del Subsidio otorgado a el empleado en base a los ingresos,
             percibidos durante el Ejercicio.

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 11/06/2020
Versión ERP: 8.0.53.04

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 25/01/2021
Versión ERP: 8.0.58.09
Solicitud: 3737


Invocada desde: PAGE_CatSubEmplMensual_AM (Solicitud 3737)
***************************************************************************************************** */




BEGIN TRY
	BEGIN TRANSACTION
		IF @dsCatSubEmplAnual IS NULL
		RAISERROR(N'Los Subs Anuales son requeridos',
			16,
			1
			)

	IF @dsCatSubEmplAnual IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatSubEmplAnual

		SELECT ATT_LimiteInferior,ATT_SubsAlEmpleado, ATT_Ejercicio, ATT_FechaVigencia
		INTO #CatSubEmpAnual
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CATSubEmpAnual',2) 
		WITH ( ATT_LimiteInferior decimal(15, 2),ATT_SubsAlEmpleado decimal(15, 2), ATT_Ejercicio int, ATT_FechaVigencia datetime )

		EXEC sp_xml_removedocument @docHandle

		DECLARE CatSubEmpAnualCursor CURSOR LOCAL SCROLL FOR
		SELECT * FROM #CatSubEmpAnual

		OPEN CatSubEmpAnualCursor
		FETCH NEXT FROM CatSubEmpAnualCursor
		INTO @CursorT_LimiteInferior , @CursorT_SubsAlEmpleado, @CursorT_Ejercicio, @CursorT_FechaVigencia

		WHILE @@FETCH_STATUS = 0
		BEGIN
			INSERT INTO CatSubEmpAnual (LimiteInferior, SubsAlEmpleado, CreadoEl, CreadoPor, Ejercicio, FechaVigencia)
			VALUES ( @CursorT_LimiteInferior, @CursorT_SubsAlEmpleado, 	@CreadoEl , @CreadoPor, @CursorT_Ejercicio, @CursorT_FechaVigencia )

			FETCH NEXT FROM CatSubEmpAnualCursor
			INTO  @CursorT_LimiteInferior , @CursorT_SubsAlEmpleado, @CursorT_Ejercicio, @CursorT_FechaVigencia
		END
		CLOSE CatSubEmpAnualCursor
		DEALLOCATE CatSubEmpAnualCursor

  END 
  COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

