CREATE PROCEDURE [dbo].[usp_ProDetalleCierreAnualAgregar]
/* *************************************************************************************************
Procedimiento usp_ProDetalleCierreAnualAgregar

Parámetros: 
01	@IdCierreAnual          (entrada, entero). Identificador del registro padre de los detalles           
02  @xmlDetallesCierreAnual (entrada, string). archivo xml con el grupo de detalles que se relacionan con el padre
03	@CreadoPor              (entrada, entero). Identificador de quien generó el detalle
04	@CreadoEl               (entrada, fecha hora). Fecha en la que se realiza la elaboración
05  @IdPeticion             (entrada, string). Id de la Petición, generada en WEBDEV 	

Descripción: El procedimiento registra los valores resultantes de los cálculos necesario para el cierre anual de la nómina del empleado

Implementada por: José Luis Cisneros G.
Fecha de implementacion: 30/07/2020
Versión ERP: 8.0.54.19

Modificada por:   
Fecha de mofidicacion: 
Versión ERP: 

Invocada desde: PAGE_ProCalculoAnualGenerar (Solicitud 2333)
***************************************************************************************************** */
--- Paso de parámetros
	@IdCierreAnualP              int,   
    @xmlDetallesCierreAnual      ntext,
	@CreadoPor                   int,
	@CreadoEl                    datetime,
    @IdPeticion                  varchar(100)
    
AS

BEGIN TRY
	BEGIN TRANSACTION

   --- locales de procesamiento
   DECLARE  @IdDetalle                      int,
            @IdCierreAnual                  int,
	        @AplicaCalculo                  int,
	        @Causa                          int, 
            @IdEmpleado                     int, 			
	        @EstatusABR                     VARCHAR(20), 
	        @IngresosTotales                money, 	
	        @BaseGravadaAcumulado           money, 
            @DiasTranscurridos              int,			
            @BaseArt142                     money,			
            @BaseDiaria                     money,
            @BaseAnual                      money,
	        @BaseGravadaProyectada          money, 
            @LimiteInferiorISR              money,                 
            @PorcentajeISR                  money,                      
            @CuotaFijaISR                   money,   
	        @Art152                         money, 
			@SubsidioCorrespondiente        money, 
	        @ImpuestoAnual                  money, 
			@SubsidioDiario                 money,    
		    @SubsidioProyectado             money,
			@ImpuestoRetenido               money, 
		    @RetencionDiaria                money,              
		    @RetencionEfectuadaProyectada   money,  
		    @ImpuestoACargoMenosRetenciones money,	
	        @ACargo                         money, 
	        @ACompensar                     money, 
	        @ComRetRealizadas               money, 
	        @ImpuestoCargoFinal             money, 
	        @ImpuestosCompensarFinal        money, 
	        @SaldoCargoCompensarFinal       money,
			@TipoPeriodo                    int, 			
			@Ejercicio                      int, 			
            @docHandle                      int

	IF ISNULL(@IdCierreAnualP,0) <= 0
			RAISERROR(N'El identificador del cierre anual es un campo requerido',	16,	1)

    IF ISDATE(@CreadoEl) = 0
			RAISERROR(N'La fecha es un campo requerido', 16, 1	)
     
    IF NOT EXISTS(SELECT IdCierreAnual FROM ProCierreAnual WHERE IdCierreAnual = @IdCierreAnualP)
       RAISERROR(N'Un Proceso de cierre no existe y debe existir', 16, 1	)


   EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlDetallesCierreAnual

   SELECT 
		COL_IdDetalle,
		COL_AplicaCalculo,
		COL_Causa,
		COL_IdEmpleado,
		COL_EstatusABR,
		COL_IngresosTotales,
		COL_BaseGravadaAcumulado,
		COL_DiasTranscurridos,
		COL_BaseArt142,
		COL_BaseDiaria,
		COL_BaseAnual,
		COL_BaseGravadaProyectada,
		COL_LimiteInferiorISR,
		COL_PorcentajeISR,
		COL_CuotaFijaISR,
		COL_Art152,
		COL_SubsidioCorrespondiente,
		COL_ImpuestoAnual,
		COL_SubsidioDiario,
		COL_SubsidioProyectado,
		COL_ImpuestoRetenido,
		COL_RetencionDiaria,
		COL_RetencionEfectuadaProyectada,
		COL_ImpuestoACargoMenosRetenciones,
		COL_ACargo,
		COL_ACompensar,
		COL_ComRetRealizadas,
		COL_ImpuestoCargoFinal,
		COL_ImpuestosCompensarFinal,
		COL_SaldoCargoCompensarFinal,
		COL_IdCierreAnual,
		COL_TipoPeriodo,
		COL_Ejercicio
		
   INTO #TempDetallesCierreAnual
   FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CalculoAnual',2)
   WITH (
			COL_IdDetalle                        int,
			COL_AplicaCalculo                    int,
			COL_Causa                            int,
			COL_IdEmpleado                       int,
			COL_EstatusABR                       VARCHAR(16),
			COL_IngresosTotales                  money,
			COL_BaseGravadaAcumulado             money,
			COL_DiasTranscurridos                int,
			COL_BaseArt142                       money,
			COL_BaseDiaria                       money,
			COL_BaseAnual                        money,
			COL_BaseGravadaProyectada            money,
			COL_LimiteInferiorISR                money,
			COL_PorcentajeISR                    money,
			COL_CuotaFijaISR                     money,
			COL_Art152                           money,
			COL_SubsidioCorrespondiente          money,
			COL_ImpuestoAnual                    money,
			COL_SubsidioDiario                   money,
			COL_SubsidioProyectado               money,
			COL_ImpuestoRetenido                 money,
			COL_RetencionDiaria                  money,
			COL_RetencionEfectuadaProyectada     money,
			COL_ImpuestoACargoMenosRetenciones   money,
			COL_ACargo                           money,
			COL_ACompensar                       money,
			COL_ComRetRealizadas                 money,
			COL_ImpuestoCargoFinal               money,
			COL_ImpuestosCompensarFinal          money,
			COL_SaldoCargoCompensarFinal         money,
			COL_IdCierreAnual                    int,
			COL_TipoPeriodo                      int,
			COL_Ejercicio                        int
        )

   DECLARE CursorDetallesCierreAnual CURSOR FOR
   SELECT * FROM #TempDetallesCierreAnual

   OPEN CursorDetallesCierreAnual
   FETCH NEXT FROM CursorDetallesCierreAnual
   INTO @IdDetalle, @AplicaCalculo, @Causa, @IdEmpleado, @EstatusABR, @IngresosTotales, @BaseGravadaAcumulado, @DiasTranscurridos, 			
        @BaseArt142, @BaseDiaria, @BaseAnual, @BaseGravadaProyectada, @LimiteInferiorISR, @PorcentajeISR, @CuotaFijaISR, @Art152, 
		@SubsidioCorrespondiente, @ImpuestoAnual, @SubsidioDiario, @SubsidioProyectado, @ImpuestoRetenido, @RetencionDiaria,                
		@RetencionEfectuadaProyectada, @ImpuestoACargoMenosRetenciones, @ACargo, @ACompensar, @ComRetRealizadas, @ImpuestoCargoFinal,    
	    @ImpuestosCompensarFinal, @SaldoCargoCompensarFinal, @IdCierreAnual, @TipoPeriodo, @Ejercicio	 

  --- SET @RetencionEfectuadaProyectada = @RetencionDiaria *30

   
   WHILE @@FETCH_STATUS = 0
      BEGIN

           INSERT INTO ProDetalleCierreAnual(IdCierreAnual, Aplica, IdEmpleado, IdTipoPeriodo, Ejercicio, Causa, EstatusABR, 
		                                     IngresosTotales, BaseGravadaAcumulado, DiasTranscurridos, BaseArt142, BaseDiaria, 
											 BaseAnual, BaseGravadaProyectada, LimiteInferiorISR, PorcentajeISR, CuotaFijaISR,	                  
                                             Art152, SubsidioCorrespondiente, ImpuestoAnual, SubsidioDiario, SubsidioProyectado,	
											 ImpuestoRetenido, RetencionDiaria, RetencionEfectuadaProyectada, ImpuestoACargoMenosRetenciones, 
											 ACargo, ACompensar, ComRetRealizadas, ImpuestoCargoFinal, ImpuestosCompensarFinal, 
											 SaldoCargoCompensarFinal, CreadoPor, CreadoEl) 

           VALUES
                   ( @IdCierreAnualP,@AplicaCalculo,@IdEmpleado,@TipoPeriodo,@Ejercicio,@Causa,@EstatusABR,
	                 @IngresosTotales,@BaseGravadaAcumulado, @DiasTranscurridos, @BaseArt142, @BaseDiaria, 
	                 @BaseAnual, @BaseGravadaProyectada, @LimiteInferiorISR, @PorcentajeISR, @CuotaFijaISR, 
	                 @Art152, @SubsidioCorrespondiente, @ImpuestoAnual, @SubsidioDiario, @SubsidioProyectado, 
	                 @ImpuestoRetenido, @RetencionDiaria, @RetencionEfectuadaProyectada, @ImpuestoACargoMenosRetenciones, 
	                 @ACargo, @ACompensar, @ComRetRealizadas, @ImpuestoCargoFinal, @ImpuestosCompensarFinal, 
	                 @SaldoCargoCompensarFinal,@CreadoPor,@CreadoEl)
       			
          FETCH NEXT FROM CursorDetallesCierreAnual
		  INTO  @IdDetalle, @AplicaCalculo, @Causa, @IdEmpleado, @EstatusABR, @IngresosTotales, @BaseGravadaAcumulado, @DiasTranscurridos, 			
                @BaseArt142, @BaseDiaria, @BaseAnual, @BaseGravadaProyectada, @LimiteInferiorISR, @PorcentajeISR, @CuotaFijaISR, @Art152, 
 		        @SubsidioCorrespondiente, @ImpuestoAnual, @SubsidioDiario, @SubsidioProyectado, @ImpuestoRetenido, @RetencionDiaria,              
		        @RetencionEfectuadaProyectada, @ImpuestoACargoMenosRetenciones, @ACargo, @ACompensar, @ComRetRealizadas, @ImpuestoCargoFinal,  
	            @ImpuestosCompensarFinal, @SaldoCargoCompensarFinal, @IdCierreAnual, @TipoPeriodo, @Ejercicio	
					
      END

	CLOSE CursorDetallesCierreAnual
	DEALLOCATE CursorDetallesCierreAnual	

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

