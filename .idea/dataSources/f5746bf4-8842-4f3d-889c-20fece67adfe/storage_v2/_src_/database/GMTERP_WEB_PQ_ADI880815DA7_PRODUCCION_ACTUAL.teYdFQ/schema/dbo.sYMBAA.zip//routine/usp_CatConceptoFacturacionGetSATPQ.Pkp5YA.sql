CREATE PROCEDURE [dbo].[usp_CatConceptoFacturacionGetSATPQ]
	@Tipo varchar(15),
	@ClaveDivision INT,
	@ClaveGrupo INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT 	
			Clase,
			cve_clase,
			Grupo,
			Division
	FROM TablaSAT pp
		WHERE (Tipo = @Tipo OR @Tipo IS NULL)
		AND (cve_division = @ClaveDivision OR @ClaveDivision IS NULL)
		AND (cve_grupo >= @ClaveGrupo OR @ClaveGrupo IS NULL)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

