


CREATE PROCEDURE [dbo].[usp_CatClientesContactosActualizarPermitirVerSeguimiento]
	@IdClienteContacto int,
	@IdPeticion varchar(100),
	@PermitirVerSeguimiento bit,
	@Usuario varchar(8),
	@Contrasena varchar(8)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	UPDATE CatClientesContactos SET 
		PermitirVerSeguimiento = @PermitirVerSeguimiento,
		Usuario = @Usuario,
		Contrasena = @Contrasena
	WHERE IdClienteContacto = @IdClienteContacto
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

