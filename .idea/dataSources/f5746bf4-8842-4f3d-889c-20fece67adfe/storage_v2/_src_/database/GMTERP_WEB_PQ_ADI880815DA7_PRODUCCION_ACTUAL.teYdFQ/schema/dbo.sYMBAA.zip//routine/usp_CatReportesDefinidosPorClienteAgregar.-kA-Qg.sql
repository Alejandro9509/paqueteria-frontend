CREATE PROCEDURE [dbo].[usp_CatReportesDefinidosPorClienteAgregar]
/* *************************************************************************************************
Procedimiento usp_CatReportesDefinidosPorClienteAgregar

Parámetros: Fueron agregados a los ya existentes los parametros necesarios para le ejecucion de reportes definidos por el cliente en le modulo portuario
            y para que los reportes se puedan ejecutar de forma automática en segundo plano. Todos los paarmetros son de entrada.

            @ModuloPortuario Bit.     Indica si el reporte es del modulo portuario            
            @EnviarCada int.          Indica la acntidad de horas a las que será enviada el reporte se quedo fija en 8 hrs              
            @EnviarEn   date.         Indica cuando se inicia el envio                
            @Frecuencia int.          Indica la frecuencia (1 Semanal, 2 mensual)              
            @FiltroFechas int.        Indica si las fechas a tomar en el filtro son por viaje (1) o son por Orden de entrega (2)              
            @FiltroMonedas int.       Indica si son (1 pesos, 2 Dolares o 3 Ambas)               
            @ReporteAutomatico Bit.   Indica si es reporte automático             
 

Descripción: 
07/11/2019   Adaptacion para reportes porturaios y la implementacion del centinela de realizacion y envio de reportes automaticos
03/12/2019   Se agregó un check box llamado Fijar Estatus. Solicitud: 578.             

Implementada por: No tengo idea
Fecha de implementacion: ??/??/????
Versión ERP: ????????

Modificada por:   Amado Navarro.
Fecha de mofidicacion: 11/06/2020
Versión ERP: 8.0.53.04
Se agrego el parametro @MostrarPor para generar el reporte en el modulo de portuarios por viaje.

Modificada por:   José Luis Cisneros G.
Fecha de mofidicacion: 07/11/2019
Versión ERP: 8.0.47.35

Modificada por:   Ricardo Sinai Miranda P.
Fecha de mofidicacion: 03/12/2019
Versión ERP: 8.0.48.11


Invocada desde: PAGE_CatReportesPortuariosDefinidosPorClienteAM
***************************************************************************************************** */
	@Nombre Varchar(150),                    --  1
	@IdCliente int,	                         --  2
	@CorreosDestinatarios varchar(8000),     --  3
	@FiltroActivoClasificacionViaje bit,     --  4
	@FiltroActivoGrupoUnidades bit,          --  5
	@FiltroActivoTipoViaje Bit,              --  6
    @ModuloPortuario Bit,                    --  7
    @EnviarCada int,                         --  8     
    @EnviarEn   date,                        --  9
    @Frecuencia int,                         -- 10
    @FiltroFechas int,                       -- 11
    @FiltroMonedas int,                      -- 12
    @ReporteAutomatico Bit,                  -- 13  
	@dsClasificacionesViajes ntext,          -- 14
	@dsEstatusViajes ntext,                  -- 15
	@dsGruposUnidades ntext,                 -- 16
	@dsTiposViajes ntext,                    -- 17
	@dsDatosViaje ntext,                     -- 18
    @dsDatosOrdenContenedores ntext,         -- 19
	@CreadoPor int,                          -- 20
	@CreadoEl datetime,	                     -- 21
	@IdPeticion varchar(100),                -- 22
	@TransportePersonal bit,                 -- 23    
	@FijarEstatus bit,                       -- 24
	@MostrarPor bit							 -- 25
AS
DECLARE
	@IdReporteDefinidoPorCliente int,
	@docHandle int,	
	@ATT_IdClasificacionViaje int,
	@ATT_IdEstatusViaje int,
	@ATT_Orden tinyint,
	@ATT_IdDatoViaje int,
	@ATT_NombreEnTabla Varchar(8000),
	@ATT_Etiqueta Varchar(30),
	@ATT_EsFecha Bit,
	@ATT_IdTipoViaje int,
	@ATT_IdGruposUnidades int
	
BEGIN TRY
	BEGIN TRANSACTION

	IF LTrim(Rtrim(@Nombre)) = ''
		RAISERROR(N'El nombre es un campo requerido', 16, 1)	
  
								
	INSERT INTO CatReportesDefinidosPorCliente(Nombre,IdCliente,CorreosDestinatarios,FiltroActivoTipoViaje,FiltroActivoClasificacionViaje,FiltroActivoGrupoUnidades,CreadoPor,CreadoEl,TransportePersonal,ModuloPortuario,EnviarCada,EnviarEn,Frecuencia,FiltroFechas,FiltroMonedas,ReporteAutomatico,FijarEstatus,MostrarPor)
	VALUES(@Nombre,@IdCliente,@CorreosDestinatarios,@FiltroActivoTipoViaje,@FiltroActivoClasificacionViaje,@FiltroActivoGrupoUnidades,@CreadoPor,@CreadoEl,@TransportePersonal,@ModuloPortuario,@EnviarCada,@EnviarEn,@Frecuencia,@FiltroFechas,@FiltroMonedas,@ReporteAutomatico,@FijarEstatus,@MostrarPor)	

    

	SET @IdReporteDefinidoPorCliente = (SELECT IDENT_CURRENT('CatReportesDefinidosPorCliente'))
	--SECCION PARA AGREGAR LOS CatClasificacionesViajes
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsClasificacionesViajes
	
	SELECT ATT_IdClasificacionViaje
	INTO #TempCatClasificacionesViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ClasificacionesViaje',2) 
	WITH (ATT_IdClasificacionViaje int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatClasificacionesViajes CURSOR FOR
	SELECT * FROM #TempCatClasificacionesViajes
	
	OPEN CursorCatClasificacionesViajes
	FETCH NEXT FROM CursorCatClasificacionesViajes
	INTO @ATT_IdClasificacionViaje
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatReportesDefinidosPorClienteClasificacionViajes(IdReporteDefinidoPorCliente,IdClasificacionViaje,CreadoEl,CreadoPor)
		VALUES(@IdReporteDefinidoPorCliente,@ATT_IdClasificacionViaje,@CreadoEl,@CreadoPor)		

		FETCH NEXT FROM CursorCatClasificacionesViajes
		INTO @ATT_IdClasificacionViaje
	END

	CLOSE CursorCatClasificacionesViajes
	DEALLOCATE CursorCatClasificacionesViajes						
	
	--SECCION PARA AGREGAR LOS CatTiposViajes
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsTiposViajes
	
	SELECT ATT_IdTipoViaje
	INTO #TempCatTiposViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_TiposViajes',2) 
	WITH (ATT_IdTipoViaje int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatTiposViajes CURSOR FOR
	SELECT * FROM #TempCatTiposViajes
	
	OPEN CursorCatTiposViajes
	FETCH NEXT FROM CursorCatTiposViajes
	INTO @ATT_IdTipoViaje
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatReportesDefinidosPorClienteTiposViajes(IdReporteDefinidoPorCliente,IdTipoViaje,CreadoEl,CreadoPor)
		VALUES(@IdReporteDefinidoPorCliente,@ATT_IdTipoViaje,@CreadoEl,@CreadoPor)		

		FETCH NEXT FROM CursorCatTiposViajes
		INTO @ATT_IdTipoViaje
	END

	CLOSE CursorCatTiposViajes
	DEALLOCATE CursorCatTiposViajes						
	
	--SECCION PARA AGREGAR LOS CatGrupoUnidades
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsGruposUnidades
	
	SELECT ATT_IdGrupo
	INTO #TempCatGruposUnidades
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_GruposUnidades',2) 
	WITH (ATT_IdGrupo int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatGruposUnidades CURSOR FOR
	SELECT * FROM #TempCatGruposUnidades
	
	OPEN CursorCatGruposUnidades
	FETCH NEXT FROM CursorCatGruposUnidades
	INTO @ATT_IdGruposUnidades
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatReportesDefinidosPorClienteGruposUnidades(IdReporteDefinidoPorCliente,IdGrupoUnidad,CreadoEl,CreadoPor)
		VALUES(@IdReporteDefinidoPorCliente,@ATT_IdGruposUnidades,@CreadoEl,@CreadoPor)		

		FETCH NEXT FROM CursorCatGruposUnidades
		INTO @ATT_IdGruposUnidades
	END

	CLOSE CursorCatGruposUnidades
	DEALLOCATE CursorCatGruposUnidades						
	
	
	--SECCION PARA AGREGAR LOS CatEstatusViaje
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsEstatusViajes
	
	SELECT ATT_IdEstatusViaje,ATT_Orden
	INTO #TempCatEstatusViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_EstatusViaje',2) 
	WITH (ATT_IdEstatusViaje int,ATT_Orden tinyint)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatEstatusViajes CURSOR FOR
	SELECT * FROM #TempCatEstatusViajes
	
	OPEN CursorCatEstatusViajes
	FETCH NEXT FROM CursorCatEstatusViajes
	INTO @ATT_IdEstatusViaje,@ATT_Orden
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatReportesDefinidosPorClienteEstatusViajes(IdReporteDefinidoPorCliente,IdEstatusViaje,Orden,CreadoEl,CreadoPor)
		VALUES(@IdReporteDefinidoPorCliente,@ATT_IdEstatusViaje,@ATT_Orden,@CreadoEl,@CreadoPor)		

		FETCH NEXT FROM CursorCatEstatusViajes
		INTO @ATT_IdEstatusViaje,@ATT_Orden
	END

	CLOSE CursorCatEstatusViajes
	DEALLOCATE CursorCatEstatusViajes
	
	--SECCION PARA AGREGAR LOS CatDatosViaje
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsDatosViaje
	
	SELECT ATT_IdDatoViaje,ATT_Orden,ATT_NombreEnTabla,ATT_Etiqueta,ATT_EsFecha
	INTO #TempCatDatosViajes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_DatosViajes',2) 
	WITH (ATT_IdDatoViaje int,ATT_Orden tinyint,ATT_NombreEnTabla Varchar(8000),ATT_Etiqueta varchar(30),ATT_EsFecha bit)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatDatosViajes CURSOR FOR
	SELECT * FROM #TempCatDatosViajes
	
	OPEN CursorCatDatosViajes
	FETCH NEXT FROM CursorCatDatosViajes
	INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatReportesDefinidosPorClienteDatosViajes(IdCatReportesDefinidosPorCliente,IdDatoViaje,Orden,CreadoEl,CreadoPor,NombreEnTabla,Etiqueta,EsFecha)
		VALUES(@IdReporteDefinidoPorCliente,@ATT_IdDatoViaje,@ATT_Orden,@CreadoEl,@CreadoPor,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha)		

		FETCH NEXT FROM CursorCatDatosViajes
		INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	END

	CLOSE CursorCatDatosViajes
	DEALLOCATE CursorCatDatosViajes

----- Agregado en solicitud 246/ 22/10/2019 modulo portuario	

	--SECCION PARA AGREGAR LOS CatDatosOrdenContenedores
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsDatosOrdenContenedores
	
	SELECT ATT_IdDatoViaje,ATT_Orden,ATT_NombreEnTabla,ATT_Etiqueta,ATT_EsFecha
	INTO #TempCatDatosOrdenContenedores
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_DatosOrdenContenedores',2) 
	WITH (ATT_IdDatoViaje int,ATT_Orden tinyint,ATT_NombreEnTabla Varchar(8000),ATT_Etiqueta varchar(30),ATT_EsFecha bit)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatDatosOrdenContenedores CURSOR FOR
	SELECT * FROM #TempCatDatosOrdenContenedores
	
	OPEN CursorCatDatosOrdenContenedores
	FETCH NEXT FROM CursorCatDatosOrdenContenedores
	INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatReportesDefinidosPorClienteOrdenEntrega(IdCatReportesDefinidosPorCliente,IdDatoOrden,Orden,CreadoEl,CreadoPor,NombreEnTabla,Etiqueta,EsFecha)
		VALUES(@IdReporteDefinidoPorCliente,@ATT_IdDatoViaje,@ATT_Orden,@CreadoEl,@CreadoPor,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha)		

		FETCH NEXT FROM CursorCatDatosOrdenContenedores
		INTO @ATT_IdDatoViaje,@ATT_Orden,@ATT_NombreEnTabla,@ATT_Etiqueta,@ATT_EsFecha
	END

	CLOSE CursorCatDatosOrdenContenedores
	DEALLOCATE CursorCatDatosOrdenContenedores



	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

