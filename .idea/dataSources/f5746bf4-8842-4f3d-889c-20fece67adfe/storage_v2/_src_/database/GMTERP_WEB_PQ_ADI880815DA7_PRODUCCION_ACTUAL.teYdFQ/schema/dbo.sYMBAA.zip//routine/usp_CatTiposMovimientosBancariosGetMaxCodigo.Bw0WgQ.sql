Create PROCEDURE [dbo].[usp_CatTiposMovimientosBancariosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTiposMovimientosBancarios
go

