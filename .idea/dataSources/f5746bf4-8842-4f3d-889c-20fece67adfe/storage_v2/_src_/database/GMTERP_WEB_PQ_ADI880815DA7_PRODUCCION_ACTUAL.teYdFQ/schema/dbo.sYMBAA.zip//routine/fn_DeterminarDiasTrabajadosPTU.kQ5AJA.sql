
CREATE FUNCTION [dbo].[fn_DeterminarDiasTrabajadosPTU] (@IdEmpleado int, @Ejercicio int)
RETURNS int
AS BEGIN
DECLARE
@Estatus int,
@FechaEstatus date,
@DiasTrabajados int=0,
@FechaVigenteInicio date,
@FechaVigenteFinal date,
@IdTipoPeriodo int = 0,
@FechaInicio date,
@FechaFinal date,
@FechaNula as date = null


set @IdTipoPeriodo = (SELECT IdTipoPeriodo FROM CatEmpleados WHERE IdEmpleado = @IdEmpleado)
set @FechaInicio = (SELECT MIN(FechaInicio) from CatPeriodos where IdTipoPeriodo = @IdTipoPeriodo and Ejercicio = @Ejercicio )
set @FechaFinal = (SELECT MAX(FechaFin) from CatPeriodos where IdTipoPeriodo = @IdTipoPeriodo and Ejercicio = @Ejercicio )

DECLARE Historial_Empl CURSOR LOCAL FOR   
SELECT FechaEstatus,Estatus 
FROM CatEmpleadosHistorial 
WHERE IdEmpleado = @IdEmpleado 
AND IdentificadorDeHistoria = 1  
AND FechaEstatus IS NOT NULL
ORDER BY FechaEstatus ASC
  
OPEN Historial_Empl  
  
FETCH NEXT FROM Historial_Empl   
INTO @FechaEstatus, @Estatus  
  
WHILE @@FETCH_STATUS = 0  
BEGIN  
	IF @Estatus = 1 
	   BEGIN
		  IF DATEPART(YEAR,@FechaEstatus) > @Ejercicio 
		     BEGIN
			   SET @FechaVigenteInicio = @FechaNula
			 END
		  ELSE	
		  IF DATEPART(YEAR,@FechaEstatus) = @Ejercicio 
		     BEGIN
			    SET @FechaVigenteInicio = @FechaEstatus
			 END
		 ELSE
		 IF DATEPART(YEAR,@FechaEstatus) < @Ejercicio 
		     BEGIN
			   SET @FechaVigenteInicio = @FechaInicio
			 END			 
	   END
    ELSE
	IF @Estatus = 2 
	   BEGIN
		 IF DATEPART(YEAR,@FechaEstatus) = @Ejercicio 
		    BEGIN	
  			  IF @FechaEstatus < @FechaFinal 
			     BEGIN
				   SET @FechaVigenteFinal = @FechaEstatus
				 END
			  ELSE
			     BEGIN
				   SET @FechaVigenteFinal = @FechaFinal
				 END	
			  SET @DiasTrabajados = @DiasTrabajados + (DATEDIFF(DD,@FechaVigenteInicio,@FechaVigenteFinal)+1)
			  SET @FechaVigenteFinal = @FechaNula
			  SET @FechaVigenteInicio =@FechaNula			  
			END
		 ELSE
		 IF DATEPART(YEAR,@FechaEstatus) < @Ejercicio
		    BEGIN			  
			  SET @FechaVigenteFinal = @FechaNula	
			  SET @FechaVigenteInicio = @FechaNula
			END
		 ELSE
		 IF DATEPART(YEAR,@FechaEstatus) > @Ejercicio   
			BEGIN	
			  IF @FechaVigenteInicio IS NOT NULL 
			     BEGIN
					SET @FechaVigenteFinal = @FechaFinal
  					SET @DiasTrabajados = @DiasTrabajados + (DATEDIFF(DD,@FechaVigenteInicio,@FechaVigenteFinal)+1)
					SET @FechaVigenteFinal = @FechaNula
					SET @FechaVigenteInicio =@FechaNula
			     END
			END
	   END
    ELSE
	IF @Estatus = 3 
	   BEGIN
	     IF DATEPART(YEAR,@FechaEstatus) < @Ejercicio
		    BEGIN
			  set @FechaVigenteInicio = @FechaInicio			  
			END
		 ELSE
		 IF DATEPART(YEAR,@FechaEstatus) = @Ejercicio
		    BEGIN		  
			  SET @FechaVigenteInicio = @FechaEstatus			
			END
		 ELSE
		 IF DATEPART(YEAR,@FechaEstatus) > @Ejercicio
		    BEGIN
			  IF @FechaVigenteInicio IS NOT NULL 			     
			     BEGIN
				   SET @FechaVigenteFinal = @FechaFinal
				   SET @DiasTrabajados = @DiasTrabajados + (DATEDIFF(DD,@FechaVigenteInicio,@FechaVigenteFinal)+1)
				   SET @FechaVigenteInicio = @FechaNula				   
				   SET @FechaVigenteFinal = @FechaNula
				 END
			END
	   END
    
    FETCH NEXT FROM Historial_Empl   
    INTO @FechaEstatus, @Estatus  
END   
CLOSE Historial_Empl;  
DEALLOCATE Historial_Empl;  

IF @Estatus =  1
   BEGIN
     IF DATEPART(YEAR,@FechaEstatus) < @Ejercicio
	    BEGIN
		  SET @FechaVigenteFinal = @FechaFinal
		  SET @DiasTrabajados = @DiasTrabajados + DATEDIFF(DD,@FechaVigenteInicio,@FechaVigenteFinal)+1
		END
	 ELSE
	 IF DATEPART(YEAR,@FechaEstatus) = @Ejercicio
	    BEGIN
		  SET @FechaVigenteFinal = @FechaFinal
		  SET @DiasTrabajados = @DiasTrabajados + DATEDIFF(DD,@FechaVigenteInicio,@FechaVigenteFinal)+1
		END
	 ELSE
	 IF DATEPART(YEAR,@FechaEstatus) > @Ejercicio
	    BEGIN		  
		  SET @DiasTrabajados = 0
		END
   END
    IF @Estatus = 3 
      BEGIN
	    IF DATEPART(YEAR,@FechaVigenteInicio) = @Ejercicio
		   BEGIN		      
		     SET @FechaVigenteFinal = @FechaFinal
		   END
		ELSE
		IF DATEPART(YEAR,@FechaVigenteInicio) < @Ejercicio
		   BEGIN
		     SET @FechaVigenteFinal = @FechaFinal
		   END
		ELSE
		IF DATEPART(YEAR,@FechaVigenteInicio) > @Ejercicio
		   BEGIN
		     SET @FechaVigenteFinal = @FechaNula
			 SET @FechaVigenteFinal = @FechaNula
		   END
		IF @FechaVigenteInicio IS NOT NULL AND @FechaVigenteFinal IS NOT NULL 
		   BEGIN
		     SET @DiasTrabajados = @DiasTrabajados + DATEDIFF(DD,@FechaVigenteInicio,@FechaVigenteFinal)+1
		   END
	  END
   RETURN @DiasTrabajados
END
go

