CREATE PROCEDURE [dbo].[usp_ProChequesMaxNumeroCheque]  
@IdCuentaBancaria int 
AS  
Select ISNULL(MAX(NumeroCheque),0)+1 AS NumeroCheque from ProCheques where IdCuentaBancaria = @IdCuentaBancaria
go

