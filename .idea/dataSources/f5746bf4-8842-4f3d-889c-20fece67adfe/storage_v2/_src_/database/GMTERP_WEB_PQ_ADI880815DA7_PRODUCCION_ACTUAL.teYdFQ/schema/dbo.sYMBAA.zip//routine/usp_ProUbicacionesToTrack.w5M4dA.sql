
CREATE PROCEDURE [dbo].[usp_ProUbicacionesToTrack]
	@dsProUbicacionesUnidadesTemp ntext,
	@IdPeticion varchar(100)
AS
/*****************************************************************************************************************************
procedimiento:[usp_ProUbicacionesToTrack]
Parámetros: 
	@IdUsuario int,
	@dsProUbicacionesUnidadesTemp ntext,
	@IdPeticion varchar(100),
	@FechaHoraSucursal datetime
Descripción: El procedimiento se encarga de mandar a guardar la informacion de las ubicaciones de las unidades
			 y procesar parametros especificos que vienen del lado del web como viajes, clientes, color de la unidad
			 entre otros, al final despues de esto pasa la informaicon en una tabla asia el webn
08/11/2019   Se le agregaro el parametro de chapa electromagnetica
Implementada por: Angel Espinoza.
Modificada por Angel Espinoza.
Fecha de implementacion: 05/23/2020
Versión GMTERP_ProcesosEspeciales 1.11.5

Invocada desde: <GMTERP_ProcesosEspeciales, ClsProUbicaciones(Execute usp_ProUbicacionesUnidades)>

Solicitud 2128

*****************************************************************************************************************************/
DECLARE
	@docHandle int,
	@variable VARCHAR (10) = '000000'
	
	CREATE TABLE #ProUbicacionesToTrack(
	[IdViajeTrayecto] [int] NULL,
	[IdSatelital] [varchar](26) COLLATE Modern_Spanish_CS_AS NULL,
	[Plataforma] [varchar](12) COLLATE Modern_Spanish_CS_AS NULL,
	[Evento] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[FechaHoraEvento] [datetime] NULL,
	[Tiempo] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,
	[Ubicacion] [varchar](650) COLLATE Modern_Spanish_CS_AS NULL,
	[Direccion] [varchar](5) COLLATE Modern_Spanish_CS_AS NULL,
	[Odometro] [float] NULL,
	[Velocidad] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[EstadoModuloGPS] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[PorcentajeBateria] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[VoltajeBateriaInterna] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[VoltajeVehiculo] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[Latitud] [float] NULL,
	[Longitud] [float] NULL,
	[EstadoMotor] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[EstadoModoTrabajo] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[CantidadSatelites] [tinyint] NULL,
	[NivelGSM] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[TipoSenal] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[NivelCombustiblePorcentaje] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[CombustibleConsumido] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[CombustibleRalenti] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[HorasRalenti] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[HorasMotor] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[CinturonSeguridad] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[TemperaturaRefrigerante] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[TemperaturaAceite] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[RPM] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[CodigosComputadora] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[AnguloPedal] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[PorcentajeCombustible] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[ConsumoInstantaneo] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[PresionAceite] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Sensor1] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Sensor2] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Sensor3] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Sensor4] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[IdUnidad] [int],
	[Unidad] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,
	[Viaje] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,
	[Identificador] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,
	[Ruta] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,
	[Operador] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Remolque1] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Remolque2] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[EstatusViaje] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL
	)
	
BEGIN TRANSACTION

BEGIN TRY
	
	IF ISNULL(CAST(@dsProUbicacionesUnidadesTemp AS VARCHAR(MAX)),'') = ''
	RAISERROR(N'El xml de ubicaciones es un parámetro requerido',
	16,
	1
	)
	
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProUbicacionesUnidadesTemp

	
	INSERT INTO #ProUbicacionesToTrack(
	[Viaje],
	[Identificador],
	[Ruta],
	[Operador],
	[Remolque1],
	[Remolque2],
	[EstatusViaje],
	[Unidad],
	[IdUnidad],
	[IdViajeTrayecto],
	[IdSatelital],
	[Plataforma],
	[Evento],
	[FechaHoraEvento],
	[Tiempo],
	[Ubicacion],
	[Direccion],
	[Odometro],
	[Velocidad],
	[EstadoModuloGPS],
	[PorcentajeBateria],
	[VoltajeBateriaInterna],
	[VoltajeVehiculo],
	[Latitud],
	[Longitud],
	[EstadoMotor],
	[EstadoModoTrabajo],
	[CantidadSatelites],
	[NivelGSM],
	[TipoSenal],
	[NivelCombustiblePorcentaje],
	[CombustibleConsumido],
	[CombustibleRalenti],
	[HorasRalenti],
	[HorasMotor],
	[CinturonSeguridad],
	[TemperaturaRefrigerante],
	[TemperaturaAceite],
	[RPM],
	[CodigosComputadora],
	[AnguloPedal],
	[PorcentajeCombustible],
	[ConsumoInstantaneo],
	[PresionAceite],
	[Sensor1],
	[Sensor2],
	[Sensor3],
	[Sensor4]
	)
	SELECT 
	'N/A',
	'N/A',
	'N/A',
	'N/A',
	'N/A',
	'N/A',
	'N/A',
	cu.Codigo,
	cu.IdUnidad,
	put.IdViajeTrayecto,
	put.NoSerie,
	put.Plataforma,
	put.Evento,
	put.FechaHoraEvento,
	put.Tiempo,
	put.Ubicacion,
	put.Direccion,
	put.Odometro,
	put.Velocidad,
	put.EstadoModuloGPS,
	put.PorcentajeBateria,
	put.VoltajeBateriaInterna,
	put.VoltajeVehiculo,
	put.Latitud,
	put.Longitud,
	put.EstadoMotor,
	put.EstadoModoTrabajo,
	put.CantidadSatelites,
	put.NivelGSM,
	put.TipoSenal,
	put.NivelCombustiblePorcentaje,
	put.CombustibleConsumido,
	put.CombustibleRalenti,
	put.HorasRalenti,
	put.HorasMotor,
	put.CinturonSeguridad,
	put.TemperaturaRefrigerante,
	put.TemperaturaAceite,
	put.RPM,
	put.CodigosComputadora,
	put.AnguloPedal,
	put.PorcentajeCombustible,
	put.ConsumoInstantaneo,
	put.PresionAceite,
	put.Sensor1,
	put.Sensor2,
	put.Sensor3,
	put.Sensor4
	FROM OPENXML(@docHandle, N'/Ubicaciones/Ubicacion',2) 
	WITH ([IdViajeTrayecto] [int],
	NoSerie varchar(200) COLLATE Modern_Spanish_CS_AS ,
	Plataforma varchar(12) COLLATE Modern_Spanish_CS_AS ,
	Evento varchar(50) COLLATE Modern_Spanish_CS_AS ,
	FechaHoraEvento datetime ,
	Tiempo varchar(200) COLLATE Modern_Spanish_CS_AS ,
	Ubicacion varchar(650) COLLATE Modern_Spanish_CS_AS ,
	Direccion varchar(5) COLLATE Modern_Spanish_CS_AS ,
	Odometro float ,
	Velocidad varchar(50) COLLATE Modern_Spanish_CS_AS ,
	EstadoModuloGPS varchar(100) COLLATE Modern_Spanish_CS_AS ,
	PorcentajeBateria varchar(50) COLLATE Modern_Spanish_CS_AS ,
	VoltajeBateriaInterna varchar(50) COLLATE Modern_Spanish_CS_AS ,
	VoltajeVehiculo varchar(50) COLLATE Modern_Spanish_CS_AS ,
	Latitud float ,
	Longitud float ,
	EstadoMotor varchar(100) COLLATE Modern_Spanish_CS_AS ,
	EstadoModoTrabajo varchar(100) COLLATE Modern_Spanish_CS_AS ,
	CantidadSatelites tinyint ,
	NivelGSM varchar(100) COLLATE Modern_Spanish_CS_AS ,
	TipoSenal varchar(100) COLLATE Modern_Spanish_CS_AS ,
	NivelCombustiblePorcentaje varchar(100) COLLATE Modern_Spanish_CS_AS ,
	CombustibleConsumido varchar(100) COLLATE Modern_Spanish_CS_AS ,
	CombustibleRalenti varchar(100) COLLATE Modern_Spanish_CS_AS ,
	HorasRalenti varchar(100) COLLATE Modern_Spanish_CS_AS ,
	HorasMotor varchar(100) COLLATE Modern_Spanish_CS_AS ,
	CinturonSeguridad varchar(100) COLLATE Modern_Spanish_CS_AS ,
	TemperaturaRefrigerante varchar(100) COLLATE Modern_Spanish_CS_AS ,
	TemperaturaAceite varchar(100) COLLATE Modern_Spanish_CS_AS ,
	RPM varchar(100) COLLATE Modern_Spanish_CS_AS ,
	CodigosComputadora varchar(100) COLLATE Modern_Spanish_CS_AS ,
	AnguloPedal varchar(100) COLLATE Modern_Spanish_CS_AS ,
	PorcentajeCombustible varchar(100) COLLATE Modern_Spanish_CS_AS ,
	ConsumoInstantaneo varchar(100) COLLATE Modern_Spanish_CS_AS ,
	PresionAceite varchar(100) COLLATE Modern_Spanish_CS_AS ,
	Sensor1 varchar(100) COLLATE Modern_Spanish_CS_AS ,
	Sensor2 varchar(100) COLLATE Modern_Spanish_CS_AS ,
	Sensor3 varchar(100) COLLATE Modern_Spanish_CS_AS ,
	Sensor4 varchar(100) COLLATE Modern_Spanish_CS_AS)
	AS put
	INNER JOIN CatUnidades AS cu ON put.NoSerie = cu.IdentificadorSatelital 
	LEFT JOIN CatOperadores as co ON cu.IdOperador = co.IdOperador
	WHERE cu.IdentificadorSatelital IS NOT NULL AND  cu.IdentificadorSatelital <> ''
	AND cu.Activa = 1
		
	EXEC sp_xml_removedocument @docHandle;
	
	WITH cte AS ( 
	SELECT pvt.IdViajeTrayecto,cs.Abreviacion,pv.Viaje,pv.NoViajeCliente,cor.OrigenDestino AS Origen,
	cde.OrigenDestino AS Destino,co1.Nombre AS NombreOperadorViaje,pv.CodigoUnidadCarga1,
	pv.CodigoUnidadCarga2,cev.Estatus,cu.IdUnidad,	 
	ROW_NUMBER() OVER (partition by cu.IdentificadorSatelital ORDER BY cu.IdentificadorSatelital) AS rownumber
	FROM CatUnidades AS cu 
	LEFT JOIN ProViajesTrayectos AS pvt ON cu.IdUnidad = pvt.IdUnidadCamion
	LEFT JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
	LEFT JOIN CatOrigenesDestinos AS cor ON pvt.IdOrigen = cor.IdOrigenDestino
	LEFT JOIN CatOrigenesDestinos AS cde ON pvt.IdDestino = cde.IdOrigenDestino
	LEFT JOIN CatSucursales AS cs ON pv.IdSucursal = cs.IdSucursal
	LEFT JOIN CatEstatusViaje AS cev ON cev.IdEstatuViaje = pv.IdEstatuViaje
	LEFT JOIN CatOperadores AS co1 ON pvt.IdOperador = co1.IdOperador 
	WHERE pvt.IdViajeTrayecto IN(SELECT puut.IdViajeTrayecto FROM #ProUbicacionesToTrack AS puut)
	)
	
	UPDATE puut SET 
	puut.Viaje = c.Abreviacion+'-'+LEFT(@variable,6 - LEN(c.Viaje))+cast(c.Viaje as varchar),
	puut.Identificador = c.NoViajeCliente,
	puut.Ruta = c.Origen+' / '+c.Destino,
	puut.Operador = c.NombreOperadorViaje,
	puut.Remolque1 = c.CodigoUnidadCarga1,
	puut.Remolque2 = c.CodigoUnidadCarga2,
	puut.EstatusViaje = c.Estatus
	FROM #ProUbicacionesToTrack AS puut 
	INNER JOIN cte AS c ON puut.IdViajeTrayecto = c.IdViajeTrayecto
	WHERE c.rownumber = 1 
	
	
	SELECT Viaje,Identificador,Unidad,Latitud,Longitud,IdSatelital,Plataforma,Evento,FechaHoraEvento,
	Tiempo,Ubicacion,Direccion,Odometro,Velocidad,EstadoModuloGPS,PorcentajeBateria,VoltajeBateriaInterna,
	VoltajeVehiculo,EstadoMotor,EstadoModoTrabajo,CantidadSatelites,NivelGSM,TipoSenal,
	NivelCombustiblePorcentaje,CombustibleConsumido,CombustibleRalenti,HorasRalenti,HorasMotor,CinturonSeguridad,
	TemperaturaRefrigerante,TemperaturaAceite,RPM,CodigosComputadora,AnguloPedal,PorcentajeCombustible,
	ConsumoInstantaneo,PresionAceite,Sensor1,Sensor2,Sensor3,Sensor4
	FROM #ProUbicacionesToTrack 
	ORDER BY IdUnidad,FechaHoraEvento
	
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION

	EXECUTE usp_SisErrorsGrabar @IdPeticion;
END CATCH

IF @@TRANCOUNT > 0  
    COMMIT TRANSACTION;
go

