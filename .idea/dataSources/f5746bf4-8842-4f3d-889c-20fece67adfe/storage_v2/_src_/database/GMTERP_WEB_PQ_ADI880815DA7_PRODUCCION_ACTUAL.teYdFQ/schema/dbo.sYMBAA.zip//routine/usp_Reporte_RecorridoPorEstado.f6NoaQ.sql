CREATE PROCEDURE [dbo].[usp_Reporte_RecorridoPorEstado]
@XmlTrayectosGPS NVARCHAR(max) ,
@Agrupado int
AS
/*
PARÁMETROS:
	@XmlTrayectos NTEXT: Entrada trayectos de los cuales se requiere la información.
	@Agrupado int: Indica el tipo de reporte que va a generar el usp
DESCRIPCIÓN:
	 Recibe como parámetro un XML que contiene todos los trayectos resultantes de GMTGPSWS: GeneraReporteRecorridoPorEstadoXML();
	 esto para unirlo con el resto de la información que requiere el reporte Recorrido por Estado.
IMPLEMENTADA POR:
	Abril CG
FECHA DE IMPLEMENTACIÓN:
	2019-07-15
VERSIÓN:
	GMTERPV8 :						8.0.44.12
	GMTERPV8_ProcesosEspeciales :	1.8.10
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-07-17
INVOCADA DESDE:
		GMTERPV8 : PAGE_Report_Trafico_RecorridoPorEstado
	hace uso de
		GMTERPV8_ProcesosEspeciales : ReporteRecorridoPorEstadoDetallado
	utiliza 
		usp_Reporte_RecorridoPorEstado
SOLICITUD: 
	012513
*/
DECLARE 
@docHandle INT
DECLARE @TempXmlUbicacionesGPS TABLE
(
  IdTabla INT IDENTITY(1,1),
  IdViajeTrayecto INT,
  IdUnidad INT,
  Estado VARCHAR(max),
  DistanciaRecorridaKms NVARCHAR(max),
  DistanciaRecorridaMillas NVARCHAR(max),
  Carreteras VARCHAR(max), 
  PRIMARY KEY NONCLUSTERED(IdTabla)
)
BEGIN
	BEGIN TRY

		 IF @XmlTrayectosGPS IS NOT NULL
		 BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XmlTrayectosGPS
  
			INSERT INTO @TempXmlUbicacionesGPS
			SELECT 
				IdViajeTrayecto, 
				IdUnidad, 
				Estado, 
				ROUND(DistaciaRecorridaKms, 5, 0) AS DistaciaRecorridaKms	, 
				ROUND(DistanciaRecorridaMillas, 5, 0) AS DistanciaRecorridaMillas, 
				Carreteras
			FROM OPENXML(@docHandle, N'/Trayecto/DetalleTrayecto',1) 
			WITH (IdViajeTrayecto INT, 
			IdUnidad INT, 
			Estado VARCHAR(MAX), 
			DistaciaRecorridaKms NVARCHAR(max), 
			DistanciaRecorridaMillas NVARCHAR(max), 
			Carreteras VARCHAR(MAX))
  
			EXEC sp_xml_removedocument @docHandle
		 END

		 IF @Agrupado = 0 
		 BEGIN
			;WITH CTE_Trayectos AS ( 
				SELECT
				pvt.IdUnidadCamion,
				pvt.IdViajeTrayecto,
				cu.Codigo,
				(CASE 
				WHEN cu.PlacasExtranjeras <> '' THEN 
					CASE
						WHEN cu.Placas <> '' THEN  cu.Placas +' / '+ cu.PlacasExtranjeras
						ELSE cu.PlacasExtranjeras
					END
				ELSE 
					cu.Placas
				END) AS Placasunidad,
				CAST(pv.FechaHora as DATE ) AS FechaHora,
				tempGPS.Estado,
				pvt.OdometroInicial AS OdometroInicialKms,
				(pvt.OdometroInicial*0.62137) AS OdometroInicialMillas,
				CatOrigen.OrigenDestino AS Origen,
				CatOrigen.Latitud AS LatitudOrigen,
				CatOrigen.Longitud AS LongitudOrigen,
				pvt.OdometroFinal AS OdometroFinalKms,
				(pvt.OdometroFinal*0.62137) AS OdometroFinalMillas,
				CatDestino.OrigenDestino AS Destino,
				CatDestino.Latitud AS LatitudDestino,
				CatDestino.Longitud AS LongitudDestino,
				tempGPS.Carreteras,
				tempGPS.DistanciaRecorridaMillas AS DistanciaRecorridaMillasGPS,
				tempGPS.DistanciaRecorridaKms AS DistanciaRecorridaKmsGPS
				FROM
				ProViajes pv
				INNER JOIN  ProViajesTrayectos pvt ON pv.IdViaje = pvt.IdViaje
				INNER JOIN  @TempXmlUbicacionesGPS tempGPS ON pvt.IdViajeTrayecto = tempGPS.IdViajeTrayecto
				INNER JOIN  CatUnidades cu ON pvt.IdUnidadCamion = cu.IdUnidad
				INNER JOIN  CatOrigenesDestinos CatOrigen ON pvt.IdOrigen = CatOrigen.IdOrigenDestino
				INNER JOIN  CatOrigenesDestinos CatDestino ON pvt.IdDestino = CatDestino.IdOrigenDestino
			)

			SELECT
			cte.*,
			(cte.OdometroFinalKms-cte.OdometroInicialKms) AS DiferenciaOdometroKms,
			(cte.OdometroFinalMillas-cte.OdometroInicialMillas) AS DiferenciaOdometroMillas
			FROM 
			CTE_Trayectos cte
			ORDER BY cte.Codigo,cte.FechaHora
		END
		ELSE /*--------------------------------------------------------------------------------*/
		BEGIN
			;WITH CTE_Trayectos AS ( 
				SELECT
				pvt.IdUnidadCamion,
				cu.Codigo,
				(CASE 
				WHEN cu.PlacasExtranjeras <> '' THEN 
					CASE
						WHEN cu.Placas <> '' THEN  cu.Placas +' / '+ cu.PlacasExtranjeras
						ELSE cu.PlacasExtranjeras
					END
				ELSE 
					cu.Placas
				END) AS Placasunidad,
				
				tempGPS.Estado,
				pvt.OdometroInicial AS OdometroInicialKms,
				(pvt.OdometroInicial*0.62137) AS OdometroInicialMillas,
				pvt.OdometroFinal AS OdometroFinalKms,
				(pvt.OdometroFinal*0.62137) AS OdometroFinalMillas,
				tempGPS.DistanciaRecorridaMillas AS DistanciaRecorridaMillasGPS,
				tempGPS.DistanciaRecorridaKms AS DistanciaRecorridaKmsGPS
				FROM
				ProViajes pv
				INNER JOIN  ProViajesTrayectos pvt ON pv.IdViaje = pvt.IdViaje
				INNER JOIN  @TempXmlUbicacionesGPS tempGPS ON pvt.IdViajeTrayecto = tempGPS.IdViajeTrayecto
				INNER JOIN  CatUnidades cu ON pvt.IdUnidadCamion = cu.IdUnidad
				INNER JOIN  CatOrigenesDestinos CatOrigen ON pvt.IdOrigen = CatOrigen.IdOrigenDestino
				INNER JOIN  CatOrigenesDestinos CatDestino ON pvt.IdDestino = CatDestino.IdOrigenDestino
			)

			SELECT
			cte.IdUnidadCamion,
			cte.Codigo,
			cte.Placasunidad,
			cte.Estado,
			SUM(CAST((cte.OdometroFinalKms-cte.OdometroInicialKms) AS FLOAT)) AS DiferenciaOdometroKms,
			SUM(CAST((cte.OdometroFinalMillas-cte.OdometroInicialMillas)AS FLOAT)) AS DiferenciaOdometroMillas,
			SUM(CAST(cte.DistanciaRecorridaMillasGPS AS FLOAT)) AS DistanciaRecorridaMillasGPS,
			SUM(CAST(cte.DistanciaRecorridaKmsGPS AS FLOAT)) AS DistanciaRecorridaKmsGPS
			FROM 
			CTE_Trayectos cte
			GROUP BY cte.IdUnidadCamion,cte.Codigo,cte.Placasunidad,cte.Estado
			ORDER BY cte.Codigo,cte.Estado
		END
 
	END TRY
BEGIN CATCH
   	IF(@@TRANCOUNT > 0)
	  ROLLBACK TRANSACTION;	
   END CATCH
END
go

