
CREATE PROCEDURE [dbo].[usp_CatUsuariosContactosAgregar]
	@Contacto varchar(100),	
	@NumeroTelefono varchar(20),	
	@IdUnidad int, 
	@FechaInicio datetime,
	@FechaVencimiento datetime,
	@IdUsuario int,	
	@CreadoEl datetime,
	@CreadoPor int,
	@IdPeticion varchar(100)	
	/* *************************************************************************************************
	Procedimiento usp_CatUsuariosContactosAgregar]=
	Descripción: El procedimiento se encarga de guardar los contacos de los clientes, esto para que ellos mismos
	visualicen una liga generada y poder accesar a la pagina del sistema de here. 
	Implementada por: Angel Espinoza.
	Fecha de implementacion: 11/10/2019
	Versión GMTERP: No cuenta con version

	Invocada desde: <GMTERPMOVIL, SERVERPROCEDURES, Agregar(Execute usp_CatUsuariosContactosAgregar)

	Solicitud 434
	***************************************************************************************************** */
AS
DECLARE
	@IdUnidadContacto int
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdUnidad,0)= 0
		RAISERROR(N'El IdUnidad es un campo requerido',
			16,
			1
			)
	IF RTRIM(LTRIM(@Contacto)) = ''
		RAISERROR(N'El Contacto es un campo requerido',
			16,
			1
			)
	IF RTRIM(LTRIM(@NumeroTelefono)) = ''
		RAISERROR(N'El teléfono es un campo requerido',
			16,
			1
			)	
	IF ISNULL(@IdUsuario,0) = 0
		RAISERROR(N'El Usuario es un campo requerido',
			16,
			1
			)		
	INSERT INTO CatUsuariosContactos(Contacto,NumeroTelefono,IdUnidad,FechaInicio,
	FechaVencimiento,IdUsuario,CreadoPor,CreadoEl)
	VALUES(@Contacto,@NumeroTelefono,@IdUnidad,@FechaInicio,
	@FechaVencimiento,@IdUsuario,@CreadoPor,@CreadoEl)

	SET @IdUnidadContacto = @@IDENTITY
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
RETURN @IdUnidadContacto
go

