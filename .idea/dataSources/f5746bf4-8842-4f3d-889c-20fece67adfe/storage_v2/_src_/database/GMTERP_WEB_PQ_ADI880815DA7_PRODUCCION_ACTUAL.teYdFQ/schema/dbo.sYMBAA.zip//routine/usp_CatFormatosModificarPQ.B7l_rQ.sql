
-- =============================================
-- Author:		<Author,,Name>
-- ALTER date: <ALTER Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_CatFormatosModificarPQ]
	@IdFormato INT,
	@Formato VARCHAR(50),
	@TipoProceso INT,
	@FormatoWDE VARCHAR(250),
	@NombreArchivo VARCHAR(256),
	@ModificadoPor INT,
	@ModificadoEl Datetime,
	@Activo Bit
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Formato, '') = '' begin
			RAISERROR(N'*INICIO*El nombre del formato es un campo requerido*FIN*', 16, 1);
			return
		end
		
		IF ISNULL(@NombreArchivo, '') = '' begin
			RAISERROR(N'*INICIO*El nombre de archivo del formato es un campo requerido*FIN*', 16, 1);
			return
		end
		
		UPDATE CatFormatos SET
		Formato = @Formato,
		TipoProceso = @TipoProceso,
		FormatoWDE = @FormatoWDE,
		NombreArchivo = @NombreArchivo,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl,
		Activo = @Activo
		WHERE IdFormato = @IdFormato
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

