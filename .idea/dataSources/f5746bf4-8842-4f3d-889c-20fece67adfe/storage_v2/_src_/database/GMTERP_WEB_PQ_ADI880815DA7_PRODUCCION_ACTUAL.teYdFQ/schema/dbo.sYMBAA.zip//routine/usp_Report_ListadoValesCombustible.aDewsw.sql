
CREATE PROCEDURE [dbo].[usp_Report_ListadoValesCombustible]
@FechaInicial date ,
@FechaFinal date ,
@Filtro varchar(200) ,
@NumeroProveedorDesde int ,
@NumeroProveedorHasta int ,
@IdUsuario int 
AS		
DECLARE 
@SQL nvarchar(max),
@Parametros nvarchar(max), 
@CadenaUnidades VARCHAR(MAX) ,
@IdUnidad NVARCHAR(255),
@SigUnidad INT
/*
	@FechaInicial: Fecha Desde que selecciona el usuario.
	@FechaFinal: Fecha Hasta que selecciona el usuario.
	@Filtro: Vales de combustible a mostar [Todos/Comprobados/Sin comprobar/Cancelados]
	@NumeroOperadorDesde: Numero de proveedor desde seleccionado por el usuario.
	@NumeroOperadorHasta: Numero de proveedor hasta seleccionado por el usuario.
	@IdUsuario: identificador del usuario que genero el reporte para obtener las unidades que selecciono.

	SOLICITUD 012479
	Versión 8.0.44.05
	Este procedimiento almacenado sustituye el query principal del reporte Listado de Vales de Combustible, ya que
	hay algunos usuarios que quieren generar el reporte por mas de 30mil unidades y el operador IN no lo soporta.
	Se opto por guardar todas las unidades seleccionadas por el usuario en SisParametros como una cadena y separarlos por 
	la ',' y guardarlos en una tabla temporal para poder obtener el reporte.
	La tabla temporal se elimina al finalizar la consulta.
*/
--Se obtiene los identificadores de las unidades
SET @CadenaUnidades= (SELECT Parametros FROM SisParametrosPagina WHERE Pagina = 'PAGE_Report_Trafico_ListadoValesCombustible' AND IdUsuario = @IdUsuario)

--Se crea una tabla temporal donde se insertan los identificadores
CREATE TABLE #ReporteListadoValesCombustible( IdUnidad INT)


IF CHARINDEX(',', @CadenaUnidades) > 0 
BEGIN
--ciclo para realizar un split e insertar los identificadores en la tabla temporal
	WHILE CHARINDEX(',', @CadenaUnidades) > 0
	BEGIN
		SELECT @SigUnidad  = CHARINDEX(',', @CadenaUnidades)  
		SELECT @IdUnidad = SUBSTRING(@CadenaUnidades, 1, @SigUnidad-1)
	 
		INSERT INTO #ReporteListadoValesCombustible
		SELECT @IdUnidad

		SELECT @CadenaUnidades = SUBSTRING(@CadenaUnidades, @SigUnidad+1, LEN(@CadenaUnidades)-@SigUnidad)
	END
	IF @CadenaUnidades <> ''
	BEGIN
		INSERT INTO #ReporteListadoValesCombustible
		SELECT @CadenaUnidades
	END
END
 ELSE
 BEGIN
	 INSERT INTO #ReporteListadoValesCombustible
	 SELECT @CadenaUnidades
 END

--Consulta dinamica		
 SET @SQL =
		N'SELECT 
		pvc.IdValeCombustible, pvc.Folio, pvt.IdViaje, pvc.Fecha, co.NumeroOperador, co.Nombre, cu.Codigo, pvc.Litros, pvc.Odometro, pvc.Concepto, cs.Abreviacion AS Sucursal, pv.Viaje, pv.IdViaje AS EXPR1, 
		cp.NumeroProveedor, cp.NombreFiscal, pvc.CanceladoEl, pvc.IdGastoViaje, pvc.ImpresoPor, pvc.ImpresoEl, isdate(pvc.CanceladoEl) AS Cancelado,
		(SELECT Folio From ProLiquidaciones where 
		ProLiquidaciones.IdLiquidacion =   pvt.IdLiquidacion ) AS FolioLiquidacion
		FROM  ProViajesTrayectos AS pvt RIGHT OUTER JOIN
		ProValesCombustible AS pvc INNER JOIN
		CatOperadores AS co ON pvc.IdOperador = co.IdOperador INNER JOIN
		CatUnidades AS cu ON pvc.IdUnidad = cu.IdUnidad INNER JOIN
		CatProveedores AS cp ON pvc.IdProveedor = cp.IdProveedor ON pvt.IdViajeTrayecto = pvc.IdViajeTrayecto LEFT OUTER JOIN
		ProViajes AS pv ON pvt.IdViaje = pv.IdViaje LEFT OUTER JOIN
		CatSucursales AS cs ON pv.IdSucursal = cs.IdSucursal
		WHERE CAST(pvc.Fecha AS date) >= @QueryFechaInicial AND CAST(pvc.Fecha AS date) <= @QueryFechaFinal
		AND cu.IdUnidad IN (SELECT IdUnidad FROM #ReporteListadoValesCombustible)
		AND cp.NumeroProveedor between @QueryNumeroProveedorDesde AND @QueryNumeroProveedorHasta'+
		@Filtro + 
		' Order By pvc.Folio';
 
 SET @Parametros = N'@QueryFechaInicial date,@QueryFechaFinal date,@QueryNumeroProveedorDesde int,@QueryNumeroProveedorHasta int ';
 EXEC sp_executesql @SQL, @Parametros, @QueryFechaInicial = @FechaInicial, @QueryFechaFinal = @FechaFinal, @QueryNumeroProveedorDesde = @NumeroProveedorDesde, @QueryNumeroProveedorHasta = @NumeroProveedorHasta

--si existe la tabla temporal se elimina
IF OBJECT_ID('tempdb.dbo.#ReporteListadoValesCombustible') IS NOT NULL
BEGIN
	DROP TABLE #ReporteListadoValesCombustible
END
go

