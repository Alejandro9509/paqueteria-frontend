CREATE PROCEDURE [dbo].[usp_CatClientesEliminar]
	@IdCliente int,
	@IdPeticion varchar(100)
AS
/*
MODIFICADO:
	Se agrego en la seccion de eliminar la cuenta contable , un delete para la cuenta contable 
	en el catalogo de CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-10-01
SOLICITUD: 
	SOLICITUD 000266

MODIFICADO:
	Se cambio el mensaje de validacion de documentos fiscales relacionados "certificado" por "Cliente"
	Se cambio el top 1 * por "Top 1 IdViaje" y "Top 1 IdFactura".
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2021-01-27
SOLICITUD: 
	SOLICITUD 003660
*/
BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 IdViaje FROM ProViajes WHERE IdCliente = @IdCliente)
		RAISERROR(N'El cliente tiene documento fiscales ligados, no es posible eliminarlo',
			16,
			1
			)
	
	IF EXISTS(SELECT TOP 1 IdFactura FROM ProFacturas WHERE IdCliente = @IdCliente)
		RAISERROR(N'El cliente tiene documento fiscales ligados, no es posible eliminarlo',
			16,
			1
			)

	DELETE FROM ProInventarioUnidades WHERE IdCliente = @IdCliente
	
	DELETE FROM ProInventarioUnidadesHistorico WHERE IdCliente = @IdCliente
	
	DELETE FROM CatRutas WHERE IdCliente = @IdCliente
	
	UPDATE CatClientesContactosClientesAsociados Set IdCliente = NULL Where IdCliente = @IdCliente --Se actualizan los clientes asociados como null para poder eliminarlos	
	DELETE FROM CatClientesContactosClientesAsociados Where IdCliente = NULL -- Se eliminan los Nulos
	 
	DELETE FROM CatClientes	WHERE IdCliente = @IdCliente
	

    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
		/*Se elimina la cuenta contable del catalogo CatCuentasContablesSaldos*/
		DELETE FROM CatCuentasContablesSaldos WHERE
		IdCuentaContable IN (SELECT IdCuentaContable FROM CatCuentasContables WHERE CatalogoLigado = 'CatClientes' AND IdCatalogoLigado = @IdCliente)

        DELETE FROM CatCuentasContables 
        WHERE CatalogoLigado = 'CatClientes' AND IdCatalogoLigado = @IdCliente
    END	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

