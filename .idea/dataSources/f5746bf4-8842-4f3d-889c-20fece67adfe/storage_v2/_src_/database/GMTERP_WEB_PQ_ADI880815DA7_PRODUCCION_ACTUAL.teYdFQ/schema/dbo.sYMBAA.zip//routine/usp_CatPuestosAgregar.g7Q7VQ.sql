
CREATE PROCEDURE [dbo].[usp_CatPuestosAgregar]
@Codigo    int,    
@Puesto    varchar(40),    
@CreadoEl    datetime,    
@CreadoPor    int,    
@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION
    IF ISNULL(@Codigo,0)= 0
        RAISERROR(N'El código del Puesto es un campo requerido',
            16,
            1
            )
            
   	IF EXISTS(SELECT Codigo FROM CatPuestos WHERE Codigo = @Codigo)
		RAISERROR(N'El código del Puesto ya existe',
			16,
			1
			)         
            
    IF ISNULL(@Puesto,'')= ''
        RAISERROR(N'El nombre del Puesto es un campo requerido',
            16,
            1
            )
    IF EXISTS(SELECT Puesto FROM CatPuestos WHERE Puesto = @Puesto)
		RAISERROR(N'La Descripción del Puesto ya existe',
			16,
			1
			) 
    INSERT INTO CatPuestos(Codigo,Puesto,CreadoEl,CreadoPor)
    VALUES(@Codigo,@Puesto,@CreadoEl,@CreadoPor)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

