CREATE PROCEDURE [dbo].[usp_ProRequisicionModificar]
	@IdRequisicion int,
	@IdProveedor int,
	@FechaHora datetime,
	@SubTotal money,
	@Descuento money,
	@MotivoDescuento varchar(100),
	@IdImpuestosTrasladadosFederales int,
    @ImpuestosTrasladadosFederales money,
    @IdImpuestosRetenidosFederales int,
    @ImpuestosRetenidosFederales money,
    @IdImpuestosTrasladadosLocales int,
    @ImpuestosTrasladadosLocales money,
    @IdImpuestosRetenidosLocales int,
    @ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Estatus tinyint,
	@Observaciones varchar(512),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@dsProRequisicionConceptos ntext,
	@IdPeticion varchar(100),
	@IdAlmacen int,
	@CargarA varchar(100)
AS
DECLARE
	@docHandle int,
	@CursorIdRequisicionConcepto int,
	@CursorIdArticulo int,
	@CursorCantidad decimal(15,4),
	@CursorEntregado decimal(15,4),
	@CursorPendiente decimal(15,4),
	@CursorPrecio_Unitario money,
	@CursorImporte money,
	@CursorObservaciones varchar(256),
	@CursorUnidad_Medida varchar(30),
	@return_value int
BEGIN TRY
	BEGIN TRANSACTION		

	IF Isnull(@IdRequisicion,0) = 0
		RAISERROR(N'El identificador de la requisicion es un campo requerido',
			16,
			1
			)

	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) = 1--surtida
		RAISERROR(N'No puede ser modificada esta requisicion porque está pagada',
			16,
			1
			)
			
	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) = 2--cancelada
		RAISERROR(N'No puede ser modificada esta requisicion porque está cancelada',
			16,
			1
			)

	IF Isnull(@FechaHora,'') = ''			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF Isnull(@SubTotal,0) = 0
		RAISERROR(N'El subtotal es un campo requerido',
			16,
			1
			)

	IF Isnull(@IdMoneda,0) = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)
			
	IF @dsProRequisicionConceptos IS NULL
		RAISERROR(N'Los conceptos de la requisicion son requeridos',
			16,
			1
			)	
	IF ISNULL(@IdProveedor,0) = 0
			SET @IdProveedor = NULL

	UPDATE ProRequisicion SET
		IdProveedor = @IdProveedor,
		FechaHora = @FechaHora,
		SubTotal = @SubTotal,
		Descuento = @Descuento,
		MotivoDescuento = @MotivoDescuento,
		IdImpuestosTrasladadosFederales = @IdImpuestosTrasladadosFederales,
		ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales,
		IdImpuestosRetenidosFederales = @IdImpuestosRetenidosFederales,
		ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales,
		IdImpuestosTrasladadosLocales = @IdImpuestosTrasladadosLocales,
		ImpuestosTrasladadosLocales = @ImpuestosTrasladadosLocales,
		IdImpuestosRetenidosLocales = @IdImpuestosRetenidosLocales,
		ImpuestosRetenidosLocales = @ImpuestosRetenidosLocales,
		Total = @Total,
		TipoCambio = @TipoCambio,
		IdMoneda = @IdMoneda,
		Estatus = @Estatus,
		Observaciones = @Observaciones,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		CargarA = @CargarA,
		IdAlmacen = @IdAlmacen
	WHERE IdRequisicion = @IdRequisicion
			
	----SECCION PARA AGREGAR LOS CONCEPTOS DE LA REQUISICION
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProRequisicionConceptos

	SELECT ATT_IdArticulo,ATT_Cantidad,ATT_Entregado,ATT_Pendiente,ATT_PrecioUnitario,ATT_Importe,ATT_Observaciones,ATT_UnidadMedida
	INTO #TempProRequisicionConceptos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProRequisicionConceptos',2) 
	WITH (ATT_IdArticulo int,ATT_Cantidad decimal(15,4),ATT_Entregado decimal(15,4),ATT_Pendiente decimal(15,4),ATT_PrecioUnitario decimal(19,6),ATT_Importe money,ATT_Observaciones varchar(256),ATT_UnidadMedida varchar(30))

	EXEC sp_xml_removedocument @docHandle
	
	DELETE FROM ProRequisicionConceptos WHERE IdRequisicion = @IdRequisicion
	
	INSERT INTO ProRequisicionConceptos(IdRequisicion,IdArticulo,Cantidad,Entregado,Pendiente,PrecioUnitario,Importe,Observaciones,UnidadMedida,ModificadoPor,ModificadoEl)
	SELECT @IdRequisicion,ATT_IdArticulo,ATT_Cantidad,ATT_Entregado,ATT_Pendiente,ATT_PrecioUnitario,ATT_Importe,ATT_Observaciones,ATT_UnidadMedida,@ModificadoPor,@ModificadoEl
	FROM #TempProRequisicionConceptos
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

