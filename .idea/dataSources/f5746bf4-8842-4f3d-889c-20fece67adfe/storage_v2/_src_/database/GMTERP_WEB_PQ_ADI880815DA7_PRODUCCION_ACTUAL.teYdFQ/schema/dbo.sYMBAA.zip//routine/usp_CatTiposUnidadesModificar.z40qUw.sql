CREATE PROCEDURE [dbo].[usp_CatTiposUnidadesModificar]
	@IdTipoUnidad int,
	@TarifaPorKMS money,
	@TarifaPorKMSDlls money,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@ClaveAutotransporteFederal varchar(10)
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdTipoUnidad = 0
		RAISERROR(N'El identificador del tipo unidad es un campo requerido',
			16,
			1
			)
	
	IF (SELECT ModificadoEl FROM CatTiposUnidades WHERE IdTipoUnidad= @IdTipoUnidad) <> @UltimaModificacion
		RAISERROR(N'Los datos de este tipo unidad fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)		
		

	UPDATE CatTiposUnidades SET 
	TarifaPorKMS = @TarifaPorKMS,
	TarifaPorKMSDlls = @TarifaPorKMSDlls,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor,
	ClaveAutotransporteFederal = @ClaveAutotransporteFederal
	WHERE IdTipoUnidad = @IdTipoUnidad
	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

