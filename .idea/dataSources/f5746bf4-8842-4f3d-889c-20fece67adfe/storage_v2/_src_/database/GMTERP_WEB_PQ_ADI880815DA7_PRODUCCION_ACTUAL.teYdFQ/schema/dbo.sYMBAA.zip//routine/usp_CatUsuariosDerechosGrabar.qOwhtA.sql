CREATE PROCEDURE [dbo].[usp_CatUsuariosDerechosGrabar]
	@IdUsuario int,
	@dsCatUsuariosDerechos ntext,
	@CreadoPor int,
	@CreadoEl datetime,	
	@IdPeticion varchar(100)
	/* *************************************************************************************************

	Modificado por:   EDGAR RAMOS
	Solicitud:4124
	Fecha de Modificado: 05/04/2021
	Versión: 8.0.59.27


	Invocada desde: GMTERPV8 --ClsCatUsuarios--GrabarDerechos
	************************************************************************************************ */
AS
DECLARE
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdUsuario,0) <= 0
		RAISERROR(N'El identificador del usuario es un campo requerido',
			16,
			1
			)
			
	IF @dsCatUsuariosDerechos IS NULL
		RAISERROR(N'Los derechos son requeridos',
			16,
			1
			)

	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUsuariosDerechos

	SELECT COL_IdUsuarioDerecho,COL_IdProceso,COL_Derecho
	INTO #TempCatUsuariosDerechos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatUsuarioDerechos',2) 
	WITH (COL_IdUsuarioDerecho int,COL_IdProceso int,COL_Derecho bit)
	
	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO CatUsuariosDerechos(CreadoEl,CreadoPor,Derecho,IdProceso,IdUsuario)
	SELECT @CreadoEl,@CreadoPor,COL_Derecho,COL_IdProceso,@IdUsuario
	FROM #TempCatUsuariosDerechos
	WHERE COL_IdUsuarioDerecho = 0
	
	UPDATE CatUsuariosDerechos SET
		CatUsuariosDerechos.Derecho = #TempCatUsuariosDerechos.COL_Derecho,
		CatUsuariosDerechos.ModificadoEl = @CreadoEl,
		CatUsuariosDerechos.ModificadoPor = @CreadoPor
	FROM CatUsuariosDerechos
	INNER JOIN #TempCatUsuariosDerechos ON CatUsuariosDerechos.IdUsuarioDerecho = #TempCatUsuariosDerechos.COL_IdUsuarioDerecho

	/*--Solicitud 4124 Se agrego esta linea para que al iniciar sesion se vuelva armar el menu,autocomplete y los accesos directos.*/
	UPDATE CatUsuarios SET 
	Menu= NULL,
	XMLAutoCompleteMenu = NULL,
	AccesosDirectos = NULL
	WHERE IdUsuario = @IdUsuario
	/*FIN DE LA SOLICITUD 4124*/
	
	DELETE FROM CatUsuariosDerechos WHERE IdUsuario = @IdUsuario AND (ModificadoEl <> @CreadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @CreadoEl
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

