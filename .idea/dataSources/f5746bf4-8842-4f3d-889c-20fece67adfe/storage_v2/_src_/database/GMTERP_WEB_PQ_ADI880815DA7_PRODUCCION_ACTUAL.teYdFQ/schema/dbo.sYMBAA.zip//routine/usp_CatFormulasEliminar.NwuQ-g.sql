Create PROCEDURE [dbo].[usp_CatFormulasEliminar]
@IdFormula int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdFormula,0)= 0
	RAISERROR(N'El identificador de la formula es un campo requerido',
			16,
			1
			)
			
		DELETE CatFormulas
		WHERE 	IdFormula=@IdFormula
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

