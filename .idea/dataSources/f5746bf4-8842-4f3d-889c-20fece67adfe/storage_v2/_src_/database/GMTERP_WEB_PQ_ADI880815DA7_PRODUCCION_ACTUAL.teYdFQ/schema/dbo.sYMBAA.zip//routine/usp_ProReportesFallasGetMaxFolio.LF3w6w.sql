CREATE PROCEDURE [dbo].[usp_ProReportesFallasGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProReportesFallas
go

