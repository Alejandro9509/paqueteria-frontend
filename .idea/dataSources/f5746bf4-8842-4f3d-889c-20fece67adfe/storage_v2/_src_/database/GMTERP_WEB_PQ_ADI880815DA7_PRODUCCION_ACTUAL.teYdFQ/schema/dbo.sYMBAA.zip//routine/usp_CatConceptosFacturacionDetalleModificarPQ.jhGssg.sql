

--select * from CatConceptosFacturacionDetalle

CREATE PROCEDURE [dbo].[usp_CatConceptosFacturacionDetalleModificarPQ](
	@IdConceptosFacturacionDetalle int,
	@IdConceptosFacturacion int,
	@IdImpuesto int,
	@Trasladado bit,
	@Predeterminado bit
)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdConceptosFacturacionDetalle, 0) = 0 begin
				RAISERROR(N'*INICIO*El Identificador del Detalle de Conceptos de Facturaciones un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@IdImpuesto, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de Impuesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		UPDATE CatConceptosFacturacionDetalle
		set @Trasladado = @Trasladado,
		Predeterminado = @Predeterminado
		where IdConceptosFacturacionDetalle = @IdConceptosFacturacionDetalle;
		
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

