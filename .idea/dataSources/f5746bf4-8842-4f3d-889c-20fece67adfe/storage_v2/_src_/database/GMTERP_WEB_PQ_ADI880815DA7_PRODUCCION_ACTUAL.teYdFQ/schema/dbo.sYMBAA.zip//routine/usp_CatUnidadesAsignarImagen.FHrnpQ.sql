CREATE PROCEDURE [dbo].[usp_CatUnidadesAsignarImagen]
	@IdUnidad int,
	@NombreImagenUnidad varchar(30),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL((SELECT IdUnidad FROM CatUnidades Where IdUnidad = @IdUnidad),0) = 0
			RAISERROR(N'La unidad no existe',
			16,
			1
			)

		UPDATE CatUnidades SET NombreImagenUnidad=@NombreImagenUnidad,ModificadoPor = @ModificadoPor,ModificadoEl = @ModificadoEl WHERE IdUnidad = @IdUnidad
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

