
CREATE PROCEDURE [dbo].[usp_CatUsuariosAccesosDirectosGrabar]
	@IdUsuario int,
	@dsCatUsuariosAccesosDirectos ntext,
	@CreadoEl datetime,	
	@IdPeticion varchar(100)
AS
DECLARE
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdUsuario,0) <= 0
		RAISERROR(N'El identificador del usuario es un campo requerido',
			16,
			1
			)
			
	IF @dsCatUsuariosAccesosDirectos IS NULL
		RAISERROR(N'Los accesos directos son requeridos',
			16,
			1
			)

	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUsuariosAccesosDirectos

	SELECT COL_IdProceso,COL_IdUsuarioAccesoDirecto
	INTO #TempCatUsuariosAccesosDirectos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatUsuarioAccesosDirectos',2) 
	WITH (COL_IdProceso int,COL_IdUsuarioAccesoDirecto int)
	
	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO CatUsuariosAccesosDirectos(CreadoEl,IdProceso,IdUsuario)
	SELECT @CreadoEl,COL_IdProceso,@IdUsuario
	FROM #TempCatUsuariosAccesosDirectos
	WHERE COL_IdUsuarioAccesoDirecto = 0
	
	UPDATE CatUsuariosAccesosDirectos SET
		CatUsuariosAccesosDirectos.ModificadoEl = @CreadoEl
	FROM CatUsuariosAccesosDirectos
	INNER JOIN #TempCatUsuariosAccesosDirectos ON CatUsuariosAccesosDirectos.IdUsuarioAccesoDirecto = #TempCatUsuariosAccesosDirectos.COL_IdUsuarioAccesoDirecto
	
	DELETE FROM CatUsuariosAccesosDirectos WHERE IdUsuario = @IdUsuario AND (ModificadoEl <> @CreadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @CreadoEl
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

