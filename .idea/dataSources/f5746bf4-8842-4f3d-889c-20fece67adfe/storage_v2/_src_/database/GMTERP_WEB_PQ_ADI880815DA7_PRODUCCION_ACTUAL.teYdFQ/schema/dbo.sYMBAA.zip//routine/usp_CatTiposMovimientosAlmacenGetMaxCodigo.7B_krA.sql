
CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosAlmacenGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTiposMovimientosAlmacen
go

