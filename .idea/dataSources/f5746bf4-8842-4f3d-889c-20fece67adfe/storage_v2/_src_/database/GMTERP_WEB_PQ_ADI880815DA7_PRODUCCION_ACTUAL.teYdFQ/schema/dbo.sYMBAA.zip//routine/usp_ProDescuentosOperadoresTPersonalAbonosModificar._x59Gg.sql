
CREATE PROCEDURE [dbo].[usp_ProDescuentosOperadoresTPersonalAbonosModificar]
	@IdAbonoDescuentoOperador int,
	@IdDescuentoOperador int,
	@FechaHora	datetime,
	@Abono	money,
	@ModificadoEl	datetime,
	@ModificadoPor	int,
	@IdPeticion varchar(100),
	@Observaciones varchar(50)
AS
  Declare 
  @ImporteDescontadoAnterior money
BEGIN TRY
	BEGIN TRANSACTION

		--Verifica que no haya sido Borrado con conterioridad o concurrencia el Descuento que se quiere modificar
		IF NOT EXISTS(SELECT * FROM ProDescuentosOperadoresTPersonalAbonos WHERE IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador)			
		RAISERROR(N'Se detecto concurrencia de (abono, eliminación o modificación), favor de verificar e intentar nuevamente',
			16,
			1
			) 
		

		IF ISNULL(@Abono,0) <= 0
		RAISERROR(N'El abono del descuento es un campo requerido',
			16,
			1
			)
		
		SET @ImporteDescontadoAnterior = (SELECT ImporteDescontado From CatDescuentosOperadoresTPersonal Where IdDescuentoOperador = @IdDescuentoOperador)-(SELECT Abono From ProDescuentosOperadoresTPersonalAbonos Where IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador)
		
		UPDATE ProDescuentosOperadoresTPersonalAbonos SET 
		FechaHora= @FechaHora,
		Abono = @Abono,
		Observaciones = @Observaciones,
		ModificadoEl = @ModificadoEl ,
	    ModificadoPor = @ModificadoPor
		WHERE IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador

		UPDATE CatDescuentosOperadoresTPersonal SET 		 
		ImporteDescontado = ISNULL(@ImporteDescontadoAnterior,0)+@Abono
		WHERE IdDescuentoOperador = @IdDescuentoOperador
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

