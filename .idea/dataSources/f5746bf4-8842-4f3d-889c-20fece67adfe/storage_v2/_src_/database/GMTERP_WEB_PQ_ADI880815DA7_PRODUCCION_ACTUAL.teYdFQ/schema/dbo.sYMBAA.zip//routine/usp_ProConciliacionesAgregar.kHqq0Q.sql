CREATE PROCEDURE [dbo].[usp_ProConciliacionesAgregar]
	@Folio int,
	@Fecha datetime,
	@Periodo Varchar(150),
	@IdCuentaBancaria int,
	@Depositos decimal(15,2),
	@Retiros  decimal(15,2),
	@Estatus int,
	@dsProConciliacionesMovimientosEstadoDeCuenta ntext,
	@dsProConciliacionesMovimientosGM ntext,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@FechaInicial datetime,
	@FechaFinal Datetime,
	@NoConsiderarChequeAlConciliar bit,
	@ConciliarConFechaCobro bit

/* *************************************************************************************************
Procedimiento usp_ProConciliacionesAgregar

Parámetros: 
	@Folio (entrada, entero). Folio de la conciliacion
	@Fecha (entrada, fecha). Fecha y hora de la conciliacion
	@Periodo (entrada, texto). Periodo de la conciliacion
	@IdCuentaBancaria (entrada, entero). Identificador de la cuenta bancaria
	@Depositos (entrada, moneda). Depositos
	@Retiros (entrada, moneda). Retiros
	@Estatus (entrada, entero). Estatus de la conciliacion
	@dsProConciliacionesMovimientosEstadoDeCuenta (entrada, texto). Relacion de estado de cuenta
	@dsProConciliacionesMovimientosGM (entrada, texto). Relacion de los movimientos bancarios
	@CreadoPor (entrada, entero). Usuario que crea el cheque
	@CreadoEl (entrada, fecha hora). Fecha y hora de creacion
	@IdPeticion (entrada, string). Id de la Petición, generada en WEBDEV
	@FechaInicial (entrada, fecha). Fecha inicial rango
	@FechaFinal (entrada, fecha). Fecha final rango
	@NoConsiderarChequeAlConciliar (entrada, boleano). Considerar cheque al conciliar
	@ConciliarConFechaCobro (entrada, boleano). Considerar fecha de cobro movimientos bancarios

Descripción: Procedimiento para agregar una conciliacion

10/07/2020 - SE AGREGO AL PROCEDIMIENTO EL PARAMETRO NoConsiderarChequeAlConciliar 
06/11/2020 - Se agrego el parametro @ConciliarConFechaCobro

Implementada por: Francisco Villela
Fecha de implementacion: 10/07/2020
Versión ERP: 8.0.54.4

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 06/11/2020
Versión ERP: 8.0.56.12

Invocada desde: PAGE_ProConciliacionesAM (Solicitud 3393)
***************************************************************************************************** */
AS
DECLARE
	@docHandle int,
	@IdConciliacion int,
	@IdConciliacionMovimientoBancario_CURSOR int,
	@IdMovimientoBancario_CURSOR int,
	@ConciliadoGM_CURSOR int
BEGIN TRY
	BEGIN TRANSACTION

	IF @Folio = 0
		RAISERROR(N'El folio es un campo requerido', 16, 1)

	IF EXISTS(SELECT Folio FROM ProConciliaciones WHERE Folio = @Folio)
		RAISERROR(N'El folio ya fue utilizado por otro usuario', 16, 1)				

	IF @IdCuentaBancaria = 0
		RAISERROR(N'La cuenta es un campo requerido', 16, 1)

			
	IF @dsProConciliacionesMovimientosEstadoDeCuenta IS NULL
		RAISERROR(N'Es necesario tener movimientos de estado de cuenta', 16, 1)	

	IF @dsProConciliacionesMovimientosGM IS NULL
		RAISERROR(N'Es necesario tener movimientos Bancarios', 16, 1)		

	INSERT INTO ProConciliaciones(Folio,Fecha,Periodo,IdCuentaBancaria,Depositos,Retiros,Estatus,CreadoPor,CreadoEl,FechaInicial,FechaFinal,NoConsiderarChequeAlConciliar,ConciliarConFechaCobro)
	VALUES(@Folio,@Fecha,@Periodo,@IdCuentaBancaria,@Depositos,@Retiros,@Estatus,@CreadoPor,@CreadoEl,@FechaInicial,@FechaFinal,@NoConsiderarChequeAlConciliar,@ConciliarConFechaCobro)

	SET @IdConciliacion = (SELECT IDENT_CURRENT('ProConciliaciones'))	

	--SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProConciliacionesMovimientosEstadoDeCuenta

	SELECT ATT_IdMovimientosEstadoDeCuenta,ATT_Fecha,ATT_Importe,ATT_Cheque,ATT_Tipo,ATT_Conciliado,ATT_Referencia,ATT_Estatus
	INTO #TempProConciliacionesMovimientosEstadoDeCuenta
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProConciliacionesMovimientosEstadoDeCuenta',2) 
	WITH (ATT_IdMovimientosEstadoDeCuenta int,ATT_Fecha datetime,ATT_Importe decimal(15,6),ATT_Cheque int,ATT_Tipo tinyint,ATT_Conciliado int,ATT_Referencia varchar(8000),ATT_Estatus varchar(5))

	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO ProConciliacionesMovimientosEstadoDeCuenta(IdConciliacion,Fecha,Importe,Cheque,Tipo,Conciliado,Referencia,Estatus,CreadoPor,CreadoEl)
	SELECT @IdConciliacion,ATT_Fecha,ATT_Importe,ATT_Cheque,ATT_Tipo,ATT_Conciliado,ATT_Referencia,ATT_Estatus,@CreadoPor,@CreadoEl
	FROM #TempProConciliacionesMovimientosEstadoDeCuenta

	----SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProConciliacionesMovimientosGM

	SELECT ATT_IdConciliacionMovimientoBancario,ATT_IdMovimientoBancario,ATT_Conciliado
	INTO #TempProConciliacionesMovimientosBancarios
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProConciliacionesMovimientosBancarios',2) 
	WITH (ATT_IdConciliacionMovimientoBancario int,ATT_IdMovimientoBancario int,ATT_Conciliado int)
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE ProConciliacionesMovimientosBancarios_CURSOR CURSOR FOR
	SELECT * FROM #TempProConciliacionesMovimientosBancarios

	OPEN ProConciliacionesMovimientosBancarios_CURSOR
	FETCH NEXT FROM ProConciliacionesMovimientosBancarios_CURSOR
	INTO @IdConciliacionMovimientoBancario_CURSOR,@IdMovimientoBancario_CURSOR,@ConciliadoGM_CURSOR

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @IdConciliacionMovimientoBancario_CURSOR = 0			
			INSERT INTO ProConciliacionesMovimientosBancarios(IdConciliacion,IdMovimientoBancario,Conciliado,CreadoEl,CreadoPor)
			VALUES(@IdConciliacion,@IdMovimientoBancario_CURSOR,@ConciliadoGM_CURSOR,@CreadoEl,@CreadoPor)
		ELSE
			UPDATE ProConciliacionesMovimientosBancarios SET
				IdConciliacion = @IdConciliacion,
				IdMovimientoBancario = @IdMovimientoBancario_CURSOR,
				Conciliado = @ConciliadoGM_CURSOR,				
				ModificadoEl = @CreadoEl,
				ModificadoPor = @CreadoPor
			WHERE IdConciliacionMovimientoBancario= @IdConciliacionMovimientoBancario_CURSOR
	
		FETCH NEXT FROM ProConciliacionesMovimientosBancarios_CURSOR
		INTO @IdConciliacionMovimientoBancario_CURSOR,@IdMovimientoBancario_CURSOR,@ConciliadoGM_CURSOR
	END

	CLOSE ProConciliacionesMovimientosBancarios_CURSOR
	DEALLOCATE ProConciliacionesMovimientosBancarios_CURSOR

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

