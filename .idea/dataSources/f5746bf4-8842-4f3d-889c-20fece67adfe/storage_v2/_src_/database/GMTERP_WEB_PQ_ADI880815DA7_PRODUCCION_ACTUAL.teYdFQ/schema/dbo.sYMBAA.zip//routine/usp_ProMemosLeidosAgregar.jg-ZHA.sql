CREATE PROCEDURE [dbo].[usp_ProMemosLeidosAgregar]
	@IdMemo int,
	@IdOperador int,
	@FechaHora datetime,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdMemo,0)=0
		RAISERROR(N'Identificador de memo, avisos y notificaciones es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdOperador,0)=0
		RAISERROR(N'Identificador de operador es un campo requerido',
			16,
			1
			)

	INSERT INTO ProMemosLeidos(IdMemo,IdOperador,FechaHora)	
	VALUES(@IdMemo,@IdOperador,@FechaHora)
	COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

