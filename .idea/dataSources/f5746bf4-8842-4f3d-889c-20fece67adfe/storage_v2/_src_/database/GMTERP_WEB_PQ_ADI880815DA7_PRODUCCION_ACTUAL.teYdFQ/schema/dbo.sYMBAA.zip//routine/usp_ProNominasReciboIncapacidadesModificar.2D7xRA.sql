CREATE PROCEDURE [dbo].[usp_ProNominasReciboIncapacidadesModificar]	
	@IdProNominaReciboIncapacidades int,
	@IdEmpleado int,
	@Folio varchar(10),
	@IdTipoIncidencia int,
	@DiasAutorizados int,
	@FechaInicio datetime,
	@RamoSeguridad int,
	@TipoRiesgo int,
	@PorcientoIncapacidad decimal (7,2),
	@SecuelaConsecuencia int,
	@ControlIncapacidad int,
	@Observaciones ntext,
	@ModificadoEl datetime,    
	@ModificadoPor int,
	@IdPeriodo int,
	@IdPeticion varchar(100),
	@UltimaModificacion datetime,
	@xmlIncedenciaValor ntext,--@IdIncidencia int,@Valor decimal(15,2),@IdProNominaDiaHora int,@Estado varchar(40),
	@TipoIncidencia int
AS
DECLARE
	@FechaFInal date, 
	@FechaRepetida int 
SET XACT_ABORT ON
BEGIN TRY
    BEGIN TRANSACTION  
    
		IF ISNULL(@IdProNominaReciboIncapacidades,0) = 0
        RAISERROR(N'La incapacidad es un campo requerido',
            16,
            1
            )
    
		IF ISNULL(@IdEmpleado,0) = 0
        RAISERROR(N'El empleado es un campo requerido',
            16,
            1
            )
            
        IF @FechaInicio < (SELECT FechaAlta FROM CatEmpleados WHERE IdEmpleado = @IdEmpleado)
        RAISERROR(N'La fecha de inicio no puede ser menor a la fecha de contratacion del empleado',
            16,
            1
            )
        
		IF @FechaInicio < (SELECT FechaInicio FROM CatPeriodos WHERE IdPeriodo = @IdPeriodo)
        RAISERROR(N'La fecha de inicio no puede ser menor a la fecha de inicio del periodo',
            16,
            1
            )
    
    	IF ISNULL(@Folio,'') = ''
        RAISERROR(N'El folio es un campo requerido',
            16,
            1
            )
		
	IF EXISTS(SELECT Folio FROM ProNominasReciboIncapacidades WHERE Folio = @Folio AND IdEmpleado <> @IdEmpleado)
		RAISERROR(N'El folio de la incidencia ya existe',
			16,
			1
			)
			
		IF ISNULL(@IdTipoIncidencia,0) = 0
        RAISERROR(N'El tipo de incidencia es un campo requerido',
            16,
            1
            )	
            
        IF ISNULL(@TipoRiesgo,0) = -1
        RAISERROR(N'El tipo de riesgo es un campo requerido',
            16,
            1
            )	
        
        IF ISNULL(@ControlIncapacidad,0) = -1
        RAISERROR(N'El control de incapacidad es un campo requerido',
            16,
            1
            )	
        
        IF (SELECT ModificadoEl FROM ProNominasReciboIncapacidades WHERE IdProNominaReciboIncapacidades = @IdProNominaReciboIncapacidades) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta incapacidad fuerón modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)	
            
		UPDATE ProNominasReciboIncapacidades SET 
		IdEmpleado = @IdEmpleado,
		Folio = @Folio,
		IdTipoIncidencia = @IdTipoIncidencia,
		DiasAutorizados = @DiasAutorizados,
		FechaInicio = @FechaInicio,
		RamoSeguridad = @RamoSeguridad,
		TipoRiesgo = @TipoRiesgo,
		PorcientoIncapacidad = @PorcientoIncapacidad,
		SecuelaConsecuencia = @SecuelaConsecuencia,
		ControlIncapacidad = @ControlIncapacidad,
		Observaciones = @Observaciones,
		ModificadoEl = @ModificadoEl,    
		ModificadoPor = @ModificadoPor
		WHERE IdProNominaReciboIncapacidades = @IdProNominaReciboIncapacidades  

		UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

		EXEC  usp_ProNominasDiasHorasModificar
		@IdPeticion,
		@IdEmpleado,
		@xmlIncedenciaValor,
		@FechaInicio,
		@ModificadoPor,
		@ModificadoEl,
		@TipoIncidencia,
		@IdProNominaReciboIncapacidades,
		@IdPeriodo,
		NULL
COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

