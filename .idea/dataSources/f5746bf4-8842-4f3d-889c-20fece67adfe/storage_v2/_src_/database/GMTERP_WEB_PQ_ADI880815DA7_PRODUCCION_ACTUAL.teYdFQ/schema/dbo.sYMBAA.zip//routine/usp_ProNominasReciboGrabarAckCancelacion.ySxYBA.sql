CREATE PROCEDURE [dbo].[usp_ProNominasReciboGrabarAckCancelacion]
	@IdNominaRecibo int,
	@AckCancelacion ntext,
	@FechaCancelacionSAT datetime,
	@EstatusUUID varchar(50),
	@IdPeticion varchar(100),
	@CanceladoPor int,
	@SATComprobanteEsCancelable varchar(30) = NULL,
	@SATComprobanteEstado varchar(20) = NULL,
	@SATComprobanteEstatusCancelacion varchar(30) = NULL,
	@SATComprobanteFechaHoraEnvioSolicitud datetime = NULL
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT IdNominaRecibo FROM ProNominasRecibo WHERE IdNominaRecibo = @IdNominaRecibo AND FechaTimbrado IS NULL)
		RAISERROR(N'No se puede cancelar este recibo porque no está timbrado en el SAT',
			16,
			1
			)
	
	IF ISNULL((Select TOP 1 IdNominaRecibo From ProNominasReciboCancelacion Where IdNominaRecibo = @IdNominaRecibo AND EstatusUUID IS NOT NULL AND AckCancelacion IS NOT NULL AND FechaCancelacionSAT IS NOT NULL AND FolioFiscalUUIDSustitucion IS NULL),0) <> 0 
		RAISERROR(N'No se puede cancelar este recibo porque ya está cancelado en el SAT',
			16,
			1
			)
	
	IF @SATComprobanteEstado = 'Vigente'
	BEGIN
		IF NOT EXISTS (SELECT IdProcesoLigado FROM ProDocumentosEnProcesoCancelacionSAT Where IdProcesoLigado = @IdNominaRecibo AND ProcesoLigado = 'ProNominasRecibos' AND EnProceso = 1)
		INSERT INTO ProDocumentosEnProcesoCancelacionSAT(IdProcesoLigado,ProcesoLigado,EnProceso,SATCanceladoPor) VALUES (@IdNominaRecibo,'ProNominasRecibos',1,@CanceladoPor)
	END
	
	IF @SATComprobanteEstado = 'Cancelado'
	BEGIN
		
		UPDATE ProDocumentosEnProcesoCancelacionSAT SET EnProceso = 0 Where IdProcesoLigado = @IdNominaRecibo AND ProcesoLigado = 'ProNominasRecibos'
		
		INSERT INTO ProNominasReciboCancelacion(AckCancelacion,CadenaOriginal,CadenaOriginalTimbrado,EstatusUUID,FechaCancelacionSAT,FechaTimbrado,FolioFiscalUUID,IdCertificado,IdNominaRecibo,NoSerieCertificadoSAT,SelloDigital,SelloSAT,XMLArchivo,SATComprobanteEsCancelable,SATComprobanteEstado,SATComprobanteEstatusCancelacion,SATComprobanteFechaHoraEnvioSolicitud)
		SELECT @AckCancelacion,CadenaOriginal,CadenaOriginalTimbrado,@EstatusUUID,@FechaCancelacionSAT,FechaTimbrado,FolioFiscalUUID,IdCertificado,@IdNominaRecibo,NoSerieCertificadoSAT,SelloDigital,SelloSAT,XMLArchivo,@SATComprobanteEsCancelable,@SATComprobanteEstado,@SATComprobanteEstatusCancelacion,@SATComprobanteFechaHoraEnvioSolicitud FROM ProNominasRecibo WHERE IdNominaRecibo = @IdNominaRecibo
		
		UPDATE ProNominasRecibo
		SET FolioFiscalUUID = NULL,
			FechaTimbrado = NULL,
			NoSerieCertificadoSAT = NULL,
			SelloSAT = NULL,
			CadenaOriginalTimbrado = NULL,
			XMLArchivo = NULL,
			TimbrePruebas = NULL,
			CadenaOriginal = NULL,
			SelloDigital = NULL
		WHERE IdNominaRecibo = @IdNominaRecibo
	END
	
	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

