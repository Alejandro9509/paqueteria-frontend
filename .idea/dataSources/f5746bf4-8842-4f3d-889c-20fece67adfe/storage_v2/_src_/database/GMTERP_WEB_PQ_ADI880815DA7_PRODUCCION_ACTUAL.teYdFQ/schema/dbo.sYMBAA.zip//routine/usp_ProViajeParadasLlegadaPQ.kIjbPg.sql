CREATE PROCEDURE [dbo].[usp_ProViajeParadasLlegadaPQ](	
	@IdViaje int,
	@IdViajeLlegada int
	
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de Viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdViajeLlegada, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de Llegada es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		UPDATE dbo.ProViajeParadasPQ set IdLlegada =@IdViajeLlegada where IdViaje=@IdViaje and  IdSalida !=0
	
	 
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

