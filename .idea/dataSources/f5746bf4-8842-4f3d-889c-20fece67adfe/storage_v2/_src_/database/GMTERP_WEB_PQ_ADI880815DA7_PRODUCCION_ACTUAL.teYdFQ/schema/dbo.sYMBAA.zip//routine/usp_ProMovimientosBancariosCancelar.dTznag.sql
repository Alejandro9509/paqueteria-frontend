CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosCancelar]
	@IdMovimientoBancario int,
	@CanceladoPor int,
    @CanceladoEl Datetime,
    @MotivoCancelacion varchar(150),	
	@IdPeticion varchar(100)	
AS
DECLARE
   @IdPasivo Int, --VARIABLE QUE SE UTILIZA PARA CURSOR
   @Importe money, --VARIABLE QUE SE UTILIZA PARA CURSOR
   @FechaPagoAnticipadoMes int,--variable para sacar el mes
   @FechaPagoAnticipadoAno int, --variable para sacar el año
   @FolioPagoAnticipado  int,
   @DeshabiliatarContabilidadIntegrada int,
   @EsPeriodoCerrado int,
   @EstructuraCatalogoCuentas varchar(15),
   @IdPagoAnticipado int,
   @Mensaje varchar(max),
   @ValidaProPagosAnticipados bit,
   @IdPasivoContraRecibo int,--variable que se utilizan en el cursos de Contrarecibos para actualizar el estatus
   @ImportePagadoContraRecibo money,--variable que se utilizan en el cursos de Contrarecibos para actualizar el estatus
   @ImportePagadoContraReciboDlls money,--variable que se utilizan en el cursos de Contrarecibos para actualizar el estatus
   @Total money,--variable que se utilizan en el cursos de Contrarecibos para actualizar el estatus
   @TotalDlls money,--variable que se utilizan en el cursos de Contrarecibos para actualizar el estatus
   @EstatusContraRecibo int,--variable que se utilizan en el cursos de Contrarecibos para actualizar el estatus
   @IdPeriodo int, -- --variable que se utiliza para liberar el periodo cuando el cheque se generó desde el proceso de nóminas
   @ImportePasivoContraReciboPesos money, --Variable que se utliza para AgruparTotal del contrarecibo 
   @ImportePasivoContraReciboDlls money, --Variable que se utliza para AgruparTotal del contrarecibo 
   @IdMoneda int, -- Se agrego por parte de la solicitud 268
   @ImportePasivoContraRecibo money, -- Se agrego por parte de la solicitud 268
   @IdPasivoContraReciboConsulta int
/*
/* *************************************************************************************************
MODIFICADO:
	se libera la liquidacion de TPersonal
MODIFICADA POR:
	Francisco Villela
FECHA DE MODIFICACIÓN:
	2020-07-30
SOLICITUD: 
	SOLICITUD 1445
MODIFICADO:
	se libera el Anticipo de TPersonal
MODIFICADA POR:
	Francisco Villela
FECHA DE MODIFICACIÓN:
	2020-06-02
SOLICITUD: 
	SOLICITUD 1423

MODIFICADO:
	Se modifico para que se devolviera es estato de la columna EsPagoComprobacion a Null cuando se cancela
MODIFICADA POR:
	Diego Rubio
FECHA DE MODIFICACIÓN:
	2020-02-18
SOLICITUD: 
	SOLICITUD 000990
*/

/**********************************************************************************************************************
MODIFICADO:
	se agrego el importe a pagar y el campo AgrupadoParaPago en el Ipdate en el retroceso del pasivo
MODIFICADA POR:
	Diego Rubio
FECHA DE MODIFICACIÓN:
	25-10-2019
SOLICITUD: 
	SOLICITUD 486
***********************************************************************************************************************/

SOLICITUD 268

Descripcion: Se modifico el cursor de contrarecibos para poder actualizar los estatus de forma correcta

Modificada por:   Ignacio Perez
Fecha de mofidicacion: 11/12/2019
Versión: Versión 8.0.48.24

Invocada desde: <ClsProCheques::Cancelar>
************************************************************************************************ */

/* *************************************************************************************************
Modificada por: Ignacio Perez 
Fecha de mofidicacion: 28/02/2020
Versión: 8.0.50.20
SOLICITUD 1176

Se Modifico el orden de los updates de propasivos

Invocada desde: PAGE_ProMovimientosBancariosRM, cancelar()
***************************************************************************************************** */
/* *************************************************************************************************
Modificada por: Ignacio Perez 
Fecha de mofidicacion: 03/03/2020
Versión 8.0.50.25
SOLICITUD 1176

Se agrego un update ara actualizar el ImporteAPagar cuando ImportePagado = 0

Invocada desde: PAGE_ProMovimientosBancariosRM, cancelar()
***************************************************************************************************** */
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdMovimientoBancario,0)= 0
		RAISERROR(N'Identificador de movimiento bancario es un campo requerido',
			16,
			1
			)
		
	IF ISDATE(@CanceladoEl)= 0
		RAISERROR(N'Fecha de cancelación de cheque es un campo requerido',
			16,
			1
			)
	
	--Si hay una liquidaicon pagada y esta timbrada no se permite cancelar el movmient		
	IF EXISTS(SELECT A.IdLiquidacion FROM ProLiquidaciones As A Inner join ProLiquidacionesCancelacionCFDI As B
		ON A.IdLiquidacion = B.IdLiquidacion
		WHERE A.IdMovimientoBancario = @IdMovimientoBancario 
		AND A.FechaTimbrado IS NOT NULL
		And B.FechaCancelacionSAT is NULL)			
		RAISERROR(N'No se puede cancelar el movimiento bancario porque la liquidación está timbrada, es necesario cancelar el timbre para poder cancelar el movimiento bancario',
			16,
			1
			)

	--Si hay una liquidaicon pagada y esta timbrada no se permite cancelar el movmient		
	IF EXISTS(SELECT A.IdLiquidacionFiscal FROM ProLiquidacionesFiscales As A Inner join ProLiquidacionesFiscalesCancelacionCFDI As B
				ON A.IdLiquidacionFiscal = B.IdLiquidacionFiscal
				WHERE A.IdMovimientoBancario = @IdMovimientoBancario 
				AND A.FechaTimbrado IS NOT NULL
				And B.FechaCancelacionSAT is NULL)			
		RAISERROR(N'No se puede cancelar el movimiento bancario porque la liquidación fiscal está timbrada, es necesario cancelar el timbre para poder cancelar el movimiento bancario',
			16,
			1
			)
		--Si hay una liquidaicon pagada y esta timbrada no se permite cancelar el movmient		
	IF EXISTS(SELECT A.IdLiquidacionTPersonal FROM ProLiquidacionesTPersonal As A Inner join ProLiquidacionesTPersonalCancelacionCFDI As B
				ON A.IdLiquidacionTPersonal = B.IdLiquidacion
				WHERE A.IdMovimientoBancario = @IdMovimientoBancario 
				AND A.FechaTimbrado IS NOT NULL
				And B.FechaCancelacionSAT is NULL)	
		RAISERROR(N'No se puede cancelar el movimiento bancario porque la liquidación está timbrada, es necesario cancelar el timbre para poder cancelar el movimiento bancario',
			16,
			1
			)
						
/*	IF ISNULL(@MotivoCancelacion,'')= ''
		RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)
*/	
		
--- Liberar Anticipo
	UPDATE ProAnticipos
	SET IdMovimientoBancario = Null
	WHERE IdMovimientoBancario = @IdMovimientoBancario 

--- Liberar Anticipo T personal
	UPDATE ProAnticiposTPersonal
	SET IdMovimientoBancario = Null
	WHERE IdMovimientoBancario = @IdMovimientoBancario 
		
--- Liberar Liquidación
	IF (SELECT top 1 LiquidacionPermisionario FROM ProLiquidaciones WHERE IdMovimientoBancario = @IdMovimientoBancario) = 1 
		BEGIN
			Update ProLiquidaciones
				   Set PagadoEl = Null,
				   PagadoPor = Null
			where IdMovimientoBancario = @IdMovimientoBancario
	END
	
	UPDATE ProLiquidaciones
	SET IdMovimientoBancario = Null
	WHERE IdMovimientoBancario = @IdMovimientoBancario 

--- Liberar Liquidación
	UPDATE ProLiquidacionesFiscales
	SET IdMovimientoBancario = Null
	WHERE IdMovimientoBancario = @IdMovimientoBancario 	

	--- Liberar Liquidación
	UPDATE ProLiquidacionesTPersonal
	SET IdMovimientoBancario = Null
	WHERE IdMovimientoBancario = @IdMovimientoBancario 	
	
--Liberar Periodo y Recibo Nomina 
	SET @IdPeriodo = ISNULL((SELECT TOP 1 IdPeriodo FROM ProNominasRecibo WHERE IdMovimientoBancario = @IdMovimientoBancario),0)
	IF @IdPeriodo > 0 
	BEGIN
		UPDATE CatPeriodos SET PagadoEl = NULL WHERE IdPeriodo = @IdPeriodo	AND PagadoEl IS NOT NULL
	END	 
		
	UPDATE ProNominasRecibo 
		   SET IdMovimientoBancario = NULL
	WHERE IdMovimientoBancario = @IdMovimientoBancario    	
	
--- Actualizar Movimiento Movimiento Bancario
	UPDATE ProMovimientosBancarios 
	SET	CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		MotivoCancelacion = @MotivoCancelacion
	WHERE ProMovimientosBancarios.IdMovimientoBancario = @IdMovimientoBancario
	

--- Liberar pasivo de movimiento bancario y pasarlo a pago de pasivos como autorizado
     
	Declare MovimientosBancarios_CURSOR Cursor For
	Select IdPasivo,Importe from ProPasivosMovimientosBancarios Where IdMovimientoBancario = @IdMovimientoBancario 

	Open MovimientosBancarios_CURSOR
	Fetch Next From MovimientosBancarios_CURSOR
	Into @IdPasivo,@Importe
	 SET @ImportePasivoContraReciboPesos = 0
	 SET @ImportePasivoContraReciboDlls = 0
	While @@Fetch_Status = 0
	Begin
		IF (Select IdMoneda FROM ProPasivos where IdPasivo = @IdPasivo) = 1   -- Solicitud 12128 se agrego condicion para calcular el importe correcto para contrarecibos con pagos con documentos 
		BEGIN
			 SET @ImportePasivoContraReciboPesos = @ImportePasivoContraReciboPesos + @Importe
		END
		else 
		BEGIN
			SET @ImportePasivoContraReciboDlls = @ImportePasivoContraReciboDlls + @Importe
		END
		--Solicutud 11371 Se agrego una condicion para evitar agregar a los pasivos no autorizados una fecha de autoizacion  
		Update ProPasivos SET 
		AutorizadoEl = NULL,
		AutorizadoPor = NULL,
		PagoSinAutorizar = NULL,
		AutorizadoPago = NULL,
		ImportePagado=ImportePagado-@Importe
        WHERE IdPasivo=@IdPasivo
		AND ImportePagado = @Importe
		AND  ISNULL(PagoSinAutorizar,0) = 1  -- Condicion para evitar autorizar pasivos 

		Update ProPasivos SET  -- Condicion para evitar autorizar pagos 
		AutorizadoEl = NULL,
		AutorizadoPor = NULL,
		PagoSinAutorizar = NULL,
		AutorizadoPago = NULL,
		ImportePagado=ImportePagado-@Importe
        WHERE IdPasivo=@IdPasivo
		AND ImportePagado = @Importe
		AND  ISNULL(AutorizadoPago,0) = 0  -- Condicion para evitar autorizar pasivos al pagar reposciones 
		AND  ISNULL(PagoSinAutorizar,0) = 0  -- s 

		Update ProPasivos SET 
		ImporteAPagar = ISNULL(ImporteAPagar,0)+@Importe
        WHERE IdPasivo=@IdPasivo
		AND ImportePagado <> @Importe

		Update ProPasivos SET 
		ImporteAPagar = NULL
        WHERE IdPasivo=@IdPasivo
		AND ImportePagado = 0

		Update ProPasivos SET 
		AutorizadoEl=@CanceladoEl,
		AutorizadoPor=@CanceladoPor,
		ImportePagado=ImportePagado-@Importe,
		ImporteAPagar = ISNULL(ImporteAPagar,0)+@Importe,  --para reversa del pasivo autorizado SOL 486
		AgrupadoParaPago =  0							   --para reversa del pasivo autorizado SOL 486
        WHERE IdPasivo=@IdPasivo
		AND ImportePagado = @Importe
		AND  ISNULL(AutorizadoPago,0) = 1 

		Fetch Next From MovimientosBancarios_CURSOR
		Into @IdPasivo,@Importe
	End
	Close MovimientosBancarios_CURSOR
	Deallocate MovimientosBancarios_CURSOR
	
--- cursor de contrarecibos para poder actualizar los estatus	
	Declare ContraRecibos_CURSOR Cursor For
	Select pp.IdPasivoContraRecibo ,
	SUM(ppmb.Importe) as Importe,
	pp.IdMoneda
	from ProPasivosMovimientosBancarios as ppmb
			INNER JOIN ProPasivos as pp On ppmb.IdPasivo = pp.IdPasivo 
			where ppmb.IdMovimientoBancario = @IdMovimientoBancario
			GROUP BY pp.IdPasivoContraRecibo,pp.IdMoneda -- Se modifico por parte de la solicitud 268

	Open ContraRecibos_CURSOR
	Fetch Next From ContraRecibos_CURSOR
	Into @IdPasivoContraRecibo, @ImportePasivoContraRecibo, @IdMoneda -- Se modifico por parte de la solicitud 268



	While @@Fetch_Status = 0
	Begin
		SET @ImportePasivoContraReciboPesos = 0 -- Se modifico por parte de la solicitud 268
		SET @ImportePasivoContraReciboDlls = 0 -- Se modifico por parte de la solicitud 268

		IF @IdMoneda = 1  
		BEGIN
			 SET @ImportePasivoContraReciboPesos = @ImportePasivoContraRecibo
		END
		else 
		BEGIN
			SET @ImportePasivoContraReciboDlls = @ImportePasivoContraRecibo
		END -- Se modifico por parte de la solicitud 268

		-- solicitud 12128
		Set @ImportePagadoContraRecibo = (Select ISNULL(ImportePagado,0) From ProPasivosContraRecibos Where IdPasivoContraRecibo = @IdPasivoContraRecibo AND CanceladoEl IS NULL ) - @ImportePasivoContraReciboPesos 
		Set @ImportePagadoContraReciboDlls = (Select ISNULL(ImportePagadoDlls,0) From ProPasivosContraRecibos Where IdPasivoContraRecibo = @IdPasivoContraRecibo  AND CanceladoEl IS NULL ) - @ImportePasivoContraReciboDlls
		Set @Total = (Select ISNULL(Total,0) From ProPasivosContraRecibos Where IdPasivoContraRecibo = @IdPasivoContraRecibo)
		set @TotalDlls = (Select ISNULL(TotalDlls,0) From ProPasivosContraRecibos Where IdPasivoContraRecibo = @IdPasivoContraRecibo)
		
		IF ISNULL(@ImportePagadoContraRecibo,0) = 0 AND ISNULL(@ImportePagadoContraReciboDlls,0) = 0
			SET @EstatusContraRecibo = 2 --PENDIENTE DE PAGO
		ELSE
			IF ISNULL(@ImportePagadoContraRecibo,0) = ISNULL(@Total,0) AND ISNULL(@ImportePagadoContraReciboDlls,0) = ISNULL(@TotalDlls,0)
				SET @EstatusContraRecibo = 1 --PAGADO
			ELSE
				 SET @EstatusContraRecibo = 3 --PARCIALMENTE PAGADO

		---------------------------FIN VALIDACIONES ESTATUS------------------------

			UPDATE ProPasivosContraRecibos SET Total = @Total ,
				TotalDlls =@TotalDlls ,
				ImportePagado = @ImportePagadoContraRecibo ,
				ImportePagadoDlls = @ImportePagadoContraReciboDlls,
				Estatus =@EstatusContraRecibo
			WHERE 	IdPasivoContraRecibo = @IdPasivoContraRecibo
		
		Fetch Next From ContraRecibos_CURSOR
		Into @IdPasivoContraRecibo, @ImportePasivoContraRecibo, @IdMoneda -- Se modifico por parte de la solicitud 268
	End
	Close ContraRecibos_CURSOR
	Deallocate ContraRecibos_CURSOR
	
    Delete From ProPasivosMovimientosBancarios Where IdMovimientoBancario = @IdMovimientoBancario	
	 
--- Actualizar ProReposiciones 
	UPDATE ProReposiciones 
	SET TipoMovimiento = Null,
		IdMovimientoBancario = Null,
		EsPagoComprobacion = NULL
	WHERE ProReposiciones.IdMovimientoBancario = @IdMovimientoBancario 
	
		   
--SE REALIZA LA VALIDACION QUE TENGA CONTABILIDAD INTEGRADA Y ESTRUCTURA CONTABLE
	SET @Mensaje =''
	SET @DeshabiliatarContabilidadIntegrada = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'DeshabiltarContabilidadIntegrada')
	SET @EstructuraCatalogoCuentas  = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas') 

 
	IF @EstructuraCatalogoCuentas <> ''
			BEGIN 
				Declare ChequesCancelarEliminarPagoAnticipado_CURSOR Cursor local For
				Select IdPagoAnticipado,MONTH(Fecha),YEAR(Fecha), Folio as FolioPagoAnticipado from ProPagosAnticipados Where IdMovimientoBancario= @IdMovimientoBancario

				Open ChequesCancelarEliminarPagoAnticipado_CURSOR
				Fetch Next From ChequesCancelarEliminarPagoAnticipado_CURSOR
				Into @IdPagoAnticipado,@FechaPagoAnticipadoMes,@FechaPagoAnticipadoAno,@FolioPagoAnticipado

				While @@Fetch_Status = 0
					Begin
						SET @ValidaProPagosAnticipados = 1
						SET @EsPeriodoCerrado =
							case @FechaPagoAnticipadoMes
								when 1 then (select PeriodoCerrado1 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 2 then (select PeriodoCerrado2 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 3 then (select PeriodoCerrado3 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 4 then (select PeriodoCerrado4 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 5 then (select PeriodoCerrado5 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 6 then (select PeriodoCerrado6 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 7 then (select PeriodoCerrado7 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 8 then (select PeriodoCerrado8 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 9 then (select PeriodoCerrado9 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 10 then (select PeriodoCerrado10 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 11 then (select PeriodoCerrado11 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
								when 12 then (select PeriodoCerrado12 from ProEjerciciosPeriodos where Ejercicio =@FechaPagoAnticipadoAno)
						END
						IF @EsPeriodoCerrado = 1 -- Valida si el periodo esta cerrada ( 1= cerrada, 0 = abierta)
							SET @Mensaje = @Mensaje+ 'el Folio '+cast(@FolioPagoAnticipado as varchar(6))+' del Pago Anticipado de su periodo contable está cerrado. Contacte a su contador o al personal encargado para abrir periodos contables'+ char(10)

						Fetch Next From ChequesCancelarEliminarPagoAnticipado_CURSOR
						Into @IdPagoAnticipado,@FechaPagoAnticipadoMes,@FechaPagoAnticipadoAno,@FolioPagoAnticipado
					End
				Close ChequesCancelarEliminarPagoAnticipado_CURSOR
				Deallocate ChequesCancelarEliminarPagoAnticipado_CURSOR 
		END
	
		IF @Mensaje <>'' 
			BEGIN
				DECLARE @MensajeError varchar(max)	
				SET 	@MensajeError  =''
				IF  @DeshabiliatarContabilidadIntegrada = 0 -- Contabilidad habilitada
					BEGIN
						SET @MensajeError = 'Su Contabilidad está activada, '+ @Mensaje
						RAISERROR(@MensajeError,
										16,
										1
										) 
					END
				ELSE -- Contabilidad deshabilita 
					BEGIN
						SET @MensajeError = 'Su Contabilidad está deshabilitada, '+@Mensaje
						RAISERROR(@MensajeError,
											16,
											1
											) 
					END
	 		END
			
	
	--- Elimina Polizas de pagos  anticipados
	IF @ValidaProPagosAnticipados = 1 
	BEGIN
		/*Antes de que se elimine la poliza, se van a quitar los asientos contables de CatCuentasContablesSaldos*/
		DECLARE @CondicionQuery nvarchar(max)  = ' pp.ProcesoLigado = ''ProPagosAnticipados'' AND pp.IdProcesoLigado IN (SELECT IdPagoAnticipado FROM ProPagosAnticipados WHERE IdMovimientoBancario = '+CAST(@IdMovimientoBancario AS varchar)+') ' 
		EXEC usp_ProPolizasActualizarSaldos @IdPeticion,0,@CondicionQuery
		DELETE FROM ProPolizas WHERE IdProcesoLigado 
									IN (SELECT IdPagoAnticipado FROM ProPagosAnticipados WHERE IdMovimientoBancario = @IdMovimientoBancario) 
									AND ProcesoLigado = 'ProPagosAnticipados'
	END
--- Eliminar ProPagosAnticipados
	DELETE FROM ProPagosAnticipados WHERE ProPagosAnticipados.IdMovimientoBancario = @IdMovimientoBancario	
	
--- Eliminar ProPagosAnticipados	
	DELETE FROM ProPagosProveedoresDocumentos WHERE ProPagosProveedoresDocumentos.IdMovimientoBancario = @IdMovimientoBancario	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

