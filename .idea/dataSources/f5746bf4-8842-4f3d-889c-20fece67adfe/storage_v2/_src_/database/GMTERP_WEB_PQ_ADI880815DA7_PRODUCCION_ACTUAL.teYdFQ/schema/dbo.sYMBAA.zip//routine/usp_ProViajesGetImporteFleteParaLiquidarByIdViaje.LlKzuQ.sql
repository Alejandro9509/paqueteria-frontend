
CREATE PROCEDURE [dbo].[usp_ProViajesGetImporteFleteParaLiquidarByIdViaje]
	@IdUsuario int,
	@IdViaje int
AS
DECLARE @Importe money

SET @Importe = ISNULL((SELECT SUM(CASE pv.IdMoneda
						WHEN 1 THEN pvcf.Importe
						ELSE pvcf.Importe * pv.TipoCambio
						END) AS Importe
				FROM ProViajesConceptosFacturacion AS pvcf
				INNER JOIN ProViajes AS pv ON pvcf.IdViaje = pv.IdViaje
				WHERE pvcf.IdViaje = @IdViaje
				AND pvcf.IncluirCalculoLiquidacionPorcentajeSobreImpFlete = 1
				),0)

IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'GetImporteFleteParaLiquidarByIdViaje' AND IdUsuario = @IdUsuario)
INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('GetImporteFleteParaLiquidarByIdViaje',@Importe,@IdUsuario)
ELSE
UPDATE SisParametrosPagina SET Parametros = @Importe WHERE Pagina = 'GetImporteFleteParaLiquidarByIdViaje' AND IdUsuario = @IdUsuario
go

