
CREATE PROCEDURE [dbo].[usp_ProSolicitudesEDIDescancelar]
	@IdSolicitudEDI int,
	@MotivoDescancelacion varchar(60),
	@DescanceladoEl datetime,
	@DescanceladoPor int,
	@IdPeticion varchar(100)
AS
DECLARE @IdViajeTrayecto int
/* *************************************************************************************************
	SOLICITUD 1813

	Descripcion: Metodo para descancelar una solicitud edi actualizando los campos:
	*CanceladoEl = NULL
	Con esto se sabe si la solicitud esta pendiente

	Ademas se actualizan 3 campos nuevos:
	@MotivoDescancelacionEDI varchar(60),
	@DescanceladoEl datetime,
	@DescanceladoPor int

	Creado por:   Amado Navarro
	Fecha de mofidicacion: 19/05/2020
	Versión 8.0.52.17

	Invocada desde: <PAGE_ProSolicitudesEDIListado>
	************************************************************************************************ */
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdSolicitudEDI,0) <= 0
		RAISERROR(N'El identificador de la solicitud EDI es un campo requerido',
			16,
			1
			)	
						
	IF NOT EXISTS(SELECT IdSolicitudEDI FROM ProSolicitudesEDI WHERE IdSolicitudEDI = @IdSolicitudEDI)
		RAISERROR(N'La solicitud EDI fue eliminado por otro usuario',
			16,
			1
			)

	IF (SELECT CanceladoEl FROM ProSolicitudesEDI WHERE IdSolicitudEDI = @IdSolicitudEDI) IS NULL --cancelado
		RAISERROR(N'No puede descancelar esta solicitud EDI porque no está cancelada',
			16,
			1
			)

	IF (SELECT AceptadoEl FROM ProSolicitudesEDI WHERE IdSolicitudEDI = @IdSolicitudEDI) IS NOT NULL --aceptado
		RAISERROR(N'No puede descancelar esta solicitud EDI porque está aceptada',
			16,
			1
			)
			
																
	UPDATE ProSolicitudesEDI SET
		CanceladoEl = NULL,
		MotivoDescancelacion = @MotivoDescancelacion,
		DescanceladoEl = @DescanceladoEl,
		DescanceladoPor = @DescanceladoPor		
	WHERE IdSolicitudEDI = @IdSolicitudEDI

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

