CREATE PROCEDURE [dbo].[usp_CatConceptosCobranzaEliminar]
	@IdConceptoCobranza int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM ProCobranza WHERE IdConceptoCobranza = @IdConceptoCobranza)
		RAISERROR(N'El conceptos ya tiene asignado movimientos de cobranza, no es posible eliminarlo',
			16,
			1
			)

	IF (SELECT DefinidoPorSistema FROM CatConceptosCobranza WHERE IdConceptoCobranza = @IdConceptoCobranza) = 1
		RAISERROR(N'El concepto que intenta eleminar es definido por sistema, no es posible eliminarlo',
			16,
			1
			)
				
	DELETE FROM CatConceptosCobranza
	WHERE IdConceptoCobranza = @IdConceptoCobranza
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

