
Create PROCEDURE [dbo].[usp_ProNominasPagarRecibo]
@IdNominaRecibo int,
@IdPeticion varchar(100),
@FechaPago dateTime
AS
BEGIN TRY
	BEGIN TRANSACTION
		UPDATE ProNominasRecibo
		SET FechaPago = @FechaPago
		WHERE IdNominaRecibo = @IdNominaRecibo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

