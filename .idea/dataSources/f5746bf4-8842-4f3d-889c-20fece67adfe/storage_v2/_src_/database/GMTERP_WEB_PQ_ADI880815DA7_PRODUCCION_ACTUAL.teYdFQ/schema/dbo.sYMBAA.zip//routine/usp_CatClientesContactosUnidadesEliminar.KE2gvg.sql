CREATE PROCEDURE [dbo].[usp_CatClientesContactosUnidadesEliminar]
	@IdClienteContactoUnidad int,
	@IdPeticion varchar(100)
AS
DECLARE
@IdClienteContacto int,
@IdUnidad int,
@IdClienteContactoUnidadHistorico int
BEGIN TRY
	BEGIN TRANSACTION
	
		IF @IdClienteContactoUnidad  = 0
			RAISERROR(N'El campo IdClienteContactoUnidad  es un campo requerido',
			16,
			1
			)
			Set @IdClienteContacto = (Select IdClienteContacto From CatClientesContactosUnidades WHERE IdClienteContactoUnidad = @IdClienteContactoUnidad)
			Set @IdUnidad = (Select IdUnidad From CatClientesContactosUnidades WHERE IdClienteContactoUnidad = @IdClienteContactoUnidad)
			IF EXISTS (SELECT TOP 1 IdClienteContactoUnidadHistorico FROM CatClientesContactosUnidadesHistorico WHERE IdUnidad = @IdUnidad AND IdClienteContacto = @IdClienteContacto ORDER BY FechaHoraVencimiento DESC)
			 BEGIN
			set @IdClienteContactoUnidadHistorico = (SELECT TOP 1 IdClienteContactoUnidadHistorico FROM CatClientesContactosUnidadesHistorico WHERE IdUnidad = @IdUnidad AND IdClienteContacto = @IdClienteContacto ORDER BY FechaHoraVencimiento DESC) 
			UPDATE CatClientesContactosUnidadesHistorico SET FechaHoraVencimiento = GETDATE()  WHERE IdClienteContactoUnidadHistorico = @IdClienteContactoUnidadHistorico
			END
		DELETE CatClientesContactosUnidades WHERE IdClienteContactoUnidad = @IdClienteContactoUnidad

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

