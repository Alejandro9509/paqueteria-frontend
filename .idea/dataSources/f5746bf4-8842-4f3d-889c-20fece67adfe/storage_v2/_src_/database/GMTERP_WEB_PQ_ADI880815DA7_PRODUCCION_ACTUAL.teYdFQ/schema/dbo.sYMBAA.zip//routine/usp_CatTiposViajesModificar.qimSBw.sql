CREATE PROCEDURE [dbo].[usp_CatTiposViajesModificar]
	@IdTipoViaje int,
	@Codigo int,
	@TipoViaje varchar(50),
	@Activo bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatTiposViajesModificar

Parámetros: 
	@IdTipoViaje 			(entrada, entero). Identificador del tipo de viaje a modificar
	@Codigo  				(entrada, entero). Codigo del tipo de viaje
	@TipoViaje 				(entrada, texto). Descripcion del tipo de viaje
	@Activo	            	(entrada, boleano). Bandera para saber si el tipo de viaje esta activa/no activa
	@ModificadoPor	        (entrada, entero). Usuario que realiza la modificacion
	@ModificadoEl	        (entrada, fecha hora). Fecha y hora de modificacion
	@UltimaModificacion 	(entrada, fecha hora). Fecha para validar la concurrencia
	@IdPeticion   	    	(entrada, string). Id de la Petición, generada en WEBDEV 	
 
Descripción: Procedimiento para modificar un tipo de viaje

23/10/2019   Se agrego el parametro de Activo a la tabla

Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 23/10/2019
Versión ERP: 8.0.47.09

Invocada desde: PAGE_CatTiposViajesAM (Solicitud 368)
***************************************************************************************************** */	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdTipoViaje,0) <= 0
		RAISERROR(N'El identificador del tipo de viaje es un campo requerido',
			16,
			1
			)	

	IF NOT EXISTS(SELECT IdTipoViaje FROM CatTiposViajes WHERE IdTipoViaje = @IdTipoViaje)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)						

	IF (SELECT ModificadoEl FROM CatTiposViajes WHERE IdTipoViaje = @IdTipoViaje) <> @UltimaModificacion
		RAISERROR(N'Los datos de este tipo de viaje fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)				

	IF ISNULL(@Codigo,0) <= 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)	

	IF EXISTS(SELECT Codigo FROM CatTiposViajes WHERE Codigo = @Codigo AND IdTipoViaje <> @IdTipoViaje)
		RAISERROR(N'El código ya existe',
			16,
			1
			)

	IF LTRIM(RTRIM(@TipoViaje)) = ''
		RAISERROR(N'El campo tipo de viaje es requerido',
			16,
			1
			)

	UPDATE CatTiposViajes SET
		Codigo = @Codigo,
		TipoViaje = @TipoViaje,
		Activo = @Activo,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdTipoViaje = @IdTipoViaje
			
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

