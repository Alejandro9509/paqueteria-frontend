CREATE PROCEDURE [dbo].[usp_CatProveedoresEliminar]
	@IdProveedor int,
	@IdPeticion varchar(100)
AS
/*
MODIFICADO:
	Se agrego en la seccion de eliminar la cuenta contable , un delete para la cuenta contable 
	en el catalogo de CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-10-01
SOLICITUD: 
	SOLICITUD 000266
*/
BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 IdValeCombustible FROM ProValesCombustible WHERE IdProveedor = @IdProveedor)
		RAISERROR(N'El proveedor tiene vales de combustible asigandos, no es posible eliminarlo',
			16,
			1
			)	
		
	DELETE FROM CatProveedores
	WHERE IdProveedor = @IdProveedor

    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
		/*Se elimina la cuenta contable del catalogo CatCuentasContablesSaldos*/
		DELETE FROM CatCuentasContablesSaldos WHERE
		IdCuentaContable IN (SELECT IdCuentaContable FROM CatCuentasContables WHERE CatalogoLigado = 'CatProveedores' AND IdCatalogoLigado = @IdProveedor)

        DELETE FROM CatCuentasContables 
        WHERE CatalogoLigado = 'CatProveedores' AND IdCatalogoLigado = @IdProveedor
    END 	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

