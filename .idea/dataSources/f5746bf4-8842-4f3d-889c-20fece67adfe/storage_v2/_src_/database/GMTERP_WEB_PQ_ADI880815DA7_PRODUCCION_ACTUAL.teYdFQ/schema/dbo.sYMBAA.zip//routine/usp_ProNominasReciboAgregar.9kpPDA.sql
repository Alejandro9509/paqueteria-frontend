CREATE PROCEDURE [dbo].[usp_ProNominasReciboAgregar]
	@IdEmpleado int,
	@IdPeriodo int,
	@Calculado bit,
	@IdDepartamento int,
	@IdPuesto int,
	@IdTipoPeriodo int,
	@IdTurno int,
	@SueldoDiario money,
	@SueldoVariable money,
	@SueldoPromedio money,
	@SueldoIntegrado money,
	@TipoContrato varchar(100),
	@ImporteTotalPercepcionesGravadoISR money,
	@ImporteTotalPercepcionesExentoISR money,
	@ImporteTotalPercepcionesGravadoIMSS money,
	@ImporteTotalPercepcionesExentoIMSS money,
	@ImporteTotalPercepciones money,
	@ImporteTotalDeduccionesGravadoISR money,
	@ImporteTotalDeduccionesExentoISR money,
	@ImporteTotalDeduccionesGravadoIMSS money,
	@ImporteTotalDeduccionesExentoIMSS money,
	@ImporteTotalDeducciones money,
	@ImporteTotalObligacionesGravadoISR money,
	@ImporteTotalObligacionesExentoISR money,
	@ImporteTotalObligacionesGravadoIMSS money,
	@ImporteTotalObligacionesExentoIMSS money,
	@ImporteTotalObligaciones money,
	@Subtotal money,
	@Descuentos money,
	@Retenciones money,
	@NetoPagar money,
	@dsProNominasRecibosConceptos ntext,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@dsProNominasRecibosTiposAcumulados ntext,
	@ClaveTipoContrato varchar(5),
	@TipoRecibo tinyint,
	@dsProNominasRecibosConceptosHorasExtras ntext
AS
DECLARE
	@docHandle int,
	@IdNominaRecibo int,
	@IdNominaReciboConcepto int,
	@IdConceptoPDO int 
BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
		IF @IdEmpleado = 0
			RAISERROR(N'El empleado es un campo requerido',
				16,
				1
				)
		IF @SueldoDiario = 0
			RAISERROR(N'El sueldo diario del empleado es un campo requerido',
				16,
				1
				)	
		IF @IdPeriodo = 0
			RAISERROR(N'El periodo es un campo requerido',
				16,
				1
				)
		IF @IdDepartamento = 0
			RAISERROR(N'El departamento es un campo requerido',
				16,
				1
				)
		IF @IdPuesto = 0
			RAISERROR(N'El puesto es un campo requerido',
				16,
				1
				)
		IF @IdTipoPeriodo = 0
			RAISERROR(N'El tipo de periodo es un campo requerido',
				16,
				1
				)		
		IF @IdTurno = 0
			RAISERROR(N'El turno es un campo requerido',
				16,
				1
				)					
	
		--validar si el empleado tiene recibos generados en el mismo perido		
		IF EXISTS(SELECT * FROM ProNominasRecibo WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo)
			RAISERROR(N'El empleado tiene recibos generados en este período',
				16,
				1
				)
	--Sección para Insertar en ProNominasRecibo	
	INSERT INTO ProNominasRecibo(IdEmpleado,IdPeriodo,Calculado,FechaHora,IdDepartamento,IdPuesto,
	IdTipoPeriodo,IdTurno,SueldoDiario,SueldoVariable,SueldoPromedio,SueldoIntegrado,TipoContrato,ImporteTotalPercepcionesGravadoISR,ImporteTotalPercepcionesExentoISR,ImporteTotalPercepcionesGravadoIMSS,
	ImporteTotalPercepcionesExentoIMSS,ImporteTotalPercepciones,ImporteTotalDeduccionesGravadoISR,ImporteTotalDeduccionesExentoISR,ImporteTotalDeduccionesGravadoIMSS,ImporteTotalDeduccionesExentoIMSS,ImporteTotalDeducciones,
	ImporteTotalObligacionesGravadoISR,ImporteTotalObligacionesExentoISR,ImporteTotalObligacionesGravadoIMSS,ImporteTotalObligacionesExentoIMSS,ImporteTotalObligaciones,Subtotal,Descuentos,Retenciones,NetoPagar,CreadoPor,CreadoEl,ClaveTipoContrato,TipoRecibo)
	VALUES(@IdEmpleado,@IdPeriodo,@Calculado,GETDATE(),@IdDepartamento,@IdPuesto,
	@IdTipoPeriodo,@IdTurno,@SueldoDiario,@SueldoVariable,@SueldoPromedio,@SueldoIntegrado,@TipoContrato,@ImporteTotalPercepcionesGravadoISR,@ImporteTotalPercepcionesExentoISR,@ImporteTotalPercepcionesGravadoIMSS,
	@ImporteTotalPercepcionesExentoIMSS,@ImporteTotalPercepciones,@ImporteTotalDeduccionesGravadoISR,@ImporteTotalDeduccionesExentoISR,@ImporteTotalDeduccionesGravadoIMSS,@ImporteTotalDeduccionesExentoIMSS,@ImporteTotalDeducciones,
	@ImporteTotalObligacionesGravadoISR,@ImporteTotalObligacionesExentoISR,@ImporteTotalObligacionesGravadoIMSS,@ImporteTotalObligacionesExentoIMSS,@ImporteTotalObligaciones,@Subtotal,@Descuentos,@Retenciones,@NetoPagar,@CreadoPor,@CreadoEl,@ClaveTipoContrato,@TipoRecibo)
	
	--Sección para Obtener el último Id que se insertó en ProNominasRecibo
	SET @IdNominaRecibo = (SELECT IDENT_CURRENT('ProNominasRecibo'))

	--Sección para agregar los conceptosPDO
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNominasRecibosConceptos

	SELECT ATT_IdConceptoPDO,ATT_TipoConcepto,ATT_Valor,ATT_ImporteTotal,ATT_ImporteGravadoISR,ATT_ImporteExentoISR,ATT_ImporteGravadoIMSS,ATT_ImporteExentoIMSS,ATT_SeModifico,ATT_Especie,ATT_IdConceptoPDOFijo
	INTO #TempProNominasRecibosConceptos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNominasRecibosConceptos',2) 
	WITH (ATT_IdConceptoPDO int,ATT_TipoConcepto int,ATT_Valor money,ATT_ImporteTotal money,ATT_ImporteGravadoISR money,ATT_ImporteExentoISR money,ATT_ImporteGravadoIMSS money,ATT_ImporteExentoIMSS money,ATT_SeModifico tinyint,ATT_Especie bit ,ATT_IdConceptoPDOFijo int)

	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO ProNominasReciboConceptos(IdNominaRecibo,IdConceptoPDO,TipoConcepto,Valor,ImporteTotal,ImporteGravadoISR,ImporteExentoISR,ImporteGravadoIMSS,ImporteExentoIMSS,CreadoPor,CreadoEl,SeModifico,Especie,IdConceptoPDOFijo)
	SELECT @IdNominaRecibo,ATT_IdConceptoPDO,ATT_TipoConcepto,ATT_Valor,ATT_ImporteTotal,ATT_ImporteGravadoISR,ATT_ImporteExentoISR,ATT_ImporteGravadoIMSS,ATT_ImporteExentoIMSS,@CreadoPor,@CreadoEl,ATT_SeModifico,ATT_Especie,ATT_IdConceptoPDOFijo
	FROM #TempProNominasRecibosConceptos

	--Sección para agregar las horas extra 
	SET @IdConceptoPDO = (SELECT IdConceptoPDO FROM CatConceptosPDO WHERE NumeroConcepto = 4) 
	SET @IdNominaReciboConcepto = (SELECT IdNominaReciboConcepto FROM ProNominasReciboConceptos WHERE IdConceptoPDO = @IdConceptoPDO AND IdNominaRecibo = @IdNominaRecibo)
	
	IF  ISNULL(@IdNominaReciboConcepto,0) <> 0
	BEGIN 
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNominasRecibosConceptosHorasExtras

		SELECT ATT_IdNominaReciboConceptoHoraExtra,ATT_IdNominaReciboConcepto,ATT_Dias,ATT_TipoHoras,ATT_HorasExtra,ATT_ImportePagado
		INTO #ProNominasReciboConceptosHorasExtras
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNominasReciboConceptosHorasExtras',2) 
		WITH (ATT_IdNominaReciboConceptoHoraExtra int,ATT_IdNominaReciboConcepto int,ATT_Dias int,ATT_TipoHoras varchar(5),ATT_HorasExtra int,ATT_ImportePagado money)

		EXEC sp_xml_removedocument @docHandle
	
		INSERT INTO ProNominasReciboConceptosHorasExtras(IdNominaReciboConcepto,Dias,TipoHoras,HorasExtra,ImportePagado,CreadoPor,CreadoEl)
		SELECT @IdNominaReciboConcepto,ATT_Dias,ATT_TipoHoras,ATT_HorasExtra,ATT_ImportePagado,@CreadoPor,@CreadoEl
		FROM #ProNominasReciboConceptosHorasExtras
	END 

		
	--Sección para agregar los Tipos Acumulados
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNominasRecibosTiposAcumulados

	SELECT ATT_IdTipoAcumulado,ATT_AcumuladoEjercicioAnterior,ATT_ImporteInicialEjercicio,ATT_Mes,ATT_Importe
	INTO #TempProNominasRecibosTiposAcumulados
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNominasRecibosTiposAcumulados',2) 
	WITH (ATT_IdTipoAcumulado int,ATT_AcumuladoEjercicioAnterior money,ATT_ImporteInicialEjercicio money,ATT_Mes int,ATT_Importe money)

	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO ProNominasRecibosTiposAcumulados(IdNominaRecibo,IdTipoAcumulado,AcumuladoEjercicioAnterior,ImporteInicialEjercicio,Mes,Importe,CreadoPor,CreadoEl)
	SELECT @IdNominaRecibo,ATT_IdTipoAcumulado,ATT_AcumuladoEjercicioAnterior,ATT_ImporteInicialEjercicio,ATT_Mes,ATT_Importe,@CreadoPor,@CreadoEl
	FROM #TempProNominasRecibosTiposAcumulados
	
	--Percepcion
	IF (SELECT CAST(ISNULL(SUM(ImporteTotal),0) AS DECIMAL (15,2)) FROM ProNominasReciboConceptos WHERE IdNominaRecibo = @IdNominaRecibo AND TipoConcepto = 1 AND Especie = 0) <> CAST(@ImporteTotalPercepciones AS DECIMAL (15,2)) 
		RAISERROR(N'La suma de los importes de los conceptos de percepción no son iguales al total de percepción',
			16,
			1
			)
	--Deduccion
	IF (SELECT ISNULL(SUM(ImporteTotal),0) FROM ProNominasReciboConceptos WHERE IdNominaRecibo = @IdNominaRecibo AND TipoConcepto = 2 AND Especie = 0) <> @ImporteTotalDeducciones
		RAISERROR(N'La suma de los importes de los conceptos de deducción no son iguales al total de deducción',
			16,
			1
			)
	--Obligacion		
	IF (SELECT ISNULL(SUM(ImporteTotal),0) FROM ProNominasReciboConceptos WHERE IdNominaRecibo = @IdNominaRecibo AND TipoConcepto = 3 AND Especie = 0) <> @ImporteTotalObligaciones
		RAISERROR(N'La suma de los importes de los conceptos de obligación no son iguales al total de obligación',
			16,
			1
			)
	COMMIT
END TRY
BEGIN CATCH	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

