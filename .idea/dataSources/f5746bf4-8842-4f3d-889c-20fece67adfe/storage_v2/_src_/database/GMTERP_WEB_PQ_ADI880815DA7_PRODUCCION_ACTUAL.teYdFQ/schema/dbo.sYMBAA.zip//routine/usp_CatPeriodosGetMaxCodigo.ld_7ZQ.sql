

create PROCEDURE [dbo].[usp_CatPeriodosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(NumeroPeriodo),0)+1 AS Codigo FROM CatPeriodos
go

