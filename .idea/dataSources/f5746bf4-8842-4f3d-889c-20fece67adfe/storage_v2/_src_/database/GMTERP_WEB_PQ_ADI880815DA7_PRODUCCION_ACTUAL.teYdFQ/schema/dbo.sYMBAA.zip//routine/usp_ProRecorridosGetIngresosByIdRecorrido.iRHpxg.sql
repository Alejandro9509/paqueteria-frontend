
CREATE PROCEDURE [dbo].[usp_ProRecorridosGetIngresosByIdRecorrido]
	@IdUsuario int,
	@IdRecorrido int,
	@IdMoneda int
AS
DECLARE @Importe money

IF @IdMoneda = 2 
BEGIN
SET @Importe = ISNULL((SELECT SUM(CASE pv.IdMoneda
						WHEN 2 THEN pvcf.Importe
						ELSE pvcf.Importe / pv.TipoCambio
						END) 
						AS Importe
						FROM ProRecorridosConceptosFacturacion AS pvcf
						INNER JOIN ProRecorridos AS pv ON pvcf.IdRecorrido = pv.IdRecorrido
						WHERE pvcf.IdRecorrido = @IdRecorrido
						--AND pvcf.IncluirCalculoIngresosLiquidacion = 1
				),0)
END
ELSE
BEGIN
SET @Importe = ISNULL((SELECT SUM(CASE pv.IdMoneda
						WHEN 1 THEN pvcf.Importe
						ELSE pvcf.Importe * pv.TipoCambio
						END) 
						AS Importe
						FROM ProRecorridosConceptosFacturacion AS pvcf
						INNER JOIN ProRecorridos AS pv ON pvcf.IdRecorrido = pv.IdRecorrido
						WHERE pvcf.IdRecorrido = @IdRecorrido
						--AND pvcf.IncluirCalculoIngresosLiquidacion = 1
				),0)
END
IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'GetIngresosByIdRecorrido' AND IdUsuario = @IdUsuario)
INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('GetIngresosByIdRecorrido',@Importe,@IdUsuario)
ELSE
UPDATE SisParametrosPagina SET Parametros = @Importe WHERE Pagina = 'GetIngresosByIdRecorrido' AND IdUsuario = @IdUsuario
go

