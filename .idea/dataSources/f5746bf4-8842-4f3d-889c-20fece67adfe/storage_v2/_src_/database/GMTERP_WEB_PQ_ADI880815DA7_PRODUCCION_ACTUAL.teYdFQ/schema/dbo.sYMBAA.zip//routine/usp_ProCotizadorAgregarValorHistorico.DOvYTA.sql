CREATE PROCEDURE [dbo].[usp_ProCotizadorAgregarValorHistorico]
	@IdCotizacion INT,
	@IdCliente INT,
	@IdSubCliente INT,
	@IdClienteContacto INT,
	@IdMoneda VARCHAR(50),
	@IdOrigen INT,
	@IdDestino INT,
	@Fecha DATETIME,
	@ModificadoEl DATETIME,
	@ModificadoPor INT,
	@TipoCambio FLOAT,
	@dsCatRutasCompuestas NTEXT,
	@IdPeticion VARCHAR(100),
	@AgregarValorHistorico BIT OUTPUT
AS
/* *************************************************************************************************
Modificada por:  Adrian Varela Morales
Fecha de mofidicacion: 18/03/2020
Versión ERP:  Versión 8.0.51.09
Solicitud 1225
--Se agregan campos para guardar valores originales que afectan al calculo de liquidacion

Modificada por: Ricardo Sinai Miranda Pantoja
Fecha de mofidicacion: 02/06/2020
Versión ERP:  Versión 8.0.52.42
Solicitud: 2,302
-- Se aegragron validaciones para realizar las actualizaciones de la tabla Cotización en Cotizaciones y Cotizaciones por Trazo.

Modificada por:  Adrian Varela Morales
Fecha de mofidicacion: 03/09/2020
Versión ERP:  Versión 8.0.55.21
Solicitud 3020
--Se agregan validaciones para el borrado de las tablas temporales

Modificada por:  Adrian Varela Morales
Fecha de mofidicacion: 04/09/2020
Versión ERP:  Versión 8.0.55.21
Solicitud 3020
--Se actualizan validaciones para el borrado de las tablas temporales
***************************************************************************************************** */

DECLARE
	@docHandle INT,
	@IdRetornoCotizacion INT,
	@IdRetornoCotizacionRuta INT,
	@COL_IdCotizacionRuta INT,
	@COL_IdRutaCompuesta INT,
	@COL_Consecutivo INT,
	@COL_Concepto VARCHAR(100),
	@COL_IncDec FLOAT,
	@COL_PrecioNeto MONEY,
	@COL_CargosAdicionales MONEY,
	@COL_CargosAdicionalesDlls MONEY,
	@COL_TotalFlete MONEY,
	@COL_XMLCargosAdicionales VARCHAR(8000),
	@COL_Grupo BIT,
	@COL_Consolidar BIT,
	@COL_FolioConsolidar int,
	@ATT_IdCotizacionRutaCargoAdicional INT,
	@ATT_IdConceptoFacturacion INT, 
	@ATT_CodigoConceptoFacturacion INT, 
	@ATT_ConceptoFacturacion VARCHAR(100),
	@ATT_Cantidad FLOAT, 
	@ATT_PrecioUnitario MONEY, 
	@ATT_Importe MONEY,
	@COL_FleteMN MONEY,
	@COL_FleteDLLS MONEY,
	@COL_xCostoKilometro money,
	@COL_Precio_Sugerido money,
	@COL_KMTotalRuta money,
	@COL_Autopistas money,
	@COL_UtilidadRuta money,
	@COL_Especializado money,
	@COL_Posicionamiento money,
	@COL_Precio_doble_op money,
	@COL_FleteMnOriginal money
BEGIN TRY

	SET @AgregarValorHistorico = 0

	IF EXISTS(SELECT IdCotizacion FROM ProCotizaciones WHERE IdCotizacion = @IdCotizacion AND
	(Fecha <> @Fecha OR
	IdCliente <> @IdCliente OR
	IdSubCliente <> @IdSubCliente OR
	IdClienteContacto <> @IdClienteContacto OR
	IdMoneda <> @IdMoneda OR
	IdOrigen <> @IdOrigen OR
	IdDestino <> @IdDestino OR
	TipoCambio <> @TipoCambio))
		SET @AgregarValorHistorico = 1

	IF @AgregarValorHistorico = 0
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasCompuestas

			IF object_id('#TempCatRutasCompuestas') > 0
				BEGIN
					DROP TABLE #TempCatRutasCompuestas
				END

			SELECT COL_IdRutaCompuesta, COL_Consecutivo, COL_Concepto, COL_IncDec, COL_PrecioNeto, COL_CargosAdicionales, 
			COL_CargosAdicionalesDlls, COL_TotalFlete, COL_XMLCargosAdicionales, COL_Grupo, COL_Consolidar,COL_FolioConsolidar,
			COL_FleteMN,COL_FleteDLLS,COL_Precio_Sugerido,
			COL_KMTotalRuta,
			COL_Autopistas,
			COL_UtilidadRuta,
			COL_Especializado,
			COL_Posicionamiento,
			COL_Precio_doble_op,
			COL_FleteMnOriginal,
			COL_CostoKilometroX 
			INTO #TempCatRutasCompuestas
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_Cotizacion',2) 
			WITH (COL_IdRutaCompuesta FLOAT, COL_Consecutivo INT, COL_Concepto VARCHAR(100), COL_IncDec FLOAT, COL_PrecioNeto MONEY,
					COL_CargosAdicionales MONEY, COL_CargosAdicionalesDlls MONEY, COL_TotalFlete MONEY, COL_XMLCargosAdicionales VARCHAR(8000), COL_Grupo BIT,COL_Consolidar BIT,
					COL_FolioConsolidar INT,
					COL_FleteMN MONEY, COL_FleteDLLS MONEY,COL_Precio_Sugerido money,
					COL_KMTotalRuta money,
					COL_Autopistas money,
					COL_UtilidadRuta money,
					COL_Especializado money,
					COL_Posicionamiento money,
					COL_Precio_doble_op money,
					COL_FleteMnOriginal money,
					COL_CostoKilometroX money)

			IF NOT (SELECT COUNT(*) FROM #TempCatRutasCompuestas) = (SELECT COUNT(*) FROM ProCotizacionesRutas WHERE IdCotizacion = @IdCotizacion) 
				BEGIN
					SET @AgregarValorHistorico = 1
					DROP TABLE #TempCatRutasCompuestas
				END
	
			IF @AgregarValorHistorico = 0
			BEGIN
				DECLARE CursorCatRutasCompuestas CURSOR FOR SELECT * FROM #TempCatRutasCompuestas

				OPEN CursorCatRutasCompuestas FETCH NEXT FROM CursorCatRutasCompuestas
				INTO @COL_IdRutaCompuesta, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales,
				@COL_CargosAdicionalesDlls, @COL_TotalFlete, @COL_XMLCargosAdicionales, @COL_Grupo, @COL_Consolidar, @COL_FolioConsolidar,
				@COL_FleteMN, @COL_FleteDLLS,@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xCostoKilometro
				WHILE @@FETCH_STATUS = 0
				BEGIN
					IF @COL_XMLCargosAdicionales <> ''
					BEGIN
						 EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLCargosAdicionales

						 IF object_id(N'tempdb..#TempProCotizacionesRutasCargosAdicionales') IS NOT NULL
							BEGIN
								DROP TABLE #TempProCotizacionesRutasCargosAdicionales
							END

						 SELECT ATT_IdConceptoFacturacion, ATT_CodigoConceptoFacturacion, ATT_ConceptoFacturacion, 
						 ATT_Cantidad, ATT_PrecioUnitario, ATT_Importe
						 INTO #TempProCotizacionesRutasCargosAdicionales
						 FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CargosAdicionales',2) 
						 WITH(ATT_IdConceptoFacturacion INT, ATT_CodigoConceptoFacturacion INT, ATT_ConceptoFacturacion VARCHAR(100),
							ATT_Cantidad FLOAT, ATT_PrecioUnitario MONEY, ATT_Importe MONEY)

						EXEC sp_xml_removedocument @docHandle

						IF EXISTS (SELECT IdCotizacionRuta FROM ProCotizacionesRutas WHERE IdRutaCompuesta = @COL_IdRutaCompuesta AND IdCotizacion = @IdCotizacion AND Consecutivo = @COL_Consecutivo)
							BEGIN
							DECLARE @IdCotizacionRutaLocal INT = (SELECT IdCotizacionRuta FROM ProCotizacionesRutas WHERE IdRutaCompuesta = @COL_IdRutaCompuesta AND IdCotizacion = @IdCotizacion AND Consecutivo = @COL_Consecutivo)

							IF NOT (SELECT COUNT(*) FROM #TempProCotizacionesRutasCargosAdicionales) = (SELECT COUNT(*) FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @IdCotizacionRutaLocal)
								BEGIN	
									SET @AgregarValorHistorico = 1
									IF object_id(N'tempdb..#TempProCotizacionesRutasCargosAdicionales') IS NOT NULL
									BEGIN
										DROP TABLE #TempProCotizacionesRutasCargosAdicionales
									END
								END
							END

							IF @AgregarValorHistorico = 0
							BEGIN
								-- Se verifica si se realizó alguna modificación en la tabla Cotización
								IF EXISTS (SELECT IdCotizacionRuta FROM ProCotizacionesRutas WHERE IdRutaCompuesta = @COL_IdRutaCompuesta AND IdCotizacion = @IdCotizacion and Consecutivo = @COL_Consecutivo AND ( Concepto <> @COL_Concepto OR
								IncDec <> @COL_IncDec OR PrecioNeto <> @COL_PrecioNeto OR CargosAdicionales <> @COL_CargosAdicionales OR CargosAdicionalesDlls <> @COL_CargosAdicionalesDlls OR
								TotalFlete <> @COL_TotalFlete OR Consolidar <> @COL_Consolidar OR FolioConsolidar <> @COL_FolioConsolidar OR FleteMN <> @COL_FleteMN OR 
								FleteDLLS <> @COL_FleteDLLS OR Grupo <> @COL_Grupo))
								BEGIN
									SET @AgregarValorHistorico = 1
									IF object_id(N'tempdb..#TempProCotizacionesRutasCargosAdicionales') IS NOT NULL
									BEGIN
										DROP TABLE #TempProCotizacionesRutasCargosAdicionales
									END
								END
							END
						ELSE
							BEGIN
								SET @AgregarValorHistorico = 1
								IF object_id(N'tempdb..#TempProCotizacionesRutasCargosAdicionales') IS NOT NULL
								BEGIN
									DROP TABLE #TempProCotizacionesRutasCargosAdicionales
								END
							END

						IF @AgregarValorHistorico = 0
							BEGIN
								DECLARE CursorProCotizacionCargosAdicionalesRuta CURSOR FOR SELECT * FROM #TempProCotizacionesRutasCargosAdicionales

								OPEN CursorProCotizacionCargosAdicionalesRuta FETCH NEXT FROM CursorProCotizacionCargosAdicionalesRuta
								INTO @ATT_IdConceptoFacturacion, @ATT_CodigoConceptoFacturacion, @ATT_ConceptoFacturacion, @ATT_Cantidad,
								@ATT_PrecioUnitario, @ATT_Importe
								WHILE @@FETCH_STATUS = 0
								BEGIN
									IF EXISTS (SELECT IdCotizacionRutaCargoAdicional FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @IdCotizacionRutaLocal AND IdConceptoFacturacion = @ATT_IdConceptoFacturacion)
										BEGIN
											DECLARE @IdCotizacionRutaCargoAdicionalLocal INT = (SELECT IdCotizacionRutaCargoAdicional FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @IdCotizacionRutaLocal AND IdConceptoFacturacion = @ATT_IdConceptoFacturacion)

											IF EXISTS (SELECT IdCotizacionRutaCargoAdicional FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRutaCargoAdicional = @IdCotizacionRutaCargoAdicionalLocal AND
											(Cantidad <> @ATT_Cantidad OR PrecioUnitario <> @ATT_PrecioUnitario))
												SET @AgregarValorHistorico = 1
										END
									ELSE
										SET @AgregarValorHistorico = 1

									FETCH NEXT FROM CursorProCotizacionCargosAdicionalesRuta
									INTO @ATT_IdConceptoFacturacion, @ATT_CodigoConceptoFacturacion, @ATT_ConceptoFacturacion, @ATT_Cantidad,
									@ATT_PrecioUnitario, @ATT_Importe
								END

								CLOSE CursorProCotizacionCargosAdicionalesRuta
								DEALLOCATE CursorProCotizacionCargosAdicionalesRuta

								DROP TABLE #TempProCotizacionesRutasCargosAdicionales
							END
					END
				ELSE
				BEGIN
					IF @AgregarValorHistorico = 0
					BEGIN
						-- Se verifica si se realizó alguna modificación en la tabla Cotización
						IF EXISTS (SELECT IdCotizacionRuta FROM ProCotizacionesRutas WHERE IdRutaCompuesta = @COL_IdRutaCompuesta AND IdCotizacion = @IdCotizacion and Consecutivo = @COL_Consecutivo AND ( Concepto <> @COL_Concepto OR
						IncDec <> @COL_IncDec OR PrecioNeto <> @COL_PrecioNeto OR CargosAdicionales <> @COL_CargosAdicionales OR CargosAdicionalesDlls <> @COL_CargosAdicionalesDlls OR
						TotalFlete <> @COL_TotalFlete OR Consolidar <> @COL_Consolidar OR FolioConsolidar <> @COL_FolioConsolidar OR FleteMN <> @COL_FleteMN OR 
						FleteDLLS <> @COL_FleteDLLS OR Grupo <> @COL_Grupo))
						BEGIN
							SET @AgregarValorHistorico = 1
						END
					END
				END

				FETCH NEXT FROM CursorCatRutasCompuestas
				INTO @COL_IdRutaCompuesta, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales,
				@COL_CargosAdicionalesDlls, @COL_TotalFlete, @COL_XMLCargosAdicionales, @COL_Grupo, @COL_Consolidar, @COL_FolioConsolidar,
				@COL_FleteMN, @COL_FleteDLLS,@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xCostoKilometro

				END

				CLOSE CursorCatRutasCompuestas
				DEALLOCATE CursorCatRutasCompuestas

				DROP TABLE #TempCatRutasCompuestas
			END
		END

	IF @AgregarValorHistorico = 1
	BEGIN
		BEGIN TRANSACTION
		
		INSERT INTO ProCotizacionesValorHistorico (IdCotizacion, CreadoEl, CreadoPor, Revision, Folio, Fecha, IdCliente, IdSubCliente, IdClienteContacto, 
		IdOrigen, IdDestino, IdMoneda, TipoCambio) SELECT IdCotizacion, @ModificadoEl, @ModificadoPor, Revision, Folio, Fecha, IdCliente, IdSubCliente, IdClienteContacto,
		IdOrigen, IdDestino, IdMoneda, TipoCambio FROM ProCotizaciones WHERE IdCotizacion = @IdCotizacion
			
		SET @IdRetornoCotizacion = (SELECT IDENT_CURRENT('ProCotizacionesValorHistorico'))

		BEGIN --Se agregan las rutas en la cotizacion
			DECLARE CursorProCotizacionesRutasHistorico CURSOR FOR 
			SELECT IdCotizacionRuta, IdRutaCompuesta, Consecutivo, Concepto, IncDec, PrecioNeto, CargosAdicionales, 
			CargosAdicionalesDlls, TotalFlete, Grupo, Consolidar,FolioConsolidar, 
			FleteMN, FleteDLLS,PrecioSugerido,
			KMTotalRuta,
			TotalCasetas,
			UtilidadRuta,
			Especializado,
			Posicionamiento,
			CostoDobleOP,
			FleteMnOriginal,
			AuxCostoKilometro 
			FROM ProCotizacionesRutas WHERE IdCotizacion = @IdCotizacion

			OPEN CursorProCotizacionesRutasHistorico FETCH NEXT FROM CursorProCotizacionesRutasHistorico
			INTO @COL_IdCotizacionRuta, @COL_IdRutaCompuesta, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales, 
			@COL_CargosAdicionalesDlls, @COL_TotalFlete, @COL_Grupo, @COL_Consolidar, @COL_FolioConsolidar,
			@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,
			@COL_KMTotalRuta,
			@COL_Autopistas,
			@COL_UtilidadRuta,
			@COL_Especializado,
			@COL_Posicionamiento,
			@COL_Precio_doble_op,
			@COL_FleteMnOriginal,
			@COL_xCostoKilometro

			WHILE @@FETCH_STATUS = 0

			BEGIN
				SET IDENTITY_INSERT ProCotizacionesRutasValorHistorico OFF

				INSERT INTO ProCotizacionesRutasValorHistorico(IdCotizacionRuta, CreadoEl, CreadoPor, IdRutaCompuesta, IdCotizacion, IdCotizacionValorHistorico, Consecutivo,
				Concepto, IncDec, PrecioNeto, CargosAdicionales, CargosAdicionalesDlls, TotalFlete, Grupo, Consolidar, FolioConsolidar, 
				FleteMN,FleteDLLS,PrecioSugerido,
				KMTotalRuta,
				TotalCasetas,
				UtilidadRuta,
				Especializado,
				Posicionamiento,
				CostoDobleOP,
				FleteMnOriginal,
				AuxCostoKilometro ) 
				VALUES (@COL_IdCotizacionRuta, @ModificadoEl, @ModificadoPor, @COL_IdRutaCompuesta,
				@IdCotizacion, @IdRetornoCotizacion, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales, @COL_CargosAdicionalesDlls, @COL_TotalFlete, @COL_Grupo, @COL_Consolidar, @COL_FolioConsolidar,
				@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xCostoKilometro)

				SET @IdRetornoCotizacionRuta = (SELECT IDENT_CURRENT('ProCotizacionesRutasValorHistorico'))
			
				BEGIN --Se agregan los cargos adicionales por cada ruta de la cotizacion
					INSERT INTO ProCotizacionesRutasCargosAdicionalesValorHistorico (IdCotizacionRutaCargoAdicional, CreadoEl, CreadoPor, IdCotizacionRuta, IdCotizacionRutaValorHistorico,
					IdConceptoFacturacion, Cantidad, PrecioUnitario, Importe) 
					SELECT IdCotizacionRutaCargoAdicional, @ModificadoEl, @ModificadoPor, @COL_IdCotizacionRuta, @IdRetornoCotizacionRuta, IdConceptoFacturacion, Cantidad, PrecioUnitario, 
					Importe FROM ProCotizacionesRutasCargosAdicionales WHERE IdCotizacionRuta = @COL_IdCotizacionRuta
				END

				FETCH NEXT FROM CursorProCotizacionesRutasHistorico
				INTO @COL_IdCotizacionRuta, @COL_IdRutaCompuesta, @COL_Consecutivo, @COL_Concepto, @COL_IncDec, @COL_PrecioNeto, @COL_CargosAdicionales, 
				@COL_CargosAdicionalesDlls, @COL_TotalFlete, @COL_Grupo, @COL_Consolidar, @COL_FolioConsolidar,@COL_FleteMN,@COL_FleteDLLS,@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xCostoKilometro
			END

			CLOSE CursorProCotizacionesRutasHistorico
			DEALLOCATE CursorProCotizacionesRutasHistorico
		END
		SELECT @AgregarValorHistorico
		COMMIT
	END
	
END TRY
BEGIN CATCH
	IF (SELECT CURSOR_STATUS('global','CursorCatRutasCompuestas')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('global','CursorCatRutasCompuestas')) > -1
			BEGIN
				CLOSE CursorCatRutasCompuestas
			END
		DEALLOCATE CursorCatRutasCompuestas
	END

	IF (SELECT CURSOR_STATUS('global','CursorProCotizacionCargosAdicionalesRuta')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('global','CursorProCotizacionCargosAdicionalesRuta')) > -1
			BEGIN
				CLOSE CursorProCotizacionCargosAdicionalesRuta
			END
		DEALLOCATE CursorProCotizacionCargosAdicionalesRuta
	END

	IF (SELECT CURSOR_STATUS('global','CursorProCotizacionesRutasHistorico')) >= -1
		BEGIN
			IF (SELECT CURSOR_STATUS('global','CursorProCotizacionesRutasHistorico')) > -1
			BEGIN
				CLOSE CursorProCotizacionesRutasHistorico
			END
		DEALLOCATE CursorProCotizacionesRutasHistorico
	END

	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

