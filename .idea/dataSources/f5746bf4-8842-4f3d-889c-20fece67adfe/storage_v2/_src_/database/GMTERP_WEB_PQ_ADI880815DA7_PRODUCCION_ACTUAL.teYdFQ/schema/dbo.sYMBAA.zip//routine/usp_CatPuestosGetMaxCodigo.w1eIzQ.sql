CREATE PROCEDURE [dbo].[usp_CatPuestosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatPuestos
go

