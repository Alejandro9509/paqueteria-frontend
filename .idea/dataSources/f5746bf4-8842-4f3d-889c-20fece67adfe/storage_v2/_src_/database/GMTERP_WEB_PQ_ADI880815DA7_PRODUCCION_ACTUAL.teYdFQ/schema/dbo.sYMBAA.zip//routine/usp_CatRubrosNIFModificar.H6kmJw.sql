

CREATE  PROCEDURE [dbo].[usp_CatRubrosNIFModificar]
@IdRubroNIF	int,
@Tipo	int,		
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@Tipo,0) = 0
	SET  @Tipo  = NULL
			
	UPDATE CatRubrosNIF SET
		Tipo = @Tipo,
		ModificadoEl= @ModificadoEl,
		ModificadoPor= @ModificadoPor
	WHERE 	IdRubroNIF	= @IdRubroNIF	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

