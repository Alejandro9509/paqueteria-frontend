Create PROCEDURE [dbo].[usp_CatLayoutsCargasAutopistaEliminar]
@IdCatLayoutCargaAutopista int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdCatLayoutCargaAutopista,0)= 0
		   RAISERROR(N'El identificador es un campo requerido',
					16,
					1
					)
		
		DELETE CatLayoutsCargasAutopista	
		WHERE 	IdLayoutCargaAutopista = @IdCatLayoutCargaAutopista
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

