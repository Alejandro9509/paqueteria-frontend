Create PROCEDURE [dbo].[usp_CatFormulasNominasEliminar]
@IdFormulaNomina int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdFormulaNomina,0)= 0
	RAISERROR(N'El identificador de la formula es un campo requerido',
			16,
			1
			)
			
		DELETE CatFormulasNominas
		WHERE 	IdFormulaNomina=@IdFormulaNomina
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

