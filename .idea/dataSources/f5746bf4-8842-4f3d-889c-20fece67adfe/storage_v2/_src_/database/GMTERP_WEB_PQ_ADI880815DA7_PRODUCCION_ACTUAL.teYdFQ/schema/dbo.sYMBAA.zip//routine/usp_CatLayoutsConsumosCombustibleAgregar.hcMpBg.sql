CREATE PROCEDURE [dbo].[usp_CatLayoutsConsumosCombustibleAgregar]
	@Layout	varchar(50),
	@TipoArchivo tinyint,
	@Separador	varchar(1),
	@RenglonInicial	tinyint,
	@ColumnaNumeroComprobante tinyint,
	@ColumnaTarjeta	tinyint,
	@FechaHoraJuntas bit,
	@ColumnaFechaHora tinyint,
	@FormatoFechaHora	varchar(26),
	@ColumnaFecha	tinyint,
	@FormatoFecha	varchar(15),
	@ColumnaHora	tinyint,
	@FormatoHora	varchar(15),
	@ColumnaLitros	tinyint,
	@TieneColumnaImporteIVA bit,
	@ColumnaImporteIVA	tinyint,
	@ColumnaTotal	tinyint,
	@ColumnaOdometro tinyint,
	@CreadoEl	datetime,
	@CreadoPor	int,
	@IdPeticion varchar(100),
	@MillasGalonesDolares bit
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
	
		INSERT INTO CatLayoutsConsumosCombustible(Layout,TipoArchivo,Separador,RenglonInicial,ColumnaNumeroComprobante,
		ColumnaTarjeta,FechaHoraJuntas,ColumnaFechaHora,FormatoFechaHora,ColumnaFecha,FormatoFecha,ColumnaHora,
		FormatoHora,ColumnaLitros,TieneColumnaImporteIVA,ColumnaImporteIVA,ColumnaTotal,ColumnaOdometro,CreadoEl,CreadoPor,MillasGalonesDolares)
		VALUES(@Layout,@TipoArchivo,@Separador,@RenglonInicial,@ColumnaNumeroComprobante,
		@ColumnaTarjeta,@FechaHoraJuntas,@ColumnaFechaHora,@FormatoFechaHora,@ColumnaFecha,@FormatoFecha,@ColumnaHora,
		@FormatoHora,@ColumnaLitros,@TieneColumnaImporteIVA,@ColumnaImporteIVA,@ColumnaTotal,@ColumnaOdometro,@CreadoEl,@CreadoPor,@MillasGalonesDolares)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

