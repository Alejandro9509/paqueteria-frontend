CREATE PROCEDURE [dbo].[usp_ProNominasDiasHorasModificar]
	@IdPeticion varchar(100),
	@IdEmpleado int, 
	@xmlIncedenciaValor ntext, 
	@Fecha date,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@TipoIncidencia int,
	@IdProNominaReciboIncapacidades int,
	@IdPeriodoActual int,
	@IdNominaReciboVacaciones int
AS
DECLARE 
	@HorasTurno decimal(15,2),	
	@docHandle int,
	@IdTipoIncidenciaCursor int,
	@ValorCursor decimal(15,2),
	@IdNominaDiaHoraCursor int,
	@EstadoCursor varchar(40),
	@FechaFinal  datetime,
	@FechaRepetida datetime,
	@FechaCursor datetime,
	@IdPeriodoCursor int

/****
 Modifico: Raymundo Esoinoza Garcia
 Fecha: 07/Feb/2020 
 Motivo: Cursor no coincidia en alguna letras, provocaba mal funcionamiento
***/

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdProNominaReciboIncapacidades,0) = 0 
		SET @IdProNominaReciboIncapacidades = NULL 

	IF ISNULL(@IdNominaReciboVacaciones,0) = 0 
		SET @IdNominaReciboVacaciones = NULL
		
	IF @IdPeriodoActual = 0
		RAISERROR(N'El periodo es un campo requerido',
			16,
			1
			)

	IF @xmlIncedenciaValor IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlIncedenciaValor

			SELECT ATT_IdTipoIncidencia,ATT_IdNominaDiaHora,ATT_Estado,ATT_Fecha,ATT_IdPeriodo
			INTO #TempProNominasDIasHoras
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNominasDIasHoras',2) 
			WITH (ATT_IdTipoIncidencia int,ATT_IdNominaDiaHora int,ATT_Estado varchar (40),ATT_Fecha datetime,ATT_IdPeriodo int)

			EXEC sp_xml_removedocument @docHandle


			DECLARE ProNominasDIasHorasCursor CURSOR FOR
			SELECT * FROM #TempProNominasDIasHoras
			
			OPEN ProNominasDIasHorasCursor
			FETCH NEXT FROM ProNominasDIasHorasCursor
			INTO @IdTipoIncidenciaCursor,@IdNominaDiaHoraCursor,@EstadoCursor,@FechaCursor,@IdPeriodoCursor
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @IdNominaDiaHoraCursor = 0 
				BEGIN 
				IF EXISTS (SELECT TOP 1 Fecha FROM ProNominasDiasHoras WHERE IdEmpleado = @IdEmpleado AND Fecha = @FechaCursor)
				BEGIN
					RAISERROR(N'Ya existen movimientos registrados para esta fecha',
					16,
					1
					)
				END
				ELSE
				BEGIN
					INSERT INTO ProNominasDiasHoras (IdEmpleado,IdPeriodo,IdTipoIncidencia,Fecha,Valor,Estado,CreadoPor,CreadoEl,IdProNominaReciboIncapacidades,IdNominaReciboVacaciones) 
					VALUES(@IdEmpleado,@IdPeriodoCursor,@IdTipoIncidenciaCursor,@FechaCursor,1,@EstadoCursor,@ModificadoPor,@ModificadoEl,@IdProNominaReciboIncapacidades,@IdNominaReciboVacaciones)
				END
				END 
				ELSE 
				BEGIN 
					UPDATE ProNominasDiasHoras                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
					SET	
					IdTipoIncidencia = @IdTipoIncidenciaCursor,
					Estado = @EstadoCursor,
					ModificadoPor = @ModificadoPor,
					ModificadoEl = @ModificadoEl
					WHERE IdNominaDiaHora = @IdNominaDiaHoraCursor 
				END
				FETCH NEXT FROM ProNominasDIasHorasCursor
				INTO @IdTipoIncidenciaCursor,@IdNominaDiaHoraCursor,@EstadoCursor,@FechaCursor,@IdPeriodoCursor
				END
				CLOSE ProNominasDIasHorasCursor
				DEALLOCATE ProNominasDIasHorasCursor
			END
			
			IF @IdProNominaReciboIncapacidades IS NOT NULL
			BEGIN 
				DELETE FROM ProNominasDiasHoras WHERE IdProNominaReciboIncapacidades = @IdProNominaReciboIncapacidades AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
			END 
			IF @IdNominaReciboVacaciones IS NOT NULL 
			BEGIN 
				DELETE FROM ProNominasDiasHoras WHERE IdNominaReciboVacaciones = @IdNominaReciboVacaciones AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
			END 
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

