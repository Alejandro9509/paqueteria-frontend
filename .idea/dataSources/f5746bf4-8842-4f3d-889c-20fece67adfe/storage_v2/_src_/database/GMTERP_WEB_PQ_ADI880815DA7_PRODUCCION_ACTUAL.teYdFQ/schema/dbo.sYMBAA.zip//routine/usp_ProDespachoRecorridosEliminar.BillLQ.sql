CREATE PROCEDURE [dbo].[usp_ProDespachoRecorridosEliminar]
	@IdRecorridoDespacho int,
	@IdPeticion varchar(100)
AS
DECLARE
	@IdFolio int
BEGIN TRY
	BEGIN TRANSACTION	
	
	
	IF ISNULL(@IdRecorridoDespacho,0) <= 0
		RAISERROR(N'El identificador del recorrido es un campo requerido.',
			16,
			1
			)	
				
	
	IF EXISTS(SELECT IdRecorridoDespacho FROM ProRecorridosDespacho WHERE IdRecorridoDespacho= @IdRecorridoDespacho AND FechaSalida IS NOT NULL)
		RAISERROR(N'No se puede eliminar el recorrido porque ya tiene una salida.',
			16,
			1
			)
			

	IF NOT EXISTS(SELECT IdRecorridoDespacho FROM ProRecorridosDespacho WHERE IdRecorridoDespacho= @IdRecorridoDespacho)
		RAISERROR(N'El recorrido fue eliminado por otro usuario.',
			16,
			1
			)             

	--Eliminamos de DespachoRecorrido
	Delete From ProRecorridosDespacho where IdRecorridoDespacho = @IdRecorridoDespacho



	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

