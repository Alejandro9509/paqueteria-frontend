
Create PROCEDURE [dbo].[usp_CatRutasTrayectosGetMaxSecuencia]
	@IdRuta	int
AS
Select Isnull(Max(Secuencia),0) as Secuencia from CatRutasTrayectos Where IdRuta = @IdRuta
go

