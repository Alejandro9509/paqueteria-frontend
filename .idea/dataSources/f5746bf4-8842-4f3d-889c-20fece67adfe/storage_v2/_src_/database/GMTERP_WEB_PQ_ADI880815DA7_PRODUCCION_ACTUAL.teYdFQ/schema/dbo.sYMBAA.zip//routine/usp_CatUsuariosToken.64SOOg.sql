CREATE PROCEDURE [dbo].[usp_CatUsuariosToken]
	@IdUsuario int ,	
	@Token varchar(max) = NULL,
	@TipoServicio tinyint,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

		UPDATE CatUsuarios SET
		Token = @Token,
		TokenIOS = @Token,
		TipoServicio = @TipoServicio
		WHERE IdUsuario = @IdUsuario

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

