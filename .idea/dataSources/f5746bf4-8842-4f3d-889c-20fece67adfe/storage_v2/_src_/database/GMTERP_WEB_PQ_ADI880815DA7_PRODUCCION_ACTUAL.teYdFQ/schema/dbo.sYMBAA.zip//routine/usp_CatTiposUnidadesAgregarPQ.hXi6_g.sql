
CREATE PROCEDURE [dbo].[usp_CatTiposUnidadesAgregarPQ](
	@TipoUnidad varchar(50),
	@CreadoEl datetime,
	@CreadoPor int ,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@TarifaPorKMS Money,
	@TarifaPorKMSDlls Money)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@TipoUnidad, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre del tipo de unidad es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@TarifaPorKMS, '') = '' begin
			RAISERROR(N'*INICIO*Trifa por kms sistema es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@TarifaPorKMSDlls , '') = '' begin
			RAISERROR(N'*INICIO*Tarifa por kms en dolares es un campo requerido*FIN*', 16, 1)
			return
		end 
		
		INSERT INTO CatTiposUnidades(TipoUnidad,CreadoEl,CreadoPor,ModificadoEl,ModificadoPor,TarifaPorKMS,TarifaPorKMSDlls)
		VALUES (@TipoUnidad,@CreadoEl,@CreadoPor,@ModificadoEl,@ModificadoPor,@TarifaPorKMS,@TarifaPorKMSDlls)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

