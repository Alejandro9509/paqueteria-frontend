
CREATE PROCEDURE [dbo].[usp_ProAnticiposTPersonalGetMaxFolio]
AS
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProAnticiposTPersonal
go

