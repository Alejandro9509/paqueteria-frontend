CREATE PROCEDURE [dbo].[usp_CatLayoutsCargasCombustibleAgregar]
	@Layout	varchar(50),
	@TipoArchivo tinyint,
	@Separador	varchar(1),
	@RenglonInicial	tinyint,
	@ColumnaKmECM Varchar(150),
    @ColumnaLtsECM Varchar(150),
    @ColumnaLtsRalenti Varchar(150),
    @ColumnasPorcLtsRalenti Varchar(150),
    @ColumnaLtsAutRalenti Varchar(150),
    @ColumnaLtsExcedidos Varchar(150),
    @ColumnaRendimientoECM Varchar(150),
    @ColumnaPorcUltimoCambio Varchar(150),
    @ColumnaPorcPenultimoCambio Varchar(150),
    @ColumnaVelocidadMaxMotor Varchar(150),
    @ColumnaVelocidadMaxUnidad Varchar(150),
    @ColumnaPorcVelMaxUnidad Varchar(150),
    @ColumnaTiempoVelocudadMaxUnidad Varchar(150),
    @ColumnaVelocidadPromedio Varchar(150),
    @ColumnaNeutralizaciones Varchar(150),
    @ColumnaFrenadosBruscos Varchar(150),
    @ColumnaCargaDeAceleracion Varchar(150),
    @ColumnaAccionamientoPedalDeFreno Varchar(150),
	@CreadoEl	datetime,
	@CreadoPor	int,
	@IdPeticion varchar(100),
	@ColumnaContineValor int,
	@ColumnaUnidad varchar(150),
	@ColumnaFechaReseteo Varchar(150)
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
	
		INSERT INTO CatLayoutsCargasCombustible(Layout,TipoArchivo,Separador,RenglonInicial,ColumnaKmECM
      ,ColumnaLtsECM
      ,ColumnaLtsRalenti
      ,ColumnasPorcLtsRalenti
      ,ColumnaLtsAutRalenti
      ,ColumnaLtsExcedidos
      ,ColumnaRendimientoECM
      ,ColumnaPorcUltimoCambio
      ,ColumnaPorcPenultimoCambio
      ,ColumnaVelocidadMaxMotor
      ,ColumnaVelocidadMaxUnidad
      ,ColumnaPorcVelMaxUnidad
      ,ColumnaTiempoVelocudadMaxUnidad
      ,ColumnaVelocidadPromedio
      ,ColumnaNeutralizaciones
      ,ColumnaFrenadosBruscos
      ,ColumnaCargaDeAceleracion
      ,ColumnaAccionamientoPedalDeFreno,CreadoEl,CreadoPor,ColumnaContineValor,ColumnaUnidad,ColumnaFechaReseteo)
		VALUES(@Layout,@TipoArchivo,@Separador,@RenglonInicial,@ColumnaKmECM
      ,@ColumnaLtsECM
      ,@ColumnaLtsRalenti
      ,@ColumnasPorcLtsRalenti
      ,@ColumnaLtsAutRalenti
      ,@ColumnaLtsExcedidos
      ,@ColumnaRendimientoECM
      ,@ColumnaPorcUltimoCambio
      ,@ColumnaPorcPenultimoCambio
      ,@ColumnaVelocidadMaxMotor
      ,@ColumnaVelocidadMaxUnidad
      ,@ColumnaPorcVelMaxUnidad
      ,@ColumnaTiempoVelocudadMaxUnidad
      ,@ColumnaVelocidadPromedio
      ,@ColumnaNeutralizaciones
      ,@ColumnaFrenadosBruscos
      ,@ColumnaCargaDeAceleracion
      ,@ColumnaAccionamientoPedalDeFreno,@CreadoEl,@CreadoPor,@ColumnaContineValor,@ColumnaUnidad,@ColumnaFechaReseteo)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

