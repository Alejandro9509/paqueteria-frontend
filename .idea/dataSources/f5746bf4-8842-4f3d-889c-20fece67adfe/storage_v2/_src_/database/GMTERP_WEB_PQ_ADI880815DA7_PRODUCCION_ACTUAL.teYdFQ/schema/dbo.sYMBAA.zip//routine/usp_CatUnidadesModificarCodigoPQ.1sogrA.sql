
CREATE PROCEDURE [dbo].[usp_CatUnidadesModificarCodigoPQ](
	@IdUnidad int,
	@Codigo varchar(16)
	)
	AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdUnidad, 0) <= 0 BEGIN
			RAISERROR(N'*INICIO*El id del cliente es campo requerido*FIN*', 16, 1)
			RETURN
		END
		IF ISNULL(@Codigo, '') = '' BEGIN
			RAISERROR(N'*INICIO*El nombre del cliente es un campo requerido*FIN*', 16, 1)
			RETURN
		END 
		
		
		UPDATE CatUnidades SET
		Codigo=@Codigo 
		WHERE IdUnidad = @IdUnidad
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

