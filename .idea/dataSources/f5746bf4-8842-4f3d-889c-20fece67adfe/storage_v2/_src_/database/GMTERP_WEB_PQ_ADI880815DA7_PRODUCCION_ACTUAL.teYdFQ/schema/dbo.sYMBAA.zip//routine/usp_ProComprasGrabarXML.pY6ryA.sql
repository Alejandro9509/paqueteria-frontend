CREATE PROCEDURE [dbo].[usp_ProComprasGrabarXML]
	@IdCompra int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@XMLArchivo ntext,
	@FolioFiscalUUID varchar(36)
AS
DECLARE
	@FolioCompraError int,
	@MensajeError varchar(200)
BEGIN TRY
	BEGIN TRANSACTION
	
	  IF ISNULL(@IdCompra,0) = 0
			RAISERROR(N'El identificador de la compra es un campo requerido',
				16,
				1
				)

	  IF (SELECT ModificadoEl FROM ProCompras WHERE IdCompra = @IdCompra) <> @UltimaModificacion
		    RAISERROR(N'Este registro fue modificado por otro usuario',
			   16,
			   1
			   )	


	  IF (Select CanceladoEl from ProCompras where IdCompra = @IdCompra) IS Not NULL
		   RAISERROR(N'La Compra esta cancelada',
			  16,
			  1
			  )
			   		  

	  IF ISNULL(@FolioFiscalUUID,'') = ''
			RAISERROR(N'El Folio Fiscal UUID es un campo  requerido',
				16,
				1
				)

	--SE VALIDA SI EL FOLIO FISCAL NO EXISTA EN UNA COMPRA VIGENTE(NO CANCELADO) YA REGISTRADO	
	  SET @FolioCompraError = (SELECT Folio FROM ProCompras WHERE FolioFiscalUUID = @FolioFiscalUUID AND CanceladoEl IS NULL)
	  IF @FolioCompraError IS NOT NULL
		BEGIN
			 SET @MensajeError = 'La Compra con el Folio '+CAST(@FolioCompraError as varchar)+' tiene registrado el Folio Fiscal UUID que intenta agregar'

			  RAISERROR(@MensajeError,
				16,
				1
				)		
	    END


	--SE VALIDA SI EL FOLIO FISCAL NO EXISTA EN UNA COMPRA VIGENTE(NO CANCELADO) YA REGISTRADO	
	IF ISNULL((SELECT FolioFiscalUUID FROM ProCompras WHERE IdCompra = @IdCompra),'') <>''
			RAISERROR(N'La compra ya tiene Folio Fiscal UUID',
				16,
				1
				)
				
				
		--SE VALIDA SI LA COMPRA TIENE UN PASIVO LIGADO
	IF ISNULL((SELECT FolioPasivo FROM ProPasivos WHERE IdCompra = @IdCompra AND CanceladoEl IS NULL),0) <> 0
			RAISERROR(N'La compra tiene un pasivo ligado',
				16,
				1
				)
	

	 



	
	  UPDATE ProCompras SET
				ModificadoPor = @ModificadoPor,
				ModificadoEl = @ModificadoEl,
				XMLArchivo = @XMLArchivo, 
	            FolioFiscalUUID = @FolioFiscalUUID
	  WHERE IdCompra = @IdCompra
		


	COMMIT

END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

