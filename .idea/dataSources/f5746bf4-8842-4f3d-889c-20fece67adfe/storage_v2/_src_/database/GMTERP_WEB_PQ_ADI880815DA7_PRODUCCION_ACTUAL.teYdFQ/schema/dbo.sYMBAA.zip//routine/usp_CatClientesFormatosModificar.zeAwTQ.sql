CREATE PROCEDURE [dbo].[usp_CatClientesFormatosModificar]
	@IdClienteFormato int,
	@IdCliente int,
	@IdFormato int,
	@Marcado bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	IF @IdClienteFormato = 0
		RAISERROR(N'El identificador del es un campo requerido',
			16,
			1
			)

	IF @IdCliente = 0
		RAISERROR(N'El identificador del cliente es un campo requerido',
			16,
			1
			)

	IF @IdFormato = 0
		RAISERROR(N'El identificador del formato es un campo requerido',
			16,
			1
			)
			
	UPDATE CatClientesFormatos SET 
	IdCliente = @IdCliente,
	IdFormato = @IdFormato,
	Marcado = @Marcado,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl
	WHERE IdClienteFormato = @IdClienteFormato
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

