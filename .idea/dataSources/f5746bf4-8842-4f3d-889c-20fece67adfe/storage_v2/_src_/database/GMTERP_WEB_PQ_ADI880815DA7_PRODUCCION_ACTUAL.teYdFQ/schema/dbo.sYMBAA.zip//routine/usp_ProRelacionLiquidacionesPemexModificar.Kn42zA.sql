
CREATE PROC [dbo].[usp_ProRelacionLiquidacionesPemexModificar]
	@IdRelacionLiquidacionPemex int,
    @Anio int,
    @NoRelacion int,
    @FechaCreacion datetime,
    @IdCliente int,
    @IdCombustible int,
    @TipoTanque int,
	@VeinteMovs bit,
	@IdOrigenes varchar(500),
    @ModificadoEl datetime,
    @ModificadoPor int,
    @ViajesXML ntext = NULL,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_ProRelacionLiquidacionesPemexModificar

Parámetros:
	@IdRelacionLiquidacionPemex    (entrada, entero). Id de la Relación Liquidación PEMEX.
    @Anio                          (entrada, entero). Año del número relación de la liquidación PEMEX.
    @NoRelacion                    (entrada, entero). Número relación de la liquidación PEMEX.
    @FechaCreacion				   (entrada, fecha hora). Fecha y hora en que fue creado la relación liquidación PEMEX.
    @IdCliente					   (entrada, entero). Identificador del cliente.
    @IdCombustible				   (entrada, entero). Identificador del combustible.
    @TipoTanque					   (entrada, entero). Indica el tipo de tanque de la relación liquidación PEMEX.
	@VeinteMovs                    (entrada, booleano). Indica si la relación filtró únicamente 20 cartas porte.
	@IdOrigenes                    (entrada, texto). Son los Id de los Orígenes por los que filtró las carta porte.
    @ModificadoEl				   (entrada, fecha hora). Fecha y hora en la que fue modificado el registro.
    @ModificadoPor				   (entrada, entero). Id del usuario que modifico el registro.
    @ViajesXML			           (entrada, xml). XML que contiene la información de los viajes.
    @IdPeticion				       (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para modificar una nueva Relación Liquidación PEMEX.

05/03/2020 - Se creó.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 05/03/2020
Versión ERP: 8.0.50.31

Invocada desde: PAGE_ProRelacionLiquidacionPemexAMC (Solicitud 921)
***************************************************************************************************** */
AS
DECLARE
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION
    -- Validaciones
	IF @IdRelacionLiquidacionPemex = 0
		RAISERROR(N'El Id de la relación de liquidación es un campo requerido', 16, 1)

    IF @Anio = 0
        RAISERROR(N'El número de relación es un campo requerido', 16, 1)

    IF @NoRelacion = 0
        RAISERROR(N'El número de relación es un campo requerido', 16, 1)

    IF @IdCliente = 0
        RAISERROR(N'El id de cliente es un campo obligatorio', 16, 1)

    IF @IdCombustible = 0
        RAISERROR(N'El id del tipo de material es un campo obligatorio', 16, 1)

	-- Modifica el registro en la tabla principal de la relación PEMEX
	UPDATE ProRelacionLiquidacionesPemex SET 
	Anio = @Anio,
	NoRelacion = @NoRelacion,
	FechaCreacion = @FechaCreacion,
	IdCliente = @IdCliente,
	IdCombustible = @IdCombustible,
	TipoTanque = @TipoTanque,
	VeinteMovs = @VeinteMovs,
	IdOrigenes = @IdOrigenes,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor
	WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex

    -- Extrae información del XML y la almacena en una tabla temporal
    EXEC sp_xml_preparedocument @docHandle OUTPUT, @ViajesXML

    -- Se crea tabla temporal que guardará la información de los viajes
    SELECT ATT_IdViajeCartaPorteConocimientoEmbarque, ATT_IdViajeCartaPorte, ATT_IdViaje, ATT_FolioViaje, ATT_Fecha, ATT_Destino, ATT_NoEmbarque, ATT_Secuencia
    INTO #TempProRelacionLiquidacionesPemex
    FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProRelacionLiquidacionesPemex', 2)
    WITH (ATT_IdViajeCartaPorteConocimientoEmbarque int,
			ATT_IdViajeCartaPorte int,
			ATT_IdViaje int,
			ATT_FolioViaje int,
			ATT_Fecha datetime,
			ATT_Destino varchar(50),
			ATT_NoEmbarque int,
			ATT_Secuencia INT)

    -- Valida que las carta porte no estén canceladas
    IF EXISTS(SELECT IdViaje FROM ProViajes INNER JOIN #TempProRelacionLiquidacionesPemex ON IdViaje = ATT_IdViaje WHERE CanceladoEl != NULL)
        RAISERROR(N'Algunas de las cartas porte seleccionadas están canceladas, favor de revisar', 16, 1)

    -- Elimina todos los registros relacionados con esa Relación 
	DELETE FROM ProRelacionLiquidacionesPemexDetalle WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex

	-- Vuelve a insertar los valores a la tabla 
    INSERT INTO ProRelacionLiquidacionesPemexDetalle(IdRelacionLiquidacionPemex, IdViajeCartaPorteConocimientoEmbarque, IdViaje, IdViajeCartaPorte, FolioViaje, Fecha, Destino, NoEmbarque, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor, CanceladoEl, CanceladoPor, Secuencia)
    SELECT @IdRelacionLiquidacionPemex, ATT_IdViajeCartaPorteConocimientoEmbarque, ATT_IdViaje, ATT_IdViajeCartaPorte, ATT_FolioViaje, ATT_Fecha, ATT_Destino, ATT_NoEmbarque, @ModificadoEl, @ModificadoPor, @ModificadoEl, @ModificadoPor, NULL, NULL, ATT_Secuencia 
    FROM #TempProRelacionLiquidacionesPemex

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

