CREATE PROCEDURE [dbo].[usp_CatUnidadesImagenesAgregar]
	@IdUnidad int,
	@dsCatUnidadesImagenes XML,
	@IdPeticion varchar(100)
	/* *************************************************************************************************
	Procedimiento usp_CatUnidadesImagenesAgregar

	Parámetros: 
		@IdUnidad int,
		@dsCatUnidadesImagenes XML,
		@IdPeticion varchar(100)

	Descripción: Agrega datos del los documentos a la base de datos

	Implementada por: Enrique 
	Fecha de implementacion:  06/02/2020
	Versión: 8.0.49.14

	Modificado por: Enrique 
	Fecha de implementacion:  25/02/2020
	Versión: 8.0.50.14
	--Se agrego update para evitar guardar la variable del obs como 1 si esta en disco 
	Invocada desde: CatUnidadesAM, ClsCatUnidades
	***************************************************************************************************** */


AS
DECLARE @TemporalXML TABLE
(	
NombreArchivo varchar(300) ,
DescripcionArchivo varchar(150),
Obs bit 
)

BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdUnidad,0) = 0
		RAISERROR(N'Identificador del operador es un campo requerido',
			16,
			1
			)

INSERT INTO @TemporalXML (NombreArchivo,DescripcionArchivo,Obs)
Select  
 NombreArchivo = Node.Data.value('(ATT_ImagenNombreArchivo)[1]', 'VARCHAR(MAX)')
,DescripcionArchivo =Node.Data.value('(ATT_Descripcion)[1]', 'VARCHAR(MAX)') 
,Obs =Node.Data.value('(ATT_Obs)[1]', 'BIT') 
FROM   @dsCatUnidadesImagenes.nodes('/WEBDEV_TABLE/Imagenes') Node(Data) 
Update @TemporalXML
set Obs = 1
where NombreArchivo like '%GMTRPV8/Permanentes%'
Update @TemporalXML
set Obs = 0
where NombreArchivo not like '%GMTRPV8/Permanentes%'
DELETE FROM CatUnidadesImagenes WHERE IdUnidad = @IdUnidad

INSERT into CatUnidadesImagenes(IdUnidad,ImagenNombreArchivo,Descripcion,Obs) 
Select  

@IdUnidad,
NombreArchivo
,DescripcionArchivo 
,Obs
FROM @TemporalXML

COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

