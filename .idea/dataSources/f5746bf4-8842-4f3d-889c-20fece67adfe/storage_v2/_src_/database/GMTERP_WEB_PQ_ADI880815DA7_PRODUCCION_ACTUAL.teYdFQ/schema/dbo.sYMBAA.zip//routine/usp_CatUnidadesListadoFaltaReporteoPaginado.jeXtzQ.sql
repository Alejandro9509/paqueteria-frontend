
	CREATE PROCEDURE [dbo].[usp_CatUnidadesListadoFaltaReporteoPaginado]
	@dsCatUnidadesListadoFaltaReporteo ntext,
	@IdUsuario int,
	@Pagina int, 
	@Elemento int,
	@FechaHoraSucursal datetime,
	@Ordenamiento varchar(100),
	@IdPeticion varchar(100)   
	AS
	DECLARE
	@docHandle int,
	@AplicarFiltroGrupoUnidades bit = 1,--bandera para aplicar filtro en el query
	@FiltrarPorGrupoUnidadesParametro bit = ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'FiltrarPorGrupoUnidades'),0)--valor del parametro
		
	CREATE TABLE #CatUnidadesListadoFaltaReporteo([Unidad] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,
		[NoSerie] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,
		[FechaHoraUTCPaquete] datetime,
		[TiempoReporte] int,
		[IconoWEB] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
		[DescripcionEvento] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL
		);

	BEGIN TRANSACTION
	BEGIN TRY
		IF ISNULL(@IdUsuario,0) = 0
		RAISERROR(N'El idusuario es un parámetro requerido',
		16,
		1
		)

		IF ISNULL(CAST(@dsCatUnidadesListadoFaltaReporteo AS VARCHAR(MAX)),'') = ''
		RAISERROR(N'El xml de ubicaciones es un parámetro requerido',
		16,
		1
		)
			
		--SE EVALUA CRITERIOS PARA APLICAR FILTRO DE GRUPOS DE UNIDADES
		IF EXISTS(SELECT * FROM CatUsuarios AS cu WHERE cu.IdUsuario = @IdUsuario AND cu.TipoUsuario IN(1,5)) OR @FiltrarPorGrupoUnidadesParametro = 0
		BEGIN
			SET @AplicarFiltroGrupoUnidades = 0
		END
		
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUnidadesListadoFaltaReporteo

		INSERT INTO #CatUnidadesListadoFaltaReporteo([Unidad],
		[NoSerie],
		[FechaHoraUTCPaquete],
		[TiempoReporte],
		[IconoWEB],
		[DescripcionEvento])
		SELECT cu.Codigo,
		put.NoSerie,
		put.FechaHoraUltimoPaquete,
		put.TiempoUltimoEventoReportado,
		put.IconoWEB,
		put.DescripcionEvento
		FROM OPENXML(@docHandle, N'/Markers/Marker',2) 
		WITH (
		NoSerie varchar(150) COLLATE Modern_Spanish_CS_AS,
		FechaHoraUltimoPaquete datetime,
		TiempoUltimoEventoReportado int,
		IconoWEB varchar(50) COLLATE Modern_Spanish_CS_AS,
		DescripcionEvento varchar(50) COLLATE Modern_Spanish_CS_AS
		) AS put
		INNER JOIN CatUnidades AS cu ON put.NoSerie = cu.IdentificadorSatelital 
		INNER JOIN CatGruposUnidades AS cgu ON cu.IdGrupoUnidad = cgu.IdGrupoUnidad
		INNER JOIN CatUsuarios AS cus ON cus.IdUsuario = @IdUsuario
		WHERE cu.IdentificadorSatelital IS NOT NULL AND  cu.IdentificadorSatelital <> '' AND
		(
		(cu.IdGrupoUnidad IN(SELECT IdGrupoUnidad 
		FROM CatGruposUnidadesUsuarios AS cguu 
		WHERE cguu.IdUsuario = @IdUsuario) AND @AplicarFiltroGrupoUnidades = 1)
		OR @AplicarFiltroGrupoUnidades = 0
		)
		AND cu.Activa = 1
		AND ((cus.TipoUsuario = 5 AND cu.IdUnidad IN(SELECT cueu.IdUnidad 
		FROM CatUsuariosEspejosUnidades  AS cueu 
		WHERE cueu.IdUsuarioEspejo = @IdUsuario AND cueu.FechaVencimiento > @FechaHoraSucursal)) 
		OR(cus.TipoUsuario != 5) )

		EXEC sp_xml_removedocument @docHandle;


		;With Listado as (select 
		case LTRIM(RTRIM(@Ordenamiento))
		when 'ub.DescripcionEvento ASC' THEN ROW_NUMBER() OVER (ORDER BY ub.DescripcionEvento ASC)
		when 'ub.DescripcionEvento DESC' THEN ROW_NUMBER() OVER (ORDER BY ub.DescripcionEvento DESC)
		when 'ub.FechaHoraUTCPaquete ASC' THEN ROW_NUMBER() OVER (ORDER BY ub.FechaHoraUTCPaquete ASC)
		when 'ub.FechaHoraUTCPaquete DESC' THEN ROW_NUMBER() OVER (ORDER BY ub.FechaHoraUTCPaquete DESC)
		when 'ub.Unidad ASC' THEN ROW_NUMBER() OVER (ORDER BY ub.Unidad ASC)
		when 'ub.Unidad DESC' THEN ROW_NUMBER() OVER (ORDER BY ub.Unidad DESC)
		when 'ub.TiempoReporte ASC' THEN ROW_NUMBER() OVER (ORDER BY ub.TiempoReporte ASC)
		when 'ub.TiempoReporte DESC' THEN ROW_NUMBER() OVER (ORDER BY ub.TiempoReporte DESC)
		END AS rownumber,
		ub.Unidad,ub.NoSerie,ub.FechaHoraUTCPaquete,ub.TiempoReporte,ub.IconoWEB, 
		ub.DescripcionEvento FROM #CatUnidadesListadoFaltaReporteo AS ub)
		select (SELECT MAX(rownumber) FROM  Listado) AS  TotalRows,* from Listado where
		rownumber >= (CASE @Pagina   
		WHEN 1 THEN 1 
		ELSE (@Elemento*(@Pagina-1))+1   
		END)AND rownumber <= (@Elemento*@Pagina) ORDER BY rownumber

	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0  
			ROLLBACK TRANSACTION
		EXECUTE usp_SisErrorsGrabar @IdPeticion;
	END CATCH
	IF @@TRANCOUNT > 0  
		COMMIT TRANSACTION;
    go

