CREATE PROCEDURE [dbo].[usp_CatClientesAddendasCamposAdicionalesGrabar]
		@IdCliente int
	,	@IdAddenda int
	,	@Campo1 varchar(250)
	,	@Campo2 varchar(250)
	,	@Campo3 varchar(250)
	,	@Campo4 varchar(250)
	,	@Campo5 varchar(250)
	,	@Campo6 varchar(250)
	,	@Campo7 varchar(250)
	,	@Campo8 varchar(250)
	,	@Campo9 varchar(250)
	,	@Campo10 varchar(250)
	,	@IdPeticion varchar(100)
	,	@CreadoEl datetime
	,	@CreadoPor int
	,	@Activo BIT = NULL
	,	@ActivarDesactivar BIT = 0

/* *************************************************************************************************
Procedimiento usp_CatClientesAddendasCamposAdicionalesGrabar

Parámetros: 
	@IdCliente int
	@IdAddenda int
	@Campo1 varchar(250)
	@Campo2 varchar(250)
	@Campo3 varchar(250)
	@Campo4 varchar(250)
	@Campo5 varchar(250)
	@Campo6 varchar(250)
	@Campo7 varchar(250)
	@Campo8 varchar(250)
	@Campo9 varchar(250)
	@Campo10 varchar(250)
	@IdPeticion varchar(100)
	@CreadoEl datetime
	@CreadoPor int
	@Activo BIT = NULL
	@ActivarDesactivar BIT = 0


Descripción: Almacena la asignación de una addenda a un cliente con sus respectivos campos adicionales.

             
*****************************************************************************************************
Modificado por: Javier Abraham Pazos Rodriguez 
Fecha de modificación: 20/08/2021
Versión: 8.0.64.05

La modificación consiste en agregar los parámetros de Activo y ActivarDesactivar, los cuales
son para marcar el estatus de la relación addenda cliente, cuando Activo = 0 el cliente no 
puede ver ni utilizar la addenda para sus procesos de facturación.

*****************************************************************************************************


Invocado desde: PAGE_CatClientesAddendas,
				PAGE_Utilerias_Facturacion_DesactivarEliminarAddendasClientes
				ClsCatClientes
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF ISNULL(@IdAddenda,0) <= 0
			RAISERROR(N'El identificador de la addenda es un campo requerido',
				16,
				1
				)
				
		IF ISNULL(@IdCliente,0) <= 0
			RAISERROR(N'El identificador del cliente es un campo requerido',
				16,
				1
				)

	IF EXISTS(SELECT IdClienteAddendaCampoAdicional FROM CatClientesAddendasCamposAdicionales WHERE IdCliente = @IdCliente AND IdAddenda = @IdAddenda)
		BEGIN

			IF @ActivarDesactivar = 0 
				BEGIN
					UPDATE CatClientesAddendasCamposAdicionales 
						SET
							  Campo1 = @Campo1
							, Campo2 = @Campo2
							, Campo3 = @Campo3
							, Campo4 = @Campo4
							, Campo5 = @Campo5
							, Campo6 = @Campo6
							, Campo7 = @Campo7
							, Campo8 = @Campo8
							, Campo9 = @Campo9
							, Campo10 = @Campo10
							, ModificadoEl = @CreadoEl
							, ModificadoPor = @CreadoPor
							, Activo = @Activo
					WHERE IdCliente = @IdCliente 
					  AND IdAddenda = @IdAddenda
				END
			ELSE
				BEGIN
					UPDATE CatClientesAddendasCamposAdicionales 
						SET
							  ModificadoEl = @CreadoEl
							, ModificadoPor = @CreadoPor
							, Activo = @Activo
					WHERE IdCliente = @IdCliente 
					  AND IdAddenda = @IdAddenda
				END 
		END		
	ELSE
		BEGIN
			INSERT INTO CatClientesAddendasCamposAdicionales(Campo1, Campo10, Campo2, Campo3, Campo4, Campo5, Campo6, Campo7, Campo8, Campo9, IdAddenda, IdCliente, CreadoEl, CreadoPor, Activo)
				VALUES
					(@Campo1, @Campo10, @Campo2, @Campo3, @Campo4, @Campo5, @Campo6, @Campo7, @Campo8, @Campo9, @IdAddenda, @IdCliente, @CreadoEl, @CreadoPor, @Activo)
		END
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

