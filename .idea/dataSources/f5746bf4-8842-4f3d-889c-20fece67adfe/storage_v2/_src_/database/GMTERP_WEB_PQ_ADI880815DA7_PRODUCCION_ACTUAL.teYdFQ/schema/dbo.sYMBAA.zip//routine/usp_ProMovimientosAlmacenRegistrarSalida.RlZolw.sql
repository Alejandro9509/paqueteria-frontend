CREATE PROCEDURE [dbo].[usp_ProMovimientosAlmacenRegistrarSalida]
	 @Folio int ,
	 @FechaHora datetime,
	 @IdTipoMovimientoAlmacen int ,
	 @IdProveedor int ,
	 @Referencia varchar(500),
	 @Estatus tinyint,
	 @Observaciones varchar(512),
	 @CreadoEl datetime,
	 @CreadoPor int,
	 @dsProMovimientosAlmacenConceptos ntext,
	 @IdPeticion varchar(100),
	 @IdMoneda int,
	 @TipoCambio money,
	 @dsProMovimientosAlmacenDetallados ntext = NULL,
	 @IdConsumidor int = NULL,
	 @EsTraspaso bit = 0 --Si es traspaso SOL 168
	/* *************************************************************************************************
	SOLICITUD 601

	Descripcion: Se modifico el rollback para que ahora se ejecute correctamente al aplicar
	el trigger de bloqueo ubicado en ProMovimientosAlmacenConceptos
	
	Modificada por:   Amado Navarro
	Fecha de mofidicacion: 15/11/2019
	Versión: Versión 8.0.47.48

	Invocada desde: <PAGE_ProMovimientosAlmacenSalidaR, Metodo gclProMovimientosAlmacen:RegistrarMovimientoSalida > <usp_ProInventariosDeAlmacenCancelar>
	************************************************************************************************ */
	/* *************************************************************************************************
	SOLICITUD 168

	Descripcion: Se agrego para detectar si se utiliza el procedimiento desde un traspaso
	
	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 25/09/2019
	Versión: Versión 8.0.46.21

	Invocada desde: <PAGE_ProMovimientosAlmacenTraspasoR >
	************************************************************************************************ */
			/* *************************************************************************************************
	SOLICITUD 466

	Descripcion: Se modifico para funcionar con el nuevo boton de devolucion en inventario
	
	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 06/11/2019
	Versión: Versión 8.0.47.31

	Invocada desde: <PAGE_ProMovimientosAlmacenDevolucionR >
	************************************************************************************************ */
		/* *************************************************************************************************
	SOLICITUD 1160

	Descripcion: Se modifico para que las observaciones en las entradas de almacen se guarden de manera correcta
	
	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 26/03/2020
	Versión: Versión 8.0.47.31

	Invocada desde: <PAGE_ProMovimientosAlmacenSalidaR Agregar() >
	************************************************************************************************ */
AS
DECLARE
	@docHandle int,
	@FolioMovimientoAlmacen int,
	@MessageError varchar(150),
	@ExistenciaActual decimal(15,4),
	@CostoPromedioActual money,
	@ImporteTotalPromedioActual money,
	@IdMovimientoAlmacen int, 
	--@IdMoneda int,
	--@IdMovimientoAlmacenConceptoEntrada int,
	@Activo bit,
	@IdMovimientoAlmacenConceptoSalida int,
	@CostoUnitarioPEPS money,
	@Articulo varchar(100),
	@ExistenciaArticulo decimal(15,4),
	@CostoPromedioActualDlls money,
	@ImporteTotalPromedioActualDlls money,
	@ErrorMsg varchar(8000)
BEGIN TRY
	BEGIN TRANSACTION
	--SET  @IdMoneda = 1
	set @ErrorMsg  = ''
	IF isnull(@FechaHora,'') = ''			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdMoneda ,0)=0
			RAISERROR(N'La moneda es un campo requerido',
				16,
				1
				)	

	IF ISNULL(@TipoCambio,0) = 0		 
				RAISERROR(N'El tipo de cambio es un campo requerido',
					16,
					1
					)	

	IF ISNULL(@IdTipoMovimientoAlmacen,0)=0
		RAISERROR(N'El tipo de movimiento de almacén es un campo requerido',
			16,
			1
			)			
		
	IF @dsProMovimientosAlmacenConceptos IS NULL
		RAISERROR(N'Los conceptos del movimiento de almacén son requeridos',
			16,
			1
			)	

	--Se realizo la validacion para la concurrencia por parte de la solicitud 54
	IF EXISTS(SELECT Folio FROM ProMovimientosAlmacen WHERE Folio = @Folio)
	BEGIN
		RAISERROR(N'El folio ya fue utilizado por otro usuario, sé asignara un nuevo folio.',
			16,
			1
			)
	END

	IF ISNULL(@Folio,0) = 0
	SET @Folio = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)
	
	IF  ISNULL(@IdProveedor,0) = 0 
	SET @IdProveedor = NULL
	
	IF  ISNULL(@IdConsumidor,0) = 0 
	SET @IdConsumidor = NULL		
	
	INSERT INTO ProMovimientosAlmacen(Folio,
	FechaHora,IdTipoMovimientoAlmacen,IdProveedor,
	Referencia,Estatus,Observaciones,TipoCambio,IdMoneda,
	CreadoEl,CreadoPor,IdConsumidor)
	VALUES(@Folio,
	@FechaHora,@IdTipoMovimientoAlmacen,@IdProveedor,
	@Referencia,@Estatus,@Observaciones,@TipoCambio,@IdMoneda,
	@CreadoEl,@CreadoPor,@IdConsumidor)

	SET @IdMovimientoAlmacen = (SELECT IDENT_CURRENT('ProMovimientosAlmacen'))		

	--seccion para agregar el idViaje a paremtros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoAlmacenSalida' AND IdUsuario = @CreadoPor)
	INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoAlmacenSalida',@IdMovimientoAlmacen,@CreadoPor)
	ELSE
	UPDATE SisParametrosPagina SET Parametros = @IdMovimientoAlmacen WHERE Pagina = 'IdMovimientoAlmacenSalida' AND IdUsuario = @CreadoPor

	-------------------------------------------------------------------------------------------------------
	-- SECCION PARA AGREGAR LOS CONCEPTOS DE MOVIMIENTO DE SALIDA DE ALMACEN
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProMovimientosAlmacenConceptos
	SELECT  ATT_IdArticulo,ATT_IdAlmacen,ATT_Cantidad,ATT_PrecioUnitario,ATT_Importe,ATT_UnidadMedida,ATT_Observaciones,ATT_IdOrdenServicioParte
	INTO #TempProMovimientosAlmacenConceptos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProMovimientosAlmacenConceptos',2) 
	WITH (ATT_IdArticulo int,ATT_IdAlmacen int,ATT_Cantidad decimal(15,4),ATT_PrecioUnitario money,ATT_Importe money,ATT_UnidadMedida varchar(30),ATT_Observaciones varchar(256), ATT_IdOrdenServicioParte INT)
	EXEC sp_xml_removedocument @docHandle

	-- Crear cursor
	DECLARE @ATT_IdArticulo int,@ATT_IdAlmacen int,@ATT_Cantidad decimal(15,4),@ATT_PrecioUnitario money,@ATT_Importe money,@ATT_UnidadMedida varchar(30),@ATT_Observaciones varchar(256), @ATT_IdOrdenServicioParte INT
	DECLARE TempProMovimientosAlmacenConceptos CURSOR FOR 
	SELECT ATT_IdArticulo,ATT_IdAlmacen,ATT_Cantidad,ATT_PrecioUnitario,ATT_Importe,ATT_UnidadMedida,ATT_Observaciones,ATT_IdOrdenServicioParte From #TempProMovimientosAlmacenConceptos
	
	SET @MessageError=''
	
	OPEN TempProMovimientosAlmacenConceptos
	FETCH NEXT FROM TempProMovimientosAlmacenConceptos INTO 
	@ATT_IdArticulo,@ATT_IdAlmacen,@ATT_Cantidad,@ATT_PrecioUnitario,@ATT_Importe,@ATT_UnidadMedida,@ATT_Observaciones, @ATT_IdOrdenServicioParte
	
	WHILE @@fetch_status = 0
	BEGIN

	-- Consulta existencia	
	SELECT @ExistenciaArticulo = ProInventarioAlmacen.Existencia, @Articulo = CatArticulos.Articulo FROM  ProInventarioAlmacen INNER JOIN
		   CatArticulos ON ProInventarioAlmacen.IdArticulo = CatArticulos.IdArticulo
	WHERE  ProInventarioAlmacen.IdAlmacen = @ATT_IdAlmacen And ProInventarioAlmacen.IdArticulo = @ATT_IdArticulo
			
	-- Verifica existencia
	SET @MessageError =''
	IF @ATT_Cantidad > @ExistenciaArticulo
		BEGIN
		 SET @MessageError = @MessageError+ @Articulo +char(10)+' No tiene existencia suficiente' 
			 RAISERROR(@MessageError ,
			 16,
			 1
			 )					
		END

	-- Calcular costos 
			SELECT  @ExistenciaActual = Existencia ,
					@ImporteTotalPromedioActual = ImporteTotalPromedio,
					@CostoPromedioActual = CostoPromedio,
					@CostoPromedioActualDlls = CostoPromedioDlls 
			FROM ProInventarioAlmacen
			WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo			
				
			SET @ExistenciaActual = @ExistenciaActual-@ATT_Cantidad
			SET @ImporteTotalPromedioActual = @ExistenciaActual*@CostoPromedioActual
			SET @ImporteTotalPromedioActualDlls = @ExistenciaActual*@CostoPromedioActualDlls  
							
	 -- Registrar costo calculado
			UPDATE ProInventarioAlmacen
			 SET  Existencia = @ExistenciaActual,
				  CostoPromedio=@CostoPromedioActual,
				  ImporteTotalPromedio=@ImporteTotalPromedioActual,
				  ModificadoEl= @CreadoEl,
				  ModificadoPor = @CreadoPor,
				  CostoPromedioDlls = @CostoPromedioActualDlls,
				  ImporteTotalPromedioDlls = @ImporteTotalPromedioActualDlls 
			 WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo	
	
		SELECT @CostoPromedioActual = CostoPromedio FROM ProInventarioAlmacen WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo	
		SELECT @CostoPromedioActualDlls = CostoPromedioDlls FROM ProInventarioAlmacen WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo
				
	--  Registrar detalle de movimiento 
		INSERT INTO ProMovimientosAlmacenConceptos(IdArticulo,Cantidad,PrecioUnitario,Importe,IdAlmacen,CreadoPor,CreadoEl,IdMovimientoAlmacen,ExistenciaControlPEPS,CostoPromedio,PrecioUnitarioDlls,ImporteDlls,CostoPromedioDlls,Observaciones,CantidadDevolucion)
		VALUES	(@ATT_IdArticulo,@ATT_Cantidad,@CostoPromedioActual,@CostoPromedioActual*@ATT_Cantidad,@ATT_IdAlmacen,@CreadoPor,@CreadoEl,@IdMovimientoAlmacen,@ATT_Cantidad,@CostoPromedioActual,@CostoPromedioActualDlls,@CostoPromedioActualDlls*@ATT_Cantidad,@CostoPromedioActualDlls,@ATT_Observaciones,@ATT_Cantidad)
						
		SET @IdMovimientoAlmacenConceptoSalida = (SELECT IDENT_CURRENT('ProMovimientosAlmacenConceptos'))						

	--- INICIO DE REGISTRAR MOVIMIENTO EN DETALLE DE PEPS
				DECLARE @IdMovimientoAlmacenConceptoEntrada Int ,
						@Cantidad decimal(15,4), 
						@PrecioUnitario Money, 
						@ExistenciaControlPEPS decimal(15,4),
						@FechaHoraEntrada DateTime,
						@PrecioUnitarioDlls Money
				    
				DECLARE TempProMovimientosAlmacenConceptosEntrada CURSOR FAST_FORWARD  
				 FOR  SELECT ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto AS IdMovimientoAlmacenConceptoEntrada, ProMovimientosAlmacenConceptos.Cantidad, 
						ProMovimientosAlmacenConceptos.PrecioUnitario, ProMovimientosAlmacenConceptos.ExistenciaControlPEPS, 
						ProMovimientosAlmacen.FechaHora AS FechaHoraEntrada,
						ProMovimientosAlmacenConceptos.PrecioUnitarioDlls
					FROM ProMovimientosAlmacenConceptos INNER JOIN
						 ProMovimientosAlmacen ON ProMovimientosAlmacenConceptos.IdMovimientoAlmacen = ProMovimientosAlmacen.IdMovimientoAlmacen INNER JOIN
						CatTiposMovimientosAlmacen ON ProMovimientosAlmacen.IdTipoMovimientoAlmacen = CatTiposMovimientosAlmacen.IdTipoMovimientoAlmacen
				WHERE (ISNULL(ProMovimientosAlmacenConceptos.ExistenciaControlPEPS, 0) > 0) AND (ProMovimientosAlmacenConceptos.IdAlmacen = @ATT_IdAlmacen ) AND 
						(ProMovimientosAlmacenConceptos.IdArticulo = @ATT_IdArticulo) And CatTiposMovimientosAlmacen.Tipo = 1
				ORDER BY FechaHoraEntrada
			--	
			OPEN TempProMovimientosAlmacenConceptosEntrada
				FETCH NEXT FROM TempProMovimientosAlmacenConceptosEntrada INTO	@IdMovimientoAlmacenConceptoEntrada,@Cantidad,@PrecioUnitario,@ExistenciaControlPEPS,@FechaHoraEntrada,@PrecioUnitarioDlls
				WHILE @@FETCH_STATUS = 0  
				BEGIN  
					
					IF @ExistenciaControlPEPS < @ATT_Cantidad
						BEGIN 
							UPDATE ProMovimientosAlmacenConceptos
							SET ExistenciaControlPEPS = 0  
							WHERE ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto = @IdMovimientoAlmacenConceptoEntrada
								SET  @ATT_Cantidad = (@ATT_Cantidad-@ExistenciaControlPEPS )
									--Registrar detalle de PEPS
									INSERT INTO ProMovimientosAlmacenConceptosPEPS (IdMovimientoAlmacenConceptoSalida,IdArticulo,IdAlmacen,Cantidad,CostoUnitario,IdMovimientoAlmacenConceptoEntrada,CostoUnitarioDlls)
									VALUES (@IdMovimientoAlmacenConceptoSalida,@ATT_IdArticulo,@ATT_IdAlmacen,@ExistenciaControlPEPS,@PrecioUnitario,@IdMovimientoAlmacenConceptoEntrada,@PrecioUnitarioDlls)
						END
					ELSE
						BEGIN
							  UPDATE  ProMovimientosAlmacenConceptos
							  SET ProMovimientosAlmacenConceptos.ExistenciaControlPEPS  = (@ExistenciaControlPEPS- @ATT_Cantidad)
							  WHERE ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto= @IdMovimientoAlmacenConceptoEntrada
							  --Registrar detalle de PEPS
								INSERT INTO ProMovimientosAlmacenConceptosPEPS
								(IdMovimientoAlmacenConceptoSalida,IdArticulo,IdAlmacen,Cantidad,CostoUnitario,IdMovimientoAlmacenConceptoEntrada,CostoUnitarioDlls)
								VALUES (@IdMovimientoAlmacenConceptoSalida,@ATT_IdArticulo,@ATT_IdAlmacen,@ATT_Cantidad,@PrecioUnitario,@IdMovimientoAlmacenConceptoEntrada,@PrecioUnitarioDlls)
							 BREAK    		 
						END
			    FETCH NEXT FROM TempProMovimientosAlmacenConceptosEntrada INTO	@IdMovimientoAlmacenConceptoEntrada,@Cantidad,@PrecioUnitario,@ExistenciaControlPEPS,@FechaHoraEntrada,@PrecioUnitarioDlls
			 END  
			 CLOSE TempProMovimientosAlmacenConceptosEntrada
			 DEALLOCATE TempProMovimientosAlmacenConceptosEntrada
		--- FIN DE REGISTRAR MOVIMIENTO EN DETALLE DE PEPS
		
		 --	Actualiza parte de servicio
				IF ISNULL(@ATT_IdOrdenServicioParte,0) <> 0
				BEGIN
					SET @CostoUnitarioPEPS = (
					  SELECT sum((CASE @IdMoneda WHEN 1 THEN CostoUnitario ELSE CostoUnitarioDlls END) *Cantidad)
								 /SUM(Cantidad)
						FROM ProMovimientosAlmacenConceptosPEPS
						WHERE ProMovimientosAlmacenConceptosPEPS.IdArticulo = @ATT_IdArticulo And ProMovimientosAlmacenConceptosPEPS.IdAlmacen = @ATT_IdAlmacen 
						AND  ProMovimientosAlmacenConceptosPEPS.IdMovimientoAlmacenConceptoSalida = @IdMovimientoAlmacenConceptoSalida
					 )
			 
					  --SOL 8655 SE QUITO EL CostoParte porque lo estaba cambiando al del inventario (no respetaba el valor que se le daba)
					UPDATE ProOrdenesServiciosPartes SET IdMovimientoAlmacenConcepto = @IdMovimientoAlmacenConceptoSalida
					--CostoParte  = @CostoUnitarioPEPS
					WHERE ProOrdenesServiciosPartes.IdOrdenServicioParte = @ATT_IdOrdenServicioParte
				
				
		-- Se actualiza importes en ProOrdenesServiciosDetalles  
					DECLARE @IdOrdenServicioDetalle INT, @ImporteTotalPartes money
					SET @ImporteTotalPartes =  (SELECT CantidadParte*CostoParte From ProOrdenesServiciosPartes where  ProOrdenesServiciosPartes.IdOrdenServicioParte  =@ATT_IdOrdenServicioParte)
					
					SELECT  @IdOrdenServicioDetalle = IdOrdenServicioDetalle 
					    FROM  ProOrdenesServiciosPartes WHERE ProOrdenesServiciosPartes.IdOrdenServicioParte =  @ATT_IdOrdenServicioParte
					    
					UPDATE ProOrdenesServiciosDetalles  
					     SET ImporteTotalPartes =@ImporteTotalPartes,
					         ImporteTotal = (@ImporteTotalPartes+ImporteManoObra)
					WHERE IdOrdenServicioDetalle  = @IdOrdenServicioDetalle
				END
	
							
		FETCH NEXT FROM TempProMovimientosAlmacenConceptos INTO 
		@ATT_IdArticulo,@ATT_IdAlmacen,@ATT_Cantidad,@ATT_PrecioUnitario,@ATT_Importe,@ATT_UnidadMedida,@ATT_Observaciones , @ATT_IdOrdenServicioParte
	END
	CLOSE TempProMovimientosAlmacenConceptos
	DEALLOCATE TempProMovimientosAlmacenConceptos

			
    -- Registrar importes 
	   DECLARE @ImporteTotalSalida money,
	   	       @ImporteTotalSalidaDlls money
	   SET @ImporteTotalSalida = (SELECT round(SUM(Importe),2) From ProMovimientosAlmacenConceptos where IdMovimientoAlmacen = @IdMovimientoAlmacen)
	   SET @ImporteTotalSalidaDlls = (SELECT round(SUM(ImporteDlls),2) From ProMovimientosAlmacenConceptos where IdMovimientoAlmacen = @IdMovimientoAlmacen)
	   UPDATE ProMovimientosAlmacen
			SET SubTotal = @ImporteTotalSalida ,
				Total = @ImporteTotalSalida,
				SubTotalDlls = @ImporteTotalSalidaDlls,
				TotalDlls = @ImporteTotalSalidaDlls
			WHERE ProMovimientosAlmacen.IdMovimientoAlmacen = @IdMovimientoAlmacen
	--
		-- SECCION PARA CONCEPTOS DE MOVIMIENTO DE ALMACEN DETALLADOS	SOLICITUD 12339
	IF @dsProMovimientosAlmacenDetallados IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProMovimientosAlmacenDetallados
		
		SELECT  ATT_IdProMovimientoDetallado, ATT_IdArticulo ,ATT_IdMovimientoAlmacen,ATT_NumeroSerie,ATT_IdConsumidor,ATT_IdTipoMovimientoAlmacen
		INTO #TempProMovimientosAlmacenDetallados
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProArticulosDetallados',2) 
		WITH (ATT_IdProMovimientoDetallado int,ATT_IdArticulo  int,ATT_IdMovimientoAlmacen  int,ATT_NumeroSerie varchar(25),ATT_IdConsumidor int,ATT_IdTipoMovimientoAlmacen int)
		
		EXEC sp_xml_removedocument @docHandle
		
		IF @EsTraspaso = 1 
			SET @Activo = 0
		ELSE
			SET @Activo = 1

		UPDATE ProMovimientosAlmacenDetallado
		SET Activo = @Activo
		FROM ProMovimientosAlmacenDetallado INNER JOIN #TempProMovimientosAlmacenDetallados
		ON ProMovimientosAlmacenDetallado.IdProMovimientodetallado = #TempProMovimientosAlmacenDetallados.ATT_IdProMovimientoDetallado
		
		IF @EsTraspaso = 1 --Si @EsTraspaso es = 1 inserta @IdTipoMovimientoAlmacen y es 0 lo toma del xml
		BEGIN
			INSERT INTO ProMovimientosAlmacenDetalladoHistorico (IdProMovimientoDetallado,CreadoEl,CreadoPor,IdMovimientoAlmacen,IdTipoMovimientoAlmacen)
			SELECT ATT_IdProMovimientoDetallado,@CreadoEl,@CreadoPor,@IdMovimientoAlmacen,@IdTipoMovimientoAlmacen FROM #TempProMovimientosAlmacenDetallados			
		END
		ELSE
		BEGIN
			INSERT INTO ProMovimientosAlmacenDetalladoHistorico (IdProMovimientoDetallado,CreadoEl,CreadoPor,IdMovimientoAlmacen,IdTipoMovimientoAlmacen)
			SELECT ATT_IdProMovimientoDetallado,@CreadoEl,@CreadoPor,@IdMovimientoAlmacen,ATT_IdTipoMovimientoAlmacen FROM #TempProMovimientosAlmacenDetallados
		END
	END
	
	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

