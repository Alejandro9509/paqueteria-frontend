CREATE PROCEDURE [dbo].[usp_CatRutasPersonalAgregar]
	@IdCliente int,
	@IdOrigen int,
	@IdDestino int,
	@IdTipoUnidad int,
	@IdTurno int,
	@IdClasificacionViaje int,
	@IdTipoRuta int,
	@IdSucursal int,
	@FolioRuta int,
	@Descripcion varchar(140),
	@AccesorioTV bit,
	@AccesorioWIFI bit,
	@AccesorioAC bit,
	@AccesorioDiscapacitados bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@Activa bit,
	@IdPeticion varchar(100),
	@dsCatRutasPersonalConceptosFacturacion ntext,
	@dsCatRutasPersonalClientesContatos ntext,
	@dsCatRutasPersonalParadas ntext,
	@IdSupervisor int	
	/* *************************************************************************************************
Procedimiento usp_CatRutasPersonalAgregar
 
Descripción: Procedimiento para agregar una ruta/tarifa de transpoete de personal

08/05/2020 - Se modifica para poder agregar varias paradas a la ruta, asi como gastos.

Implementada por: XXXXXX
Fecha de implementacion: XXXXXX
Versión ERP: XXXXXX

Modificada por:   Francisco Villela
Fecha de mofidicacion: 08/05/2020
Versión ERP: 8.0.50.02


Invocada desde: PAGE_CatRutasPersonalAM 
***************************************************************************************************** */
AS
DECLARE
	@IdRutaPersonal int,
	@docHandle int,
	@CursorIdConceptoFacturacion int,
	@CursorImporte money,
	@CursorImporteDlls money,
	@CursorIdPuesto int,
	@CursorPuntos int,
	@CursorIdClienteContacto int,
	@CursorIdGeocerca int,
	@CursorIdEstatuViajeEntrada int,
	@CursorIdEstatuViajeSalida int,
	@COL_Secuencia int,
	@COL_IdOrigen int,
	@COL_IdDestino int,
	@COL_Kilometros int,
	@COL_Horas decimal(15,2),
	@COL_RutaGoogleMap varchar(max),
	@COL_GastosAutorizados varchar(8000),
	@COL_SueldoBase money,
	@COL_SueldoBaseDlls money,
	@COL_IdGeocercaDisparaSalida int,
	@COL_GeocercaDisparaSalidaES tinyint,
	@COL_IdGeocercaDisparaLlegada int,
	@COL_GeocercaDisparaLlegadaES tinyint,
	@COL_Geocercas varchar(max),
	@COL_IdEstatuViajeSalida int,
	@COL_IdEstatuViajeLlegada int,	
	@IdRutaTrayecto int,
	@COL_TipoTrayecto TINYINT,
	@COL_Puntuaciones varchar(max),
	@COL_HoraSalida datetime,
	@COL_HoraReporte datetime,
	@CursorIdTipoViaje int,
	@CursorIdTipoUnidad int,
	@CursorIdClasificacionViaje int,
	@IdImpuestoTrasladado decimal(15,2),
	@IdImpuestoRetenido decimal(15,2),
	@CursorTraslada bit,
	@CursorRetiene bit,
	@IdRutaConceptoFacturacion int
BEGIN TRY
	BEGIN TRANSACTION
		
		IF @FolioRuta = 0
		RAISERROR(N'El folio de la ruta es un campo requerido',
			16,
			1
			)
		IF EXISTS(SELECT * FROM CatRutasPersonal WHERE FolioRuta = @FolioRuta)			
		RAISERROR(N'El folio de la ruta ya existe en el catálogo',
			16,
			1
			)
		IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
		IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)			
		IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)			
		IF RTRIM(LTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción de la ruta es un campo requerido',
			16,
			1
			)	
		IF @IdSucursal = 0
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)
		IF @dsCatRutasPersonalParadas IS NULL
		RAISERROR(N'Las paradas son requeridas',
			16,
			1
			)
		IF @IdClasificacionViaje = 0
			SET @IdClasificacionViaje = NULL
		IF @IdTurno = 0 
			SET @IdTurno = NULL
		IF @IdTipoUnidad = 0
			SET	@IdTipoUnidad = NULL
		IF @IdTipoRuta = 0
			SET @IdTipoRuta = NULL
		IF @IdSupervisor = 0
			SET @IdSupervisor = NULL
								
		INSERT INTO CatRutasPersonal(IdCliente,IdOrigen,IdDestino,IdTipoUnidad,IdTurno,IdClasificacionViaje,IdTipoRuta,IdSucursal,FolioRuta,Descripcion,AccesorioTV,AccesorioAC,AccesorioWIFI,AccesorioDiscapacitados,CreadoPor,CreadoEl,Activa,IdSupervisor)
		VALUES(@IdCliente,@IdOrigen,@IdDestino,@IdTipoUnidad,@IdTurno,@IdClasificacionViaje,@IdTipoRuta,@IdSucursal,@FolioRuta,@Descripcion,@AccesorioTV,@AccesorioAC,@AccesorioWIFI,@AccesorioDiscapacitados,@CreadoPor,@CreadoEl,@Activa,@IdSupervisor)	

		SET @IdRutaPersonal = (SELECT IDENT_CURRENT('CatRutasPersonal'))

		--AGREGA LOS CONCEPTOS DE FACTURACION	
		IF @dsCatRutasPersonalConceptosFacturacion IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalConceptosFacturacion
			
			SELECT ATT_IdConceptoFacturacion,ATT_Importe,ATT_ImporteDlls,COL_IdTipoViaje,COL_IdTipoUnidad,COL_IdClasificacionViaje,COL_IdImpuestoTrasladado,COL_IdImpuestoRetenido,COL_Traslada,COL_Retiene
			INTO #TempCatRutasPersonalConceptosFacturacion
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalConceptosFacturacion',2) 
			WITH (ATT_IdConceptoFacturacion int,ATT_Importe money,ATT_ImporteDlls money,COL_IdTipoViaje int,COL_IdTipoUnidad int,COL_IdClasificacionViaje int,COL_IdImpuestoTrasladado int,COL_IdImpuestoRetenido int,COL_Traslada bit ,COL_Retiene bit)
			
			EXEC sp_xml_removedocument @docHandle
			
			DECLARE CursorCatRutasPersonalConceptosFacturacion CURSOR FOR
			SELECT * FROM #TempCatRutasPersonalConceptosFacturacion
			
			OPEN CursorCatRutasPersonalConceptosFacturacion
			FETCH NEXT FROM CursorCatRutasPersonalConceptosFacturacion
			INTO @CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
					IF @CursorIdTipoViaje = 0
				SET	@CursorIdTipoViaje = NULL

			IF @CursorIdTipoUnidad = 0
				SET	@CursorIdTipoUnidad = NULL

			IF @CursorIdClasificacionViaje = 0
				SET	@CursorIdClasificacionViaje = NULL				
				INSERT INTO CatRutasPersonalConceptosFacturacion(IdRutaPersonal,IdConceptoFacturacion,Importe,ImporteDlls,CreadoPor,CreadoEl
				,IdTipoViaje,IdTipoUnidad,IdClasificacionViaje,TrasladaImpuesto,RetieneImpuesto)
				VALUES(@IdRutaPersonal,@CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,@CreadoPor,@CreadoEl
				,@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@CursorTraslada,@CursorRetiene)
				SET @IdRutaConceptoFacturacion = (SELECT IDENT_CURRENT('CatRutasPersonalConceptosFacturacion'))
				IF @IdImpuestoTrasladado > 0
				BEGIN
					INSERT INTO CatRutasPersonalConceptosFacturacionImpuestos(IdRutaPersonalConceptoFacturacion,IdImpuesto)
					VALUES( @IdRutaConceptoFacturacion,@IdImpuestoTrasladado )
				END
				
				IF @IdImpuestoRetenido > 0
				BEGIN
					INSERT INTO CatRutasPersonalConceptosFacturacionImpuestos(IdRutaPersonalConceptoFacturacion,IdImpuesto)
					VALUES( @IdRutaConceptoFacturacion,@IdImpuestoRetenido )
				END

				FETCH NEXT FROM CursorCatRutasPersonalConceptosFacturacion
				INTO @CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
			
			END
			CLOSE CursorCatRutasPersonalConceptosFacturacion
			DEALLOCATE CursorCatRutasPersonalConceptosFacturacion						
		END
	
		--AGREGAR LAS NOTIFICACIONES 
		IF @dsCatRutasPersonalClientesContatos IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalClientesContatos
			
			SELECT ATT_IdClienteContacto
			INTO #TempCatRutasPersonalClientesContatos
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalClientesContatos',2) 
			WITH (ATT_IdClienteContacto int)
			
			EXEC sp_xml_removedocument @docHandle
			
			DECLARE CursorCatRutasPersonalClientesContatos CURSOR FOR
			SELECT * FROM #TempCatRutasPersonalClientesContatos
			
			OPEN CursorCatRutasPersonalClientesContatos
			FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
			INTO @CursorIdClienteContacto
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
									
				INSERT INTO CatRutasPersonalClientesContatos(IdRutaPersonal,IdClienteContacto,CreadoPor,CreadoEl)
				VALUES(@IdRutaPersonal,@CursorIdClienteContacto,@CreadoPor,@CreadoEl)
			
				FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
				INTO @CursorIdClienteContacto
			END
			CLOSE CursorCatRutasPersonalClientesContatos
			DEALLOCATE CursorCatRutasPersonalClientesContatos					
		END

		--AGREGAR LAS PARADAS 
		--SECCION PARA AGREGAR LOS trayectos
		
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalParadas
	
	SELECT COL_Secuencia,COL_IdOrigen,COL_IdDestino,COL_Kilometros,COL_Horas,COL_RutaGoogleMap,COL_GastosAutorizados,
	COL_SueldoBase,COL_SueldoBaseDlls,	
	COL_IdGeocercaDisparaSalida,COL_GeocercaDisparaSalidaES,COL_IdGeocercaDisparaLlegada,COL_GeocercaDisparaLlegadaES,COL_Geocercas,
	COL_IdEstatuViajeSalida,COL_IdEstatuViajeLlegada,COL_TipoTrayecto,COL_Puntuaciones,COL_HoraSalida,COL_HoraReporte
	INTO #TempCatRutasTrayectos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalParadas',2) 
	WITH (COL_Secuencia int,COL_IdOrigen int,COL_IdDestino int,COL_Kilometros int,COL_Horas decimal(15,2),COL_RutaGoogleMap ntext,COL_GastosAutorizados varchar(8000),
	COL_SueldoBase money,COL_SueldoBaseDlls money,
	COL_IdGeocercaDisparaSalida int,COL_GeocercaDisparaSalidaES tinyint,COL_IdGeocercaDisparaLlegada int,COL_GeocercaDisparaLlegadaES tinyint,COL_Geocercas ntext,
	COL_IdEstatuViajeSalida int,COL_IdEstatuViajeLlegada int,COL_TipoTrayecto TINYINT,COL_Puntuaciones ntext,COL_HoraSalida datetime,COL_HoraReporte datetime)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatRutasTrayectos CURSOR FOR
	SELECT * FROM #TempCatRutasTrayectos
	
	OPEN CursorCatRutasTrayectos
	FETCH NEXT FROM CursorCatRutasTrayectos
	INTO @COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
	@COL_SueldoBase,@COL_SueldoBaseDlls,
	@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,
	@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,@COL_TipoTrayecto,@COL_Puntuaciones,@COL_HoraSalida,@COL_HoraReporte
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		IF @COL_IdEstatuViajeSalida = 0
			SET @COL_IdEstatuViajeSalida = NULL

		IF @COL_IdEstatuViajeLlegada = 0
			SET @COL_IdEstatuViajeLlegada = NULL
		
		IF ISNULL(@COL_Kilometros,0) <= 0	
		RAISERROR(N'El kilometraje la parada es un campo requerido',
			16,
			1
			)
				
		IF ISNULL(@COL_Horas,0) <= 0	
		RAISERROR(N'Las horas para la parada es un campo requerido',
			16,
			1
			)
		
		INSERT INTO CatRutasPersonalParadas(CreadoEl,CreadoPor,Horas,IdDestino,IdOrigen,IdRutaPersonal,Kilometros,RutaGoogleMap,Secuencia,		
		SueldoBase,SueldoBaseDlls,IdGeocercaDisparaSalida,GeocercaDisparaSalidaES,IdGeocercaDisparaLlegada,GeocercaDisparaLlegadaES,IdEstatuViajeSalida,
		IdEstatuViajeEntrada,TipoParada,HoraSalida,HoraReporte)
		VALUES(@CreadoEl,@CreadoPor,@COL_Horas,@COL_IdDestino,@COL_IdOrigen,@IdRutaPersonal,@COL_Kilometros,@COL_RutaGoogleMap,@COL_Secuencia,
		@COL_SueldoBase,@COL_SueldoBaseDlls,		
		@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,
		@COL_TipoTrayecto,@COL_HoraSalida,@COL_HoraReporte)

		SET @IdRutaTrayecto = (SELECT IDENT_CURRENT('CatRutasPersonalParadas'))
			
		IF @COL_GastosAutorizados <> ''
		BEGIN
			select(@COL_GastosAutorizados)
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_GastosAutorizados
			SELECT ATT_ConceptoGastoViaje,ATT_IdConceptoGastoViaje,ATT_IdRutaTrayectoGasto,ATT_ImporteAutorizado,ATT_ImporteAutorizadoState,ATT_LitrosAutorizados,ATT_LitrosAutorizadosState
			INTO #TempCatRutasTrayectosGastos
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosGastos',2) 
			WITH(ATT_ConceptoGastoViaje Varchar(50),ATT_IdConceptoGastoViaje int,ATT_IdRutaTrayectoGasto int,ATT_ImporteAutorizado money,ATT_ImporteAutorizadoState int,ATT_LitrosAutorizados Decimal(15,2),ATT_LitrosAutorizadosState int)
			EXEC sp_xml_removedocument @docHandle
			INSERT INTO CatRutasPersonalParadasGastos(IdRutaPersonalParada,IdConceptoGastoViaje,ImporteAutorizado,ImporteAutorizadoState,LitrosAutorizados,LitrosAutorizadosState,CreadoEl,CreadoPor)
			SELECT @IdRutaTrayecto,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_ImporteAutorizadoState,ATT_LitrosAutorizados,ATT_LitrosAutorizadosState,@CreadoEl,@CreadoPor
			FROM #TempCatRutasTrayectosGastos
			
			DROP TABLE #TempCatRutasTrayectosGastos
		END
		
		IF @COL_Geocercas <> ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Geocercas

			SELECT COL_IdEstatuViajeEntrar,COL_IdEstatuViajeSalir,COL_IdGeocerca
			INTO #TempCatRutasTrayectosGeocercas
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosGeocercas',2) 
			WITH(COL_IdEstatuViajeEntrar int,COL_IdEstatuViajeSalir int,COL_IdGeocerca int)
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasPersonalParadasGeocercas(IdRutaTrayecto,IdEstatuViajeEntrada,IdEstatuViajeSalida,IdGeocerca,CreadoEl,CreadoPor)
			SELECT @IdRutaTrayecto,
			CASE COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE COL_IdEstatuViajeEntrar END,
			CASE COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE COL_IdEstatuViajeSalir END,
			COL_IdGeocerca,@CreadoEl,@CreadoPor
			FROM #TempCatRutasTrayectosGeocercas
			
			DROP TABLE #TempCatRutasTrayectosGeocercas
		END

		IF @COL_Puntuaciones <> ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Puntuaciones

			SELECT ATT_IdRutaPersonalPuntuacion,ATT_IdPuesto,ATT_Puntos
			INTO #TempCatRutasPersonalPuntuaciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalPuntuaciones',2) 
			WITH(ATT_IdRutaPersonalPuntuacion int,ATT_IdPuesto int,ATT_Puntos int)
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasPersonalPuntuaciones(IdRutaPersonalParada,IdPuesto,Puntos,CreadoEl,CreadoPor)
			SELECT @IdRutaTrayecto,ATT_IdPuesto,ATT_Puntos,@CreadoEl,@CreadoPor
			FROM #TempCatRutasPersonalPuntuaciones
			
			
			DROP TABLE #TempCatRutasPersonalPuntuaciones
		END
		
		
		
		----despues de agregar/modificar/eliminar las casetas autorizadas se valida
		----que los gastos autorizados de autopistas y autopistas iave sean igual a la suma de de las casetas autorizadas
		----solo si el modulo de ptv "NO esta contratado" esta seccion debe estar despues de casetas autorizadas y gastos autorizados
		----solicitud 11783
		--IF @PTVContratado = 0
		--BEGIN
		--	DECLARE @GastoAutorizado money,@CasetaAutorizado money,
		--	@GastoAutorizadoText nvarchar(20),@CasetaAutorizadoText nvarchar(20)

		--	--seccion para evaluar autopistas a contado IdConceptoGastoViaje = 3
		--	SET @GastoAutorizado = ISNULL((SELECT SUM(ImporteAutorizado) FROM CatRutasTrayectosGastos where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 3),0)
		--	SET @CasetaAutorizado = ISNULL((SELECT SUM(Importe) FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 3 AND ISNULL(NomenclaturaSCT,'') = '' AND ISNULL(NumeroEjes,0) = 0),0)

		--	IF @GastoAutorizado <> @CasetaAutorizado AND EXISTS(SELECT * FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 3)
		--	BEGIN
		--		SET @GastoAutorizadoText = CAST(@GastoAutorizado AS nvarchar(20))
		--		SET @CasetaAutorizadoText = CAST(@CasetaAutorizado AS nvarchar(20))
		--		RAISERROR(N'En el trayecto %d el importe autorizado para autopistas (contado/efectivo) $%s no coincide con la suma de los importes de las casetas a contado $%s',
		--			16,
		--			1,
		--			@COL_Secuencia,
		--			@GastoAutorizadoText,
		--			@CasetaAutorizadoText
		--			)
		--	END

		--	--seccion para evaluar autopistas a credito IdConceptoGastoViaje = 4
		--	SET @GastoAutorizado = ISNULL((SELECT SUM(ImporteAutorizado) FROM CatRutasTrayectosGastos where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 4),0)
		--	SET @CasetaAutorizado = ISNULL((SELECT SUM(Importe) FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 4 AND ISNULL(NomenclaturaSCT,'') = '' AND ISNULL(NumeroEjes,0) = 0),0)

		--	IF @GastoAutorizado <> @CasetaAutorizado AND EXISTS(SELECT * FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 4)
		--	BEGIN
		--		SET @GastoAutorizadoText = CAST(@GastoAutorizado AS nvarchar(20))
		--		SET @CasetaAutorizadoText = CAST(@CasetaAutorizado AS nvarchar(20))
		--		RAISERROR(N'En el trayecto %d el importe autorizado para autopistas IAVE(crédito) $%s no coincide con la suma de los importes de las casetas a crédito $%s',
		--			16,
		--			1,
		--			@COL_Secuencia,
		--			@GastoAutorizadoText,
		--			@CasetaAutorizadoText
		--			)
		--	END
		--END

		

		FETCH NEXT FROM CursorCatRutasTrayectos
		INTO @COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
		@COL_SueldoBase,@COL_SueldoBaseDlls,
		@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,
		@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,@COL_TipoTrayecto,@COL_Puntuaciones,@COL_HoraSalida,@COL_HoraReporte

	END

	CLOSE CursorCatRutasTrayectos
	DEALLOCATE CursorCatRutasTrayectos	
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

