
CREATE PROCEDURE [dbo].[usp_CatTiposUnidadesEliminarPQ]
	@IdTipoUnidad INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdTipoUnidad,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del tipo de unidad es un campo requerido*FIN*', 16, 1)
			return 
		end
		
		DELETE FROM CatTiposUnidades
		WHERE IdTipoUnidad = @IdTipoUnidad
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

