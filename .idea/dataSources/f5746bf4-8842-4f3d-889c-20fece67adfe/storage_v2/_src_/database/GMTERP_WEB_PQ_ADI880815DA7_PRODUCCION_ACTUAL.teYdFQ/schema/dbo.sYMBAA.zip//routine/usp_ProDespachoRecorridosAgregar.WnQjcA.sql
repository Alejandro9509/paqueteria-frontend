CREATE PROCEDURE [dbo].[usp_ProDespachoRecorridosAgregar]
	@FechaRecorrido datetime,
	@IdCliente int,
	@Descripcion varchar(50),    
	@IdUnidad int,
	@IdOperador int,
	@Observaciones varchar(512),
	@TiempoRecorrido decimal(15,2),
	@Kilometros int,
	@IdRecorrido int,
	@FechaHoraRecorridoEstatus datetime,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdEstatuViaje int,
	@IdPeticion varchar(100),
	@Referencia varchar(50),
	@Placas varchar(9),
	@CodigoUnidad varchar(16),
	@NombreOperador varchar(100),
	@IdOrigen int,
	@IdDestino int,
	@Folio  int,
	@Fecha datetime
AS
DECLARE
	@RutaGoogleMap nvarchar(MAX),
	@IdRecorridoDespacho int,
	@UltimoFolio int 		
BEGIN TRY		
	BEGIN TRANSACTION

	IF ISDATE(@FechaRecorrido) = 0
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF ISDATE(@FechaHoraRecorridoEstatus) = 0
		RAISERROR(N'La fecha y hora del estatus es un campo requerido',
			16,
			1
			)
			
	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
			
	IF @IdRecorrido = 0 
		RAISERROR(N'La ruta es un campo requerido',
			16,
			1
			)
				
	IF @IdEstatuViaje = 0
		RAISERROR(N'El estatus es un campo requerido',
			16,
			1
			)
    IF EXISTS(SELECT Folio FROM ProRecorridosDespacho WHERE Folio = @Folio) 
		RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar.',
			16,
			1
			)	
	IF EXISTS(SELECT IdUnidad FROM CatUnidades WHERE IdUnidad = @IdUnidad and Activa = 0) 
		RAISERROR(N'La unidad seleccionada no esta activa.',
			16,
			1
			)		
	IF EXISTS(SELECT IdOperador FROM CatOperadores WHERE IdOperador = @IdOperador and Activo = 0) 
		RAISERROR(N'El operador seleccionado no esta activo.',
			16,
			1
			)		
	IF @IdOperador = 0
	BEGIN 
		SET @IdOperador = NULL
	    SET @NombreOperador = NULL
	END  
	IF @IdUnidad = 0 
		Set @IdUnidad = NULL

	SET @RutaGoogleMap = (Select RutaGoogleMap FROM CatRecorridos where IdRecorrido = @IdRecorrido) 

	
			
	INSERT INTO ProRecorridosDespacho(FechaHoraRecorridoEstatus,IdCliente,Descripcion,IdUnidad,IdOperador,TiempoRecorrido,Observaciones,Kilometros,IdRecorrido,CreadoPor,CreadoEl,Placas,CodigoUnidad,Folio,IdOrigen,IdDestino,IdEstatuViaje,NombreOperador,Referencia,Fecha,RutaGoogleMap) 
	VALUES(@FechaRecorrido,@IdCliente,@Descripcion,@IdUnidad,@IdOperador,@TiempoRecorrido,@Observaciones,@Kilometros,@IdRecorrido,@CreadoPor,@CreadoEl,@Placas,@CodigoUnidad,@Folio,@IdOrigen,@IdDestino,@IdEstatuViaje,@NombreOperador,@Referencia,@Fecha,@RutaGoogleMap) 

	SET @IdRecorridoDespacho = (SELECT IDENT_CURRENT('ProRecorridosDespacho'))
	
	INSERT INTO ProRecorridosDespachoEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatusViaje,IdRecorridoDespacho)
	VALUES(@CreadoEl,@CreadoPor,@FechaHoraRecorridoEstatus,@IdEstatuViaje,@IdRecorridoDespacho)

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

