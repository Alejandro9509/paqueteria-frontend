
CREATE PROCEDURE [dbo].[usp_CatTiposViajesEliminar]
	@IdTipoViaje int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM CatRutas WHERE IdTipoViaje = @IdTipoViaje)
		RAISERROR(N'El tipo de viaje tiene rutas asignadas, no es posible eliminarlo',
			16,
			1
			)		
					
	DELETE FROM CatTiposViajes
	WHERE IdTipoViaje = @IdTipoViaje
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

