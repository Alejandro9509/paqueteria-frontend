CREATE PROCEDURE [dbo].[usp_CatPuestosModificar]
@IdPuesto	int,
@Codigo	int,	
@Puesto	varchar(40),	
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdPuesto,0)= 0
	RAISERROR(N'El identificador del Puesto es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del Puesto es un campo requerido',
			16,
			1
			)
	
	 IF EXISTS(SELECT Codigo FROM CatPuestos WHERE Codigo = @Codigo And IdPuesto <> @IdPuesto)
		RAISERROR(N'El código del Puesto ya existe',
			16,
			1
			)  
							
	IF ISNULL(@Puesto,'')= ''
		RAISERROR(N'El nombre del Puesto es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Puesto FROM CatPuestos WHERE Puesto = @Puesto And IdPuesto <> @IdPuesto)
		RAISERROR(N'El Puesto ya fue Registrado',
			16,
			1
			) 
			
	UPDATE CatPuestos SET
	Codigo= @Codigo,
	Puesto= @Puesto,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor
	WHERE 	IdPuesto=@IdPuesto
		---------Modificar Operadores----------------------
	Alter Table CatOperadores 
	Disable trigger trg_CatOperadores
	Update CatOperadores set Puesto = @Puesto where IdOperador in(select IdOperador from CatEmpleados where IdPuesto = @IdPuesto)
	Alter Table CatOperadores
	Enable trigger trg_CatOperadores
	---------Fin de Modificar Operadores---------------
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

