CREATE PROCEDURE [dbo].[usp_ProReportesRoboAgregar]
	@IdUnidad int,
	@IdViaje int,
	@NombreOperador varchar(100),
	@Licencia varchar (19),
	@Telefonos varchar (26),
	@TipoTractor varchar (26),
	@ModeloTractor varchar (26),
	@ColorTractor varchar (26),
	@SerieTractor varchar (100),
	@MarcaTractor varchar (26),
	@PlacasTractor varchar (20),
	@AnoTractor int,
	@CodigoTractor varchar (26),
	@TipoRemolque varchar (26),
	@ModeloRemolque varchar (26),
	@ColorRemolque varchar (26),
	@SerieRemolque varchar (100),
	@MarcaRemolque varchar (26),
	@PlacasRemolque varchar (20),
	@AnoRemolque int,
	@CodigoRemolque varchar (26),
	@NoCartaPorte varchar (50),
	@DescripcionMercancia varchar (100),
	@DetallesSiniestro varchar (200),
	@Ciudad varchar (26),
	@CarreteraAvenida varchar (60),
	@Kilometro varchar (60),
	@Coordenadas varchar (60),
	@Referencias varchar (100),
	@AutoridadesDependiencia varchar (50),
	@PersonaAtendioReporte varchar (100),
	@NoReporteAutoridades varchar (60),
	@Hora datetime,
	@AutoridadesTelefono varchar (26),
	@Aseguradora varchar (60),
	@NoPoliza varchar (60),
	@NoReporteAseguradora varchar (60),
	@NombreAjustador varchar (100),
	@TelefonoAjustador varchar (26),
	@NombreInformante varchar (100),
	@PuestoInformante varchar (60),
	@TelefonoInformante varchar (26),
	@DatosAdicionales varchar (MAX),
	@FechaHora  datetime,
	@IdPeticion varchar(100),
	@dsProReportesRoboVehiculosInvolucrados ntext,
	@dsProReportesRoboCondicionesOcupantes ntext,
	@CreadoPor int,
	@CreadoEl datetime
AS
DECLARE
	@docHandle int,
	@IdReportesRobo int,
	@IdReportesRoboOcupantes int
BEGIN TRY
	BEGIN TRANSACTION
		IF LTRIM(RTRIM(@IdUnidad)) = ''
			RAISERROR(N'El IdUnidad es un campo requerido',
			16,
			1
			)	
			
			IF 	@IdViaje = 0
			SET @IdViaje = NULL 

		INSERT INTO ProReportesRobo(IdViaje,NombreOperador,Licencia,Telefonos,TipoTractor,ModeloTractor,ColorTractor,SerieTractor,MarcaTractor,PlacasTractor,AnoTractor,CodigoTractor,TipoRemolque,
		ModeloRemolque,ColorRemolque,SerieRemolque,MarcaRemolque,PlacasRemolque,AnoRemolque,CodigoRemolque,NoCartaPorte,DescripcionMercancia,DetallesSiniestro,Ciudad,
		CarreteraAvenida,Kilometro,Coordenadas,Referencias,AutoridadesDependiencia,PersonaAtendioReporte,NoReporteAutoridades,Hora,AutoridadesTelefono,Aseguradora,NoPoliza,
		NoReporteAseguradora,NombreAjustador,TelefonoAjustador,NombreInformante,PuestoInformante,TelefonoInformante,DatosAdicionales,FechaHora,CreadoPor,CreadoEl,IdUnidad) 
		
		VALUES(@IdViaje,@NombreOperador ,@Licencia ,@Telefonos, @TipoTractor ,@ModeloTractor ,@ColorTractor ,@SerieTractor, @MarcaTractor ,@PlacasTractor ,@AnoTractor, @CodigoTractor,@TipoRemolque,
		@ModeloRemolque ,@ColorRemolque,@SerieRemolque ,@MarcaRemolque ,@PlacasRemolque ,@AnoRemolque ,@CodigoRemolque,@NoCartaPorte ,@DescripcionMercancia ,@DetallesSiniestro  ,
		@Ciudad ,@CarreteraAvenida ,@Kilometro  ,@Coordenadas  ,@Referencias  ,@AutoridadesDependiencia ,@PersonaAtendioReporte ,@NoReporteAutoridades ,@Hora,
		@AutoridadesTelefono,@Aseguradora ,@NoPoliza  ,@NoReporteAseguradora ,@NombreAjustador ,@TelefonoAjustador ,@NombreInformante ,@PuestoInformante ,@TelefonoInformante ,
		@DatosAdicionales,@FechaHora,@CreadoPor,@CreadoEl,@IdUnidad)
		
		--agrega ProReportesRoboVehiculosInvolucrados

		SET @IdReportesRobo = (SELECT IDENT_CURRENT('ProReportesRobo'))	 	

		IF @dsProReportesRoboVehiculosInvolucrados IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProReportesRoboVehiculosInvolucrados
		
			SELECT ATT_Marca,ATT_Placas,ATT_Color,ATT_NombreConductor,ATT_Ocupantes, ATT_Otros 
			INTO #TempProReportesRoboVehiculosInvolucrados
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProReportesRobo',2) 
			WITH (ATT_Marca varchar(25),ATT_Placas varchar(25),ATT_Color varchar(25),ATT_NombreConductor varchar(25),ATT_Ocupantes int ,ATT_Otros varchar(25),ATT_IdReportesRobo int)
		
			EXEC sp_xml_removedocument @docHandle
		
			INSERT INTO ProReportesRoboVehiculosInvolucrados(MarcaVehiculo,Placas,Color,NombreConductor,Ocupantes,Otros,IdReportesRobo,CreadoPor,CreadoEl) 
			SELECT ATT_Marca,ATT_Placas,ATT_Color,ATT_NombreConductor,ATT_Ocupantes, ATT_Otros, @IdReportesRobo,@CreadoPor,@CreadoEl      
			FROM #TempProReportesRoboVehiculosInvolucrados                                                
		END					
		IF @dsProReportesRoboCondicionesOcupantes IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProReportesRoboCondicionesOcupantes
		
			SELECT ATT_NombreHerido,ATT_Herido,ATT_Comentarios    
			INTO #TempProReportesRoboCondicionesOcupantes
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CondicionesOcupantes',2) 
			WITH (ATT_NombreHerido varchar(25),ATT_Herido varchar(25),ATT_Comentarios varchar(25),ATT_IdReportesRoboOcupantes int)
		
			EXEC sp_xml_removedocument @docHandle
		
			INSERT INTO ProReportesRoboCondicionesOcupantes(NombreOcupante,Herido,Comentarios,IdReportesRobo,CreadoPor,CreadoEl)  
			SELECT ATT_NombreHerido,ATT_Herido,ATT_Comentarios,@IdReportesRobo,@CreadoPor,@CreadoEl    
			FROM #TempProReportesRoboCondicionesOcupantes                                                  
		END					
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

