CREATE PROCEDURE [dbo].[usp_CatProveedoresIEPSEliminar]
@IdProveedorIEPS int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdProveedorIEPS ,0)= 0
		RAISERROR(N'Identificador de proveedor IEPS es un campo requerido',
			16,
			1
			)

-- Eliminar proveedorIEPS
   DELETE FROM CatProveedoresIEPS	WHERE IdProveedorIEPS  = @IdProveedorIEPS 
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

