
CREATE PROCEDURE [dbo].[usp_ProViajeModificarPQ](	
	@IdViaje int ,
	@IdSucursal int ,
	@NumViajeCliente varchar(10) ,
	@Fecha date ,
	@Hora time(7) ,
	@FechaRegistro  varchar(80),
	@HoraRegistro  varchar(80),
	@IdEstatusViaje int ,
	@CandadoOficial varchar ,
	@Identificador varchar, 
	@idusuariocancelacion int,
	@IdUnidad int,
	@IdRemolque1 int,
	@IdRemolque2 int,
	@IdDolly int
	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @IdGuia int;
		DECLARE @FOLIO int;
		DECLARE @FOLIOSTR varchar(10);		
		DECLARE @TRACKINGSTR varchar(10);
		declare @FechaCancelacion datetime;

		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@IdSucursal, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NumViajeCliente, '') = '' begin
			RAISERROR(N'*INICIO*El numero de viaje cliente es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@IdEstatusViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus del viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
	
		if @IdEstatusViaje = 6 begin
			set @FechaCancelacion = SYSDATETIME();
		end
		else
		begin
			set @idusuariocancelacion = null;
		end
		update ProViajesPQ
		set IdSucursal = @IdSucursal,
		NumViajeCliente = @NumViajeCliente,
		IdEstatusViaje = @IdEstatusViaje,
		CandadoOficial = @CandadoOficial,
		Identificador = @Identificador,
		FechaCancelacion = @FechaCancelacion,
		IdUsuarioCancelacion = @idusuariocancelacion,
		IdUnidad=@IdUnidad, IdRemolque1 = @IdRemolque1,
		IdRemolque2 = @IdRemolque2,
		IdDolly = @IdDolly 
		where IdViaje = @IdViaje;
		IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

