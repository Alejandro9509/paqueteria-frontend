CREATE PROCEDURE [dbo].[usp_CatContenedoresEliminar]
@IdContenedor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdContenedor,0)= 0
			RAISERROR(N'El identificador de contenedor es un campo requerido',
					16,
					1
					)
			
	IF EXISTS(SELECT TOP 1 IdContenedor FROM ProDescargasCombustible WHERE IdContenedor = @IdContenedor)
			RAISERROR(N'El Contenedor tiene descarga de combustible ligados, no es posible eliminarla',
				16,
				1
				)
						
	IF EXISTS(SELECT TOP 1 IdContenedor  FROM ProCargasCombustible WHERE IdContenedor = @IdContenedor)
			RAISERROR(N'El Contenedor tiene cargas de combustible ligados, no es posible eliminarla',
				16,
				1
				)
			
		DELETE CatContenedores
		WHERE 	IdContenedor=@IdContenedor
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

