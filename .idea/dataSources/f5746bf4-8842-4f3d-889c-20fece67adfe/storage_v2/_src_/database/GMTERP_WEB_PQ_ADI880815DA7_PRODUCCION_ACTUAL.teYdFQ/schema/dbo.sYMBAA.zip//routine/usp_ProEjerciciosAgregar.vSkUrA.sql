
CREATE PROCEDURE [dbo].[usp_ProEjerciciosAgregar]

@IdPeticion varchar(100),
@Fecha int
AS
BEGIN TRY
	BEGIN TRANSACTION
	

	IF NOT EXISTS(Select Ejercicio From ProEjerciciosPeriodos where Ejercicio = @Fecha)
insert into ProEjerciciosPeriodos(Ejercicio) values(@Fecha)   

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

