
CREATE PROCEDURE [dbo].[usp_ProDescuentosOperadoresTPersonalAbonosEliminar]
	@IdAbonoDescuentoOperador int,
	@Abono money,
	@IdDescuentoOperador int,
	@IdPeticion varchar(100)

/*************************************************************************************************************************************
Procedimiento almacenado usp_ProDescuentosOperadoresTPersonalAbonosEliminar

Parámetros: 
	@IdAbonoDescuentoOperador int	->(Entrada) Se Utiliza para saber cual Ebono es el que se va a eliminar de la tabla
	@IdDescuentoOperador int		->(Entrada) Se utiliza para tener relación con el catalogo de DescuentosOperadores y poder actualizar el campo de ImporteDescontado correspondiente al descuento del operador, a su vez con esta variable se puede saber la concurrencia del usuario 	
	@Abono money					->(Entrada) Se utiliza o se entiende como el Importe el cual se esta abonando sobre el descuento del operador
	@IdPeticion varchar(100)		->(Entrada) Se utiliza para saber la peticion del proceso en casi de que ocurra algun problema
	

Descripción: Elimina los datos de la tabla de abono segun los datos de entrada y actualiza la tabla CatDescuentosOperadoresTPeronal para cuadre de importes

Implementada por: Francisco Villela
Fecha de implementación: 18/06/2020
Versión: V8 8.0.44.27

Invocada desde: ClsCatDescuentosOperadoresTPersonal
			
******************************************************************************************************************* */

AS
BEGIN TRY
	BEGIN TRANSACTION

		--Verifica que no haya sido Borrado con conterioridad o concurrencia el Descuento que se quiere modificar
		IF NOT EXISTS(SELECT * FROM ProDescuentosOperadoresTPersonalAbonos WHERE IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador)
		Begin
		RAISERROR(N'Se detecto concurrencia de (abono, eliminación o modificación), favor de verificar e intentar nuevamente',
			16,
			1
			) 
		END

		DELETE FROM ProDescuentosOperadoresTPersonalAbonos
		WHERE IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador

		Update CatDescuentosOperadoresTPersonal
		SET ImporteDescontado = ImporteDescontado - @Abono
		Where IdDescuentoOperador = @IdDescuentoOperador
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

