

CREATE PROCEDURE [dbo].[usp_CatUsuariosEliminarPQ]
	@IdUsuario INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdUsuario,0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador del usuario es un campo requerido*FIN*', 16, 1)
			return
		end
		
		DELETE FROM CatUsuarios
		WHERE IdSucursal = @IdUsuario
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

