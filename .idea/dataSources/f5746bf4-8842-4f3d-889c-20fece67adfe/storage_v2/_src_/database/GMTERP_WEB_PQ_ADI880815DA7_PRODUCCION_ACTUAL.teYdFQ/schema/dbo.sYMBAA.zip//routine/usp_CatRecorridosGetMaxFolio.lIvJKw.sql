CREATE PROCEDURE usp_CatRecorridosGetMaxFolio 

AS

SELECT ISNULL(MAX(FolioRecorrido),0)+1 AS FolioRuta FROM CatRecorridos
go

