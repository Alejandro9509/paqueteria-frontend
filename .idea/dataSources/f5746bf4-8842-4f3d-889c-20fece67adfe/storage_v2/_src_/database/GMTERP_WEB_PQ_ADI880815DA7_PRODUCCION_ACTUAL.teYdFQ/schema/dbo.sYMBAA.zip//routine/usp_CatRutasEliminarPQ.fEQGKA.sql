

CREATE PROCEDURE [dbo].[usp_CatRutasEliminarPQ]
	@IdRuta int
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdRuta,0) <= 0 begin			
			RAISERROR(N'*INICIO*Identificador de ruta es un campo requerido*FIN*', 16, 1)			
			return
		end
		DELETE FROM CatRutasPQ
		WHERE IdRuta = @IdRuta
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

