CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosRegistrarPagoConsolidado]
	@Fecha datetime,
	@IdCuentaBancaria int,
	@TipodeMovimiento int,
	@NumeroMovimiento int,
	@NumeroCheque int ,
	@CodigoEstatuCheque int,
	@CreadoPor int,	
	@CreadoEl datetime,
	@NetoAPagar money,
	@TipoCambio money,
	@XMLLiquidaciones varchar(max),
	@XMLLiquidacionesFiscales varchar(max),
	@XMLRecibosPagar varchar(max),
	@IdPeticion varchar(100),
	@FechaCobro datetime

/* *************************************************************************************************
Procedimiento usp_ProMovimientosBancariosRegistrarPagoConsolidado

Parámetros: 
	@Fecha (entrada, Fecha). Fecha del pago consolidado
	@IdCuentaBancaria (entrada, entero). Identificador de la cuenta bancaria
	@TipodeMovimiento (entrada, entero). Tipo de movimiento
	@NumeroMovimiento (entrada, entero). Numero de movimiento
	@NumeroCheque (entrada, entero). Numero de cheque
	@CodigoEstatuCheque (entrada, entero). Codigo del chque
	@CreadoPor (entrada, entero). Usuario que crea el cheque
	@CreadoEl (entrada, fecha hora). Fecha y hora de creacion
	@NetoAPagar (entrada, moneda). Neto a pagar
	@TipoCambio (entrada, moneda). Tipo de cambio
	@XMLLiquidaciones (entrada, texto). XML de liquidaciones
	@XMLLiquidacionesFiscales (entrada, texto). XML de liquidaciones fiscales
	@XMLRecibosPagar (entrada, texto). XML de recibos de nomina
	@IdPeticion (entrada, string). Id de la Petición, generada en WEBDEV
	@FechaCobro (entrada, fecha). Fecha de cobro

Descripción: Procedimiento para registrar un pago concoliado

06/11/2020 - Se agrego el flujo de asignarle una fecha de cobro a los movimientos bancarios y cheques

Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 06/11/2020
Versión ERP: 8.0.56.12

Invocada desde: PAGE_ProMovimientosBancariosPagoConsolidado (Solicitud 3393)
***************************************************************************************************** */
AS
DECLARE 
	@IdCheque int,
	@Concepto varchar(150),
	@Beneficiario varchar(150),
	@IdMovimientoBancario  int,
	@IdTipoMovimientoBancario int,
	@IdEstatuCheque int,
	@NumeroBeneficiario int,
	@IdBeneficiario int,
	@NroCuentaPago varchar(50),
	@MetodoPago varchar(50),
	@FolioLiquidacion varchar(150),
	@ClaveMetodoPago varchar(5),
	@ATT_IdLiquidacion int,
	@ATT_Folio varchar(150),
	@ATT_IdBancoOperador int,
	@ATT_CuentaBancaria varchar(21),
	@ATT_IdLiquidacionFiscal int,
	@ATT_IdNominaRecibo int,
	@ATT_IdEmpleado int,
	@ATT_ReferenciaPago Varchar(150),
	@FechaPago datetime,
	@FechaTimbrado Datetime,
	@docHandle int,
	@Contador int = 1,
	@Mensaje varchar(150)
BEGIN TRY
	BEGIN TRANSACTION
	
	SET @IdCheque = Null
	IF @XMLLiquidaciones != ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLLiquidaciones
             
			SELECT ATT_IdLiquidacion, ATT_Folio
			INTO #TempLiquidaciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Liquidaciones',3) 
			WITH (ATT_IdLiquidacion int, ATT_Folio varchar(150))

			EXEC sp_xml_removedocument @docHandle
			DECLARE LiquidacionesPagarCursor CURSOR FOR
			SELECT * FROM #TempLiquidaciones

			OPEN LiquidacionesPagarCursor
			FETCH NEXT FROM LiquidacionesPagarCursor
			INTO @ATT_IdLiquidacion, @ATT_Folio
		
			WHILE @@FETCH_STATUS = 0
			BEGIN
				-----validaciones
				IF ISDATE((Select AutorizadaEl From ProLiquidaciones WHERE IdLiquidacion =  @ATT_IdLiquidacion)) = 0
				BEGIN
					SET @Mensaje = 'La liquidación '+@ATT_Folio+' no está autorizada para registrar pago'
					RAISERROR(@Mensaje, 16, 1)
				END	
				IF  ISNULL((Select IdMovimientoBancario  from ProLiquidaciones WHERE IdLiquidacion =  @ATT_IdLiquidacion),0) > 0 OR ISDATE((Select PagadoEl  from ProLiquidaciones WHERE IdLiquidacion =  @ATT_IdLiquidacion)) <> 0 
				BEGIN
					set @Mensaje = 'La liquidación '+@ATT_Folio+' ya fué pagada por otro usuario'
					RAISERROR(@Mensaje, 16, 1)
				END

				FETCH NEXT FROM LiquidacionesPagarCursor
				INTO @ATT_IdLiquidacion, @ATT_Folio
			END

			CLOSE LiquidacionesPagarCursor
			DEALLOCATE LiquidacionesPagarCursor
		END

	IF ISDATE(@Fecha) = 0
		RAISERROR(N'Fecha es un campo requerido', 16, 1)

	IF ISDATE(@FechaCobro) = 0
		RAISERROR(N'Fecha de cobro es un campo requerido', 16, 1)
			
	IF ISNULL(@IdCuentaBancaria,0) <= 0
		RAISERROR(N'El identificador de cuenta bancaria es un campo requerido', 16, 1)	
	
	IF ISNULL(@TipodeMovimiento,0) <= 0
		RAISERROR(N'Tipo de movimiento es un campo requerido', 16, 1)
	
	IF ISNULL(@TipoCambio,0)= 0
		RAISERROR(N'Tipo de cambio es un campo requerido', 16, 1)

	Select @IdBeneficiario = (Select IdBeneficiario  from CatBeneficiarios where RTRIM(LTRIM(Nombre)) = RTRIM(LTRIM('PAGO CONSOLIDADO')))
	SET @Beneficiario = 'PAGO CONSOLIDADO'
	IF  ISNULL(@IdBeneficiario ,0) = 0 
		BEGIN
			SELECT @NumeroBeneficiario = (SELECT ISNULL(MAX(NumeroBeneficiario),0)+1 AS Codigo FROM CatBeneficiarios)
			INSERT INTO CatBeneficiarios(NumeroBeneficiario,Nombre,CreadoEl,CreadoPor,Activo)
			VALUES(@NumeroBeneficiario,RTRIM(LTRIM('PAGO CONSOLIDADO')),@CreadoEl,@CreadoPor,1)
			SET @IdBeneficiario = (SELECT IDENT_CURRENT('CatBeneficiarios'))	 
		END
									
    --- Generar cheque
    IF @TipodeMovimiento = 1 --- CHEQUE 
		BEGIN
			Select @IdTipoMovimientoBancario = 2 -- Cheque
			Select @IdEstatuCheque = IdEstatuCheque From CatEstatusCheques where Codigo = @CodigoEstatuCheque 
		
			IF ISNULL(@NumeroCheque,0) = 0
				RAISERROR(N'Número de cheque es un campo requerido', 16, 1)
			-- valida que el número de cheque no este usado
			IF EXISTS(Select NumeroCheque from ProCheques where NumeroCheque  = @NumeroCheque AND IdCuentaBancaria = @IdCuentaBancaria)
				RAISERROR(N'El Número de cheque ya fue utilizado por otro usuario, se le asignará el siguiente número de cheque disponible, revise la información y vuelva hacer click en aceptar', 16, 1)
			--- Registrar cheque		
			SET @Concepto = 'PAGO CONSOLIDADO'
			INSERT INTO ProCheques (NumeroCheque,Fecha,IdCuentaBancaria,TipoCambio,Concepto,Beneficiario,Importe,IdEstatuCheque,TipoBeneficiario,IdBeneficiario,FechaCobro,CreadoPor,CreadoEl)
			VALUES(@NumeroCheque,@Fecha,@IdCuentaBancaria,@TipoCambio,@Concepto,RTRIM(LTRIM(@Beneficiario)),@NetoAPagar,@IdEstatuCheque,2,@IdBeneficiario,@FechaCobro,@CreadoPor,@CreadoEl)
			--- Registrar Movimiento Bancario
			SET @IdCheque = (SELECT IDENT_CURRENT('ProCheques'))
		
			SET @MetodoPago = 'CHEQUE NOMINATIVO'
			SET @ClaveMetodoPago = '02'
			SET @NumeroMovimiento =(SELECT ISNULL(MAX(NumeroMovimiento),0)+1 AS NumeroMovimiento from ProMovimientosBancarios where IdCuentaBancaria = @IdCuentaBancaria)
		END
	ELSE
		BEGIN -- TRANSFERENCIA
			PRINT N' trans';
			SET @MetodoPago = 'TRANSFERENCIA ELECTRÓNICA DE FONDOS'	
			SELECT @IdTipoMovimientoBancario = 3 -- Retiro por transferencia
			SET @ClaveMetodoPago = '03'
			IF ISNULL(@NumeroMovimiento, 0) = 0
				RAISERROR(N'Número de movimiento bancario es un campo requerido', 16, 1)

			-- valida que el número de mov. bancario no este usado
			IF EXISTS(Select NumeroMovimiento from ProMovimientosBancarios where NumeroMovimiento = @NumeroMovimiento AND IdCuentaBancaria = @IdCuentaBancaria)
				RAISERROR(N'El Número de movimiento bancario ya fue utilizado por otro usuario, se le asignará el siguiente número de movimiento bancario disponible, revise la información y vuelva hacer click en aceptar', 16, 1)
			-- si el importe a pagar es negativo poner cero
			IF @NetoAPagar < 0
				SET @NetoAPagar = 0
		END
	
	--- Registrar Movimiento Bancario // SOLICITUD 11919  - Se agrego el campo PagoConsolidadoBancos para diferenciar el pago cosolidado de cobranza del operacional al realziar pasivos. 

	INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,TipoCambio,ReferenciaBancaria,IdTipoMovimientoBancario,CreadoPor,CreadoEl,IdCheque,TipoBeneficiario,IdBeneficiario,Beneficiario,PagoConsolidadoBancos,FechaCobro) --ultimo dato PagoConsolidadoBancos SOL. 11919
	VALUES (@NumeroMovimiento,@Fecha,@IdCuentaBancaria,@NetoAPagar,@TipoCambio, 'PAGO CONSOLIDADO',@IdTipoMovimientoBancario,@CreadoPor,@CreadoEl,@IdCheque,2,@IdBeneficiario,RTRIM(LTRIM(@Beneficiario)),1,@FechaCobro) -- ultimo dato PagoConsolidadoBancos SOL. 11919
		
	SET @IdMovimientoBancario = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))
	--- Registrar número de movimiento bancario en anticipo 	
		
	SET @NroCuentaPago = (SELECT NumeroCuenta FROM CatCuentasBancarias WHERE IdCuentaBancaria = @IdCuentaBancaria)		   
	
	IF @XMLLiquidaciones != '' --LIQUIDACIONES
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLLiquidaciones

		SELECT ATT_IdLiquidacion, ATT_Folio, ATT_IdBancoOperador, ATT_CuentaBancaria
		INTO #TempLiquidaciones2
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Liquidaciones',3) 
		WITH (ATT_IdLiquidacion int, ATT_Folio varchar, ATT_IdBancoOperador int , ATT_CuentaBancaria varchar(21))

		EXEC sp_xml_removedocument @docHandle
		DECLARE LiquidacionesPagarCursor CURSOR FOR
		SELECT * FROM #TempLiquidaciones2

		OPEN LiquidacionesPagarCursor
		FETCH NEXT FROM LiquidacionesPagarCursor
		INTO @ATT_IdLiquidacion, @ATT_Folio, @ATT_IdBancoOperador ,@ATT_CuentaBancaria
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			UPDATE ProLiquidaciones SET
			   IdMovimientoBancario =  	@IdMovimientoBancario,
			   IdBancoOperador = @ATT_IdBancoOperador, 
			   NumeroCuentaBancariaOperador = @ATT_CuentaBancaria,
			   MetodoPago = @MetodoPago,
			   NroCuentaPago = @NroCuentaPago,
			   ClaveMetodoPago = @ClaveMetodoPago
			WHERE  IdLiquidacion =  @ATT_IdLiquidacion

			FETCH NEXT FROM LiquidacionesPagarCursor
			INTO @ATT_IdLiquidacion, @ATT_Folio, @ATT_IdBancoOperador ,@ATT_CuentaBancaria
		END

		CLOSE LiquidacionesPagarCursor
		DEALLOCATE LiquidacionesPagarCursor	
	END
	
	IF @XMLLiquidacionesFiscales != '' --LIQUIDACIONES FISCALES
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLLiquidacionesFiscales

		SELECT ATT_IdLiquidacionFiscal, ATT_Folio, ATT_IdBancoOperador, ATT_CuentaBancaria
		INTO #TempLiquidacionesFiscales
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_LiquidacionesFiscales',3) 
		WITH (ATT_IdLiquidacionFiscal int, ATT_Folio varchar, ATT_IdBancoOperador int , ATT_CuentaBancaria varchar(21))

		EXEC sp_xml_removedocument @docHandle
		DECLARE LiquidacionesFiscalesPagarCursor CURSOR FOR
		SELECT * FROM #TempLiquidacionesFiscales

		OPEN LiquidacionesFiscalesPagarCursor
		FETCH NEXT FROM LiquidacionesFiscalesPagarCursor
		INTO @ATT_IdLiquidacionFiscal, @ATT_Folio, @ATT_IdBancoOperador ,@ATT_CuentaBancaria
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF  ISNULL((Select IdMovimientoBancario  from ProLiquidacionesFiscales WHERE IdLiquidacionFiscal =  @ATT_IdLiquidacionFiscal),0) > 0
			BEGIN
				SET @Mensaje = 'La liquidación '+@ATT_Folio+' ya fué pagada por otro usuario'
				RAISERROR(@Mensaje, 16, 1)
			END	

			UPDATE ProLiquidacionesFiscales SET
			   IdMovimientoBancario =  	@IdMovimientoBancario,
			   IdBancoOperador = @ATT_IdBancoOperador, 
			   NumeroCuentaBancariaOperador = @ATT_CuentaBancaria,
			   MetodoPago = @MetodoPago,
			   NroCuentaPago = @NroCuentaPago,
			   ClaveMetodoPago = @ClaveMetodoPago
			WHERE  IdLiquidacionFiscal =  @ATT_IdLiquidacionFiscal

			FETCH NEXT FROM LiquidacionesFiscalesPagarCursor
			INTO @ATT_IdLiquidacionFiscal, @ATT_Folio, @ATT_IdBancoOperador ,@ATT_CuentaBancaria
		END

		CLOSE LiquidacionesFiscalesPagarCursor
		DEALLOCATE LiquidacionesFiscalesPagarCursor
	END
	
	IF @XMLRecibosPagar != '' --RECIBOS DE NOMINA
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLRecibosPagar 
	
		SELECT ATT_IdNominaRecibo,ATT_IdEmpleado,ATT_ReferenciaPago,ATT_CuentaBancaria
		INTO #TempRecibosPagar
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_RecibosPagar',2) 
		WITH (ATT_IdNominaRecibo int,ATT_IdEmpleado int,ATT_ReferenciaPago Varchar(150),ATT_CuentaBancaria Varchar(21))
	
		EXEC sp_xml_removedocument @docHandle
	
		DECLARE RECIBOSPAGAR_Cursor CURSOR FOR
		SELECT * FROM #TempRecibosPagar
	
		OPEN RECIBOSPAGAR_Cursor
		FETCH NEXT FROM RECIBOSPAGAR_Cursor
		INTO @ATT_IdNominaRecibo,@ATT_IdEmpleado,@ATT_ReferenciaPago,@ATT_CuentaBancaria
	
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @FechaPago=FechaPago,@FechaTimbrado=FechaTimbrado,@ATT_IdEmpleado = IdEmpleado, @NetoAPagar = NetoPagar FROM ProNominasRecibo Where IdNominaRecibo = @ATT_IdNominaRecibo
			SET @ATT_ReferenciaPago = ('RECIBO:'+CONVERT(VARCHAR(10),(Select Codigo from CatEmpleados where IdEmpleado=@ATT_IdEmpleado))+'-'+ (Select Nombre From CatEmpleados Where IdEmpleado=@ATT_IdEmpleado) )
			IF ISNULL((Select IdMovimientoBancario  from ProNominasRecibo WHERE IdNominaRecibo =  @ATT_IdNominaRecibo),0) > 0 
				RAISERROR(N'El recibo ya esta pagado', 16, 1)	
			
			IF @FechaTimbrado IS NOT NULL -- si el recibo ya fue timbrado
				IF @FechaPago IS NOT NULL
					UPDATE ProNominasRecibo Set FechaEfectivaPago = @FechaPago Where IdNominaRecibo = @ATT_IdNominaRecibo
				ELSE
					UPDATE ProNominasRecibo Set FechaEfectivaPago = @FechaTimbrado Where IdNominaRecibo = @ATT_IdNominaRecibo
			ELSE
				UPDATE ProNominasRecibo Set FechaEfectivaPago = @Fecha Where IdNominaRecibo = @ATT_IdNominaRecibo			

			UPDATE ProNominasRecibo SET
			   IdMovimientoBancario =  	@IdMovimientoBancario,   
			   IdBancoOperador = @ATT_IdBancoOperador, 
			   NumeroCuentaBancariaOperador = @ATT_CuentaBancaria,
			   MetodoPago = @MetodoPago,
			   NroCuentaPago = @NroCuentaPago,
			   ClaveMetodoPago = @ClaveMetodoPago
			WHERE  IdNominaRecibo =  @ATT_IdNominaRecibo

			FETCH NEXT FROM RECIBOSPAGAR_Cursor
			INTO @ATT_IdNominaRecibo,@ATT_IdEmpleado,@ATT_ReferenciaPago,@ATT_CuentaBancaria
		END

		CLOSE RECIBOSPAGAR_Cursor
		DEALLOCATE RECIBOSPAGAR_Cursor
	END
    --seccion para agregar el idmovimientobancario a paremtros y poder obtenerlo de lado del web
    IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancario' AND IdUsuario = @CreadoPor)
		INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoBancario',@IdMovimientoBancario,@CreadoPor)
    ELSE
		UPDATE SisParametrosPagina SET Parametros = @IdMovimientoBancario WHERE Pagina = 'IdMovimientoBancario' AND IdUsuario = @CreadoPor
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

