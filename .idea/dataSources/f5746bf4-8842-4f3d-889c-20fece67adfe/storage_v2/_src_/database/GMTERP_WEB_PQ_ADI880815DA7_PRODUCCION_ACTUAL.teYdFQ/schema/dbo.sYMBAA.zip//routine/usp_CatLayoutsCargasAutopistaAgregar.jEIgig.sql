CREATE PROCEDURE [dbo].[usp_CatLayoutsCargasAutopistaAgregar]
	@Layout	varchar(50),
	@Separador	varchar(1),
	@TieneEncabezado	bit,
	@RenglonInicial	tinyint,
	@ColumnaTarjeta	tinyint,
	@ColumnaFecha	tinyint,
	@FormatoFecha	varchar(15),
	@ColumnaHora	tinyint,
	@FormatoHora	varchar(15),
	@ColumnaClase	tinyint,
	@ColumnaImporte	tinyint,
	@ColumnaCaseta	tinyint,
	@ColumnaCasetaIncluyeCarril	bit,
	@ColumnaCarril	tinyint,
	@CreadoEl	datetime,
	@CreadoPor	int,
	@IdPeticion varchar(100),
	@TipoArchivo tinyint,
	@FechaHoraJuntas bit,
	@ColumnaFechaHora tinyint,
	@FormatoFechaHora varchar(26),
	@ColumnaCasetaLayoutVPAS bit
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
	
		INSERT INTO CatLayoutsCargasAutopista(ColumnaCarril,ColumnaCaseta,ColumnaCasetaIncluyeCarril,ColumnaClase,ColumnaFecha,ColumnaHora,ColumnaImporte,ColumnaTarjeta,CreadoEl,CreadoPor,FormatoFecha,FormatoHora,Layout,RenglonInicial,Separador,TieneEncabezado,TipoArchivo,FechaHoraJuntas,ColumnaFechaHora,FormatoFechaHora,ColumnaCasetaLayoutVPAS)
		VALUES(@ColumnaCarril,@ColumnaCaseta,@ColumnaCasetaIncluyeCarril,@ColumnaClase,@ColumnaFecha,@ColumnaHora,@ColumnaImporte,@ColumnaTarjeta,@CreadoEl,@CreadoPor,@FormatoFecha,@FormatoHora,@Layout,@RenglonInicial,@Separador,@TieneEncabezado,@TipoArchivo,@FechaHoraJuntas,@ColumnaFechaHora,@FormatoFechaHora,@ColumnaCasetaLayoutVPAS)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

