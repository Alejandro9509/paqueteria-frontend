
CREATE PROCEDURE [dbo].[usp_CatConvenioAgregarPQ](
	@IdCliente int,
	@Vigencia varchar(80),
	@Activo bit,
	@CuotaMensual money
)
AS
BEGIN
	BEGIN TRANSACTION
	DECLARE @VigenciaDate date;
		IF ISNULL(@IdCliente, 0) = 0 begin
			RAISERROR(N'*INICIO*El cliente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF @Vigencia IS NOT NULL AND LEN(@Vigencia) > 0 begin
			set @VigenciaDate = CAST(@Vigencia as date)
		end
		
		INSERT INTO CatConveniosPQ (IdCliente,Vigencia,activo,CuotaMensual)
		Values (@IdCliente, @VigenciaDate, @Activo,@CuotaMensual)
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

