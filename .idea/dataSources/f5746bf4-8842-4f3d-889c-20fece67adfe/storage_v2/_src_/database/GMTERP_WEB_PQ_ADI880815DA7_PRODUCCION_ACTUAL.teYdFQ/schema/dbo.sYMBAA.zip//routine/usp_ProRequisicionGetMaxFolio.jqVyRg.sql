CREATE PROCEDURE [dbo].[usp_ProRequisicionGetMaxFolio]    
AS    
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProRequisicion
go

