CREATE PROCEDURE [dbo].[usp_ProCostoArticuloReset]
@Codigo int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@Codigo,0)= 0
	RAISERROR(N'El codigo del Articulo es un campo requerido',
			16,
			1
			)

			
		DELETE ProCostoArticulo	
		WHERE 	Codigo = @Codigo
		AND Estatus = 2
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

