

	CREATE PROCEDURE [dbo].[usp_ProCotizadorModificarEstatus]
	@IdCotizacion	int,
	@Rutas      VARCHAR(1000),-- Cadena de tokens que contiene el conjunto de rutas que se relacionan con la cotizacion
	@IdPeticion varchar(100)	
	AS
	SET NOCOUNT ON

	BEGIN TRY
		BEGIN TRANSACTION
		IF ISNULL(@IdCotizacion, 0) = 0
			RAISERROR(N'El código de la Cotización es un campo requerido', 16, 1)
		IF ISNULL(@Rutas, '') = ''
			RAISERROR(N'Las Rutas a relacionar con la Cotización son requeridas', 16, 1)
			
			
			--El separador de nuestros parametros deberá ser una coma ","
			DECLARE @Posicion int
			--@Posicion es la posicion de cada uno de nuestros separadores
			DECLARE @Ruta varchar(1000)
			--@Ruta es cada una de las rutas (token) de los valores en @Rutas
			SET @Rutas = @Rutas + ','
			--Colocamos un separador al final de los parametros para un funcionamiento correcto
			--Hacemos un Ciclo que se repite mientras haya separadores
			WHILE patindex('%,%' , @Rutas) <> 0
			--patindex busca un patron en una cadena y nos devuelve su posicion
			BEGIN
			   SELECT @Posicion =  patindex('%,%' , @Rutas)
			   --Buscamos la posicion de la primera ,
			   SELECT @Ruta = left(@Rutas, @Posicion - 1)
			   --Y obtenemos una subcadena hasta la posicion de la coma
			   
			   UPDATE ProCotizacionesRutas SET Estatus = 1 WHERE IdCotizacion = @IdCotizacion AND IdCotizacionRuta = @Ruta
			  
			   -- Reemplazamos la cadena extraida con nada mediante la funcion stuff
			   -- es equivalente a borrar o retirar la subcadena de la cadena
			   SELECT @Rutas = stuff(@Rutas, 1, @Posicion, '')
			   -- Retornamos al inicio del ciclo
			END
			--Y cuando se han recorrido todos los parametros terminamos la tranacción exitosa

		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

