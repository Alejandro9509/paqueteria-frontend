
CREATE PROCEDURE [dbo].[usp_CatRutasPersonalEliminar]
	@IdRutaPersonal int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdRutaPersonal,0) <= 0	
		RAISERROR(N'La ruta es un campo requerido',
			16,
			1
			)	
	IF EXISTS(SELECT TOP 1 * FROM ProRecorridos WHERE IdRutaPersonal = @IdRutaPersonal)
		RAISERROR(N'La ruta tiene recorridos ligados, no es posible eliminarlo',
			16,
			1
			)
					
	DELETE FROM CatRutasPersonal
	WHERE IdRutaPersonal = @IdRutaPersonal
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

