CREATE PROCEDURE [dbo].[usp_ProLlantasRegistrar]
@NumeroEconomico varchar(20),
@IdModeloLlanta int,
@IdMarcaLlanta int,
@IdMedidaLlanta int,
@IdTipoLlanta int,
@ProfundidadOriginal decimal (10, 2),
@ProfundidadMinima  decimal (10, 2),
@PresionMaxima  decimal (10, 2),
@PresionMinima  decimal (10, 2),
@ProfundidadActual  decimal (10, 2),
@PresionActual  decimal (10, 2),
@IdEstatuLlanta int,
@DisponibleDesde datetime,
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100),
@CostoLlanta money,
@VidaUtil int,
@IdArticulo int,
@PendienteEtiqueta bit,
@IdCompra int,
@CostoLlantaDlls money,
@TipoCambio money,
@FechaRegistro datetime
AS
DECLARE	
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	IF isdate(@FechaRegistro) = 0
		RAISERROR(N'Fecha de registro es un campo requerido',
			16,
			1
			)
								
	IF isnull(@NumeroEconomico,'') =''
		RAISERROR(N'El numero económico de la llanta es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT NumeroEconomico  FROM ProLlantas WHERE NumeroEconomico  = @NumeroEconomico )
		RAISERROR(N'El numero económico de la llanta ya existe',
			16,
			1
			)
			
	IF isnull(@IdModeloLlanta,0) = 0 
		RAISERROR(N'Identificador de modelo es un campo requerido',
			16,
			1
			)	
	
	IF isnull(@IdMarcaLlanta,0) = 0 
		RAISERROR(N'Identificador de marca es un campo requerido',
			16,
			1
			)

	IF isnull(@IdMedidaLlanta,0) = 0 
		RAISERROR(N'Identificador de medida es un campo requerido',
			16,
			1
			)
							
	IF ISNULL(@IdArticulo,0) = 0
	SET @IdArticulo = NULL
	
	IF ISNULL(@IdCompra,0) = 0
	SET @IdCompra = NULL
				
							
	INSERT INTO ProLlantas (NumeroEconomico,IdModeloLlanta,IdMarcaLlanta,IdMedidaLlanta,IdTipoLlanta,ProfundidadOriginal,ProfundidadMinima,PresionMaxima,PresionMinima,ProfundidadActual,PresionActual,IdEstatuLlanta,DisponibleDesde,CreadoPor,CreadoEl,CostoLlanta,VidaUtil,IdArticulo,PendienteEtiqueta,IdCompra,CostoLlantaDlls,TipoCambio,FechaRegistro) VALUES
						   (@NumeroEconomico,@IdModeloLlanta,@IdMarcaLlanta,@IdMedidaLlanta,@IdTipoLlanta,@ProfundidadOriginal,@ProfundidadMinima,@PresionMaxima,@PresionMinima,@ProfundidadActual,@PresionActual,@IdEstatuLlanta,@DisponibleDesde,@CreadoPor,@CreadoEl,@CostoLlanta,@VidaUtil,@IdArticulo,@PendienteEtiqueta,@IdCompra,@CostoLlantaDlls,@TipoCambio,@FechaRegistro) 
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

