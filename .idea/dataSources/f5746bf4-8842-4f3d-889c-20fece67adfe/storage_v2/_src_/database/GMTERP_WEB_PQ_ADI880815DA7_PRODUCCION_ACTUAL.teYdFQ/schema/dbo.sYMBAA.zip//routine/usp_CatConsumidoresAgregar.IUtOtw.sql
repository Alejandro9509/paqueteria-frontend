
	CREATE PROCEDURE [dbo].[usp_CatConsumidoresAgregar]
		@Codigo	varchar(20),	
		@Consumidor	varchar(100),	
		@Activo bit,
		@CreadoEl	datetime,	
		@CreadoPor	int,
		@IdPeticion varchar(100)
	AS
	BEGIN TRY
		BEGIN TRANSACTION
		IF ISNULL(@Codigo,0)= 0
			RAISERROR(N'El código del Consumidor es un campo requerido',
				16,
				1
				)
				
		IF EXISTS(SELECT Codigo FROM CatConsumidores WHERE Codigo = @Codigo)
			RAISERROR(N'El código del Consumidor ya existe',
				16,
				1
				)	
						
		IF ISNULL(@Consumidor,'')= ''
			RAISERROR(N'El nombre del Consumidor es un campo requerido',
				16,
				1
				)
				
		INSERT INTO CatConsumidores(Codigo,Consumidor,Activo,CreadoEl,CreadoPor)
		VALUES(@Codigo,@Consumidor,@Activo,@CreadoEl,@CreadoPor)
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

