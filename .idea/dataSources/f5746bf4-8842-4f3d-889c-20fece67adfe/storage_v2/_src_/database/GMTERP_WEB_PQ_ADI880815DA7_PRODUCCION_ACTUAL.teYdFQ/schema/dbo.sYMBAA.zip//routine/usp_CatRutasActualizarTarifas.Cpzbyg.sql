
CREATE PROCEDURE [dbo].[usp_CatRutasActualizarTarifas]
@dsCatRutasTrayectosPermisionarios	text,
@ModificadoEl	datetime,	
@ModificadoPor	int,	
@IdPeticion varchar(100)	
AS
Declare
@docHandle int,
@ATT_IdRutaTrayectoPermisionario int,
@ATT_IdOperador int,
@ATT_SueldoBaseSencilloCargado money,
@ATT_SueldoBaseFullCargado money,
@ATT_SueldoBaseFullVacioCargado_CargadoVacio money,
@ATT_SueldoBaseSencilloVacio money,
@ATT_SueldoBaseFullVacio money, 
@ATT_SueldoBaseDllsSencilloCargado money,
@ATT_SueldoBaseDllsFullCargado money,
@ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio money,
@ATT_SueldoBaseDllsSencilloVacio money,
@ATT_SueldoBaseDllsFullVacio money

BEGIN TRY
	BEGIN TRANSACTION
	
	
	IF @dsCatRutasTrayectosPermisionarios IS NULL
		RAISERROR(N'No hay permisionarios asignados en el trayecto seleccionado.',
			16,
			1
			)
			
	IF @dsCatRutasTrayectosPermisionarios IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectosPermisionarios
             
			SELECT ATT_IdRutaTrayectoPermisionario,ATT_IdOperador,
			ATT_SueldoBaseDllsFullVacio,ATT_SueldoBaseDllsSencilloVacio,ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,
			ATT_SueldoBaseDllsFullCargado,ATT_SueldoBaseDllsSencilloCargado,ATT_SueldoBaseFullVacio,ATT_SueldoBaseSencilloVacio,
			ATT_SueldoBaseFullVacioCargado_CargadoVacio,ATT_SueldoBaseFullCargado,ATT_SueldoBaseSencilloCargado
			INTO #TempRutasTrayectosPermisionarios
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosPermisionarios',3) 
			WITH (ATT_IdRutaTrayectoPermisionario int,ATT_IdOperador int,
			ATT_SueldoBaseDllsFullVacio money,ATT_SueldoBaseDllsSencilloVacio money,ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio money,
			ATT_SueldoBaseDllsFullCargado money,ATT_SueldoBaseDllsSencilloCargado money,ATT_SueldoBaseFullVacio money,ATT_SueldoBaseSencilloVacio money,
			ATT_SueldoBaseFullVacioCargado_CargadoVacio money,ATT_SueldoBaseFullCargado money,ATT_SueldoBaseSencilloCargado money)

			EXEC sp_xml_removedocument @docHandle
			DECLARE RutasTrayectosPermisionariosCursor CURSOR FOR
			SELECT * FROM #TempRutasTrayectosPermisionarios

			OPEN RutasTrayectosPermisionariosCursor
			FETCH NEXT FROM RutasTrayectosPermisionariosCursor
			INTO @ATT_IdRutaTrayectoPermisionario,@ATT_IdOperador ,
			@ATT_SueldoBaseDllsFullVacio ,@ATT_SueldoBaseDllsSencilloVacio,@ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,
			@ATT_SueldoBaseDllsFullCargado ,@ATT_SueldoBaseDllsSencilloCargado ,@ATT_SueldoBaseFullVacio,@ATT_SueldoBaseSencilloVacio,
			@ATT_SueldoBaseFullVacioCargado_CargadoVacio ,@ATT_SueldoBaseFullCargado ,@ATT_SueldoBaseSencilloCargado
		
			WHILE @@FETCH_STATUS = 0
			BEGIN
			
				IF EXISTS((Select IdRutaTrayectoPermisionario From CatRutasTrayectosPermisionarios WHERE IdRutaTrayectoPermisionario = @ATT_IdRutaTrayectoPermisionario AND IdOperador = @ATT_IdOperador))
				BEGIN
					UPDATE CatRutasTrayectosPermisionarios
					SET
					SueldoBaseDllsFullVacio = @ATT_SueldoBaseDllsFullVacio ,
					SueldoBaseDllsSencilloVacio = @ATT_SueldoBaseDllsSencilloVacio,
					SueldoBaseDllsFullVacioCargado_CargadoVacio = @ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,
					SueldoBaseDllsFullCargado = @ATT_SueldoBaseDllsFullCargado ,
					SueldoBaseDllsSencilloCargado = @ATT_SueldoBaseDllsSencilloCargado ,
					SueldoBaseFullVacio = @ATT_SueldoBaseFullVacio,
					SueldoBaseSencilloVacio = @ATT_SueldoBaseSencilloVacio,
					SueldoBaseFullVacioCargado_CargadoVacio  = @ATT_SueldoBaseFullVacioCargado_CargadoVacio ,
					SueldoBaseFullCargado = @ATT_SueldoBaseFullCargado ,
					SueldoBaseSencilloCargado = @ATT_SueldoBaseSencilloCargado
					WHERE
					IdRutaTrayectoPermisionario = @ATT_IdRutaTrayectoPermisionario
					AND IdOperador = @ATT_IdOperador
				END	

			FETCH NEXT FROM RutasTrayectosPermisionariosCursor
				INTO @ATT_IdRutaTrayectoPermisionario,@ATT_IdOperador ,
				@ATT_SueldoBaseDllsFullVacio ,@ATT_SueldoBaseDllsSencilloVacio,@ATT_SueldoBaseDllsFullVacioCargado_CargadoVacio,
				@ATT_SueldoBaseDllsFullCargado ,@ATT_SueldoBaseDllsSencilloCargado ,@ATT_SueldoBaseFullVacio,@ATT_SueldoBaseSencilloVacio,
				@ATT_SueldoBaseFullVacioCargado_CargadoVacio ,@ATT_SueldoBaseFullCargado ,@ATT_SueldoBaseSencilloCargado
			END

			CLOSE RutasTrayectosPermisionariosCursor
			DEALLOCATE RutasTrayectosPermisionariosCursor
			
		END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

