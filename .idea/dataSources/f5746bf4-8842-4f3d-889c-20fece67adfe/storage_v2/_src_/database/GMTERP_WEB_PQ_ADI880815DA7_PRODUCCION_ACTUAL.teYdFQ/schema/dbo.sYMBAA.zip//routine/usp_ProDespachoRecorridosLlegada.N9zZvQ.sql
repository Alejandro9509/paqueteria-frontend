
CREATE PROCEDURE [dbo].[usp_ProDespachoRecorridosLlegada]
	@IdRecorridoDespacho int,
	@IdEstatuViaje int,	
	@Llegada datetime,		
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@EstatusGeneradoAutomaticamente bit = 0
AS	
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdRecorridoDespacho,0) = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdEstatuViaje,0) = 0
		RAISERROR(N'El estatus del recorrido es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@Llegada) = 0
		RAISERROR(N'La fecha y hora de llegada es un campo requerido',
			16,
			1
			)

	IF (SELECT FechaSalida FROM ProRecorridosDespacho WHERE IdRecorridoDespacho = @IdRecorridoDespacho) > @Llegada		
		RAISERROR(N'La fecha de llegada no puede ser menor a la fecha salida',
			16,
			1
			)

	IF EXISTS(SELECT FechaLlegada FROM ProRecorridosDespacho WHERE IdRecorridoDespacho = @IdRecorridoDespacho AND FechaLlegada IS NOT NULL)--tiene llegada
			RAISERROR(N'No se puede dar llegada a este recorrido porque ya tiene llegada',
				16,
				1
				)
	
	UPDATE ProRecorridosDespacho SET
		FechaLlegada = @Llegada,		
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		IdEstatuViaje = @IdEstatuViaje,
		FechaHoraRecorridoEstatus = @Llegada		
	WHERE IdRecorridoDespacho = @IdRecorridoDespacho
	
	INSERT INTO ProRecorridosDespachoEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatusViaje,IdRecorridoDespacho,GeneradoAutomaticamente)
	VALUES(@ModificadoEl,@ModificadoPor,@Llegada,@IdEstatuViaje,@IdRecorridoDespacho,@EstatusGeneradoAutomaticamente)
	
				
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

