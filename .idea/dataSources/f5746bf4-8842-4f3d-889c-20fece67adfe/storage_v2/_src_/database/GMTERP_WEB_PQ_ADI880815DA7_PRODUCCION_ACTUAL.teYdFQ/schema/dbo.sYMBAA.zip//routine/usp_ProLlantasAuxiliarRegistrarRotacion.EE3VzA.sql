CREATE PROCEDURE [dbo].[usp_ProLlantasAuxiliarRegistrarRotacion]
@FechaHora datetime,
@IdUnidad int,
-- rotar 1
@IdLlantaRotar1 int,
@NumeroPosicionLlantaRotar1 int,
@KilometrajeDeLLantaRotar1 int,
@CostoParaUnidadRotar1 money,
@KilometrajeHistoricoRotar1 int,
-- rotar 2
@IdLlantaRotar2 int,
@NumeroPosicionLlantaRotar2 int,
@KilometrajeDeLLantaRotar2 int,
@CostoParaUnidadRotar2 money,
@KilometrajeHistoricoRotar2 int,
--
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100)
AS
DECLARE 
	@MessageError varchar(8000),
	@IdProcesoLlantaDesasignadoPorRotacion int,
	@IdProcesoLlantaAsignadoPorRotacion int,
	@IdEstatuLlantaRotar1 int,
	@PresionActualRotar1 decimal (10, 2),
	@ProfundidadRodamientoRotar1 decimal(10, 2),
	@RefaccionRotar1 bit,
	@IdEstatuLlantaRotar2 int,
	@PresionActualRotar2 decimal (10, 2),
	@ProfundidadRodamientoRotar2 decimal(10, 2),
	@RefaccionRotar2 bit,
	@NuevoKmHistorico1 int,	
	@NuevoKmHistorico2 int,	
	@NuevoCostoParaUnidad1 money,
	@NuevoCostoParaUnidad2 money,
	--Llanta Origen
	@IdOrdenServicioParte1 int,
	@IdOrdenServicio1 int,	
	@FolioOrdenServicio1 int, 
	--Llanta destino
	@IdOrdenServicioParte2 int,
	@IdOrdenServicio2 int,	
	@FolioOrdenServicio2 int 	
			
BEGIN TRY
	BEGIN TRANSACTION
	SET @IdProcesoLlantaDesasignadoPorRotacion = 3
	SET @IdProcesoLlantaAsignadoPorRotacion = 4
	
	SET @MessageError =''
	IF ISDATE(@FechaHora)= 0 
		RAISERROR(N'Fecha de Desasignación es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdUnidad,0)= 0 
		RAISERROR(N'Identificador de unidad es un campo requerido',
			16,
			1
			)
						
	IF ISNULL(@IdLlantaRotar1,0)= 0 
		RAISERROR(N'Identificador de llanta es un campo requerido, dato de posición origen',
			16,
			1
			)
			
	IF ISNULL(@NumeroPosicionLlantaRotar1,0)= 0 
		RAISERROR(N'No de posición de llanta es un campo requerido, dato de posición origen',
			16,
			1
			)


	-- Validad que lla llanta no este asigado desde orden de servicio (rotar 1)
	SET @IdOrdenServicioParte1 = (Select IdOrdenServicioParte From ProLlantas WHERE IdLlanta = @IdLlantaRotar1)
	DECLARE @NumeroEconomicoLlantaRotar1 varchar(20)
	SET @NumeroEconomicoLlantaRotar1 = (select NumeroEconomico from ProLlantas where IdLlanta = @IdLlantaRotar1)
	
	IF ISNULL(@IdOrdenServicioParte1,0) != 0
		 BEGIN
			 SET  @IdOrdenServicio1 =
					  (SELECT ProOrdenesServiciosDetalles.IdOrdenServicio
						 FROM  ProOrdenesServiciosPartes INNER JOIN
							   ProOrdenesServiciosDetalles ON ProOrdenesServiciosPartes.IdOrdenServicioDetalle = ProOrdenesServiciosDetalles.IdOrdenServicioDetalle
						WHERE (ProOrdenesServiciosPartes.IdOrdenServicioParte = @IdOrdenServicioParte1))
						
			SET @FolioOrdenServicio1 = (Select Folio From ProOrdenesServicios where IdOrdenServicio = @IdOrdenServicio1)
	
			IF (SELECT CerradoEl FROM ProOrdenesServicios WHERE IdOrdenServicio = @IdOrdenServicio1) IS NULL
				BEGIN
				
					 SET @MessageError ='La llanta '+@NumeroEconomicoLlantaRotar1+' que intenta rotar pertencese a una orden de servicio folio '+CAST(@FolioOrdenServicio1 AS VARCHAR(10))+', debe estar terminada la orden de servicio' 
						 RAISERROR(@MessageError ,
							 16,
							 1
							 )
			 
				END

		END	
	---- fin
		


					
	-- Validar que efectivamente es el no de posición origen a rotar.
	IF (SELECT isnull(NumeroPosicionLlanta,0) FROM ProLlantas where IdLlanta= @IdLlantaRotar1) != @NumeroPosicionLlantaRotar1	
			RAISERROR(N'No de posición origen ya fue actualizado por otro usuario, verificar información',
				16,
				1
				)
	SELECT 					
			@IdEstatuLlantaRotar1 = IdEstatuLlanta,
			@PresionActualRotar1 =PresionActual,
			@ProfundidadRodamientoRotar1= ProfundidadActual,
			@RefaccionRotar1= Refaccion
	FROM ProLlantas
	WHERE IdLlanta = @IdLlantaRotar1
				
	IF ISNULL(@IdEstatuLlantaRotar1,0)= 0 
		RAISERROR(N'Identificador estatus de unidad es un campo requerido, dato de posición origen',
			16,
			1
			)
						
	IF ISNULL(@IdLlantaRotar2,0)= 0 
		RAISERROR(N'Identificador de llanta es un campo requerido, dato de posición destino',
			16,
			1
			)
			
	IF ISNULL(@NumeroPosicionLlantaRotar2,0)= 0 
		RAISERROR(N'No de posición de llanta es un campo requerido, dato de posición destino',
			16,
			1
			)
			

	-- Validad que lla llanta no este asigado desde orden de servicio (rotar 2)
	SET @IdOrdenServicioParte2 = (Select IdOrdenServicioParte From ProLlantas WHERE IdLlanta = @IdLlantaRotar2)
	DECLARE @NumeroEconomicoLlantaRotar2 varchar(20)
	SET @NumeroEconomicoLlantaRotar2 = (select NumeroEconomico from ProLlantas where IdLlanta = @IdLlantaRotar2)
	
	IF ISNULL(@IdOrdenServicioParte2,0) != 0
		 BEGIN
			 SET  @IdOrdenServicio2 =
					  (SELECT ProOrdenesServiciosDetalles.IdOrdenServicio
						 FROM  ProOrdenesServiciosPartes INNER JOIN
							   ProOrdenesServiciosDetalles ON ProOrdenesServiciosPartes.IdOrdenServicioDetalle = ProOrdenesServiciosDetalles.IdOrdenServicioDetalle
						WHERE (ProOrdenesServiciosPartes.IdOrdenServicioParte = @IdOrdenServicioParte2))
						
			SET @FolioOrdenServicio2 = (Select Folio From ProOrdenesServicios where IdOrdenServicio = @IdOrdenServicio2)
	
			IF (SELECT CerradoEl FROM ProOrdenesServicios WHERE IdOrdenServicio = @IdOrdenServicio2) IS NULL
				BEGIN
				
					 SET @MessageError ='La llanta '+@NumeroEconomicoLlantaRotar2+' que intenta rotar pertencese a una orden de servicio folio '+CAST(@FolioOrdenServicio2 AS VARCHAR(10))+', debe estar terminada la orden de servicio' 
						 RAISERROR(@MessageError ,
							 16,
							 1
							 )
			 
				END

		END	
	---- fin
				
	-- Validar que efectivamente es el no de posición origen a rotar.
	IF (SELECT isnull(NumeroPosicionLlanta,0) FROM ProLlantas where IdLlanta= @IdLlantaRotar2) != @NumeroPosicionLlantaRotar2	
			RAISERROR(N'No de posición destino ya fue actualizado por otro usuario, verificar información',
				16,
				1
				)

	SELECT 					
			@IdEstatuLlantaRotar2 = IdEstatuLlanta,
			@PresionActualRotar2 =PresionActual,
			@ProfundidadRodamientoRotar2= ProfundidadActual,
			@RefaccionRotar2= Refaccion
	FROM ProLlantas
	WHERE IdLlanta = @IdLlantaRotar2
											
	IF ISNULL(@IdEstatuLlantaRotar1,0)= 0 
		RAISERROR(N'Identificador estatus de unidad es un campo requerido, dato de posición destino',
			16,
			1
			)
	
	--DESASINGAR LLANTA DE POSICION ORIGEN
			
	--Actualizar ProLlantas 
		UPDATE ProLlantas SET IdUnidad = Null,
							  NumeroPosicionLlanta = NULL,
							  CostoLlanta = CostoLlanta-@CostoParaUnidadRotar1,
							  ProfundidadActual =@ProfundidadRodamientoRotar1,
							  PresionActual = @PresionActualRotar1,
							  IdEstatuLlanta = @IdEstatuLlantaRotar1, 
							  KilometrajeLLanta=isnull(KilometrajeLLanta,0)+@KilometrajeDeLLantaRotar1,	
							  Refaccion = NULL,
							  IdArticulo= NULL,
							  IdProcesoLlanta = @IdProcesoLlantaDesasignadoPorRotacion				  
		WHERE IdLlanta = @IdLlantaRotar1						   
	
	-- Registrar en Auxiliar de Llantas	rotacion 1														
		INSERT INTO ProLlantasAuxiliar (IdLlanta,IdUnidad,NumeroPosicionLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta,Refaccion) 
			   VALUES (@IdLlantaRotar1,@IdUnidad,@NumeroPosicionLlantaRotar1,@FechaHora,@IdEstatuLlantaRotar1,@PresionActualRotar1,@ProfundidadRodamientoRotar1,@KilometrajeDeLLantaRotar1,@KilometrajeHistoricoRotar1,@CostoParaUnidadRotar1,@CreadoPor,@CreadoEl,@IdProcesoLlantaDesasignadoPorRotacion,@RefaccionRotar1) 	



	--DESASIGNAR LLANTA DE POSICION DESTINO		
	--Actualizar ProLlantas 
		UPDATE ProLlantas SET IdUnidad = Null,
							  NumeroPosicionLlanta = NULL,
							  CostoLlanta = CostoLlanta-@CostoParaUnidadRotar2,
							  ProfundidadActual =@ProfundidadRodamientoRotar2,
							  PresionActual = @PresionActualRotar2,
							  IdEstatuLlanta = @IdEstatuLlantaRotar2, 
							  KilometrajeLLanta=isnull(KilometrajeLLanta,0)+@KilometrajeDeLLantaRotar2,	
							  Refaccion = NULL,
							  IdArticulo= NULL,
							  IdProcesoLlanta = @IdProcesoLlantaDesasignadoPorRotacion					  
		WHERE IdLlanta = @IdLlantaRotar2						   
	
	-- Registrar en Auxiliar de Llantas	rotacion 2														
		INSERT INTO ProLlantasAuxiliar (IdLlanta,IdUnidad,NumeroPosicionLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta, Refaccion) 
			   VALUES (@IdLlantaRotar2,@IdUnidad,@NumeroPosicionLlantaRotar2,@FechaHora,@IdEstatuLlantaRotar2,@PresionActualRotar2,@ProfundidadRodamientoRotar2,@KilometrajeDeLLantaRotar2,@KilometrajeHistoricoRotar2,@CostoParaUnidadRotar2,@CreadoPor,@CreadoEl,@IdProcesoLlantaDesasignadoPorRotacion,@RefaccionRotar2) 	
	
	
	
	--ASIGNAR POR ROTACION  1
		-- Actualizar ProLlantas
	UPDATE ProLlantas SET IdUnidad = @IdUnidad,
						  NumeroPosicionLlanta = @NumeroPosicionLlantaRotar2,
						  Refaccion = @RefaccionRotar2,
						  IdProcesoLlanta = @IdProcesoLlantaAsignadoPorRotacion
	WHERE IdLlanta = @IdLlantaRotar1	
	
	SELECT @NuevoKmHistorico1 = KilometrajeLLanta,@NuevoCostoParaUnidad1= CostoLlanta From ProLlantas where IdLlanta = @IdLlantaRotar1			   
	
	-- Registrar en Auxiliar de Llantas															
	INSERT INTO ProLlantasAuxiliar (IdLlanta,IdUnidad,NumeroPosicionLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta,Refaccion) 
		   VALUES (@IdLlantaRotar1,@IdUnidad,@NumeroPosicionLlantaRotar2,@FechaHora,@IdEstatuLlantaRotar1,@PresionActualRotar1,@ProfundidadRodamientoRotar1,0,@NuevoKmHistorico1,@NuevoCostoParaUnidad1,@CreadoPor,@CreadoEl,@IdProcesoLlantaAsignadoPorRotacion,@RefaccionRotar1) 	
	
	--ASIGNAR POR ROTACION  1
		-- Actualizar ProLlantas
	UPDATE ProLlantas SET IdUnidad = @IdUnidad,
						  NumeroPosicionLlanta = @NumeroPosicionLlantaRotar1,
						  Refaccion = @RefaccionRotar1,
						  IdProcesoLlanta = @IdProcesoLlantaAsignadoPorRotacion
	WHERE IdLlanta = @IdLlantaRotar2		
					   
	SELECT @NuevoKmHistorico2 = KilometrajeLLanta, @NuevoCostoParaUnidad2= CostoLlanta From ProLlantas where IdLlanta = @IdLlantaRotar2
		
	-- Registrar en Auxiliar de Llantas															
	INSERT INTO ProLlantasAuxiliar (IdLlanta,IdUnidad,NumeroPosicionLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta,Refaccion) 
		   VALUES (@IdLlantaRotar2,@IdUnidad,@NumeroPosicionLlantaRotar1,@FechaHora,@IdEstatuLlantaRotar2,@PresionActualRotar2,@ProfundidadRodamientoRotar2,0,@NuevoKmHistorico2,@NuevoCostoParaUnidad2,@CreadoPor,@CreadoEl,@IdProcesoLlantaAsignadoPorRotacion,@RefaccionRotar2) 	
				
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

