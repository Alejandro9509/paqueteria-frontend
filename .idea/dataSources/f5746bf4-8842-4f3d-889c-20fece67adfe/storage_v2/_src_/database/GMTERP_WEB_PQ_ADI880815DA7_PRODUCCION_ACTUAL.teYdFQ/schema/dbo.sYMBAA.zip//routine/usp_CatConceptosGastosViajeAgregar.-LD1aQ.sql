CREATE PROCEDURE [dbo].[usp_CatConceptosGastosViajeAgregar]
	@Codigo int,
	@ConceptoGastoViaje varchar(30),
	@Activo bit,
	@ConsiderarCalculoISPT bit,
	@ConsiderarCalculoRendimiento bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@GastoACredito bit
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@Codigo,0) <= 0
		RAISERROR(N'El Codigo es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT IdConceptoGastoViaje FROM CatConceptosGastosViaje WHERE Codigo = @Codigo)		
		RAISERROR(N'El código del concepto de gasto de viaje no se puede repetir',
			16,
			1
			)

	IF LTRIM(RTRIM(@ConceptoGastoViaje)) = ''
		RAISERROR(N'El Concepto de gastos de viaje es un campo requerido',
			16,
			1
			)
			
	INSERT INTO CatConceptosGastosViaje(Activo,Codigo,ConceptoGastoViaje,ConsiderarCalculoISPT,ConsiderarCalculoRendimiento,CreadoEl,CreadoPor,DefinidoPorSistema,GastoACredito)
	VALUES(@Activo,@Codigo,@ConceptoGastoViaje,@ConsiderarCalculoISPT,@ConsiderarCalculoRendimiento,@CreadoEl,@CreadoPor,0,@GastoACredito)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

