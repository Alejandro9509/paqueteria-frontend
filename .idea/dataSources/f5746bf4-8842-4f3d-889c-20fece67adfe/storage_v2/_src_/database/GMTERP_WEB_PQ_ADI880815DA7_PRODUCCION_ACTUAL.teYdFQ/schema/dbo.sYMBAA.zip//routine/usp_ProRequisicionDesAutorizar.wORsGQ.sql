
CREATE PROCEDURE [dbo].[usp_ProRequisicionDesAutorizar]
	@IdRequisicion int,
	@DesAutorizadoEl Datetime,
	@DesAutorizadoPor int,
	@IdPeticion varchar(100)
AS
DECLARE 
	@EstatusAutorizada int,
	@EstatusCancelada int,
	@MotivoCancelacion varchar(50),
	@IdOrdenCompra int,
	@return_value int	
BEGIN TRY
	SET @EstatusCancelada = 2
	SET @EstatusAutorizada = 9
		
	IF Isnull(@IdRequisicion,0) = 0
			RAISERROR(N'El identificador de la requisición es un campo requerido',
				16,
				1
				)
	
	-- Valida que este autorizada 			
	IF (SELECT AutorizadoEl FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) IS NULL 
			RAISERROR(N'No se puede desautorizar esta requisición porque no está autorizada',
				16,
				1
				)
				
	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) <> @EstatusAutorizada
			RAISERROR(N'No se puede desautorizar esta requisición porque no está autorizada',
				16,
				1
				)
				
	-- manda llamar el store procedure de registrar cancelar orden de compra. 
	SET @MotivoCancelacion ='Orden de compra cancelada por desautorización de requisición original'	
	SELECT @IdOrdenCompra = IdOrdenCompra FROM ProOrdenCompra where IdRequisicion = @IdRequisicion

	EXEC @return_value = usp_ProOrdenCompraCancelar @IdOrdenCompra,@EstatusCancelada,@MotivoCancelacion,@DesAutorizadoEl,@DesAutorizadoPor,@IdPeticion
			
	IF @return_value <> 0
			RAISERROR(N'Recuerde que unicamente se puede desautorizar si la orden de compra ligado a esta requisición esta con el estatus abierta.',
				16,
				1
				)

END TRY
BEGIN CATCH
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

