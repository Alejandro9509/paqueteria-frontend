CREATE PROCEDURE [dbo].[usp_CatUsuariosIndicadoresGrabar]
	@IdUsuario int,
	@IdProceso int,
	@Iframe tinyint,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
		
		IF NOT EXISTS(SELECT IdUsuarioIndicador FROM CatUsuariosIndicadores WHERE IdUsuario = @IdUsuario AND Iframe = @Iframe)
		BEGIN
			INSERT INTO CatUsuariosIndicadores(CreadoEl,IdProceso,IdUsuario,Iframe)
			VALUES(GETDATE(),@IdProceso,@IdUsuario,@Iframe)
		END
		ELSE
		BEGIN
			UPDATE CatUsuariosIndicadores SET
				IdProceso = @IdProceso,
				ModificadoEl = GETDATE()
			WHERE IdUsuario = @IdUsuario AND Iframe = @Iframe
		END
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

