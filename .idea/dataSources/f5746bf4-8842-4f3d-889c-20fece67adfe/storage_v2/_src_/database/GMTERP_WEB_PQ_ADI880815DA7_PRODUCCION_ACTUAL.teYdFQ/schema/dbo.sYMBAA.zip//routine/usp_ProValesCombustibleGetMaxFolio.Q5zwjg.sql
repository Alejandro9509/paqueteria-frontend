CREATE PROCEDURE [dbo].[usp_ProValesCombustibleGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProValesCombustible
go

