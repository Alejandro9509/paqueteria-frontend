
CREATE PROCEDURE [dbo].[usp_CatUnidadesActualizarTemperaturaCritica]
	@IdUnidad int,
	@IdPeticion varchar(100),
	@TemperaturaCritica decimal(15,2)
/* *************************************************************************************************
Procedimiento usp_CatUnidadesActualizarTemperaturaCritica

Parámetros: 
	@IdUnidad int,
	@IdPeticion varchar(100),
	@TemperaturaCritica decimal(3, 2)

Descripción: El procedimiento se encarga de actualizar la opcion de temperatura critica cuando se opima el boton del lado de la 
pagina.
05/11/2020 Se agrego la variable de temperatura
Implementada por:  Angel Espinoza.
Fecha de implementacion: 05/11/2020
Versión GMTERPV8 8.0.49.01

Invocada desde: <PAGE_ProUbicacionesReporteTemperatura, ClsCatUnidades, ActualizarTemperaturaCritica(Execute usp_CatUnidadesActualizarTemperaturaCritica)

Solicitud 784
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF @IdUnidad = 0
		RAISERROR(N'El identificador de la unidad es un campo requerido',
			16,
			1
			)

	UPDATE CatUnidades SET 
	TemperaturaCritica = @TemperaturaCritica
	WHERE IdUnidad = @IdUnidad	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

