CREATE PROCEDURE [dbo].[usp_ProEjerciciosPeriodosCerrar]
@Ejercicio smallint,
@Periodo tinyint,	
@CerradoEl datetime,
@CerradoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@Ejercicio,0)= 0
	RAISERROR(N'El ejercicio es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Periodo,0)= 0
		RAISERROR(N'El periodo es un campo requerido',
			16,
			1
			)
			
	UPDATE ProEjerciciosPeriodos SET
	PeriodoCerrado1 = CASE @Periodo WHEN 1 THEN 1 ELSE PeriodoCerrado1 END,
	PeriodoCerrado2 = CASE @Periodo WHEN 2 THEN 1 ELSE PeriodoCerrado2 END,
	PeriodoCerrado3 = CASE @Periodo WHEN 3 THEN 1 ELSE PeriodoCerrado3 END,
	PeriodoCerrado4 = CASE @Periodo WHEN 4 THEN 1 ELSE PeriodoCerrado4 END,
	PeriodoCerrado5 = CASE @Periodo WHEN 5 THEN 1 ELSE PeriodoCerrado5 END,
	PeriodoCerrado6 = CASE @Periodo WHEN 6 THEN 1 ELSE PeriodoCerrado6 END,
	PeriodoCerrado7 = CASE @Periodo WHEN 7 THEN 1 ELSE PeriodoCerrado7 END,
	PeriodoCerrado8 = CASE @Periodo WHEN 8 THEN 1 ELSE PeriodoCerrado8 END,
	PeriodoCerrado9 = CASE @Periodo WHEN 9 THEN 1 ELSE PeriodoCerrado9 END,
	PeriodoCerrado10 = CASE @Periodo WHEN 10 THEN 1 ELSE PeriodoCerrado10 END,
	PeriodoCerrado11 = CASE @Periodo WHEN 11 THEN 1 ELSE PeriodoCerrado11 END,	
	PeriodoCerrado12 = CASE @Periodo WHEN 12 THEN 1 ELSE PeriodoCerrado12 END,	
	PeriodoCerradoEl1 = CASE @Periodo WHEN 1 THEN @CerradoEl ELSE PeriodoCerradoEl1 END,
	PeriodoCerradoEl2 = CASE @Periodo WHEN 2 THEN @CerradoEl ELSE PeriodoCerradoEl2 END,
	PeriodoCerradoEl3 = CASE @Periodo WHEN 3 THEN @CerradoEl ELSE PeriodoCerradoEl3 END,
	PeriodoCerradoEl4 = CASE @Periodo WHEN 4 THEN @CerradoEl ELSE PeriodoCerradoEl4 END,
	PeriodoCerradoEl5 = CASE @Periodo WHEN 5 THEN @CerradoEl ELSE PeriodoCerradoEl5 END,
	PeriodoCerradoEl6 = CASE @Periodo WHEN 6 THEN @CerradoEl ELSE PeriodoCerradoEl6 END,
	PeriodoCerradoEl7 = CASE @Periodo WHEN 7 THEN @CerradoEl ELSE PeriodoCerradoEl7 END,
	PeriodoCerradoEl8 = CASE @Periodo WHEN 8 THEN @CerradoEl ELSE PeriodoCerradoEl8 END,
	PeriodoCerradoEl9 = CASE @Periodo WHEN 9 THEN @CerradoEl ELSE PeriodoCerradoEl9 END,
	PeriodoCerradoEl10 = CASE @Periodo WHEN 10 THEN @CerradoEl ELSE PeriodoCerradoEl10 END,
	PeriodoCerradoEl11 = CASE @Periodo WHEN 11 THEN @CerradoEl ELSE PeriodoCerradoEl11 END,	
	PeriodoCerradoEl12 = CASE @Periodo WHEN 12 THEN @CerradoEl ELSE PeriodoCerradoEl12 END,
	PeriodoCerradoPor1 = CASE @Periodo WHEN 1 THEN @CerradoPor ELSE PeriodoCerradoPor1 END,
	PeriodoCerradoPor2 = CASE @Periodo WHEN 2 THEN @CerradoPor ELSE PeriodoCerradoPor2 END,
	PeriodoCerradoPor3 = CASE @Periodo WHEN 3 THEN @CerradoPor ELSE PeriodoCerradoPor3 END,
	PeriodoCerradoPor4 = CASE @Periodo WHEN 4 THEN @CerradoPor ELSE PeriodoCerradoPor4 END,
	PeriodoCerradoPor5 = CASE @Periodo WHEN 5 THEN @CerradoPor ELSE PeriodoCerradoPor5 END,
	PeriodoCerradoPor6 = CASE @Periodo WHEN 6 THEN @CerradoPor ELSE PeriodoCerradoPor6 END,
	PeriodoCerradoPor7 = CASE @Periodo WHEN 7 THEN @CerradoPor ELSE PeriodoCerradoPor7 END,
	PeriodoCerradoPor8 = CASE @Periodo WHEN 8 THEN @CerradoPor ELSE PeriodoCerradoPor8 END,
	PeriodoCerradoPor9 = CASE @Periodo WHEN 9 THEN @CerradoPor ELSE PeriodoCerradoPor9 END,
	PeriodoCerradoPor10 = CASE @Periodo WHEN 10 THEN @CerradoPor ELSE PeriodoCerradoPor10 END,
	PeriodoCerradoPor11 = CASE @Periodo WHEN 11 THEN @CerradoPor ELSE PeriodoCerradoPor11 END,	
	PeriodoCerradoPor12 = CASE @Periodo WHEN 12 THEN @CerradoPor ELSE PeriodoCerradoPor12 END		
	WHERE Ejercicio =@Ejercicio

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

