CREATE PROCEDURE [dbo].[usp_ProNominasRecibosPagar]
@Fecha datetime,
@IdCuentaBancaria int,
@TipodeMovimiento int,
@NumeroMovimiento int,
@NumeroCheque int ,
@IdBancoOperador int,
@CodigoEstatuCheque int,
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100),
@dsRecorridosPagar Varchar(max),
@GenerarUnSoloMovimientoBancario tinyint,
@IdPeriodo int,
@FechaCobro datetime

/* *************************************************************************************************
Procedimiento [dbo].[usp_ProNominasRecibosPagar]

Parámetros: 
	@dsCatRutasConceptosTarifas  (entrada, texto). Xml Lista de Conceptos de facturacion para las Rutas elegidas con cambio 
	                                              de tarifas
	@dsCatRutasMaterialesTarifas (entrada, texto). Xml Lista Materiales para las Rutas elegidas con cambio de tarifas
	@ModificadoEl	             (entrada, fecha hora). Fecha en la que se realiza la modificación
	@ModificadoPor	             (entrada, entero). Quien solicita la modificación
	@IdPeticion varchar(100)	 (entrada, string). Id de la Petición, generada en WEBDEV 	

	@Fecha datetime,			(entrada, fecha), fecha del proceso.
	@IdCuentaBancaria int,		(entrada, entero), clave de la cuenta del banco en la tabla.
	@TipodeMovimiento int,		(entrada, entero), determina si es pago con chque por transferencia electronica.
	@NumeroMovimiento int,		(entrada, entero), consecutivo asignado a la operacion.
	@NumeroCheque int ,			(entrada, entero), consecutivo del cheque(s) utilizar en el pago.
	@IdBancoOperador int,		(entrada, entero), clave de la cuenta bancaria del empleado.
	@CodigoEstatuCheque int,	(entrada, entero), estatus que guarda el cheque en la operacion realizada (cobrado, retenido, etc)
	@CreadoPor int,				(entrada, entero), clave del usuario que reealizo el proceso.
	@CreadoEl datetime,			(entrada, fecha), fecha del proceso realizado.
	@IdPeticion varchar(100),	(entrada, texto), Id de la Petición, generada en WEBDEV 
	@dsRecorridosPagar Varchar(max), (entrada, texto), engloba todos los movimientos  realizar en la operacion bancaria.
	@GenerarUnSoloMovimientoBancario tinyint, (entrada, entero), determina si se cubriran las operaciones con un solo pago cheque/transferencia o sera individual.
	@IdPeriodo int				(entrada, entero), clave del periodo de pago de las operaciones.
 

Descripción: El procedimiento actualiza o agrega movimientos movimientos bancarios ralcionados con el pago de la nomina, actualiza la informacion de la tabla 
ProCheques asi como los beneficiarios.

Implementada por: N/A.
Fecha de implementacion: N/A.
Versión ERP: N/A.

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 02/nov/2020
Versión ERP: 8.0.56.05

Invocada desde: PAGE_ProNominasReciboPagar (Solicitud 3360)

Modificada por:   Abril C.G.
Se agrego la fecha de cobro a los insert en ProCheques y ProMovimientosBancarios
Fecha de mofidicacion: 11/11/2020
Invocada desde: PAGE_ProNominasReciboPagar (Solicitud 3400)
***************************************************************************************************** */


AS
Declare
		@docHandle int, 
		@IdCheque int,
		@Concepto varchar(150),
		@Beneficiario varchar(150),
		@IdMovimientoBancario  int,
		@IdTipoMovimientoBancario int,
		@IdEstatuCheque int,
		@NumeroBeneficiario int,
		@IdBeneficiario int,
		@NroCuentaPago varchar(50),
		@MetodoPago varchar(50),
		@ClaveMetodoPago varchar(5),
		@ATT_IdNominaRecibo int,
		@IdEmpleado int,
		@FechaPago datetime,
		@FechaTimbrado Datetime,
		@ImporteGlobal Money,
		@NetoAPagar money,
		@ATT_ReferenciaPago Varchar(150),
		@ATT_CuentaBancariaOperador Varchar(21),
		@TotalRecibos int,
		@RecibosPagado int,
		@TipoCambio money
		

BEGIN TRY
	BEGIN TRANSACTION
	SET @IdCheque = Null
	--IF ISNULL(@IdNominaRecibo,0) <= 0
	--	RAISERROR(N'El identificador del recibo es un campo requerido',
	--		16,
	--		1
	--		)	
	
	IF ISDATE(@Fecha) = 0
		RAISERROR(N'Fecha es un campo requerido',
			16,
			1
			)
	
	--IF ISNULL(@IdEmpleado,0) <= 0
	--		RAISERROR(N'El identificador de operador es un campo requerido',
	--		16,
	--		1
	--		)	
			
	IF ISNULL(@IdCuentaBancaria,0) <= 0
		RAISERROR(N'El identificador de cuenta bancaria es un campo requerido',
			16,
			1
			)	
	
	IF ISNULL(@TipodeMovimiento,0) <= 0
		RAISERROR(N'Tipo de movimiento es un campo requerido',
			16,
			1
			)
	IF @dsRecorridosPagar is null
			RAISERROR(N'Debe de marcar Recibos para Pagar.',
				16,
				1
				)
							
	SET @TipoCambio= (SELECT TipoCambio FROM CatTiposCambio WHERE Cast(Fecha As DATE) = @Fecha)
	IF ISNULL(@TipoCambio,0)=0
	BEGIN
	SET @TipoCambio=(SELECT TOP 1 TipoCambio FROM CatTiposCambio ORDER BY Fecha DESC )
	END
	
	SET @ImporteGlobal = 0			
	IF @GenerarUnSoloMovimientoBancario = 2 --SI SE VA A GENERAR UN SOLO MOVIMIENTO BANCARIO POR EL TOTAL DE LOS RECIBOS PAGADOS
	BEGIN
		--- Registrar Beneficiario 
	
		Select @IdBeneficiario = (Select IdBeneficiario  from CatBeneficiarios where RTRIM(LTRIM(Nombre)) = RTRIM(LTRIM('PAGO DE NOMINA')))
		SET @Beneficiario = 'PAGO DE NOMINA'
		IF  ISNULL(@IdBeneficiario ,0) = 0 
		BEGIN
			SELECT @NumeroBeneficiario = (SELECT ISNULL(MAX(NumeroBeneficiario),0)+1 AS Codigo FROM CatBeneficiarios)
			INSERT INTO CatBeneficiarios(NumeroBeneficiario,Nombre,CreadoEl,CreadoPor,Activo)
				   VALUES(@NumeroBeneficiario,RTRIM(LTRIM('PAGO DE NOMINA')),@CreadoEl,@CreadoPor,1)
			SET @IdBeneficiario = (SELECT IDENT_CURRENT('CatBeneficiarios'))	 
		END
		--- Generar cheque CUANDO ES UNO GLOBAL
		IF @TipodeMovimiento = 1 --- CHEQUE 
		BEGIN
			Select @IdTipoMovimientoBancario = 2 -- Cheque
			Select @IdEstatuCheque = IdEstatuCheque From CatEstatusCheques where Codigo = @CodigoEstatuCheque 			
			IF ISNULL(@NumeroCheque,0) = 0
				RAISERROR(N'Número de cheque es un campo requerido',
				16,
				1
				)
			-- valida que el número de cheque no este usado
			IF EXISTS(Select NumeroCheque from ProCheques where NumeroCheque  = @NumeroCheque AND IdCuentaBancaria = @IdCuentaBancaria)
						RAISERROR(N'El Número de cheque ya fue utilizado por otro usuario, se le asignará el siguiente número de cheque disponible, revise la información y vuelva hacer click en aceptar',					
							16,
							1
							)		
							
			--- Registrar cheque		
			
			Set @Concepto = @Beneficiario
			INSERT INTO ProCheques (NumeroCheque,Fecha,IdCuentaBancaria,Concepto,Beneficiario,Importe,IdEstatuCheque,TipoBeneficiario,IdBeneficiario,FechaCobro,CreadoPor,CreadoEl,TipoCambio)
			VALUES(@NumeroCheque,@Fecha,@IdCuentaBancaria,@Concepto,RTRIM(LTRIM(@Beneficiario)),@ImporteGlobal,@IdEstatuCheque,2,@IdBeneficiario,@FechaCobro,@CreadoPor,@CreadoEl,@TipoCambio)
			--- Registrar Movimiento Bancario
			SET @IdCheque= (SELECT IDENT_CURRENT('ProCheques'))
			SET @MetodoPago = 'CHEQUE NOMINATIVO'
			SET @ClaveMetodoPago = '02'
			SET @NumeroMovimiento =(Select ISNULL(MAX(NumeroMovimiento),0)+1 AS NumeroMovimiento from ProMovimientosBancarios where IdCuentaBancaria = @IdCuentaBancaria)
			
		END
		ELSE
		BEGIN -- TRANSFERENCIA
			SET @MetodoPago = 'TRANSFERENCIA ELECTRÓNICA DE FONDOS'	
			Select @IdTipoMovimientoBancario = 3 -- Retiro por transferencia
			SET @ClaveMetodoPago = '03'
				IF ISNULL(@NumeroMovimiento,0) = 0
				RAISERROR(N'Número de movimiento bancario es un campo requerido',
				16,
				1
				)
				-- valida que el número de mov. bancario no este usado
			IF EXISTS(Select NumeroMovimiento from ProMovimientosBancarios where NumeroMovimiento = @NumeroMovimiento AND IdCuentaBancaria = @IdCuentaBancaria)
						RAISERROR(N'El Número de movimiento bancario ya fue utilizado por otro usuario, se le asignará el siguiente número de movimiento bancario disponible, revise la información y vuelva hacer click en aceptar',					
							16,
							1
							)
			-- si el importe a pagar es negativo poner cero
			IF @ImporteGlobal < 0
				SET @ImporteGlobal = 0
		END		
		--- Registrar Movimiento Bancario 
		
		INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,ReferenciaBancaria,IdTipoMovimientoBancario,CreadoPor,CreadoEl,IdCheque,TipoBeneficiario,IdBeneficiario,Beneficiario,TipoCambio,FechaCobro)
		VALUES (@NumeroMovimiento,@Fecha,@IdCuentaBancaria,@ImporteGlobal, @ATT_ReferenciaPago+' -CTA:'+@ATT_CuentaBancariaOperador,@IdTipoMovimientoBancario,@CreadoPor,@CreadoEl,@IdCheque,2,@IdBeneficiario,RTRIM(LTRIM(@Beneficiario)),@TipoCambio,@FechaCobro)
		SET @IdMovimientoBancario = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))			   
					
		SET @NroCuentaPago = (SELECT NumeroCuenta FROM CatCuentasBancarias WHERE IdCuentaBancaria = @IdCuentaBancaria)		   		
		--seccion para agregar el idmovimientobancario a paremtros y poder obtenerlo de lado del web
		--francisco villela: antes de Grabar en SisParametrosPagina se eliminara el registro que exista esto porque havia un error en la generacion de la poliza global SOLICITUD 12593
		DELETE FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancario:' + CAST(@IdPeriodo as Varchar(10)) AND IdUsuario = @CreadoPor 
		IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancario:' + CAST(@IdPeriodo as Varchar(10)) AND IdUsuario = @CreadoPor AND Parametros = @IdMovimientoBancario)
			INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoBancario:' + CAST(@IdPeriodo as Varchar(10)),@IdMovimientoBancario,@CreadoPor)
		ELSE
			UPDATE SisParametrosPagina SET Parametros = @IdMovimientoBancario WHERE Pagina = 'IdMovimientoBancario:' + CAST(@IdPeriodo as Varchar(10)) AND IdUsuario = @CreadoPor
	END -- FIN SI SE VA A GENERAR UN MOVIMIENTO BANCARIO POR CADA UNO DE LOS RECIBOS A PAGAR
	
	-- modificacion CON RECORRIDO XML
	--SECCION PARA AGREGAR LOS CatClasificacionesViajes
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsRecorridosPagar
	
	SELECT ATT_IdNominaRecibo,ATT_ReferenciaPago,ATT_CuentaBancariaOperador
	INTO #TempRecibosPagar
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_RecibosPagar',2) 
	WITH (ATT_IdNominaRecibo int,ATT_ReferenciaPago Varchar(150),ATT_CuentaBancariaOperador Varchar(21))
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE RECIBOSPAGAR_Cursor CURSOR FOR
	SELECT * FROM #TempRecibosPagar
	
	OPEN RECIBOSPAGAR_Cursor
	FETCH NEXT FROM RECIBOSPAGAR_Cursor
	INTO @ATT_IdNominaRecibo,@ATT_ReferenciaPago,@ATT_CuentaBancariaOperador
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @FechaPago=FechaPago,@FechaTimbrado=FechaTimbrado,@IdEmpleado = IdEmpleado, @NetoAPagar = NetoPagar FROM ProNominasRecibo Where IdNominaRecibo = @ATT_IdNominaRecibo
		SET @ATT_ReferenciaPago = ('RECIBO:'+CONVERT(VARCHAR(10),(Select Codigo from CatEmpleados where IdEmpleado=@IdEmpleado))+'-'+ (Select Nombre From CatEmpleados Where IdEmpleado=@IdEmpleado) )
		IF  ISNULL((Select IdMovimientoBancario  from ProNominasRecibo WHERE IdNominaRecibo =  @ATT_IdNominaRecibo),0) > 0 
		RAISERROR(N'El recibo ya esta pagado',
			16,
			1
			)	
		IF @FechaTimbrado is not null -- si el recivo ya fue timbrado
			IF @FechaPago is not null
				UPDATE ProNominasRecibo Set FechaEfectivaPago = @FechaPago Where IdNominaRecibo = @ATT_IdNominaRecibo
			ELSE
				UPDATE ProNominasRecibo Set FechaEfectivaPago = @FechaTimbrado Where IdNominaRecibo = @ATT_IdNominaRecibo
		ELSE
			UPDATE ProNominasRecibo Set FechaEfectivaPago = @Fecha Where IdNominaRecibo = @ATT_IdNominaRecibo			
		
		SET @ImporteGlobal = @ImporteGlobal + @NetoAPagar	
			
		IF @GenerarUnSoloMovimientoBancario != 2 --SI SE VA A GENERAR UN MOVIMIENTO BANCARIO POR CADA UNO DE LOS RECIBOS A PAGAR
		BEGIN
			--- Registrar Beneficiario 
			Select @Beneficiario = Nombre  from CatEmpleados where IdEmpleado = @IdEmpleado
			Select @IdBeneficiario = (Select IdBeneficiario  from CatBeneficiarios where RTRIM(LTRIM(Nombre)) = RTRIM(LTRIM(@Beneficiario)))
			
			IF  ISNULL(@IdBeneficiario ,0) = 0 
			BEGIN
				SELECT @NumeroBeneficiario = (SELECT ISNULL(MAX(NumeroBeneficiario),0)+1 AS Codigo FROM CatBeneficiarios)
				INSERT INTO CatBeneficiarios(NumeroBeneficiario,Nombre,CreadoEl,CreadoPor,Activo)
					   VALUES(@NumeroBeneficiario,RTRIM(LTRIM(@Beneficiario)),@CreadoEl,@CreadoPor,1)
				SET @IdBeneficiario = (SELECT IDENT_CURRENT('CatBeneficiarios'))	   
			END
			--- Generar cheque
			IF @TipodeMovimiento = 1 --- CHEQUE 
			BEGIN
				Select @IdTipoMovimientoBancario = 2 -- Cheque
				Select @IdEstatuCheque = IdEstatuCheque From CatEstatusCheques where Codigo = @CodigoEstatuCheque 				
				IF ISNULL(@NumeroCheque,0) = 0
					RAISERROR(N'Número de cheque es un campo requerido',
					16,
					1
					)	
				IF @NumeroCheque= (Select NumeroCheque from ProCheques where NumeroCheque  = @NumeroCheque AND IdCuentaBancaria = @IdCuentaBancaria)
				BEGIN
				SET @NumeroCheque=(SELECT MAX(NumeroCheque) + 1 FROM ProCheques WHERE IdCuentaBancaria = @IdCuentaBancaria)
				END
				
				-- valida que el número de cheque no este usado
				IF EXISTS(Select NumeroCheque from ProCheques where NumeroCheque  = @NumeroCheque AND IdCuentaBancaria = @IdCuentaBancaria)
							RAISERROR(N'El Número de cheque ya fue utilizado por otro usuario, se le asignará el siguiente número de cheque disponible, revise la información y vuelva hacer click en aceptar',					
								16,
								1
								)
				--- Registrar cheque		
				--Set @Concepto = 'RECIBO: '+CONVERT(VARCHAR(10),@ATT_IdNominaRecibo)+' '+@Beneficiario
				SET @Concepto = ('RECEIPT:'+CONVERT(VARCHAR(10),(Select Codigo from CatEmpleados where IdEmpleado=@IdEmpleado))+'-'+ (Select Nombre From CatEmpleados Where IdEmpleado=@IdEmpleado) )--Se tradujo por parte de la solicitud 11140
				INSERT INTO ProCheques (NumeroCheque,Fecha,IdCuentaBancaria,Concepto,Beneficiario,Importe,IdEstatuCheque,TipoBeneficiario,IdBeneficiario,FechaCobro,CreadoPor,CreadoEl,TipoCambio)
				VALUES(@NumeroCheque,@Fecha,@IdCuentaBancaria,@Concepto,RTRIM(LTRIM(@Beneficiario)),@NetoAPagar,@IdEstatuCheque,2,@IdBeneficiario,@FechaCobro,@CreadoPor,@CreadoEl,@TipoCambio)
				--- Registrar Movimiento Bancario
				
				SET @IdCheque= (SELECT IDENT_CURRENT('ProCheques'))	
				SET @MetodoPago = 'CHEQUE NOMINATIVO'
				SET @ClaveMetodoPago = '02'
				SET @NumeroMovimiento =(Select ISNULL(MAX(NumeroMovimiento),0)+1 AS NumeroMovimiento from ProMovimientosBancarios where IdCuentaBancaria = @IdCuentaBancaria)
				SET @NumeroCheque = (SELECT NumeroCheque + 1 FROM ProCheques WHERE IdCuentaBancaria = @IdCuentaBancaria AND NumeroCheque = @NumeroCheque)
			END
			ELSE
			BEGIN -- TRANSFERENCIA
				SET @MetodoPago = 'TRANSFERENCIA ELECTRÓNICA DE FONDOS'	
				Select @IdTipoMovimientoBancario = 3 -- Retiro por transferencia
				SET @ClaveMetodoPago = '03'
					IF ISNULL(@NumeroMovimiento,0) = 0
					RAISERROR(N'Número de movimiento bancario es un campo requerido',
					16,
					1
					)
				
				IF @NumeroMovimiento= (Select NumeroMovimiento from ProMovimientosBancarios where NumeroMovimiento  = @NumeroMovimiento AND IdCuentaBancaria = @IdCuentaBancaria)
				BEGIN
					SET @NumeroMovimiento=(SELECT MAX(NumeroMovimiento) + 1 FROM ProMovimientosBancarios WHERE IdCuentaBancaria = @IdCuentaBancaria)
				END
	
			-- valida que el número de mov. bancario no este usado
			IF EXISTS(Select NumeroMovimiento from ProMovimientosBancarios where NumeroMovimiento = @NumeroMovimiento AND IdCuentaBancaria = @IdCuentaBancaria)
					RAISERROR(N'El Número de movimiento bancario ya fue utilizado por otro usuario, se le asignará el siguiente número de movimiento bancario disponible, revise la información y vuelva hacer click en aceptar',					
					16,
					1
					)
			--estaba aqui la validacion de mov bancario
			
				-- si el importe a pagar es negativo poner cero
				IF @NetoAPagar < 0
					SET @NetoAPagar = 0
			END
					
			--- Registrar Movimiento Bancario 
			INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,ReferenciaBancaria,IdTipoMovimientoBancario,CreadoPor,CreadoEl,IdCheque,TipoBeneficiario,IdBeneficiario,Beneficiario,TipoCambio,FechaCobro)
			VALUES (@NumeroMovimiento,@Fecha,@IdCuentaBancaria,@NetoAPagar, @ATT_ReferenciaPago+' -CTA:'+@ATT_CuentaBancariaOperador,@IdTipoMovimientoBancario,@CreadoPor,@CreadoEl,@IdCheque,2,@IdBeneficiario,RTRIM(LTRIM(@Beneficiario)),@TipoCambio,@FechaCobro)
			SET @IdMovimientoBancario = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))			   
				
			SET @NroCuentaPago = (SELECT NumeroCuenta FROM CatCuentasBancarias WHERE IdCuentaBancaria = @IdCuentaBancaria)		   
			 
			
			UPDATE ProNominasRecibo SET
				   IdMovimientoBancario =  	@IdMovimientoBancario,
				   IdBancoOperador = @IdBancoOperador, 
				   NumeroCuentaBancariaOperador =@ATT_CuentaBancariaOperador,				   
				   MetodoPago = @MetodoPago,
				   NroCuentaPago = @NroCuentaPago,
				   ClaveMetodoPago = @ClaveMetodoPago
			WHERE  IdNominaRecibo =  @ATT_IdNominaRecibo							
			--seccion para agregar el idmovimientobancario a paremtros y poder obtenerlo de lado del web
			--francisco villela: antes de Grabar en SisParametrosPagina se eliminara el registro que exista esto porque havia un error en la generacion de la poliza global SOLICITUD 12593
			DELETE FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancario:' + CAST(@ATT_IdNominaRecibo as Varchar(10)) AND IdUsuario = @CreadoPor 
			IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancario:' + CAST(@ATT_IdNominaRecibo as Varchar(10)) AND IdUsuario = @CreadoPor AND Parametros = @IdMovimientoBancario)
				INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoBancario:' + CAST(@ATT_IdNominaRecibo as Varchar(10)),@IdMovimientoBancario,@CreadoPor)
			ELSE
				UPDATE SisParametrosPagina SET Parametros = @IdMovimientoBancario WHERE Pagina = 'IdMovimientoBancario:' + CAST(@ATT_IdNominaRecibo as Varchar(10)) AND IdUsuario = @CreadoPor
							
		END -- FIN SI SE VA A GENERAR UN MOVIMIENTO BANCARIO POR CADA UNO DE LOS RECIBOS A PAGAR
		ELSE
		BEGIN
				UPDATE ProNominasRecibo SET
			   IdMovimientoBancario =  	@IdMovimientoBancario   
		WHERE  IdNominaRecibo =  @ATT_IdNominaRecibo
		END
		FETCH NEXT FROM RECIBOSPAGAR_Cursor
		INTO @ATT_IdNominaRecibo,@ATT_ReferenciaPago,@ATT_CuentaBancariaOperador
	END

	CLOSE RECIBOSPAGAR_Cursor
	DEALLOCATE RECIBOSPAGAR_Cursor		
				
	IF @GenerarUnSoloMovimientoBancario =2
	BEGIN
	UPDATE ProCheques SET Importe = @ImporteGlobal 
	wHERE IdCheque = @IdCheque
	
	UPDATE ProMovimientosBancarios SET Importe = @ImporteGlobal,
	ReferenciaBancaria='PAGO DE NOMINA'  
	WHERE IdMovimientoBancario = @IdMovimientoBancario
	END
	-- FIN MODIFIFCACION CON RECORRIDO XML							
	
			SET @TotalRecibos =(SELECT COUNT(*) FROM ProNominasRecibo WHERE IdPeriodo=@IdPeriodo)
			SET @RecibosPagado = (SELECT COUNT (*)FROM ProNominasRecibo WHERE IdPeriodo=@IdPeriodo AND FechaEfectivaPago IS NOT NULL)
			IF  @RecibosPagado = @TotalRecibos
			BEGIN
				UPDATE CatPeriodos
				SET PagadoEl =@Fecha
				WHERE IdPeriodo=@IdPeriodo
			END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

