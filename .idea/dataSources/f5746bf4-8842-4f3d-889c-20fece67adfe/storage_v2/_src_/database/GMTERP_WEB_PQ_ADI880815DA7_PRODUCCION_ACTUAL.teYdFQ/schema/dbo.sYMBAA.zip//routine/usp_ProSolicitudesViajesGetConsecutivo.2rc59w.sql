Create PROCEDURE [dbo].[usp_ProSolicitudesViajesGetConsecutivo]
@IdCliente int  
AS  
SELECT ISNULL(MAX(Consecutivo),0)+1 AS Consecutivo FROM ProSolicitudesViajes WHERE IdCliente = @IdCliente
go

