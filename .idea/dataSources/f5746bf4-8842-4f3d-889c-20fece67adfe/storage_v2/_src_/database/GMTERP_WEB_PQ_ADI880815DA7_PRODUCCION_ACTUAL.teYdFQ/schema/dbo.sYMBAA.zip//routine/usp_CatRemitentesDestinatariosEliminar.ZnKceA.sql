
CREATE PROCEDURE [dbo].[usp_CatRemitentesDestinatariosEliminar]
	@IdRemitenteDestintario int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM ProViajes WHERE IdRemitente = @IdRemitenteDestintario OR IdDestinatario = @IdRemitenteDestintario)
		RAISERROR(N'El remitente-destinatario tiene viajes ligados, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM CatRutas WHERE IdRemitente = @IdRemitenteDestintario OR IdDestinatario = @IdRemitenteDestintario)
		RAISERROR(N'El remitente-destinatario tiene rutas ligadas, no es posible eliminarlo',
			16,
			1
			)
				
	DELETE FROM CatRemitentesDestinatarios
	WHERE IdRemitenteDestinatario = @IdRemitenteDestintario
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

