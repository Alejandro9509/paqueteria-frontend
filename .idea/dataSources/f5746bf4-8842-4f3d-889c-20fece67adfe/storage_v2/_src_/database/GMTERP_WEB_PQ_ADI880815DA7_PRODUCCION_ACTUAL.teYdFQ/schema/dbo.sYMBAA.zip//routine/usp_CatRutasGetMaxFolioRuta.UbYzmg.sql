




CREATE PROCEDURE [dbo].[usp_CatRutasGetMaxFolioRuta]

AS

SELECT ISNULL(MAX(FolioRuta),0)+1 AS FolioRuta FROM CatRutas
go

