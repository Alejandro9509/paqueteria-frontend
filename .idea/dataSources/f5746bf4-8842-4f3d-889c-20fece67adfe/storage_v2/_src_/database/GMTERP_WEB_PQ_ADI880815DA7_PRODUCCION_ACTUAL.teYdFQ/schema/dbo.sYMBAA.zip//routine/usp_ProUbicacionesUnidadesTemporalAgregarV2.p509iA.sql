CREATE PROCEDURE [dbo].[usp_ProUbicacionesUnidadesTemporalAgregarV2]
	@IdUsuario int,
	@dsProUbicacionesUnidadesTemp ntext,
	@IdPeticion varchar(100),
	@sIdentificadoresUnidades varchar(MAX) = '',
	@FechaHoraSucursal datetime
AS
DECLARE
	@docHandle int,
	@Consulta nvarchar(3000),
	@ConsultaValores nvarchar(3000),
	@variable VARCHAR (10) = '000000'

BEGIN TRANSACTION

BEGIN TRY
	IF isnull(@IdUsuario,0) = 0
	RAISERROR(N'El idusuario es un campo requerido',
	16,
	1
	)

	IF @dsProUbicacionesUnidadesTemp IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProUbicacionesUnidadesTemp
		
		SELECT Unidad,Pais,
		Estado,Ciudad,
		Calle,Evento,
		Icono,
		ExisteAlertaReporteo,DireccionImagenAdvertencia,
		DentroGeocerca,RFC,
		FechaHoraPaquete,
		TiempoEstimadoUltimoReporte,
		Velocidad,PorcentajeBateria,
		VoltajeVehiculo,CadenaLitros,
		Direccion,Latitud,
		Longitud,Codigo,
		Posicion,NoSerie,
		OdometroGPS,
		EstadoMotor,Temperatura,
		FechaHoraUltimaPeticion,FechaHoraUnidad,
		HASHGPS,CantidadSatelite,
		LinkGoogleMaps,FechaHoraServidor,
		EstadoModoTrabajo,EstadoModuloGPS,
		NivelGSM,TipoSenal,
		VoltajeBateriaInterna,
		SumaLitrosTanques,
		TieneSensores,
		NivelCombustiblePorcentaje,
		EventoPSalidaGeo,
		EventoPEntradaGeo,
		EventoPDemorado,
		EventoPFueraRuta,
		EventoPTempAlta,
		EventoPTempBaja,
		ISNULL(DireccionImagenSeguimiento,'/GMTERPV8_WEB/Imagenes/OJOINACTIVO.png') AS DireccionImagenSeguimiento,
		ISNULL(UnidadSeleccionada,1) AS UnidadSeleccionada,
		ISNULL(CapacidadTanque1,0) AS CapacidadTanque1,
		ISNULL(CapacidadTanque2,0) AS CapacidadTanque2,
		ISNULL(CapacidadTanque3,0) AS CapacidadTanque3,
		ISNULL(CapacidadTanque4,0) AS CapacidadTanque4
		INTO #TempProUbicacionesUnidadesTemp
		FROM OPENXML(@docHandle, N'/Markers/Marker',2) 
		WITH (Unidad varchar(150) COLLATE Modern_Spanish_CS_AS,Pais varchar(150) COLLATE Modern_Spanish_CS_AS,
		Estado varchar(150) COLLATE Modern_Spanish_CS_AS,Ciudad varchar(150) COLLATE Modern_Spanish_CS_AS,
		Calle varchar(200) COLLATE Modern_Spanish_CS_AS,Evento varchar(50) COLLATE Modern_Spanish_CS_AS,
		Icono varchar(50) COLLATE Modern_Spanish_CS_AS,
		ExisteAlertaReporteo bit,DireccionImagenAdvertencia varchar(200) COLLATE Modern_Spanish_CS_AS,
		DentroGeocerca bit,RFC varchar(15) COLLATE Modern_Spanish_CS_AS,
		FechaHoraPaquete varchar(110) COLLATE Modern_Spanish_CS_AS,
		TiempoEstimadoUltimoReporte varchar(150) COLLATE Modern_Spanish_CS_AS,
		Velocidad varchar(50) COLLATE Modern_Spanish_CS_AS,PorcentajeBateria varchar(50) COLLATE Modern_Spanish_CS_AS,
		VoltajeVehiculo varchar(50) COLLATE Modern_Spanish_CS_AS,CadenaLitros varchar(150) COLLATE Modern_Spanish_CS_AS,
		Direccion varchar(5) COLLATE Modern_Spanish_CS_AS,Latitud float,
		Longitud float,Codigo int,
		Posicion varchar(100) COLLATE Modern_Spanish_CS_AS,NoSerie varchar(50) COLLATE Modern_Spanish_CS_AS,
		OdometroGPS float,
		EstadoMotor int,Temperatura varchar(50) COLLATE Modern_Spanish_CS_AS,
		FechaHoraUltimaPeticion datetime,FechaHoraUnidad datetime,
		HASHGPS varchar(50) COLLATE Modern_Spanish_CS_AS,CantidadSatelite tinyint,
		LinkGoogleMaps varchar(400) COLLATE Modern_Spanish_CS_AS,FechaHoraServidor datetime,
		EstadoModoTrabajo varchar(100) COLLATE Modern_Spanish_CS_AS,EstadoModuloGPS varchar(100) COLLATE Modern_Spanish_CS_AS,
		NivelGSM varchar(100) COLLATE Modern_Spanish_CS_AS,TipoSenal varchar(100) COLLATE Modern_Spanish_CS_AS,
		VoltajeBateriaInterna varchar(50) COLLATE Modern_Spanish_CS_AS,
		SumaLitrosTanques decimal(15, 4),
		TieneSensores int,
		NivelCombustiblePorcentaje float,
		EventoPSalidaGeo bit,
		EventoPEntradaGeo bit,
		EventoPDemorado bit,
		EventoPFueraRuta bit,
		EventoPTempAlta bit,
		EventoPTempBaja bit,
		DireccionImagenSeguimiento varchar(200) COLLATE Modern_Spanish_CS_AS,
		UnidadSeleccionada bit,
		CapacidadTanque1 float,
		CapacidadTanque2 float,
		CapacidadTanque3 float,
		CapacidadTanque4 float)
		
		EXEC sp_xml_removedocument @docHandle

		--Esta seccion indica que es el primero el primer registro de todas las unidades como valor @sIdentificadoresUnidades = ''
		--caso contrario, indicara que es ya existe unidades registradas y solo se requiere eliminar las unidades que se movieron
		IF @sIdentificadoresUnidades = '' 
		BEGIN
			Delete from ProUbicacionesUnidadesTemporal where IdUsuario = @IdUsuario	
		END
		ELSE
		BEGIN
			--actualiza la DireccionImagenSeguimiento,UnidadSeleccionada
			UPDATE #TempProUbicacionesUnidadesTemp SET
			DireccionImagenSeguimiento = ISNULL((SELECT put.DireccionImagenSeguimiento FROM ProUbicacionesUnidadesTemporal AS put WHERE put.NoSerie = #TempProUbicacionesUnidadesTemp.NoSerie AND put.IdUsuario = @IdUsuario),'/GMTERPV8_WEB/Imagenes/OJOINACTIVO.png'),
			UnidadSeleccionada = ISNULL((SELECT put.UnidadSeleccionada FROM ProUbicacionesUnidadesTemporal AS put WHERE put.NoSerie = #TempProUbicacionesUnidadesTemp.NoSerie AND put.IdUsuario = @IdUsuario),1)

			set @Consulta = N'DELETE FROM ProUbicacionesUnidadesTemporal WHERE NoSerie IN ('+@sIdentificadoresUnidades+') and IdUsuario = '+cast(@IdUsuario as varchar)
			EXEC dbo.sp_executesql @Consulta
		END
		
		INSERT INTO ProUbicacionesUnidadesTemporal (Unidad,Pais,
		Estado,Ciudad,
		Calle,Evento,
		Icono,
		ExisteAlertaReporteo,DireccionImagenAdvertencia,
		DentroGeocerca,RFC,
		FechaHoraPaquete,
		TiempoEstimado,
		Velocidad,PorcentajeBateria,
		VoltajeVehiculo,CadenaLitros,
		Direccion,Latitud,
		Longitud,CodigoEvento,
		Posicion,NoSerie,
		Odometro,
		EstadoMotor,Temperatura,
		FechaHoraUltimaPeticion,FechaHoraUnidad,
		HASHGPS,CantidadSatelites,
		LinkGoogleMaps,
		FechaHoraServidor,
		IdUsuario,
		EstadoModoTrabajo,
		EstadoModuloGPS,
		NivelGSM,
		TipoSenal,
		VoltajeBateriaInterna,
		SumaLitrosTanques,
		TieneSensores,
		NivelCombustiblePorcentaje,
		DireccionImagenInfo,
		DireccionImagenSeguimiento,
		UnidadSeleccionada,
		EventoPSalidaGeo,
		EventoPEntradaGeo,
		EventoPDemorado,
		EventoPFueraRuta,
		EventoPTempAlta,
		EventoPTempBaja,
		DireccionImagenUnidad,
		IdUnidad,
		GrupoUnidades,
		IdGrupoUnidad,
		UnidadOperador,
		Viaje,
		Identificador,
		Ruta,
		Operador,
		Remolque1,
		Remolque2,
		EstatusViaje,
		CapacidadTanque1,
		CapacidadTanque2,
		CapacidadTanque3,
		CapacidadTanque4
		)
		SELECT cu.Codigo,put.Pais,
		put.Estado,put.Ciudad,
		put.Calle,put.Evento,
		CASE 
		WHEN put.Codigo = 3 AND Cast(Replace(put.Velocidad,' km/h','') As int) = 0 THEN 'POSICIONMOTOR'
		WHEN put.Codigo = 3 AND Cast(Replace(put.Velocidad,' km/h','') As int) != 0 THEN 
			CASE 
				WHEN cu.NombreImagenUnidad ='' THEN  'DIRECCIONMOTOR'+put.Direccion
				ELSE ISNULL(cu.NombreImagenUnidad,'DIRECCIONMOTOR')+put.Direccion
			END
		WHEN put.Codigo in (58,59) AND Cast(Replace(put.Velocidad,' km/h','') As int) != 0 THEN put.Icono+put.Direccion
		ELSE ISNULL(put.Icono,'MARKERG')
		END
		AS Icono,
		put.ExisteAlertaReporteo,put.DireccionImagenAdvertencia,
		put.DentroGeocerca,put.RFC,
		put.FechaHoraPaquete,
		put.TiempoEstimadoUltimoReporte,
		put.Velocidad,put.PorcentajeBateria,
		put.VoltajeVehiculo,put.CadenaLitros,
		put.Direccion,put.Latitud,
		put.Longitud,put.Codigo,
		put.Posicion,put.NoSerie,
		put.OdometroGPS,
		put.EstadoMotor,put.Temperatura,
		put.FechaHoraUltimaPeticion,put.FechaHoraUnidad,
		put.HASHGPS,put.CantidadSatelite,
		put.LinkGoogleMaps,put.FechaHoraServidor,
		@IdUsuario,
		put.EstadoModoTrabajo,
		put.EstadoModuloGPS,
		put.NivelGSM,
		put.TipoSenal,
		put.VoltajeBateriaInterna,
		put.SumaLitrosTanques,
		put.TieneSensores,
		put.NivelCombustiblePorcentaje,
		'/GMTERPV8_WEB/Imagenes/Info.png',
		put.DireccionImagenSeguimiento,
		put.UnidadSeleccionada,
		ISNULL(put.EventoPSalidaGeo,0),
		ISNULL(put.EventoPEntradaGeo,0),
		ISNULL(put.EventoPDemorado,0),
		ISNULL(put.EventoPFueraRuta,0),
		ISNULL(put.EventoPTempAlta,0),
		ISNULL(put.EventoPTempBaja,0),
		'/GMTERPV8_WEB/Imagenes/'+
		(CASE ISNULL(cu.NombreImagenUnidad,'')
		WHEN '' THEN 'DIRECCIONMOTOR'
		ELSE cu.NombreImagenUnidad
		END)
		+'.png',--DireccionImagenUnidad
		cu.IdUnidad,
		Replace(cgu.GrupoUnidad,' ',''),
		cu.IdGrupoUnidad,
		SUBSTRING(cu.Codigo+(CASE ISNULL(co.Nombre,'')
		WHEN '' THEN ''
		ELSE '/'+co.Nombre
		END),1,30), --UnidadOperador
		'',--Viaje
		'',--Identificador
		'',--Ruta
		'',--Operador
		'',--Remolque1
		'',--Remolque2
		'',--EstatusViaje
		ISNULL(put.CapacidadTanque1,0),
		ISNULL(put.CapacidadTanque2,0),
		ISNULL(put.CapacidadTanque3,0),
		ISNULL(put.CapacidadTanque4,0)
		FROM #TempProUbicacionesUnidadesTemp AS put
		INNER JOIN CatUnidades AS cu ON put.NoSerie = cu.IdentificadorSatelital 
		LEFT JOIN CatOperadores as co ON cu.IdOperador = co.IdOperador
		INNER JOIN CatGruposUnidades AS cgu ON cu.IdGrupoUnidad = cgu.IdGrupoUnidad
		INNER JOIN CatUsuarios AS cus ON cus.IdUsuario = @IdUsuario
		WHERE cu.IdGrupoUnidad IN(SELECT CatGrupoUnidades.IdGrupoUnidad AS IdGrupoUnidad FROM CatGrupoUnidadesTemporal as CatGrupoUnidades WHERE  CatGrupoUnidades.IdUsuario = @IdUsuario)
		AND cu.Activa = 1
		AND ((cus.TipoUsuario = 5 AND cu.IdUnidad IN(SELECT cueu.IdUnidad 
		FROM CatUsuariosEspejosUnidades  AS cueu 
		WHERE cueu.IdUsuarioEspejo = @IdUsuario AND cueu.FechaVencimiento > @FechaHoraSucursal)) OR(cus.TipoUsuario != 5))
		;

		WITH cte AS ( 
		SELECT cu.IdentificadorSatelital,cu.IdUnidad,cu.IdGrupoUnidad,cu.NombreImagenUnidad,cu.Codigo,co.Nombre as NombreOperadorCatalogo,cgu.GrupoUnidad,cs.Abreviacion,pv.Viaje,
		cor.OrigenDestino as Origen, cde.OrigenDestino as Destino, pv.NoViajeCliente, co1.Nombre as NombreOperadorViaje,pv.CodigoUnidadCarga1, pv.CodigoUnidadCarga2, cev.Estatus,
		ROW_NUMBER() OVER (partition by cu.IdentificadorSatelital ORDER BY cu.IdentificadorSatelital) AS rownumber
		FROM CatUnidades AS cu 
		LEFT JOIN CatOperadores as co ON cu.IdOperador = co.IdOperador
		LEFT JOIN CatGruposUnidades AS cgu ON cu.IdGrupoUnidad = cgu.IdGrupoUnidad  
		LEFT JOIN ProViajesTrayectos AS pvt ON cu.IdUnidad = pvt.IdUnidadCamion
		LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion
		LEFT JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
		LEFT JOIN CatOrigenesDestinos AS cor ON pvt.IdOrigen = cor.IdOrigenDestino
		LEFT JOIN CatOrigenesDestinos AS cde ON pvt.IdDestino = cde.IdOrigenDestino
		LEFT JOIN CatSucursales AS cs ON pv.IdSucursal = cs.IdSucursal
		LEFT JOIN CatEstatusViaje AS cev ON cev.IdEstatuViaje = pv.IdEstatuViaje
		LEFT JOIN CatOperadores AS co1 ON pvt.IdOperador = co1.IdOperador 
		WHERE  cu.IdUnidad IN(SELECT puut.IdUnidad FROM ProUbicacionesUnidadesTemporal AS puut WHERE puut.IdUsuario = @IdUsuario)
		AND ((pvt.Salida IS NOT NULL AND pvt.Llegada IS NULL AND pv.CanceladoEl IS NULL AND (pvt.IdLiquidacion IS NULL OR (pvt.IdLiquidacion IS NOT NULL AND pl.CerradaEl IS NULL)) AND pv.IdViajeCompuestoPadre IS NULL)) 
		)

		UPDATE ProUbicacionesUnidadesTemporal SET 
		Viaje = c.Abreviacion+'-'+LEFT(@variable,6 - LEN(c.Viaje))+cast(c.Viaje as varchar),
		Identificador = c.NoViajeCliente,
		Ruta = c.Origen+' / '+c.Destino,
		Operador = c.NombreOperadorViaje,
		Remolque1 = c.CodigoUnidadCarga1,
		Remolque2 = c.CodigoUnidadCarga2,
		EstatusViaje = c.Estatus
		FROM ProUbicacionesUnidadesTemporal AS puut 
		INNER JOIN cte AS c ON puut.IdUnidad = c.IdUnidad
		WHERE puut.IdUsuario = @IdUsuario AND c.rownumber = 1 

		SELECT TOP 1 FechaHoraUltimaPeticion,FechaHoraServidor
		FROM #TempProUbicacionesUnidadesTemp
	END	

END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION

	EXECUTE usp_SisErrorsGrabar @IdPeticion;
END CATCH

IF @@TRANCOUNT > 0  
    COMMIT TRANSACTION;
go

