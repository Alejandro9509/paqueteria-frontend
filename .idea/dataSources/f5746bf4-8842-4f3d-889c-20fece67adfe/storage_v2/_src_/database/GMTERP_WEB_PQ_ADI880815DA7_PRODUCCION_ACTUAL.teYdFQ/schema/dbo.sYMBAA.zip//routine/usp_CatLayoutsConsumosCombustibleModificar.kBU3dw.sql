CREATE PROCEDURE [dbo].[usp_CatLayoutsConsumosCombustibleModificar]
	@Layout	varchar(50),
	@TipoArchivo tinyint,
	@Separador	varchar(1),
	@RenglonInicial	tinyint,
	@ColumnaNumeroComprobante tinyint,
	@ColumnaTarjeta	tinyint,
	@FechaHoraJuntas bit,
	@ColumnaFechaHora tinyint,
	@FormatoFechaHora	varchar(26),
	@ColumnaFecha	tinyint,
	@FormatoFecha	varchar(15),
	@ColumnaHora	tinyint,
	@FormatoHora	varchar(15),
	@ColumnaLitros	tinyint,
	@TieneColumnaImporteIVA bit,
	@ColumnaImporteIVA	tinyint,
	@ColumnaTotal	tinyint,
	@ColumnaOdometro tinyint,
	@ModificadoEl	datetime,
	@ModificadoPor	int,
	@IdPeticion varchar(100),
	@IdLayoutConsumoCombustible	int,
	@MillasGalonesDolares bit
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF @IdLayoutConsumoCombustible = 0
			RAISERROR(N'El identificador del layout es un campo requerido',
				16,
				1
				)

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
	
		UPDATE CatLayoutsConsumosCombustible SET 
		Layout = @Layout,
		TipoArchivo = @TipoArchivo,
		Separador = @Separador,
		RenglonInicial = @RenglonInicial,
		ColumnaNumeroComprobante = @ColumnaNumeroComprobante,
		ColumnaTarjeta = @ColumnaTarjeta,
		FechaHoraJuntas = @FechaHoraJuntas,
		ColumnaFechaHora = @ColumnaFechaHora,
		FormatoFechaHora = @FormatoFechaHora,
		ColumnaFecha = @ColumnaFecha,
		FormatoFecha = @FormatoFecha,
		ColumnaHora = @ColumnaHora,
		FormatoHora = @FormatoHora,
		ColumnaLitros = @ColumnaLitros,
		TieneColumnaImporteIVA = @TieneColumnaImporteIVA,
		ColumnaImporteIVA = @ColumnaImporteIVA,
		ColumnaTotal = @ColumnaTotal,
		ColumnaOdometro = @ColumnaOdometro,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		MillasGalonesDolares = @MillasGalonesDolares
		WHERE IdLayoutConsumoCombustible = @IdLayoutConsumoCombustible
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

