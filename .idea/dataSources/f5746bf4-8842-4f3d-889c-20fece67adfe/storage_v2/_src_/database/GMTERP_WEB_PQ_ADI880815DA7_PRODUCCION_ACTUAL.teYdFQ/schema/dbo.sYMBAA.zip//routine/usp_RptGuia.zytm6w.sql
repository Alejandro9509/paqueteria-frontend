CREATE PROCEDURE [dbo].[usp_RptGuia]
@IdGuia int
AS
BEGIN TRY
	BEGIN TRANSACTION
	select PE.FolioEmbarque,PG.FolioGuia,PG.Fecha,
ctc.NumeroCliente,ctc.RFC,ctc.NombreFiscal,ctc.Calle,ctc.NoExterior,ctc.Colonia,ctc.CodigoPostal,ctc.Municipio,
PE.NombreRemitente,PE.RFCRemitente,PE.DomicilioRemitente,PE.ContactoRemitente,PE.TelefonoRemitente,
PE.NombreDestinatario,PE.RFCDestinatario,PE.DomicilioDestinatario,PE.ContactoDestinatario,PE.TelefonoDestinatario,PE.DomicilioEntrega,PE.EntregarEn,PE.DatosAdicionales,
PR.RecoleccionDiferenteDomicilio,PE.IdEmbarque,ctco.Descripcion TipoCobro,PG.Tracking, cats.Sucursal,concat(convert(varchar(10),catf.Folio),'-',catf.Serie) FolioFactura
from ProGuiaPQ PG 
inner join ProEmbarquePQ PE on PG.IdEmbarque = PE.IdEmbarque
inner join CatClientes ctc on ctc.IdCliente=PE.IdCliente
left join ProRecoleccionPQ PR on PE.IdRecoleccion=PR.IdRecoleccion
left Join CatTipoCobroPQ ctco on ctco.IdTipoCobro=PE.IdTipoCobro
left join CatSucursales cats on cats.IdSucursal=PE.IdSucursal
left join ProViajes prv on prv.IdGuia=PG.IdGuia
left join ProViajesFacturas pvf on prv.IdViaje=pvf.IdViaje
left join ProFacturas pf on pf.IdFactura=pvf.IdFactura
left join CatFolios catf on catf.IdFolio=pf.IdFolio
where PG.IdGuia=@IdGuia
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

