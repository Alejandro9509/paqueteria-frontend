CREATE PROCEDURE [dbo].[usp_ProCotizadorAcepto]
@IdCotizacion int,
@Estatus int,
@ContactoAcepto varchar(100),
@AceptadoEl datetime,
@AceptadoPor int,
@IdPeticion varchar(100)


AS

BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdCotizacion,0) <= 0
		RAISERROR(N'El identificador de la cotización es un campo requerido',
			16,
			1
			)	
			
	IF NOT EXISTS(SELECT IdCotizacion FROM ProCotizaciones WHERE IdCotizacion = @IdCotizacion) --Eliminado
		RAISERROR(N'La cotización fue Eliminada por otro usuario. No es posible Aceptarla',
			16,
			1
			)
			
	IF (SELECT Estatus FROM ProCotizaciones WHERE IdCotizacion = @IdCotizacion) = 2 --Aceptado
		RAISERROR(N'La cotización ya fue Aceptada por otro usuario. No es posible Aceptarla',
			16,
			1
			)

    IF (SELECT Estatus FROM ProCotizaciones WHERE IdCotizacion = @IdCotizacion) = 3 --Rechazado
        RAISERROR(N'La Cotización ya fue Rechazada. No es posible Aceptarla',
            16,
            1
            )

   IF LTRIM(RTRIM(@ContactoAcepto))= ''
	RAISERROR(N'El campo ContactoAcepto de la Cotizacion es un campo requerido',
			16,
			1
			) 			  
	IF ISDATE(@AceptadoEl) = 0
		RAISERROR(N'La fecha/hora AceptadoEl es un campo requerido',
			16,
			1
			)	
	IF ISNull(@AceptadoPor,0)=0
	   RAISERROR(N'El Campo AceptadoPor es un campo requerido',
			16,
			1
			) 							  
	
		--1 PENDIENTE
		--2 ACEPTADO
		--3 RECHAZADO
		
		set @Estatus = 2

		UPDATE ProCotizaciones
		SET
			Estatus = @Estatus,
			AceptadoEl =  @AceptadoEl,
			AceptadoPor = @AceptadoPor,
			ContactoAcepto = @ContactoAcepto
		WHERE IdCotizacion = @IdCotizacion
			
	COMMIT
END TRY
BEGIN CATCH    
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion	
END CATCH
go

