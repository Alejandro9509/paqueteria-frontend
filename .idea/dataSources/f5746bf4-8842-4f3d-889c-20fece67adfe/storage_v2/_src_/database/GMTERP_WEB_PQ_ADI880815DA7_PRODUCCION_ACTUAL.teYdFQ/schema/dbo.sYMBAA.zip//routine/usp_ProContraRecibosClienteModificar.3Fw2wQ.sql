
create PROCEDURE [dbo].[usp_ProContraRecibosClienteModificar]
@IdContraReciboCliente int,
@Folio int,
@IdCliente int,
@FechaHora datetime,
@ReferenciaCliente varchar(15),
@FechaProgramadoPago datetime,
@TotalPesos money,
@TotalDolares money,
@TotalAbonoPesos money,
@TotalAbonoDolares money,
@TotalSaldoPesos money,
@TotalSaldoDolares money,
@Estatus tinyint,
@dsProContraRecibosClienteFacturas ntext,
@ModificadoPor int,
@ModificadoEl datetime,
@IdPeticion varchar(100),
@UltimaModificacion	datetime
AS
DECLARE @docHandle int,
		@ATT_IdFactura int,
		@ATT_Importe money,
		@DoctoFactura varchar(50),
		@MensajeError varchar(250),
		@EstatusPendPago int,
		@EstatusPagada int,
		@EstatusCancelada int,
		@ImporteAdeudo money, 
		@EstatusActualFactura int,
		@FolioContraRecibo int ,
		@CantidadFacturasPagadas int
BEGIN TRY
	BEGIN TRANSACTION
	
		SET @EstatusPendPago = 0
		SET @EstatusPagada = 1
		SET @EstatusCancelada = 2

	IF ISNULL(@IdContraReciboCliente,0)= 0
		RAISERROR(N'El identificador de contra recibo es un campo requerido',
			16,
			1
			)
			
	IF (SELECT ModificadoEl FROM ProContraRecibosCliente  WHERE IdContraReciboCliente = @IdContraReciboCliente) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
								
	IF ISNULL(@Folio,0)= 0
		RAISERROR(N'El folio de contra recibo es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Folio FROM ProContraRecibosCliente WHERE Folio= @Folio AND IdContraReciboCliente <> @IdContraReciboCliente)
		RAISERROR(N'El folio del contra recibo ya fue utilizado por otro usuario, revise la información',
			16,
			1
			)
			
	IF EXISTS(SELECT Folio FROM ProContraRecibosCliente WHERE IdContraReciboCliente = @IdContraReciboCliente AND CanceladoEl IS NOT NULL)
		RAISERROR(N'El contra recibo ya fue cancelada por otro usuario, revise la información',
			16,
			1
			)
			
					
										
	IF ISNULL(@IdCliente,0)= 0
		RAISERROR(N'Identificador de cliente es un campo requerido',
			16,
			1
			)
						
	IF ISDATE(@FechaHora)= 0
		RAISERROR(N'Fecha de contra recibo es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaProgramadoPago)= 0
		RAISERROR(N'Fecha programado de pago es un campo requerido',
			16,
			1
			)

	UPDATE ProContraRecibosCliente
		 SET Folio = @Folio,
			 IdCliente = @IdCliente,
			 FechaHora = @FechaHora,
			 ReferenciaCliente = @ReferenciaCliente,
			 FechaProgramadoPago = @FechaProgramadoPago,
			 TotalPesos = @TotalPesos,
			 TotalDolares = @TotalDolares,
			 TotalAbonoPesos = @TotalAbonoPesos,
			 TotalAbonoDolares = @TotalAbonoDolares,
			 TotalSaldoPesos = @TotalSaldoPesos,
			 TotalSaldoDolares = @TotalSaldoDolares,
			 Estatus = @Estatus,
			 ModificadoPor = @ModificadoPor,
			 ModificadoEl = @ModificadoEl
	WHERE IdContraReciboCliente  =   @IdContraReciboCliente 

  -- Valida que alguna factura ya esta pagada.
	 SET @CantidadFacturasPagadas =(SELECT  count(ProFacturas.Estatus)
														FROM  ProContraRecibosClienteFacturas INNER JOIN
																	   ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
														WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente =@IdContraReciboCliente and ProFacturas.Estatus = 1))
	 IF @CantidadFacturasPagadas > 0
	 		RAISERROR(N'El contra recibo que intenta modificar ya tiene facturas pagadas por otro usuario,revise la información',
			16,
			1
			)
			
			
	 DELETE  ProContraRecibosClienteFacturas WHERE IdContraReciboCliente = @IdContraReciboCliente 
	 
  -- REGISTRAR EN EL PUENTE CONTRARECIBOS CLIENTE  / FACTURAS. 

	IF @dsProContraRecibosClienteFacturas IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProContraRecibosClienteFacturas 

		SELECT ATT_IdFactura,ATT_Importe
		INTO #TempProContraRecibosClienteFacturas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturas',2) 
		WITH (ATT_IdFactura int,ATT_Importe money)

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE ProContraRecibosClienteFacturasCursor CURSOR FOR
		SELECT ATT_IdFactura,ATT_Importe FROM #TempProContraRecibosClienteFacturas 

		OPEN ProContraRecibosClienteFacturasCursor
		FETCH NEXT FROM ProContraRecibosClienteFacturasCursor INTO @ATT_IdFactura,@ATT_Importe
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
		
		-- Validar concurrencia de facturas al registrar detalle.
		
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @ATT_IdFactura)

		SELECT @EstatusActualFactura  = ISNULL(Estatus,0), @ImporteAdeudo = (Total-Isnull(Abonos,0))  FROM ProFacturas WHERE IdFactura = @ATT_IdFactura

		--Valida si esta cancelada
		IF @EstatusActualFactura = @EstatusCancelada -- cancelado = 2
			BEGIN
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya fue cancelada por otro usuario' 
					 RAISERROR(@MensajeError,
							16,
							1
							)
			END										

		--Valida si esta pagada
		IF @EstatusActualFactura = @EstatusPagada -- Pagada = 1
			BEGIN
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya fue pagada por otro usuario' 
					 RAISERROR(@MensajeError,
							16,
							1
							)
			END
			
		--Valida si esta pendiente de pago y el importe adeudado no sea diferente.
		IF @EstatusActualFactura = @EstatusPendPago AND @ImporteAdeudo <>  @ATT_Importe -- Pendiente de pago = 0
			BEGIN
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya tiene importe abonado por otro usuario' 
					 RAISERROR(@MensajeError,
							16,
							1
							)
			END
			
		-- Valida que la factura no este en un contra recibo
		IF EXISTS(SELECT ProContraRecibosCliente.Folio
							FROM  ProContraRecibosClienteFacturas INNER JOIN
								 ProContraRecibosCliente 
								 ON ProContraRecibosClienteFacturas.IdContraReciboCliente = ProContraRecibosCliente.IdContraReciboCliente	
							WHERE ProContraRecibosCliente.CanceladoEl IS NULL AND  ProContraRecibosClienteFacturas.IdFactura = @ATT_IdFactura)
			BEGIN
				SET @FolioContraRecibo = (SELECT TOP 1 ProContraRecibosCliente.Folio
										FROM  ProContraRecibosClienteFacturas INNER JOIN
											 ProContraRecibosCliente 
											 ON ProContraRecibosClienteFacturas.IdContraReciboCliente = ProContraRecibosCliente.IdContraReciboCliente	
										WHERE ProContraRecibosCliente.CanceladoEl IS NULL AND  ProContraRecibosClienteFacturas.IdFactura =  @ATT_IdFactura)
						 
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya esta relacionado al contra recibo folio '+cast(@FolioContraRecibo as varchar(6))
				  
				 RAISERROR(@MensajeError,
							16,
							1
							)
			END
	
		-- Registrar facturas en el detalle del contra recibo
		    INSERT INTO ProContraRecibosClienteFacturas (IdContraReciboCliente,IdFactura,Importe) values (@IdContraReciboCliente,@ATT_IdFactura,@ATT_Importe)
		 
			FETCH NEXT FROM ProContraRecibosClienteFacturasCursor
			INTO @ATT_IdFactura,@ATT_Importe
		END   
		
		CLOSE ProContraRecibosClienteFacturasCursor
		DEALLOCATE ProContraRecibosClienteFacturasCursor

	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

