CREATE PROCEDURE [dbo].[usp_CatGruposClientesModificar]
@IdGrupoCliente int,
@Codigo			int,	
@Grupo			varchar(50),	
@ModificadoEl	datetime,
@ModificadoPor  int,
@IdPeticion		varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdGrupoCliente,0)= 0
	RAISERROR(N'El identificador de grupo de cliente es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de grupo de cliente es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Codigo FROM CatGruposClientes WHERE Codigo = @Codigo And IdGrupoCliente <> @IdGrupoCliente)
		RAISERROR(N'El código de grupo de cliente ya existe, verificar infromación',
			16,
			1
			)	
						
			
	IF ISNULL(@Grupo,'')= ''
		RAISERROR(N'Descripción de grupo de cliente es un campo requerido',
			16,
			1
			)
			
	UPDATE CatGruposClientes SET
			Codigo		  = @Codigo,
			Grupo		  = @Grupo,
			ModificadoEl  = @ModificadoEl,
			ModificadoPor = @ModificadoPor
	WHERE IdGrupoCliente=@IdGrupoCliente
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

