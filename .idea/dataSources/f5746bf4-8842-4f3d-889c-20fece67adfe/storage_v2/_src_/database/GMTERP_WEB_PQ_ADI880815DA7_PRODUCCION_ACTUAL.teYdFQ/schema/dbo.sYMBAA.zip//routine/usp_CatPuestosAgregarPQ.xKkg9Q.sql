CREATE PROCEDURE [dbo].[usp_CatPuestosAgregarPQ](
	@Codigo VARCHAR(3),
	@Puesto VARCHAR(50),
	@CreadoEl DATETIME,
	@CreadoPor INT,
	@ModificadoEl DATETIME,
	@ModificadoPor INT)
AS
BEGIN
	BEGIN TRANSACTION begin
		IF ISNULL(@Codigo, '') = ''
			RAISERROR(N'*INICIO*El código del Puesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		IF ISNULL(@Puesto, '') = '' begin
			RAISERROR(N'*INICIO*El puesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		INSERT INTO CatPuestos(Codigo, Puesto, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
		VALUES (@Codigo, @Puesto, @CreadoEl, @CreadoPor,@ModificadoEl,@ModificadoPor)
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

