
CREATE PROCEDURE [dbo].[usp_CatRutasPersonalGetMaxFolioRuta]

AS

SELECT ISNULL(MAX(FolioRuta),0)+1 AS FolioRuta FROM CatRutasPersonal
go

