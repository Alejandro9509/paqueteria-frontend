CREATE PROCEDURE [dbo].[usp_ProDescargasCombustibleModificar]
@IdDescargaCombustible int,
@Folio int,
@NumeroOrden varchar(30) ,
@Fecha datetime ,
@LitrosDescarga decimal(15, 4),
@SolicitadaEl datetime,
@LitrosSolicitada decimal(15, 4),
@EstatusSello int ,
@Costo money,
@ExistenciaCombustible decimal(15, 4),
@IdContenedor int,
@IdSucursal int,
@RevisadoPor int,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100),
@PlacasPipa varchar(10),
@Observacion varchar(300)
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF EXISTS(SELECT  TOP 1 IdDescargaCombustible FROM  ProCargasCombustibleDetalle WHERE IdDescargaCombustible = @IdDescargaCombustible)
		RAISERROR(N'Ya tiene cargas de combustible, no es posible modificar',
			16,
			1
			)	

	IF ISNULL(@IdDescargaCombustible,0)= 0
		RAISERROR(N'Identificador de descarga de combustible es un campo requerido',
			16,
			1
			)	
	
	IF ISNULL(@Folio,0)= 0
		RAISERROR(N'Folio de descarga es un campo requerido',
			16,
			1
			)

	IF ISNULL(@NumeroOrden,'')= ''
		RAISERROR(N'Número de orden es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@Fecha,'') = ''
		RAISERROR(N'Fecha es un campo requerido',
			16,
			1
			)	
			
	IF ISNULL(@LitrosDescarga,0)= 0
		RAISERROR(N'Litros de descarga es un campo requerido',
			16,
			1
			)
	IF ISNULL(@SolicitadaEl,'') = ''
		RAISERROR(N'Fecha solicitada es un campo requerido',
			16,
			1
			)	
			
	IF ISNULL(@LitrosSolicitada,0) = 0
		RAISERROR(N'Litros solicitada es un campo requerido',
			16,
			1
			)	
			
	IF ISNULL(@Costo,0) = 0
		RAISERROR(N'El costo es un campo requerido',
			16,
			1
			)
	IF @Fecha <	@SolicitadaEl
		RAISERROR(N'Fecha de descarga no debe ser menor a la fecha solicitada',
			16,
			1
			)					
			
	UPDATE ProDescargasCombustible
	SET Folio = @Folio,
		NumeroOrden = @NumeroOrden,
		Fecha = @Fecha,
		LitrosDescarga = @LitrosDescarga,
		SolicitadaEl = @SolicitadaEl, 
		LitrosSolicitada = @LitrosSolicitada,
		EstatusSello = @EstatusSello,
		Costo = @Costo,
		ExistenciaCombustible = @ExistenciaCombustible,
		IdContenedor = @IdContenedor,
		IdSucursal = @IdSucursal,
		RevisadoPor = @RevisadoPor,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		PlacasPipa  = @PlacasPipa,
		Observacion = @Observacion 
	WHERE IdDescargaCombustible = @IdDescargaCombustible
	

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

