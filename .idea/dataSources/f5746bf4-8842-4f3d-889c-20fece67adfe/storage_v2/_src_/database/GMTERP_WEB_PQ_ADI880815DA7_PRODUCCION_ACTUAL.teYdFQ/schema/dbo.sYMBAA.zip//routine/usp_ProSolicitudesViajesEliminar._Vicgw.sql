CREATE PROCEDURE [dbo].[usp_ProSolicitudesViajesEliminar]
	@IdSolicitudViaje int,
	@IdPeticion varchar(100)
AS
DECLARE
	@Estatus int
BEGIN TRY
	BEGIN TRANSACTION
	
	SET @Estatus = (SELECT Estatus FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje)
	
	IF @Estatus <> 2 --Si es diferente de Pendiente
		RAISERROR(N'La solicitud no se puede eliminar debido a que fue cambiado su estatus',
			16,
			1
			)
			
	IF NOT EXISTS(SELECT IdSolicitudViaje FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)	
	---Borramos de ProSolicitudesViajes
	DELETE FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje
	
	---Borramos en ProSolicitudesViajesDetalleEquipo
	DELETE FROM ProSolicitudesViajesDetalleEquipo WHERE IdSolicitudViaje = @IdSolicitudViaje
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

