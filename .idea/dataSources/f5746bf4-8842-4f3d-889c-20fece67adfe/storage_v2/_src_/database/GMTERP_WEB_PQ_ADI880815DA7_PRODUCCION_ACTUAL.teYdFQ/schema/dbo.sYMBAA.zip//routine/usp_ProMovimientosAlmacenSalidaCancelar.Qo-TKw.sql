CREATE  PROCEDURE [dbo].[usp_ProMovimientosAlmacenSalidaCancelar]
@IdMovimientoAlmacen int,
@MotivoCancelacion varchar(500),
@IdTipoMovimientoAlmacen int,
@CanceladoEl datetime,
@CanceladoPor int,
@IdPeticion varchar(100),
@UltimaModificacion datetime,
@EsTraspaso bit = 0 --SOL 171
	/* *************************************************************************************************
	SOLICITUD 601

	Descripcion: Se modifico el rollback para que ahora se ejecute correctamente al aplicar
	el trigger de bloqueo ubicado en ProMovimientosAlmacenConceptos
	
	Modificada por:   Amado Navarro
	Fecha de mofidicacion: 15/11/2019
	Versión: Versión 8.0.47.47

	Invocada desde: <PAGE_ProMovimientosAlmacenListado>
	************************************************************************************************ */
	/*
	SOLICITUD 1681

	Descripcion: Se incluyó el campo Observaciones al insertar en la tabla ProMoimientosAlmacenConceptos, ya que se estaba 
				 omitiendo

	Modificada por:   Julio Hermosillo
	Fecha de mofidicacion: 15/05/2020
	Versión: Versión Versión 8.0.52.11

	Invocada desde: <PAGE_ProMovimientosAlmacenEntradaCancelar>
	************************************************************************************************ */
		/* *************************************************************************************************
	
	*/
AS
DECLARE
@TipoMovimiento int,
@FolioMovimientoAlmacen  int,
@IdMovimientoAlmacenSalida int,
@ExistenciaActual decimal(15,4),
@ImporteTotalPromedioActual money,
@ImporteTotalPromedioActualDlls money,
@CostoPromedioActual money,
@CostoPromedioActualDlls money,
@FolioOS varchar(50)
BEGIN TRY
	BEGIN TRANSACTION
	SET @ExistenciaActual = 0
	SET @ImporteTotalPromedioActual = 0
	SET @CostoPromedioActual  = 0
	SET @ImporteTotalPromedioActualDlls = 0
	SET @CostoPromedioActualDlls  = 0	
	SET @TipoMovimiento = 1 -- Entrada
	
	IF ISNULL(@IdMovimientoAlmacen,0) = 0
		RAISERROR(N'El identificador del movimiento de almacén es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@MotivoCancelacion,'')='' 
		 RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)	
	
	IF ISDATE(@CanceladoEl)=0 
		RAISERROR(N'La fecha de cancelación es un campo requerido',
			16,
			1
			)	
	
	IF (SELECT ModificadoEl FROM ProMovimientosAlmacen WHERE IdMovimientoAlmacen= @IdMovimientoAlmacen) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
								
	-- Valida que el movimiento  no este cancelada		
	IF (SELECT CanceladoEl FROM ProMovimientosAlmacen WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen) IS NOT NULL --cancelado
					RAISERROR(N'No puede cancelar este movimiento porque está cancelada',
						16,
						1
						)

		-- Valida que el movimiento no sea por salida por traspaso SOLICITUD 171
	IF @EsTraspaso = 0
	IF EXISTS(SELECT  IdMovimientoAlmacenSalida FROM ProMovimientosAlmacenTraspasos WHERE  IdMovimientoAlmacenSalida =@IdMovimientoAlmacen)
			RAISERROR(N'El movimiento de salida al almacén pertence a un movimiento por traspaso',
					16,
					1
					)


	IF (SELECT IdMovimientoAlmacenQueCancela FROM ProMovimientosAlmacen WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen) IS NOT NULL --cancelado
					RAISERROR(N'No puede cancelar este movimiento porque está cancelada',
						16,
						1
						)
	
	IF EXISTS(SELECT ctma.Movimiento
						FROM   ProMovimientosAlmacen AS pma
							   INNER JOIN CatTiposMovimientosAlmacen AS ctma
									   ON pma.IdTipoMovimientoAlmacen = ctma.IdTipoMovimientoAlmacen
						WHERE ctma.Tipo = 1
							   AND pma.IdMovimientoAlmacen = @IdMovimientoAlmacen )
					RAISERROR(N'El movimiento de almacén es de entrada, no es posible cancelar',
						16,
						1
						)


	IF EXISTS(SELECT ctma.Movimiento
						FROM   ProMovimientosAlmacen AS pma
							   INNER JOIN CatTiposMovimientosAlmacen AS ctma
									   ON pma.IdTipoMovimientoAlmacen = ctma.IdTipoMovimientoAlmacen
						WHERE  ctma.Movimiento = 'DESAFECTAR SALIDA'
							   AND ctma.Tipo = 2
							   AND ctma.DefinidoPorSistema = 1
							   AND pma.IdMovimientoAlmacen = @IdMovimientoAlmacen )
					RAISERROR(N'El movimiento de almacén del tipo desafectar salida, no es posible cancelar',
						16,
						1
						)

	IF EXISTS(SELECT ctma.Movimiento
						FROM   ProMovimientosAlmacen AS pma
							   INNER JOIN CatTiposMovimientosAlmacen AS ctma
									   ON pma.IdTipoMovimientoAlmacen = ctma.IdTipoMovimientoAlmacen
						WHERE  ctma.Movimiento = 'SALIDA POR CANCELACION'
							   AND ctma.Tipo = 2
							   AND ctma.DefinidoPorSistema = 1
							   AND pma.IdMovimientoAlmacen = @IdMovimientoAlmacen )
					RAISERROR(N'El movimiento de almacén del tipo salida por cancelación, no es posible cancelar',
						16,
						1
						)


	SET @FolioMovimientoAlmacen  = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)
	SET @FolioOS = CAST((select distinct PROS.Folio from ProOrdenesServicios as PROS 
		left Join ProOrdenesServiciosDetalles as PROSD on PROS.IdOrdenServicio = PROSD.IdOrdenServicio
		left join ProOrdenesServiciosPartes as posp on PROSD.IdOrdenServicioDetalle = posp.IdOrdenServicioDetalle 
		left join ProMovimientosAlmacenConceptos as pmac on pmac.IdMovimientoAlmacenConcepto = posp.IdMovimientoAlmacenConcepto
		left join ProOrdenesServiciosPartesDevolucion as pospd on pospd.IdOrdenServicioParte = posp.IdOrdenServicioParte
		left join ProMovimientosAlmacen as pma on pmac.IdMovimientoAlmacen = pma.IdMovimientoAlmacen
		where pma.IdMovimientoAlmacen = @IdMovimientoAlmacen) as varchar (50))
		
	---- Registrar salida por devolución
	INSERT INTO ProMovimientosAlmacen(
				Estatus,
				FechaHora,
				IdProveedor,
				Folio,
				IdMoneda,
				Observaciones,
				SubTotal,
				SubTotalDlls,
				TipoCambio,
				Total,
				TotalDlls,
				IdImpuestosTrasladadosFederales,
				ImpuestosTrasladadosFederales,
				ImpuestosTrasladadosFederalesDlls,
				IdImpuestosRetenidosFederales,
				ImpuestosRetenidosFederales,
				ImpuestosRetenidosFederalesDlls,
				IdImpuestosTrasladadosLocales,
				ImpuestosTrasladadosLocales,
				ImpuestosTrasladadosLocalesDlls,
				IdImpuestosRetenidosLocales,
				ImpuestosRetenidosLocales,
				ImpuestosRetenidosLocalesDlls,
				IdTipoMovimientoAlmacen,
				CreadoEl,
				CreadoPor,
				Referencia)
			SELECT 
				pma.Estatus,
				pma.FechaHora,
				pma.IdProveedor,
				@FolioMovimientoAlmacen,
				pma.IdMoneda,
				pma.Observaciones,
				-ISNULL(pma.SubTotal,0),
				-ISNULL(pma.SubTotalDlls,0),
				pma.TipoCambio,
				-ISNULL(pma.Total,0),
				-ISNULL(pma.TotalDlls,0),
				pma.IdImpuestosTrasladadosFederales,
				-ISNULL(pma.ImpuestosTrasladadosFederales,0),
				-ISNULL(pma.ImpuestosTrasladadosFederalesDlls,0),
				pma.IdImpuestosRetenidosFederales,
				-ISNULL(pma.ImpuestosRetenidosFederales,0),
				-ISNULL(pma.ImpuestosRetenidosFederalesDlls,0),
				pma.IdImpuestosTrasladadosLocales,
				-ISNULL(pma.ImpuestosTrasladadosLocales,0),
				-ISNULL(pma.ImpuestosTrasladadosLocalesDlls,0),
				pma.IdImpuestosRetenidosLocales,
				-ISNULL(pma.ImpuestosRetenidosLocales,0),
				-ISNULL(pma.ImpuestosRetenidosLocalesDlls,0),
				@IdTipoMovimientoAlmacen,
				@CanceladoEl,
				@CanceladoPor,
				CASE
					when @FolioOS Is not null then
						'DESAFECTAR INVENTARIO POR ORDEN DE SERVICIO FOLIO: '+@FolioOS
					ELSE
						'SE CANCELA EL MOVIMIENTO DE ALMACEN, FOLIO: ' + CAST(pma.Folio as varchar(10))+', DE LA FECHA '+CONVERT(varchar, CONVERT(datetime, FechaHora), 103)
				END
	FROM ProMovimientosAlmacen AS pma WHERE pma.IdMovimientoAlmacen = @IdMovimientoAlmacen
	--
	SET @IdMovimientoAlmacenSalida = (SELECT IDENT_CURRENT('ProMovimientosAlmacen'))
	
	
	---- Registrar detalle 	
	DECLARE @ATT_IdArticulo int,
			@ATT_Cantidad decimal(15,4),
			@ATT_Entregado decimal(15,4),
			@ATT_Pendiente decimal(15,4),
			@ATT_PrecioUnitario money,
			@ATT_PrecioUnitarioDlls money,
			@ATT_Importe money,
			@ATT_Observaciones varchar(255),
			@ATT_ImporteDlls money,
			@ATT_UnidadMedida varchar(30),
			@ATT_IdAlmacen int, 
			@ATT_IdMovimientoAlmacenConcepto int

	DECLARE TempProMovimientosAlmacenConceptosL CURSOR local FOR 
    SELECT IdArticulo,
			-ISNULL(Cantidad,0),
			-ISNULL(Entregado,0) AS Entregado,
			-ISNULL(Pendiente,0) As Pendiente,
			PrecioUnitario,
			PrecioUnitarioDlls,
			-ISNULL(Importe,0),
			Observaciones,
			-ISNULL(ImporteDlls,0),
			UnidadMedida,
			IdAlmacen,
			IdMovimientoAlmacenConcepto 
	FROM ProMovimientosAlmacenConceptos WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen

	OPEN TempProMovimientosAlmacenConceptosL
	FETCH NEXT FROM TempProMovimientosAlmacenConceptosL INTO 
					@ATT_IdArticulo,
					@ATT_Cantidad,
					@ATT_Entregado,
					@ATT_Pendiente,
					@ATT_PrecioUnitario,
					@ATT_PrecioUnitarioDlls,
					@ATT_Importe,
					@ATT_Observaciones,
					@ATT_ImporteDlls,
					@ATT_UnidadMedida,
					@ATT_IdAlmacen,
					@ATT_IdMovimientoAlmacenConcepto  

	WHILE @@fetch_status = 0
		BEGIN
			 --- Detectar las salidas del movimiento 		 
		 DECLARE  @CursorIdMovimientoAlmacenConceptoEntrada int, 
				  @CursorIdMovimientoAlmacenConceptoSalida INT,
				  @CursorIdArticulo INT,
				  @CursorIdAlmacen INT,
				  @CursorCantidad decimal(15,4),
				  @CursorCostoUnitario money,
				  @CursorCostoUnitarioDlls money
		DECLARE TempProMovimientosAlmacenConceptosPEPS CURSOR local FOR 
		SELECT 
				  pmaPEPS.IdMovimientoAlmacenConceptoEntrada, 
				  pmaPEPS.IdMovimientoAlmacenConceptoSalida,
				  pmaPEPS.IdArticulo,
				  pmaPEPS.IdAlmacen,
				  -pmaPEPS.Cantidad,
				  pmaPEPS.CostoUnitario,
				  pmaPEPS.CostoUnitarioDlls
		 FROM ProMovimientosAlmacenConceptosPEPS  as pmaPEPS
		 WHERE pmaPEPS.IdMovimientoAlmacenConceptoSalida = @ATT_IdMovimientoAlmacenConcepto  

		--------------------------------------------------------------------------------------------------
		OPEN TempProMovimientosAlmacenConceptosPEPS
		FETCH NEXT FROM TempProMovimientosAlmacenConceptosPEPS INTO 
						  @CursorIdMovimientoAlmacenConceptoEntrada, 
						  @CursorIdMovimientoAlmacenConceptoSalida,
						  @CursorIdArticulo,
						  @CursorIdAlmacen,
						  @CursorCantidad,
						  @CursorCostoUnitario,
						  @CursorCostoUnitarioDlls
				WHILE @@fetch_status = 0
					BEGIN
						INSERT INTO ProMovimientosAlmacenConceptos (
								IdArticulo,
								Cantidad,
								PrecioUnitario,
								PrecioUnitarioDlls,
								Importe,
								ImporteDlls,
								Observaciones,
								UnidadMedida,
								IdAlmacen,
								CreadoPor,
								CreadoEl,
								IdMovimientoAlmacen,
								ExistenciaControlPEPS,
								CostoPromedio,
								CostoPromedioDlls)
							VALUES	(@ATT_IdArticulo,
								@CursorCantidad,
								@CursorCostoUnitario,
								@CursorCostoUnitarioDlls,
								@CursorCantidad*@CursorCostoUnitario,
								@CursorCantidad*@CursorCostoUnitarioDlls,
								@ATT_Observaciones,
								@ATT_UnidadMedida,
								@ATT_IdAlmacen,
								@CanceladoPor,
								@CanceladoEl,
								@IdMovimientoAlmacenSalida,
								0,
								@CostoPromedioActual,
								@CostoPromedioActualDlls)	
						
						DECLARE  @IdMovimientoAlmacenConceptoSalida INT
						SET @IdMovimientoAlmacenConceptoSalida = (SELECT IDENT_CURRENT('ProMovimientosAlmacenConceptos'))

						-- Calcular costos 
						SELECT  @ExistenciaActual = Existencia ,
								@ImporteTotalPromedioActual = ImporteTotalPromedio,
								@CostoPromedioActual = CostoPromedio,
								@CostoPromedioActualDlls = CostoPromedioDlls 
						FROM ProInventarioAlmacen
						WHERE IdAlmacen = @CursorIdAlmacen AND IdArticulo = @CursorIdArticulo			
				
						SET @ExistenciaActual = @ExistenciaActual-@CursorCantidad
						SET @ImporteTotalPromedioActual = @ExistenciaActual*@CostoPromedioActual
						SET @ImporteTotalPromedioActualDlls = @ExistenciaActual*@CostoPromedioActualDlls  
							
						-- Registrar costo calculado
						UPDATE ProInventarioAlmacen
						 SET  Existencia	= @ExistenciaActual,
							  CostoPromedio = @CostoPromedioActual,
							  ImporteTotalPromedio=@ImporteTotalPromedioActual,
							  ModificadoEl  = @CanceladoEl,
							  ModificadoPor = @CanceladoPor,
							  CostoPromedioDlls		   = @CostoPromedioActualDlls,
							  ImporteTotalPromedioDlls = @ImporteTotalPromedioActualDlls 
						 WHERE IdAlmacen = @CursorIdAlmacen  AND IdArticulo = @CursorIdArticulo	
	
						SELECT @CostoPromedioActual = CostoPromedio FROM ProInventarioAlmacen WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo	
						SELECT @CostoPromedioActualDlls = CostoPromedioDlls FROM ProInventarioAlmacen WHERE IdAlmacen = @CursorIdAlmacen AND IdArticulo = @CursorIdArticulo	

						--- Actualiza control de stock
						UPDATE ProMovimientosAlmacenConceptos
								SET ExistenciaControlPEPS	= ExistenciaControlPEPS	- @CursorCantidad								
								WHERE ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto = @CursorIdMovimientoAlmacenConceptoEntrada
						-- Actualiza la salida por el IdMovimientoAlmacen	que cancela.
						UPDATE ProMovimientosAlmacen 
							 SET    IdMovimientoAlmacenQueCancela = @IdMovimientoAlmacenSalida, 
									MotivoCancelacion			   = @MotivoCancelacion, 
									CanceladoPor				   = @CanceladoPor, 
									CanceladoEl					   = @CanceladoEl
							 WHERE IdMovimientoAlmacen =  	@IdMovimientoAlmacen
							 		
						--Registrar detalle de PEPS
						INSERT INTO ProMovimientosAlmacenConceptosPEPS
									(IdMovimientoAlmacenConceptoSalida,
									IdArticulo,
									IdAlmacen,
									Cantidad,
									CostoUnitario,
									IdMovimientoAlmacenConceptoEntrada,
									CostoUnitarioDlls)
						VALUES (@IdMovimientoAlmacenConceptoSalida,
									@CursorIdArticulo,
									@CursorIdAlmacen,
									@CursorCantidad,
									@CursorCostoUnitario,
									@CursorIdMovimientoAlmacenConceptoEntrada,
									@CursorCostoUnitarioDlls)
						---

						FETCH NEXT FROM TempProMovimientosAlmacenConceptosPEPS INTO 
									  @CursorIdMovimientoAlmacenConceptoEntrada, 
									  @CursorIdMovimientoAlmacenConceptoSalida,
									  @CursorIdArticulo,
									  @CursorIdAlmacen,
									  @CursorCantidad,
									  @CursorCostoUnitario,
									  @CursorCostoUnitarioDlls
				END
				CLOSE TempProMovimientosAlmacenConceptosPEPS
				DEALLOCATE TempProMovimientosAlmacenConceptosPEPS
		--------------------------------------------------------------------------------------------------
		FETCH NEXT FROM TempProMovimientosAlmacenConceptosL INTO 
							@ATT_IdArticulo,
							@ATT_Cantidad,
							@ATT_Entregado,
							@ATT_Pendiente,
							@ATT_PrecioUnitario,
							@ATT_PrecioUnitarioDlls,
							@ATT_Importe,
							@ATT_Observaciones,
							@ATT_ImporteDlls,
							@ATT_UnidadMedida,
							@ATT_IdAlmacen,
							@ATT_IdMovimientoAlmacenConcepto  
		END
		  
	CLOSE TempProMovimientosAlmacenConceptosL
	DEALLOCATE TempProMovimientosAlmacenConceptosL
	
		--/////////////
	DECLARE @ATT_IdProMovimientoDetallado int
	DECLARE TempProMovimientosAlmacenHistorico CURSOR local FOR 
    SELECT IdProMovimientoDetallado
	 FROM ProMovimientosAlmacenDetalladoHistorico WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen

	OPEN TempProMovimientosAlmacenHistorico
	 FETCH NEXT FROM TempProMovimientosAlmacenHistorico INTO @ATT_IdProMovimientoDetallado
		 WHILE @@fetch_status = 0
		 BEGIN
			 INSERT INTO ProMovimientosAlmacenDetalladoHistorico(IdProMovimientoDetallado,CreadoEl,CreadoPor,IdMovimientoAlmacen,IdTipoMovimientoAlmacen) 
			 values(@ATT_IdProMovimientoDetallado,@CanceladoEl,@CanceladoPor,@IdMovimientoAlmacenSalida,@IdTipoMovimientoAlmacen)
			 
			 If @EsTraspaso = 0 --Si no es traspaso sigue el flujo normal, si lo es actualiza el idAlmacen en ProMovimientosAlmacenDetallado SOL 171
				 UPDATE ProMovimientosAlmacenDetallado
				 SET Activo = 0
				 WHERE IdProMovimientodetallado = @ATT_IdProMovimientoDetallado
			 ELSE
				 UPDATE ProMovimientosAlmacenDetallado
				 SET Activo = 0,
				 IdAlmacen = (SELECT pmat.IdAlmacenOrigen FROM ProMovimientosAlmacenTraspasos pmat WHERE pmat.IdMovimientoAlmacenSalida = @IdMovimientoAlmacen)
				 WHERE IdProMovimientodetallado = @ATT_IdProMovimientoDetallado
			 
			 
			 FETCH NEXT FROM TempProMovimientosAlmacenHistorico INTO 
							@ATT_IdProMovimientoDetallado
		 END

	 CLOSE TempProMovimientosAlmacenHistorico
	 DEALLOCATE TempProMovimientosAlmacenHistorico

	DELETE FROM ProMovimientosAlmacenDetalladoHistorico WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen
	DELETE FROM ProMovimientosAlmacenDetalladoHistorico WHERE IdMovimientoAlmacen = @IdMovimientoAlmacenSalida

	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

