CREATE PROCEDURE [dbo].[usp_CatSalariosMinimosPorZonasAgregar]
@FechaVigencia datetime,			--(Entrada,Fecha), contiene la fecha de inicio de la vigencia de los Salarios
@SalarioMinimoZonaA decimal(10,2),	--(Entrada,Monedtario), contiene el importe del Salario Minimo de la Zona A
@SalarioMinimoZonaB decimal(10,2),	--(Entrada,Monedtario), contiene el importe del Salario Minimo de la Zona B
@SalarioMinimoZonaC decimal(10,2),	--(Entrada,Monedtario), contiene el importe del Salario Minimo de la Zona C
@CreadoPor int,				--(Entrada,Entero), clave del usuario que agrego la fecha y el importe de los salarios
@CreadoEl datetime,			--(Entrada,Fecha), contiene la fecha de creacion del registro de los salarios
@IdPeticion varchar(100)	--(Entrada,Texto), Id de la peticion de, generada por Webdev
AS
/*********************
Descripcion: El procedimiento permite agregar los valores correspondientes a un ejercicio con los valores de los salarios minimos 
correspondientes por zona
24/02/2020	  Creacion.

Implementado por: Raymundo Espinoza Garcia
Fecha de implementacion: 241/02/2020
Version:  Versión 8.0.50.14

Invocada desde: PAGE_CatSalariosMinimosZonasAM

 *********************/

BEGIN TRY
    BEGIN TRANSACTION
    --Validar si el ejercicio ya está registrado 
	IF EXISTS(Select * FROM CatSalariosMinimosZonas where YEAR(Vigencia) = YEAR(@FechaVigencia))
			RAISERROR(N'No se permite más de un registro dentro del mismo Año/Ejercicio',
				16,
				1
				)	
	IF ISNULL(@SalarioMinimoZonaA,0) = 0 OR @SalarioMinimoZonaA =0
		RAISERROR(N'El Salario Minimo por Zona debe de ser mayor que $0.00',
				16,
				1
				)
	IF ISNULL(@SalarioMinimoZonaB,0) = 0 OR @SalarioMinimoZonaA = 0
		RAISERROR(N'El Salario Minimo por Zona debe de ser mayor que $0.00',
				16,
				1
				)
	IF ISNULL(@SalarioMinimoZonaC,0) = 0 OR @SalarioMinimoZonaA =0
		RAISERROR(N'El Salario Minimo por Zona debe de ser mayor que $0.00',
				16,
				1
				)

    INSERT INTO CatSalariosMinimosZonas(Vigencia,SalarioMinimoZonaA,SalarioMinimoZonaB,SalarioMinimoZonaC,CreadoPor,CreadoEl)
    VALUES(@FechaVigencia,@SalarioMinimoZonaA,@SalarioMinimoZonaB,@SalarioMinimoZonaC,@CreadoPor,@CreadoEl)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

