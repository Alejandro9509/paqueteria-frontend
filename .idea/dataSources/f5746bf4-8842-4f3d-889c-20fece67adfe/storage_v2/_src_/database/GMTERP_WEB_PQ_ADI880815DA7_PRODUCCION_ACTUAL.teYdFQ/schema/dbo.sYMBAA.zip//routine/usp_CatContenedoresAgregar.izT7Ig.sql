CREATE PROCEDURE [dbo].[usp_CatContenedoresAgregar]
@Codigo int,
@Contenedor varchar(50),
@Capacidad decimal(15, 4),
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de contenedor es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT Codigo FROM CatContenedores WHERE Codigo = @Codigo)
		RAISERROR(N'El código del contenedor ya existe',
			16,
			1
			)
			
	IF ISNULL(@Contenedor,'')= ''
		RAISERROR(N'Descripción de contenedor es un campo requerido',
			16,
			1
			)
			
	INSERT INTO CatContenedores(Codigo,Contenedor,Capacidad,CreadoEl,CreadoPor)
	VALUES(@Codigo,@Contenedor,@Capacidad,@CreadoEl,@CreadoPor)

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

