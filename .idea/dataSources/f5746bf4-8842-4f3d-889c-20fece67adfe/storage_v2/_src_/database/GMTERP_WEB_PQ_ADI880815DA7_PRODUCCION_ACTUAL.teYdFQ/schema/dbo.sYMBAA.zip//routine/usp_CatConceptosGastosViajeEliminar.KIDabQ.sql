CREATE PROCEDURE [dbo].[usp_CatConceptosGastosViajeEliminar]
	@IdConceptoGastoViaje int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	--IF EXISTS(SELECT TOP 1 * FROM ProCobranza WHERE IdConceptoCobranza = @IdConceptoCobranza)
	--	RAISERROR(N'El conceptos ya tiene asignado movimientos de cobranza, no es posible eliminarlo',
	--		16,
	--		1
	--		)

	IF (SELECT DefinidoPorSistema FROM CatConceptosGastosViaje WHERE IdConceptoGastoViaje = @IdConceptoGastoViaje) = 1
		RAISERROR(N'El concepto que intenta eleminar es definido por sistema, no es posible eliminarlo',
			16,
			1
			)
	IF EXISTS(Select * from CatRutasTrayectosGastos Where IdConceptoGastoViaje =@IdConceptoGastoViaje)
			RAISERROR(N'El concepto no se puede eliminar porque ya cuenta con asignaciones en gastos autorizados de la ruta/trayecto',
				16,
				1
				)
				
	IF EXISTS(SELECT * FROM ProGastosViaje Where IdConceptoGastoViaje = @IdConceptoGastoViaje)
		RAISERROR('El concepto no se puede modificar porque ya cuenta con asignaciones en gastos de viaje',
			16,
			1
			)
				
	DELETE FROM CatConceptosGastosViaje
	WHERE IdConceptoGastoViaje = @IdConceptoGastoViaje
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

