CREATE PROCEDURE [dbo].[usp_ProNominasReciboModificar]
	@IdNominaRecibo int,
	@IdEmpleado int,
	@IdPeriodo int,
	@Calculado bit,
	@IdDepartamento int,
	@IdPuesto int,
	@IdTipoPeriodo int,
	@IdTurno int,
	@SueldoDiario money,
	@SueldoVariable money,
	@SueldoPromedio money,
	@SueldoIntegrado money,
	@TipoContrato varchar(100),
	@ImporteTotalPercepcionesGravadoISR money,
	@ImporteTotalPercepcionesExentoISR money,
	@ImporteTotalPercepcionesGravadoIMSS money,
	@ImporteTotalPercepcionesExentoIMSS money,
	@ImporteTotalPercepciones money,
	@ImporteTotalDeduccionesGravadoISR money,
	@ImporteTotalDeduccionesExentoISR money,
	@ImporteTotalDeduccionesGravadoIMSS money,
	@ImporteTotalDeduccionesExentoIMSS money,
	@ImporteTotalDeducciones money,
	@ImporteTotalObligacionesGravadoISR money,
	@ImporteTotalObligacionesExentoISR money,
	@ImporteTotalObligacionesGravadoIMSS money,
	@ImporteTotalObligacionesExentoIMSS money,
	@ImporteTotalObligaciones money,
	@Subtotal money,
	@Descuentos money,
	@Retenciones money,
	@NetoPagar money,
	@dsProNominasReciboConceptos ntext,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@dsProNominasRecibosTiposAcumulados ntext,
	@ClaveTipoContrato varchar(5),
	@TipoRecibo tinyint,
	@FechaBajaFiniquito date,
	@AplicarValidacionNetoPagar bit,
	@dsProNominasRecibosConceptosHorasExtras ntext


/* *************************************************************************************************
Procedimiento usp_ProNominasReciboModificar

 

Descripción: El procedimiento actualiza los conceptos PDO dele recibo del empleado.

Implementada por: N/A
Fecha de implementacion: N/A
Versión ERP: x.x.xx.xx

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 07/04/2020
Versión ERP: Versión 8.0.51.34

Invocada desde: PAGE_PAGE_ProNominaRecibo (Solicitud 1071)
***************************************************************************************************** */
AS
DECLARE
	@docHandle int,
	@CursorIdNominaReciboConcepto int,
	@CursorIdNominaRecibo int,
	@CursorIdConceptoPDO int,
	@CursorTipoConcepto int, 
	@CursorValor money,
	@CursorImporteTotal money,
	@CursorImporteGravadoISR money,
	@CursorImporteExentoISR money,
	@CursorImporteGravadoIMSS money,
	@CursorImporteExentoIMSS money,
	@CursorIdNominaReciboTiposAcumulados int,
	@CursorIdTipoAcumulado int,
	@CursorAcumuladoEjercicioAnterior money,
	@CursorImporteInicialEjercicio money,
	@CursorMes int,
	@CursorImporte money,
	@CursorSeModifico tinyint,
	@CursorEspecie bit, 
	@CursorIdConceptoPDOFijo int,
	@Error decimal (15,4),
	@CursorIdNominaReciboConceptoHoraExtra int,
	@CursorDias int,
	@CursorTipoHoras varchar(5),
	@CursorHorasExtra int,
	@CursorImportePagado money ,
	@IdConceptoPDOHE int,
	@CursorModificadoPorUsuario tinyint
BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
		--IF (SELECT ModificadoEl FROM ProNominasRecibo WHERE IdNominaRecibo = @IdNominaRecibo) <> @UltimaModificacion
		IF (SELECT ModificadoEl FROM ProNominasRecibo WHERE IdNominaRecibo = @IdNominaRecibo AND ModificadoPor <> @ModificadoPor) <> @UltimaModificacion
		RAISERROR(N'Los datos de este recibo fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise',
			16,
			1
			)
		IF @IdNominaRecibo = 0
			RAISERROR(N'El IdNominaRecibo es un campo requerido',
				16,
				1
				)
		IF @IdEmpleado = 0
			RAISERROR(N'El empleado es un campo requerido',
				16,
				1
				)
		IF @SueldoDiario = 0
			RAISERROR(N'El sueldo diario del empleado es un campo requerido',
				16,
				1
				)	
		IF @IdPeriodo = 0
			RAISERROR(N'El periodo es un campo requerido',
				16,
				1
				)
		IF @IdDepartamento = 0
			RAISERROR(N'El departamento es un campo requerido',
				16,
				1
				)
		IF @IdPuesto = 0
			RAISERROR(N'El puesto es un campo requerido',
				16,
				1
				)
		IF @IdTipoPeriodo = 0
			RAISERROR(N'El tipo de periodo es un campo requerido',
				16,
				1
				)		
		IF @IdTurno = 0
			RAISERROR(N'El turno es un campo requerido',
				16,
				1
				)				
		IF @NetoPagar < 0 AND @AplicarValidacionNetoPagar=1
			RAISERROR(N'El neto a pagar se está expresando en negativo, no será posible emitir el timbre, favor de validar la información',
				16,
				1
				)
				
		--validar si el empleado tiene recibos generados en el mismo perido		
		IF EXISTS(SELECT * FROM ProNominasRecibo WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo AND IdNominaRecibo <> @IdNominaRecibo)
			RAISERROR(N'El empleado tiene recibos generados en este período',
				16,
				1
				)
	--UPDATE A LA TABLA ProNominasRecibo CON LA INFORMACION PROPORCIONADA		
	UPDATE ProNominasRecibo SET
	IdEmpleado = @IdEmpleado,
	IdPeriodo = @IdPeriodo,
	Calculado = @Calculado,
	SueldoDiario = @SueldoDiario,
	ImporteTotalPercepcionesGravadoISR = @ImporteTotalPercepcionesGravadoISR,
	ImporteTotalPercepcionesExentoISR = @ImporteTotalPercepcionesExentoISR,
	ImporteTotalPercepcionesGravadoIMSS = @ImporteTotalPercepcionesGravadoIMSS,
	ImporteTotalPercepcionesExentoIMSS = @ImporteTotalPercepcionesExentoIMSS,
	ImporteTotalPercepciones = @ImporteTotalPercepciones,
	ImporteTotalDeduccionesGravadoISR = @ImporteTotalDeduccionesGravadoISR,
	ImporteTotalDeduccionesExentoISR = @ImporteTotalDeduccionesExentoISR,
	ImporteTotalDeduccionesGravadoIMSS = @ImporteTotalDeduccionesGravadoIMSS,
	ImporteTotalDeduccionesExentoIMSS = @ImporteTotalDeduccionesExentoIMSS,
	ImporteTotalDeducciones = @ImporteTotalDeducciones,
	ImporteTotalObligacionesGravadoISR = @ImporteTotalObligacionesGravadoISR,
	ImporteTotalObligacionesExentoISR = @ImporteTotalObligacionesExentoISR,
	ImporteTotalObligacionesGravadoIMSS = @ImporteTotalObligacionesGravadoIMSS,
	ImporteTotalObligacionesExentoIMSS = @ImporteTotalObligacionesExentoIMSS,
	ImporteTotalObligaciones = @ImporteTotalObligaciones,
	Subtotal = @Subtotal,
	Descuentos = @Descuentos,
	Retenciones = @Retenciones,
	NetoPagar = @NetoPagar,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	ClaveTipoContrato = @ClaveTipoContrato,
	TipoContrato = TipoContrato,
	TipoRecibo = @TipoRecibo,
	FechaBajaFiniquito = @FechaBajaFiniquito
	WHERE IdNominaRecibo = @IdNominaRecibo

	--Sección para agregar los conceptosPDO
	IF @dsProNominasReciboConceptos IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNominasReciboConceptos

		SELECT ATT_IdNominaReciboConcepto,ATT_IdConceptoPDO,ATT_TipoConcepto,ATT_Valor,ATT_ImporteTotal,ATT_ImporteGravadoISR,ATT_ImporteExentoISR,ATT_ImporteGravadoIMSS,ATT_ImporteExentoIMSS,ATT_SeModifico,ATT_Especie,ATT_IdConceptoPDOFijo,ATT_ModificadoUsuario
		INTO #TempProNominasReciboConceptos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNominasRecibosConceptos',2) 
		WITH (ATT_IdNominaReciboConcepto int,ATT_IdConceptoPDO int,ATT_TipoConcepto int,ATT_Valor money,ATT_ImporteTotal money,ATT_ImporteGravadoISR money,ATT_ImporteExentoISR money,ATT_ImporteGravadoIMSS money,ATT_ImporteExentoIMSS money,ATT_SeModifico tinyint,ATT_Especie bit,ATT_IdConceptoPDOFijo int,ATT_ModificadoUsuario tinyint)

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorProNominasReciboConceptos CURSOR FOR
		SELECT * FROM #TempProNominasReciboConceptos
		
		OPEN CursorProNominasReciboConceptos
		FETCH NEXT FROM CursorProNominasReciboConceptos
		INTO @CursorIdNominaReciboConcepto,@CursorIdConceptoPDO,@CursorTipoConcepto,@CursorValor,@CursorImporteTotal,@CursorImporteGravadoISR,@CursorImporteExentoISR,@CursorImporteGravadoIMSS,@CursorImporteExentoIMSS,@CursorSeModifico,@CursorEspecie,@CursorIdConceptoPDOFijo,@CursorModificadoPorUsuario
		
		WHILE @@FETCH_STATUS = 0
			BEGIN
				--Hay que verificar si el idconcepoPDO y idconceptopdofijo vienen 0 hay que ponerlo NULL
					IF @CursorIdConceptoPDO = 0  
					BEGIN
					SET @CursorIdConceptoPDO = NULL 
					END
					
					IF @CursorIdConceptoPDOFijo = 0
					BEGIN
					SET @CursorIdConceptoPDOFijo = NULL 
					END
				IF @CursorIdNominaReciboConcepto = 0
				BEGIN
					INSERT INTO ProNominasReciboConceptos(IdNominaRecibo,IdConceptoPDO,TipoConcepto,Valor,ImporteTotal,ImporteGravadoISR,ImporteExentoISR,ImporteGravadoIMSS,ImporteExentoIMSS,CreadoPor,CreadoEl,SeModifico,Especie,IdConceptoPDOFijo,ModificadoUsuario)
					VALUES(@IdNominaRecibo,@CursorIdConceptoPDO,@CursorTipoConcepto,@CursorValor,@CursorImporteTotal,@CursorImporteGravadoISR,@CursorImporteExentoISR,@CursorImporteGravadoIMSS,@CursorImporteExentoIMSS,@ModificadoPor,@ModificadoEl,@CursorSeModifico,@CursorEspecie,@CursorIdConceptoPDOFijo,@CursorModificadoPorUsuario)
				END
				ELSE
				BEGIN
					IF @CursorSeModifico = 2
					BEGIN 
					 DELETE FROM ProNominasReciboConceptos WHERE IdNominaReciboConcepto = @CursorIdNominaReciboConcepto 
					END 
					ELSE
					BEGIN
						UPDATE ProNominasReciboConceptos SET
						IdNominaRecibo = @IdNominaRecibo,
						IdConceptoPDO = @CursorIdConceptoPDO,
						TipoConcepto = @CursorTipoConcepto,
						Valor = @CursorValor,
						ImporteTotal = @CursorImporteTotal,
						ImporteGravadoISR = @CursorImporteGravadoISR,
						ImporteExentoISR = @CursorImporteExentoISR,
						ImporteGravadoIMSS = @CursorImporteGravadoIMSS,
						ImporteExentoIMSS = @CursorImporteExentoIMSS,
						ModificadoPor = @ModificadoPor,
						ModificadoEl = @ModificadoEl,
						SeModifico = @CursorSeModifico,
						Especie = @CursorEspecie,
						IdConceptoPDOFijo = @CursorIdConceptoPDOFijo,
						ModificadoUsuario = @CursorModificadoPorUsuario
						WHERE  IdNominaReciboConcepto = @CursorIdNominaReciboConcepto
					END
				END
				FETCH NEXT FROM CursorProNominasReciboConceptos
				INTO @CursorIdNominaReciboConcepto,@CursorIdConceptoPDO,@CursorTipoConcepto,@CursorValor,@CursorImporteTotal,@CursorImporteGravadoISR,@CursorImporteExentoISR,@CursorImporteGravadoIMSS,@CursorImporteExentoIMSS,@CursorSeModifico,@CursorEspecie,@CursorIdConceptoPDOFijo,@CursorModificadoPorUsuario
			END
			CLOSE CursorProNominasReciboConceptos
			DEALLOCATE CursorProNominasReciboConceptos	
	END
	DELETE FROM ProNominasReciboConceptos WHERE IdNominaRecibo = @IdNominaRecibo AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	--SECCION PARA AGREGAR LAS HORAS EXTRAS 
	IF @dsProNominasReciboConceptos IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNominasRecibosConceptosHorasExtras

		SELECT ATT_IdNominaReciboConceptoHoraExtra,ATT_IdNominaReciboConcepto,ATT_Dias,ATT_TipoHoras,ATT_HorasExtra,ATT_ImportePagado 
		INTO #TempProNominasRecibosConceptosHorasExtras
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNominasReciboConceptosHorasExtras',2) 
		WITH (ATT_IdNominaReciboConceptoHoraExtra int,ATT_IdNominaReciboConcepto int,ATT_Dias int,ATT_TipoHoras varchar(5),ATT_HorasExtra int,ATT_ImportePagado money)

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorProNominasRecibosConceptosHorasExtras CURSOR FOR
		SELECT * FROM #TempProNominasRecibosConceptosHorasExtras
		
		OPEN CursorProNominasRecibosConceptosHorasExtras
		FETCH NEXT FROM CursorProNominasRecibosConceptosHorasExtras
		INTO @CursorIdNominaReciboConceptoHoraExtra,@CursorIdNominaReciboConcepto, @CursorDias,@CursorTipoHoras,@CursorHorasExtra,@CursorImportePagado
		
		WHILE @@FETCH_STATUS = 0
			BEGIN
				--HAY QUE VERIFICAR SI EL IdNominaReciboConcepto VIENE 0 HAY PONERLO NULL
				IF @CursorIdNominaReciboConcepto = 0
				BEGIN
					SET @IdConceptoPDOHE = (SELECT IdConceptoPDO FROM CatConceptosPDO WHERE NumeroConcepto = 4) 
					SET @CursorIdNominaReciboConcepto = (SELECT IdNominaReciboConcepto FROM ProNominasReciboConceptos WHERE IdConceptoPDO = @IdConceptoPDOHE AND IdNominaRecibo = @IdNominaRecibo) 
					
				END 
				IF @CursorIdNominaReciboConceptoHoraExtra = 0
				BEGIN

					INSERT INTO ProNominasReciboConceptosHorasExtras(IdNominaReciboConcepto,Dias,TipoHoras,HorasExtra,ImportePagado,CreadoPor,CreadoEl)
					VALUES(@CursorIdNominaReciboConcepto, @CursorDias,@CursorTipoHoras,@CursorHorasExtra,@CursorImportePagado,@ModificadoPor,@ModificadoEl)
				END
				ELSE
				BEGIN
					UPDATE ProNominasReciboConceptosHorasExtras SET
					IdNominaReciboConcepto = @CursorIdNominaReciboConcepto,
					Dias = @CursorDias,
					TipoHoras = @CursorTipoHoras,
					HorasExtra = @CursorHorasExtra,
					ImportePagado = @CursorImportePagado,
					ModificadoPor = @ModificadoPor,
					ModificadoEl = @ModificadoEl
					WHERE  IdNominaReciboConceptoHoraExtra = @CursorIdNominaReciboConceptoHoraExtra
				END
				FETCH NEXT FROM CursorProNominasRecibosConceptosHorasExtras
				INTO  @CursorIdNominaReciboConceptoHoraExtra,@CursorIdNominaReciboConcepto, @CursorDias,@CursorTipoHoras,@CursorHorasExtra,@CursorImportePagado
			END
			CLOSE CursorProNominasRecibosConceptosHorasExtras
			DEALLOCATE CursorProNominasRecibosConceptosHorasExtras	

	END
	DELETE FROM ProNominasReciboConceptosHorasExtras WHERE IdNominaReciboConcepto = @CursorIdNominaReciboConcepto AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	

	--Sección para agregar los Tipos Acumulados
	IF @dsProNominasRecibosTiposAcumulados IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProNominasRecibosTiposAcumulados

		SELECT ATT_IdNominaReciboTiposAcumulados,ATT_IdTipoAcumulado,ATT_AcumuladoEjercicioAnterior,ATT_ImporteInicialEjercicio,ATT_Mes,ATT_Importe
		INTO #TempProNominasRecibosTiposAcumulados
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProNominasRecibosTiposAcumulados',2) 
		WITH (ATT_IdNominaReciboTiposAcumulados int,ATT_IdTipoAcumulado int,ATT_AcumuladoEjercicioAnterior money,ATT_ImporteInicialEjercicio money,ATT_Mes int,ATT_Importe money)

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorProNominasRecibosTiposAcumulados CURSOR FOR
		SELECT * FROM #TempProNominasRecibosTiposAcumulados
		
		OPEN CursorProNominasRecibosTiposAcumulados
		FETCH NEXT FROM CursorProNominasRecibosTiposAcumulados
		INTO @CursorIdNominaReciboTiposAcumulados,@CursorIdTipoAcumulado,@CursorAcumuladoEjercicioAnterior,@CursorImporteInicialEjercicio,@CursorMes,@CursorImporte
		
		WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @CursorIdNominaReciboTiposAcumulados = 0
				BEGIN
					INSERT INTO ProNominasRecibosTiposAcumulados(IdNominaRecibo,IdTipoAcumulado,AcumuladoEjercicioAnterior,ImporteInicialEjercicio,Mes,Importe,CreadoPor,CreadoEl)
					VALUES(@IdNominaRecibo,@CursorIdTipoAcumulado,@CursorAcumuladoEjercicioAnterior,@CursorImporteInicialEjercicio,@CursorMes,@CursorImporte,@ModificadoPor,@ModificadoEl)
				END
				ELSE
				BEGIN
					UPDATE ProNominasRecibosTiposAcumulados SET
					IdNominaRecibo = @IdNominaRecibo,
					IdTipoAcumulado = @CursorIdTipoAcumulado,
					AcumuladoEjercicioAnterior = @CursorAcumuladoEjercicioAnterior,
					ImporteInicialEjercicio = @CursorImporteInicialEjercicio,
					Mes = @CursorMes,
					Importe = @CursorImporte,
					ModificadoPor = @ModificadoPor,
					ModificadoEl = @ModificadoEl
					WHERE  IdNominaReciboTiposAcumulados  = @CursorIdNominaReciboTiposAcumulados 
				END
				FETCH NEXT FROM CursorProNominasRecibosTiposAcumulados
				INTO @CursorIdNominaReciboTiposAcumulados,@CursorIdTipoAcumulado,@CursorAcumuladoEjercicioAnterior,@CursorImporteInicialEjercicio,@CursorMes,@CursorImporte
			END
			CLOSE CursorProNominasRecibosTiposAcumulados
			DEALLOCATE CursorProNominasRecibosTiposAcumulados
	END
	DELETE FROM ProNominasRecibosTiposAcumulados WHERE IdNominaRecibo = @IdNominaRecibo AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	

	--Percepcion
	IF (SELECT CAST(ISNULL(SUM(pnrc.ImporteTotal),0) AS DECIMAL (15,2)) 
FROM ProNominasReciboConceptos As pnrc Inner join CatConceptosPDO As ccpdo ON pnrc.IdConceptoPDO = ccpdo.IdConceptoPDO
WHERE pnrc.IdNominaRecibo = @IdNominaRecibo 
AND pnrc.TipoConcepto = 1 
AND pnrc.Especie = 0
AND ccpdo.IdConceptoPDO<>'39') <> CAST(@ImporteTotalPercepciones AS DECIMAL (15,2)) 
		RAISERROR(N'La suma de los importes de los conceptos de percepción no son iguales al total de percepción',
			16,
			1
			)

	--Deduccion
	IF (SELECT ISNULL(SUM(ImporteTotal),0) FROM ProNominasReciboConceptos WHERE IdNominaRecibo = @IdNominaRecibo AND TipoConcepto = 2 AND Especie = 0) <> @ImporteTotalDeducciones
		RAISERROR(N'La suma de los importes de los conceptos de deducción no son iguales al total de deducción',
			16,
			1
			)
	--Obligacion		
	IF (SELECT ISNULL(SUM(ImporteTotal),0) FROM ProNominasReciboConceptos WHERE IdNominaRecibo = @IdNominaRecibo AND TipoConcepto = 3 AND Especie = 0) <> @ImporteTotalObligaciones
		RAISERROR(N'La suma de los importes de los conceptos de obligación no son iguales al total de obligación',
			16,
			1
			)
	COMMIT
END TRY
BEGIN CATCH	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

