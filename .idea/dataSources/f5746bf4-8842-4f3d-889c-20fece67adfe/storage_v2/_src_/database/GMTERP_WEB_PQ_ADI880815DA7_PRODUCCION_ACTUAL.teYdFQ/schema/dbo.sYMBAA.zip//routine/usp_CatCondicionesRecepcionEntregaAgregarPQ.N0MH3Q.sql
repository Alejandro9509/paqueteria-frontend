CREATE PROCEDURE [dbo].[usp_CatCondicionesRecepcionEntregaAgregarPQ](
	@ID int,
	@Descripcion varchar(50),
	@Activo bit
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La Descripción es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@ID, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		

		INSERT INTO CatCondicionesRecepcionEntregas(ID,Descripcion,Activo) values (@ID,@Descripcion,@Activo)


		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

