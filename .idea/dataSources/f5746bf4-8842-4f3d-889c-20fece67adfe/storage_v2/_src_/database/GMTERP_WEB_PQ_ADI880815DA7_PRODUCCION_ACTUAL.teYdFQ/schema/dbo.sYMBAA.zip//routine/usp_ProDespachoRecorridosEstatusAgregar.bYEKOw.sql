
CREATE PROCEDURE [dbo].[usp_ProDespachoRecorridosEstatusAgregar]
	@IdRecorridoDespacho int,
	@IdEstatusViaje int,
	@FechaHora datetime,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@GeneradoAutomaticamente bit
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdRecorridoDespacho,0) = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdEstatusViaje,0) = 0
		RAISERROR(N'El estatus es un campo requerido',
			16,
			1
			)

	IF @FechaHora = ''
		RAISERROR(N'La fecha/hora es un campo requerido',
			16,
			1
			)	
			
	INSERT INTO ProRecorridosDespachoEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatusViaje,IdRecorridoDespacho,GeneradoAutomaticamente)
	VALUES(@CreadoEl,@CreadoPor,@FechaHora,@IdEstatusViaje,@IdRecorridoDespacho,@GeneradoAutomaticamente)
	
	UPDATE ProRecorridosDespacho SET
		IdEstatuViaje = @IdEstatusViaje,
		FechaHoraRecorridoEstatus = @FechaHora,
		ModificadoPor = @CreadoPor,
		ModificadoEl = @CreadoEl
	WHERE IdRecorridoDespacho = @IdRecorridoDespacho	

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

