

CREATE PROCEDURE [dbo].[usp_ProChatEnLineaEnviarMensajePQ](
	@IdEnviadoPor int,
	@IdOperador int,
	@IdUsuario int,
	@Mensaje varchar(500))
AS
BEGIN 
	IF @IdEnviadoPor = 0 BEGIN
		RAISERROR(N'*INICIO*El identificador de quien lo envía es un campo requerido*FIN*',16,1);
		return;
	END;
	IF @IdOperador = 0 BEGIN
		RAISERROR(N'*INICIO*El identificador del operador es un campo requerido*FIN*',16,1);
		return;
	END;
	IF ISNULL(@Mensaje, '') = '' BEGIN
		RAISERROR(N'El mensaje es un campo requerido', 16, 1);
		return;
	END

	INSERT INTO ProChatEnLineaMensajePQ(IdEnviadoPor, IdOperador, IdUsuario, Mensaje)
	VALUES(@IdEnviadoPor, @IdOperador, @IdUsuario, @Mensaje)

END
go

