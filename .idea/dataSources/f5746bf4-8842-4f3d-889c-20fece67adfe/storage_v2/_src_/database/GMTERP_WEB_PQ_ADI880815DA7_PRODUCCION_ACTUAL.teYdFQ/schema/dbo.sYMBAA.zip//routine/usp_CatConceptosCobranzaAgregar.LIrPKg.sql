
CREATE PROCEDURE [dbo].[usp_CatConceptosCobranzaAgregar]
	@Codigo int,
	@ConceptoCobranza varchar(50),
	@TipoConcepto tinyint,
	@Activo bit,
	@RequiereCtaBancaria bit,		
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF @Codigo <= 0
		RAISERROR(N'El Codigo es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT IdConceptoCobranza FROM CatConceptosCobranza WHERE Codigo = @Codigo)		
		RAISERROR(N'El código del concepto de cobranza no se puede repetir',
			16,
			1
			)
	IF LTRIM(RTRIM(@ConceptoCobranza)) = ''
		RAISERROR(N'El Concepto de cobranza es un campo requerido',
			16,
			1
			)

			
	INSERT INTO CatConceptosCobranza(Codigo,ConceptoCobranza,TipoConcepto,Activo,RequiereCtaBancaria,DefinidoPorSistema,CreadoPor,CreadoEl)
	VALUES(@Codigo,@ConceptoCobranza,@TipoConcepto,@Activo,@RequiereCtaBancaria,0,@CreadoPor,@CreadoEl)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

