CREATE PROCEDURE [dbo].[usp_ProContraRecibosClienteAgregar]
@Folio int,
@IdCliente int,
@FechaHora datetime,
@ReferenciaCliente varchar(15),
@FechaProgramadoPago datetime,
@TotalPesos money,
@TotalDolares money,
@TotalAbonoPesos money,
@TotalAbonoDolares money,
@TotalSaldoPesos money,
@TotalSaldoDolares money,
@Estatus tinyint,
@dsProContraRecibosClienteFacturas ntext,
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100)	
AS
DECLARE @IdContraReciboCliente int,
		@docHandle int,
		@ATT_IdFactura int,
		@ATT_Importe money,
		@DoctoFactura varchar(50),
		@MensajeError varchar(250),
		@EstatusPendPago int,
		@EstatusPagada int,
		@EstatusCancelada int,
		@ImporteAdeudo money, 
		@EstatusActualFactura int,
		@FolioContraRecibo int 
BEGIN TRY
	BEGIN TRANSACTION
	
		SET @EstatusPendPago = 0
		SET @EstatusPagada = 1
		SET @EstatusCancelada = 2
		
	IF ISNULL(@Folio,0)= 0
		RAISERROR(N'El folio de contra recibo es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Folio FROM ProContraRecibosCliente WHERE Folio= @Folio)
		RAISERROR(N'El folio del contra recibo ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar',
			16,
			1
			)			
						
	IF ISNULL(@IdCliente,0)= 0
		RAISERROR(N'Identificador de cliente es un campo requerido',
			16,
			1
			)
						
	IF ISDATE(@FechaHora)= 0
		RAISERROR(N'Fecha de contra recibo es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaProgramadoPago)= 0
		RAISERROR(N'Fecha programado de pago es un campo requerido',
			16,
			1
			)

	INSERT INTO ProContraRecibosCliente(Folio,IdCliente,FechaHora,ReferenciaCliente,FechaProgramadoPago,TotalPesos,TotalDolares,TotalAbonoPesos,TotalAbonoDolares,TotalSaldoPesos,TotalSaldoDolares,Estatus,CreadoPor,CreadoEl)
	VALUES(@Folio,@IdCliente,@FechaHora,@ReferenciaCliente,@FechaProgramadoPago,@TotalPesos,@TotalDolares,@TotalAbonoPesos,@TotalAbonoDolares,@TotalSaldoPesos,@TotalSaldoDolares,@Estatus,@CreadoPor,@CreadoEl)
	
	SET @IdContraReciboCliente= (SELECT IDENT_CURRENT('ProContraRecibosCliente'))
	
--   REGISTRAR EN EL PUENTE CONTRARECIBOS CLIENTE  / FACTURAS. 

	
	IF @dsProContraRecibosClienteFacturas IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProContraRecibosClienteFacturas 

		SELECT ATT_IdFactura,ATT_Importe
		INTO #TempProContraRecibosClienteFacturas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturas',2) 
		WITH (ATT_IdFactura int,ATT_Importe money)

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE ProContraRecibosClienteFacturasCursor CURSOR FOR
		SELECT ATT_IdFactura,ATT_Importe FROM #TempProContraRecibosClienteFacturas 

		OPEN ProContraRecibosClienteFacturasCursor
		FETCH NEXT FROM ProContraRecibosClienteFacturasCursor INTO @ATT_IdFactura,@ATT_Importe
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
		
		-- Validar concurrencia de facturas al registrar detalle.
		
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @ATT_IdFactura)

		SELECT @EstatusActualFactura  = ISNULL(Estatus,0), @ImporteAdeudo = (Total-Isnull(Abonos,0))  FROM ProFacturas WHERE IdFactura = @ATT_IdFactura

		--Valida si esta cancelada
		IF @EstatusActualFactura = @EstatusCancelada -- cancelado = 2
			BEGIN
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya fue cancelada por otro usuario' 
					 RAISERROR(@MensajeError,
							16,
							1
							)
			END										

		--Valida si esta pagada
		IF @EstatusActualFactura = @EstatusPagada -- Pagada = 1
			BEGIN
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya fue pagada por otro usuario' 
					 RAISERROR(@MensajeError,
							16,
							1
							)
			END
			
		--Valida si esta pendiente de pago y el importe adeudado no sea diferente.
		IF @EstatusActualFactura = @EstatusPendPago AND @ImporteAdeudo <>  @ATT_Importe -- Pendiente de pago = 0
			BEGIN
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya tiene importe abonado por otro usuario' 
					 RAISERROR(@MensajeError,
							16,
							1
							)
			END
			
		-- Valida que la factura no este en un contra recibo
		IF EXISTS(SELECT ProContraRecibosCliente.Folio
							FROM  ProContraRecibosClienteFacturas INNER JOIN
								 ProContraRecibosCliente 
								 ON ProContraRecibosClienteFacturas.IdContraReciboCliente = ProContraRecibosCliente.IdContraReciboCliente	
							WHERE ProContraRecibosCliente.CanceladoEl IS NULL AND  ProContraRecibosClienteFacturas.IdFactura = @ATT_IdFactura)
			BEGIN
				SET @FolioContraRecibo = (SELECT TOP 1 ProContraRecibosCliente.Folio
										FROM  ProContraRecibosClienteFacturas INNER JOIN
											 ProContraRecibosCliente 
											 ON ProContraRecibosClienteFacturas.IdContraReciboCliente = ProContraRecibosCliente.IdContraReciboCliente	
										WHERE ProContraRecibosCliente.CanceladoEl IS NULL AND  ProContraRecibosClienteFacturas.IdFactura =  @ATT_IdFactura)
						 
				 SET @MensajeError = 'La factura '+@DoctoFactura+' no se puede agregar porque ya esta relacionado al contra recibo folio '+cast(@FolioContraRecibo as varchar(6))
				  
				 RAISERROR(@MensajeError,
							16,
							1
							)
			END
	
		-- Registrar facturas en el detalle del contra recibo
		    INSERT INTO ProContraRecibosClienteFacturas (IdContraReciboCliente,IdFactura,Importe) values (@IdContraReciboCliente,@ATT_IdFactura,@ATT_Importe)
		 
			FETCH NEXT FROM ProContraRecibosClienteFacturasCursor
			INTO @ATT_IdFactura,@ATT_Importe
		END   
		
		CLOSE ProContraRecibosClienteFacturasCursor
		DEALLOCATE ProContraRecibosClienteFacturasCursor
		IF NOT EXISTS (SELECT  IdContraReciboCliente FROM ProContraRecibosClienteFacturas WHERE IdContraReciboCliente =@IdContraReciboCliente)
				RAISERROR(N'Marque al menos una factura',
						16,
						1
						)
		
		
		
	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

