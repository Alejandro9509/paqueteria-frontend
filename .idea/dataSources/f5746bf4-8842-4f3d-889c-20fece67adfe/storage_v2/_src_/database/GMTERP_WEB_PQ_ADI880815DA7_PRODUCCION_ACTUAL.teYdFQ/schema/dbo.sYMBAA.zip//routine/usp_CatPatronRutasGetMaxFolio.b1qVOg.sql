
CREATE PROCEDURE [dbo].[usp_CatPatronRutasGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM CatPatronRutas
go

