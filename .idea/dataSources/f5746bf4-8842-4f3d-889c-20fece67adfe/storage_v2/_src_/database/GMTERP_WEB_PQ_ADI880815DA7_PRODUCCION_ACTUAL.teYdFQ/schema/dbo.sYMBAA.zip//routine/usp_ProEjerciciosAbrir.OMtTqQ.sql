
	CREATE PROCEDURE [dbo].[usp_ProEjerciciosAbrir]
	@IdPeticion varchar(100),
	@Ejercicio int
	AS
	DECLARE
	@EjercicioMayor varchar(5),
	@Mensaje varchar(100)

	BEGIN TRY
		BEGIN TRANSACTION
		
		--Ejercicio Compara
		SET @EjercicioMayor =(Select TOP 1 CONVERT(varchar(5), Ejercicio) FROM ProEjerciciosPeriodos Where Ejercicio > @Ejercicio AND PeriodoCerrado13 = 1 ORDER BY Ejercicio DESC)
		SET @Mensaje = 'Para poder abrir el ejercicio es necesario primero abrir el:'+@EjercicioMayor
		
		IF EXISTS(Select Ejercicio FROM ProEjerciciosPeriodos Where Ejercicio > @Ejercicio AND PeriodoCerrado13 = 1)
		BEGIN
			RAISERROR(@Mensaje,
							16,
							1
							)   
		END
		
		
		
		IF NOT EXISTS(Select IdPoliza from ProPolizas Where Periodo = 13 AND Ejercicio = @Ejercicio)
			RAISERROR(N'No se encontro póliza de cierre para el ejercicio',
				16,
				1
				)
				

		IF EXISTS(Select Ejercicio FROM ProEjerciciosPeriodos Where PeriodoCerrado13 Is NULL  AND Ejercicio = @Ejercicio)
			RAISERROR(N'El ejercicio ya fue abierto por otra estación',
				16,
				1
				)	
		
		Delete ProPolizas Where Periodo = 13 AND Ejercicio = @Ejercicio
		
		Update ProEjerciciosPeriodos SET PeriodoCerrado13 = NULL, 
		PeriodoCerradoEl13 = NULL,
		PeriodoCerradoPor13 = NULL
		Where PeriodoCerrado13 = 1  AND Ejercicio = @Ejercicio   

		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

