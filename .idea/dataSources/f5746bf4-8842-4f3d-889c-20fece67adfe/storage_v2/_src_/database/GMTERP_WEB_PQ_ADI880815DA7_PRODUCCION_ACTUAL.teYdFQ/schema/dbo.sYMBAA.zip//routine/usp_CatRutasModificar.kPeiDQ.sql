CREATE PROCEDURE [dbo].[usp_CatRutasModificar]
	@IdRuta int,	
	@FolioRuta int,
	@IdCliente int,
	@IdOrigen int,
	@IdDestino int,
	@DescripcionRuta varchar(140),
	@Activa bit,
	@IdTipoUnidad int,
	@Kilometros int,
	@Horas decimal(15,2),
	@IdSucursal int,
	@Item varchar(50),
	@Planta varchar(50),
	@Convenio varchar(50),
	@IdRemitente int,
	@IdDestinatario int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@dsCatRutasConceptosFacturacion ntext,	
	@dsCatRutasDescripcionesCargaTarifas ntext,
	@dsCatRutasTrayectos ntext,		
	@IdPeticion varchar(100),
	@ViajeFacturable bit,
	@dsCatRutasClienteContactos ntext,
	@ImporteBase money,
	@IdTipoViaje int,
	@IdClasificacionViaje int,
	@Millas decimal(15,2),
	@ETA decimal(15,2),
	@PTVContratado bit = 0,--para identificar si el cliente contrato el modulo de ptv
	@dsCatRutasTarifasMaterialesPemex ntext,
	@dsCatRutasTrayectosDistribucionConceptosFacturacion XML = NULL,
	@ViajeInternacional bit = NULL,
	@ImportacionExportacion tinyint = NULL,
	@ViajeRepartoRecolecta bit = NULL,
	@FechaAlta datetime = NULL,
	@FechaVigencia datetime = NULL

/* *************************************************************************************************
Procedimiento usp_CatRutasModificar
 
Descripción: Procedimiento para modificar una ruta/tarifa

14/02/2020 - Se agrego parametro dsCatRutasTarifasMaterialesPemex para el xml del nuevo catalogo de Materiales Pemex
26/03/2020 - se agregó seccion para insertar los porcentajes de impuestos de cada concepto de facturacion de la ruta, ademas
			de los campos de @IdImpuestoTrasladado,@IdImpuestoRetenido,@IdRutaConceptoFacturacion para obtener dichos datos 
			del xml de  @dsCatRutasConceptosFacturacion, y evitar que se inserte ceros
08/04/2020 - se agregó traslada y retiene impuesto en la isnercion de conceptos de facturacion de la ruta
22/02/2021 - Se modifico el tipo de dato money a float en las tarifas pesos y dolares de los materiales

Implementada por: XXXXXX
Fecha de implementacion: XXXXXX
Versión ERP: XXXXXX

Modificada por: Edgar Ramos
Fecha de modificación: 14/05/2021
Versión: 8.0.61.13
Solicitud: 4208
Descripción: Se agrego la distribucion de ingresos en los trayectos.

Modificada por: Edgar Ramos
Fecha de modificación: 08/06/2021
Versión: 8.0.62.05
Solicitud: 4333
Descripción: Se agregaron campos ViajeInternacional , ExportacionImportacion y claves del sat a los materiales,se cerraron cursores

Modificada por: Edgar Ramos
Fecha de modificación: 18/06/2021
Versión:  8.0.62.14
Solicitud: 4450
Descripción: Se agrego el parametro ViajeRepartoRecolecta y una seccion para guardar las ubicaciones del remitente y destinatario para la carta porte

Invocada desde: PAGE_CatRutasAM (Solicitud 902)


Modificada por:Yarazeth Lemus
Fecha de modificación: 18/08/2021
Versión: 8.0.63.02
Solicitud: 4667
Descripción: se cambio el varchar de la clave de sat a 10

Modificada por: Ignacio Perez
Fecha de modificación: 26/08/2021
Versión: 8.0.64.13
Solicitud: 4683
Descripción: Se agregaron las nuevas columnas de catrutas FechaAlta y FechaVigencia

Modificada por: Jesús Humberto Morales
Fecha de modificación: 27/08/2021
Versión: 8.0.64.13
Solicitud: 4527
Descripción: Se modifico el tipo de valor de Importe base en la descripcion de materiales

***************************************************************************************************** */

AS
DECLARE
	@docHandle int,
	@CursorIdRutaConceptoFacturacion int,
	@CursorIdConceptoFacturacion int,
	@CursorImporte money,
	@CursorImporteDlls money,
	@CursorIdRutaDescripcionCarga int,
	@CursorDescripcionCarga varchar(1024),
	@CursorIdUnidadMedidaEmbalaje int,
	@CursorIdUnidadMedidaPeso int,
	@CursorTarifa float,
	@CursorTarifaDlls float,
	@CursorIdTipoViaje int,
	@CursorIdTipoUnidad int,
	@CursorIdClasificacionViaje int,	
	@CursorImporteBaseLiquidacion float,	
	@CursorAplicarTarifaPor tinyint,
	@CursorIdRutaTarifaMaterialPemex int,
	@CursorIdMaterialPemex int,
	@CursorTarifaPemex money,
	@CursorPeaje5Pemex money,
	@CursorPeaje6Pemex money,
	@CursorPeaje9Pemex money,
	@CursorSueldoBaseSencilloPemex money,
	@CursorSueldoBaseFullPemex money,
	@CursorComisionSencilloPemex money,
	@CursorComisionFullPemex money,
	@COL_IdRutaTrayecto int,
	@COL_Secuencia int,
	@COL_IdOrigen int,
	@COL_IdDestino int,
	@COL_Kilometros int,
	@COL_Horas decimal(15,2),
	@COL_RutaGoogleMap varchar(max),
	@COL_GastosAutorizados varchar(max),
	@COL_SueldoBaseSencilloCargado money,
	@COL_SueldoBaseSencilloVacio money,
	@COL_SueldoBaseFullCargado money,
	@COL_SueldoBaseFullVacio money,
	@COL_SueldoBaseFullVacioCargado_CargadoVacio money,	
	@COL_SueldoBaseDllsSencilloCargado money,
	@COL_SueldoBaseDllsSencilloVacio money,
	@COL_SueldoBaseDllsFullCargado money,
	@COL_SueldoBaseDllsFullVacio money,
	@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio money,	
	@COL_PorcentajeComisionPermisionario int,	
	@COL_CuotaPorKilometro money,
	@COL_CuotaDiaria money,
	@COL_ImporteSeguro money,
	@COL_IdGeocercaDisparaSalida int,
	@COL_GeocercaDisparaSalidaES tinyint,
	@COL_IdGeocercaDisparaLlegada int,
	@COL_GeocercaDisparaLlegadaES tinyint,
	@COL_Geocercas varchar(max),
	@COL_IdEstatuViajeSalida int,
	@COL_IdEstatuViajeLlegada int,
	@COL_FactorLiqKmsSencilloCargado decimal(15,2),
	@COL_FactorLiqKmsSencilloVacio decimal(15,2), 
	@COL_FactorLiqKmsFullCargado decimal(15,2),
	@COL_FactorLiqKmsFullVacio decimal(15,2),
	@COL_FactorLiqKmsFullVacioCargado_CargadoVacio decimal(15,2),
	@COL_Casetas varchar(max),
	@COL_FactorLiqKmsDllsSencilloCargado decimal(15, 2),
	@COL_FactorLiqKmsDllsSencilloVacio decimal(15, 2),
	@COL_FactorLiqKmsDllsFullCargado decimal(15, 2),
	@COL_FactorLiqKmsDllsFullVacio decimal(15, 2),
	@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio decimal(15, 2),
	@COL_Permisionarios varchar(max),
	@COL_TipoTrayecto TINYINT,
	@COL_Millas decimal (15,2),
	@COL_ETA decimal(15,2),
	@COL_LocationIdLoad VARCHAR(100),
	@COL_NameLoad VARCHAR(100),
	@COL_AddressLoad VARCHAR(100),
	@COL_CityLoad varchar(100),
	@COL_StateLoad VARCHAR(100),
	@COL_PostalCodeLoad VARCHAR(100),
	@COL_CountryLoad VARCHAR(100),
	@COL_LatitudeLoad float,
	@COL_LongitudeLoad float,
	@COL_LocationIdUnload VARCHAR(100),
	@COL_NameUnload varchar(100),
	@COL_AddressUnload VARCHAR(100),
	@COL_CityUnload VARCHAR(100), 
	@COL_StateUnload varchar(100),
	@COL_PostalCodeUnload VARCHAR(100),
	@COL_CountryUnload VARCHAR(100),
	@COL_LatitudeUnload VARCHAR(100),
	@COL_LongitudeUnload varchar(100),
	@COL_TieneLocation bit,
	@IdImpuestoTrasladado int,
	@IdImpuestoRetenido int,
	@IdRutaConceptoFacturacion int,
	@CursorTraslada bit,
	@CursorRetiene bit,
	@COL_ClavesSatXML varchar(max),
	@IdRutaDescripcionCarga int,
	@COL_UbicacionesXML varchar(max)
	/*SOLICITUD 4208*/
	DECLARE @TempCatRutasTrayectosDistribucionConceptosFacturacion AS TABLE 
		(
		 COL_IdRutaTrayectoDistribucionConceptoFacturacion int
		,COL_IdRutaTrayecto int
		,COL_Secuencia int
		,COL_IdConceptoFacturacion int
		,COL_Importe money
		,COL_ImporteDlls money)
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdRuta = 0
		RAISERROR(N'El identificador de la ruta es un campo requerido',
			16,
			1
			)
			
	IF (SELECT ModificadoEl FROM CatRutas WHERE IdRuta = @IdRuta) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta ruta fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)				

	IF @FolioRuta = 0
		RAISERROR(N'El folio de la ruta es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT * FROM CatRutas WHERE FolioRuta = @FolioRuta AND IdRuta != @IdRuta)			
		RAISERROR(N'El folio de la ruta ya existe en el catálogo',
			16,
			1
			)						

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)			

	IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)			
				
	IF RTRIM(LTRIM(@DescripcionRuta)) = ''
		RAISERROR(N'La descripción de la ruta es un campo requerido',
			16,
			1
			)	

	IF @IdSucursal = 0
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)
	
	IF @dsCatRutasTrayectos IS NULL
		RAISERROR(N'Los trayectos son requeridos',
			16,
			1
			)							
			
	IF @IdTipoUnidad = 0
		SET @IdTipoUnidad = NULL

	IF @IdRemitente = 0 
		SET @IdRemitente = NULL
		
	IF @IdDestinatario = 0 
		SET @IdDestinatario = NULL

	IF @IdTipoViaje = 0 
		SET @IdTipoViaje = NULL

	IF @IdClasificacionViaje = 0 
		SET @IdClasificacionViaje = NULL		
						
	UPDATE CatRutas SET
	FolioRuta = @FolioRuta,
	IdCliente = @IdCliente,
	IdOrigen = @IdOrigen,
	IdDestino = @IdDestino,
	DescripcionRuta = @DescripcionRuta,
	Activa = @Activa,
	IdTipoUnidad = @IdTipoUnidad,
	Kilometros = @Kilometros,
	Horas = @Horas,
	IdSucursal = @IdSucursal,
	Item = @Item,
	Planta = @Planta,
	Convenio = @Convenio,
	IdRemitente = @IdRemitente,
	IdDestinatario = @IdDestinatario,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor,
	ViajeFacturable = @ViajeFacturable,
	ImporteBase = @ImporteBase,
	IdTipoViaje = @IdTipoViaje,
	IdClasificacionViaje = @IdClasificacionViaje,
	Millas = @Millas,
	ETA = @ETA,
	ViajeInternacional = @ViajeInternacional,
	ImportacionExportacion = @ImportacionExportacion,
	ViajeRepartoRecolecta = @ViajeRepartoRecolecta,
	FechaAlta = @FechaAlta,
	FechaVigencia = @FechaVigencia
	WHERE IdRuta = @IdRuta
	
	/*SOLICITUD 4208 SECCION PARA AGREGAR LA DISTRIBUCION DE LOS CONCEPTOS EN UNA VARIABLE TABLA*/
	IF @dsCatRutasTrayectosDistribucionConceptosFacturacion IS NOT NULL
	BEGIN
		
		INSERT INTO @TempCatRutasTrayectosDistribucionConceptosFacturacion(COL_IdRutaTrayectoDistribucionConceptoFacturacion,COL_IdRutaTrayecto,COL_Secuencia,COL_IdConceptoFacturacion,COL_Importe,COL_ImporteDlls)
		SELECT  
		 COL_IdRutaTrayectoDistribucionConceptoFacturacion = T.Item.value('COL_IdRutaTrayectoDistribucionConceptoFacturacion[1]', 'int')
		,COL_IdRutaTrayecto = T.Item.value('COL_IdRutaTrayecto[1]', 'int')
		,COL_Secuencia = T.Item.value('COL_Secuencia[1]', 'int')
		,COL_IdConceptoFacturacion = T.Item.value('COL_IdConceptoFacturacion[1]', 'int')
		,COL_Importe = T.Item.value('COL_Importe[1]', 'money')
		,COL_ImporteDlls = T.Item.value('COL_ImporteDlls[1]', 'money')
		FROM   @dsCatRutasTrayectosDistribucionConceptosFacturacion.nodes('WINDEV_TABLE/CatRutasTrayectosDistribucionConceptosFacturacion') AS T(Item);

	END
	/*FIN SOLICITUD 4208*/

	--SECCION PARA AGREGAR LOS trayectos
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectos
	
	SELECT COL_IdRutaTrayecto,COL_Secuencia,COL_IdOrigen,COL_IdDestino,COL_Kilometros,COL_Horas,COL_RutaGoogleMap,COL_GastosAutorizados,
	COL_SueldoBaseSencilloCargado,COL_SueldoBaseSencilloVacio,COL_SueldoBaseFullCargado,
	COL_SueldoBaseFullVacio,COL_SueldoBaseFullVacioCargado_CargadoVacio,
	COL_SueldoBaseDllsSencilloCargado,COL_SueldoBaseDllsSencilloVacio,COL_SueldoBaseDllsFullCargado,
	COL_SueldoBaseDllsFullVacio,COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,	
	COL_IdGeocercaDisparaSalida,COL_GeocercaDisparaSalidaES,COL_IdGeocercaDisparaLlegada,COL_GeocercaDisparaLlegadaES,COL_Geocercas,COL_IdEstatuViajeSalida,
	COL_IdEstatuViajeLlegada,COL_FactorLiqKmsSencilloCargado,COL_FactorLiqKmsSencilloVacio,COL_FactorLiqKmsFullCargado,COL_FactorLiqKmsFullVacio,
	COL_FactorLiqKmsFullVacioCargado_CargadoVacio,COL_Casetas,
	COL_FactorLiqKmsDllsSencilloCargado,COL_FactorLiqKmsDllsSencilloVacio,COL_FactorLiqKmsDllsFullCargado,
	COL_FactorLiqKmsDllsFullVacio,COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,COL_Permisionarios,COL_TipoTrayecto,COL_Millas,COL_ETA, COL_LocationIdLoad,COL_NameLoad,
	COL_AddressLoad,COL_CityLoad,COL_StateLoad,COL_PostalCodeLoad,COL_CountryLoad,COL_LatitudeLoad,COL_LongitudeLoad,COL_LocationIdUnload,COL_NameUnload,COL_AddressUnload,COL_CityUnload, COL_StateUnload,COL_PostalCodeUnload,COL_CountryUnload,COL_LatitudeUnload,COL_LongitudeUnload,COL_TieneLocation,COL_UbicacionesXML
	INTO #TempCatRutasTrayectos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectos',2) 
	WITH (COL_IdRutaTrayecto int,COL_Secuencia int,COL_IdOrigen int,COL_IdDestino int,COL_Kilometros int,COL_Horas decimal(15,2),COL_RutaGoogleMap ntext,COL_GastosAutorizados ntext,
	COL_SueldoBaseSencilloCargado money,COL_SueldoBaseSencilloVacio money,COL_SueldoBaseFullCargado money,
	COL_SueldoBaseFullVacio money,COL_SueldoBaseFullVacioCargado_CargadoVacio money,
	COL_SueldoBaseDllsSencilloCargado money,COL_SueldoBaseDllsSencilloVacio money,COL_SueldoBaseDllsFullCargado money,
	COL_SueldoBaseDllsFullVacio money,COL_SueldoBaseDllsFullVacioCargado_CargadoVacio money,		
	COL_IdGeocercaDisparaSalida int,COL_GeocercaDisparaSalidaES tinyint,COL_IdGeocercaDisparaLlegada int,COL_GeocercaDisparaLlegadaES tinyint,COL_Geocercas ntext,COL_IdEstatuViajeSalida int,
	COL_IdEstatuViajeLlegada int,COL_FactorLiqKmsSencilloCargado decimal(15,2),COL_FactorLiqKmsSencilloVacio decimal(15,2),COL_FactorLiqKmsFullCargado decimal(15,2),COL_FactorLiqKmsFullVacio decimal(15,2),
	COL_FactorLiqKmsFullVacioCargado_CargadoVacio decimal(15,2),COL_Casetas ntext,
	COL_FactorLiqKmsDllsSencilloCargado decimal(15,2),COL_FactorLiqKmsDllsSencilloVacio decimal(15,2),COL_FactorLiqKmsDllsFullCargado decimal(15,2),
	COL_FactorLiqKmsDllsFullVacio decimal(15,2),COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio decimal(15,2),COL_Permisionarios varchar(max),COL_TipoTrayecto TINYINT,COL_Millas decimal(15,2),COL_ETA  decimal(15,2),COL_LocationIdLoad VARCHAR(100),COL_NameLoad VARCHAR(100),COL_AddressLoad VARCHAR(100),COL_CityLoad varchar(100),COL_StateLoad VARCHAR(100),COL_PostalCodeLoad VARCHAR(100),COL_CountryLoad VARCHAR(100),COL_LatitudeLoad float,COL_LongitudeLoad float,COL_LocationIdUnload VARCHAR(100),COL_NameUnload varchar(100),COL_AddressUnload VARCHAR(100),COL_CityUnload VARCHAR(100), COL_StateUnload varchar(100),COL_PostalCodeUnload VARCHAR(100),COL_CountryUnload VARCHAR(100),COL_LatitudeUnload VARCHAR(100),COL_LongitudeUnload varchar(100), COL_TieneLocation bit,COL_UbicacionesXML varchar(max)) 
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatRutasTrayectos CURSOR LOCAL FOR
	SELECT * FROM #TempCatRutasTrayectos
	
	OPEN CursorCatRutasTrayectos
	FETCH NEXT FROM CursorCatRutasTrayectos
	INTO @COL_IdRutaTrayecto,@COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
	@COL_SueldoBaseSencilloCargado,@COL_SueldoBaseSencilloVacio,@COL_SueldoBaseFullCargado,
	@COL_SueldoBaseFullVacio,@COL_SueldoBaseFullVacioCargado_CargadoVacio,
	@COL_SueldoBaseDllsSencilloCargado,@COL_SueldoBaseDllsSencilloVacio,@COL_SueldoBaseDllsFullCargado,
	@COL_SueldoBaseDllsFullVacio,@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,		
	@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,@COL_IdEstatuViajeSalida,
	@COL_IdEstatuViajeLlegada,@COL_FactorLiqKmsSencilloCargado,@COL_FactorLiqKmsSencilloVacio,@COL_FactorLiqKmsFullCargado,@COL_FactorLiqKmsFullVacio,
	@COL_FactorLiqKmsFullVacioCargado_CargadoVacio,@COL_Casetas,
	@COL_FactorLiqKmsDllsSencilloCargado,@COL_FactorLiqKmsDllsSencilloVacio,@COL_FactorLiqKmsDllsFullCargado,
	@COL_FactorLiqKmsDllsFullVacio,@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,@COL_Permisionarios,@COL_TipoTrayecto,@COL_Millas,@COL_ETA, @COL_LocationIdLoad, @COL_NameLoad, @COL_AddressLoad, @COL_CityLoad, @COL_StateLoad, @COL_PostalCodeLoad, @COL_CountryLoad, @COL_LatitudeLoad, @COL_LongitudeLoad, @COL_LocationIdUnload, @COL_NameUnload, @COL_AddressUnload, @COL_CityUnload, @COL_StateUnload, @COL_PostalCodeUnload, @COL_CountryUnload, @COL_LatitudeUnload, @COL_LongitudeUnload, @COL_TieneLocation,@COL_UbicacionesXML
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @COL_IdEstatuViajeSalida = 0
			SET @COL_IdEstatuViajeSalida = NULL

		IF @COL_IdEstatuViajeLlegada = 0
			SET @COL_IdEstatuViajeLlegada = NULL
			
		IF ISNULL(@COL_Kilometros,0) <= 0	
		RAISERROR(N'El kilometraje del trayecto es un campo requerido',
			16,
			1
			)
				
		IF ISNULL(@COL_Horas,0) <= 0	
		RAISERROR(N'Las horas para el trayecto es un campo requerido',
			16,
			1
			)	
			
		IF @COL_IdRutaTrayecto = 0			
		BEGIN
			INSERT INTO CatRutasTrayectos(CreadoEl,CreadoPor,Horas,IdDestino,IdOrigen,IdRuta,Kilometros,RutaGoogleMap,Secuencia,
			SueldoBaseSencilloCargado,SueldoBaseSencilloVacio,SueldoBaseFullCargado,
			SueldoBaseFullVacio,SueldoBaseFullVacioCargado_CargadoVacio,
			SueldoBaseDllsSencilloCargado,SueldoBaseDllsSencilloVacio,SueldoBaseDllsFullCargado,
			SueldoBaseDllsFullVacio,SueldoBaseDllsFullVacioCargado_CargadoVacio,					
			IdGeocercaDisparaSalida,GeocercaDisparaSalidaES,IdGeocercaDisparaLlegada,GeocercaDisparaLlegadaES,IdEstatuViajeSalida,IdEstatuViajeLlegada,
			FactorLiqKmsSencilloCargado,FactorLiqKmsSencilloVacio,FactorLiqKmsFullCargado,FactorLiqKmsFullVacio,FactorLiqKmsFullVacioCargado_CargadoVacio,
			FactorLiqKmsDllsSencilloCargado,FactorLiqKmsDllsSencilloVacio,FactorLiqKmsDllsFullCargado,FactorLiqKmsDllsFullVacio,FactorLiqKmsDllsFullVacioCargado_CargadoVacio,
			TipoTrayecto,Millas,ETA)
			VALUES(@ModificadoEl,@ModificadoPor,@COL_Horas,@COL_IdDestino,@COL_IdOrigen,@IdRuta,@COL_Kilometros,@COL_RutaGoogleMap,@COL_Secuencia,
			@COL_SueldoBaseSencilloCargado,@COL_SueldoBaseSencilloVacio,@COL_SueldoBaseFullCargado,
			@COL_SueldoBaseFullVacio,@COL_SueldoBaseFullVacioCargado_CargadoVacio,
			@COL_SueldoBaseDllsSencilloCargado,@COL_SueldoBaseDllsSencilloVacio,@COL_SueldoBaseDllsFullCargado,
			@COL_SueldoBaseDllsFullVacio,@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,					
			@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,
			@COL_FactorLiqKmsSencilloCargado,@COL_FactorLiqKmsSencilloVacio,@COL_FactorLiqKmsFullCargado,@COL_FactorLiqKmsFullVacio,@COL_FactorLiqKmsFullVacioCargado_CargadoVacio,
			@COL_FactorLiqKmsDllsSencilloCargado,@COL_FactorLiqKmsDllsSencilloVacio,@COL_FactorLiqKmsDllsFullCargado,@COL_FactorLiqKmsDllsFullVacio,@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,
			@COL_TipoTrayecto,@COL_Millas,@COL_ETA)
			
			SET @COL_IdRutaTrayecto = (SELECT IDENT_CURRENT('CatRutasTrayectos'))	
			--Se agregó sección por la solicitud 12255 para insertar los valores de location en las rutas trayectos cuando retransmision de feight verify
			IF @COL_TieneLocation = 1 
			BEGIN
				INSERT INTO CatRutasTrayectosLocation ( IdRutaTrayecto, LocationIdLoad, NameLoad, AddressLoad, CityLoad, StateLoad, PostalCodeLoad, CountryLoad, LatitudeLoad, LongitudeLoad, LocationIdUnload, NameUnload, AddressUnload, CityUnload, StateUnload, PostalCodeUnload, CountryUnload, LatitudeUnload, LongitudeUnload )
				VALUES( @COL_IdRutaTrayecto, @COL_LocationIdLoad, @COL_NameLoad, @COL_AddressLoad, @COL_CityLoad, @COL_StateLoad, @COL_PostalCodeLoad, @COL_CountryLoad, @COL_LatitudeLoad,
				@COL_LongitudeLoad,@COL_LocationIdUnload,@COL_NameUnload, @COL_AddressUnload, @COL_CityUnload, @COL_StateUnload, @COL_PostalCodeUnload, @COL_CountryUnload, @COL_LatitudeUnload, @COL_LongitudeUnload)
			END	

			/*SOLICITUD 4208*/
			INSERT INTO CatRutasTrayectosDistribucionConceptosFacturacion(IdRutaTrayecto,IdConceptoFacturacion,Secuencia,Importe,ImporteDlls,UltimaModificacion)
			SELECT 
			 @COL_IdRutaTrayecto
			,COL_IdConceptoFacturacion
			,COL_Secuencia
			,COL_Importe
			,COL_ImporteDlls
			,@ModificadoEl
			FROM @TempCatRutasTrayectosDistribucionConceptosFacturacion
			WHERE COL_Secuencia = @COL_Secuencia
			/*SOLICITUD 4208*/

		END
		ELSE
		BEGIN
			UPDATE CatRutasTrayectos SET 
				CatRutasTrayectos.Horas = @COL_Horas,
				CatRutasTrayectos.IdDestino = @COL_IdDestino,
				CatRutasTrayectos.IdOrigen = @COL_IdOrigen,
				CatRutasTrayectos.Kilometros = @COL_Kilometros,
				CatRutasTrayectos.RutaGoogleMap = @COL_RutaGoogleMap,
				CatRutasTrayectos.Secuencia = @COL_Secuencia,
				CatRutasTrayectos.ModificadoEl = @ModificadoEl,
				CatRutasTrayectos.ModificadoPor = @ModificadoPor,
				CatRutasTrayectos.SueldoBaseFullCargado = @COL_SueldoBaseFullCargado,
				CatRutasTrayectos.SueldoBaseFullVacio = @COL_SueldoBaseFullVacio,
				CatRutasTrayectos.SueldoBaseFullVacioCargado_CargadoVacio = @COL_SueldoBaseFullVacioCargado_CargadoVacio,
				CatRutasTrayectos.SueldoBaseSencilloCargado = @COL_SueldoBaseSencilloCargado,
				CatRutasTrayectos.SueldoBaseSencilloVacio = @COL_SueldoBaseSencilloVacio,
				CatRutasTrayectos.SueldoBaseDllsFullCargado = @COL_SueldoBaseDllsFullCargado,
				CatRutasTrayectos.SueldoBaseDllsFullVacio = @COL_SueldoBaseDllsFullVacio,
				CatRutasTrayectos.SueldoBaseDllsFullVacioCargado_CargadoVacio = @COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,
				CatRutasTrayectos.SueldoBaseDllsSencilloCargado = @COL_SueldoBaseDllsSencilloCargado,
				CatRutasTrayectos.SueldoBaseDllsSencilloVacio = @COL_SueldoBaseDllsSencilloVacio,				
				CatRutasTrayectos.IdGeocercaDisparaSalida = @COL_IdGeocercaDisparaSalida,
				CatRutasTrayectos.GeocercaDisparaSalidaES = @COL_GeocercaDisparaSalidaES,
				CatRutasTrayectos.IdGeocercaDisparaLlegada = @COL_IdGeocercaDisparaLlegada,
				CatRutasTrayectos.GeocercaDisparaLlegadaES = @COL_GeocercaDisparaLlegadaES,
				CatRutasTrayectos.IdEstatuViajeSalida = @COL_IdEstatuViajeSalida,
				CatRutasTrayectos.IdEstatuViajeLlegada = @COL_IdEstatuViajeLlegada,
				CatRutasTrayectos.FactorLiqKmsFullCargado = @COL_FactorLiqKmsFullCargado,
				CatRutasTrayectos.FactorLiqKmsFullVacio = @COL_FactorLiqKmsFullVacio,
				CatRutasTrayectos.FactorLiqKmsFullVacioCargado_CargadoVacio = @COL_FactorLiqKmsFullVacioCargado_CargadoVacio,
				CatRutasTrayectos.FactorLiqKmsSencilloCargado = @COL_FactorLiqKmsSencilloCargado,
				CatRutasTrayectos.FactorLiqKmsSencilloVacio = @COL_FactorLiqKmsSencilloVacio,
				CatRutasTrayectos.FactorLiqKmsDllsFullCargado = @COL_FactorLiqKmsDllsFullCargado,
				CatRutasTrayectos.FactorLiqKmsDllsFullVacio = @COL_FactorLiqKmsDllsFullVacio,
				CatRutasTrayectos.FactorLiqKmsDllsFullVacioCargado_CargadoVacio = @COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,
				CatRutasTrayectos.FactorLiqKmsDllsSencilloCargado = @COL_FactorLiqKmsDllsSencilloCargado,
				CatRutasTrayectos.FactorLiqKmsDllsSencilloVacio = @COL_FactorLiqKmsDllsSencilloVacio,
				CatRutasTrayectos.TipoTrayecto = @COL_TipoTrayecto,
				CatRutasTrayectos.Millas = @COL_Millas,
				CatRutasTrayectos.ETA = @COL_ETA
			WHERE IdRutaTrayecto = @COL_IdRutaTrayecto

			/*SOLICITUD 4208*/
			INSERT INTO CatRutasTrayectosDistribucionConceptosFacturacion(IdRutaTrayecto,IdConceptoFacturacion,Secuencia,Importe,ImporteDlls,UltimaModificacion)
			SELECT 
			 COL_IdRutaTrayecto
			,COL_IdConceptoFacturacion
			,COL_Secuencia
			,COL_Importe
			,COL_ImporteDlls
			,@ModificadoEl
			FROM @TempCatRutasTrayectosDistribucionConceptosFacturacion
			WHERE COL_IdRutaTrayecto = @COL_IdRutaTrayecto AND ISNULL(COL_IdRutaTrayectoDistribucionConceptoFacturacion,0) = 0

			UPDATE CRTDCF SET
			CRTDCF.Secuencia = Temp.COL_Secuencia,
			CRTDCF.IdConceptoFacturacion = Temp.COL_IdConceptoFacturacion,
			CRTDCF.Importe = Temp.COL_Importe,
			CRTDCF.ImporteDlls = Temp.COL_ImporteDlls,
			CRTDCF.UltimaModificacion = @ModificadoEl
			FROM CatRutasTrayectosDistribucionConceptosFacturacion AS CRTDCF
			INNER JOIN @TempCatRutasTrayectosDistribucionConceptosFacturacion AS Temp on CRTDCF.IdRutaTrayectoDistribucionConceptoFacturacion = ISNULL(Temp.COL_IdRutaTrayectoDistribucionConceptoFacturacion,0)
			/*SOLICITUD 4208*/

			--Se agregó sección por la solicitud 12255 para actualizar los valores de location en las rutas trayectos cuando retransmision de feight verify
			IF @COL_TieneLocation = 1 
			BEGIN
				IF EXISTS( SELECT * FROM CatRutasTrayectosLocation WHERE IdRutaTrayecto = @COL_IdRutaTrayecto ) 
				BEGIN
					UPDATE CatRutasTrayectosLocation SET
					LocationIdLoad = @COL_LocationIdLoad,
					NameLoad = @COL_NameLoad,
					AddressLoad = @COL_AddressLoad,
					CityLoad = @COL_CityLoad,
					StateLoad = @COL_StateLoad,
					PostalCodeLoad = @COL_PostalCodeLoad,
					CountryLoad = @COL_CountryLoad,
					LatitudeLoad = @COL_LatitudeLoad,
					LongitudeLoad = @COL_LongitudeLoad,
					LocationIdUnload = @COL_LocationIdUnload,
					NameUnload = @COL_NameUnload,
					AddressUnload = @COL_AddressUnload,
					CityUnload = @COL_CityUnload,
					StateUnload = @COL_StateUnload,
					PostalCodeUnload = @COL_PostalCodeUnload,
					CountryUnload = @COL_CountryUnload,
					LatitudeUnload = @COL_LatitudeUnload,
					LongitudeUnload = @COL_LongitudeUnload
					WHERE IdRutaTrayecto = @COL_IdRutaTrayecto
				END
				ELSE
				BEGIN
					INSERT INTO CatRutasTrayectosLocation ( IdRutaTrayecto, LocationIdLoad, NameLoad, AddressLoad, CityLoad, StateLoad, PostalCodeLoad, CountryLoad, LatitudeLoad, LongitudeLoad, LocationIdUnload, NameUnload, AddressUnload, CityUnload, StateUnload, PostalCodeUnload, CountryUnload, LatitudeUnload, LongitudeUnload )
					VALUES( @COL_IdRutaTrayecto, @COL_LocationIdLoad, @COL_NameLoad, @COL_AddressLoad, @COL_CityLoad, @COL_StateLoad, @COL_PostalCodeLoad, @COL_CountryLoad, @COL_LatitudeLoad,
					@COL_LongitudeLoad,@COL_LocationIdUnload,@COL_NameUnload, @COL_AddressUnload, @COL_CityUnload, @COL_StateUnload, @COL_PostalCodeUnload, @COL_CountryUnload, @COL_LatitudeUnload, @COL_LongitudeUnload)
				END
			END
			ELSE
			BEGIN
				DECLARE @IdRutaTrayectoLocation int
				SET @IdRutaTrayectoLocation = ( SELECT IdRutaTrayectoLocation FROM CatRutasTrayectosLocation WHERE IdRutaTrayecto = @COL_IdRutaTrayecto )
				IF @IdRutaTrayectoLocation IS NOT NULL
				BEGIN
					DELETE CatRutasTrayectosLocation WHERE IdRutaTrayectoLocation = @IdRutaTrayectoLocation
				END
			END	
		END

		/*Seccion para agregar las ubicaciones para el complemento de carta porte*/
		----------------------------------------------
		IF @COL_UbicacionesXML <> ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_UbicacionesXML
			
			SELECT ATT_IdRutaTrayectoUbicacion,ATT_IdRemitente,ATT_FechaCarga,ATT_DatosRemitente,ATT_IdDestinatario,ATT_FechaEntrega,ATT_DatosDestinatario
			INTO #TempCatRutasTrayectosUbicaciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosUbicaciones',2) 
			WITH(ATT_IdRutaTrayectoUbicacion int,ATT_IdRemitente int,ATT_FechaCarga datetime,ATT_DatosRemitente nvarchar(max),ATT_IdDestinatario int,ATT_FechaEntrega datetime,ATT_DatosDestinatario nvarchar(max))
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasTrayectosUbicaciones(IdRutaTrayecto,IdRemitente,FechaCarga,DatosRemitente,IdDestinatario,FechaEntrega,DatosDestinatario,UltimaFechaModificacion)
			SELECT @COL_IdRutaTrayecto,ATT_IdRemitente,CASE WHEN ATT_FechaCarga = '' THEN NULL ELSE ATT_FechaCarga END,ATT_DatosRemitente,ATT_IdDestinatario,CASE WHEN ATT_FechaEntrega = '' THEN NULL ELSE ATT_FechaEntrega END,ATT_DatosDestinatario,@ModificadoEl
			FROM #TempCatRutasTrayectosUbicaciones
			WHERE
			ATT_IdRutaTrayectoUbicacion = 0

			UPDATE CatRutasTrayectosUbicaciones SET
			IdRemitente = #TempCatRutasTrayectosUbicaciones.ATT_IdRemitente
			,FechaCarga = CASE WHEN #TempCatRutasTrayectosUbicaciones.ATT_FechaCarga = '' THEN NULL ELSE #TempCatRutasTrayectosUbicaciones.ATT_FechaCarga END 
			,DatosRemitente = #TempCatRutasTrayectosUbicaciones.ATT_DatosRemitente
			,IdDestinatario = #TempCatRutasTrayectosUbicaciones.ATT_IdDestinatario
			,FechaEntrega =  CASE WHEN #TempCatRutasTrayectosUbicaciones.ATT_FechaEntrega = '' THEN NULL ELSE #TempCatRutasTrayectosUbicaciones.ATT_FechaEntrega END
			,DatosDestinatario = #TempCatRutasTrayectosUbicaciones.ATT_DatosDestinatario
			,UltimaFechaModificacion = @ModificadoEl
			FROM CatRutasTrayectosUbicaciones 
			INNER JOIN #TempCatRutasTrayectosUbicaciones ON CatRutasTrayectosUbicaciones.IdRutaTrayectoUbicacion = #TempCatRutasTrayectosUbicaciones.ATT_IdRutaTrayectoUbicacion

			
			DROP TABLE #TempCatRutasTrayectosUbicaciones
		END
		DELETE CatRutasTrayectosUbicaciones WHERE IdRutaTrayecto = @COL_IdRutaTrayecto AND UltimaFechaModificacion <> @ModificadoEl
		-----------------------------------------------

		IF @COL_GastosAutorizados <> ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_GastosAutorizados
			
			SELECT ATT_IdRutaTrayectoGasto,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_LitrosAutorizados,ATT_ImporteAutorizadoState,ATT_LitrosAutorizadosState,ATT_GalonesAutorizados
			INTO #TempCatRutasTrayectosGastos
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosGastos',2) 
			WITH(ATT_IdRutaTrayectoGasto int,ATT_IdConceptoGastoViaje int,ATT_ImporteAutorizado money,ATT_LitrosAutorizados decimal(15,2),ATT_ImporteAutorizadoState int,ATT_LitrosAutorizadosState int,ATT_GalonesAutorizados decimal(15,2))
			
			EXEC sp_xml_removedocument @docHandle
									
			INSERT INTO CatRutasTrayectosGastos(IdRutaTrayecto,IdConceptoGastoViaje,ImporteAutorizado,ImporteAutorizadoState,LitrosAutorizados,LitrosAutorizadosState,CreadoEl,CreadoPor,GalonesAutorizados)
			SELECT @COL_IdRutaTrayecto,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_ImporteAutorizadoState,ATT_LitrosAutorizados,ATT_LitrosAutorizadosState,@ModificadoEl,@ModificadoPor,ATT_GalonesAutorizados
			FROM #TempCatRutasTrayectosGastos
			WHERE ATT_IdRutaTrayectoGasto = 0
			
			UPDATE CatRutasTrayectosGastos SET
				CatRutasTrayectosGastos.ImporteAutorizado = #TempCatRutasTrayectosGastos.ATT_ImporteAutorizado,
				CatRutasTrayectosGastos.ImporteAutorizadoState = #TempCatRutasTrayectosGastos.ATT_ImporteAutorizadoState,
				CatRutasTrayectosGastos.LitrosAutorizados = #TempCatRutasTrayectosGastos.ATT_LitrosAutorizados,
				CatRutasTrayectosGastos.LitrosAutorizadosState = #TempCatRutasTrayectosGastos.ATT_LitrosAutorizadosState,
				CatRutasTrayectosGastos.ModificadoEl = @ModificadoEl,
				CatRutasTrayectosGastos.ModificadoPor = @ModificadoPor,
				CatRutasTrayectosGastos.GalonesAutorizados = #TempCatRutasTrayectosGastos.ATT_GalonesAutorizados
			FROM CatRutasTrayectosGastos
			INNER JOIN #TempCatRutasTrayectosGastos ON CatRutasTrayectosGastos.IdRutaTrayectoGasto = #TempCatRutasTrayectosGastos.ATT_IdRutaTrayectoGasto
			
			DROP TABLE #TempCatRutasTrayectosGastos						
		END
		
		DELETE FROM CatRutasTrayectosGastos WHERE IdRutaTrayecto = @COL_IdRutaTrayecto AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		DELETE FROM CatRutasTrayectosDistribucionConceptosFacturacion WHERE IdRutaTrayecto = @COL_IdRutaTrayecto AND UltimaModificacion <> @ModificadoEl
		--seccion para agregar y actualizar las geocercas y estatus automaticos
		IF @COL_Geocercas <> ''
        BEGIN
            EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Geocercas

            SELECT COL_IdEstatuViajeEntrar,COL_IdEstatuViajeSalir,COL_IdGeocerca,COL_IdRutaTrayectoGeocerca
            INTO #TempCatRutasTrayectosGeocercas
            FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosGeocercas',2) 
            WITH(COL_IdEstatuViajeEntrar int,COL_IdEstatuViajeSalir int,COL_IdGeocerca int,COL_IdRutaTrayectoGeocerca int)
            
            EXEC sp_xml_removedocument @docHandle
            
            INSERT INTO CatRutasTrayectosGeocercas(IdRutaTrayecto,IdEstatuViajeEntrada,IdEstatuViajeSalida,IdGeocerca,CreadoEl,CreadoPor)
            SELECT @COL_IdRutaTrayecto,
			CASE COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE COL_IdEstatuViajeEntrar END,
			CASE COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE COL_IdEstatuViajeSalir END,
            COL_IdGeocerca,@ModificadoEl,@ModificadoPor
            FROM #TempCatRutasTrayectosGeocercas
            WHERE COL_IdRutaTrayectoGeocerca = 0
            
            UPDATE CatRutasTrayectosGeocercas SET
				CatRutasTrayectosGeocercas.IdGeocerca = #TempCatRutasTrayectosGeocercas.COL_IdGeocerca,
				CatRutasTrayectosGeocercas.IdEstatuViajeEntrada = CASE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeEntrar END,
				CatRutasTrayectosGeocercas.IdEstatuViajeSalida = CASE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeSalir END,
				CatRutasTrayectosGeocercas.ModificadoEl = @ModificadoEl,
				CatRutasTrayectosGeocercas.ModificadoPor = @ModificadoPor
            FROM CatRutasTrayectosGeocercas
            INNER JOIN #TempCatRutasTrayectosGeocercas ON CatRutasTrayectosGeocercas.IdRutaTrayectoGeocerca = #TempCatRutasTrayectosGeocercas.COL_IdRutaTrayectoGeocerca
            
            DROP TABLE #TempCatRutasTrayectosGeocercas
        END
        
        DELETE FROM CatRutasTrayectosGeocercas WHERE IdRutaTrayecto = @COL_IdRutaTrayecto AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
        
		--seccion para grabar la informacion de las casetas autorizadas
        IF @COL_Casetas <> ''		
		BEGIN
			--se agrego en la solicitud 11783 los campos de nomenclaturasat y numero de ejes para usarlo cuando tenga ptv activado
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Casetas
			
			SELECT ATT_IdCaseta,ATT_IdConceptoGastoViaje,ATT_Importe,ATT_IdRutaTrayectoCaseta,
			ATT_NomenclaturaSCT,ATT_NumeroEjes
			INTO #TempCatRutasTrayectosCasetas
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosCasetas',2) 
			WITH (ATT_IdCaseta int,ATT_IdConceptoGastoViaje int,ATT_Importe money,ATT_IdRutaTrayectoCaseta int,
			ATT_NomenclaturaSCT varchar(1),ATT_NumeroEjes tinyint)
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasTrayectosCasetas(CreadoEl,CreadoPor,IdRutaTrayecto,IdCaseta,IdConceptoGastoViaje,
			Importe,NomenclaturaSCT,NumeroEjes)
			SELECT @ModificadoEl,@ModificadoPor,@COL_IdRutaTrayecto,ATT_IdCaseta,ATT_IdConceptoGastoViaje,
			ATT_Importe,ATT_NomenclaturaSCT,ATT_NumeroEjes
			FROM #TempCatRutasTrayectosCasetas			
			WHERE ATT_IdRutaTrayectoCaseta = 0
			
			UPDATE CatRutasTrayectosCasetas SET
			CatRutasTrayectosCasetas.NomenclaturaSCT = #TempCatRutasTrayectosCasetas.ATT_NomenclaturaSCT,
			CatRutasTrayectosCasetas.NumeroEjes = #TempCatRutasTrayectosCasetas.ATT_NumeroEjes,
			CatRutasTrayectosCasetas.ModificadoEl = @ModificadoEl,
			CatRutasTrayectosCasetas.ModificadoPor = @ModificadoPor,
			CatRutasTrayectosCasetas.IdCaseta = #TempCatRutasTrayectosCasetas.ATT_IdCaseta,
			CatRutasTrayectosCasetas.IdConceptoGastoViaje = #TempCatRutasTrayectosCasetas.ATT_IdConceptoGastoViaje,
			CatRutasTrayectosCasetas.Importe = #TempCatRutasTrayectosCasetas.ATT_Importe
			FROM CatRutasTrayectosCasetas
			INNER JOIN #TempCatRutasTrayectosCasetas ON CatRutasTrayectosCasetas.IdRutaTrayectoCaseta = #TempCatRutasTrayectosCasetas.ATT_IdRutaTrayectoCaseta
			
			DROP TABLE #TempCatRutasTrayectosCasetas
		END
		
		DELETE FROM CatRutasTrayectosCasetas WHERE IdRutaTrayecto = @COL_IdRutaTrayecto AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

		--despues de agregar/modificar/eliminar las casetas autorizadas se valida
		--que los gastos autorizados de autopistas y autopistas iave sean igual a la suma de de las casetas autorizadas
		--solo si el modulo de ptv "NO esta contratado" esta seccion debe estar despues de casetas autorizadas y gastos autorizados
		--solicitud 11783
		IF @PTVContratado = 0
		BEGIN
			DECLARE @GastoAutorizado money,@CasetaAutorizado money,
			@GastoAutorizadoText nvarchar(20),@CasetaAutorizadoText nvarchar(20)

			--seccion para evaluar autopistas a contado IdConceptoGastoViaje = 3
			SET @GastoAutorizado = ISNULL((SELECT SUM(ImporteAutorizado) FROM CatRutasTrayectosGastos where IdRutaTrayecto = @COL_IdRutaTrayecto AND IdConceptoGastoViaje = 3),0)
			SET @CasetaAutorizado = ISNULL((SELECT SUM(Importe) FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @COL_IdRutaTrayecto AND IdConceptoGastoViaje = 3 AND ISNULL(NomenclaturaSCT,'') = '' AND ISNULL(NumeroEjes,0) = 0),0)

			IF @GastoAutorizado <> @CasetaAutorizado AND EXISTS(SELECT * FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @COL_IdRutaTrayecto AND IdConceptoGastoViaje = 3)
			BEGIN
				SET @GastoAutorizadoText = CAST(@GastoAutorizado AS nvarchar(20))
				SET @CasetaAutorizadoText = CAST(@CasetaAutorizado AS nvarchar(20))
				RAISERROR(N'En el trayecto %d el importe autorizado para autopistas (contado/efectivo) $%s no coincide con la suma de los importes de las casetas a contado $%s',
					16,
					1,
					@COL_Secuencia,
					@GastoAutorizadoText,
					@CasetaAutorizadoText
					)
			END

			--seccion para evaluar autopistas a credito IdConceptoGastoViaje = 4
			SET @GastoAutorizado = ISNULL((SELECT SUM(ImporteAutorizado) FROM CatRutasTrayectosGastos where IdRutaTrayecto = @COL_IdRutaTrayecto AND IdConceptoGastoViaje = 4),0)
			SET @CasetaAutorizado = ISNULL((SELECT SUM(Importe) FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @COL_IdRutaTrayecto AND IdConceptoGastoViaje = 4 AND ISNULL(NomenclaturaSCT,'') = '' AND ISNULL(NumeroEjes,0) = 0),0)

			IF @GastoAutorizado <> @CasetaAutorizado AND EXISTS(SELECT * FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @COL_IdRutaTrayecto AND IdConceptoGastoViaje = 4)
			BEGIN
				SET @GastoAutorizadoText = CAST(@GastoAutorizado AS nvarchar(20))
				SET @CasetaAutorizadoText = CAST(@CasetaAutorizado AS nvarchar(20))
				RAISERROR(N'En el trayecto %d el importe autorizado para autopistas IAVE(crédito) $%s no coincide con la suma de los importes de las casetas a crédito $%s',
					16,
					1,
					@COL_Secuencia,
					@GastoAutorizadoText,
					@CasetaAutorizadoText
					)
			END
		END

		-- Agrega, modificar permisionarios
		IF @COL_Permisionarios <> '' AND  @COL_ETA <> '1'		
		BEGIN

			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Permisionarios
			SELECT 	COL_SueldoBaseSencilloCargado,
					COL_SueldoBaseFullCargado,
					COL_SueldoBaseFullVacioCargado_CargadoVacio,
					COL_SueldoBaseSencilloVacio,
					COL_SueldoBaseFullVacio,
					COL_SueldoBaseDllsSencilloCargado,
					COL_SueldoBaseDllsFullCargado,
					COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,
					COL_SueldoBaseDllsSencilloVacio,
					COL_SueldoBaseDllsFullVacio,
					COL_IdOperador,
					COL_IdRutaTrayectoPermisionario,
					COL_PorcentajeComisionPermisionario,	
					COL_CuotaPorKilometro,
					COL_CuotaDiaria,
					COL_ImporteSeguro
			INTO #TempCatRutasTrayectosPermisionarios
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosPermisionarios',2) 
			WITH ( COL_SueldoBaseSencilloCargado money,
				   COL_SueldoBaseFullCargado money,
				   COL_SueldoBaseFullVacioCargado_CargadoVacio money,
				   COL_SueldoBaseSencilloVacio money,
				   COL_SueldoBaseFullVacio money,
				   COL_SueldoBaseDllsSencilloCargado money,
				   COL_SueldoBaseDllsFullCargado money,
				   COL_SueldoBaseDllsFullVacioCargado_CargadoVacio money,
				   COL_SueldoBaseDllsSencilloVacio money,
				   COL_SueldoBaseDllsFullVacio money,
				   COL_IdOperador int,
				   COL_IdRutaTrayectoPermisionario int,
				   COL_PorcentajeComisionPermisionario int,	
				   COL_CuotaPorKilometro money,
				   COL_CuotaDiaria money,
				   COL_ImporteSeguro money
				   )

			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasTrayectosPermisionarios(CreadoEl,CreadoPor,IdRutaTrayecto,IdOperador,SueldoBaseFullCargado,SueldoBaseFullVacio,
					SueldoBaseFullVacioCargado_CargadoVacio,SueldoBaseSencilloCargado,SueldoBaseSencilloVacio,SueldoBaseDllsFullCargado,
					SueldoBaseDllsFullVacio,SueldoBaseDllsFullVacioCargado_CargadoVacio,SueldoBaseDllsSencilloCargado,SueldoBaseDllsSencilloVacio,
					PorcentajeComisionPermisionario,CuotaPorKilometro,CuotaDiaria,ImporteSeguro)
			SELECT @ModificadoEl,@ModificadoPor,@COL_IdRutaTrayecto,COL_IdOperador,COL_SueldoBaseFullCargado,COL_SueldoBaseFullVacio,
				   COL_SueldoBaseFullVacioCargado_CargadoVacio,COL_SueldoBaseSencilloCargado,COL_SueldoBaseSencilloVacio,
				   COL_SueldoBaseDllsFullCargado,COL_SueldoBaseDllsFullVacio,COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,
				   COL_SueldoBaseDllsSencilloCargado,COL_SueldoBaseDllsSencilloVacio,COL_PorcentajeComisionPermisionario,
				   COL_CuotaPorKilometro,COL_CuotaDiaria,COL_ImporteSeguro
			FROM #TempCatRutasTrayectosPermisionarios
			WHERE COL_IdRutaTrayectoPermisionario = 0
			
			UPDATE CatRutasTrayectosPermisionarios SET
			CatRutasTrayectosPermisionarios.ModificadoEl								= @ModificadoEl,
			CatRutasTrayectosPermisionarios.ModificadoPor								= @ModificadoPor,
			CatRutasTrayectosPermisionarios.IdOperador									= #TempCatRutasTrayectosPermisionarios.COL_IdOperador,
			CatRutasTrayectosPermisionarios.SueldoBaseFullCargado						= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseFullCargado,
			CatRutasTrayectosPermisionarios.SueldoBaseFullVacio							= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseFullVacio,
			CatRutasTrayectosPermisionarios.SueldoBaseFullVacioCargado_CargadoVacio		= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseFullVacioCargado_CargadoVacio,
			CatRutasTrayectosPermisionarios.SueldoBaseSencilloCargado					= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseSencilloCargado,
			CatRutasTrayectosPermisionarios.SueldoBaseSencilloVacio						= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseSencilloVacio,
			CatRutasTrayectosPermisionarios.SueldoBaseDllsFullCargado					= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseDllsFullCargado,
			CatRutasTrayectosPermisionarios.SueldoBaseDllsFullVacio						= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseDllsFullVacio,
			CatRutasTrayectosPermisionarios.SueldoBaseDllsFullVacioCargado_CargadoVacio = #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,
			CatRutasTrayectosPermisionarios.SueldoBaseDllsSencilloCargado				= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseDllsSencilloCargado,
			CatRutasTrayectosPermisionarios.SueldoBaseDllsSencilloVacio					= #TempCatRutasTrayectosPermisionarios.COL_SueldoBaseDllsSencilloVacio,
			CatRutasTrayectosPermisionarios.PorcentajeComisionPermisionario				= #TempCatRutasTrayectosPermisionarios.COL_PorcentajeComisionPermisionario,
			CatRutasTrayectosPermisionarios.CuotaPorKilometro							= #TempCatRutasTrayectosPermisionarios.COL_CuotaPorKilometro,
			CatRutasTrayectosPermisionarios.CuotaDiaria									= #TempCatRutasTrayectosPermisionarios.COL_CuotaDiaria,
			CatRutasTrayectosPermisionarios.ImporteSeguro								= #TempCatRutasTrayectosPermisionarios.COL_ImporteSeguro
			FROM CatRutasTrayectosPermisionarios
			INNER JOIN #TempCatRutasTrayectosPermisionarios ON CatRutasTrayectosPermisionarios.IdRutaTrayectoPermisionario = #TempCatRutasTrayectosPermisionarios.COL_IdRutaTrayectoPermisionario
			
			DROP TABLE #TempCatRutasTrayectosPermisionarios
		END
		
		DELETE FROM CatRutasTrayectosPermisionarios WHERE IdRutaTrayecto = @COL_IdRutaTrayecto AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		
		--next del cursor ultima linea en el while
		FETCH NEXT FROM CursorCatRutasTrayectos
		INTO @COL_IdRutaTrayecto,@COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
		@COL_SueldoBaseSencilloCargado,@COL_SueldoBaseSencilloVacio,@COL_SueldoBaseFullCargado,
		@COL_SueldoBaseFullVacio,@COL_SueldoBaseFullVacioCargado_CargadoVacio,
		@COL_SueldoBaseDllsSencilloCargado,@COL_SueldoBaseDllsSencilloVacio,@COL_SueldoBaseDllsFullCargado,
		@COL_SueldoBaseDllsFullVacio,@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,				
		@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,@COL_IdEstatuViajeSalida,
		@COL_IdEstatuViajeLlegada,@COL_FactorLiqKmsSencilloCargado,@COL_FactorLiqKmsSencilloVacio,@COL_FactorLiqKmsFullCargado,@COL_FactorLiqKmsFullVacio,
		@COL_FactorLiqKmsFullVacioCargado_CargadoVacio,@COL_Casetas,
		@COL_FactorLiqKmsDllsSencilloCargado,@COL_FactorLiqKmsDllsSencilloVacio,@COL_FactorLiqKmsDllsFullCargado,
		@COL_FactorLiqKmsDllsFullVacio,@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,@COL_Permisionarios,@COL_TipoTrayecto,@COL_Millas,@COL_ETA, @COL_LocationIdLoad, @COL_NameLoad, @COL_AddressLoad, @COL_CityLoad, @COL_StateLoad, @COL_PostalCodeLoad, @COL_CountryLoad, @COL_LatitudeLoad, @COL_LongitudeLoad, @COL_LocationIdUnload, @COL_NameUnload, @COL_AddressUnload, @COL_CityUnload, @COL_StateUnload, @COL_PostalCodeUnload, @COL_CountryUnload, @COL_LatitudeUnload, @COL_LongitudeUnload, @COL_TieneLocation,@COL_UbicacionesXML
	END

	CLOSE CursorCatRutasTrayectos
	DEALLOCATE CursorCatRutasTrayectos						

	--elimina los trayectos que no hayan sido modificados o creados
	IF EXISTS(SELECT TOP 1 IdViaje FROM ProViajes WHERE IdRuta = @IdRuta) AND EXISTS(SELECT IdRutaTrayecto FROM CatRutasTrayectos WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl)
		RAISERROR(N'La ruta/trayectos tiene viajes ligados, no es posible eliminarlo',
			16,
			1
			)
	
	DELETE FROM CatRutasTrayectosLocation WHERE IdRutaTrayecto = ( SELECT IdRutaTrayecto FROM CatRutasTrayectos WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl )
	DELETE FROM CatRutasTrayectos WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	--AGREGA LOS CONCEPTOS DE FACTURACION	
	IF @dsCatRutasConceptosFacturacion IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasConceptosFacturacion
		
		SELECT COL_IdRutaConceptoFacturacion,COL_IdConceptoFacturacion,COL_Importe,COL_ImporteDlls,
		COL_IdTipoViaje,COL_IdTipoUnidad,COL_IdClasificacionViaje,COL_IdImpuestoTrasladado,COL_IdImpuestoRetenido,COL_Traslada,COL_Retiene
		INTO #TempCatRutasConceptosFacturacion
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasConceptosFacturacion',2) 
		WITH (COL_IdRutaConceptoFacturacion int,COL_IdConceptoFacturacion int,COL_Importe money,COL_ImporteDlls money,
		COL_IdTipoViaje int,COL_IdTipoUnidad int,COL_IdClasificacionViaje int,COL_IdImpuestoTrasladado int, COL_IdImpuestoRetenido int,COL_Traslada bit ,COL_Retiene bit)
		
		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorCatRutasConceptosFacturacion CURSOR LOCAL FOR
		SELECT * FROM #TempCatRutasConceptosFacturacion
		
		OPEN CursorCatRutasConceptosFacturacion
		FETCH NEXT FROM CursorCatRutasConceptosFacturacion
		INTO @CursorIdRutaConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,
		@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @CursorIdTipoViaje = 0
				SET	@CursorIdTipoViaje = NULL

			IF @CursorIdTipoUnidad = 0
				SET	@CursorIdTipoUnidad = NULL

			IF @CursorIdClasificacionViaje = 0
				SET	@CursorIdClasificacionViaje = NULL
					
			IF @CursorIdRutaConceptoFacturacion != 0
			BEGIN
				UPDATE CatRutasConceptosFacturacion SET
				IdConceptoFacturacion = @CursorIdConceptoFacturacion,
				Importe = @CursorImporte,
				ImporteDlls = @CursorImporteDlls,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor,
				IdTipoViaje = @CursorIdTipoViaje,
				IdTipoUnidad = @CursorIdTipoUnidad,
				IdClasificacionViaje = @CursorIdClasificacionViaje,
				TrasladaImpuesto = @CursorTraslada,
				RetieneImpuesto = @CursorRetiene
				WHERE IdRutaConceptoFacturacion = @CursorIdRutaConceptoFacturacion

				DELETE FROM CatRutasConceptosFacturacionImpuestos WHERE IdRutaConceptoFacturacion = @CursorIdRutaConceptoFacturacion

				IF @IdImpuestoTrasladado != 0 
				BEGIN
					INSERT INTO CatRutasConceptosFacturacionImpuestos(IdRutaConceptoFacturacion,IdImpuesto)
					VALUES( @CursorIdRutaConceptoFacturacion,@IdImpuestoTrasladado )
				END

				IF @IdImpuestoRetenido != 0
				BEGIN
					INSERT INTO CatRutasConceptosFacturacionImpuestos(IdRutaConceptoFacturacion,IdImpuesto)
					VALUES( @CursorIdRutaConceptoFacturacion,@IdImpuestoRetenido )
				END
			END
			ELSE
			BEGIN
				INSERT INTO CatRutasConceptosFacturacion(CreadoEl,CreadoPor,IdConceptoFacturacion,
				IdRuta,Importe,ImporteDlls,IdTipoViaje,IdTipoUnidad,IdClasificacionViaje,TrasladaImpuesto,RetieneImpuesto)
				VALUES(@ModificadoEl,@ModificadoPor,@CursorIdConceptoFacturacion,
				@IdRuta,@CursorImporte,@CursorImporteDlls,@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@CursorTraslada,@CursorRetiene)

				SET @IdRutaConceptoFacturacion = (SELECT IDENT_CURRENT('CatRutasConceptosFacturacion'))

				IF @IdImpuestoTrasladado != 0 
				BEGIN
					INSERT INTO CatRutasConceptosFacturacionImpuestos(IdRutaConceptoFacturacion,IdImpuesto)
					VALUES( @IdRutaConceptoFacturacion,@IdImpuestoTrasladado )
				END

				IF @IdImpuestoRetenido != 0
				BEGIN
					INSERT INTO CatRutasConceptosFacturacionImpuestos(IdRutaConceptoFacturacion,IdImpuesto)
					VALUES( @IdRutaConceptoFacturacion,@IdImpuestoRetenido )
				END
			END	
		
			FETCH NEXT FROM CursorCatRutasConceptosFacturacion
			INTO @CursorIdRutaConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,
			@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
		END

		CLOSE CursorCatRutasConceptosFacturacion
		DEALLOCATE CursorCatRutasConceptosFacturacion										
	END

	DELETE FROM CatRutasConceptosFacturacionImpuestos 
	WHERE IdRutaConceptoFacturacion IN( SELECT IdRutaConceptoFacturacion FROM CatRutasConceptosFacturacion 
		WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl )

	DELETE FROM CatRutasConceptosFacturacion WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	--AGREGA LAS DESCRIPCION/MATERIALES
	IF @dsCatRutasDescripcionesCargaTarifas IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasDescripcionesCargaTarifas

		SELECT COL_IdRutaDescripcionCarga,COL_DescripcionCarga,COL_IdUnidadMedidaEmbalaje,COL_IdUnidadMedidaPeso,COL_Tarifa,COL_AplicarTarifaPor,COL_TarifaDlls,COL_ImporteBaseLiquidacion,COL_ClavesSatXML
		INTO #TempCatRutasDescripcionesCargaTarifas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasDescripcionesCargaTarifas',2) 
		WITH (COL_IdRutaDescripcionCarga int,COL_DescripcionCarga varchar(1024),COL_IdUnidadMedidaEmbalaje int,COL_IdUnidadMedidaPeso int,COL_Tarifa float,COL_AplicarTarifaPor tinyint,COL_TarifaDlls float,COL_ImporteBaseLiquidacion float,COL_ClavesSatXML varchar(max))

		EXEC sp_xml_removedocument @docHandle		

		DECLARE CursorCatRutasDescripcionesCargaTarifas CURSOR LOCAL FOR
		SELECT * FROM #TempCatRutasDescripcionesCargaTarifas
		
		OPEN CursorCatRutasDescripcionesCargaTarifas
		FETCH NEXT FROM CursorCatRutasDescripcionesCargaTarifas
		INTO @CursorIdRutaDescripcionCarga,@CursorDescripcionCarga,@CursorIdUnidadMedidaEmbalaje,@CursorIdUnidadMedidaPeso,@CursorTarifa,@CursorAplicarTarifaPor,@CursorTarifaDlls,@CursorImporteBaseLiquidacion,@COL_ClavesSatXML
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @IdRutaDescripcionCarga = @CursorIdRutaDescripcionCarga
			IF @CursorIdRutaDescripcionCarga != 0
			BEGIN
				UPDATE CatRutasDescripcionesCargaTarifas SET
				DescripcionCarga = @CursorDescripcionCarga,
				IdUnidadMedidaEmbalaje = @CursorIdUnidadMedidaEmbalaje,
				IdUnidadMedidaPeso = @CursorIdUnidadMedidaPeso,
				Tarifa = @CursorTarifa,
				TarifaDlls = @CursorTarifaDlls,
				ImporteBaseLiquidacion = @CursorImporteBaseLiquidacion,
				AplicarTarifaPor = @CursorAplicarTarifaPor,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
				WHERE IdRutaDescripcionCarga = @CursorIdRutaDescripcionCarga
			END
			ELSE
			BEGIN
				INSERT INTO CatRutasDescripcionesCargaTarifas(AplicarTarifaPor,CreadoEl,CreadoPor,DescripcionCarga,
				IdRuta,IdUnidadMedidaEmbalaje,IdUnidadMedidaPeso,Tarifa,TarifaDlls,ImporteBaseLiquidacion)
				VALUES(@CursorAplicarTarifaPor,@ModificadoEl,@ModificadoPor,@CursorDescripcionCarga,
				@IdRuta,@CursorIdUnidadMedidaEmbalaje,@CursorIdUnidadMedidaPeso,@CursorTarifa,@CursorTarifaDlls,@CursorImporteBaseLiquidacion)

				SET @IdRutaDescripcionCarga = (SELECT IDENT_CURRENT('CatRutasDescripcionesCargaTarifas'))
			END
			--Seccion para las claves del sat de los materiales
			IF ISNULL(@COL_ClavesSatXML,'') <> ''
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_ClavesSatXML
					SELECT
						 @IdRutaDescripcionCarga AS ATT_IdRutaDescripcionCarga
						,ATT_ClaveSAT
						,ATT_DescripcionSAT
						,ATT_CatalogoSAT
						,ATT_Opcional
					INTO #TempCatRutasDescripcionesCargaTarifasClavesSAT
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasDescripcionesCargaTarifasClavesSAT',2) 
					WITH (
						 ATT_IdRutaDescripcionCarga int
						,ATT_ClaveSAT varchar(10)
						,ATT_DescripcionSAT varchar(max)
						,ATT_CatalogoSAT varchar(50)
						,ATT_Opcional nvarchar(100))

			
					EXEC sp_xml_removedocument @docHandle

					UPDATE CRD SET
					CRD.ClaveSAT = T.ATT_ClaveSAT,
					CRD.Opcional = T.ATT_Opcional,
					CRD.UltimaModificacion = @ModificadoEl
					FROM
					CatRutasDescripcionesCargaTarifasClavesSAT AS CRD
					INNER JOIN #TempCatRutasDescripcionesCargaTarifasClavesSAT AS T ON T.ATT_IdRutaDescripcionCarga = CRD.IdRutaDescripcionCarga
					WHERE T.ATT_CatalogoSAT = CRD.CatalogoSAT

					INSERT INTO CatRutasDescripcionesCargaTarifasClavesSAT(IdRutaDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					SELECT 
					ATT_IdRutaDescripcionCarga
				   ,ATT_ClaveSAT 
				   ,ATT_CatalogoSAT 
				   ,ATT_Opcional 
				   ,@ModificadoEl
					FROM #TempCatRutasDescripcionesCargaTarifasClavesSAT
					WHERE
					ATT_IdRutaDescripcionCarga NOT IN (
					SELECT SUB.IdRutaDescripcionCarga FROM CatRutasDescripcionesCargaTarifasClavesSAT AS SUB 
					WHERE 
					SUB.ClaveSAT = ATT_ClaveSAT
					AND SUB.CatalogoSAT = ATT_CatalogoSAT)
					

					DROP TABLE #TempCatRutasDescripcionesCargaTarifasClavesSAT
				END

			DELETE FROM CatRutasDescripcionesCargaTarifasClavesSAT WHERE IdRutaDescripcionCarga = @CursorIdRutaDescripcionCarga AND UltimaModificacion <> @ModificadoEl
			FETCH NEXT FROM CursorCatRutasDescripcionesCargaTarifas
			INTO @CursorIdRutaDescripcionCarga,@CursorDescripcionCarga,@CursorIdUnidadMedidaEmbalaje,@CursorIdUnidadMedidaPeso,@CursorTarifa,@CursorAplicarTarifaPor,@CursorTarifaDlls,@CursorImporteBaseLiquidacion,@COL_ClavesSatXML
		END

		CLOSE CursorCatRutasDescripcionesCargaTarifas
		DEALLOCATE CursorCatRutasDescripcionesCargaTarifas												
	END

	DELETE FROM CatRutasDescripcionesCargaTarifas WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	--MODIFICA Y/O AGREGA LAS TARIFAS MATERIALES PEMEX -- SOLICITUD 902
	IF @dsCatRutasTarifasMaterialesPemex IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTarifasMaterialesPemex

		SELECT COL_IdRutaTarifasMateriales,COL_IdMaterialPemex,COL_Tarifa,COL_Peaje5,COL_Peaje6,COL_Peaje9,COL_SueldoBaseSencillo,COL_SueldoBaseFull,COL_ComisionSencillo,COL_ComisionFull
		INTO #TempCatRutasTarifasMaterialesPemex
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasTarifasMaterialesPemex',2) 
		WITH (COL_IdRutaTarifasMateriales int,COL_IdMaterialPemex int,COL_Tarifa money,COL_Peaje5 money,COL_Peaje6 money,COL_Peaje9 money,COL_SueldoBaseSencillo money,COL_SueldoBaseFull money,COL_ComisionSencillo money,COL_ComisionFull money)

		EXEC sp_xml_removedocument @docHandle		

		DECLARE CursorCatRutasTarifasMaterialesPemex CURSOR LOCAL FOR
		SELECT * FROM #TempCatRutasTarifasMaterialesPemex
		
		OPEN CursorCatRutasTarifasMaterialesPemex
		FETCH NEXT FROM CursorCatRutasTarifasMaterialesPemex
		INTO @CursorIdRutaTarifaMaterialPemex,@CursorIdMaterialPemex,@CursorTarifaPemex,@CursorPeaje5Pemex,@CursorPeaje6Pemex,@CursorPeaje9Pemex,@CursorSueldoBaseSencilloPemex,@CursorSueldoBaseFullPemex,@CursorComisionSencilloPemex,@CursorComisionFullPemex
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @CursorIdRutaTarifaMaterialPemex != 0
			BEGIN
				UPDATE CatRutasTarifasMateriales SET
				IdMaterialPemex = @CursorIdMaterialPemex,
				Tarifa = @CursorTarifaPemex,
				Peaje5 = @CursorPeaje5Pemex,
				Peaje6 = @CursorPeaje6Pemex,
				Peaje9 = @CursorPeaje9Pemex,
				SueldoBaseSencillo = @CursorSueldoBaseSencilloPemex,
				SueldoBaseFull = @CursorSueldoBaseFullPemex,
				ComisionSencillo = @CursorComisionSencilloPemex,
				ComisionFull = @CursorComisionFullPemex,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
				WHERE IdRutaTarifasMateriales = @CursorIdRutaTarifaMaterialPemex
			END
			ELSE
			BEGIN
				INSERT INTO CatRutasTarifasMateriales(IdRuta,IdMaterialPemex,CreadoEl,CreadoPor,Tarifa,Peaje5,Peaje6,Peaje9,
				SueldoBaseSencillo,SueldoBaseFull,ComisionSencillo,ComisionFull)
				VALUES(@IdRuta,@CursorIdMaterialPemex,@ModificadoEl,@ModificadoPor,@CursorTarifaPemex,@CursorPeaje5Pemex,
				@CursorPeaje6Pemex,@CursorPeaje9Pemex,@CursorSueldoBaseSencilloPemex,@CursorSueldoBaseFullPemex,@CursorComisionSencilloPemex,@CursorComisionFullPemex)
			END
		
			FETCH NEXT FROM CursorCatRutasTarifasMaterialesPemex
			INTO @CursorIdRutaTarifaMaterialPemex,@CursorIdMaterialPemex,@CursorTarifaPemex,@CursorPeaje5Pemex,@CursorPeaje6Pemex,@CursorPeaje9Pemex,@CursorSueldoBaseSencilloPemex,@CursorSueldoBaseFullPemex,@CursorComisionSencilloPemex,@CursorComisionFullPemex
		END

		CLOSE CursorCatRutasTarifasMaterialesPemex
		DEALLOCATE CursorCatRutasTarifasMaterialesPemex												
	END

	DELETE FROM CatRutasTarifasMateriales WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	--seccion para agregar los contactos que no van recibir informacion de la ruta
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasClienteContactos
	
	SELECT ATT_IdClienteContacto,ATT_IdRutaClienteContacto
	INTO #TempCatRutasClienteContactos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasClienteContactos',2) 
	WITH (ATT_IdClienteContacto int,ATT_IdRutaClienteContacto int)
	
	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO CatRutasClientesContactos(CreadoEl,CreadoPor,IdRuta,IdClienteContacto)
	SELECT @ModificadoEl,@ModificadoPor,@IdRuta,ATT_IdClienteContacto
	FROM #TempCatRutasClienteContactos
	WHERE ATT_IdRutaClienteContacto = 0
	
	UPDATE CatRutasClientesContactos SET
	CatRutasClientesContactos.ModificadoEl = @ModificadoEl,
	CatRutasClientesContactos.ModificadoPor = @ModificadoPor
	FROM CatRutasClientesContactos
	INNER JOIN #TempCatRutasClienteContactos ON CatRutasClientesContactos.IdRutaClienteContacto = #TempCatRutasClienteContactos.ATT_IdRutaClienteContacto
	
	DELETE FROM CatRutasClientesContactos WHERE IdRuta = @IdRuta AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	COMMIT
END TRY
BEGIN CATCH
	--Se cierran los cursores
	 IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasTrayectos')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','')) > -1
		BEGIN
			CLOSE CursorCatRutasTrayectos
		END
	  DEALLOCATE CursorCatRutasTrayectos
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasConceptosFacturacion')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasConceptosFacturacion')) > -1
		BEGIN
			CLOSE CursorCatRutasConceptosFacturacion
		END
	  DEALLOCATE CursorCatRutasConceptosFacturacion
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasDescripcionesCargaTarifas')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasDescripcionesCargaTarifas')) > -1
		BEGIN
			CLOSE CursorCatRutasDescripcionesCargaTarifas
		END
	  DEALLOCATE CursorCatRutasDescripcionesCargaTarifas
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasTarifasMaterialesPemex')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasTarifasMaterialesPemex')) > -1
		BEGIN
			CLOSE CursorCatRutasTarifasMaterialesPemex
		END
	  DEALLOCATE CursorCatRutasTarifasMaterialesPemex
	  END

	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

