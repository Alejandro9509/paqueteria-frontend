CREATE PROCEDURE [dbo].[usp_ProViajeAgregarPQ](	
	@IdSucursal int ,
	@NumViajeCliente varchar(10) ,
	@Fecha date ,
	@Hora time(7) ,
	@FechaRegistro  varchar(80),
	@HoraRegistro  varchar(80),
	@IdEstatusViaje int ,
	@CandadoOficial varchar ,
	@Identificador varchar,
	@IdUnidad int,
	@IdOrigen int,
	@IdDestino int,
	@IdRemolque1 int,
	@IdRemolque2 int,
	@IdDolly int,
	@IdOperador int
	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @IdGuia int;
		DECLARE @FOLIO int;
        DECLARE @CodigoUnidad varchar(16);
		DECLARE @FOLIOSTR varchar(10);
        DECLARE @Observacion varchar(max);
        DECLARE @FechaRegistroDate date;
	DECLARE @HoraRegistroTime time;
		DECLARE @TRACKINGSTR varchar(10);
		IF ISNULL(@IdSucursal, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NumViajeCliente, '') = '' begin
			RAISERROR(N'*INICIO*El numero de viaje cliente es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdEstatusViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus del viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@FechaRegistro, '') = '' begin
			RAISERROR(N'*INICIO*La fecha de registro es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@HoraRegistro, '') = '' begin
			RAISERROR(N'*INICIO*La hora de registro es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end


	IF @FechaRegistro IS NOT NULL AND LEN(@FechaRegistro) > 0 begin
	set @FechaRegistroDate = CAST(@FechaRegistro as date)
	set @HoraRegistroTime= CAST(@HoraRegistro as time)
	
		end
		

		
		EXEC @FOLIO = GenerarSecuenciaPQ @proceso=5;
		--	RAISERROR(N'*INICIO*El Tipo de cambio de estatus es un campo requerido*FIN*' ,  -1, 1,@FOLIO )
		
		select @FOLIOSTR = [dbo].[GeneraFolioPQ](5, @FOLIO);
        

        insert into ProViajesPQ (	
		IdSucursal,
		FolioViaje ,
		NumViajeCliente,
		Fecha,
		Hora,
		FechaRegistro,
		HoraRegistro,
		IdEstatusViaje,
		CandadoOficial,
		Identificador,
		IdOrigen,
		IdDestino,
		IdUnidad,
		IdRemolque1,
		IdRemolque2,
		IdDolly,
		IdOperador
	)
	values
	(
		@IdSucursal,
	@FOLIOSTR ,
	@NumViajeCliente ,
	getdate(),
	CONVERT(TIME, GETDATE()),
	@FechaRegistroDate,
	@HoraRegistroTime,
	@IdEstatusViaje,
	@CandadoOficial,
	@Identificador,
	@IdOrigen,
	@IdDestino,
	@IdUnidad,
	@IdRemolque1,
	@IdRemolque2,
	@IdDolly,
	@IdOperador
	);
        --SET @CodigoUnidad = (SELECT Codigo FROM CatUnidades WHERE IdUnidad = @IdUnidad);
        --set @Observacion = 'Unidad asignada al viaje ' + @FOLIOSTR;

        --exec usp_ProInventarioUnidadesActualizar @IdUnidad, @CodigoUnidad,4,0,0,
          --   @IdOrigen,@FechaRegistroDate,null,@FechaRegistroDate,'',0,@Observacion;

        IF @@TRANCOUNT > 0
			BEGIN

                COMMIT TRANSACTION 

                RETURN
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

