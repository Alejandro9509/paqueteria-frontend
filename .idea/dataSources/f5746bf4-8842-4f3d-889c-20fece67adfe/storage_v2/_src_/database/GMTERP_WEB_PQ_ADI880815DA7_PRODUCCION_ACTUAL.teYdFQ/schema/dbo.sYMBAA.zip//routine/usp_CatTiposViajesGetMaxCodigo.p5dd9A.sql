
CREATE PROCEDURE [dbo].[usp_CatTiposViajesGetMaxCodigo]

AS

SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTiposViajes
go

