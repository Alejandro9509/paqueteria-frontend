
CREATE PROCEDURE [dbo].[usp_CatTiposPeriodosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTiposPeriodos
go

