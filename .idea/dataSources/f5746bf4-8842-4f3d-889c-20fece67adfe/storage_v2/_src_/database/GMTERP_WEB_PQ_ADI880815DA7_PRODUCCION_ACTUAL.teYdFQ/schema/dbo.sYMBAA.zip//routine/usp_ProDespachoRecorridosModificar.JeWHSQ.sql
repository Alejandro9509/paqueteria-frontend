CREATE PROCEDURE [dbo].[usp_ProDespachoRecorridosModificar]


	@FechaRecorrido datetime,
	@IdCliente int,
	@Descripcion varchar(50),    
	@IdUnidad int,
	@IdOperador int,
	@Observaciones varchar(512),
	@TiempoRecorrido decimal(15,2),
	@Kilometros int,
	@IdRecorrido int,
	@FechaHoraRecorridoEstatus datetime,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdEstatuViaje int,
	@IdPeticion varchar(100),
	@Referencia varchar(50),
	@Placas varchar(9),
	@CodigoUnidad varchar(16),
	@NombreOperador varchar(100),
	@IdOrigen int,
	@IdDestino int,
	@IdRecorridoDespacho int
AS
DECLARE
	@RutaGoogleMap nvarchar(MAX)
			
BEGIN TRY
	BEGIN TRANSACTION
		IF ISDATE(@FechaRecorrido) = 0
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF ISDATE(@FechaHoraRecorridoEstatus) = 0
		RAISERROR(N'La fecha y hora del estatus es un campo requerido',
			16,
			1
			)
			
	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
			
	IF @IdRecorrido = 0 
		RAISERROR(N'La ruta es un campo requerido',
			16,
			1
			)
				
	IF @IdEstatuViaje = 0
		RAISERROR(N'El estatus es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT IdUnidad FROM CatUnidades WHERE IdUnidad = @IdUnidad and Activa = 0) 
		RAISERROR(N'La unidad seleccionada no esta activa.',
			16,
			1
			)		
	IF EXISTS(SELECT IdOperador FROM CatOperadores WHERE IdOperador = @IdOperador and Activo = 0) 
		RAISERROR(N'El operador seleccionado no esta activo.',
			16,
			1
			)
	IF @IdOperador = 0
	BEGIN 
		SET @IdOperador = NULL
	    SET @NombreOperador = NULL
	END  
	IF @IdUnidad = 0 
		Set @IdUnidad = NULL

	SET @RutaGoogleMap = (Select RutaGoogleMap FROM CatRecorridos where IdRecorrido = @IdRecorrido)
		
	UPDATE ProRecorridosDespacho SET
	FechaHoraRecorridoEstatus = @FechaHoraRecorridoEstatus,
	IdCliente = @IdCliente,
	Descripcion = @Descripcion,
	IdUnidad = @IdUnidad,
	IdOperador = @IdOperador,
	Kilometros = @Kilometros,
	IdRecorrido = @IdRecorrido,
	Observaciones = @Observaciones,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	IdEstatuViaje = @IdEstatuViaje,
	Placas = @Placas,
	CodigoUnidad = @CodigoUnidad,
	NombreOperador = @NombreOperador,
	IdOrigen = @IdOrigen,
	IdDestino = @IdDestino,
	RutaGoogleMap = @RutaGoogleMap,
	Referencia = @Referencia
	WHERE IdRecorridoDespacho = @IdRecorridoDespacho
	
	IF NOT EXISTS(SELECT IdRecorridoDespachoEstatus from ProRecorridosDespachoEstatus where IdRecorridoDespacho = @IdRecorridoDespacho and FechaHora = @FechaHoraRecorridoEstatus AND IdEstatusViaje = @IdEstatuViaje)
	BEGIN
		INSERT INTO ProRecorridosDespachoEstatus(ModificadoEl,ModificadoPor,FechaHora,IdEstatusViaje,IdRecorridoDespacho)
		VALUES(@ModificadoEl,@ModificadoPor,@FechaHoraRecorridoEstatus,@IdEstatuViaje,@IdRecorridoDespacho)
	END
    COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

