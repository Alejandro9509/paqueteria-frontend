CREATE PROCEDURE [dbo].[usp_RptInformeTotalesPQ]
@IdInforme int
AS
BEGIN TRY
    BEGIN TRANSACTION

DECLARE @ImporteFlete decimal(20,6);
DECLARE @ImporteSeguro decimal(20,6);
DECLARE @ImporteManiobraEntrega decimal(20,6);
DECLARE @ImporteManiobraRecoleccion decimal(20,6);
DECLARE @ImporteCarga decimal(20,6);
DECLARE @ImporteDescarga decimal(20,6);
DECLARE @PesoToneladas decimal(20,6);


set @ImporteFlete = (select isnull(sum(pgcpq.Importe),0)  as flete 
from ProGuiaPQ PG 
inner join ProGuiaConceptoPQ pgcpq on pgcpq.IdGuia=PG.IdGuia
inner join CatConceptosFacturacion ccf on ccf.IdConceptoFacturacion=pgcpq.IdConceptoFacturacion
inner join ProInformeGuiaPQ pig on pig.IdGuia=PG.IdGuia
inner join ProInformePQ pipq on pipq.IdInforme=pig.IdInforme
where pipq.IdInforme=@IdInforme and ccf.ConceptoFacturacion like '%FLETE%')

set @ImporteSeguro = (select isnull(sum(pgcpq.Importe),0)  as flete 
from ProGuiaPQ PG 
inner join ProGuiaConceptoPQ pgcpq on pgcpq.IdGuia=PG.IdGuia
inner join CatConceptosFacturacion ccf on ccf.IdConceptoFacturacion=pgcpq.IdConceptoFacturacion
inner join ProInformeGuiaPQ pig on pig.IdGuia=PG.IdGuia
inner join ProInformePQ pipq on pipq.IdInforme=pig.IdInforme
where pipq.IdInforme=@IdInforme and ccf.ConceptoFacturacion like '%SEGURO%')

set @ImporteManiobraEntrega = (select isnull(sum(pgcpq.Importe),0)  as flete 
from ProGuiaPQ PG 
inner join ProGuiaConceptoPQ pgcpq on pgcpq.IdGuia=PG.IdGuia
inner join CatConceptosFacturacion ccf on ccf.IdConceptoFacturacion=pgcpq.IdConceptoFacturacion
inner join ProInformeGuiaPQ pig on pig.IdGuia=PG.IdGuia
inner join ProInformePQ pipq on pipq.IdInforme=pig.IdInforme
where pipq.IdInforme=@IdInforme and ccf.ConceptoFacturacion like '%MANIOBRAS DE ENTREGA%')

set @ImporteManiobraRecoleccion = (select isnull(sum(pgcpq.Importe),0)  as flete 
from ProGuiaPQ PG 
inner join ProGuiaConceptoPQ pgcpq on pgcpq.IdGuia=PG.IdGuia
inner join CatConceptosFacturacion ccf on ccf.IdConceptoFacturacion=pgcpq.IdConceptoFacturacion
inner join ProInformeGuiaPQ pig on pig.IdGuia=PG.IdGuia
inner join ProInformePQ pipq on pipq.IdInforme=pig.IdInforme
where pipq.IdInforme=@IdInforme and ccf.ConceptoFacturacion like '%MANIOBRAS DE RECOLECCION%')

set @ImporteCarga = (select isnull(sum(pgcpq.Importe),0)  as flete 
from ProGuiaPQ PG 
inner join ProGuiaConceptoPQ pgcpq on pgcpq.IdGuia=PG.IdGuia
inner join CatConceptosFacturacion ccf on ccf.IdConceptoFacturacion=pgcpq.IdConceptoFacturacion
inner join ProInformeGuiaPQ pig on pig.IdGuia=PG.IdGuia
inner join ProInformePQ pipq on pipq.IdInforme=pig.IdInforme
where pipq.IdInforme=@IdInforme and ccf.ConceptoFacturacion like '%CARGA%')

set @ImporteDescarga = (select isnull(sum(pgcpq.Importe),0)  as flete 
from ProGuiaPQ PG 
inner join ProGuiaConceptoPQ pgcpq on pgcpq.IdGuia=PG.IdGuia
inner join CatConceptosFacturacion ccf on ccf.IdConceptoFacturacion=pgcpq.IdConceptoFacturacion
inner join ProInformeGuiaPQ pig on pig.IdGuia=PG.IdGuia
inner join ProInformePQ pipq on pipq.IdInforme=pig.IdInforme
where pipq.IdInforme=@IdInforme and ccf.ConceptoFacturacion like '%DESCARGA%')

select @ImporteFlete as flete,@ImporteSeguro as seguro, @ImporteManiobraEntrega as entrega, @ImporteManiobraRecoleccion as recoleccion, @ImporteCarga as carga,@ImporteDescarga as descarga;

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION
    EXECUTE usp_GetErrorInfo;
END CATCH
go

