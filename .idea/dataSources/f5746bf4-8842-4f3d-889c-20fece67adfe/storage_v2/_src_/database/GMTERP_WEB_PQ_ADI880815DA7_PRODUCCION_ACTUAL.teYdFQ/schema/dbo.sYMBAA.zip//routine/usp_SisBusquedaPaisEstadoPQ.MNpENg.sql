CREATE PROCEDURE [dbo].[usp_SisBusquedaPaisEstadoPQ]
	@IdCP INT

AS
BEGIN TRY
	BEGIN TRANSACTION
		  select cp.IdEstado ,(Select p.IdPais from CatEstados p where p.IdEstado =cp.IdEstado)as IdPais from CatCodigosPostales cp   where cp.IdCodigoPostal = @IdCP
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

