CREATE PROCEDURE [dbo].[usp_ProConciliacionesModificar]
	@Folio int,
	@Fecha datetime,
	@Periodo Varchar(150),
	@IdCuentaBancaria int,
	@Depositos decimal(15,2),
	@Retiros  decimal(15,2),
	@Estatus int,
	@dsProConciliacionesMovimientosEstadoDeCuenta ntext,
	@dsProConciliacionesMovimientosGM ntext,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@FechaInicial datetime,
	@FechaFinal Datetime,
	@IdConciliacion int,
	@ConciliarConFechaCobro bit

/* *************************************************************************************************
Procedimiento usp_ProConciliacionesModificar

Parámetros: 
	@Folio (entrada, entero). Folio de la conciliacion
	@Fecha (entrada, fecha). Fecha y hora de la conciliacion
	@Periodo (entrada, texto). Periodo de la conciliacion
	@IdCuentaBancaria (entrada, entero). Identificador de la cuenta bancaria
	@Depositos (entrada, moneda). Depositos
	@Retiros (entrada, moneda). Retiros
	@Estatus (entrada, entero). Estatus de la conciliacion
	@dsProConciliacionesMovimientosEstadoDeCuenta (entrada, texto). Relacion de estado de cuenta
	@dsProConciliacionesMovimientosGM (entrada, texto). Relacion de los movimientos bancarios
	@ModificadoPor (entrada, entero). Usuario que modifico
	@ModificadoEl (entrada, fecha hora). Fecha y hora de modificacion
	@IdPeticion (entrada, string). Id de la Petición, generada en WEBDEV
	@FechaInicial (entrada, fecha). Fecha inicial rango
	@FechaFinal (entrada, fecha). Fecha final rango
	@IdConciliacion (entrada, entero). Identificador de la conciliacion
	@ConciliarConFechaCobro (entrada, boleano). Considerar fecha de cobro movimientos bancarios

Descripción: Procedimiento para modificar una conciliacion

06/11/2020 - Se agrego el parametro @ConciliarConFechaCobro

Implementada por: XXXX
Fecha de implementacion: XXXX
Versión ERP: XXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 06/11/2020
Versión ERP: 8.0.56.12

Invocada desde: PAGE_ProConciliacionesAM (Solicitud 3393)
***************************************************************************************************** */
AS
DECLARE
	@docHandle int,
	@IdMovimientosEstadoDeCuenta_CURSOR int,
	@Fecha_CURSOR datetime,
	@Importe_CURSOR decimal(15,2),
	@Cheque_CURSOR int,
	@Tipo_CURSOR tinyint,
	@Conciliado_CURSOR int,
	@Referencia_CURSOR varchar(8000),
	@Estatus_CURSOR varchar(5),
	@IdConciliacionMovimientoBancario_CURSOR int,
	@IdMovimientoBancario_CURSOR int,
	@ConciliadoGM_CURSOR int
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdConciliacion = 0
		RAISERROR(N'El Id de la conciliación es un campo requerido', 16, 1)

	IF @Folio = 0
		RAISERROR(N'El folio es un campo requerido', 16, 1)

	IF EXISTS(SELECT Folio FROM ProConciliaciones WHERE Folio = @Folio AND IdConciliacion <> @IdConciliacion)
		RAISERROR(N'El folio ya fue utilizado por otro usuario', 16, 1)				

	IF @IdCuentaBancaria = 0
		RAISERROR(N'La cuenta es un campo requerido', 16, 1)

			
	IF @dsProConciliacionesMovimientosEstadoDeCuenta IS NULL
		RAISERROR(N'Es necesario tener movimientos de estado de cuenta', 16, 1)	

	IF @dsProConciliacionesMovimientosGM IS NULL
		RAISERROR(N'Es necesario tener movimientos Bancarios', 16, 1)		

	Update ProConciliaciones SET
		Folio = @Folio,
		Fecha = @Fecha,
		Periodo = @Periodo,
		IdCuentaBancaria = @IdCuentaBancaria,
		Depositos = @Depositos,
		Retiros = @Retiros,
		Estatus = @Estatus,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl,
		FechaInicial = @FechaInicial,
		FechaFinal = @FechaFinal,
		ConciliarConFechaCobro = @ConciliarConFechaCobro
	Where IdConciliacion = @IdConciliacion

	----SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProConciliacionesMovimientosEstadoDeCuenta

	SELECT ATT_IdMovimientosEstadoDeCuenta,ATT_Fecha,ATT_Importe,ATT_Cheque,ATT_Tipo,ATT_Conciliado,ATT_Referencia,ATT_Estatus
	INTO #TempProConciliacionesMovimientosEstadoDeCuenta
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProConciliacionesMovimientosEstadoDeCuenta',2) 
	WITH (ATT_IdMovimientosEstadoDeCuenta int,ATT_Fecha datetime,ATT_Importe decimal(15,6),ATT_Cheque int,ATT_Tipo tinyint,ATT_Conciliado int,ATT_Referencia varchar(8000),ATT_Estatus Varchar(5))
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE ProConciliacionesMovimientosEstadoDeCuenta_CURSOR CURSOR FOR
	SELECT * FROM #TempProConciliacionesMovimientosEstadoDeCuenta

	OPEN ProConciliacionesMovimientosEstadoDeCuenta_CURSOR
	FETCH NEXT FROM ProConciliacionesMovimientosEstadoDeCuenta_CURSOR
	INTO @IdMovimientosEstadoDeCuenta_CURSOR,@Fecha_CURSOR,@Importe_CURSOR,@Cheque_CURSOR,@Tipo_CURSOR,@Conciliado_CURSOR,@Referencia_CURSOR,@Estatus_CURSOR

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @IdMovimientosEstadoDeCuenta_CURSOR = 0
		
			INSERT INTO ProConciliacionesMovimientosEstadoDeCuenta(IdConciliacion,Fecha,Importe,Cheque,Tipo,Conciliado,Referencia,Estatus,CreadoEl,CreadoPor)
			VALUES(@IdConciliacion,@Fecha_CURSOR,@Importe_CURSOR,@Cheque_CURSOR,@Tipo_CURSOR,@Conciliado_CURSOR,@Referencia_CURSOR,@Estatus_CURSOR,@ModificadoEl,@ModificadoPor)
		ELSE
			UPDATE ProConciliacionesMovimientosEstadoDeCuenta SET
				IdConciliacion = @IdConciliacion,
				Fecha = @Fecha_CURSOR,
				Importe = @Importe_CURSOR,
				Cheque = @Cheque_CURSOR,
				Tipo = @Tipo_CURSOR,
				Conciliado = @Conciliado_CURSOR,
				Referencia = @Referencia_CURSOR,
				Estatus = @Estatus_CURSOR,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdConciliacionMovimientoEstadoDeCuenta = @IdMovimientosEstadoDeCuenta_CURSOR
	
		FETCH NEXT FROM ProConciliacionesMovimientosEstadoDeCuenta_CURSOR
		INTO @IdMovimientosEstadoDeCuenta_CURSOR,@Fecha_CURSOR,@Importe_CURSOR,@Cheque_CURSOR,@Tipo_CURSOR,@Conciliado_CURSOR,@Referencia_CURSOR,@Estatus_CURSOR
	END

	CLOSE ProConciliacionesMovimientosEstadoDeCuenta_CURSOR
	DEALLOCATE ProConciliacionesMovimientosEstadoDeCuenta_CURSOR
	
	DELETE FROM ProConciliacionesMovimientosEstadoDeCuenta WHERE IdConciliacion = @IdConciliacion AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	
	--set @SumatoriaConceptos = (SELECT ISNULL(SUM(Importe),0) FROM ProFacturasConceptosFacturacion WHERE IdFactura = @IdFactura)
	--set @DiferenciaImporte = @SubTotal - @SumatoriaConceptos

	--IF @DiferenciaImporte > 1 OR @DiferenciaImporte < -1
	--	RAISERROR(N'La suma de los importes de los conceptos de facturación no son iguales al subtotal',
	--		16,
	--		1
	--		)


	--SECCION PARA AGREGAR LOS IMPUESTOS
	----SECCION PARA AGREGAR LOS CONCEPTOS DE FACTURACION
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProConciliacionesMovimientosGM

	SELECT ATT_IdConciliacionMovimientoBancario,ATT_IdMovimientoBancario,ATT_Conciliado
	INTO #TempProConciliacionesMovimientosBancarios
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProConciliacionesMovimientosBancarios',2) 
	WITH (ATT_IdConciliacionMovimientoBancario int,ATT_IdMovimientoBancario int,ATT_Conciliado int)
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE ProConciliacionesMovimientosBancarios_CURSOR CURSOR FOR
	SELECT * FROM #TempProConciliacionesMovimientosBancarios

	OPEN ProConciliacionesMovimientosBancarios_CURSOR
	FETCH NEXT FROM ProConciliacionesMovimientosBancarios_CURSOR
	INTO @IdConciliacionMovimientoBancario_CURSOR,@IdMovimientoBancario_CURSOR,@ConciliadoGM_CURSOR

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @IdConciliacionMovimientoBancario_CURSOR = 0
			
			INSERT INTO ProConciliacionesMovimientosBancarios(IdConciliacion,IdMovimientoBancario,Conciliado,CreadoEl,CreadoPor)
			VALUES(@IdConciliacion,@IdMovimientoBancario_CURSOR,@ConciliadoGM_CURSOR,@ModificadoEl,@ModificadoPor)
		ELSE
			UPDATE ProConciliacionesMovimientosBancarios SET
				IdConciliacion = @IdConciliacion,
				IdMovimientoBancario = @IdMovimientoBancario_CURSOR,
				Conciliado = @ConciliadoGM_CURSOR,				
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
			WHERE IdConciliacionMovimientoBancario= @IdConciliacionMovimientoBancario_CURSOR
	
		FETCH NEXT FROM ProConciliacionesMovimientosBancarios_CURSOR
		INTO @IdConciliacionMovimientoBancario_CURSOR,@IdMovimientoBancario_CURSOR,@ConciliadoGM_CURSOR
	END

	CLOSE ProConciliacionesMovimientosBancarios_CURSOR
	DEALLOCATE ProConciliacionesMovimientosBancarios_CURSOR
	
	DELETE FROM ProConciliacionesMovimientosBancarios WHERE IdConciliacion = @IdConciliacion AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

