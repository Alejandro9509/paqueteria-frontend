	
	CREATE PROCEDURE [dbo].[usp_CatLayoutsImportarIncidenciasModificar]
		@IdLayoutImportarIncidencia	int,
		@Layout	varchar(50),
		@TipoArchivo tinyint,
		@Separador	varchar(1),
		@RenglonInicial	tinyint,
		@ColumnaCodigoEmpleado tinyint,
		@ColumnaIdIncidencia	tinyint,
		@ColumnaValorIncidencia tinyint,
		@ColumnaEstado tinyint,
		@FechaHoraJuntas bit,
		@ColumnaFechaHora tinyint,
		@FormatoFechaHora	varchar(26),
		@ColumnaFecha	tinyint,
		@FormatoFecha	varchar(15),
		@ColumnaHora	tinyint,
		@FormatoHora	varchar(15),	
		@ModificadoEl	datetime,
		@ModificadoPor	int,
		@IdPeticion varchar(100)		
	AS
	BEGIN TRY
		BEGIN TRANSACTION

			IF @IdLayoutImportarIncidencia = 0
				RAISERROR(N'El identificador del layout es un campo requerido',
					16,
					1
					)

			IF LTRIM(RTRIM(@Layout)) = ''
				RAISERROR(N'El nombre del layout es un campo requerido',
					16,
					1
					)
		
			UPDATE CatLayoutsImportarIncidencias SET 
			Layout = @Layout,
			TipoArchivo = @TipoArchivo,
			Separador = @Separador,
			RenglonInicial = @RenglonInicial,
			ColumnaCodigoEmpleado = @ColumnaCodigoEmpleado,
			ColumnaIdIncidencias = @ColumnaIdIncidencia,
			ColumnaValorIncidencia = @ColumnaValorIncidencia,
			ColumnaEstado = @ColumnaEstado,		
			FechaHoraJuntas = @FechaHoraJuntas,
			ColumnaFechaHora = @ColumnaFechaHora,
			FormatoFechaHora = @FormatoFechaHora,
			ColumnaFecha = @ColumnaFecha,
			FormatoFecha = @FormatoFecha,
			ColumnaHora = @ColumnaHora,
			FormatoHora = @FormatoHora,		
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor		
			WHERE IdLayoutImportarIncidencia = @IdLayoutImportarIncidencia	
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

