CREATE PROCEDURE [dbo].[usp_CatConceptosPDOFijosAgregar]
	@Descripcion Varchar(40),
	@IdConceptoPDO int,
	@FechaInicioAplicacion datetime,
	@ImporteValor tinyint,
	@VecesAplicar int,
	@VecesAplicado int,
	@MontoLimite decimal(15,2),
	@MontoAcumulado decimal(15,2),
	@FechaRegistro datetime,
	@Activo bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@Valor decimal(7,2),
	@Importe money,
	@TipoConcepto int,
	@NumeroConcepto int,
	@DescripcionConcepto Varchar(40),
	@IdEmpleado int,	
	@NumeroControl int,
	@IdPeticion varchar(100),
	@IdPeriodo int,
	@IdCalculoAnual INT = 0
AS
BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
		IF @Descripcion = ''
			RAISERROR(N'La descripción es un campo requerido',
				16,
				1
				)
		IF isnull(@FechaInicioAplicacion, '') = ''
			RAISERROR(N'La fecha de inicio de aplicación es un campo requerido',
				16,
				1
				)	
		IF @ImporteValor = 0
			RAISERROR(N'El ImporteValor es un campo requerido',
				16,
				1
				)
		IF @VecesAplicar = 0
			RAISERROR(N'Veces a aplicar es un campo requerido',
				16,
				1
				)
	--Sección para Insertar en CatConceptosPDOFijos
	INSERT INTO CatConceptosPDOFijos(Descripcion,IdConceptoPDO,FechaInicioAplicacion,
	ImporteValor,VecesAplicar,VecesAplicado,MontoLimite,MontoAcumulado,FechaRegistro,Activo,CreadoPor,
	CreadoEl,Valor,Importe,TipoConcepto,NumeroConcepto,DescripcionConcepto,IdEmpleado,NumeroControl,IdCalculoAnual)
	VALUES(@Descripcion,@IdConceptoPDO,@FechaInicioAplicacion,
	@ImporteValor,@VecesAplicar,@VecesAplicado,@MontoLimite,@MontoAcumulado,@FechaRegistro,@Activo,@CreadoPor,
	@CreadoEl,@Valor,@Importe,@TipoConcepto,@NumeroConcepto,@DescripcionConcepto,@IdEmpleado,@NumeroControl,@IdCalculoAnual)

	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	COMMIT
END TRY
BEGIN CATCH	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

