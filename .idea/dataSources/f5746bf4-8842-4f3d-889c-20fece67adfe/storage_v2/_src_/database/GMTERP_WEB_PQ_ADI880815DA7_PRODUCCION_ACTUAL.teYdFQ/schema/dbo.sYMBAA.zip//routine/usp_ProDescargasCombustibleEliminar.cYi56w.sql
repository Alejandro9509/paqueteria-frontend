
CREATE PROCEDURE [dbo].[usp_ProDescargasCombustibleEliminar]
	@IdDescargaCombustible int,
	@IdPeticion varchar(100)


	/* *************************************************************************************************
Procedimiento usp_ProDescargasCombustibleEliminar

Parámetros: 
	@IdDescargaCombustible		(entrada, datetime). Id de descarga de combustible
	@IdPeticion					(entrada, string). Id de petición
	

Descripción: Procedimiento para eliminar una descarga de combustible previamente cancelada



Implementada por: Julio Hermosillo
Fecha de implementacion: 12/06/2020
Versión ERP: 8.0.53.06


Invocada desde: PAGE_ProDescargasListado (Solicitud 2097)
***************************************************************************************************** */

AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdDescargaCombustible,0)= 0
		RAISERROR(N'Identificador de descarga de combustible es un campo requerido',
			16,
			1
			)	

	IF NOT EXISTS (SELECT * FROM ProDescargasCombustible WHERE IdDescargaCombustible = @IdDescargaCombustible)
		RAISERROR(N'No se pudo eliminar, la descarga de combustible no existe o ya fue eliminada',
			16,
			1
			)

	IF ISNULL((SELECT CanceladoEl FROM ProDescargasCombustible WHERE IdDescargaCombustible = @IdDescargaCombustible), 0) = 0
		RAISERROR(N'No es posible eliminar la descarga de combustible, debe estar previamente cancelada',
			16,
			1
			)

	DELETE FROM ProDescargasCombustible
	WHERE IdDescargaCombustible = @IdDescargaCombustible
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

