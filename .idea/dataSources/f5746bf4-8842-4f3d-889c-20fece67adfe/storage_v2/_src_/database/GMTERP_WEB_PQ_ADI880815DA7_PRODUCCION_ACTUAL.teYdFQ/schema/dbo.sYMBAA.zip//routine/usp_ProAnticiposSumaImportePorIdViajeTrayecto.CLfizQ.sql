
CREATE PROCEDURE [dbo].[usp_ProAnticiposSumaImportePorIdViajeTrayecto]
	@IdUsuario int,
	@IdViajeTrayecto int
AS
DECLARE @Importe money

SET @Importe = (SELECT ISNULL(SUM(Importe),0) AS Importe FROM ProAnticipos WHERE IdViajeTrayecto = @IdViajeTrayecto)

IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'SumaImportesAnticipos' AND IdUsuario = IdUsuario)
INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('SumaImportesAnticipos',@Importe,@IdUsuario)
ELSE
UPDATE SisParametrosPagina SET Parametros = @Importe WHERE Pagina = 'SumaImportesAnticipos' AND IdUsuario = @IdUsuario
go

