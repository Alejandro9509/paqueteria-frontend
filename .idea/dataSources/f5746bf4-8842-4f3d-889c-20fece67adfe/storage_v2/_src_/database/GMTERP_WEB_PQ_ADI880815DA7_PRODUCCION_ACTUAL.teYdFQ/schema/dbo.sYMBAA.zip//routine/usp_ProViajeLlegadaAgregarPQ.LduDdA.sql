CREATE PROCEDURE [dbo].[usp_ProViajeLlegadaAgregarPQ](	
	@IdViaje int ,
	
	@CV1Km float ,
	@CV2Km float ,
	@CV1Millas float ,
	@CV2Millas float ,
	@FechaSalida varchar(20) ,
	@HoraSalida varchar(20) ,
	@FechaLlegada date ,
	@HoraLlegada time(7),
	@KmViaje float ,
	@MillasViaje float,
	@Liquidacion float,
	@IdEstatusUnidad int, 
	@IdTipoCambio int,
	@IdEstatusLlegada int,
	@MotivoRetraso varchar(100),
	@PesoDescarga float,
	@IdRuta int

	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @IdGuia int;
		DECLARE @FOLIO int;
		DECLARE @FOLIOSTR varchar(10);		
		DECLARE @TRACKINGSTR varchar(10);
	

		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		

	
	
		/*IF ISNULL(@FechaSalida, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@HoraSalida,'' ) = '' begin
			RAISERROR(N'*INICIO*La hora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
		/*
		IF ISNULL(@IdEstatusSalida, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus de salida un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@KmViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Los kilometros de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@MillasViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Las millas de viaje esun campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		*/
		insert into ProViajeLlegadaPQ(	
		IdViaje ,
		
		CV1Km ,
		CV2Km ,
		CV1Millas ,
		CV2Millas ,
		--HoraSalida,
		FechaLlegada,
		HoraLlegada,
		KmViaje ,
		MillasViaje,
		Liquidacion ,
		IdEstatusUnidad , 
		IdTipoCambio ,
		IdEstatusLlegada,
		MotivoRetraso,
		PesoDescarga, IdRuta)
	values
	(
		@IdViaje ,
	
		@CV1Km ,
		@CV2Km ,
		@CV1Millas ,
		@CV2Millas ,
		--@HoraSalida,
		@FechaLlegada ,
		@HoraLlegada,
		@KmViaje ,
		@MillasViaje,
		@Liquidacion ,
		@IdEstatusUnidad , 
		@IdTipoCambio ,
		@IdEstatusLlegada,
		@MotivoRetraso,
		@PesoDescarga,
		@IdRuta
	);

	update ProInventarioUnidades set
		IdEstatuUnidad = 4 --Asignada
	where IdUnidad = (select pv.IdUnidad from ProViajesPQ pv where pv.IdViaje = @IdViaje)

		IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

