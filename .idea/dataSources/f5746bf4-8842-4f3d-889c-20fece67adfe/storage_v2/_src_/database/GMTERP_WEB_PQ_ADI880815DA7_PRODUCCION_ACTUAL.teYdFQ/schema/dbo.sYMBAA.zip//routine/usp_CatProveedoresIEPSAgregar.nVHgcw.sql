CREATE PROCEDURE [dbo].[usp_CatProveedoresIEPSAgregar]
@IdProveedor int,
@Anio int,
@Enero decimal(15,6),
@Febrero decimal(15,6),
@Marzo decimal(15,6), 
@Abril decimal(15,6), 
@Mayo decimal(15,6),
@Junio decimal(15,6), 
@Julio decimal(15,6), 
@Agosto decimal(15,6), 
@Septiembre decimal(15,6),
@Octubre decimal(15,6), 
@Noviembre decimal(15,6), 
@Diciembre decimal(15,6), 
@CreadoEl    datetime,    
@CreadoPor    int,    
@IdPeticion varchar(100),
@IdCombustible int 
AS
DECLARE @Folio int
BEGIN TRY
    BEGIN TRANSACTION
    IF ISNULL(@IdProveedor,0)= 0
        RAISERROR(N'Identificador de proveedor es un campo requerido',
            16,
            1
            )

    IF ISNULL(@Anio,0)= 0
        RAISERROR(N'El año es un campo requerido',
            16,
            1
            )
    
    SET @Folio = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM CatProveedoresIEPS)
    IF @IdCombustible =0 
       SET @IdCombustible = NULL
       
    INSERT INTO CatProveedoresIEPS
        (Folio,IdProveedor,Anio,Enero,Febrero,Marzo, Abril, Mayo,Junio, Julio, Agosto, Septiembre,Octubre, 
         Noviembre, Diciembre, CreadoEl,CreadoPor,IdCombustible)
        VALUES
        (@Folio,@IdProveedor,@Anio,@Enero,@Febrero,@Marzo,@Abril,@Mayo,@Junio,@Julio, @Agosto,@Septiembre,
         @Octubre,@Noviembre,@Diciembre,@CreadoEl,@CreadoPor,@IdCombustible)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

