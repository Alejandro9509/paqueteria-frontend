CREATE PROCEDURE [dbo].[usp_ProNominasDiasHorasRegistrar]
	@IdPeticion VARCHAR(100),		--(entrada, texto). Id de la Petición, generada en WEBDEV. 
	@IdEmpleado INT,				--(entrada, entero). Id del empleado.
	@xmlIncedenciaValor NTEXT,    --	@IdIncidencia INT,--	@Valor DECIMAL(15,2), 	@IdProNominaDiaHora int,@Estado VARCHAR(40),
									--(entrada, texto). Contiene todas las incidencias del empleado.
	@Fecha DATE,					--(entrada, fecha). Contiene la fecha de Inicio de las incidencias.
	@ModificadoPor INT,				--(entrada, entero). La clave del usuario que realizo la modificacion.
	@ModificadoEl DATETIME,			--(entrada, fecha). Fecha cuando se agrego/modifico la incidencia.
	@TipoIncidencia INT,			--(entrada, entero). Indica si la incidencia es por Dia/Hora/Destajo.
	@IdPeriodo INT					--(entrada, entero). Contiene la clave del periodo que ocurrio la incidencia.

 
/* *************************************************************************************************
Descripción: El procedimiento genera/actualiza las incidencias del empleado durante el periodo.

28/01/2020   Se modifico la funcionalidad para permitir que se agregaran incidencias en un periodo(s) cerrado(s),
con las condicionantes que no estuvieran cerrrados y/o Reicbo de nomina timbrado .

Implementada por: N/A
Fecha de implementacion: N/A
Versión ERP: N/A

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 20/01/2020
Versión ERP: 8.0.49.16

Invocada desde: PAGE_ProNominasDiasHorasIncapacidadesAM (Solicitud 762)
***************************************************************************************************** */


AS
DECLARE 
	@HorasTurno DECIMAL(15,2),			--(entrada, decimal). Obtiene las horas que corresponden a cada dia del turno
	@HorasAcumuladas DECIMAL(15,2),		--(entrada, decimal). Obtiene las horas acumuladas al momento de las incidencias.
	@docHandle INT,						
	@IdTipoIncidenciaCursor INT,		--(entrada, entero).  Obtiene la clave de la incidencia
	@ValorCursor DECIMAL(15,2),			--(entrada, decimal). Obtiene la cantidad horas/dias de la incidencia  	
	@ValorCursorDias INT,				--(entrada, entero).  Se asigna la cantidad de horas/dias para comparacion del contador de las incidencias
	@IdNominaDiaHoraCursor INT,			--(entrada, entero).  obtiene el IdNominaDiaHora de la tabla (para modificacion/agregar)
	@EstadoCursor VARCHAR(40),			--(entrada, texto).   Estatus de la incidencia
	@ContadorDias INT,					--(entrada, entero).  Obtiene el valor del contador al momento de la incidencia
	@SeguirAgregando BIT,				--(entrada, boolean). Determina si continua/detiene el proceso de las incidencias.
	@IdPeriodoActual INT,				--(entrada, entero).  Obtiene el idPeriodo segun el dia de insercion/modificado de la incidencia
	@CadenaHorasTurno VARCHAR(10),		--(entrada, texto).   Se utiliza para conversion de valores al mandar un mensaje. 
	@PeriodoActual INT,					--(entrada, entero).  Se utiliza para verificar si el periodo esta cerrado/abierto y/o el recibo sin timbrar.
	@IdTipoPeriodo INT					--(entrada, entero).  Se obtiene la claver del Tipo de periodo que tiene el empleado

BEGIN TRY
	BEGIN TRANSACTION
	IF @IdPeriodoActual = 0
		RAISERROR(N'El periodo es un campo requerido',
			16,
			1
			)
		SET @ContadorDias = 0
		SET @SeguirAgregando = 1
		SET @HorasAcumuladas = 0
		IF @TipoIncidencia <> 0 
		BEGIN
			
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlIncedenciaValor
			
			SELECT Valor,IdTipoIncidencia,IdNominaDiaHora,Estado
			INTO #TempProNominasDiasHoras
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_MovimientosIncidencias',2) 
			WITH (Valor DECIMAL(15,2),IdTipoIncidencia INT,IdNominaDiaHora INT,Estado VARCHAR (40))

			EXEC sp_xml_removedocument @docHandle
			
			DECLARE ProNominasDiasHorasCursor CURSOR FOR
			SELECT * FROM #TempProNominasDiasHoras
			OPEN ProNominasDiasHorasCursor
			FETCH NEXT FROM ProNominasDiasHorasCursor
			INTO @ValorCursor,@IdTipoIncidenciaCursor,@IdNominaDiaHoraCursor,@EstadoCursor
			WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @TipoIncidencia = 1 --Dias 
				BEGIN 
				SET @ValorCursorDias = @ValorCursor
					WHILE @ContadorDias < @ValorCursorDias
					BEGIN
						IF  EXISTS(SELECT * FROM ProNominasDiasHoras WHERE Fecha = DATEADD(DAY,@ContadorDias,@Fecha) AND IdEmpleado = @IdEmpleado) AND @ContadorDias >0
						BEGIN 
							SET @SeguirAgregando = 0
						END
						IF  @SeguirAgregando = 1
						BEGIN				
							SET @IdPeriodoActual = (SELECT ISNULL(cp.IdPeriodo,-1) FROM CatPeriodos AS cp 
							INNER JOIN CatEmpleados AS ce on cp.IdTipoPeriodo = ce.IdTipoPeriodo
							LEFT JOIN ProNominasRecibo pnr ON pnr.IdEmpleado = ce.IdEmpleado AND pnr.IdPeriodo = cp.IdPeriodo
							LEFT JOIN ProNominasReciboCancelacion pnrc ON pnrc.IdNominaRecibo = pnr.IdNominaRecibo
							WHERE cp.FechaInicio <= DATEADD(DAY,@ContadorDias,@Fecha) AND cp.FechaFin >= DATEADD(DAY,@ContadorDias,@Fecha) AND ce.IdEmpleado = @IdEmpleado
							AND  ((DATEADD(DAY,@ContadorDias,@Fecha) >= cp.FechaInicio AND DATEADD(DAY,@ContadorDias,@Fecha) <= cp.FechaFin AND cp.CerradoEl IS NULL ) OR
							(DATEADD(DAY,@ContadorDias,@Fecha) >= cp.FechaInicio AND DATEADD(DAY,@ContadorDias,@Fecha) <= cp.FechaFin AND cp.CerradoEl IS NOT NULL AND 
							 convert(varchar,pnrc.FechaCancelacionSAT) <> '00000000000000000'))  )
							--SOLICITUD 762 agregar incidencias cuando se haya cancelado el timbrado
							 IF @IdPeriodoActual = -1 OR ISNULL(@IdPeriodoActual,0)=0
							    BEGIN
								  RAISERROR(N'No se puede generar incidencia debido a que el timbrado del recibo de nómina no esta cancelado',
								  16,
							 	  1
								  )
								END
							IF @IdPeriodoActual <> -1 
							BEGIN
								IF @IdNominaDiaHoraCursor = 0 OR @ContadorDias > 0
								BEGIN
									IF  EXISTS(SELECT * FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado) AND @ContadorDias =0
									BEGIN 
										DELETE FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado
									END 
									INSERT INTO ProNominasDiasHoras (IdEmpleado,IdPeriodo,IdTipoIncidencia,Fecha,Valor,Estado,CreadoPor,CreadoEl) 
									VALUES(@IdEmpleado,@IdPeriodoActual,@IdTipoIncidenciaCursor,DATEADD(DAY,@ContadorDias,@Fecha),1,@EstadoCursor,@ModificadoPor,@ModificadoEl)
								END
								ELSE
								BEGIN
									UPDATE ProNominasDiasHoras 
									SET	
									IdTipoIncidencia = @IdTipoIncidenciaCursor,
									Estado = @EstadoCursor,
									ModificadoPor = @ModificadoPor,
									ModificadoEl = @ModificadoEl
									WHERE IdNominaDiaHora = @IdNominaDiaHoraCursor  
								END
							END
						END
					SET @ContadorDias = @ContadorDias + 1
					END
				END
				ELSE IF @TipoIncidencia = 2 --Horas
				BEGIN 
					SET @HorasAcumuladas = @HorasAcumuladas + @ValorCursor
					SET @HorasTurno = (SELECT ISNULL(ct.Horas,0) FROM CatEmpleados AS ce INNER JOIN CatTurnos AS ct ON ce.IdTurno = ct.IdTurno WHERE ce.IdEmpleado = @IdEmpleado)
					IF @HorasAcumuladas <=  @HorasTurno
					BEGIN
						IF @IdNominaDiaHoraCursor <> 0 
						BEGIN
							UPDATE ProNominasDiasHoras 
							SET	IdTipoIncidencia = @IdTipoIncidenciaCursor,
							Valor = @ValorCursor,
							Estado = @EstadoCursor,
							ModificadoPor = @ModificadoPor,
							ModificadoEl = @ModificadoEl
							WHERE IdNominaDiaHora = @IdNominaDiaHoraCursor 
						END
						ELSE
						BEGIN
							
							SET @IdPeriodoActual = (SELECT ISNULL(IdPeriodo,-1) FROM CatPeriodos AS cp 
							INNER JOIN CatEmpleados AS ce on cp.IdTipoPeriodo = ce.IdTipoPeriodo
							WHERE cp.FechaInicio <= @Fecha AND cp.FechaFin >= @Fecha AND ce.IdEmpleado = @IdEmpleado )
							
							INSERT INTO ProNominasDiasHoras (IdEmpleado,IdPeriodo,IdTipoIncidencia,Fecha,Valor,Estado,CreadoPor,CreadoEl) 
							VALUES(@IdEmpleado,@IdPeriodoActual,@IdTipoIncidenciaCursor,@Fecha,@ValorCursor,@EstadoCursor,@ModificadoPor,@ModificadoEl)					
						END
					END
					ELSE 
					BEGIN
						SET @CadenaHorasTurno = convert(varchar, @HorasTurno)
						RAISERROR(N'El Total de Horas del Turno del Empleado son de %s Horas.',
						16,
						1,
						@CadenaHorasTurno
						)
					END
				END
				ELSE -- Destajos
				BEGIN  
					SET @HorasAcumuladas = @HorasAcumuladas + @ValorCursor
					IF 24 >= @HorasAcumuladas  		
					BEGIN
						IF @IdNominaDiaHoraCursor <> 0 
						BEGIN
							UPDATE ProNominasDiasHoras 
							SET	IdTipoIncidencia = @IdTipoIncidenciaCursor,
							Valor = @ValorCursor,	
							Estado = @EstadoCursor,
							ModificadoPor = @ModificadoPor,
							ModificadoEl = @ModificadoEl
							WHERE IdNominaDiaHora = @IdNominaDiaHoraCursor  
						END
						ELSE
						BEGIN
							SET @IdPeriodoActual = (SELECT ISNULL(IdPeriodo,-1) FROM CatPeriodos AS cp 
							INNER JOIN CatEmpleados AS ce on cp.IdTipoPeriodo = ce.IdTipoPeriodo
							WHERE cp.FechaInicio <= @Fecha AND cp.FechaFin >= @Fecha AND ce.IdEmpleado = @IdEmpleado )
							INSERT INTO ProNominasDiasHoras (IdEmpleado,IdPeriodo,IdTipoIncidencia,Fecha,Valor,Estado,CreadoPor,CreadoEl) 
							VALUES(@IdEmpleado,@IdPeriodoActual,@IdTipoIncidenciaCursor,@Fecha,@ValorCursor,@EstadoCursor,@ModificadoPor,@ModificadoEl)					
						END
					END
					ELSE 
					BEGIN
						RAISERROR(N'Sobrepaso las Horas de las Incidencias Tipo Destajo que son 24 horas.',
						16,
						1
						)
					END					
				END
				FETCH NEXT FROM ProNominasDiasHorasCursor
				INTO @ValorCursor,@IdTipoIncidenciaCursor,@IdNominaDiaHoraCursor,@EstadoCursor
			END
			CLOSE ProNominasDiasHorasCursor
			DEALLOCATE ProNominasDiasHorasCursor
			--Se  Borran todas aquellas incidencias que no se agregaron o modificaron por fecha y empleado
			IF @TipoIncidencia = 2 OR @TipoIncidencia = 3
			BEGIN
				DELETE FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
			END
		END
		ELSE
		BEGIN
			DELETE FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		END

		UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

