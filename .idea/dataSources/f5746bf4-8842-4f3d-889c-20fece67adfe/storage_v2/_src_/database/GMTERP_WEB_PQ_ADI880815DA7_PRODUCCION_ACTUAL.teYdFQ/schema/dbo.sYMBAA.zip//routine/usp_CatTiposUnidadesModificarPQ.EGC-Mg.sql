
CREATE PROCEDURE [dbo].[usp_CatTiposUnidadesModificarPQ](
	@IdTipoUnidad int,
	@TipoUnidad varchar(50),
	@ModificadoEl datetime,
	@ModificadoPor int,
	@TarifaPorKMS Money,
	@TarifaPorKMSDlls Money)

	AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdTipoUnidad,0) <= 0 begin
		RAISERROR(N'*INICIO*El identificador de tipo de unidad es un campo requerido*FIN*', 16, 1)
		return
	end
	
		IF ISNULL(@TipoUnidad, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre del tipo de unidad es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@TarifaPorKMS, '') = '' begin
			RAISERROR(N'*INICIO*Trifa por kms sistema es un campo requerido*FIN*', 16, 1)
			return
		end
		IF ISNULL(@TarifaPorKMSDlls , '') = '' begin
			RAISERROR(N'*INICIO*Tarifa por kms en dolares es un campo requerido*FIN*', 16, 1)
			return
		end
		UPDATE CatTiposUnidades SET
		TipoUnidad=@TipoUnidad,
		ModificadoEl=@ModificadoEl ,
		ModificadoPor=@ModificadoPor ,
		TarifaPorKMS=@TarifaPorKMS ,
		TarifaPorKMSDlls=@TarifaPorKMSDlls
		WHERE IdTipoUnidad = @IdTipoUnidad

	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

