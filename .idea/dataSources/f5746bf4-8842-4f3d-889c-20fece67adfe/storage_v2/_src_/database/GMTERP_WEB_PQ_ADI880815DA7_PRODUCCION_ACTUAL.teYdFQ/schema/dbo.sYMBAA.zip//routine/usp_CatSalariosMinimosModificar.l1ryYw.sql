
CREATE PROCEDURE [dbo].[usp_CatSalariosMinimosModificar]
@IdSalarioMinimo int,
@Ejercicio datetime,
@SalarioMinimo decimal (15,4),
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdSalarioMinimo,0)= 0
	RAISERROR(N'El identificador del Salario Minimo es un campo requerido',
			16,
			1
			)
			
	  --Validar si el ejercicio ya está registrado 
		IF EXISTS(Select * FROM CatSalariosMinimos where YEAR(Ejercicio) = YEAR(@Ejercicio) AND IdSalarioMinimo <> @IdSalarioMinimo)
	RAISERROR(N'No se permiten registros con el ejercicio duplicado',
			16,
			1
			)		
			
	UPDATE CatSalariosMinimos SET
	Ejercicio = @Ejercicio,
	SalarioMinimo = @SalarioMinimo,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor
	WHERE IdSalarioMinimo = @IdSalarioMinimo 

  COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

