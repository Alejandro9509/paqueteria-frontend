CREATE PROCEDURE [dbo].[usp_CatRutasTrayectosAgregar]
	@IdRuta int,
	@IdOrigen int,
	@IdDestino int,	
	@Kilometros int,
	@Horas decimal(15,2),
	@RutaGoogleMap ntext,
	@IdGeocercaDisparaSalida int,
	@GeocercaDisparaSalidaES tinyint,
	@IdGeocercaDisparaLlegada int,
	@GeocercaDisparaLlegadaES tinyint,
	@IdEstatuViajeSalida int,
	@IdEstatuViajeLlegada int,
	@SueldoBaseSencilloCargado money,
	@SueldoBaseSencilloVacio money,
	@SueldoBaseFullCargado money,
	@SueldoBaseFullVacio money,
	@SueldoBaseFullVacioCargado_CargadoVacio money,	
	@dsCatRutasTrayectosGeocercas ntext,
	@dsCatRutasTrayectosGastos ntext,
	@CreadoPor int,
	@CreadoEl datetime,	
	@IdPeticion varchar(100),
	@SueldoBaseDllsSencilloCargado money,
	@SueldoBaseDllsSencilloVacio money,
	@SueldoBaseDllsFullCargado money,
	@SueldoBaseDllsFullVacio money,
	@SueldoBaseDllsFullVacioCargado_CargadoVacio money,	
	@FactorLiqKmsSencilloCargado decimal(15,2),
	@FactorLiqKmsSencilloVacio decimal(15,2), 
	@FactorLiqKmsFullCargado decimal(15,2),
	@FactorLiqKmsFullVacio decimal(15,2),
	@FactorLiqKmsFullVacioCargado_CargadoVacio decimal(15,2),
	@FactorLiqKmsDllsSencilloCargado decimal(15, 2),
	@FactorLiqKmsDllsSencilloVacio decimal(15, 2),
	@FactorLiqKmsDllsFullCargado decimal(15, 2),
	@FactorLiqKmsDllsFullVacio decimal(15, 2),
	@FactorLiqKmsDllsFullVacioCargado_CargadoVacio decimal(15, 2),
	@TipoTrayecto TINYINT,
	@Millas decimal(15,2),
	@ETA decimal(15,2)

/*************************************************************************************************************************************
Procedimiento almacenado usp_ProViajesTrayectosAgregar

Parámetros: 
 @IdRuta int,
	@IdOrigen int,
	@IdDestino int,	
	@Kilometros int,
	@Horas decimal(15,2),
	@RutaGoogleMap ntext,
	@IdGeocercaDisparaSalida int,
	@GeocercaDisparaSalidaES tinyint,
	@IdGeocercaDisparaLlegada int,
	@GeocercaDisparaLlegadaES tinyint,
	@IdEstatuViajeSalida int,
	@IdEstatuViajeLlegada int,
	@SueldoBaseSencilloCargado money,
	@SueldoBaseSencilloVacio money,
	@SueldoBaseFullCargado money,
	@SueldoBaseFullVacio money,
	@SueldoBaseFullVacioCargado_CargadoVacio money,	
	@dsCatRutasTrayectosGeocercas ntext,
	@dsCatRutasTrayectosGastos ntext,
	@CreadoPor int,
	@CreadoEl datetime,	
	@IdPeticion varchar(100),
	@SueldoBaseDllsSencilloCargado money,
	@SueldoBaseDllsSencilloVacio money,
	@SueldoBaseDllsFullCargado money,
	@SueldoBaseDllsFullVacio money,
	@SueldoBaseDllsFullVacioCargado_CargadoVacio money,	
	@FactorLiqKmsSencilloCargado decimal(15,2),
	@FactorLiqKmsSencilloVacio decimal(15,2), 
	@FactorLiqKmsFullCargado decimal(15,2),
	@FactorLiqKmsFullVacio decimal(15,2),
	@FactorLiqKmsFullVacioCargado_CargadoVacio decimal(15,2),
	@FactorLiqKmsDllsSencilloCargado decimal(15, 2),
	@FactorLiqKmsDllsSencilloVacio decimal(15, 2),
	@FactorLiqKmsDllsFullCargado decimal(15, 2),
	@FactorLiqKmsDllsFullVacio decimal(15, 2),
	@FactorLiqKmsDllsFullVacioCargado_CargadoVacio decimal(15, 2),
	@TipoTrayecto TINYINT,
	@Millas decimal(15,2),
	@ETA decimal(15,2)

Descripción: Agrega Trayectos a las Rutas de viaje 

Modificada por:   Diego Arturo Rubio Meza
Fecha de modificación: 24/07/2019
Versión: V8 8.0.44.50
Descripción: Se agrego la validacion para que no te deje agregar mas de 999 Trayectos

Invocada desde: ClsCatRutas
    Solicitud 12236
******************************************************************************************************************* */

AS
DECLARE
	@docHandle int,
	@KilometrosTotales int,
	@HorasTotales decimal(15,2),
	@IdRutaTrayecto int ,
	@Secuencia int,
	@MillasTotales decimal(15,2),
	@ETATotal decimal(15,2)
BEGIN TRY
	BEGIN TRANSACTION

		IF @IdRuta = 0
			RAISERROR(N'El identificador de la ruta es un campo requerido',
				16,
				1
				)	

		IF @IdOrigen = 0
			RAISERROR(N'El origen de la ruta/trayecto es un campo requerido',
				16,
				1
				)	

		IF @IdDestino = 0
			RAISERROR(N'El destino de la ruta/trayecto es un campo requerido',
				16,
				1
				)	

		IF @IdEstatuViajeSalida = 0
			SET @IdEstatuViajeSalida = NULL

		IF @IdEstatuViajeLlegada = 0
			SET @IdEstatuViajeLlegada = NULL
		
		IF ISNULL(@Kilometros,0) <= 0	
		RAISERROR(N'El kilometraje del trayecto es un campo requerido',
			16,
			1
			)
				
		IF ISNULL(@Horas,0) <= 0	
		RAISERROR(N'Las horas para el trayecto es un campo requerido',
			16,
			1
			)
			
		SET @Secuencia = (SELECT ISNULL(MAX(Secuencia),0)+1 FROM CatRutasTrayectos WHERE IdRuta = @IdRuta)	

		IF @Secuencia > 999
		BEGIN
		RAISERROR(N'No es posible agregar más de 999 trayectos en un viaje, favor de eliminar los trayectos que no estén en uso para continuar.',
					16,
					1)
		END

		INSERT INTO CatRutasTrayectos(CreadoEl,CreadoPor,Horas,IdDestino,IdOrigen,IdRuta,Kilometros,RutaGoogleMap,Secuencia,
		SueldoBaseSencilloCargado,SueldoBaseSencilloVacio,SueldoBaseFullCargado,
		SueldoBaseFullVacio,SueldoBaseFullVacioCargado_CargadoVacio,
		IdGeocercaDisparaSalida,GeocercaDisparaSalidaES,IdGeocercaDisparaLlegada,GeocercaDisparaLlegadaES,IdEstatuViajeSalida,
		IdEstatuViajeLlegada,
		SueldoBaseDllsSencilloCargado,SueldoBaseDllsSencilloVacio,SueldoBaseDllsFullCargado,SueldoBaseDllsFullVacio,SueldoBaseDllsFullVacioCargado_CargadoVacio,	
		FactorLiqKmsSencilloCargado,FactorLiqKmsSencilloVacio,FactorLiqKmsFullCargado,FactorLiqKmsFullVacio,FactorLiqKmsFullVacioCargado_CargadoVacio,
		FactorLiqKmsDllsSencilloCargado,FactorLiqKmsDllsSencilloVacio,FactorLiqKmsDllsFullCargado,FactorLiqKmsDllsFullVacio,FactorLiqKmsDllsFullVacioCargado_CargadoVacio,
		TipoTrayecto,Millas,ETA)
		VALUES(@CreadoEl,@CreadoPor,@Horas,@IdDestino,@IdOrigen,@IdRuta,@Kilometros,@RutaGoogleMap,@Secuencia,
		@SueldoBaseSencilloCargado,@SueldoBaseSencilloVacio,@SueldoBaseFullCargado,
		@SueldoBaseFullVacio,@SueldoBaseFullVacioCargado_CargadoVacio,
		@IdGeocercaDisparaSalida,@GeocercaDisparaSalidaES,@IdGeocercaDisparaLlegada,@GeocercaDisparaLlegadaES,@IdEstatuViajeSalida,
		@IdEstatuViajeLlegada,
		@SueldoBaseDllsSencilloCargado,@SueldoBaseDllsSencilloVacio,@SueldoBaseDllsFullCargado,@SueldoBaseDllsFullVacio,@SueldoBaseDllsFullVacioCargado_CargadoVacio,					
		@FactorLiqKmsSencilloCargado,@FactorLiqKmsSencilloVacio,@FactorLiqKmsFullCargado,@FactorLiqKmsFullVacio,@FactorLiqKmsFullVacioCargado_CargadoVacio,
		@FactorLiqKmsDllsSencilloCargado,@FactorLiqKmsDllsSencilloVacio,@FactorLiqKmsDllsFullCargado,@FactorLiqKmsDllsFullVacio,@FactorLiqKmsDllsFullVacioCargado_CargadoVacio,
		@TipoTrayecto,@Millas,@ETA)
		
		SET @IdRutaTrayecto = (SELECT IDENT_CURRENT('CatRutasTrayectos'))
		
		--SECCION PARA AGREGAR LAS GEOCERCAS/ESTATUS AUTOMATICOS
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectosGeocercas

		SELECT COL_IdEstatuViajeEntrar,COL_IdEstatuViajeSalir,COL_IdGeocerca
		INTO #TempCatRutasTrayectosGeocercas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosGeocercas',2) 
		WITH(COL_IdEstatuViajeEntrar int,COL_IdEstatuViajeSalir int,COL_IdGeocerca int)
    
		EXEC sp_xml_removedocument @docHandle
			
		INSERT INTO CatRutasTrayectosGeocercas(IdRutaTrayecto,IdEstatuViajeEntrada,IdEstatuViajeSalida,IdGeocerca,CreadoEl,CreadoPor)
		SELECT @IdRutaTrayecto,
		CASE COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE COL_IdEstatuViajeEntrar END,
		CASE COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE COL_IdEstatuViajeSalir END,
		COL_IdGeocerca,@CreadoEl,@CreadoPor
		FROM #TempCatRutasTrayectosGeocercas
		
		--SECCION PARA AGREGAR LOS GASTOS AUTORIZADOS
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectosGastos
		
		SELECT ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_LitrosAutorizados,ATT_ImporteAutorizadoState,ATT_LitrosAutorizadosState,ATT_GalonesAutorizados
		INTO #TempCatRutasTrayectosGastos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosGastos',2) 
		WITH(ATT_IdConceptoGastoViaje int,ATT_ImporteAutorizado money,ATT_LitrosAutorizados decimal(15,2),ATT_ImporteAutorizadoState int,ATT_LitrosAutorizadosState int,ATT_GalonesAutorizados decimal(15,2))
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatRutasTrayectosGastos(IdRutaTrayecto,IdConceptoGastoViaje,ImporteAutorizado,ImporteAutorizadoState,LitrosAutorizados,LitrosAutorizadosState,CreadoEl,CreadoPor,GalonesAutorizados)
		SELECT @IdRutaTrayecto,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_ImporteAutorizadoState,ATT_LitrosAutorizados,ATT_LitrosAutorizadosState,@CreadoEl,@CreadoPor,ATT_GalonesAutorizados
		FROM #TempCatRutasTrayectosGastos
				
		SET @KilometrosTotales = ISNULL((SELECT SUM(Kilometros) FROM CatRutasTrayectos WHERE IdRuta = @IdRuta),0)
		SET @HorasTotales = ISNULL((SELECT SUM(Horas) FROM CatRutasTrayectos WHERE IdRuta = @IdRuta),0)
		SET @MillasTotales = ISNULL((SELECT SUM(Millas) FROM CatRutasTrayectos WHERE IdRuta = @IdRuta),0)
		SET @ETATotal = ISNULL((SELECT SUM(ETA) FROM CatRutasTrayectos WHERE IdRuta = @IdRuta),0)
			
		UPDATE CatRutas SET 
			Kilometros = @KilometrosTotales, 
			Horas = @HorasTotales, 
			ModificadoEl = @CreadoEl, 
			ModificadoPor = @CreadoPor,
			Millas = @MillasTotales,
			ETA = @ETATotal
		WHERE IdRuta = @IdRuta
		 
		 IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdRutaTrayecto' AND IdUsuario = @CreadoPor)
			INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdRutaTrayecto',CAST(@IdRutaTrayecto as varchar(10)),@CreadoPor )
		 ELSE
			UPDATE SisParametrosPagina SET Parametros = CAST(@IdRutaTrayecto as varchar(10)) WHERE Pagina = 'IdRutaTrayecto' AND IdUsuario = @CreadoPor

 	COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

