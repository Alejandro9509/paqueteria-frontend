CREATE PROCEDURE [dbo].[usp_CatClientesModificar]
    @IdCliente int,
    @NumeroCliente int,
    @TipoCliente tinyint,
    @RFC varchar(13),
    @NombreFiscal varchar(150),
    @NombreCorto varchar(12),
    @Calle varchar(100),
    @NoExterior varchar(20),
    @NoInterior varchar(20),
    @Colonia varchar(100),
    @Localidad varchar(100),
    @Municipio varchar(100),
    @IdEstado varchar(5),
    @CodigoPostal varchar(10),
    @Telefono varchar(20),
    @Celular varchar(20),
    @Nextel varchar(20),
    @CorreoElectronico varchar(100),
    @MetodoPago varchar(50),
    @NroCuentaPago varchar(50),
    @Activo bit,
    @Credito money,
    @CreditoDLLS money,
    @DiasCredito tinyint,
    @ModificadoPor int,
    @ModificadoEl datetime,
    @UltimaModificacion datetime,
    @IdSucursal int,
    @dsCatClientesContactos ntext,
    @IdPeticion varchar(100),
    @IdMoneda int,
    @IdGrupoCliente int,
    @IdImpuestoTransladado INT,
    @dsFormatos ntext,
    @OperadorLogistico bit,
    @PermitirParoDeMotor BIT,
    @FacturacionPorViajeDetallado bit,
    @PermitirHistorialDeDia bit,
    @IdUsoCFDI varchar(5),
    @NoRegistroIdentidadFiscal varchar(40),
    @PermitirAgruparCantidadPorConcepto bit,
    @ClaveTAR varchar(15),
    @NumeroProveedor varchar(15),
    @DistanciaDistribuidorCliente int,
    @Latitud decimal(24,7),
    @Longitud decimal(24,7),
    @EnvioCorreoDias int,
    @FechaEnvioCorreoApartir varchar(10),
    @InformacionRetransmisionGPS varchar(max)=null, --solicitud 10029 isaac
    --solicitud 010068
    @EnvioAutomaticoSeguimientoViajesActivar bit = 0,
    @EnvioAutomaticoSeguimientoViajesFrecuencia smallint = null,
    @EnvioAutomaticoSeguimientoViajesFechaHoraInicio datetime = null,
    --solicitud 10363 isdejenuhe
    @AjustarImportes2DecimalesXML bit = 0
    --SOLICITUD 010597 
    ,
    @BancoOrdenante varchar(300),
    @RFCBancoOrdenante varchar(13),
    @NoCuentaBancoOrdenante varchar(50),
    @ExcluirNodoCondicionesPagoXML bit,
    @EstatusViajeEDI Varchar(500), -- SOLCITID 220 FRANCISCO VILLELA
    @dsComplementos ntext = NULL, --Sol 396
    @AplicarXMLDetallePorCadaViajeCartaPorte bit = 0, --Solicitud 001935
    @EnviarCorreoSeguimiento bit =0, --SOLICITUD 003350 FRANCISCO VILLELA
    @EnviarCorreoEstatusEDI bit=0, --SOLICITUD 003350 FRANCISCO VILLELA
    @EnviarCorreoReporteFourkites bit=0, --SOLICITUD 003350 FRANCISCO VILLELA
    @EnviarFoukitesFTP_Correo tinyint=NULL,--SOLICITUD 003518 FRANCISCO VILLELA
    @Fourkites_FTPServer varchar(100) = null,--SOLICITUD 003518 FRANCISCO VILLELA
    @Fourkites_FTPUsuario varchar(100) = null,--SOLICITUD 003518 FRANCISCO VILLELA
    @Fourkites_FTPContrasenia varchar(100) = null--SOLICITUD 003518 FRANCISCO VILLELA
    ,@DesglosarDetalleRutaPorConcepto bit = null, -- SOLICITUD 004148
	@PermitirPoleo bit = null
AS
DECLARE
    @docHandle int,
    @docHandle2 int,
    @CursorIdClienteContacto int,           --cursor
    @CursorContacto varchar(90),            --cursor
    @CursorCorreoElectronico varchar(100),  --cursor
    @CursorTelefonos varchar(max),          --cursor
    @CursorRecibirFactura bit,              --cursor
    @CursorRecibirCP bit,                   --cursor
    @CursorRecibirEdoCta bit,               --cursor
    @CursorPermitirVerSeguimiento bit,      --cursor
    @CursorUsuario varchar(8),              --cursor
    @CursorContrasena varchar(8),           --cursor
    @CursorOperadorLogistico bit,           --cursor
    @CursorPortalClientes bit,              --cursor    
    @CusorRecibirReporteFourkites bit,      --cursor
    @CusorMostrarRutaTrayectoSeguimientoviajes bit,     --cursor
    @return_value int,
    @CursorUsoDeServiciosWeb bit,           --Cursor
    @NumeroDeClienteCompara int,
    @RFCCompara varchar(13),
    @NombreFiscalCompara varchar(150),
    @CursorFormatoIdClienteFormato int,     --CursorFormatos
    @CursorFormatoIdFormato int,            --CursorFormatos
    @CursorFormatoMarcado bit,              --CursorFormatos
    @CursorClientesXML varchar(max),
    @CursorMostrarSeguimientoSolicitudes bit,
    @CursorMostrarImportesEnHistoricoViajes bit,
    @CursorSeguimientoRecorrido bit,
    @CursorRecibirCotizador bit,
    @CursorComplementoIdComplemento int, --CURSOR COMPLEMENTOS SOL 386
    @CursorComplementoValor1 varchar(250), --CURSOR COMPLEMENTOS SOL 386
    @CursorComplementoValor2 varchar(250), --CURSOR COMPLEMENTOS SOL 386
    @ComplementosCreadoEl datetime,  --COMPLEMENTOS SOL 386
    @ComplementosCreadoPor int   --COMPLEMENTOS SOL 386

/*
*********************************************************************************************************************************************************************
MODIFICADO:
    Se agrego un nuevo check para ocultar la columna de ruta/trayecto en el portal de seguimiento
MODIFICADA POR:
    EDGAR RAMOS
FECHA DE MODIFICACION:
    2021-02-22
SOLICITUD :
    003910
*********************************************************************************************************************************************************************
MODIFICADO:
    Se cambio el tipo de dato de @CursorTelefonos a varcahr(max) porque ahora contine un xml
MODIFICADA POR:
    Abril CG
FECHA DE MODIFICACIÓN:
    2021-01-20
SOLICITUD: 
    SOLICITUD 003660
*********************************************************************************************************************************************************************
SOLICITUD 003353
Descripcion: se agregan campo EnviarCorreoSeguimiento,EnviarCorreoEstatusEDI,EnviarCorreoReporteFourkites Para gragar confiruacion que servira en procesos especiales
al momento de enviar los correo de seg, estatus edi.
Modificada por: FRANCISCO VILLELA
Fecha de mofidicacion: 12/11/2020
*********************************************************************************************************************************************************************
MODIFICADO:
    Se agrego la columna DesglosarDetalleRutaPorConcepto
MODIFICADA POR:
    Abril CG
FECHA DE MODIFICACIÓN:
    2021-05-03
SOLICITUD: 
    SOLICITUD 004148


Invocada desde: <PAGE_CatClietesAM  / ClsCatClientes / Modificar() >
*/

BEGIN TRY
    BEGIN TRANSACTION
    
    IF @IdCliente = 0
        RAISERROR(N'El identificador del cliente es un campo requerido',
            16,
            1
            )
            
    IF NOT EXISTS(SELECT IdCliente FROM CatClientes WHERE IdCliente = @IdCliente)
        RAISERROR(N'Este registro fue eliminado por otro usuario',
            16,
            1
            )   

    IF (SELECT ModificadoEl FROM CatClientes WHERE IdCliente = @IdCliente) <> @UltimaModificacion
        RAISERROR(N'Los datos de este cliente fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
            16,
            1
            )                   

    IF @NumeroCliente = 0
        RAISERROR(N'El numero de cliente es un campo requerido',
            16,
            1
            )

    IF EXISTS(SELECT NumeroCliente FROM CatClientes WHERE NumeroCliente = @NumeroCliente AND IdCliente <> @IdCliente)
        RAISERROR(N'El numero de cliente ya existe',
            16,
            1
            )   
            
    IF @TipoCliente = 0
        RAISERROR(N'El tipo de cliente es un campo requerido',
            16,
            1
            )

    IF LTRIM(RTRIM(@RFC)) = ''
        RAISERROR(N'El RFC es un campo requerido',
            16,
            1
            )

    IF LTRIM(RTRIM(@NombreFiscal)) = ''
        RAISERROR(N'El nombre es un campo requerido',
            16,
            1
            )

    IF LTRIM(RTRIM(@Calle)) = ''
        RAISERROR(N'La calle es un campo requerido',
            16,
            1
            )

    IF LTRIM(RTRIM(@Municipio)) = ''
        RAISERROR(N'El municipio es un campo requerido',
            16,
            1
            )       
            
    IF LTRIM(RTRIM(@IdEstado)) = ''
        RAISERROR(N'El estado es un campo requerido',
            16,
            1
            )

    IF LTRIM(RTRIM(@CodigoPostal)) = ''
        RAISERROR(N'El código postal es un campo requerido',
            16,
            1
            )
            
    IF LTRIM(RTRIM(@NroCuentaPago)) <> '' and LEN(LTRIM(RTRIM(@NroCuentaPago))) < 4
        RAISERROR(N'El numero de cuenta de pago debe tener al menos 4 caracteres',
            16,
            1
            )           
            
    IF @IdSucursal = 0 
        RAISERROR(N'La sucursal es un campo requerido',
            16,
            1
            )

    IF @IdMoneda = 0 
        RAISERROR(N'La moneda es un campo requerido',
            16,
            1
            )           

    IF @IdGrupoCliente = 0
    SET  @IdGrupoCliente = NULL

    IF @FechaEnvioCorreoApartir = ''
    SET  @FechaEnvioCorreoApartir = NULL
    
    Set @RFCCompara=(SELECT RFC FROM CatClientes WHERE IdCliente = @IdCliente)
    Set @NombreFiscalCompara = (SELECT NombreFiscal FROM CatClientes WHERE IdCliente = @IdCliente)
    
    IF EXISTS(SELECT TOP 1 IdCliente FROM ProFacturas WHERE IdCliente = @IdCliente)    
    OR EXISTS(SELECT TOP 1 IdCliente FROM ProViajes WHERE IdCliente = @IdCliente)
    BEGIN
        IF (@RFCCompara <> @RFC) OR (@NombreFiscalCompara <> @NombreFiscal)
        RAISERROR(N'El RFC ó Nombre Fiscal no puede modificarse porque tiene documentos fiscales asignados',
            16,
            1
            )     
    END
    
    SET @NumeroDeClienteCompara = (SELECT NumeroCliente FROM CatClientes WHERE IdCliente = @IdCliente)
    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
        IF EXISTS(SELECT * FROM CatCuentasContables WHERE CatalogoLigado = 'CatClientes' AND IdCatalogoLigado = @IdCliente)
        AND (@NumeroDeClienteCompara <> @NumeroCliente)
        RAISERROR(N'El número de cliente no puede modificarse porque tiene ligada cuentas contables',
            16,
            1
            )        
    END 

    --INICIA SOLICITUD 010068
    IF ISNULL(@EnvioAutomaticoSeguimientoViajesActivar,0) = 1
    BEGIN
        IF ISDATE(@EnvioAutomaticoSeguimientoViajesFechaHoraInicio) = 0
            RAISERROR(N'Es necesario definir una fecha de inicio para el envío automático de seguimiento de viajes',
            16,
            1
            )

        IF ISNULL(@EnvioAutomaticoSeguimientoViajesFrecuencia,0) < 15 OR ISNULL(@EnvioAutomaticoSeguimientoViajesFrecuencia,0) > 1440
            RAISERROR(N'La frecuencia para el envío automático de seguimiento de viajes debe estar entre 30min y 24hrs',
            16,
            1
            )
    END
    ELSE
    BEGIN
        SET @EnvioAutomaticoSeguimientoViajesFechaHoraInicio = NULL
        SET @EnvioAutomaticoSeguimientoViajesFrecuencia = NULL
    END
    --FIN SOLICITUD 010068 
    
    UPDATE CatClientes SET
        NumeroCliente = @NumeroCliente,
        TipoCliente = @TipoCliente,
        RFC = @RFC,
        NombreFiscal = @NombreFiscal,
        NombreCorto = @NombreCorto,
        Calle = @Calle,
        NoExterior = @NoExterior,
        NoInterior = @NoInterior,
        Colonia = @Colonia,
        Localidad = @Localidad,
        Municipio = @Municipio,
        IdEstado = @IdEstado,
        CodigoPostal = @CodigoPostal,
        Telefono = @Telefono,
        Celular = @Celular,
        Nextel = @Nextel,
        CorreoElectronico = @CorreoElectronico,
        MetodoPago = @MetodoPago,
        NroCuentaPago = @NroCuentaPago,
        Activo = @Activo,
        Credito = @Credito,
        CreditoDLLS = @CreditoDLLS,
        DiasCredito = @DiasCredito,
        ModificadoPor = @ModificadoPor,
        ModificadoEl = @ModificadoEl,
        IdSucursal = @IdSucursal,
        IdMoneda = @IdMoneda,
        IdGrupoCliente = @IdGrupoCliente,
        IdImpuestoTransladado = @IdImpuestoTransladado,
        OperadorLogistico = @OperadorLogistico,
        PermitirParoDeMotor = @PermitirParoDeMotor,
        FacturacionPorViajeDetallado = @FacturacionPorViajeDetallado,
        PermitirHistorialDeDia = @PermitirHistorialDeDia,
        IdUsoCFDI = @IdUsoCFDI,
        NoRegistroIdentidadFiscal = @NoRegistroIdentidadFiscal,
        PermitirAgruparCantidadPorConcepto = @PermitirAgruparCantidadPorConcepto,
        ClaveTAR = @ClaveTAR,
        NumeroProveedor = @NumeroProveedor,
        DistanciaDistribuidorCliente = @DistanciaDistribuidorCliente,
        Latitud = @Latitud,
        Longitud = @Longitud,
        EnvioCorreoDias = @EnvioCorreoDias,
        FechaEnvioCorreoApartir = @FechaEnvioCorreoApartir,
        InformacionRetransmisionGPS = @InformacionRetransmisionGPS,  --solicitud 10029 isaac
        EnvioAutomaticoSeguimientoViajesActivar = @EnvioAutomaticoSeguimientoViajesActivar, --sol 010068
        EnvioAutomaticoSeguimientoViajesFechaHoraInicio = @EnvioAutomaticoSeguimientoViajesFechaHoraInicio, --sol 010068
        EnvioAutomaticoSeguimientoViajesFrecuencia = @EnvioAutomaticoSeguimientoViajesFrecuencia, --sol 010068
        --solicitud 10363 isdejenuhe se agrego campo AjustarImportes2DecimalesXML
        AjustarImportes2DecimalesXML = @AjustarImportes2DecimalesXML
        --SOLICITUD 010597 
        ,
        BancoOrdenante = @BancoOrdenante ,
        RFCBancoOrdenante = @RFCBancoOrdenante,
        NoCuentaBancoOrdenante = @NoCuentaBancoOrdenante,
        ExcluirNodoCondicionesPagoXML = @ExcluirNodoCondicionesPagoXML --Solicitud 10528--
        ,EstatusViajeEDI = @EstatusViajeEDI 
        ,AplicarDetalleMaterialesEnCadaViajeEnXML = @AplicarXMLDetallePorCadaViajeCartaPorte,
        EnviarCorreoSeguimiento =@EnviarCorreoSeguimiento,
        EnviarCorreoEstatusEDI=@EnviarCorreoEstatusEDI,
        EnviarCorreoReporteFourkites=@EnviarCorreoReporteFourkites,
        EnviarFoukitesFTP_Correo=@EnviarFoukitesFTP_Correo,
        Fourkites_FTPServer=@Fourkites_FTPServer,
        Fourkites_FTPUsuario=@Fourkites_FTPUsuario, 
        Fourkites_FTPContrasenia =@Fourkites_FTPContrasenia 
        ,DesglosarDetalleRutaPorConcepto = @DesglosarDetalleRutaPorConcepto,
		PermitirPoleo = @PermitirPoleo
        WHERE IdCliente = @IdCliente

    IF @dsCatClientesContactos IS NOT NULL
    BEGIN   
        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatClientesContactos

        SELECT ATT_IdContacto,ATT_Contacto,ATT_CorreoElectronico,ATT_Telefonos,ATT_RecibirFactura,ATT_RecibirCP,ATT_RecibirEdoCta,ATT_PermitirVerSeguimiento,ATT_Usuario,ATT_Contrasena,ATT_UsoDeServiciosWeb,ATT_OperadorLogistico,ATT_PortalClientes,ATT_ClientesXML,ATT_MostrarSeguimientoSolicitudes, ATT_MostrarImportesEnHistoricoViajes, ATT_SeguimientoRecorrido,ATT_RecibirCotizador,ATT_RecibirReporteFourkites,ATT_MostrarRutaTrayectoSeguimientoviajes
        INTO #TempCatClientesContactos
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatClientesContactos',2) 
        WITH (ATT_IdContacto int,ATT_Contacto varchar(90),ATT_CorreoElectronico varchar(100),ATT_Telefonos varchar(max),ATT_RecibirFactura bit,ATT_RecibirCP bit,ATT_RecibirEdoCta bit,ATT_PermitirVerSeguimiento bit, ATT_Usuario varchar(8),ATT_Contrasena varchar(8),ATT_UsoDeServiciosWeb bit,ATT_OperadorLogistico bit,ATT_PortalClientes bit,ATT_ClientesXML varchar(max),ATT_MostrarSeguimientoSolicitudes bit, ATT_MostrarImportesEnHistoricoViajes bit, ATT_SeguimientoRecorrido bit,ATT_RecibirCotizador bit,ATT_RecibirReporteFourkites bit,ATT_MostrarRutaTrayectoSeguimientoviajes bit)

        EXEC sp_xml_removedocument @docHandle
        
        DECLARE CatClientesContactosCursor CURSOR LOCAL FOR
        SELECT * FROM #TempCatClientesContactos

        OPEN CatClientesContactosCursor
        FETCH NEXT FROM CatClientesContactosCursor
        INTO @CursorIdClienteContacto,@CursorContacto,@CursorCorreoElectronico,@CursorTelefonos,@CursorRecibirFactura,@CursorRecibirCP,@CursorRecibirEdoCta,@CursorPermitirVerSeguimiento,@CursorUsuario,@CursorContrasena,@CursorUsoDeServiciosWeb,@CursorOperadorLogistico,@CursorPortalClientes,@CursorClientesXML,@CursorMostrarSeguimientoSolicitudes, @CursorMostrarImportesEnHistoricoViajes, @CursorSeguimientoRecorrido,@CursorRecibirCotizador,@CusorRecibirReporteFourkites,@CusorMostrarRutaTrayectoSeguimientoviajes
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
        
            IF @CursorIdClienteContacto = 0
            BEGIN
                EXEC @return_value = usp_CatClientesContactosAgregar @IdCliente, @CursorContacto, @CursorCorreoElectronico, @CursorTelefonos, @CursorRecibirFactura, @CursorRecibirCP, @CursorRecibirEdoCta, @ModificadoPor, @ModificadoEl, @IdPeticion, @CursorPermitirVerSeguimiento, @CursorUsuario, @CursorContrasena, @CursorUsoDeServiciosWeb, @CursorOperadorLogistico,@CursorPortalClientes,@CursorClientesXML,@CursorMostrarSeguimientoSolicitudes,@CursorMostrarImportesEnHistoricoViajes, @CursorSeguimientoRecorrido,@CursorRecibirCotizador,@CusorRecibirReporteFourkites,@CusorMostrarRutaTrayectoSeguimientoviajes
            END 
            ELSE
            BEGIN
                EXEC @return_value = usp_CatClientesContactosModificar @CursorIdClienteContacto, @CursorContacto, @CursorCorreoElectronico, @CursorTelefonos, @CursorRecibirFactura, @CursorRecibirCP, @CursorRecibirEdoCta, @ModificadoPor, @ModificadoEl, @IdPeticion, @CursorPermitirVerSeguimiento, @CursorUsuario, @CursorContrasena, @CursorUsoDeServiciosWeb, @CursorOperadorLogistico,@CursorPortalClientes,@CursorClientesXML,@CursorMostrarSeguimientoSolicitudes,@CursorMostrarImportesEnHistoricoViajes, @CursorSeguimientoRecorrido,@CursorRecibirCotizador,@CusorRecibirReporteFourkites,@CusorMostrarRutaTrayectoSeguimientoviajes
            END
            
            IF @return_value <> 0
            RAISERROR(N'Ocurrió un error al agregar los contactos',
                16,
                1
                )

            FETCH NEXT FROM CatClientesContactosCursor
            INTO @CursorIdClienteContacto,@CursorContacto,@CursorCorreoElectronico,@CursorTelefonos,@CursorRecibirFactura,@CursorRecibirCP,@CursorRecibirEdoCta,@CursorPermitirVerSeguimiento,@CursorUsuario,@CursorContrasena,@CursorUsoDeServiciosWeb,@CursorOperadorLogistico,@CursorPortalClientes,@CursorClientesXML,@CursorMostrarSeguimientoSolicitudes,@CursorMostrarImportesEnHistoricoViajes, @CursorSeguimientoRecorrido,@CursorRecibirCotizador,@CusorRecibirReporteFourkites,@CusorMostrarRutaTrayectoSeguimientoviajes
        END
        CLOSE CatClientesContactosCursor
        DEALLOCATE CatClientesContactosCursor
    END
    --------------------------Se agregan los formatos---------------------------------------------
    IF @dsFormatos IS NOT NULL
    BEGIN   
        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsFormatos

        SELECT ATT_IdClienteFormato,ATT_IdFormato,ATT_Marcado
        INTO #TempCatClientesFormatos
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatFormatos',2) 
        WITH (ATT_IdClienteFormato int,ATT_IdFormato int,ATT_Marcado bit)

        EXEC sp_xml_removedocument @docHandle

        DECLARE CatClientesFormatosCursor CURSOR LOCAL FOR
        SELECT * FROM #TempCatClientesFormatos      

        OPEN CatClientesFormatosCursor
        FETCH NEXT FROM CatClientesFormatosCursor
        INTO @CursorFormatoIdClienteFormato,@CursorFormatoIdFormato,@CursorFormatoMarcado
    
        WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @CursorFormatoIdClienteFormato = 0
            BEGIN
                EXEC @return_value = usp_CatClientesFormatosAgregar @IdCliente,@CursorFormatoIdFormato,@CursorFormatoMarcado,@ModificadoPor,@ModificadoEl,@IdPeticion
            END
            ELSE
            BEGIN
                EXEC @return_value = usp_CatClientesFormatosModificar @CursorFormatoIdClienteFormato,@IdCliente,@CursorFormatoIdFormato,@CursorFormatoMarcado,@ModificadoPor,@ModificadoEl,@IdPeticion
            END
            IF @return_value <> 0
            RAISERROR(N'Ocurrió un error al agregar los formatos',
                16,
                1
                )       
        
            FETCH NEXT FROM CatClientesFormatosCursor
            INTO @CursorFormatoIdClienteFormato,@CursorFormatoIdFormato,@CursorFormatoMarcado
        END
        CLOSE CatClientesFormatosCursor
        DEALLOCATE CatClientesFormatosCursor
    END 
    -----------------------------------------------------------------------

    --SE VALIDA QUE LOS CONTACTOS A ELIMINAR NO ESTEN ASOCIADOS A COTIZACIONES SOLICITUD 291 ADRIAN VARELA 30 SEPT 2019
    IF EXISTS (Select IdCotizacion From ProCotizaciones Where IdClienteContacto in (Select IdClienteContacto From CatClientesContactos WHERE IdCliente = @IdCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl))
    BEGIN

        DECLARE @NombreContacto VARCHAR (50)
        SET @NombreContacto = (SELECT top 1 ccc.Contacto FROM CatClientesContactos as ccc
        INNER JOIN ProCotizaciones as pc on ccc.IdClienteContacto = pc.IdClienteContacto 
        WHERE ccc.IdCliente = @IdCliente AND (ccc.ModificadoEl <> @ModificadoEl OR ccc.ModificadoEl IS NULL) AND ccc.CreadoEl <> @ModificadoEl)
        RAISERROR(N'No es posible eliminar el contacto %s porque ya tiene cotizaciones relacionadas.',
            16,
            1,
            @NombreContacto
            ) 

    END

    --SE ELIMINAN LOS CONTACTOS QUE NO FUERON AGREGADOS O MODIFICADOS
    DELETE FROM CatClientesContactos WHERE IdCliente = @IdCliente AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
        UPDATE CatCuentasContables SET
        Nombre = @NombreFiscal
        WHERE CatalogoLigado = 'CatClientes' AND IdCatalogoLigado = @IdCliente
    END
    SELECT @dsComplementos
    --Se modifican los complementos
    IF @dsComplementos IS NOT NULL
        BEGIN   
        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsComplementos
        
        SELECT ATT_IdComplemento,ATT_Valor1,ATT_Valor2
        INTO #TempCatClientesComplementos
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatClientesCamposAdicionales',2) 
        WITH (ATT_IdComplemento int,ATT_Valor1 varchar(250), ATT_Valor2 varchar(250))

        EXEC sp_xml_removedocument @docHandle
        
        DECLARE CatClientesComplementosCursor CURSOR LOCAL FOR
        SELECT * FROM #TempCatClientesComplementos

        OPEN CatClientesComplementosCursor
        FETCH NEXT FROM CatClientesComplementosCursor
        INTO @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2
        
        WHILE @@FETCH_STATUS = 0 
        BEGIN
        SET @ComplementosCreadoEl = (SELECT CreadoEl From CatClientesComplementosCamposAdicionales WHERE IdCliente = @IdCliente)
        SET @ComplementosCreadoPor = (SELECT CreadoPor From CatClientesComplementosCamposAdicionales WHERE IdCliente = @IdCliente)

            DELETE FROM CatClientesComplementosCamposAdicionales WHERE IdCliente = @IdCliente

            INSERT INTO CatClientesComplementosCamposAdicionales(IdCliente, IdComplemento, Campo1, Campo2, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
            VALUES(@IdCliente, @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2,@ComplementosCreadoEl,@ComplementosCreadoPor, @ModificadoEl, @ModificadoPor )
        
            FETCH NEXT FROM CatClientesComplementosCursor
            INTO @CursorComplementoIdComplemento,@CursorComplementoValor1, @CursorComplementoValor2
        END
        CLOSE CatClientesComplementosCursor
        DEALLOCATE CatClientesComplementosCursor
    END
    ELSE
    BEGIN
        DELETE FROM CatClientesComplementosCamposAdicionales WHERE IdCliente = @IdCliente 
    END
            
    COMMIT
END TRY
BEGIN CATCH

    IF (SELECT CURSOR_STATUS('LOCAL','CatClientesContactosCursor')) >= -1
    BEGIN
        IF (SELECT CURSOR_STATUS('LOCAL','CatClientesContactosCursor')) > -1
        BEGIN
            CLOSE CatClientesContactosCursor
        END
        DEALLOCATE CatClientesContactosCursor
    END

    IF (SELECT CURSOR_STATUS('LOCAL','CatClientesFormatosCursor')) >= -1
    BEGIN
        IF (SELECT CURSOR_STATUS('LOCAL','CatClientesFormatosCursor')) > -1
        BEGIN
            CLOSE CatClientesFormatosCursor
        END
        DEALLOCATE CatClientesFormatosCursor
    END
        
    IF (SELECT CURSOR_STATUS('LOCAL','CatClientesComplementosCursor')) >= -1
    BEGIN
        IF (SELECT CURSOR_STATUS('LOCAL','CatClientesComplementosCursor')) > -1
        BEGIN
            CLOSE CatClientesComplementosCursor
        END
        DEALLOCATE CatClientesComplementosCursor
    END

    iF(@@TRANCOUNT>0)
    BEGIN
      ROLLBACK
        EXECUTE usp_SisErrorsGrabar @IdPeticion
    END
END CATCH
go

