CREATE PROCEDURE [dbo].[usp_CatFormulasNominasAgregar]
@Codigo int,
@Nombre  varchar(50), 
@Expresion  ntext,   
@DefinidoPorSistema bit,
@dsVariables ntext,
@CreadoEl    datetime,    
@CreadoPor    int,    
@IdPeticion varchar(100), 
@dsTodasVariables ntext,
@Ayuda Varchar(100),
@EsFuncion bit

AS
DECLARE
	@IdFormulaNomina int,
	@docHandle int,
	@ATT_IdVariable int,
	@ATT_IdVariable2 int,
	@ATT_Nombre Varchar(50),
	@ATT_Query Varchar(Max),
	@ATT_TipoDeDato int,
	@ATT_Categoria int,
	@ATT_IdFormulaNominaVariable int,
	@ATT_Nombre2 Varchar(50),
	@IdVariable int
	
BEGIN TRY
    BEGIN TRANSACTION            
    IF ISNULL(@Codigo,0)= 0
        RAISERROR(N'El código de la Formula es un campo requerido',
            16,
            1
            )
	IF @Expresion is null
        RAISERROR(N'La definición de la Formula es un campo requerido',
            16,
            1
            )    
    INSERT INTO CatFormulasNominas(Codigo,Nombre,Expresion,DefinidoPorSistema,CreadoEl,CreadoPor,Ayuda,EsFuncion)
    VALUES(@Codigo,@Nombre,@Expresion,@DefinidoPorSistema,@CreadoEl,@CreadoPor,@Ayuda,@EsFuncion)
    
    SET @IdFormulaNomina  = (SELECT IDENT_CURRENT('CatFormulasNominas'))
    
    --SI HAY VARIABLES NUEVAS QUE SE DIERON DE ALTA LAS AGREGAMOS SI Y SI HAY MODIFICADAS SE MODIFICAN SI NO SE BORRAN.
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsTodasVariables
	
	SELECT ATT_IdVariable,ATT_Nombre,ATT_Query,ATT_TipoDeDato,ATT_Categoria
	INTO #TempCatTodasVariables
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatVariables',2) 
	WITH (ATT_IdVariable int,ATT_Nombre Varchar(50),ATT_Query ntext,ATT_TipoDeDato int,ATT_Categoria int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatTodasVariables CURSOR FOR
	SELECT * FROM #TempCatTodasVariables
	
	OPEN CursorCatTodasVariables
	FETCH NEXT FROM CursorCatTodasVariables
	INTO @ATT_IdVariable2,@ATT_Nombre,@ATT_Query,@ATT_TipoDeDato,@ATT_Categoria
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdVariable2 = 0
		begin
			IF @ATT_Categoria = 0
				SET @ATT_Categoria = NULL
			INSERT INTO CatVariables(Nombre,Query,TipoDeDato,CreadoEl,CreadoPor,IdVariableCategoria)
			VALUES(@ATT_Nombre,@ATT_Query,@ATT_TipoDeDato,@CreadoEl,@CreadoPor,@ATT_Categoria)		
		end
		else
		begin
			if @ATT_Categoria = 0 
				SET @ATT_Categoria = NULL 
				
			Update CatVariables
			Set Nombre = @ATT_Nombre,
			Query = @ATT_Query,
			ModificadoEl = @CreadoEl,
			ModificadoPor = @CreadoPor,
			TipoDeDato = @ATT_TipoDeDato,
			IdVariableCategoria = @ATT_Categoria
			Where IdVariable = @ATT_IdVariable2
		end

		FETCH NEXT FROM CursorCatTodasVariables
		INTO @ATT_IdVariable2,@ATT_Nombre,@ATT_Query,@ATT_TipoDeDato,@ATT_Categoria
	END
    CLOSE CursorCatTodasVariables
	DEALLOCATE CursorCatTodasVariables
	
	DELETE FROM CatVariables WHERE ((ModificadoEl <> @CreadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @CreadoEl) 
	And IdVariable not in(Select IdVariable From CatFormulasNominasVariables)
	
    --SECCION PARA AGREGAR A LA TABLA PUENTE LAS VARIABLES QUE ESTAN CONTENIDAS EN LA FORMULA.
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsVariables
	
	SELECT ATT_IdVariable,ATT_IdFormulaNominaVariable,ATT_Nombre
	INTO #TempCatVariables
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Variables',2) 
	WITH (ATT_IdVariable int,ATT_IdFormulaNominaVariable int,ATT_Nombre Varchar(50))
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatVariables CURSOR FOR
	SELECT * FROM #TempCatVariables
	
	OPEN CursorCatVariables
	FETCH NEXT FROM CursorCatVariables
	INTO @ATT_IdVariable,@ATT_IdFormulaNominaVariable,@ATT_Nombre2
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdFormulaNominaVariable = 0
		begin
			If @ATT_IdVariable = 0
			begin
				Set @IdVariable  = (Select IdVariable From CatVariables Where Nombre = @ATT_Nombre2)
			end
			INSERT INTO CatFormulasNominasVariables(IdFormulaNomina,IdVariable,CreadoEl,CreadoPor)
			VALUES(@IdFormulaNomina,@IdVariable,@CreadoEl,@CreadoPor)		
		end
		else
		begin
			Update CatFormulasNominasVariables
			Set IdVariable = @ATT_IdVariable,
			ModificadoEl = @CreadoEl,
			ModificadoPor = @CreadoPor
			Where IdFormulaNominaVariable = @ATT_IdFormulaNominaVariable
		end						
		

		FETCH NEXT FROM CursorCatVariables
		INTO @ATT_IdVariable,@ATT_IdFormulaNominaVariable,@ATT_Nombre2
	END

	CLOSE CursorCatVariables
	DEALLOCATE CursorCatVariables
	
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

