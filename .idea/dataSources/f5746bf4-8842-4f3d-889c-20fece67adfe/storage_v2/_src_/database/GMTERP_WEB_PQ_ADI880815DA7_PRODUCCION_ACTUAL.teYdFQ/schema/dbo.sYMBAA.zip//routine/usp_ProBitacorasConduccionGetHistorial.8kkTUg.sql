
CREATE PROCEDURE [dbo].[usp_ProBitacorasConduccionGetHistorial]
	@NoTelefono varchar(10)	
AS
/*****************************************************************************************************
Descripción:
Regresa los ultimos 18 dias de las bitacoras para que se pueda restaurar en el celular

Implementada por: ISAAC NUÑEZ
Fecha de implementacion: 17/09/2019
Versión: 1.11.04

Modificada por: ISAAC NUÑEZ
Fecha de mofidicacion: 17/09/2019
Versión: 1.11.04

Invocado desde:
SCM:\WebDev Projects\GMTERPV8_ProcesosEspeciales
Clase:ClsProBitacorasConduccion Metodo:GetHistorial
***************************************************************************************************** */
DECLARE @FechaInicial datetime = GETUTCDATE()
	
SET @FechaInicial = DATEADD(DD,-18,@FechaInicial)

SELECT 
pb.FechaHoraInicialUTC,
pb.FechaHoraFinalUTC,
pb.Latitud,
pb.Longitud,
pb.Ubicacion,
pb.Notas,
pb.Accion,
pb.TipoCasoExcepcion,
pb.TipoActividadAuxiliar,
pb.OtrosTipos,
pb.FirmaNombreArchivo,
pb.Origen,
pb.Llegada,
pb.Salida,
pb.Destino,
pb.PuntosIntermedios,
pb.SisParametrosGenerales,
pb.BitacoraUUID
FROM ProBitacorasConduccion AS pb
INNER JOIN CatOperadores AS co ON pb.IdOperador = co.IdOperador
INNER JOIN CatOperadoresInstalacionesAppBitacora AS coia ON pb.IdOperador = coia.IdOperador
WHERE coia.NoTelefono = @NoTelefono
AND pb.FechaHoraInicialUTC >= @FechaInicial
go

