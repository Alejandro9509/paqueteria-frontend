
CREATE PROC [dbo].[usp_CatConfigurarLineasEliminar]
    @IdConfigurarLineas          int,
    @IdPeticion                  varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatCatConfigurarLineasEliminar

Parámetros:
    @IdConfigurarLineas          (entrada, entero). Código de la configuración a las lineas.
    @IdPeticion                  (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para modificar una nueva configuración a las lineas de KPIs.

12/03/2020 - Se creó.

Implementada por: José Luis Cisneros González.
Fecha de implementacion: 07/02/2020
Versión ERP:

Invocada desde: PAGE_CatConfigurarLineasAM (Solicitud 1400)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
    -- Valida que el Id no venga en cero
    IF @IdConfigurarLineas = 0
        RAISERROR(N'El id de la configuración es un campo requerido', 16, 1)

    -- Elimina el registro que tenga el mismo Id
    DELETE FROM CatConfigurarLineas 
    WHERE IdConfigurarLineas = @IdConfigurarLineas

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

