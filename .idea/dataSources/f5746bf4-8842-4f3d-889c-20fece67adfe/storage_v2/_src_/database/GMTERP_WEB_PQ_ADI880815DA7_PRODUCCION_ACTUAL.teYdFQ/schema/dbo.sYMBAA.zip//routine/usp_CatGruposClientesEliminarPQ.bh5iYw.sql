CREATE PROCEDURE [dbo].[usp_CatGruposClientesEliminarPQ]
	@IdGrupoCliente INT
AS
BEGIN 
	BEGIN TRANSACTION
		IF ISNULL(@IdGrupoCliente,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del grupo es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		DELETE FROM CatGruposClientes
		WHERE IdGrupoCliente = @IdGrupoCliente
	IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

