CREATE PROCEDURE [dbo].[usp_SisConsulta]
    @sConsulta ntext,
    @IdUsuario int
AS

DELETE FROM SisConsultas WHERE IdUsuario = @IdUsuario

EXEC dbo.sp_executesql @sConsulta
go

