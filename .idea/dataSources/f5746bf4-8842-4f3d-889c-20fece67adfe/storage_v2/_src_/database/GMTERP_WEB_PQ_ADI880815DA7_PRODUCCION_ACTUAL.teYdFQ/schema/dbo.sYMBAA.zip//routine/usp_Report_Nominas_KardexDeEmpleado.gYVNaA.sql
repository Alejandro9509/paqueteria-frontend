CREATE PROCEDURE [dbo].[usp_Report_Nominas_KardexDeEmpleado]
	@NumeroDepartamentoDesde INT,
	@NumeroDepartamentoHasta INT,
	@NumeroEmpleadoDesde INT,
	@NumeroEmpleadoHasta INT,
	@NumeroEjercicio INT,
	@PeriodoDesde INT,
	@PeriodoHasta INT,
	@StringFiltroGlobal NVARCHAR(MAX),
	@StringConceptosSeleccionados NVARCHAR(MAX)
AS
/* *************************************************************************************************


Parámetros: 
	@NumeroDepartamentoDesde INT,(entrada, entero). Clave de departamento inicial del rango
	@NumeroDepartamentoHasta INT,(entrada, entero). Clave de departamento final del rango
	@NumeroEmpleadoDesde INT,	 (entrada, entero). Clave de empleado inicial del rango 
	@NumeroEmpleadoHasta INT,	 (entrada, entero). Clave de empleado final del rango 
	@NumeroEjercicio INT,		 (entrada, entero). Clave del Ejercicio que se henerara el kardex del empleado
	@PeriodoDesde INT,			 (entrada, entero). Clave del periodo inicial del rango 	
	@PeriodoHasta INT,			 (entrada, entero). Clave del periodo final del rango 	
	@StringFiltroGlobal NVARCHAR(MAX), (entrada, cadena). Filtros adiconales utilizados en el reporte
	@StringConceptosSeleccionados NVARCHAR(MAX) (entrada, cadena). Conceptos de Percepciones y Deducciones a utilizarse en el kardex


Descripción: El procedimiento genera el Kardex del Empleado utilizando 5 Percepciones y 5 Deducciones como base del reporte, eleccionados por el usuario.
			 Se habia omitido el manejo de valores nulos en el campo que indica la concurrencia, se agregó lógica para 
             el manejo de los nulos.

Implementada por: N/A
Fecha de implementacion: N/A
Versión ERP: X.X.XX.XX

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 06/Mayo/2020
Versión ERP: Versión 8.0.51.59
Solicitud: 1787

Modificada por:   Raymundo Espinoza Garcia
Fecha de mofidicacion: 09/Dic/2020
Versión ERP: Versión 8.0.57.09

Invocada desde: PAGE_Report_Nominas_KardexDeEmpleado (Solicitud 3520)
***************************************************************************************************** */


DECLARE @QUERY AS VARCHAR(MAX)
BEGIN
	SET @QUERY = 'SELECT * FROM(
		SELECT 
		CD.Codigo AS CodigoDepartamento,
		CD.Descripcion,
		CE.Codigo AS CodigoEmpleado,
		CE.Nombre,
		CP.NumeroPeriodo AS ''Periodo'',
		CTP.Extraordinario,
		PNR.IdNominaRecibo,
		PNRC.ImporteTotal,
		(CASE WHEN ''' + @StringConceptosSeleccionados + ''' NOT LIKE ''%''+CONVERT(NVARCHAR, CCPDO.IdConceptoPDO) +''%'' THEN CASE WHEN CCPDO.TipoConcepto = 1 THEN ''OTROSPERCEPCION'' ELSE ''OTROSDEDUCCION'' END ELSE CONVERT(NVARCHAR, CCPDO.IdConceptoPDO) END) AS ''FILTRO''

		FROM ProNominasRecibo AS PNR
		INNER JOIN ProNominasReciboConceptos AS PNRC ON PNR.IdNominaRecibo = PNRC.IdNominaRecibo
		INNER JOIN CatTiposPeriodos AS CTP ON PNR.IdTipoPeriodo = CTP.IdTipoPeriodo
		INNER JOIN CatEmpleados AS CE ON PNR.IdEmpleado = CE.IdEmpleado
		INNER JOIN CatDepartamentos AS CD ON CE.IdDepartamento = CD.IdDepartamento
		INNER JOIN CatPeriodos AS CP ON PNR.IdPeriodo = CP.IdPeriodo
		INNER JOIN CatConceptosPDO AS CCPDO ON PNRC.IdConceptoPDO = CCPDO.IdConceptoPDO
		WHERE 
		CD.Codigo BETWEEN ' + CONVERT(NVARCHAR, @NumeroDepartamentoDesde) + ' AND '+ CONVERT(NVARCHAR, @NumeroDepartamentoHasta) + '
		AND CE.Codigo BETWEEN ' + CONVERT(NVARCHAR, @NumeroEmpleadoDesde) + ' AND ' + CONVERT(NVARCHAR, @NumeroEmpleadoHasta) + '
		AND CP.Ejercicio = ' + CONVERT(NVARCHAR, @NumeroEjercicio) + '
		AND CP.NumeroPeriodo BETWEEN ' + CONVERT(NVARCHAR, @PeriodoDesde) + ' AND ' + CONVERT(NVARCHAR, @PeriodoHasta) + '
		AND (CCPDO.TipoConcepto = 1 OR CCPDO.TipoConcepto = 2)		
		AND CCPDO.NumeroConcepto != 0'
		+ @StringFiltroGlobal +'
	) AS Reporte
	PIVOT (SUM(ImporteTotal) FOR FILTRO IN (' + @StringConceptosSeleccionados + ')) AS PivoteConceptosPDO
	ORDER BY CodigoDepartamento, CodigoEmpleado, Periodo'
	
	EXECUTE(@QUERY);
END
go

