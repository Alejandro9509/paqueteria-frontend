

CREATE PROCEDURE [dbo].[usp_CatConvenioEliminarPQ]
	@IdConvenio INT
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdConvenio,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador de la Tarifa es un campo requerido*FIN*', 16, 1);
			return;
		end;
		
		DELETE FROM CatConveniosPQ
		WHERE IdConvenio = @IdConvenio
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
END
go

