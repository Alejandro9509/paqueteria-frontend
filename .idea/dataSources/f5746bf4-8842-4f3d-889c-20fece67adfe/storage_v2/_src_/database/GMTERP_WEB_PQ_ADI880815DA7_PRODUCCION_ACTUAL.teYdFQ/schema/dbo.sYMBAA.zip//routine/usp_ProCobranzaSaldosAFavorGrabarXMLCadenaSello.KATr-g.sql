
CREATE PROCEDURE [dbo].[usp_ProCobranzaSaldosAFavorGrabarXMLCadenaSello]
	@XMLArchivoPagos ntext,
	@CadenaOriginal ntext,
	@SelloDigital ntext,
	@IdCobranzaSaldoAFavor int,
	@Secuencia int,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

	UPDATE ProCobranzaSaldosAFavorTimbrados
	SET SelloDigital = @SelloDigital,
		CadenaOriginal = @CadenaOriginal,
		XMLArchivoSaldoAFavor = @XMLArchivoPagos		
	WHERE IdCobranzaSaldoAFavor = @IdCobranzaSaldoAFavor AND Secuencia = @Secuencia

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

