CREATE PROCEDURE [dbo].[usp_ProReposicionesGetMaxFolioReposicion]

AS

SELECT ISNULL(MAX(FolioReposicion),0)+1 AS FolioReposicion FROM ProReposiciones
go

