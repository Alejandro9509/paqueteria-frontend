
CREATE PROCEDURE [dbo].[usp_CatClientesFormatosAgregar]
	@IdCliente int,
	@IdFormato int,
	@Marcado bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
			
	IF @IdFormato = 0
		RAISERROR(N'El Formato es un campo requerido',
			16,
			1
			)

	INSERT INTO CatClientesFormatos(IdCliente,IdFormato,Marcado,CreadoPor,CreadoEl)
	VALUES(@IdCliente,@IdFormato,@Marcado,@CreadoPor,@CreadoEl)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

