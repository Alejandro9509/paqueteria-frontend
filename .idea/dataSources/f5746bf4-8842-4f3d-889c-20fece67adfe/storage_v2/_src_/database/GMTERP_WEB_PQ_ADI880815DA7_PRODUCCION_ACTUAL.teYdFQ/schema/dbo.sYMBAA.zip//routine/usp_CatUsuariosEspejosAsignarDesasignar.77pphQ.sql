
CREATE PROCEDURE [dbo].[usp_CatUsuariosEspejosAsignarDesasignar]
	@IdUsuarioEspejo INT,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsCatUnidades ntext,
	@IdPeticion varchar(100)
AS
DECLARE 
	@docHandle INT,
	@IdUnidadCursor INT,
	@IdCatUsuariosEspejosCursor INT,
	@FechaHoraActual DATETIME = GETDATE(),
	@FechaHoraVencimientoCursor VARCHAR(20)
BEGIN TRY
	BEGIN TRANSACTION
	IF @dsCatUnidades IS NOT NULL
	BEGIN	
	
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUnidades

		SELECT COL_IdUsuarioEspejoUnidad,COL_IdUnidad,Vencimiento
		INTO #TempCatUnidades
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatUnidades',2) 
		WITH (COL_IdUsuarioEspejoUnidad INT,COL_IdUnidad INT,Vencimiento VARCHAR(20))

		EXEC sp_xml_removedocument @docHandle
		DECLARE CatUnidadesCursor CURSOR FOR
		SELECT * FROM #TempCatUnidades
		OPEN CatUnidadesCursor
		FETCH NEXT FROM CatUnidadesCursor
		INTO @IdCatUsuariosEspejosCursor,@IdUnidadCursor,@FechaHoraVencimientoCursor
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF  @IdCatUsuariosEspejosCursor = 0 AND @FechaHoraVencimientoCursor <> ''
			BEGIN
				INSERT INTO CatUsuariosEspejosUnidades (IdUsuarioEspejo,IdUnidad,FechaVencimiento,CreadoEl,CreadoPor)
							VALUES (@IdUsuarioEspejo,@IdUnidadCursor,CONVERT(DATETIME,@FechaHoraVencimientoCursor,103),@CreadoEl,@CreadoPor)
				INSERT INTO ProUsuariosEspejosUnidadesHistorial (IdUsuarioEspejo,IdUnidad,FechaInicio,FechaFinal,CreadoEl,CreadoPor) 
							VALUES (@IdUsuarioEspejo,@IdUnidadCursor,@FechaHoraActual,CONVERT(DATETIME,@FechaHoraVencimientoCursor,103),@CreadoEl,@CreadoPor)
			END
			ELSE 
			BEGIN	
				IF  @IdCatUsuariosEspejosCursor <> 0 AND  (SELECT FechaVencimiento FROM CatUsuariosEspejosUnidades WHERE IdUsuarioEspejoUnidad = @IdCatUsuariosEspejosCursor ) <> CONVERT(DATETIME,@FechaHoraVencimientoCursor,103) OR @FechaHoraVencimientoCursor <> '' 
				BEGIN
					UPDATE CatUsuariosEspejosUnidades 
					SET 
						FechaVencimiento = CONVERT(DATETIME,@FechaHoraVencimientoCursor,103),
						ModificadoEl = @FechaHoraActual,
						ModificadoPor = @CreadoPor
					WHERE IdUsuarioEspejoUnidad = @IdCatUsuariosEspejosCursor

					IF @FechaHoraVencimientoCursor IS NOT NULL AND @FechaHoraVencimientoCursor <> ''
					BEGIN 
						INSERT INTO ProUsuariosEspejosUnidadesHistorial (IdUsuarioEspejo,IdUnidad,FechaInicio,FechaFinal,CreadoEl,CreadoPor) 
									VALUES (@IdUsuarioEspejo,@IdUnidadCursor,@FechaHoraActual,CONVERT(DATETIME,@FechaHoraVencimientoCursor,103),@CreadoEl,@CreadoPor)
					END 
				END	
			END
			FETCH NEXT FROM CatUnidadesCursor
			INTO @IdCatUsuariosEspejosCursor,@IdUnidadCursor,@FechaHoraVencimientoCursor		
		END
		CLOSE CatUnidadesCursor
		DEALLOCATE CatUnidadesCursor
	END
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

