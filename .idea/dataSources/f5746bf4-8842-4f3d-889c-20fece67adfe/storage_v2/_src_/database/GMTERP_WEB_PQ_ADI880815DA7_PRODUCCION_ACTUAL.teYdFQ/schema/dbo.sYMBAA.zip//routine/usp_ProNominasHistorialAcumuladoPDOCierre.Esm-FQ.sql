CREATE PROCEDURE [dbo].[usp_ProNominasHistorialAcumuladoPDOCierre]
	@Ejercicio INT,				--(Entrada,Entero). La clave del ejercicio en curso a procesar. 
	@IdTipoPeriodo INT,			--(Entrada,Entero). La clave del Tipo Periodo a procesar.
	@IdPeriodo INT,				--(Entrada,Entero). La clave del periodo a cerrar.
	@IdPeticion VARCHAR(100)	--(Entrada,varchar).Id de la Petición, generada en WEBDEV 
 AS
DECLARE
	@IdPeriodoSRC INT,			--(Proceso,Entero). La clave del periodo del ultimo registro del empleado acumulado.
	@IdNominaRecibo INT,		--(Proceso,Entero). La clave del recibo del ultimo registro del empleado acumulado.
	@IdEmpleado INT,			--(Proceso,Entero). La clave del empleado.
	@IdNominaReciboConcepto INT,--(Proceso,Entero). La clave del periodo del ultimo registro del empleado acumulado.
	@IdConceptoPDO INT,			--(Proceso,Entero). La clave del concepto pdo del ultimo registro del empleado acumulado.
	@Descripcion VARCHAR(200),	--(Proceso,string). La descripcion de la clave de concepto del ultimo registro del empleado acumulado.
	@IdTipoPeriodoSRC INT,		--(Proceso,Entero). La clave del Tipo periodo del ultimo registro del empleado acumulado.
	@TipoConcepto VARCHAR(1),	--(Proceso,string). El tipo de concepto correspondeinte a La clave del concepto P/D/O.
	@ImporteTotal NUMERIC (18,4),--(Proceso,Decimal). El importe correspondiente a la clave del concepto PDO en el periodo correspondiente.
	@EjercicioSRC INT,			--(Proceso,Entero). La clave del ejericio procesado.	
	@ImporteAcumulado NUMERIC(18,4),--(Proceso,Decimal). Los vlaores acumulados durante el rango de periodos de cada clave de concepto PDO.	
	@FechaInicio DATE,				--(Proceso,Fecha). La fecha de inicio del periodo en prroceso.
	@FechaFinal DATE,				--(Proceso,Fecha). La fecha de Termino del periodo en prroceso.
	@FechaBaja DATE,				--(Proceso,Fecha). La fecha de Baja del empleado (si existe).
	@FechaAlta DATE,				--(Proceso,Fecha). La fecha de Alta/Modificacion del empleado .
	@FechaIni DATE,					--(Proceso,Fecha). La fecha de inicio del proceso a generar.
	@FechaFin DATE,					--(Proceso,Fecha). La fecha de termino del proceso a generar.
	@TotalRegs INT

/***************************************************************************************************** *
Descripción: El procedimiento actualiza el acumulado de cada uno de los conceptos PDO, correspondientes a cada empleado durante el 
Ejericio

10/12/2019   N/A.

Implementada por: Raymundo Espinoza Garcia.
Fecha de implementacion: 10/12/2019
Versión ERP: 8.0.48.23

Modificada por:   N/A
Fecha de mofidicacion: /N/A15/05/2019
Versión ERP: N/A

Invocada desde: PAGE_ProNominasListado (Solicitud 668)
***************************************************************************************************** */	


BEGIN TRY
	BEGIN TRANSACTION
	--se realiza la busqueda de los periodos a procesar los acumulados
	SET @FechaIni = (SELECT top 1 MIN(CONVERT(DATE,FechaInicio)) as Fini FROM CatPeriodos WHERE Ejercicio =  @Ejercicio)
	SET @FechaFin = (SELECT TOP 1 (CONVERT(DATE,FechaInicio)) as Ffin FROM CatPeriodos WHERE Ejercicio =  @Ejercicio AND IdPeriodo =@IdPeriodo)
	--print 'Fecha Inicio ' + convert(varchar , @FechaIni)
	--print 'Fecha Final ' + convert(varchar , @FechaFin)

DECLARE c_RecibosEmpleado CURSOR FOR
SELECT pnr.IdPeriodo,pnr.IdNominaRecibo,pnr.IdEmpleado,pnrc.IdNominaReciboConcepto,
	   pnrc.IdConceptoPDO, ccpdo.Descripcion, pnr.IdTipoPeriodo,
		CASE pnrc.TipoConcepto
		 WHEN 1 then 'P'
		 WHEN 2 then 'D'
		 WHEN 3 then 'O'		 
		END as TipoConcepto,
		ISNULL(pnrc.ImporteTotal,0)AS ImporteTotal ,cp.Ejercicio, CONVERT(DATE,cp.FechaInicio) AS FechaInicio,
		CONVERT(DATE,cp.FechaFin) AS FechaFinal, CONVERT( DATE,ce.FechaBaja) as FechaBaja,
		CONVERT(DATE,ce.FechaAlta) AS FechaAlta		
		FROM ProNominasRecibo pnr
		INNER JOIN ProNominasReciboConceptos pnrc ON pnrc.IdNominaRecibo = pnr.IdNominaRecibo
		INNER JOIN CatConceptosPDO ccpdo ON ccpdo.IdConceptoPDO = pnrc.IdConceptoPDO
		INNER JOIN CatPeriodos cp ON cp.IdPeriodo = pnr.IdPeriodo
		INNER JOIN CatEmpleados ce ON ce.IdEmpleado = pnr.IdEmpleado
		WHERE cp.Ejercicio = @Ejercicio
		AND cp.IdPeriodo = @IdPeriodo
		--AND cp.IdTipoPeriodo = @IdtipoPeriodo
		--AND pnrc.IdConceptoPDO = 38
		--AND pnr.IdEmpleado = 1212
		--AND cp.FechaInicio >= @FechaIni 
		--AND cp.FechaInicio <= @FechaFin
		ORDER BY pnr.IdEmpleado,cp.FechaInicio,TipoConcepto,pnrc.IdConceptoPDO,  pnr.IdNominaRecibo ,
		pnrc.IdNominaReciboConcepto
OPEN c_RecibosEmpleado

FETCH NEXT FROM c_RecibosEmpleado INTO 
		@IdPeriodoSRC,@IdNominaRecibo ,@IdEmpleado ,@IdNominaReciboConcepto ,@IdConceptoPDO ,@Descripcion ,@IdTipoPeriodoSRC ,@TipoConcepto ,@ImporteTotal,@EjercicioSRC,
		@FechaInicio,@FechaFinal,@FechaBaja,@FechaAlta

WHILE @@FETCH_STATUS = 0
BEGIN

			--se valida si el empleado estaba vigente durante cada periodo acumumulado
			IF (@FechaBaja IS NULL OR (@FechaBaja >=@FechaInicio AND @FechaBaja <= @FechaFinal) OR 
			   (@FechaAlta >=@FechaInicio AND @FechaAlta <=@FechaFinal) OR 
			   (@FechaAlta < @FechaInicio)
			   )
			 BEGIN
				  SET @TotalRegs = (SELECT count(*) FROM ProNominasHistorialAcumuladosPDO WHERE Ejercicio = @EjercicioSRC and IdConceptoPDO = @IdConceptoPDO AND IdEmpleado = @IdEmpleado)	
				  if @TotalRegs = 0
					 BEGIN
						INSERT INTO ProNominasHistorialAcumuladosPDO(Ejercicio,IdEmpleado,IdConceptoPDO,TipoConceptoPDO,MontoAcumulado,IdUltimoPeriodoAcumulado,IdUltimoTipoPeriodo)
						VALUES(@EjercicioSRC,@IdEmpleado,@IdConceptoPDO,@TipoConcepto,@ImporteTotal ,@IdPeriodoSRC,@IdTipoPeriodoSRC)
					 END
				  ELSE
					 BEGIN
					    SET @ImporteAcumulado = 0
						SET @ImporteAcumulado = (SELECT ISNULL(MontoAcumulado,0) as MontoAcumulado FROM ProNominasHistorialAcumuladosPDO WHERE Ejercicio = @EjercicioSRC 
						                         AND IdEmpleado = @IdEmpleado AND IdConceptoPDO = @IdConceptoPDO )
						--SET @ImporteAcumulado = (SELECT  ISNULL(SUM(pnrc.ImporteTotal),0)AS ImporteTotal 
						--						 FROM ProNominasRecibo pnr
						--						 INNER JOIN ProNominasReciboConceptos pnrc ON pnrc.IdNominaRecibo = pnr.IdNominaRecibo
						--						 INNER JOIN CatConceptosPDO ccpdo ON ccpdo.IdConceptoPDO = pnrc.IdConceptoPDO
						--						 INNER JOIN CatPeriodos cp ON cp.IdPeriodo = pnr.IdPeriodo
						--						 INNER JOIN CatEmpleados ce ON ce.IdEmpleado = pnr.IdEmpleado
						--						WHERE cp.Ejercicio = @Ejercicio
						--						AND ccpdo.IdConceptoPDO = @IdConceptoPDO
						--						AND pnr.IdEmpleado = @IdEmpleado
						--						AND cp.FechaInicio >= @FechaIni 
						--						AND cp.FechaInicio <= @FechaFin )
						SET @ImporteAcumulado = @ImporteAcumulado + @ImporteTotal
						UPDATE ProNominasHistorialAcumuladosPDO
						SET
						   MontoAcumulado = @ImporteAcumulado,
				 		   IdUltimoPeriodoAcumulado = @IdPeriodoSRC,
						   IdUltimoTipoPeriodo = @IdTipoPeriodoSRC
						WHERE Ejercicio = @EjercicioSRC AND
							  IdConceptoPDO = @IdConceptoPDO AND
							  IdEmpleado = @IdEmpleado
					  END
				END


FETCH NEXT FROM c_RecibosEmpleado INTO 
		@IdPeriodoSRC,@IdNominaRecibo ,@IdEmpleado ,@IdNominaReciboConcepto ,@IdConceptoPDO ,@Descripcion ,@IdTipoPeriodoSRC ,@TipoConcepto ,@ImporteTotal,@EjercicioSRC,
		@FechaInicio,@FechaFinal,@FechaBaja,@FechaAlta
END
CLOSE c_RecibosEmpleado
DEALLOCATE c_RecibosEmpleado
	--------

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	IF (SELECT CURSOR_STATUS('global','c_RecibosEmpleado')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','c_RecibosEmpleado')) > -1
		BEGIN
			CLOSE c_RecibosEmpleado
		END
	  DEALLOCATE c_RecibosEmpleado
	END
	EXECUTE usp_SisErrorsGrabar @IdPeticion
	
END CATCH
go

