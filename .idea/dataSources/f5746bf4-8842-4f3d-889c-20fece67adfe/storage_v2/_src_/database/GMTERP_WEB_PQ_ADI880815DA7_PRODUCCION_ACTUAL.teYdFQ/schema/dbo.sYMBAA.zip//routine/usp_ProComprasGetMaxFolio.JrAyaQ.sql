CREATE PROCEDURE [dbo].[usp_ProComprasGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProCompras
go

