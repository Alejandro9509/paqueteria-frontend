CREATE PROCEDURE [dbo].[usp_ProReportesFallasEliminar]
@IdReporteFalla int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdReporteFalla,0)= 0
		RAISERROR(N'El identificador de reporte de falla es un campo requerido',
			16,
			1
			)
	IF NOT EXISTS(SELECT IdReporteFalla FROM  ProReportesFallas WHERE ProReportesFallas.IdReporteFalla = @IdReporteFalla)
		RAISERROR(N'Reporte de falla fue eliminada por otro usuario',
			16,
			1
			)
					
	IF EXISTS(SELECT  IdOrdenServicio FROM ProReportesFallas WHERE ProReportesFallas.IdReporteFalla = @IdReporteFalla AND IdOrdenServicio IS NOT NULL)
		RAISERROR(N'Reporte de falla esta atendido, no puede ser eliminado',
			16,
			1
			)

		DELETE ProReporteFallas
		WHERE 	IdReporteFalla=@IdReporteFalla
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

