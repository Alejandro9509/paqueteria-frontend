CREATE PROCEDURE [dbo].[usp_ProViajeSalidaAgregarPQ](	
	@IdViaje int ,
	
	
	@CV1Km float ,
	@CV2Km float ,
	@CV1Millas float ,
	@CV2Millas float ,
	@CV1Estatus bit ,
	@CV2Estatus bit ,
	@FechaSalida date ,
	@HoraSalida time(7) ,
	@IdEstatusSalida int ,
	@KmViaje float ,
	@MillasViaje float,
	@MotivoRetraso varchar(100)
	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @IdGuia int;
        DECLARE @IdUnidad int;
		DECLARE @FOLIO int;
        DECLARE @IdOrigen int;
        DECLARE @CodigoUnidad varchar(16);
		DECLARE @FOLIOSTR varchar(10);		
		DECLARE @TRACKINGSTR varchar(10);
        DECLARE @Observacion varchar(max);

		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

	
	
		/*IF ISNULL(@FechaSalida, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@HoraSalida,'' ) = '' begin
			RAISERROR(N'*INICIO*La hora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
		/*
		IF ISNULL(@IdEstatusSalida, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus de salida un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@KmViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Los kilometros de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@MillasViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Las millas de viaje esun campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		*/
		insert into ProViajeSalidaPQ (	
		IdViaje ,
		
		
		CV1Km ,
		CV2Km ,
		CV1Millas ,
		CV2Millas ,
		CV1Estatus,
		CV2Estatus ,
		FechaSalida ,
		HoraSalida,
		IdEstatusSalida ,
		KmViaje ,
		MillasViaje,
		MotivoRetraso)
	values
	(
		@IdViaje ,
		
	
		@CV1Km ,
		@CV2Km ,
		@CV1Millas ,
		@CV2Millas ,
		@CV1Estatus,
		@CV2Estatus ,
		@FechaSalida ,
		@HoraSalida,
		@IdEstatusSalida ,
		@KmViaje ,
		@MillasViaje,
		@MotivoRetraso
	);

        --SET @CodigoUnidad = (SELECT Codigo FROM CatUnidades WHERE IdUnidad = @IdUnidad);
		--set @FOLIOSTR = (Select FolioViaje from ProViajesPQ where IdViaje = @IdViaje)
        --set @IdUnidad = (Select IdUnidad from ProViajesPQ where IdViaje = @IdViaje)
        --set @IdOrigen = (Select IdOrigen from ProViajesPQ where IdViaje = @IdViaje)
        --set @Observacion = 'Unidad inicio el viaje ' + @FOLIOSTR;
        --exec usp_ProInventarioUnidadesActualizar @IdUnidad, @CodigoUnidad,2,0,0,
          --      @IdOrigen,@FechaSalida,null,@FechaSalida,'',0,@Observacion

		IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

