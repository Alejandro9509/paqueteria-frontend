--SOLICITUD 9736 - JAVIER - GMTERP / NOTIFICACIONES / ALERTAS

CREATE PROCEDURE [dbo].[usp_CatConfiguracionesNotificacionesGPSGrabar]
	@IdUsuario int,
	@CodigoEvento int,
	@Sonido tinyint,
	@Activo bit,
	@IdPeticion varchar(100),
	@TipoNotificacion INT,
	@EnviarNotificacionMovil bit
AS
DECLARE
	@IdConfiguracionNotificacionesGPS int

BEGIN TRY
	BEGIN TRANSACTION
	
		IF @IdUsuario = 0
		RAISERROR(N'El IdUsuario es un campo requerido',
		16,
		1
		)
		
		IF @Sonido = 0
		RAISERROR(N'El Sonido es un campo requerido',
		16,
		1
		)
		
		SET @IdConfiguracionNotificacionesGPS = (SELECT IdConfiguracionNotificacionesGPS FROM CatConfiguracionesNotificacionesGPS WHERE IdUsuario = @IdUsuario AND CodigoEvento = @CodigoEvento)
		
		IF @IdConfiguracionNotificacionesGPS IS NULL
			INSERT INTO CatConfiguracionesNotificacionesGPS(IdUsuario,CodigoEvento,Sonido,Activo,CreadoEl,TipoNotificacion,EnviarNotificacionMovil) VALUES(@IdUsuario,@CodigoEvento,@Sonido,@Activo,GETDATE(),@TipoNotificacion,@EnviarNotificacionMovil)
		ELSE
			UPDATE CatConfiguracionesNotificacionesGPS 
			SET 
				IdUsuario=@IdUsuario, 
				CodigoEvento=@CodigoEvento,
				Sonido=@Sonido,
				Activo=@Activo, 
				ModificadoEl=GETDATE(),
				TipoNotificacion = @TipoNotificacion,
				EnviarNotificacionMovil = @EnviarNotificacionMovil
				WHERE IdConfiguracionNotificacionesGPS = @IdConfiguracionNotificacionesGPS
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

