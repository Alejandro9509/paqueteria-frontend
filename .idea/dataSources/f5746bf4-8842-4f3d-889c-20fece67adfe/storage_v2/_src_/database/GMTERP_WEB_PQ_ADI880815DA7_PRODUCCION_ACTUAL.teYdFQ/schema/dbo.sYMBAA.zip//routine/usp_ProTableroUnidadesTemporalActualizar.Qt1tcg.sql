CREATE PROCEDURE [dbo].[usp_ProTableroUnidadesTemporalActualizar]
	@IdUsuario int,
	@dsProTableroUnidadesTemporal ntext,
	@IdPeticion varchar(100),
	@FechaHoraSucursal datetime
AS
DECLARE
	@docHandle int,
	@TipoUsuario int
BEGIN TRY
	BEGIN TRANSACTION
	IF @dsProTableroUnidadesTemporal IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProTableroUnidadesTemporal

		SELECT Unidad,
		Ubicacion,
		Evento,
		VoltajeVehiculo,
		Latitud,
		Longitud,
		Codigo,
		NoSerie,
		IdUsuarioWeb,
		FechaModificadoWeb,
		ZonaRiesgo,
		CASE 
		WHEN FechaDeReactivacion IS NULL THEN NULL
		WHEN FechaDeReactivacion = '' THEN NULL
		ELSE FechaDeReactivacion
		END AS FechaDeReactivacion,
		Mantenimiento,
		Icono,
		FechaDeReactivacionCadena,
		SumaLitrosTanques,
		TieneSensor,
		PocentajeCombustible,    --Solicitud 9916 agregar porcentaje combustible y tiempo ralenti al tablero
		TiempoRalenti,
		CantidadSatelites ,
		FechaHoraUltimoReporte			--Solicitud 9916 agregar porcentaje combustible y tiempo ralenti al tablero 
		INTO #TempProTableroUnidadesTemp
		FROM OPENXML(@docHandle, N'/Markers/Marker',2) 
		WITH (Unidad varchar(16),
		Ubicacion varchar(700),
		Evento varchar(50),
		VoltajeVehiculo decimal(15, 4),
		Latitud float,
		Longitud float,
		Codigo varchar(16),
		NoSerie varchar(26),
		IdUsuarioWeb int,
		FechaModificadoWeb varchar(300),
		ZonaRiesgo varchar(100),
		FechaDeReactivacion datetime,
		Mantenimiento bit,
		Icono varchar(200),
		FechaDeReactivacionCadena varchar(350),
		SumaLitrosTanques decimal(15, 4),
		TieneSensor bit,
		PocentajeCombustible FLOAT,
		TiempoRalenti varchar(30),
		CantidadSatelites int,
		FechaHoraUltimoReporte VARCHAR(30)) 
		
		EXEC sp_xml_removedocument @docHandle
		

		UPDATE ProTableroUnidadesTemporal set
		CodigoUnidad = cu.Codigo,
		UltimaUbicacion = tmp.Ubicacion,
		UltimoEvento = tmp.Evento,
		Voltaje = tmp.VoltajeVehiculo,
		Latitud = tmp.Latitud,
		Longitud = tmp.Longitud,
		CodigoEvento = tmp.Codigo,
		IdentificadorSatelital = tmp.NoSerie,
		ZonaRiesgo = tmp.ZonaRiesgo,
		FechaSalida = tmp.FechaDeReactivacion,
		EstaMantenimiento = tmp.Mantenimiento,
		IdUsuario = @IdUsuario,
		IdUnidad = cu.IdUnidad,
		Placas = cu.Placas,
		FechaModificado = tmp.FechaModificadoWeb,
		ModificadoPor= (select Usuario from CatUsuarios where IdUsuario = tmp.IdUsuarioWeb),  
		SerieUnidad = cu.SerieUnidad,
		IdGrupoUnidad = cu.IdGrupoUnidad,
		GrupoUnidad = cgu.GrupoUnidad,
		IdTipoUnidad = ctu.IdTipoUnidad,
		TipoUnidad = ctu.TipoUnidad,
		IdOperador = co.IdOperador,
		ColorUnidad = cu.ColorUnidad,
		Modelo = cu.Modelo,
		CantidadSatelites = tmp.CantidadSatelites,
		FechaHoraUltimoReporte = tmp.FechaHoraUltimoReporte,
		Operador = co.Nombre,
		IconoUltimoEvento = 'Imagenes/'+tmp.Icono+'.png',
		FechaSalidaCadena = tmp.FechaDeReactivacionCadena,
		TiempoRalenti = tmp.TiempoRalenti, 
		PorcentajeCombustible = ( CASE 
	              WHEN tmp.TieneSensor = 1 AND cu.CapacidadTanqueCombustible > 0 THEN
		CASE 
			WHEN (CAST((tmp.SumaLitrosTanques * 100)AS INT) / cu.CapacidadTanqueCombustible) > 100 THEN 'N/A' 
			ELSE cast( (CAST((tmp.SumaLitrosTanques * 100)AS INT) / cu.CapacidadTanqueCombustible) as varchar)+'%' 
		END 
			WHEN (tmp.PocentajeCombustible) >= 0 then CAST((tmp.PocentajeCombustible)  AS varchar)+'%'
			ELSE 'N/A'
		END)
		FROM ProTableroUnidadesTemporal as ptut
		inner join #TempProTableroUnidadesTemp as tmp on ptut.IdentificadorSatelital = tmp.NoSerie collate Modern_Spanish_CS_AS
		inner join CatUnidades as cu on cu.IdentificadorSatelital = tmp.NoSerie collate Modern_Spanish_CS_AS
		inner join CatGruposUnidades as cgu on cgu.IdGrupoUnidad = cu.IdGrupoUnidad
		inner join CatTiposUnidades as ctu on ctu.IdTipoUnidad = cu.IdTipoUnidad
		left join CatOperadores as co on co.IdOperador = cu.IdOperador
		inner join CatUsuarios as ca on ca.IdUsuario = @IdUsuario
		WHERE ptut.IdUsuario = @IdUsuario AND
		((ca.TipoUsuario = 5 AND cu.IdUnidad IN(SELECT cueu.IdUnidad 
		FROM CatUsuariosEspejosUnidades  AS cueu 
		WHERE cueu.IdUsuarioEspejo = @IdUsuario AND cueu.FechaVencimiento > @FechaHoraSucursal)
		OR(ca.TipoUsuario != 5)))
		

	    set @TipoUsuario = (select TipoUsuario from CatUsuarios where IdUsuario = @IdUsuario) 
		--se metio esta validacion para que cuando se acabe la fecha hora del usuario espejo y sincronizar la unidad se quite sol 11127
		IF (@TipoUsuario = 5 )
		BEGIN
			DELETE ProTableroUnidadesTemporal WHERE IdUsuario = @IdUsuario AND (( IdUnidad NOT IN(SELECT cueu.IdUnidad 
		FROM CatUsuariosEspejosUnidades  AS cueu 
		WHERE cueu.IdUsuarioEspejo = @IdUsuario AND cueu.FechaVencimiento > @FechaHoraSucursal)))
		END 

		DELETE FROM ProTableroUnidadesTemporal where IdUsuario = @IdUsuario AND IdUnidad is null 

		

	END	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

