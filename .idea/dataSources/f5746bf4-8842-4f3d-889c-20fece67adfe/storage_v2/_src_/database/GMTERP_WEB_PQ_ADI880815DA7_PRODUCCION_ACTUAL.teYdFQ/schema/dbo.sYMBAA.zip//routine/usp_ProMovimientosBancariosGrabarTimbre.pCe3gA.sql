CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosGrabarTimbre]
	@IdMovimientoBancario int,
	@XMLArchivoPagos ntext,
	@FolioFiscalUUIDPagos varchar(36),
	@FechaTimbrado datetime,
	@NoSerieCertificadoSAT varchar(20),
	@SelloSAT ntext,
	@CadenaOriginalTimbrado ntext,
	@TimbrePruebas bit,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	--Se agrego validacion a peticion de la solicitud 009732
	IF EXISTS(SELECT IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdMovimientoBancario = @IdMovimientoBancario AND CanceladoEl IS NOT NULL )
		RAISERROR(N'No se puede timbrar este recibo de pago porque está cancelado',
			16,
			1
			)
						
	UPDATE ProMovimientosBancarios
	SET FolioFiscalUUIDPagos = @FolioFiscalUUIDPagos,
		FechaTimbrado = @FechaTimbrado,
		NoSerieCertificadoSAT = @NoSerieCertificadoSAT,
		SelloSAT = @SelloSAT,
		CadenaOriginalTimbrado = @CadenaOriginalTimbrado,
		XMLArchivoPagos = @XMLArchivoPagos,
		TimbrePruebas = @TimbrePruebas
	WHERE IdMovimientoBancario = @IdMovimientoBancario

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

