CREATE PROCEDURE [dbo].[usp_ProCotizadorAgregar]
@IdCliente int,
@IdSubCliente int,
@IdClienteContacto int,
@Folio varchar(100),
@Revision int,
@IdMoneda varchar(50),
@IdOrigen int,
@IdDestino int,
@Fecha datetime,
@CreadoEl Datetime,
@CreadoPor int,
@ElaboradoEl Datetime,
@ElaboradoPor int,
@IdPeticion varchar(100),
@Estatus int,
@dsCatRutasCompuestas ntext,
@TipoCambio float,
@TipoCotizacion tinyint = NULL
AS

/* *************************************************************************************************

Descripción: El procedimiento agrega un registro de Cotizacion con toda la informacion de las ruta compuesta y los valores de la cotizacion.

Implementada por: N/A
Fecha de implementacion: N/A
Versión ERP: N/A

Modificada por:  Raymundo Espinoza Garcia
Fecha de mofidicacion: 13/09/2019
Versión ERP:  8.0.46.05

Modificada por:  Raymundo Espinoza Garcia
Fecha de mofidicacion: 25/10/2019
Versión ERP:  x.x.xx.xx

Modificada por:  Francisco  Villela
Fecha de mofidicacion: 14/11/2019
Versión ERP:  Versión 8.0.47.45

Modificada por:  Francisco  Villela
Fecha de mofidicacion: 28/11/2019
Versión ERP:  Versión 8.0.48.02
-- se agrego paramtro  xml por trazo asi como la Generacion de las Rutascompuestas por Carda Registro en el XML

Modificada por:  Francisco  Villela
Fecha de mofidicacion: 09/01/2020
Versión ERP:  Versión 8.0.48.67
-- se agrego parametros  Descripcion,Especializado por trazo en la tabla de las Rutascompuestas por Cada Registro.

Modificada por:  Adrian Varela Morales
Fecha de mofidicacion: 18/03/2020
Versión ERP:  Versión 8.0.51.09
Solicitud 1225
--Se agregan campos para guardar valores originales que afectan al calculo de liquidacion

Invocada desde: PAGE_ProCotizadorGenerar(SOLICITUD 218)
Invocada desde: PAGE_ProCotizadorGenerar(SOLICITUD 293)
***************************************************************************************************** */


DECLARE
@IdCotizacion int,
@docHandle int,
@docHandle2 int,
@COL_IdRutaCompuesta int,
@COL_Consecutivo int,
@COL_Concepto varchar(100),
@COL_IncDec float,
@COL_PrecioNeto money,
@COL_CargosAdicionales money,
@COL_CargosAdicionalesDlls money,
@COL_TotalFlete money,
@IdRutaCotizacion int,
@IdConceptoFacturacion int,
@Cantidad float,
@PrecionUnitario money,
@Importe money,
@COL_Grupo bit,
@COL_Consolidar Bit, --sol 293
@COL_FolioConsolidar int, --sol 293
@COL_XMLCargosAdicionales varchar(8000) ,
@COL_CodigoRuta int,
@ATT_IdFactorTipoUnidad int,
@ATT_IdTipoViaje int,
@ATT_IdClasificacion int,
@ATT_KilometroTotalRuta decimal(15,6),
@ATT_TiempoEnTransito decimal(15,6),
@ATT_TotalCasetas money,
@ATT_CostoRutaCP money,
@ATT_PrecioFleteSP money,
@COL_PrecioLista money,
@COL_IdTipoServicio int,
@RC int,
@IdCatPadronDeRutaCompuesta int,
@COL_XMLTrazos varchar(8000),
@ATT_Trazo varchar(8000),
@ATT_IdOrigen int,
@ATT_IdDestino int,
@ATT_IdTipoServicio int,
@COL_XMLGastosAutorizados varchar(8000),
@COL_XMLCasetas  varchar(8000),
@COL_FleteMN money,
@COL_FleteDLLS money,
@COL_xCostoDobleOP money,
@COL_xEspecializado money,
@COL_xPrecioKilometroNeto money,
@COL_xPrecioSugerido money,
@COL_xCostoKilometro money,
@COL_Precio_Sugerido money,
@COL_KMTotalRuta money,
@COL_Autopistas money,
@COL_UtilidadRuta money,
@COL_Especializado money,
@COL_Posicionamiento money,
@COL_Precio_doble_op money,
@COL_FleteMnOriginal money,
@COL_xAutopistas money,
@COL_xPosicionamiento money


BEGIN TRY
	BEGIN TRANSACTION

	if isnull(@TipoCotizacion,0) = 0 -- si no trae tipo de cotizacion, se identificara como que se captura desde la forma de cotizacion que se hizo por primera ves
		SET @TipoCotizacion = 1      -- sino seta la cotizacion por Trazo.

	IF ISNULL(@IdCliente,0)= 0
	RAISERROR(N'El Id del cliente es un campo requerido',
			16,
			1
			)
   /* //SOLICITUD 291, el campo subcliente no es obligatorio
   IF ISNULL(@IdSubCliente,0)= 0
	RAISERROR(N'El Id del Subcliente es un campo requerido',
			16,
			1
			)
*/
    IF ISNULL(@IdClienteContacto,0)=0
	   RAISERROR(N'El IdClienteContacto es un campo requerido',
			16,
			1
			)
   IF LTRIM(RTRIM(@Folio))= ''
	RAISERROR(N'El campo Folio de la Cotizacion es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT * FROM ProCotizaciones WHERE Folio = @Folio)			
		RAISERROR(N'El folio de la cotizacion ya existe en el catálogo',
			16,
			1
			)
	IF LTRIM(RTRIM(@Revision))= ''
	RAISERROR(N'El campo Revision de la Cotizacion es un campo requerido',
			16,
			1
			) 
	IF ISNULL(@IdMoneda,0)=0
	   RAISERROR(N'El IdMoneda es un campo requerido',
			16,
			1
			)		
	IF @TipoCotizacion = 1
	begin		
		IF ISNULL(@IdOrigen,0)=0
		   RAISERROR(N'El IdOrigen es un campo requerido',
				16,
				1
				)    
		IF ISNULL(@IdDestino,0)=0
		   RAISERROR(N'El IdOrigen es un campo requerido',
				16,
				1
				)			   
	end
	IF @TipoCotizacion = 2
	begin		
		SET @IdOrigen = NULL
		SET @IdDestino = NULL
	end
	IF ISDATE(@Fecha) = 0
		RAISERROR(N'La fecha/hora de la Cotizacion es un campo requerido',
			16,
			1
			)				  
	IF ISDATE(@CreadoEl) = 0
		RAISERROR(N'La fecha/hora CreadoEl es un campo requerido',
			16,
			1
			)	
	IF ISNull(@CreadoPor,0)=0
	   RAISERROR(N'El Campo CreadoPor es un campo requerido',
			16,
			1
			) 	
						  
	IF ISDATE(@ElaboradoEl) = 0
		RAISERROR(N'La fecha/hora ElaboradoEl es un campo requerido',
			16,
			1
			)	
	IF ISNull(@ElaboradoPor,0)=0
	   RAISERROR(N'El Campo ElaboradoPor es un campo requerido',
			16,
			1
			) 
		
		--1 PENDIENTE
		--2 ACEPTADO
		--3 RECHAZADO

	set @Estatus = 1

	INSERT INTO ProCotizaciones( Revision, Fecha, IdCliente, IdSubCliente, Estatus, IdMoneda, IdOrigen,IdDestino, 
	Folio, IdClienteContacto,  CreadoEl, CreadoPor,	ElaboradoEl, ElaboradoPor, TipoCambio,TipoCotizacion )
	VALUES ( @Revision,  @Fecha, @IdCliente, @IdSubCliente, @Estatus, @IdMoneda, @IdOrigen, @IdDestino,
		@Folio, @IdClienteContacto, @CreadoEl, @CreadoPor, @ElaboradoEl, @ElaboradoPor ,@TipoCambio,@TipoCotizacion)

	SET @IdCotizacion = (SELECT IDENT_CURRENT('ProCotizaciones'))

	IF @TipoCotizacion = 1
	BEGIN
		--SECCION PARA AGREGAR LAS RUTAS COMPUESTAS
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasCompuestas
	
		SELECT COL_IdRutaCompuesta,
				COL_Consecutivo,
				COL_Concepto,
				COL_IncDec,
				COL_PrecioNeto,
				COL_CargosAdicionales,
				COL_CargosAdicionalesDlls,
				COL_TotalFlete,
				COL_XMLCargosAdicionales,
				COL_Grupo,
				COL_Consolidar,
				COL_FolioConsolidar,
				COL_FleteMN,
				COL_FleteDLLS,
				COL_Precio_Sugerido,
				COL_KMTotalRuta,
				COL_Autopistas,
				COL_UtilidadRuta,
				COL_Especializado,
				COL_Posicionamiento,
				COL_Precio_doble_op,
				COL_FleteMnOriginal,
				COL_AutopistasX,
				COL_PosicionamientoX,
				COL_CostoDobleOPX,
				COL_EspecializadoX,
				COL_PrecioKilometroNetoX,
				COL_PrecioSugeridoX,
				COL_CostoKilometroX
		INTO #TempCatRutasCompuestas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_Cotizacion',2) 
		WITH (COL_IdRutaCompuesta float,
				COL_Consecutivo int,
				COL_Concepto varchar(100),
				COL_IncDec float,
				COL_PrecioNeto money,
				COL_CargosAdicionales money,
				COL_CargosAdicionalesDlls money,
				COL_TotalFlete money,
				COL_XMLCargosAdicionales varchar(8000),
				COL_Grupo bit,
				COL_Consolidar Bit, 
				COL_FolioConsolidar int,
				COL_FleteMN money,
				COL_FleteDLLS money,
				COL_Precio_Sugerido money,
				COL_KMTotalRuta money,
				COL_Autopistas money,
				COL_UtilidadRuta money,
				COL_Especializado money,
				COL_Posicionamiento money,
				COL_Precio_doble_op money,
				COL_FleteMnOriginal money,
				COL_AutopistasX money,
				COL_PosicionamientoX money,
				COL_CostoDobleOPX money,
				COL_EspecializadoX money,
				COL_PrecioKilometroNetoX money,
				COL_PrecioSugeridoX money,
				COL_CostoKilometroX money)

		DECLARE CursorCatRutasCompuestas CURSOR FOR
		SELECT * FROM #TempCatRutasCompuestas
	
		OPEN CursorCatRutasCompuestas
		FETCH NEXT FROM CursorCatRutasCompuestas
		INTO @COL_IdRutaCompuesta,
				@COL_Consecutivo,
				@COL_Concepto,
				@COL_IncDec,
				@COL_PrecioNeto,
				@COL_CargosAdicionales,
				@COL_CargosAdicionalesDlls,
				@COL_TotalFlete,
				@COL_XMLCargosAdicionales,
				@COL_Grupo,
				@COL_Consolidar,
				@COL_FolioConsolidar,
				@COL_FleteMN,
				@COL_FleteDLLS,
				@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xAutopistas,
				@COL_xPosicionamiento,
				@COL_xCostoDobleOP,
				@COL_xEspecializado,
				@COL_xPrecioKilometroNeto,
				@COL_xPrecioSugerido,
				@COL_xCostoKilometro

		WHILE @@FETCH_STATUS = 0
		BEGIN
			/*AQUI VAN LAS VALIDACIONES*/			
			INSERT INTO ProCotizacionesRutas(IdRutaCompuesta,
												IdCotizacion,
												Consecutivo,
												Concepto,
												IncDec,
												PrecioNeto,
												CargosAdicionales,
												CargosAdicionalesDlls,
												TotalFlete,
												Grupo,
												Consolidar,
												FolioConsolidar,
												Revision,
												FleteMN,
												FleteDLLS,
												PrecioSugerido,
												KMTotalRuta,
												TotalCasetas,
												UtilidadRuta,
												Especializado,
												Posicionamiento,
												CostoDobleOP,
												FleteMnOriginal,
												AuxAutopistas,
												AuxPosicionamiento,
												AuxCostoDobleOP,
												AuxEspecializado,
												AuxPrecioNeto,
												AuxPrecioSugerido,
												AuxCostoKilometro)
			VALUES(@COL_IdRutaCompuesta,
					@IdCotizacion,
					@COL_Consecutivo,
					@COL_Concepto,
					@COL_IncDec,
					@COL_PrecioNeto,
					@COL_CargosAdicionales,
					@COL_CargosAdicionalesDlls,
					@COL_TotalFlete,
					@COL_Grupo,
					@COL_Consolidar,
					@COL_FolioConsolidar,
					@Revision,
					@COL_FleteMN,
					@COL_FleteDLLS,
					@COL_Precio_Sugerido,
					@COL_KMTotalRuta,
					@COL_Autopistas,
					@COL_UtilidadRuta,
					@COL_Especializado,
					@COL_Posicionamiento,
					@COL_Precio_doble_op,
					@COL_FleteMnOriginal,
					@COL_xAutopistas,
					@COL_xPosicionamiento,
					@COL_xCostoDobleOP,
					@COL_xEspecializado,
					@COL_xPrecioKilometroNeto,
					@COL_xPrecioSugerido,
					@COL_xCostoKilometro)

				SET @IdRutaCotizacion = (SELECT IDENT_CURRENT('ProCotizacionesRutas'))
		
				IF @COL_XMLCargosAdicionales <> ''	
				BEGIN
					select @COL_XMLCargosAdicionales 
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLCargosAdicionales
			
					SELECT ATT_IdConceptoFacturacion,
							ATT_CodigoConceptoFacturacion,
							ATT_ConceptoFacturacion,
							ATT_Cantidad,
							ATT_PrecioUnitario,
							ATT_Importe
					INTO #TempProCotizacionesRutasCargosAdicionales
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CargosAdicionales',2) 
					WITH(ATT_IdConceptoFacturacion int,
							ATT_CodigoConceptoFacturacion int,
							ATT_ConceptoFacturacion varchar(100),
							ATT_Cantidad float,
							ATT_PrecioUnitario money,
							ATT_Importe money)
			
					EXEC sp_xml_removedocument @docHandle
			
					INSERT INTO ProCotizacionesRutasCargosAdicionales(CreadoEl,
																		CreadoPor,
																		IdCotizacionRuta,
																		IdConceptoFacturacion,
																		Cantidad,
																		PrecioUnitario,
																		Importe,
																		Revision)
					SELECT @CreadoEl,
							@CreadoPor,
							@IdRutaCotizacion,
							ATT_IdConceptoFacturacion,
							ATT_Cantidad,
							ATT_PrecioUnitario,
							ATT_Importe,
							@Revision
					FROM #TempProCotizacionesRutasCargosAdicionales
			
					DROP TABLE #TempProCotizacionesRutasCargosAdicionales
				END

		
				FETCH NEXT FROM CursorCatRutasCompuestas
				INTO @COL_IdRutaCompuesta,
					@COL_Consecutivo,
					@COL_Concepto,
					@COL_IncDec,
					@COL_PrecioNeto,
					@COL_CargosAdicionales,
					@COL_CargosAdicionalesDlls,
					@COL_TotalFlete,
					@COL_XMLCargosAdicionales,
					@COL_Grupo,
					@COL_Consolidar,
					@COL_FolioConsolidar,
					@COL_FleteMN,
					@COL_FleteDLLS,
					@COL_Precio_Sugerido,
					@COL_KMTotalRuta,
					@COL_Autopistas,
					@COL_UtilidadRuta,
					@COL_Especializado,
					@COL_Posicionamiento,
					@COL_Precio_doble_op,
					@COL_FleteMnOriginal,
					@COL_xAutopistas,
					@COL_xPosicionamiento,
					@COL_xCostoDobleOP,
					@COL_xEspecializado,
					@COL_xPrecioKilometroNeto,
					@COL_xPrecioSugerido,
					@COL_xCostoKilometro
					
		END

		CLOSE CursorCatRutasCompuestas
		DEALLOCATE CursorCatRutasCompuestas	
	END-- FIN NO ES COTIZACION POR TRAZO
	ELSE
	BEGIN -- SI VIENE DE COTIZACION POR TRASO GENERARE LAS RUTAS COMPUESTA.
		--SECCION PARA AGREGAR LAS RUTAS COMPUESTAS
		--SECCION PARA AGREGAR LAS RUTAS COMPUESTAS
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasCompuestas
	
		SELECT COL_IdRutaCompuesta,
				COL_Consecutivo,
				COL_Concepto,
				COL_IncDec,
				COL_PrecioNeto,
				COL_CargosAdicionales,
				COL_CargosAdicionalesDlls,
				COL_TotalFlete,
				COL_XMLCargosAdicionales,
				COL_Grupo,
				COL_Consolidar,
				COL_FolioConsolidar,
				COL_XMLTrazos,
				COL_XMLGastosAutorizados,
				COL_XMLCasetas,
				COL_FleteMN,
				COL_FleteDLLS,
				COL_Precio_Sugerido,
				COL_KMTotalRuta,
				COL_Autopistas,
				COL_UtilidadRuta,
				COL_Especializado,
				COL_Posicionamiento,
				COL_Precio_doble_op,
				COL_FleteMnOriginal,
				COL_AutopistasX,
				COL_PosicionamientoX,
				COL_CostoDobleOPX,
				COL_EspecializadoX,
				COL_PrecioKilometroNetoX,
				COL_PrecioSugeridoX,
				COL_CostoKilometroX
		INTO #TempCatRutasCompuestas2
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_Cotizacion',2) 
		WITH (COL_IdRutaCompuesta float,
				COL_Consecutivo int,
				COL_Concepto varchar(100),
				COL_IncDec float,
				COL_PrecioNeto money,
				COL_CargosAdicionales money,
				COL_CargosAdicionalesDlls money,
				COL_TotalFlete money,
				COL_XMLCargosAdicionales varchar(8000),
				COL_Grupo bit,
				COL_Consolidar Bit, 
				COL_FolioConsolidar int,
				COL_XMLTrazos varchar(8000),
				COL_XMLGastosAutorizados Varchar(8000),
				COL_XMLCasetas Varchar(8000),
				COL_FleteMN MONEY,
				COL_FleteDLLS MONEY,
				COL_Precio_Sugerido money,
				COL_KMTotalRuta money,
				COL_Autopistas money,
				COL_UtilidadRuta money,
				COL_Especializado money,
				COL_Posicionamiento money,
				COL_Precio_doble_op money,
				COL_FleteMnOriginal money,
				COL_AutopistasX money,
				COL_PosicionamientoX money,
				COL_CostoDobleOPX money,
				COL_EspecializadoX money,
				COL_PrecioKilometroNetoX money,
				COL_PrecioSugeridoX money,
				COL_CostoKilometroX money)

		DECLARE CursorCatRutasCompuestas CURSOR FOR
		SELECT * FROM #TempCatRutasCompuestas2
	
		OPEN CursorCatRutasCompuestas
		FETCH NEXT FROM CursorCatRutasCompuestas
		INTO @COL_IdRutaCompuesta,
				@COL_Consecutivo,
				@COL_Concepto,
				@COL_IncDec,
				@COL_PrecioNeto,
				@COL_CargosAdicionales,
				@COL_CargosAdicionalesDlls,
				@COL_TotalFlete,
				@COL_XMLCargosAdicionales,
				@COL_Grupo,
				@COL_Consolidar,
				@COL_FolioConsolidar,
				@COL_XMLTrazos,
				@COL_XMLGastosAutorizados,
				@COL_XMLCasetas,
				@COL_FleteMN,
				@COL_FleteDLLS,
				@COL_Precio_Sugerido,
				@COL_KMTotalRuta,
				@COL_Autopistas,
				@COL_UtilidadRuta,
				@COL_Especializado,
				@COL_Posicionamiento,
				@COL_Precio_doble_op,
				@COL_FleteMnOriginal,
				@COL_xAutopistas,
				@COL_xPosicionamiento,
				@COL_xCostoDobleOP,
				@COL_xEspecializado,
				@COL_xPrecioKilometroNeto,
				@COL_xPrecioSugerido,
				@COL_xCostoKilometro

		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			--/*AQUI VAN LAS VALIDACIONES*/	
			IF @COL_XMLTrazos <> ''
			BEGIN	
				
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLTrazos
	
				SELECT ATT_IdFactorTipoUnidad,
						ATT_IdClasificacion,
						ATT_IdTipoViaje,
						ATT_Trazo,
						ATT_IdOrigen,
						ATT_IdDestino,
						ATT_KilometroTotalRuta,
						ATT_TiempoEnTransito,
						ATT_TotalCasetas,
						ATT_CostoRutaCP,
						ATT_PrecioFleteSP,
						ATT_IdTipoServicio
				INTO #TempTrazos2
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Trazo',2) 
				WITH (ATT_IdFactorTipoUnidad int,
							ATT_IdClasificacion int,
							ATT_IdTipoViaje int,
							ATT_Trazo varchar(8000),
							ATT_IdOrigen int,
							ATT_IdDestino int,
							ATT_KilometroTotalRuta decimal(15,6),
							ATT_TiempoEnTransito decimal(15,6),
							ATT_TotalCasetas money,
							ATT_CostoRutaCP money,
							ATT_PrecioFleteSP money,
							ATT_IdTipoServicio int)

						EXEC sp_xml_removedocument @docHandle

						Declare Trazos_Cursor Cursor For
						Select * from #TempTrazos2
						Open Trazos_Cursor
					Fetch Next From Trazos_Cursor
					Into @ATT_IdFactorTipoUnidad,
						@ATT_IdClasificacion,
						@ATT_IdTipoViaje,
						@ATT_Trazo,
						@ATT_IdOrigen,
						@ATT_IdDestino,
						@ATT_KilometroTotalRuta,
						@ATT_TiempoEnTransito,
						@ATT_TotalCasetas,
						@ATT_CostoRutaCP,
						@ATT_PrecioFleteSP,
						@ATT_IdTipoServicio
					While @@Fetch_Status = 0
					Begin
					 select @ATT_IdFactorTipoUnidad
						EXECUTE @RC = [dbo].[usp_CatPadronDeRutaCompuestaAgregar] 
							   @COL_IdRutaCompuesta
							  ,@CreadoEl
							  ,@CreadoPor
							  ,NULL
							  ,NULL
							  ,@ATT_IdFactorTipoUnidad
							  ,@ATT_IdTipoViaje
							  ,@ATT_IdClasificacion
							  ,@ATT_KilometroTotalRuta
							  ,@ATT_TiempoEnTransito
							  ,@ATT_TotalCasetas
							  ,@ATT_CostoRutaCP
							  ,@ATT_PrecioFleteSP
							  ,NULL
							  ,NULL
							  ,@ATT_PrecioFleteSP
							  ,1
							  ,@ATT_IdTipoServicio
							  ,@IdPeticion,1,@ATT_IdOrigen,@ATT_IdDestino,
							  NULL,
							  NULL

							  Fetch Next From Trazos_Cursor
							  Into  @ATT_IdFactorTipoUnidad,
						@ATT_IdClasificacion,
						@ATT_IdTipoViaje,
						@ATT_Trazo,
						@ATT_IdOrigen,
						@ATT_IdDestino,
						@ATT_KilometroTotalRuta,
						@ATT_TiempoEnTransito,
						@ATT_TotalCasetas,
						@ATT_CostoRutaCP,
						@ATT_PrecioFleteSP,
						@ATT_IdTipoServicio
					END
					Close Trazos_Cursor
					Deallocate Trazos_Cursor

				SET @IdCatPadronDeRutaCompuesta = (SELECT IDENT_CURRENT('CatPadronDeRutaCompuesta'))
				drop table #TempTrazos2
			END
			
			INSERT INTO ProCotizacionesRutas(IdRutaCompuesta,
												IdCotizacion,
												Consecutivo,
												Concepto,
												IncDec,
												PrecioNeto,
												CargosAdicionales,
												CargosAdicionalesDlls,
												TotalFlete,
												Grupo,
												Consolidar,
												FolioConsolidar,
												Revision,RutaTrazo,
												IdOrigen,
												IdDestino,
												CasetasAutorizadas,
												FleteMN,
												FleteDLLS,
												PrecioSugerido,
												KMTotalRuta,
												TotalCasetas,
												UtilidadRuta,
												Especializado,
												Posicionamiento,
												CostoDobleOP,
												FleteMnOriginal,
												AuxAutopistas,
												AuxPosicionamiento,
												AuxCostoDobleOP,
												AuxEspecializado,
												AuxPrecioNeto,
												AuxPrecioSugerido,
												AuxCostoKilometro)
			VALUES(@IdCatPadronDeRutaCompuesta,
					@IdCotizacion,
					@COL_Consecutivo,
					@COL_Concepto,
					@COL_IncDec,
					@COL_PrecioNeto,
					@COL_CargosAdicionales,
					@COL_CargosAdicionalesDlls,
					@COL_TotalFlete,
					@COL_Grupo,
					@COL_Consolidar,
					@COL_FolioConsolidar,
					@Revision,
					@ATT_Trazo,
					@ATT_IdOrigen,
					@ATT_IdDestino,
					@COL_XMLCasetas,
					@COL_FleteMN,
					@COL_FleteDLLS,
					@COL_Precio_Sugerido,
					@COL_KMTotalRuta,
					@COL_Autopistas,
					@COL_UtilidadRuta,
					@COL_Especializado,
					@COL_Posicionamiento,
					@COL_Precio_doble_op,
					@COL_FleteMnOriginal,
					@COL_xAutopistas,
					@COL_xPosicionamiento,
					@COL_xCostoDobleOP,
					@COL_xEspecializado,
					@COL_xPrecioKilometroNeto,
					@COL_xPrecioSugerido,
					@COL_xCostoKilometro)

				SET @IdRutaCotizacion = (SELECT IDENT_CURRENT('ProCotizacionesRutas'))
				
				

				IF @COL_XMLGastosAutorizados <> ''
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLGastosAutorizados
					SELECT  ATT_TipoGasto,	
							ATT_IdConceptoGastoViaje,
							ATT_Litros,
							ATT_Importe,	
							ATT_Credito

					INTO #TempGastosAutorizados
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_GastosAutorizados',2) 
					WITH(ATT_TipoGasto tinyint,	
							ATT_IdConceptoGastoViaje int,
							ATT_Litros decimal(15,6),
							ATT_Importe money,	
							ATT_Credito bit)
			
					EXEC sp_xml_removedocument @docHandle
			
					INSERT INTO ProCotizacionesRutasCompuestasGatosPorTrazo(TipoGasto,	
																			IdConceptoGastoViaje,	
																			Litros,	
																			Importe,	
																			Credito,	
																			CreadoEl,	
																			CreadoPor,	
																			IdRutaCotizacion)
					SELECT ATT_TipoGasto,
							ATT_IdConceptoGastoViaje,
							ATT_Litros,
							ATT_Importe,
							ATT_Credito,
							@CreadoEl,
							@CreadoPor,
							@IdRutaCotizacion
					FROM #TempGastosAutorizados
			
					DROP TABLE #TempGastosAutorizados
				END

				IF @COL_XMLCargosAdicionales <> ''	
				BEGIN				
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_XMLCargosAdicionales
			
					SELECT ATT_IdConceptoFacturacion,
							ATT_CodigoConceptoFacturacion,
							ATT_ConceptoFacturacion,
							ATT_Cantidad,
							ATT_PrecioUnitario,
							ATT_Importe
					INTO #TempProCotizacionesRutasCargosAdicionales2
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CargosAdicionales',2) 
					WITH(ATT_IdConceptoFacturacion int,
							ATT_CodigoConceptoFacturacion int,
							ATT_ConceptoFacturacion varchar(100),
							ATT_Cantidad float,
							ATT_PrecioUnitario money,
							ATT_Importe money)
			
					EXEC sp_xml_removedocument @docHandle
			
					INSERT INTO ProCotizacionesRutasCargosAdicionales(CreadoEl,
																		CreadoPor,
																		IdCotizacionRuta,
																		IdConceptoFacturacion,
																		Cantidad,
																		PrecioUnitario,
																		Importe,
																		Revision)
					SELECT @CreadoEl,
							@CreadoPor,
							@IdRutaCotizacion,
							ATT_IdConceptoFacturacion,
							ATT_Cantidad,
							ATT_PrecioUnitario,
							ATT_Importe,
							@Revision
					FROM #TempProCotizacionesRutasCargosAdicionales2
			
					DROP TABLE #TempProCotizacionesRutasCargosAdicionales2
				END

		
				FETCH NEXT FROM CursorCatRutasCompuestas
				INTO @COL_IdRutaCompuesta,
					@COL_Consecutivo,
					@COL_Concepto,
					@COL_IncDec,
					@COL_PrecioNeto,
					@COL_CargosAdicionales,
					@COL_CargosAdicionalesDlls,
					@COL_TotalFlete,
					@COL_XMLCargosAdicionales,
					@COL_Grupo,
					@COL_Consolidar,
					@COL_FolioConsolidar,
					@COL_XMLTrazos,
					@COL_XMLGastosAutorizados,
					@COL_XMLCasetas,
					@COL_FleteMN,
					@COL_FleteDLLS,
					@COL_Precio_Sugerido,
					@COL_KMTotalRuta,
					@COL_Autopistas,
					@COL_UtilidadRuta,
					@COL_Especializado,
					@COL_Posicionamiento,
					@COL_Precio_doble_op,
					@COL_FleteMnOriginal,
					@COL_xAutopistas,
					@COL_xPosicionamiento,
					@COL_xCostoDobleOP,
					@COL_xEspecializado,
					@COL_xPrecioKilometroNeto,
					@COL_xPrecioSugerido,
					@COL_xCostoKilometro
		END

		CLOSE CursorCatRutasCompuestas
		DEALLOCATE CursorCatRutasCompuestas	
	END
	COMMIT
END TRY
BEGIN CATCH    
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion	
END CATCH
go

