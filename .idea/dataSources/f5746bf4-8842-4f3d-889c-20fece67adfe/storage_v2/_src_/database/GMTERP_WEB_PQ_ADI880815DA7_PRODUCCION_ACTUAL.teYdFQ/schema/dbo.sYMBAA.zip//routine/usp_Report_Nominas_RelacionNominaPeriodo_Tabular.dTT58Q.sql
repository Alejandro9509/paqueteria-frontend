CREATE PROCEDURE [dbo].[usp_Report_Nominas_RelacionNominaPeriodo_Tabular]
	@IdDepartamentoDesde INT,
	@IdDepartamentoHasta INT,
	@IdEmpleadoDesde INT,
	@IdEmpleadoHasta INT,
	@IdTipoPeriodo INT,
	@NumeroEjercicio INT,
	@NumeroPeriodo INT,
	@IncluirEmpleadoBaja INT,
	@IncluirEmpleadoNeto INT,
	@IncluirFormaPago INT,
	@IncluirConceptosEspecie INT,
	@OrdenImpresion INT

/* *************************************************************************************************
Procedimiento usp_Report_Nominas_RelacionNominaPeriodo_Tabular

Parámetros: 
    @IdDepartamentoDesde            (entrada, entero) Identificador de departamento inicial de busqueda
    @IdDepartamentoHasta            (entrada, entero) Identificador de departamento final de busqueda
    @IdEmpleadoDesde				(entrada, entero) Identificador de empleado inicial de busqueda
    @IdEmpleadoHasta				(entrada, entero) Identificador de empleado final de busqueda
    @IdTipoPeriodo					(entrada, entero) Identificador del tipo de periodo
    @NumeroEjercicio				(entrada, entero) Numero de ejercicio
    @NumeroPeriodo					(entrada, entero) Numero de periodo
    @IncluirEmpleadoBaja            (entrada, entero) Bandera para el filtro dinamico
    @IncluirEmpleadoNeto            (entrada, entero) Bandera para el filtro dinamico
	@IncluirFormaPago				(entrada, entero) Bandera para el filtro dinamico
	@IncluirConceptosEspecie		(entrada, entero) Bandera para el filtro dinamico
 

Descripción: El procedimiento regresa la coleccion de empleados en pivote de los conceptos separados por percepcion, 
			 deduccion y obligaciones
20/09/2019   Se realizo optimizacion del query para poder obtener toda la informacion en una sola consulta	 

Implementada por: Jesus Humberto Morales M.
Fecha de implementacion: 25/03/2019
Versión ERP: 8.0.41.08

Modificada por: Jesus Humberto Morales M.
Fecha de mofidicacion: 20/09/2019
Versión ERP: 8.0.46.XX
Invocada desde: PAGE_Report_Nominas_RelacionNominaPorPeriodo (Solicitud 166)

Modificada por: Raymundo Espinoza Garcia
Fecha de mofidicacion: 31/03/2020
Versión ERP: 8.0.46.XX
Invocada desde: PAGE_Report_Nominas_RelacionNominaPorPeriodo (Solicitud 1604)

Modificada por: Raymundo Espinoza Garcia
Fecha de mofidicacion: 24/11/2020
Versión ERP: 8.0.56.30
Invocada desde: PAGE_Report_Nominas_RelacionNominaPorPeriodo (Solicitud 3280)


***************************************************************************************************** */
AS

DECLARE @COLUMNAS AS NVARCHAR(MAX), @QUERYCOLUMNAS AS NVARCHAR(MAX), @QUERY AS NVARCHAR(MAX)
DECLARE @STRINGFILTROS AS NVARCHAR(MAX)
DECLARE @FiltroOrdenImpresion VARCHAR(100)
SET @STRINGFILTROS = '' 

BEGIN -- SE ARMAN LOS FILTROS
	IF @IncluirEmpleadoBaja = 1 -- SOLO ALTA
		SET @STRINGFILTROS = @STRINGFILTROS + 'AND ce.FechaAlta IS NOT NULL AND ce.FechaBaja IS NULL'
	ELSE IF @IncluirEmpleadoBaja = 2 -- ALTA Y BAJA
		SET @STRINGFILTROS = @STRINGFILTROS + ''
	ELSE IF @IncluirEmpleadoBaja = 3 -- SOLO BAJA
		SET @STRINGFILTROS = @STRINGFILTROS + ' AND ce.FechaBaja IS NOT NULL'

	IF @IncluirEmpleadoNeto = 1
		SET @STRINGFILTROS = @STRINGFILTROS + ''
	ELSE
		SET @STRINGFILTROS = @STRINGFILTROS + ' AND pnr.NetoPagar != 0'

	IF @IncluirFormaPago = 0
		SET @STRINGFILTROS = @STRINGFILTROS + ''
	ELSE IF @IncluirFormaPago = 1
		SET @STRINGFILTROS = @STRINGFILTROS + ' AND ce.FormaPago = 1'
	ELSE IF @IncluirFormaPago = 2
		SET @STRINGFILTROS = @STRINGFILTROS + ' AND ce.FormaPago = 2'
	ELSE IF @IncluirFormaPago = 3
		SET @STRINGFILTROS = @STRINGFILTROS + ' AND ce.FormaPago = 3'

	IF @IncluirConceptosEspecie = 0
		SET @STRINGFILTROS = @STRINGFILTROS + ''
	ELSE IF @IncluirConceptosEspecie = 1
		SET @STRINGFILTROS = @STRINGFILTROS + ' AND pnrc.Especie = 0'
	 
	 IF @OrdenImpresion = 1
	    SET @FiltroOrdenImpresion = ' '
	ELSE IF @OrdenImpresion = 2
		    SET @FiltroOrdenImpresion = ' ORDER BY Nombre'	
END

BEGIN -- SE OBTIENEN LAS COLUMNAS SEGUN EL TIPO DE CONCEPTO
	SET @QUERYCOLUMNAS = 'SELECT @COLUMNASRETORNO = STUFF((SELECT '','' + QUOTENAME(REPLACE(CONVERT(VARCHAR(1), pnrc.TipoConcepto) + ''/'' + ccp.Descripcion,'' '',''_''))
	FROM ProNominasRecibo AS pnr 
	INNER JOIN ProNominasReciboConceptos As pnrc ON pnr.IdNominaRecibo = pnrc.IdNominaRecibo 
	INNER JOIN CatEmpleados As ce ON pnr.IdEmpleado = ce.IdEmpleado 
	INNER JOIN CatPuestos As cp ON ce.IdPuesto = cp.IdPuesto 
	INNER JOIN CatDepartamentos AS cd ON ce.IdDepartamento = cd.IdDepartamento 
	INNER JOIN CatPeriodos AS cpd ON pnr.IdPeriodo = cpd.IdPeriodo  
	INNER JOIN CatConceptosPDO AS ccp ON pnrc.IdConceptoPDO = ccp.IdConceptoPDO  
	INNER JOIN CatTurnos AS ct ON pnr.IdTurno = ct.IdTurno 
	WHERE cd.Codigo BETWEEN ' + CONVERT(NVARCHAR, @IdDepartamentoDesde) +' AND ' + CONVERT(NVARCHAR, @IdDepartamentoHasta) + ' 
	AND ce.Codigo BETWEEN ' + CONVERT(NVARCHAR, @IdEmpleadoDesde) + ' AND ' + CONVERT(NVARCHAR, @IdEmpleadoHasta) + ' 
	AND pnr.IdTipoPeriodo = ' + CONVERT(NVARCHAR, @IdTipoPeriodo) + ' 
	AND cpd.Ejercicio = ' + CONVERT(NVARCHAR, @NumeroEjercicio) + ' 
	AND cpd.NumeroPeriodo = ' + CONVERT(NVARCHAR, @NumeroPeriodo) + '  
	AND ccp.NumeroConcepto != 00000
	--AND ce.FechaAlta <= cpd.FechaFin
	AND pnrc.TipoConcepto IN (1,2,3) ' 
	+ @STRINGFILTROS + ' 
	GROUP BY ccp.Descripcion, pnrc.TipoConcepto 
	ORDER BY pnrc.TipoConcepto, ccp.Descripcion
	FOR XML PATH(''''))
	, 1, 1, '''')'

	EXEC sp_executesql @QUERYCOLUMNAS, N'@COLUMNASRETORNO AS NVARCHAR(MAX) OUTPUT', @COLUMNAS OUTPUT
	SET @COLUMNAS = ISNULL(@COLUMNAS, 'VACIO')
END

BEGIN -- SE HACEN LOS PIVOT SEGUN EL TIPO DE CONCEPTO
	SET @QUERY = 'SELECT * FROM (SELECT MAX(ce.Nombre) AS Nombre, LEFT(REPLACE(STR(ce.Codigo, 6), '' '', ''0''), 6) AS Codigo, REPLACE(CONVERT(VARCHAR(1), pnrc.TipoConcepto) + ''/'' +ccp.Descripcion,'' '',''_'') AS Descripcion, SUM(pnrc.ImporteTotal) AS ImporteTotal
			FROM ProNominasRecibo AS pnr
			INNER JOIN ProNominasReciboConceptos As pnrc ON pnr.IdNominaRecibo = pnrc.IdNominaRecibo
			INNER JOIN CatEmpleados As ce ON pnr.IdEmpleado = ce.IdEmpleado
			INNER JOIN CatPuestos As cp ON ce.IdPuesto = cp.IdPuesto
			INNER JOIN CatDepartamentos AS cd ON ce.IdDepartamento = cd.IdDepartamento
			INNER JOIN CatPeriodos AS cpd ON pnr.IdPeriodo = cpd.IdPeriodo 
			INNER JOIN CatConceptosPDO AS ccp ON pnrc.IdConceptoPDO = ccp.IdConceptoPDO 
			INNER JOIN CatTurnos AS ct ON pnr.IdTurno = ct.IdTurno
			WHERE cd.Codigo BETWEEN ' + CONVERT(NVARCHAR, @IdDepartamentoDesde) +' AND ' + CONVERT(NVARCHAR, @IdDepartamentoHasta) + ' 
			AND ce.Codigo BETWEEN ' + CONVERT(NVARCHAR, @IdEmpleadoDesde) + ' AND ' + CONVERT(NVARCHAR, @IdEmpleadoHasta) + ' 
			AND pnr.IdTipoPeriodo = ' + CONVERT(NVARCHAR, @IdTipoPeriodo) + ' 
			AND cpd.Ejercicio = ' + CONVERT(NVARCHAR, @NumeroEjercicio) + ' 
			AND cpd.NumeroPeriodo = ' + CONVERT(NVARCHAR, @NumeroPeriodo) + ' 
			AND ccp.NumeroConcepto != 00000
			--AND ce.FechaAlta <= cpd.FechaFin
			AND pnrc.TipoConcepto IN (1,2,3) '
			+ @STRINGFILTROS + ' 
			GROUP BY ce.Codigo, ccp.Descripcion, pnrc.TipoConcepto
		) X
		PIVOT 
		(
			AVG(ImporteTotal)
			FOR Descripcion IN (' + @COLUMNAS + ')
		) P ' +    @FiltroOrdenImpresion
	EXECUTE(@QUERY);
END
go

