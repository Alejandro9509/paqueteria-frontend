
CREATE PROCEDURE [dbo].[usp_ProCorteCajaAgregarPQ](
	@IdSucursal int,
	@FechaRegistro date,
	@HoraRegistro time,
	@IdDestino int,
	@IdTipoMoneda int,
	@IdTipoPago int,
	@Total float,
	@IdEstatusCorte int,
	@IdUsuario int
)
AS
BEGIN
	BEGIN TRANSACTION
	DECLARE @VigenciaDate date;
		/*IF ISNULL(@IdCliente, 0) = 0 begin
			RAISERROR(N'*INICIO*El cliente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF @Vigencia IS NOT NULL AND LEN(@Vigencia) > 0 begin
			set @VigenciaDate = CAST(@Vigencia as date)
		end*/
		
		INSERT INTO ProCorteCajaPQ (IdSucursal, FechaRegistro, HoraRegistro, IdDestino, IdTipoMoneda, IdTipoPago, Total, IdEstatusCorte, IdUsuario)
		values(@IdSucursal, @FechaRegistro, @HoraRegistro, @IdDestino, @IdTipoMoneda, @IdTipoPago, @Total, @IdEstatusCorte, @IdUsuario) 

		/*INSERT INTO ProCorteCajaGuiasPQ (IdCorte, IdGuia)
		values(@IdCorte, @IdGuia) */

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

