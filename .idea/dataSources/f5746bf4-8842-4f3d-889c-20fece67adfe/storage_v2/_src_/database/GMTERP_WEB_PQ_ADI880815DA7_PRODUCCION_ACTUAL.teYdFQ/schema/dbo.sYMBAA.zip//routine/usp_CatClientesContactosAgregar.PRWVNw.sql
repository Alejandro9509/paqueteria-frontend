CREATE PROCEDURE [dbo].[usp_CatClientesContactosAgregar]
	@IdCliente int,
	@Contacto varchar(90),
	@CorreoElectronico varchar(100),
	@Telefonos varchar(max),
	@RecibirFactura bit,
	@RecibirCP bit,
	@RecibirEdoCta bit,		
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@PermitirVerSeguimiento bit,
	@Usuario varchar(8),
	@Contrasena varchar(8),
	@UsoDeServiciosWeb bit,
	@OperadorLogistico bit,
	@PortalClientes bit,
	@dsClientes ntext,
	@CursorMostrarSeguimientoSolicitudes bit,
	@CursorMostrarImportesEnHistoricoViajes bit,
	@CursorSeguimientoRecorrido bit,
	@CursorRecibirCotizador bit,
	@CusorRecibirReporteFourkites bit,
	@CusorMostrarRutaTrayectoSeguimientoviajes bit
AS
DECLARE
@IdClienteContacto int,
@docHandle int,
@IdClienteAsociado int,
@ATT_IdClienteContacto int,@ATT_IdTelefonoContacto int,@ATT_Telefono varchar(36),@ATT_IdTipoTelefono int

/*
*********************************************************************************************************************************************************************
MODIFICADO:
	Se agrego un nuevo check para ocultar la columna de ruta/trayecto en el portal de seguimiento
MODIFICADA POR:
	EDGAR RAMOS
FECHA DE MODIFICACION:
	2021-02-22
SOLICITUD :
	003910
*********************************************************************************************************************************************************************
MODIFICADO:
	Se cambio el tipo de dato de @CursorTelefonos a varcahr(max) porque ahora contine un xml
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2021-01-20
SOLICITUD: 
	SOLICITUD 003660
*********************************************************************************************************************************************************************
*/
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@Contacto)) = ''
		RAISERROR(N'El Contacto es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@CorreoElectronico)) = ''
		RAISERROR(N'El correo es un campo requerido',
			16,
			1
			)
			
	INSERT INTO CatClientesContactos(Contacto,CorreoElectronico,CreadoEl,CreadoPor,IdCliente,RecibirCP,RecibirEdoCta,RecibirFactura,PermitirVerSeguimiento,Usuario,Contrasena,UsoDeServiciosWeb,OperadorLogistico,PortalClientes,MostrarSeguimientoSolicitudes, MostrarImportesEnHistoricoViajes, SeguimientoRecorrido,RecibirCotizador,RecibirReporteFourkites,MostrarRutaTrayectoSeguimientoviajes)
	VALUES(@Contacto,@CorreoElectronico,@CreadoEl,@CreadoPor,@IdCliente,@RecibirCP,@RecibirEdoCta,@RecibirFactura,@PermitirVerSeguimiento,@Usuario,@Contrasena,@UsoDeServiciosWeb,@OperadorLogistico,@PortalClientes,@CursorMostrarSeguimientoSolicitudes, @CursorMostrarImportesEnHistoricoViajes, @CursorSeguimientoRecorrido,@CursorRecibirCotizador,@CusorRecibirReporteFourkites,@CusorMostrarRutaTrayectoSeguimientoviajes)

	SET @IdClienteContacto = (SELECT IDENT_CURRENT('CatClientesContactos'))	

	DELETE FROM CatClientesContactosTelefonos WHERE IdClienteContacto = @IdClienteContacto
	
	IF @Telefonos IS NOT NULL
	BEGIN	
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @Telefonos
		
		SELECT ATT_IdClienteContacto,ATT_Telefono,ATT_IdTipoTelefono
		INTO #TempTelefonosContacto
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatContactosClienteAsociadosTelefonos',2) 
		WITH (ATT_IdClienteContacto int,ATT_Telefono varchar(36),ATT_IdTipoTelefono int)

		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatClientesContactosTelefonos(IdClienteContacto,Telefono,IdTipoTelefono)
		SELECT @IdClienteContacto,ATT_Telefono,ATT_IdTipoTelefono FROM #TempTelefonosContacto
	END

    ------------------------------------Agregar Clientes Asociados		
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsClientes

	SELECT ATT_IdClienteAsociado
	INTO #TempCatClientesAsociados
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatContactosClienteAsociados',2) 
	WITH (ATT_IdClienteAsociado int)

	EXEC sp_xml_removedocument @docHandle
	
	SELECT * FROM #TempCatClientesAsociados
	
	DECLARE ClientesContactosAsociadosCursor CURSOR FOR
	SELECT * FROM #TempCatClientesAsociados

	OPEN ClientesContactosAsociadosCursor
	FETCH NEXT FROM ClientesContactosAsociadosCursor
	INTO @IdClienteAsociado
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		IF ISNULL(@IdClienteAsociado,0) <> 0
		BEGIN
			Insert Into CatClientesContactosClientesAsociados(IdClienteContacto,IdCliente) 
			Values(@IdClienteContacto,@IdClienteAsociado) 
		END	
		
		FETCH NEXT FROM ClientesContactosAsociadosCursor
		INTO @IdClienteAsociado
	END	
	CLOSE ClientesContactosAsociadosCursor
	DEALLOCATE ClientesContactosAsociadosCursor
	DROP TABLE #TempCatClientesAsociados		
	------------------------------------	
					
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

