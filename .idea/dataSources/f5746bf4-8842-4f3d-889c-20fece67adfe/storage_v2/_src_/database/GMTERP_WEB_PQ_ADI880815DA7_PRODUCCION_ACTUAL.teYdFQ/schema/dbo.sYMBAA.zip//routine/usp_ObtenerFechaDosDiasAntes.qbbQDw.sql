
CREATE PROCEDURE [dbo].[usp_ObtenerFechaDosDiasAntes]

AS
BEGIN 
	BEGIN TRANSACTION
	DECLARE @VFecha datetime = GETDATE();

	SELECT DATEADD(DAY,-2,@VFecha) as FechaInicio;
	COMMIT
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

