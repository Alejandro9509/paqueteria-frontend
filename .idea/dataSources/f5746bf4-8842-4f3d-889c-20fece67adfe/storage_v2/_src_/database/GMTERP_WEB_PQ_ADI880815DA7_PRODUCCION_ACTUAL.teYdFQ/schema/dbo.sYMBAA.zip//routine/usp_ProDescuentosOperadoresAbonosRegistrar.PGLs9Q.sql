CREATE PROCEDURE [dbo].[usp_ProDescuentosOperadoresAbonosRegistrar]
	@IdDescuentoOperador int,	
	@IdOperador	int,
	@IdDeduccion	int,
	@TipoDescuento	tinyint,
	@FechaHora	datetime,
	@Abono	money,
	@IdMoneda	int,
	@ImporteTotalPorDescontar	money,
	@CreadoEl	datetime,
	@CreadoPor	int,
	@IdPeticion varchar(100),
	@Observaciones varchar(50)

/*************************************************************************************************************************************
Procedimiento almacenado usp_ProDescuentosOperadoresAbonosRegistrar

Parámetros: 
	@IdDescuentoOperador int		->(Entrada) Se utiliza para tener relación con el catalogo de DescuentosOperadores y poder agregar el campo del abono correspondiente al descuento del operador, a su vez con esta variable se puede saber la concurrencia del usuario 	
	@IdOperador	int					->(Entrada) Se utiliza para tener relación con el catalogo de Operadores y saber el Operador correspondiente al descuento sobre el cual se aplica el abono
	@IdDeduccion int				->(Entrada) Se Utiliza para tener relación con el Cataloco de deducciones y saber el tipo de la deduccion sobre la cual se esta aplicando
	@TipoDescuento tinyint			->(Entrada) Se utiliza para saber el tipo de descuento sobre el cual se aplica el abono
	@FechaHora datetime				->(Entrada) Se utiliza para tener control sobre los abonos realizados conforme a la fecha 
	@Abono money					->(Entrada) Se utiliza o se entiende como el Importe el cual se esta abonando sobre el descuento del operador
	@IdMoneda int					->(Entrada) Se utiliza para tener relacion con el catalogo de Monedas 
	@ImporteTotalPorDescontar money ->(Entrada) se utiliza para saber cuanto es el Total del descuento por el cual se esta aplicando el Abono y sobre este obtener saldos
	@CreadoEl datetime				->(Entrada) Se utiliza para tener el control sobre las fechas de creacion del abono 
	@CreadoPor int					->(Entrada) Se utiliza para saber quien creo el abono
	@IdPeticion varchar(100)		->(Entrada) Se utiliza para saber la peticion del proceso en casi de que ocurra algun problema
	@Observaciones varchar(50)		->(Entrada) Se utiliza para referencias o adiciones al abono

Descripción: Agrega los nuevos datos de abono sobre los descuentos del operador 

Implementada por: Diego Arturo Rubio Meza
Fecha de implementación: 12/07/2019
Versión: V8 8.0.44.27

Modificada por:   Diego Arturo Rubio Meza
Fecha de modificación: 16/07/2019
Versión: V8 8.0.44.40

Invocada desde: ClsCatDescuentosOperadores
				Solicitud 12512
******************************************************************************************************************* */

AS
DECLARE
	@IdAbonoDescuentoOperador int,
	@Folio	int,
	@Saldo money
BEGIN TRY
	BEGIN TRANSACTION


		--Verifica que no haya sido Agregado con conterioridad o concurrencia el Descuento que se quiere agregar
		IF EXISTS(SELECT * FROM ProDescuentosOperadoresAbonos WHERE IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador)			
		RAISERROR(N'Se detecto concurrencia de (abono, eliminación o modificación), favor de verificar e intentar nuevamente',
			16,
			1
			)

		IF ISNULL(@Abono,0) <= 0
			RAISERROR(N'El abono es un campo requerido.',
				16,
				1
				)

		--Se Obtiene el Saldo restante del descuento para ver si el abono entrante no es mayor al Saldo habiente
		set @Saldo = (Select ImporteTotalPorDescontar From CatDescuentosOperadores WHERE IdDescuentoOperador = @IdDescuentoOperador) - (Select ImporteDescontado From CatDescuentosOperadores WHERE IdDescuentoOperador = @IdDescuentoOperador)
		
		-- Si el Abono que viene de entrada es Mayor al Saldo te regresa error y si el descuento es de tipo "Otros Descuentos" 
		IF ISNULL(@Abono,0) > @Saldo AND (Select TipoDescuento From CatDescuentosOperadores WHERE IdDescuentoOperador = @IdDescuentoOperador) = 2
			RAISERROR(N'El monto del abono es mayor al saldo del descuento.',
				16,
				1
				)

		
		IF @IdMoneda = 0 
			SET @IdMoneda = NULL


		IF @Folio = 0
		BEGIN
		 SET @Folio = Null 
		END

		INSERT INTO ProDescuentosOperadoresAbonos(Folio,IdOperador,IdDeduccion,IdDescuentoOperador,TipoDescuento,FechaHora,Abono,IdMoneda,ImporteTotalPorDescontar,CreadoEl,CreadoPor,ModificadoEl,ModificadoPor,Observaciones)
		VALUES(@Folio,@IdOperador,@IdDeduccion,@IdDescuentoOperador,@TipoDescuento,@FechaHora,@Abono,@IdMoneda,@ImporteTotalPorDescontar,@CreadoEl,@CreadoPor,Null,Null,@Observaciones)
		
		SET @IdAbonoDescuentoOperador = (SELECT IDENT_CURRENT('ProDescuentosOperadoresAbonos'))

		UPDATE CatDescuentosOperadores 
		SET ImporteDescontado = ISNULL(ImporteDescontado,0)+@Abono
		WHERE IdDescuentoOperador = @IdDescuentoOperador

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH

RETURN @IdDescuentoOperador
go

