	
	CREATE PROCEDURE [dbo].[usp_CatLayoutEstadosDeCuentaEliminar]
	@IdLayoutEstadoCuenta int,
	@IdPeticion varchar(100)	
	AS
	BEGIN TRY
		BEGIN TRANSACTION
		
		IF ISNULL(@IdLayoutEstadoCuenta,0)= 0
			   RAISERROR(N'El identificador es un campo requerido',
						16,
						1
						)
			
			DELETE CatLayoutEstadosDeCuenta	
			WHERE 	IdLayoutEstadoCuenta = @IdLayoutEstadoCuenta
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

