CREATE PROCEDURE [dbo].[usp_ProCorteCajaGetListadoPQ]
AS
BEGIN TRY
	BEGIN TRANSACTION
		SELECT 
		IdCorte,
		IdSucursal, 
		FechaRegistro,
		HoraRegistro,
		IdDestino,
		IdTipoMoneda,
		IdTipoPago,
		Total,
		(Select Ciudad from CatCiudades c WHERE c.IdCiudad = IdDestino) as Destino,
		IdEstatusCorte,
		(Select Descripcion from CatEstatusCortePQ e WHERE e.IdEstatusCorte = cc.IdEstatusCorte) as EstatusCorte
		,IdUsuario
	  ,(select Usuario from CatUsuariosPQ u where u.IdUsuario = cc.IdUsuario) as Usuario
		FROM ProCorteCajaPQ cc where FechaRegistro = Convert(date, GETDATE())
		/*join ProCorteCajaGuiasPQ cg on c.IdCorte = cg.IdCorte 
		join ProGuiaPQ g on g.IdGuia = cg.IdGuia*/
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

