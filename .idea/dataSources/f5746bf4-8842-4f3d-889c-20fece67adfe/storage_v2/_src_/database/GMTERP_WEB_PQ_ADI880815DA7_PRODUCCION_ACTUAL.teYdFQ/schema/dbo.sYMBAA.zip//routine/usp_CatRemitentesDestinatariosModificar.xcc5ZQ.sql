CREATE PROCEDURE [dbo].[usp_CatRemitentesDestinatariosModificar]
	@IdRemitenteDestinatario int,
	@IdCliente int,
	@Numero int,
	@Nombre varchar(150),
	@RFC varchar(13),	
	@Activo bit,	
	@Calle varchar(100),
	@NoExterior varchar(20),
	@NoInterior varchar(20),
	@Colonia varchar(100),
	@Localidad varchar(100),
	@Municipio varchar(100),
	@IdEstado varchar(5),
	@CodigoPostal varchar(10),	
	@IdSucursal int,	
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@Contacto varchar(90),
	@CorreoElectronico varchar(100),
	@Telefono varchar(20),
	@NoRegistroIdentidadFiscal varchar(20)
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdRemitenteDestinatario = 0
		RAISERROR(N'El identificador del remitente-destinatario es un campo requerido',
			16,
			1
			)

	IF (SELECT ModificadoEl FROM CatRemitentesDestinatarios WHERE IdRemitenteDestinatario = @IdRemitenteDestinatario) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)	

	IF @Numero = 0
		RAISERROR(N'El numero de remitente-destinatario es un campo requerido',
			16,
			1
			)			

	IF EXISTS(SELECT Numero FROM CatRemitentesDestinatarios WHERE Numero = @Numero AND IdRemitenteDestinatario <> @IdRemitenteDestinatario)
		RAISERROR(N'El numero de remitente-destinatario ya existe',
			16,
			1
			)	
			
	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El nombre es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@Calle)) = ''
		RAISERROR(N'La calle es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@Municipio)) = ''
		RAISERROR(N'El municipio es un campo requerido',
			16,
			1
			)		
			
	IF LTRIM(RTRIM(@IdEstado)) = ''
		RAISERROR(N'El estado es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@CodigoPostal)) = ''
		RAISERROR(N'El código postal es un campo requerido',
			16,
			1
			)
						
	IF @IdSucursal = 0 
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)

	IF @IdCliente = 0
		SET @IdCliente = NULL			
	
	UPDATE CatRemitentesDestinatarios SET
		Activo = @Activo,
		Calle = @Calle,
		CodigoPostal = @CodigoPostal,
		Colonia = @Colonia,
		IdCliente = @IdCliente,
		IdEstado = @IdEstado,
		IdSucursal = @IdSucursal,
		Localidad = @Localidad,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		Municipio = @Municipio,
		NoExterior = @NoExterior,
		NoInterior = @NoInterior,
		Nombre = @Nombre,
		Numero = @Numero,
		RFC = @RFC,
		Contacto = @Contacto ,
	    CorreoElectronico = @CorreoElectronico ,
	    Telefono = @Telefono ,
		NoRegistroIdentidadFiscal = @NoRegistroIdentidadFiscal
	WHERE IdRemitenteDestinatario = @IdRemitenteDestinatario
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

