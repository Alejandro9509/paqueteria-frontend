
CREATE PROCEDURE [dbo].[usp_CatFormatosCorreosModificar]
	@IdFormatoCorreo int,
	@FormatoCorreo varchar(50),
	@CadenaHTML ntext,
	@AsuntoCorreo varchar(150),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdFormatoCorreo,0) <= 0
		RAISERROR(N'El identificador del formato del correo es un campo requerido',
			16,
			1
			)	

	IF NOT EXISTS(SELECT IdFormatoCorreo FROM CatFormatosCorreos WHERE IdFormatoCorreo = @IdFormatoCorreo)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)						

	IF (SELECT ModificadoEl FROM CatFormatosCorreos WHERE IdFormatoCorreo = @IdFormatoCorreo) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta deducción fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)				

	IF LTRIM(RTRIM(@FormatoCorreo)) = ''
		RAISERROR(N'El nombre del formato de correo es requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(cast(@CadenaHTML as varchar(max)))) = ''
		RAISERROR(N'La cadena html es requerido',
			16,
			1
			)			

	IF LTRIM(RTRIM(@AsuntoCorreo)) = ''
			RAISERROR(N'El Asunto del correo es requerido',
				16,
				1
				)	
				
	UPDATE CatFormatosCorreos SET		
		FormatoCorreo = @FormatoCorreo,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		CadenaHTML = @CadenaHTML,
		AsuntoCorreo = @AsuntoCorreo 
	WHERE IdFormatoCorreo = @IdFormatoCorreo
			
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

