

CREATE PROCEDURE [dbo].[usp_CatGruposUnidadesEliminar]
	@IdGrupoUnidad int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION

	IF (SELECT DefinidoPorSistema FROM CatGruposUnidades WHERE IdGrupoUnidad = @IdGrupoUnidad) = 1
		RAISERROR(N'El gruppo de unidades que intenta eleminar es definido por sistema, no es posible eliminarlo',
			16,
			1
			)	
	
	--IF EXISTS(SELECT TOP 1 * FROM ProLiquidacionesGruposUnidades WHERE IdGrupoUnidad = @IdGrupoUnidad)
	--	RAISERROR(N'El concepto de deducción tiene liquidaciones asignados, no es posible eliminarlo',
	--		16,
	--		1
	--		)		
					
	DELETE FROM CatGruposUnidades
	WHERE IdGrupoUnidad = @IdGrupoUnidad
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

