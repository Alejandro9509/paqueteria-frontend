
CREATE PROCEDURE [dbo].[usp_CatClientesFacturacionEDIAgregar]
	@dsCatClientesFacturacionEDI ntext,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100)
AS
DECLARE
	@docHandle int,
	@CURSORIdClienteFactuacionEDI int,
	@CURSORIdCliente int,
	@CURSORActivo bit,
	@CURSORCarrier int,
	@CURSORSCAC varchar(50),
	@CURSORProtocolo int,
	@CURSORServidor  varchar(100),
	@CURSORCarpeta  varchar(50),
	@CURSORUsuario varchar(50),
	@CURSORContrasena varchar(50),
	@CURSORPuerto int,
	@CURSORArchivoLlave varchar(max)
	
BEGIN TRY
	BEGIN TRANSACTION

	IF @dsCatClientesFacturacionEDI IS NOT NULL
	BEGIN	
	
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatClientesFacturacionEDI

		SELECT ATT_IdClienteFactuacionEDI,ATT_IdCliente,ATT_Activo,ATT_Carrier,ATT_SCAC,ATT_Protocolo,ATT_Servidor,ATT_Carpeta,ATT_Usuario,ATT_Contrasena,ATT_Puerto,ATT_ArchivoLlave
		INTO #TempCatClientesFacturacionEDI
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ClientesFacturacionEDI',2) 
		WITH (ATT_IdClienteFactuacionEDI int,ATT_IdCliente int,ATT_Activo bit,ATT_Carrier int,ATT_SCAC varchar(50),ATT_Protocolo int,ATT_Servidor varchar(100),ATT_Carpeta varchar(50),ATT_Usuario varchar(50),ATT_Contrasena varchar(50),ATT_Puerto int,ATT_ArchivoLlave varchar(max))

		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CatClientesFacturacionEDICursor CURSOR FOR
		SELECT * FROM #TempCatClientesFacturacionEDI

		OPEN CatClientesFacturacionEDICursor
		FETCH NEXT FROM CatClientesFacturacionEDICursor
		INTO @CURSORIdClienteFactuacionEDI,@CURSORIdCliente,@CURSORActivo,@CURSORCarrier,@CURSORSCAC,@CURSORProtocolo,@CURSORServidor,@CURSORCarpeta,@CURSORUsuario,@CURSORContrasena,@CURSORPuerto,@CURSORArchivoLlave
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			 IF @CURSORIdClienteFactuacionEDI = 0
			BEGIN
				 INSERT INTO CatClientesFacturacionEDI(IdCliente,Activo,Carrier,SCAC,Protocolo,Servidor,Carpeta,Usuario,Contrasena,Puerto,ArchivoLlave,CreadoEl,CreadoPor)
				Values(@CURSORIdCliente,@CURSORActivo,@CURSORCarrier,@CURSORSCAC,@CURSORProtocolo,@CURSORServidor,@CURSORCarpeta,@CURSORUsuario,@CURSORContrasena,@CURSORPuerto,@CURSORArchivoLlave,@CreadoEl,@CreadoPor)
			END
			ELSE
			BEGIN
				--IF EXISTS(SELECT * FROM ProFacturasEDI As pfe Left Join ProFacturas As pf ON pfe.IdFactura = pf.IdFactura WHERE pf.IdCliente = @CURSORIdCliente)
				--RAISERROR(N'No se puede moficar el cliente porque tiene archivos 210 generados.',
				--	16,
				--	1
				--	)
				UPDATE CatClientesFacturacionEDI
				SET IdCliente =@CURSORIdCliente,
				Activo =@CURSORActivo,
				Carrier =@CURSORCarrier,
				SCAC =@CURSORSCAC,
				Protocolo =@CURSORProtocolo,
				Servidor =@CURSORServidor,
				Carpeta =@CURSORCarpeta,
				Usuario =@CURSORUsuario,
				Contrasena =@CURSORContrasena,
				Puerto =@CURSORPuerto,
				ModificadoEl =@CreadoEl,
				ModificadoPor =@CreadoPor
				WHERE IdClienteFacturacionEDI = @CURSORIdClienteFactuacionEDI
			END
			FETCH NEXT FROM CatClientesFacturacionEDICursor
			INTO @CURSORIdClienteFactuacionEDI,@CURSORIdCliente,@CURSORActivo,@CURSORCarrier,@CURSORSCAC,@CURSORProtocolo,@CURSORServidor,@CURSORCarpeta,@CURSORUsuario,@CURSORContrasena,@CURSORPuerto,@CURSORArchivoLlave
		END
		CLOSE CatClientesFacturacionEDICursor
		DEALLOCATE CatClientesFacturacionEDICursor

		DELETE FROM CatClientesFacturacionEDI WHERE  (ModificadoEl <> @CreadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @CreadoEl
	END



	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

