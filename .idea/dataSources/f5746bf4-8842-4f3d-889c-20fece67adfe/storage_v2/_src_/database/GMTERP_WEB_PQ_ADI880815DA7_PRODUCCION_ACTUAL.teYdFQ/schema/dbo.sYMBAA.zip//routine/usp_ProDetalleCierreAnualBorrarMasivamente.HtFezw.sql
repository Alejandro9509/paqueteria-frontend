
	CREATE PROCEDURE [dbo].[usp_ProDetalleCierreAnualBorrarMasivamente]
	/* *************************************************************************************************
	Procedimiento usp_ProDetalleCierreAnualBorrarMasivamente

	Parámetros: 

	01	@IdCierreAnual         (entrada, entero). Identificador del registro padre de los detalles           
	02  @IdPeticion            varchar(100)	  (entrada, string). Id de la Petición, generada en WEBDEV 

	Descripción: El procedimiento retira todos los registros de detalle del cierre anual, para ser sustituidos por otros.

	Implementada por: José Luis Cisneros G.
	Fecha de implementacion: 30/07/2020
	Versión ERP: 8.0.54.19

	Modificada por:   
	Fecha de mofidicacion: 
	Versión ERP: 

	Invocada desde: PAGE_ProCalculoAnualGenerar (Solicitud 2333)
	***************************************************************************************************** */
		@IdCierreAnual         int,                       
		@IdPeticion            VARCHAR(100)
	AS

	BEGIN TRY
		BEGIN TRANSACTION

		IF ISNULL(@IdCierreAnual,0) <= 0
				RAISERROR(N'El identificador del cierre anual es un campo requerido',	16,	1)


	DELETE FROM ProDetalleCierreAnual
		  WHERE IdCierreAnual = @IdCierreAnual
				AND AplicadoEl IS NULL

		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

