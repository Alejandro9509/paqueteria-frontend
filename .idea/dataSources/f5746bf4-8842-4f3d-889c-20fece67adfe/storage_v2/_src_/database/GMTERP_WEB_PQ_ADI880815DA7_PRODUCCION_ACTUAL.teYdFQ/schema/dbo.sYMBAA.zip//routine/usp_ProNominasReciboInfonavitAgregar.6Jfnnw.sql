CREATE PROCEDURE [dbo].[usp_ProNominasReciboInfonavitAgregar]
	@NumeroCredito varchar(40),
	@Descripcion varchar(40),
	@IdConceptoInfonavit int,
	@IdConceptoSeguro int,
	@IdEmpleado int,
	@Activo bit,
	@TipoCaptura int,
	@TipoCredito int,
	@FechaInicioAplicacion datetime,
	@FechaRegistro datetime,
	@Importe money,
	@VecesAplicado int,
	@MontoAcumulado decimal(15,2),
	@CreadoPor int,
	@CreadoEl datetime,	
	@IdPeticion varchar(100),
	@IdPeriodo int
AS
DECLARE
@NumeroConcepto int = 0,
@DescripcionConcepto varchar(40),
@IdProNominasReciboInfonavit int = 0,
@IdConceptoPDOFijo int =0,
@ImporteValor int = 1,
@Valor decimal(7,2) = 0
BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
		
		IF ISNULL(@NumeroCredito,'') = ''
		   RAISERROR(N'El numero de credito es un campo requerido',
				16,
				1
				)

		IF EXISTS(SELECT NumeroCredito FROM ProNominasReciboInfonavit WHERE NumeroCredito = @NumeroCredito )
		   RAISERROR(N'El numero de credito ya existe favor de verificarlo',
				16,
				1
				)
		
		IF @Descripcion = ''
			RAISERROR(N'La descripción es un campo requerido',
				16,
				1
				)

		IF isnull(@FechaInicioAplicacion, '') = ''
			RAISERROR(N'La fecha de inicio de aplicación es un campo requerido',
				16,
				1
				)	
		IF @TipoCaptura = 1
		BEGIN
			IF ISNULL(@IdConceptoInfonavit,0) = 0
			RAISERROR(N'El concepto de infonavit es un campo requerido',
				16,
				1
				)
			IF ISNULL(@IdConceptoSeguro,0) = 0
			RAISERROR(N'El concepto de seguro es un campo requerido',
				16,
				1
				)
		END
		ELSE
		BEGIN
			IF ISNULL(@IdConceptoInfonavit,0) = 0
				RAISERROR(N'El concepto de infonavit es un campo requerido',
					16,
					1
					)
		END
	
	INSERT INTO ProNominasReciboInfonavit(IdConceptoInfonavit,IdConceptoSeguro,IdEmpleado,NumeroCredito,Descripcion,Activo,FechaInicioAplicacion,FechaRegistro,TipoCaptura,TipoCredito,Importe,VecesAplicado,MontoAcumulado,CreadoPor,CreadoEl)
	VALUES(@IdConceptoInfonavit,@IdConceptoSeguro,@IdEmpleado,@NumeroCredito,@Descripcion,@Activo,@FechaInicioAplicacion,@FechaRegistro,@TipoCaptura,@TipoCredito,@Importe,@VecesAplicado,@MontoAcumulado,@CreadoPor,@CreadoEl)

	SET @IdProNominasReciboInfonavit = (SELECT IDENT_CURRENT('ProNominasReciboInfonavit'))

	IF @TipoCredito <> 1 
	BEGIN
		SET @ImporteValor  = 2
		SET @Valor  = @Importe
		SET @Importe = 0
	END

	--Sección para Insertar en CatConceptosPDOFijos el concepto de infonavit
	IF ISNULL(@IdConceptoInfonavit,0) <> 0 
	BEGIN
	
	SET @NumeroConcepto = (SELECT NumeroConcepto FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoInfonavit)
    SET @DescripcionConcepto = (SELECT Descripcion FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoInfonavit)
	
	INSERT INTO CatConceptosPDOFijos(Descripcion,IdConceptoPDO,FechaInicioAplicacion,
	VecesAplicado,MontoAcumulado,FechaRegistro,Activo,CreadoPor,
	CreadoEl,Importe,TipoConcepto,NumeroConcepto,DescripcionConcepto,IdEmpleado,NumeroControl,IdNominaReciboInfonavit,VecesAplicar,MontoLimite,ImporteValor,Valor)
	VALUES(@Descripcion,@IdConceptoInfonavit,@FechaInicioAplicacion,
	@VecesAplicado,@MontoAcumulado,@FechaRegistro,@Activo,@CreadoPor,
	@CreadoEl,@Importe,2,@NumeroConcepto,@DescripcionConcepto,@IdEmpleado,0,@IdProNominasReciboInfonavit,9999,9999999,@ImporteValor,@Valor)
	
	SET @IdConceptoPDOFijo  = (SELECT IDENT_CURRENT('CatConceptosPDOFijos'))
	UPDATE ProNominasReciboInfonavit SET IdConceptoPDOFijoInfonavit = @IdConceptoPDOFijo WHERE IdNominaReciboInfonavit =@IdProNominasReciboInfonavit 
	
	END

	--Sección para Insertar en CatConceptosPDOFijos el concepto de seguro de vivienda
	IF ISNULL(@IdConceptoSeguro,0) <> 0 
	BEGIN
	
	SET @NumeroConcepto = (SELECT NumeroConcepto FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoSeguro)
    SET @DescripcionConcepto = (SELECT Descripcion FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoSeguro)
	
	INSERT INTO CatConceptosPDOFijos(Descripcion,IdConceptoPDO,FechaInicioAplicacion,
	VecesAplicado,MontoAcumulado,FechaRegistro,Activo,CreadoPor,
	CreadoEl,Importe,TipoConcepto,NumeroConcepto,DescripcionConcepto,IdEmpleado,NumeroControl,IdNominaReciboInfonavit,VecesAplicar,MontoLimite,ImporteValor,Valor)
	VALUES('SEGURO DE VIVIENDA',@IdConceptoSeguro,@FechaInicioAplicacion,
	@VecesAplicado,@MontoAcumulado,@FechaRegistro,@Activo,@CreadoPor,
	@CreadoEl,0,2,@NumeroConcepto,@DescripcionConcepto,@IdEmpleado,0,@IdProNominasReciboInfonavit,9999,9999999,2,0)
	
	SET @IdConceptoPDOFijo  = (SELECT IDENT_CURRENT('CatConceptosPDOFijos'))
	UPDATE ProNominasReciboInfonavit SET IdConceptoPDOFijoSeguro = @IdConceptoPDOFijo WHERE IdNominaReciboInfonavit =@IdProNominasReciboInfonavit 
	
	END

	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	COMMIT
END TRY
BEGIN CATCH	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

