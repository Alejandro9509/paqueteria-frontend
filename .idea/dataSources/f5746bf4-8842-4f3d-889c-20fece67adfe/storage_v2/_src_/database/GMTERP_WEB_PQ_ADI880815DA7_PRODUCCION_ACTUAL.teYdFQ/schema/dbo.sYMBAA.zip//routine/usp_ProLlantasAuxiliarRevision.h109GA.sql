CREATE PROCEDURE [dbo].[usp_ProLlantasAuxiliarRevision]
@IdLlanta int,
@IdUnidad int,
@NumeroPosicionLlanta int,
@FechaHora datetime,
@IdEstatuLlanta int,
@PresionActual decimal (10, 2),
@ProfundidadRodamiento decimal(10, 2),
@KilometrajeDeLLanta int,
@KilometrajeHistorico int,
@CostoParaUnidad money,
@IdProcesoLlanta int,
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100),
@Refaccion bit,
@RevisadoPor nvarchar(50),
@Comentarios nvarchar(250),
@IdTipoLlanta int
AS
DECLARE 
	@MessageError varchar(8000),
	@IdOrdenServicioParte int,
	@IdOrdenServicio int,	
	@FolioOrdenServicio int,
	@Folio int 
BEGIN TRY
	BEGIN TRANSACTION
	
	SET @MessageError =''
	
	IF ISDATE(@FechaHora)= 0 
		RAISERROR(N'Fecha de Desasignación es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdLlanta,0)= 0 
		RAISERROR(N'Identificador de llanta es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdUnidad,0)= 0 
		RAISERROR(N'Identificador de unidad es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@NumeroPosicionLlanta,0)= 0 
		RAISERROR(N'No de posición de llanta es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdEstatuLlanta,0)= 0 
		RAISERROR(N'Identificador estatus de unidad es un campo requerido',
			16,
			1
			)
	
	IF EXISTS(SELECT IdUnidad FROM ProLlantas WHERE IdLlanta = @IdLlanta AND IdUnidad IS NULL) 
		RAISERROR(N'Llanta ya fue desasignado por otro usuario, revisar información ',
			16,
			1
			)
	
	IF ISNULL(@PresionActual,0)= 0 
		RAISERROR(N'Presión de llanta es un campo requerido',
			16,
			1
			)

	IF ISNULL(@ProfundidadRodamiento,0)= 0 
		RAISERROR(N'Profundidad de rodamiento de llanta es un campo requerido',
			16,
			1
			)
							

	IF ISNULL(@KilometrajeDeLLanta,0)= 0 
		RAISERROR(N'Kilometraje de llanta es un campo requerido',
			16,
			1
			)
	
	-- Validad que lla llanta no este asigado desde orden de servicio
	SET @IdOrdenServicioParte = (Select IdOrdenServicioParte From ProLlantas WHERE IdLlanta = @IdLlanta)
	DECLARE @NumeroEconomicoLlanta varchar(20)
	SET @NumeroEconomicoLlanta = (select NumeroEconomico from ProLlantas where IdLlanta = @IdLlanta)
	
	IF ISNULL(@IdOrdenServicioParte,0) != 0
		 BEGIN
			 SET  @IdOrdenServicio =
					  (SELECT ProOrdenesServiciosDetalles.IdOrdenServicio
						 FROM  ProOrdenesServiciosPartes INNER JOIN
							   ProOrdenesServiciosDetalles ON ProOrdenesServiciosPartes.IdOrdenServicioDetalle = ProOrdenesServiciosDetalles.IdOrdenServicioDetalle
						WHERE (ProOrdenesServiciosPartes.IdOrdenServicioParte = @IdOrdenServicioParte))
						
			SET @FolioOrdenServicio = (Select Folio From ProOrdenesServicios where IdOrdenServicio = @IdOrdenServicio)
	
			IF (SELECT CerradoEl FROM ProOrdenesServicios WHERE IdOrdenServicio = @IdOrdenServicio) IS NULL
				BEGIN
				
					 SET @MessageError ='La llanta '+@NumeroEconomicoLlanta+' que intenta desasignar pertencese a una orden de servicio folio '+CAST(@FolioOrdenServicio AS VARCHAR(10))+', debe desasignar desde la orden de servicio o terminar la orden' 
						 RAISERROR(@MessageError ,
							 16,
							 1
							 )
			 
				END

		END	
							
			             		
	-- Actualizar ProLlantas
	UPDATE ProLlantas SET IdUnidad = @IdUnidad,
						  NumeroPosicionLlanta = @NumeroPosicionLlanta,
						  CostoLlanta = CostoLlanta-@CostoParaUnidad,
						  ProfundidadActual =@ProfundidadRodamiento,
						  PresionActual = @PresionActual,
						  IdEstatuLlanta = @IdEstatuLlanta, 
						  KilometrajeLLanta=isnull(KilometrajeLLanta,0)+@KilometrajeDeLLanta,	
						  Refaccion = @Refaccion,
						  IdArticulo= NULL,
						  IdOrdenServicioParte= Null,
						  IdTipoLlanta = @IdTipoLlanta
						--  IdProcesoLlanta = @IdProcesoLlanta			  
	WHERE IdLlanta = @IdLlanta						   
	
	-- Registrar en Auxiliar de Llantas		
	SET @Folio = (SELECT ISNULL(MAX(Folio),0)+1 AS FolioRevision FROM ProLlantasAuxiliar)													
	INSERT INTO ProLlantasAuxiliar (IdLlanta,IdUnidad,NumeroPosicionLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta,Refaccion,RevisadoPor,Comentarios,Folio, IdTipoLlanta) 
		   VALUES (@IdLlanta,@IdUnidad,@NumeroPosicionLlanta,@FechaHora,@IdEstatuLlanta,@PresionActual,@ProfundidadRodamiento,@KilometrajeDeLLanta,@KilometrajeHistorico,@CostoParaUnidad,@CreadoPor,@CreadoEl,@IdProcesoLlanta,@Refaccion,@RevisadoPor,@Comentarios,@Folio,@IdTipoLlanta) 	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

