CREATE PROCEDURE [dbo].[usp_ProCobranzaRegistrarPagosAbonosNoBancarizados]
	@FechaHora datetime,	
	@Importe money,
	@TipoCambio money,
	@IdMonedaPago int,
	@ReferenciaBancaria varchar(50),
	@IdConceptoCobranza int,
	@IdCliente int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProFacturas ntext,
	@IdPeticion varchar(100),
	@PagoConContraRecibo bit, -- Bandera de pago con contra recibo 0= Pago normal / 1 = pago con contra recibo
	@IdCertificado int,
	@ClaveMetodoPago varchar(8),
	@CobranzaExterna bit,
	@IdCobranzaNoBancarizadoAnterior int = NULL,
	@MovimientoCFDI33 bit = NULL,
	@PagoConsolidado bit = NULL,
	@CuentaBancaria bit,
	@FechaSustitucion datetime = NULL


	--@IdCuentaBancaria int,  
	--@ImporteSaldoFavor money,	
	--@RfcEmisorCtaOrd varchar(15),
	--@NomBancoOrdExt varchar(100),
	--@CtaOrdenante varchar(20),
	--@TipoCodPago varchar(3),
	--@CertPago varchar(MAX),
	--@CadPago varchar(MAX),
	--@SelloPago varchar(MAX),
	
	--@MovimientoCFDI33 bit = NULL,
	--@FolioFiscalUUIDFactor varchar(36) = NULL,
	--@Compensacion money = NULL,
	--@XMLArchivoOdenante ntext = NULL,
	--@PagoConsolidado bit = NULL,
	
AS
DECLARE
	@docHandle int,
	@IdCobranzaNoBancarizado int,

	--@IdMovimientoBancario int,
	--@IdMonedaCtaBancaria int,
	@ImporteFacturas money,
	@ImporteClienteDLLS money,
	@ImporteClientePESOS money,
	@IdFactura int,
	@DoctoFactura varchar(50),
	@MensajeError varchar(250),
	@ATT_IdFactura int,
	@ATT_IdMoneda int,
	@ATT_IdSucursal int,
	@ATT_Importe money,
	@ATT_Referencia    varchar(50),
	@ATT_MetodoPago varchar(50),
	@IdCobranza int,
	@Porcentaje decimal(38,7),
	@ImpuestosTrasladadosFederales money,
	@ImpuestosRetenidosFederales money,
	@ImpuestosGenerales money,
	@ImpuestosTrasladadosLocales money,
	@ImpuestosRetenidosLocales money,
	@IdFacturaConceptoFacturacion int,
	@AbonoConcepto money,
	@Retiene bit,
	@Traslada bit,
	@NumeroMovimiento int,
	@Beneficiario varchar(150),
	@IdBeneficiario int,	
	@NumeroBeneficiario int,
	@ATT_IdContraReciboCliente int,
	@ImporteClienteDLLSContraRecibo money,
	@ImporteClientePESOSContraRecibo money,
	@IdConceptoCobranzaSaldoAFavor int,
	@Sustituto bit = 0,
	@ATT_EsFactoraje bit,
	@ATT_ImporteCompensacion money,
	@ATT_DocumentoConFactoraje int,
	@IdConceptoCobranzaFactoraje int,
	@IdContraReciboClienteFactura int,
	@IdClienteFactura int,
	@IdFacturaPedienteCobrar int,
	@ATT_ImporteImpuestoFactura money,
	@PorcentajeCalculoImpuesto decimal(38,7)
/*
MODIFICADO:
	Se agrego en el looper la columna MetodoPago , ademas se cambio @MetodoPago por MetodoPago para que la factura registrada en cobranza
	tenga la forma de pago que asigno el usuario.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-10-22
INVOCADA DESDE:
	ClsProCobranza::Agregar
SOLICITUD: 
	SOLICITUD 0000329


MODIFICADO:
	Se agrego cambio el tipo de calculo de los impuestos que se guardan en procobranzaimpuestos
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-05-14
INVOCADA DESDE:
	ClsProCobranza::Agregar
SOLICITUD: 
	SOLICITUD 001534

MODIFICADO:
	Se agregó un nuevo campo de @PorcentajeCalculoImpuesto para obtener el porcentaje de 
	impuestos que le toca del abono a cada factura, ademas de quitar la resta de los abonos al calculo del 
	importe de impuestos para cada uno y para las tablas de cobranza
MODIFICADA POR:
	David Omar Cabrera Bernal
FECHA DE MODIFICACIÓN:
	2020-09-29
INVOCADA DESDE:
	ClsProCobranza::Agregar
SOLICITUD: 
	SOLICITUD 003176

*/
BEGIN TRY
	BEGIN TRANSACTION
	    
	IF ISDATE(@FechaHora) = 0
		RAISERROR(N'La fecha del pago/abono es un campo requerido',
			16,
			1
			)


	IF ISNULL(@Importe,0) <= 0
		RAISERROR(N'El importe es un campo requerido',
			16,
			1
			)    

	IF ISNULL(@TipoCambio,0) <= 0
		RAISERROR(N'El tipo de cambio es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@ReferenciaBancaria)) = ''
		RAISERROR(N'La referencia es un campo requerido',
			16,
			1
			)                
    
	IF ISNULL(@IdConceptoCobranza,0) <= 0
		RAISERROR(N'El concepto de cobranza es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdCliente,0) <= 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
            
	IF @dsProFacturas IS NULL
		RAISERROR(N'Las facturas que se estan pagando son requeridos',
			16,
			1
			)
	


	IF ISNULL(@CuentaBancaria,0) = 0
	BEGIN
		IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizadoAnterior AND IdCobranzaNoBancarizadoAnterior  IS NOT NULL)
		RAISERROR(N'El pago que intenta relacionar ya fue sustituído',
			16,
			1
			)
	END
	ELSE
	BEGIN
		IF EXISTS(SELECT IdMovimientoBancario FROM ProMovimientosBancarios WHERE IdMovimientoBancario = @IdCobranzaNoBancarizadoAnterior AND IdMovimientoBancarioAnterior IS NOT NULL)
		RAISERROR(N'El pago que intenta relacionar ya fue sustituído',
			16,
			1
			)
	END


	
	--IF EXISTS(SELECT IdCobranzaNoBancarizado FROM ProCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizadoAnterior AND IdCobranzaNoBancarizadoAnterior  IS NOT NULL)
	--RAISERROR(N'El pago que intenta relacionar ya fue sustituído',
	--		16,
	--		1
	--		)
					
	IF NOT EXISTS(SELECT Ejercicio FROM ProEjerciciosPeriodos WHERE Ejercicio = YEAR(@FechaHora)) AND (Select isnull(Valor,0) From SisParametrosValores where Parametro = 'DeshabiltarContabilidadIntegrada')<> 1
		RAISERROR(N'El ejercicio contable no está abierto y por lo tanto no se puede registrar la información, contacte a su contador o al personal encargado de abrir el ejercicio contable',
			16,
			1
			)
			
	If @IdCertificado = 0
		SET @IdCertificado = NULL
		
	If @IdCobranzaNoBancarizadoAnterior = 0
		SET @IdCobranzaNoBancarizadoAnterior = NULL
	
	If @IdCobranzaNoBancarizadoAnterior IS NOT NULL
		SET @Sustituto = 1
		

	--se carga las facturas a una tabla temporal
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProFacturas
    
	SELECT ATT_IdFactura,ATT_Importe,ATT_IdMoneda,ATT_Referencia,ATT_IdSucursal,ATT_IdContraReciboCliente,ATT_EsFactoraje,ATT_ImporteCompensacion,ATT_DocumentoConFactoraje,ATT_IdCliente,ATT_MetodoPago
	INTO #TempProFacturas
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProFacturas',2) 
	WITH (ATT_IdFactura int,ATT_Importe money,ATT_IdMoneda int,ATT_Referencia varchar(50),ATT_IdSucursal int,ATT_IdContraReciboCliente int,ATT_EsFactoraje bit,ATT_ImporteCompensacion money,ATT_DocumentoConFactoraje int,ATT_IdCliente int,ATT_MetodoPago VARCHAR(50))
    
	EXEC sp_xml_removedocument @docHandle

	--SI ALGUNA FACTURA    
	--IdCliente != @IdCliente OR
	SET @IdFactura = (SELECT TOP 1 IdFactura FROM ProFacturas WHERE ( Estatus != 0 OR CanceladoEl IS NOT NULL OR ISNULL(Abonos,0) = Total) AND IdFactura IN(SELECT ATT_IdFactura FROM #TempProFacturas))
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)

		SET @MensajeError = 'La factura '+@DoctoFactura+' que esta intentando pagar no cumple con los criterios; Ya sea que no es de ese cliente, No tiene el estatus de pendiente de pago, Este cancelada o Ya fue pagada por otro usuario'

		RAISERROR(@MensajeError,
			16,
			1
			)
	END

			--SI ALGUNA FACTURA ESTA DENTRO DE UN CONTRA RECIBO SOLICITUD 10118
	SET @IdFactura = (select top 1 pcrcf.IdFactura from ProContraRecibosClienteFacturas as pcrcf
	inner join ProContraRecibosCliente as pcrc on pcrc.IdContraReciboCliente = pcrcf.IdContraReciboCliente
	where pcrcf.IdFactura IN (select ATT_IdFactura from #TempProFacturas) and pcrc.CanceladoEl is null)
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0 AND @PagoConContraRecibo = 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)

		--Se cambia mensaje de validacion para la solicitud 10118
		--SET @MensajeError = 'La factura '+@DoctoFactura+' que esta intentando pagar no cumple con los criterios; Ya sea que no es de ese cliente, No tiene el estatus de pendiente de pago, Este cancelada o Ya fue pagada por otro usuario'
		SET @MensajeError = 'No es posible aplicar el pago/abono a la '+@DoctoFactura+', ya que se encuentra dentro de un contra recibo.'
		RAISERROR(@MensajeError,
			16,
			1
			)
	END
	--FIN DE VALIDACION PARA SABER SI LA FACTURA ESTA DENTRO DE UN CONTRA RECIBO

	SET @ImporteFacturas = 0
	--OBTIENE LOS IMPORTES DE LA FACTURAS PAGADAS PARA ACTULIAZAR SALDO DE CLIENTYE
	SET @ImporteClienteDLLS = (SELECT ISNULL(SUM(ATT_Importe),0) FROM #TempProFacturas WHERE ATT_IdMoneda = 2)
	SET @ImporteClientePESOS = (SELECT ISNULL(SUM(ATT_Importe),0) FROM #TempProFacturas WHERE ATT_IdMoneda != 2)  
	
    IF @PagoConContraRecibo = 1  ----OR @ImporteSaldoFavor <= 0
    Begin
		IF @IdMonedaPago = 2 --DOLARES
		BEGIN
			IF @ImporteClientePESOS = 0
			BEGIN
				IF @Importe <> (@ImporteClienteDLLS)--+@ImporteSaldoFavor)
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)
			END
			ELSE
			BEGIN
				SET @ImporteFacturas = @Importe - ((@ImporteClientePESOS / @TipoCambio) + @ImporteClienteDLLS)
				IF @ImporteFacturas > 1 OR @ImporteFacturas < -1
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)			
			END
		END
		ELSE
		BEGIN
			IF @ImporteClienteDLLS = 0
			BEGIN
				IF @Importe <> (@ImporteClientePESOS)---+@ImporteSaldoFavor)
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)
			END
			ELSE
			BEGIN
				SET @ImporteFacturas = @Importe - ((@ImporteClienteDLLS * @TipoCambio) + @ImporteClientePESOS)
				IF @ImporteFacturas > 1 OR @ImporteFacturas < -1
				RAISERROR(N'El importe del pago/abono es diferente del importe de la suma de las facturas pagadas/abonadas',
					16,
					1
					)			
			END		
		END
	END
	
	SET @NumeroMovimiento = (Select ISNULL(MAX(NumeroMovimiento),0)+1 FROM ProCobranzaNoBancarizado where IdCliente = @IdCliente)
	-- SE REGISTRA EL PAGO/ABONO SIN CUENTA BANCARIA
	INSERT INTO ProCobranzaNoBancarizado(NumeroMovimiento,Fecha,Importe,TipoCambio,Referencia,CreadoEl,CreadoPor,IdCliente,IdMoneda,ClaveMetodoPago,IdCertificado,MovimientoCFDI33,Sustituto,FechaSustitucion)
	VALUES(@NumeroMovimiento,@FechaHora,@Importe,@TipoCambio,@ReferenciaBancaria,@CreadoEl,@CreadoPor,@IdCliente,@IdMonedaPago,@ClaveMetodoPago,@IdCertificado,@MovimientoCFDI33,@Sustituto,@FechaSustitucion)


	SET @IdCobranzaNoBancarizado = (SELECT IDENT_CURRENT('ProCobranzaNoBancarizado'))
	
	--seccion para agregar el IdCobranzaNoBancarizado a paremtros y poder obtenerlo de lado del web
	IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = @IdPeticion AND IdUsuario = @CreadoPor)
	BEGIN
		INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES(@IdPeticion,@IdCobranzaNoBancarizado,@CreadoPor)
	END
	ELSE
	BEGIN
		UPDATE SisParametrosPagina SET Parametros = @IdCobranzaNoBancarizado WHERE Pagina = @IdPeticion AND IdUsuario = @CreadoPor
	END

	--Actualiza el movimiento anterior (sustituido) Solicitud 8555
	IF ISNULL(@CuentaBancaria,0) = 0
	BEGIN
		IF @IdCobranzaNoBancarizadoAnterior IS NOT NULL
		begin
			UPDATE ProCobranzaNoBancarizado SET IdCobranzaNoBancarizadoAnterior = @IdCobranzaNoBancarizado WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizadoAnterior
		end
	END
	ELSE
	BEGIN /* MOVIMIENTO BANCARIO */ --el pago/abono con cuenta bancaria, fue sustituido por uno sin cuenta bancaria.
		IF @IdCobranzaNoBancarizadoAnterior IS NOT NULL
		begin
			--UPDATE ProCobranzaNoBancarizado SET IdMovimientoBancario = @IdCobranzaNoBancarizadoAnterior WHERE IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado
			UPDATE ProMovimientosBancarios SET IdCobranzaNoBancarizado = @IdCobranzaNoBancarizado WHERE IdMovimientoBancario = @IdCobranzaNoBancarizadoAnterior /*SE ACTUALIZA EN MOVIMIENTOS BANCARIOS */
		end
	END
    

	DECLARE ProFacturasCursor CURSOR FOR
	SELECT ATT_IdFactura,ATT_IdMoneda,ATT_IdSucursal,ATT_Importe,ATT_Referencia, ATT_IdContraReciboCliente,ATT_EsFactoraje,ATT_ImporteCompensacion,ATT_DocumentoConFactoraje,ATT_IdCliente,ATT_MetodoPago FROM #TempProFacturas WHERE ATT_Importe != 0  ORDER BY CASE WHEN ATT_IdCliente = @IdCliente THEN 0 ELSE ATT_IdCliente END
	OPEN ProFacturasCursor
	FETCH NEXT FROM ProFacturasCursor
	INTO @ATT_IdFactura,@ATT_IdMoneda,@ATT_IdSucursal,@ATT_Importe,@ATT_Referencia,@ATT_IdContraReciboCliente,@ATT_EsFactoraje,@ATT_ImporteCompensacion,@ATT_DocumentoConFactoraje,@IdClienteFactura,@ATT_MetodoPago
    
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdSucursal,Importe,Referencia,TipoCambio,CobranzaExterna,IdCertificado,ClaveMetodoPago,RequiereCuentaBancaria,IdCobranzaNoBancarizado,FechaSustitucion)
		VALUES(@CreadoEl,@CreadoPor,@FechaHora,CASE WHEN ISNULL(@IdClienteFactura,0)= 0 THEN @IdCliente ELSE @IdClienteFactura END,@IdConceptoCobranza,@ATT_IdFactura,@ATT_IdMoneda,@ATT_IdSucursal,@ATT_Importe,@ATT_Referencia,@TipoCambio,@CobranzaExterna,@IdCertificado,@ATT_MetodoPago,0,@IdCobranzaNoBancarizado,@FechaSustitucion)
        
        --valida si la factura es una factura general
        DECLARE @EsFactGeneral bit=0
        IF (SELECT TipoFactura FROM ProFacturas WHERE IdFactura = @ATT_IdFactura) = 7
			SET @EsFactGeneral = 1
        
		SET @IdCobranza = (SELECT IDENT_CURRENT('ProCobranza'))
        
		--se obtiene el porcentaje del abono sobre el saldo antes de aplicarle el abono del movimiento
		SET @Porcentaje = (SELECT (CAST(@ATT_Importe AS decimal(38,7))/CAST((Total-ISNULL(Abonos,0)) AS decimal(38,7))) FROM ProFacturas WHERE IdFactura = @ATT_IdFactura)
		SET @PorcentajeCalculoImpuesto = (SELECT ( CAST(@ATT_Importe AS decimal(38,10))/ CAST(Total AS  decimal(38,10))) FROM ProFacturas WHERE IdFactura = @ATT_IdFactura)
		
		IF (SELECT FacturaExterna FROM ProFacturas WHERE  IdFactura  = @ATT_IdFactura )  = 1 AND @CobranzaExterna <> 1
			RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
			16,
			1
			)

		--actualizo el abono en facturas
		UPDATE ProFacturas SET
			ProFacturas.Abonos = ISNULL(ProFacturas.Abonos,0) + @ATT_Importe,
			ProFacturas.Estatus = CASE WHEN (ISNULL(ProFacturas.Abonos,0)+ @ATT_Importe)= ProFacturas.Total THEN 1 ELSE ProFacturas.Estatus END,
			ProFacturas.ModificadoEl = @CreadoEl,
			ProFacturas.ModificadoPor = @CreadoPor,
			ProFacturas.EsFactoraje = @ATT_EsFactoraje
		WHERE IdFactura = @ATT_IdFactura                

        
                               
		--hago un cursor para afectar el abono a cada concepto de facturacion y obtener los importes base para el calculo de los impuestos                       
		DECLARE ProFacturasConceptosFacturacion CURSOR FOR
		SELECT IdFacturaConceptoFacturacion,RetieneImpuesto,TrasladaImpuesto FROM ProFacturasConceptosFacturacion WHERE IdFactura = @ATT_IdFactura
		
		OPEN ProFacturasConceptosFacturacion
		FETCH NEXT FROM ProFacturasConceptosFacturacion
		INTO @IdFacturaConceptoFacturacion,@Retiene,@Traslada
		
		SET @ImpuestosTrasladadosFederales = 0
		SET @ImpuestosRetenidosFederales = 0
		SET @ImpuestosGenerales = 0
		SET @ImpuestosTrasladadosLocales = 0
		SET @ImpuestosRetenidosLocales = 0

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @AbonoConcepto = (SELECT (Importe-ISNULL(Descuento,0)-ISNULL(Abonos,0))*@Porcentaje FROM ProFacturasConceptosFacturacion WHERE IdFacturaConceptoFacturacion = @IdFacturaConceptoFacturacion)
				
			UPDATE ProFacturasConceptosFacturacion SET
				Abonos = ISNULL(Abonos,0)+ROUND(@AbonoConcepto,4)
			WHERE IdFacturaConceptoFacturacion = @IdFacturaConceptoFacturacion
			
			INSERT INTO ProCobranzaFacturaConceptosFacturacion(IdFacturaConceptoFacturacion,IdCobranza,Importe)
			VALUES(@IdFacturaConceptoFacturacion,@IdCobranza,ROUND(@AbonoConcepto,4))
			
			IF @EsFactGeneral = 1
				SET @ImpuestosGenerales = @ImpuestosGenerales + @AbonoConcepto
				
			IF @Retiene = 1
				SET @ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales+@AbonoConcepto
				
			IF @Traslada = 1
				SET @ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales+@AbonoConcepto
		
			FETCH NEXT FROM ProFacturasConceptosFacturacion
			INTO @IdFacturaConceptoFacturacion,@Retiene,@Traslada
		END
		
		CLOSE ProFacturasConceptosFacturacion
		DEALLOCATE ProFacturasConceptosFacturacion
		
		IF @EsFactGeneral = 1
		BEGIN  
			DECLARE @IdImpuestoConcepto int,
			@PorcentajeImpuesto decimal(38,2)
			
			DECLARE ProFacturasImpuestosCursor CURSOR FOR
			SELECT IdImpuesto, Porcentaje, Importe FROM ProFacturasImpuestos WHERE IdFactura = @ATT_IdFactura
			
			OPEN ProFacturasImpuestosCursor
			FETCH NEXT FROM ProFacturasImpuestosCursor INTO @IdImpuestoConcepto, @PorcentajeImpuesto,@ATT_ImporteImpuestoFactura
			WHILE @@FETCH_STATUS = 0
			BEGIN
			
				DECLARE @PorcentajeIVA decimal(38,2),
				@TipoCalculo int,
				@NombreImpuestoXML varchar(10),
				@ImporteIVATraslado money, @ImporteImpuesto money
				
				SET @PorcentajeIVA = (SELECT Porcentaje FROM CatImpuestos WHERE IdImpuesto = @IdImpuestoConcepto)
				SET @TipoCalculo= (SELECT TipoCalculo FROM CatImpuestos WHERE IdImpuesto = @IdImpuestoConcepto)
				SET @NombreImpuestoXML = (SELECT NombreImpuestoXML FROM CatImpuestos WHERE IdImpuesto = @IdImpuestoConcepto)
				
				IF @TipoCalculo = 2 AND @NombreImpuestoXML = 'IVA'
					SET @ImporteImpuesto = (@ATT_ImporteImpuestoFactura * (@PorcentajeCalculoImpuesto))
				ELSE
					BEGIN
						IF @TipoCalculo = 1 AND @NombreImpuestoXML = 'IVA'
						BEGIN
							SET @ImporteIVATraslado = (@ATT_ImporteImpuestoFactura * (@PorcentajeCalculoImpuesto))
							SET @ImporteImpuesto = @ImporteIVATraslado
						END
						ELSE
							SET @ImporteImpuesto = (@ATT_ImporteImpuestoFactura * (@PorcentajeCalculoImpuesto))
					END
					
				INSERT INTO ProCobranzaImpuestos(IdCobranza,IdImpuesto,Importe,CreadoPor,CreadoEl)
				VALUES(@IdCobranza,@IdImpuestoConcepto,@ImporteImpuesto,@CreadoPor,@CreadoEl)	
				
				FETCH NEXT FROM ProFacturasImpuestosCursor INTO @IdImpuestoConcepto, @PorcentajeImpuesto,@ATT_ImporteImpuestoFactura
			END
			
			CLOSE ProFacturasImpuestosCursor
			DEALLOCATE ProFacturasImpuestosCursor
		END
		ELSE
		BEGIN      
			INSERT INTO ProCobranzaImpuestos(IdCobranza,IdImpuesto,Importe,CreadoPor,CreadoEl)
			SELECT @IdCobranza,pfi.IdImpuesto,
			((pfi.Importe*@PorcentajeCalculoImpuesto)) AS ImporteT
			,@CreadoPor,@CreadoEl
			FROM ProFacturasImpuestos AS pfi
			INNER JOIN CatImpuestos AS ci ON pfi.IdImpuesto = ci.IdImpuesto
			WHERE pfi.IdFactura = @ATT_IdFactura  
		END              
        IF @EsFactGeneral = 1
			BEGIN
				SET @ImpuestosTrasladadosFederales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 1 AND CatImpuestos.EsImpuestoFederal = 1)
				SET @ImpuestosRetenidosFederales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 2 AND CatImpuestos.EsImpuestoFederal = 1)
				SET @ImpuestosTrasladadosLocales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 1 AND CatImpuestos.EsImpuestoLocal = 1)
				SET @ImpuestosRetenidosLocales = (SELECT SUM(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 2 AND CatImpuestos.EsImpuestoLocal = 1)
				IF (SELECT CobranzaExterna FROM ProCobranza WHERE  IdCobranza  = @IdCobranza )  = 1 AND @CobranzaExterna <> 1
					RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
					16,
					1
					)
				--actualizo impuestos/importe sin iva en cobranza para el reporte de pagos
				UPDATE ProCobranza SET
					ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales,
					ImpuestosRetenidosLocales = @ImpuestosRetenidosLocales,
					ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales,
					ImpuestosTrasladadosLocales = @ImpuestosTrasladadosLocales,
					ImporteSinImpuestos = Importe - @ImpuestosTrasladadosFederales + @ImpuestosRetenidosFederales - @ImpuestosRetenidosLocales + @ImpuestosTrasladadosLocales
				WHERE IdCobranza = @IdCobranza
			END
        ELSE
			BEGIN
				SET @ImpuestosTrasladadosFederales = (SELECT sum(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 1)
				SET @ImpuestosRetenidosFederales = (SELECT sum(Importe) FROM ProCobranzaImpuestos INNER JOIN CatImpuestos ON ProCobranzaImpuestos.IdImpuesto = CatImpuestos.IdImpuesto    WHERE ProCobranzaImpuestos.IdCobranza = @IdCobranza AND CatImpuestos.TipoCalculo = 2)
				IF (SELECT CobranzaExterna FROM ProCobranza WHERE  IdCobranza  = @IdCobranza )  = 1 AND @CobranzaExterna <> 1
					RAISERROR(N'No se puede registrar este pago por que tiene que afectar abono de  una  factura externa',
					16,
					1
					)
				--actualizo impuestos/importe sin iva en cobranza para el reporte de pagos
				UPDATE ProCobranza SET
					ImpuestosRetenidosFederales = @ImpuestosRetenidosFederales,
					ImpuestosRetenidosLocales = 0,
					ImpuestosTrasladadosFederales = @ImpuestosTrasladadosFederales,
					ImpuestosTrasladadosLocales = 0,
					ImporteSinImpuestos = Importe - @ImpuestosTrasladadosFederales + @ImpuestosRetenidosFederales
				WHERE IdCobranza = @IdCobranza
			END
        
        -- Inicio alctualizar estatus de contra recibo de cliente
        IF @PagoConContraRecibo = 1 -- Bandera activa de pago con contra recibo
        BEGIN
			DECLARE @FolioContraRecibo int, @DocFacturaContraRecibo varchar(50)
			-- valida que el contra recibo no este cancelado
			SET @FolioContraRecibo = (Select Folio from ProContraRecibosCliente WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente)	
			IF EXISTS(Select IdContraReciboCliente from ProContraRecibosCliente where Estatus = 3 AND IdContraReciboCliente = @ATT_IdContraReciboCliente)	
			BEGIN		
				SET @MensajeError = 'El contra recibo de cliente '+@FolioContraRecibo +' que esta intentando pagar ya fue cancelada por otro usuario, verificar información'
				RAISERROR(@MensajeError,
							16,
							1
							)
			END	
						
			-- valida que la factura sea la que pertenece al contrarecibo 
			IF NOT EXISTS(Select IdContraReciboCliente from ProContraRecibosClienteFacturas where IdFactura = @ATT_IdFactura AND IdContraReciboCliente =@ATT_IdContraReciboCliente)
			BEGIN		
				SET @DocFacturaContraRecibo  = (SELECT CASE cf.Serie
															WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
															ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
														END
												FROM ProFacturas AS pf
													INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
													INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
												WHERE IdFactura = @IdFactura)
						
				SET @MensajeError = 'La factura '+@DocFacturaContraRecibo+' que esta intentando pagar ya no pertenece al contra recibo '+@FolioContraRecibo +', verificar información'

				RAISERROR(@MensajeError,
							16,
							1
							)
			END			
			
    		SET @ImporteClienteDLLSContraRecibo = 0
			SET @ImporteClientePESOSContraRecibo = 0  
           
			IF @ATT_IdMoneda = 2
				SET @ImporteClienteDLLSContraRecibo =@ATT_Importe
			ELSE
				SET @ImporteClientePESOSContraRecibo  =@ATT_Importe
			
			-- Actualiza la información en la tabla puente, asignando el IdCobranza si es nulo, o agregando un nuevo registro si ya tiene registrado un pago 
			IF (SELECT TOP 1 ISNULL(IdCobranza,0) FROM ProContraRecibosClienteFacturas WHERE IdFactura = @ATT_IdFactura ORDER BY IdContraReciboClienteFactura DESC) = 0
			--Se agrega el top 1 para evitar IdCobranza duplicado en caso de que existan mas registros de la factura con IdCobranza NULL SOLICITUD 010143
				BEGIN
					SET @IdContraReciboClienteFactura = (SELECT TOP 1 IdContraReciboClienteFactura FROM ProContraRecibosClienteFacturas WHERE IdFactura = @ATT_IdFactura ORDER BY IdContraReciboClienteFactura DESC)
					UPDATE TOP(1) ProContraRecibosClienteFacturas set IdCobranza = @IdCobranza where IdFactura = @ATT_IdFactura and IdContraReciboClienteFactura = @IdContraReciboClienteFactura
				END
			ELSE
				IF NOT EXISTS(SELECT IdCobranza FROM ProContraRecibosClienteFacturas WHERE IdFactura = @ATT_IdFactura AND IdCobranza = @IdCobranza)
				BEGIN
					INSERT INTO ProContraRecibosClienteFacturas (IdContraReciboCliente,IdFactura,Importe,IdCobranza) 
					values(@ATT_IdContraReciboCliente,@ATT_IdFactura,@ATT_Importe,@IdCobranza)
				END
			
			UPDATE ProContraRecibosCliente 
					SET TotalAbonoDolares =TotalAbonoDolares +@ImporteClienteDLLSContraRecibo 
					,TotalAbonoPesos=TotalAbonoPesos+@ImporteClientePESOSContraRecibo
			WHERE ProContraRecibosCliente.IdContraReciboCliente =  	@ATT_IdContraReciboCliente
			
		 -- Actualizar estatus	contra recibo de cliente  	
			DECLARE @CantidadFacturas int, @CantidadFacturasPagadas int
			SET @CantidadFacturas = (SELECT  count(ProFacturas.Estatus)
												FROM  ProContraRecibosClienteFacturas INNER JOIN
														ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
												WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @ATT_IdContraReciboCliente  AND ProFacturas.Estatus<> 2) )

			SET @CantidadFacturasPagadas =(SELECT  count(ProFacturas.Estatus)
												FROM  ProContraRecibosClienteFacturas INNER JOIN
														ProFacturas ON ProContraRecibosClienteFacturas.IdFactura = ProFacturas.IdFactura
												WHERE (ProContraRecibosClienteFacturas.IdContraReciboCliente = @ATT_IdContraReciboCliente  and ProFacturas.Estatus = 1 AND ProFacturas.Estatus<> 2 ))

			--Se comenta linea de codigo para cambiar el estatus de los contra recibos en cuanto tienen un abono solicitud 10118
			--IF @CantidadFacturasPagadas > 0 
				IF @CantidadFacturas = @CantidadFacturasPagadas
					UPDATE ProContraRecibosCliente SET Estatus = 2, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
					WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente  -- Pagada
				ELSE
					UPDATE ProContraRecibosCliente SET Estatus = 1, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
					WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente  -- Parcialmente pagada
			--Se agrega seccion para actualizar los saldos del contrarecibo SOLICITUD 10087
			--ELSE
			--	UPDATE ProContraRecibosCliente SET Estatus = 0, TotalSaldoPesos = TotalPesos -TotalAbonoPesos, TotalSaldoDolares = TotalDolares-TotalAbonoDolares 
			--	WHERE IdContraReciboCliente = @ATT_IdContraReciboCliente   -- Pendiente de pagar
			END	 
			-- Fin actualizar estatus de contra recibo de cliente        			        
			FETCH NEXT FROM ProFacturasCursor
			INTO @ATT_IdFactura,@ATT_IdMoneda,@ATT_IdSucursal,@ATT_Importe,@ATT_Referencia,@ATT_IdContraReciboCliente,@ATT_EsFactoraje,@ATT_ImporteCompensacion,@ATT_DocumentoConFactoraje,@IdClienteFactura,@ATT_MetodoPago
		END        
    
		CLOSE ProFacturasCursor
		DEALLOCATE ProFacturasCursor
		----Si Genero Saldo a Favor del Cliente, se Genera Un Registro de Cobranza  Adicional por el Concepto de SALDO A FAVOR
		--IF @ImporteSaldoFavor > 0
		--begin
		--	SET @IdConceptoCobranzaSaldoAFavor = (Select IdConceptoCobranza from CatConceptosCobranza Where ConceptoCobranza = 'SALDO A FAVOR' And DefinidoPorSistema = 1)
			
		--	INSERT INTO ProCobranza(CreadoEl,CreadoPor,FechaHora,IdCliente,IdConceptoCobranza,IdFactura,IdMoneda,IdMovimientoBancario,IdSucursal,Importe,Referencia,TipoCambio,Saldo,Secuencia)
		--	VALUES(@CreadoEl,@CreadoPor,@FechaHora,@IdCliente,@IdConceptoCobranzaSaldoAFavor,NULL,@IdMonedaCtaBancaria,@IdMovimientoBancario,NULL,@ImporteSaldoFavor,'SALDO A FAVOR',@TipoCambio,@ImporteSaldoFavor,0)        
		--end
    
		--verificar que la suma de cobranza por factura sea igual a los abonos
		SET @IdFactura = 
		(SELECT TOP 1 pf.IdFactura FROM ProFacturas AS pf 
		INNER JOIN #TempProFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura 
		WHERE ISNULL(pf.Abonos,0) != 
			(SELECT ISNULL(SUM(pc.Importe),0) FROM ProCobranza AS pc 
			INNER JOIN CatConceptosCobranza AS ccc ON pc.IdConceptoCobranza = ccc.IdConceptoCobranza 
			LEFT JOIN ProMovimientosBancarios AS pmb ON pc.IdMovimientoBancario = pmb.IdMovimientoBancario
			LEFT JOIN ProCobranzaNoBancarizado AS pcnb ON pc.IdCobranzaNoBancarizado = pcnb.IdCobranzaNoBancarizado
			WHERE ccc.TipoConcepto = 2 
			AND pc.IdFactura = pf.IdFactura 
			AND ((pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NULL AND pmb.CanceladoEl IS NULL AND pc.IdCobranzaNoBancarizado is null) 
				OR (pc.IdConceptoCobranza NOT IN(3,6) AND pmb.FolioFiscalUUIDPagos IS NOT NULL AND pmb.FechaCancelacionSAT IS NULL) 
				OR (pc.IdConceptoCobranza IN(3) AND pc.CanceladoEl IS NULL) 
				OR (pc.IdConceptoCobranza IN(6) AND pc.CanceladoEl IS NULL AND NOT EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor)) 
				OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND Secuencia=pc.Secuencia AND FolioFiscalUUIDPagos IS NOT NULL AND FechaCancelacionSAT IS NULL))
				OR (pc.IdConceptoCobranza = 6 AND EXISTS(SELECT FolioFiscalUUIDPagos FROM ProCobranzaSaldosAFavorTimbrados WHERE IdCobranzaSaldoAFavor=pc.IdCobranzaSaldoAFavor AND FolioFiscalUUIDPagos IS NULL AND pc.CanceladoEl IS NULL))
				)
			/*SOLICITUD 011473 - PAGO/ABONO SIN CUENTA BANCARIA*/
			OR (pc.IdCobranzaNoBancarizado <> 0 AND pc.CanceladoEl is NULL AND pc.IdFactura = pf.IdFactura)
			)
		)
		
		IF @IdFactura IS NOT NULL AND @IdFactura <> 0
		BEGIN
			SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)

		SET @MensajeError =    'El saldo de la factura* '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago a esta factura.'
                    
		RAISERROR(@MensajeError,
			16,
			1
			)            
	END

	--verificar que la suma de cobranza por factura sea igual a los abonos

	--Se comenta este codigo por error presentado en el cliente comandos
	--SET @IdFactura = (SELECT TOP 1 pf.IdFactura FROM ProFacturasConceptosFacturacion AS pf INNER JOIN #TempProFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura WHERE (pf.Importe > 0 AND ISNULL(pf.Abonos,0) > round(pf.Importe,2)) OR (pf.Importe < 0 AND ISNULL(pf.Abonos,0) < round(pf.Importe,2))) 
	SET @IdFactura = (SELECT TOP 1 pf.IdFactura FROM ProFacturasConceptosFacturacion AS pf INNER JOIN #TempProFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura WHERE (round(pf.Importe,2) > 0 AND round(ISNULL(pf.Abonos,0),2)> round(pf.Importe,2)) OR (pf.Importe < 0 AND round(ISNULL(pf.Abonos,0),0) < round(pf.Importe,2)))
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)
    
		SET @MensajeError =    'El saldo de un concepto de la factura '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago o una nota de crédito a esta factura.'
                    
		RAISERROR(@MensajeError,
			16,
			1
			)
	END
    
	--verificar que la suma de cobranza por factura sea igual a los abonos
	SET @IdFactura = (SELECT TOP 1 pf.IdFactura FROM ProFacturas AS pf INNER JOIN #TempProFacturas AS tpf ON pf.IdFactura = tpf.ATT_IdFactura WHERE ISNULL(pf.Abonos,0) > pf.Total)
	IF @IdFactura IS NOT NULL AND @IdFactura <> 0
	BEGIN
		SET @DoctoFactura = (SELECT CASE cf.Serie
			WHEN '' THEN ctd.Documento+' '+CAST(cf.Folio AS varchar)
			ELSE ctd.Documento+' '+CAST(cf.Folio AS varchar)+'-'+cf.Serie
		END
		FROM ProFacturas AS pf
		INNER JOIN CatFolios AS cf ON pf.IdFolio = cf.IdFolio
		INNER JOIN CatTiposDocumentos AS ctd ON cf.IdTipoDocumento = ctd.IdTipoDocumento
		WHERE IdFactura = @IdFactura)
    
		SET @MensajeError =    'El saldo de la factura '+@DoctoFactura+' es menor al importe a pagar, favor de revisar que otro usuario no haya realizado un pago a esta factura.'
                    
		RAISERROR(@MensajeError,
			16,
			1
			)
	END       

	--Solicitud 11939 
	DECLARE ProFacturasClientesSaldos CURSOR FOR
	SELECT ATT_IdCliente,ATT_IdFactura FROM #TempProFacturas -- se agrega el id de la factura para evitar sumar el total de las factura
			
	OPEN ProFacturasClientesSaldos
	FETCH NEXT FROM ProFacturasClientesSaldos INTO @IdClienteFactura, @IdFacturaPedienteCobrar
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @ImporteClienteDLLS = (SELECT ISNULL(ATT_Importe,0) FROM #TempProFacturas WHERE ATT_IdMoneda = 2 AND ATT_IdCliente = @IdClienteFactura and ATT_IdFactura = @IdFacturaPedienteCobrar) -- para evitar el valor en nulo se agrego isnull
		SET @ImporteClientePESOS = (SELECT ISNULL(ATT_Importe,0) FROM #TempProFacturas WHERE ATT_IdMoneda != 2 AND ATT_IdCliente = @IdClienteFactura AND ATT_IdFactura = @IdFacturaPedienteCobrar)
	
	IF @ImporteClienteDLLS > 0
	begin 
			UPDATE CatClientes SET 
			SaldoCreditoDLLS = SaldoCreditoDLLS - @ImporteClienteDLLS --se agrego isnull para evitar calcular errores al calcular el saldo 
			WHERE IdCliente = @IdClienteFactura				
	end
	IF @ImporteClientePESOS > 0
	begin 
		UPDATE CatClientes SET 
			SaldoCredito = SaldoCredito - @ImporteClientePESOS--se agrego isnull para evitar calcular errores al calcular el saldo 			
			WHERE IdCliente = @IdClienteFactura				
	end
		
		FETCH NEXT FROM ProFacturasClientesSaldos INTO @IdClienteFactura, @IdFacturaPedienteCobrar
	END
			
	CLOSE ProFacturasClientesSaldos
	DEALLOCATE ProFacturasClientesSaldos
    
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	--Seccion para cerrar los cursores en caso de algun error
	IF (SELECT CURSOR_STATUS('global','ProFacturasCursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','ProFacturasCursor')) > -1
		BEGIN
			CLOSE ProFacturasCursor
		END
	DEALLOCATE ProFacturasCursor
	END
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

