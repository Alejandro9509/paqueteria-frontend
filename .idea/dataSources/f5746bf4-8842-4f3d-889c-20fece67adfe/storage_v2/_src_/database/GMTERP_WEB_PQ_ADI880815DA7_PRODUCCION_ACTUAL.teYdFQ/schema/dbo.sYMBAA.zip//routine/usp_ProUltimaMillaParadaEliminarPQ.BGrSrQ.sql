
CREATE PROCEDURE [dbo].[usp_ProUltimaMillaParadaEliminarPQ]
	@IdParada int,
	@IdGuia int,
	@EsRecoleccion bit
AS

BEGIN TRY

	BEGIN TRANSACTION
	IF ISNULL(@IdParada,0) <= 0
		RAISERROR(N'El identificador es un campo requerido',
			16,
			1
			)	
							
	IF NOT EXISTS(SELECT @IdParada FROM ParadaUltimaMillaPQ WHERE m_nIdProParadaUltimaMilla = @IdParada)
		RAISERROR(N'El registro ya fue eliminado por otro usuario',
			16,
			1
			)
			

			if (Select count(*) from ProParadaUltimaMillaGuiasPQ where m_nIdParadaUltimaMilla = @IdParada) = 1  BEGIN
			
			DELETE FROM ParadaUltimaMillaPQ WHERE m_nIdProParadaUltimaMilla = @IdParada
			
			END
			If @EsRecoleccion = 1 BEGIN 
				UPDATE ProRecoleccionPQ SET IdEstatusRecoleccion =  (case when IdEstatusRecoleccion = 3 then 1 else IdEstatusRecoleccion end) where IdRecoleccion = @IdGuia
			END
			ELSE 
			BEGIN
			UPDATE ProGuiaPQ SET IdEstatusGuia = (case when IdEstatusGuia = 17  then 11 else IdEstatusGuia end) where IdGuia = @IdGuia
			
			END

			DELETE FROM ProParadaUltimaMillaGuiasPQ WHERE m_nIdParadaUltimaMilla = @IdParada and m_nIdGuia = @IdGuia and EsRecoleccion = @EsRecoleccion

				

	
	

	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdParada
END CATCH
go

