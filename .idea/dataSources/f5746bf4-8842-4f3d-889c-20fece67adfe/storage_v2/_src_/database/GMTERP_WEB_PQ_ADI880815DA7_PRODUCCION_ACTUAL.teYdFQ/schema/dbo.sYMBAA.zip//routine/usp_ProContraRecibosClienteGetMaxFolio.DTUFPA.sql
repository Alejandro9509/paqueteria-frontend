create PROCEDURE [dbo].[usp_ProContraRecibosClienteGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProContraRecibosCliente
go

