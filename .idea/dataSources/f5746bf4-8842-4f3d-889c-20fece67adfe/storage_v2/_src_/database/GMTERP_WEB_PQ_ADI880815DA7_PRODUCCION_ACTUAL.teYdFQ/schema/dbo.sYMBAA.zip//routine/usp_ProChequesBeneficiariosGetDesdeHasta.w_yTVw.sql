CREATE PROCEDURE [dbo].[usp_ProChequesBeneficiariosGetDesdeHasta]
AS
SELECT ISNULL(MAX(Beneficiario),'') AS Hasta,ISNULL(MIN(Beneficiario),'') AS Desde FROM ProCheques
go

