
CREATE PROCEDURE [dbo].[usp_CatLayoutsMantenimientoCargasCombustibleAgregar]
	@Layout	varchar(50),
	@TipoArchivo tinyint,
	@Separador	varchar(1),
	@RenglonInicial	tinyint,
	@ColumnaNumeroComprobante tinyint,
	@ColumnaTarjeta	tinyint,
	@FechaHoraJuntas bit,
	@ColumnaFechaHora tinyint,
	@FormatoFechaHora	varchar(26),
	@ColumnaFecha	tinyint,
	@FormatoFecha	varchar(15),
	@ColumnaHora	tinyint,
	@FormatoHora	varchar(15),
	@ColumnaLitros	tinyint,
	@TieneColumnaImporteIVA bit,
	@ColumnaImporteIVA	tinyint,
	@ColumnaTotal	tinyint,
	@ColumnaOdometro tinyint,
	@ColumnaOperador tinyint,
	@ColumnaReferencia tinyint,
	@ColumnaContenedor tinyint,
	@CreadoEl	datetime,
	@CreadoPor	int,
	@IdPeticion varchar(100)

	/* *************************************************************************************************
	SOLICITUD 12798

	Descripcion: Se creo el procedimiento almacenado para la creacion de formatos de importacion de cargas de combustible por el modulo de mantenimiento
	
	Implementada por:   Ignacio Perez
	Fecha de mofidicacion: 17/07/2019
	Versión: Versión 8.0.44.

	Invocada desde: <PAGE_CatLayoutsMantenimientoCargasCombustibleAM>
	************************************************************************************************ */
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)

		INSERT INTO CatLayoutsMantenimientoCargasCombustible(
			Layout,
			TipoArchivo,
			Separador,
			RenglonInicial,
			ColumnaNumeroComprobante,
			ColumnaTarjeta,
			FechaHoraJuntas,
			ColumnaFechaHora,
			FormatoFechaHora,
			ColumnaFecha,
			FormatoFecha,
			ColumnaHora,
			FormatoHora,
			ColumnaLitros,
			TieneColumnaImporteIVA,
			ColumnaImporteIVA,
			ColumnaTotal,
			ColumnaOdometro,
			ColumnaOperador,
			ColumnaReferencia,
			ColumnaContenedor,
			CreadoEl,
			CreadoPor)
		VALUES(
			@Layout,
			@TipoArchivo,
			@Separador,
			@RenglonInicial,
			@ColumnaNumeroComprobante,
			@ColumnaTarjeta,
			@FechaHoraJuntas,
			@ColumnaFechaHora,
			@FormatoFechaHora,
			@ColumnaFecha,
			@FormatoFecha,
			@ColumnaHora,
			@FormatoHora,
			@ColumnaLitros,
			@TieneColumnaImporteIVA,
			@ColumnaImporteIVA,
			@ColumnaTotal,
			@ColumnaOdometro,
			@ColumnaOperador,
			@ColumnaReferencia,
			@ColumnaContenedor,
			@CreadoEl,
			@CreadoPor)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

