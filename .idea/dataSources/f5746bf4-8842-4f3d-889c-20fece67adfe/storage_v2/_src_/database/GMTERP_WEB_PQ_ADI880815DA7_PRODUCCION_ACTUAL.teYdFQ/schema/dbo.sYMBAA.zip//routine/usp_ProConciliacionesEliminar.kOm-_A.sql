
	Create PROCEDURE [dbo].[usp_ProConciliacionesEliminar]
		@IdConciliacion int,
		@IdPeticion varchar(100)	
	AS
	DECLARE 
		@IdMovimientoBancario int
	BEGIN TRY
		BEGIN TRANSACTION
		
		IF ISNULL(@IdConciliacion,0)= 0
				RAISERROR(N'El identificador es un campo requerido',
						16,
						1
						)
		
		IF NOT EXISTS(SELECT IdConciliacion FROM ProConciliaciones WHERE IdConciliacion = @IdConciliacion ) 
				RAISERROR(N'El registro ya fue eliminado por otro usuario',
						16,
						1
						)	
					
				
		IF (SELECT Estatus FROM ProConciliaciones WHERE IdConciliacion = @IdConciliacion ) = 1
				RAISERROR(N'El registro no se puede eliminar, está conciliado',
						16,
						1
						)	
						
		DELETE FROM ProConciliaciones where  IdConciliacion = @IdConciliacion
		
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

