CREATE PROCEDURE [dbo].[usp_CatTiposPolizasGetMaxCodigo]

AS

SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTiposPolizas
go

