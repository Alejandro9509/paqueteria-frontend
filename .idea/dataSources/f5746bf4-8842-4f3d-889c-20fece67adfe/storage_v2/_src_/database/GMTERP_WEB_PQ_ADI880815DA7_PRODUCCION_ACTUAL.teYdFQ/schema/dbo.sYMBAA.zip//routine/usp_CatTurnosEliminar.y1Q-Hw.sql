
CREATE PROCEDURE [dbo].[usp_CatTurnosEliminar]
@IdTurno int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdTurno,0)= 0
	RAISERROR(N'El identificador del Turno es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT TOP 1 * FROM CatEmpleados WHERE IdTurno = @IdTurno)
			RAISERROR(N'El Turno no se puede eliminar ya que esta asignado a un Empleado.',
				16,
				1
				)

			
		DELETE CatTurnos		
		WHERE 	IdTurno=@IdTurno
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

