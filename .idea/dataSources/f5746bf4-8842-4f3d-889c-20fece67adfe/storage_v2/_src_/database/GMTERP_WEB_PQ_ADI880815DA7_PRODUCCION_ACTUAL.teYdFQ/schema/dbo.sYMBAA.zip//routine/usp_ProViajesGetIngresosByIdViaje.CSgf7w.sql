
CREATE PROCEDURE [dbo].[usp_ProViajesGetIngresosByIdViaje]
	@IdUsuario int,
	@IdViaje int,
	@IdMoneda int
AS
DECLARE @Importe money

IF @IdMoneda = 2 
BEGIN
SET @Importe = ISNULL((SELECT SUM(CASE pv.IdMoneda
						WHEN 2 THEN pvcf.Importe
						ELSE pvcf.Importe / pv.TipoCambio
						END) 
						AS Importe
						FROM ProViajesConceptosFacturacion AS pvcf
						INNER JOIN ProViajes AS pv ON pvcf.IdViaje = pv.IdViaje
						WHERE pvcf.IdViaje = @IdViaje
						AND pvcf.IncluirCalculoIngresosLiquidacion = 1
				),0)
END
ELSE
BEGIN
SET @Importe = ISNULL((SELECT SUM(CASE pv.IdMoneda
						WHEN 1 THEN pvcf.Importe
						ELSE pvcf.Importe * pv.TipoCambio
						END) 
						AS Importe
						FROM ProViajesConceptosFacturacion AS pvcf
						INNER JOIN ProViajes AS pv ON pvcf.IdViaje = pv.IdViaje
						WHERE pvcf.IdViaje = @IdViaje
						AND pvcf.IncluirCalculoIngresosLiquidacion = 1
				),0)
END
IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'GetIngresosByIdViaje' AND IdUsuario = @IdUsuario)
INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('GetIngresosByIdViaje',@Importe,@IdUsuario)
ELSE
UPDATE SisParametrosPagina SET Parametros = @Importe WHERE Pagina = 'GetIngresosByIdViaje' AND IdUsuario = @IdUsuario
go

