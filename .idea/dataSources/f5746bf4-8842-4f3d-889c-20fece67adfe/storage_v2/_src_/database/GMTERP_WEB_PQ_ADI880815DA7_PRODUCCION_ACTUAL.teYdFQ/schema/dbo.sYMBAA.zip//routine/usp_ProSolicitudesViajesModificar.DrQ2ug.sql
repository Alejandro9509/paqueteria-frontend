CREATE PROCEDURE [dbo].[usp_ProSolicitudesViajesModificar]
	@IdCliente int,
	@IdSolicitudViaje int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@Consecutivo int,
	@Correo varchar(100),
	@Telefono varchar(20),
	@LoadNumber varchar(20),
	@IdOrigen int,
	@IdDestino int,
	@PesoEstimado decimal(15,4),
	@IdUnidadMedida int,
	@FechaHoraCarga datetime,
	@FechaHoraDescarga datetime,
	@SeRecogeraEn varchar(100),
	@SeEntregaraEn varchar(100),
	@Observaciones varchar(512),
	@CantidadPedida smallint,
	@dsDetalleEquipo ntext,
	@IdPeticion varchar(100)
AS
DECLARE
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION
	
	IF (SELECT Estatus FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje) <> 2
		RAISERROR(N'La solicitud no se puede modificar debido a que fue cambiado su estatus',
			16,
			1
			)
	IF NOT EXISTS(SELECT IdSolicitudViaje FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje)
		RAISERROR(N'Este registro fue eliminado por otro usuario',
			16,
			1
			)	
	IF (SELECT ModificadoEl FROM ProSolicitudesViajes WHERE IdSolicitudViaje = @IdSolicitudViaje) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta solicitud fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)
				
	IF @Consecutivo = 0
		RAISERROR(N'El numero de solicitud es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Consecutivo FROM ProSolicitudesViajes WHERE Consecutivo = @Consecutivo AND IdCliente=@IdCliente AND IdSolicitudViaje <> @IdSolicitudViaje)
		RAISERROR(N'El numero de solicitud ya existe',
			16,
			1
			)
		
	IF @CantidadPedida = 0
		RAISERROR(N'Es necesario seleccionar al menos un equipo',
			16,
			1
			)
				
	IF LTRIM(RTRIM(@SeRecogeraEn)) = ''
		RAISERROR(N'Se recogera en, es un campo requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@SeEntregaraEn)) = ''
		RAISERROR(N'Se entregara en, es un campo requerido',
			16,
			1
			)
	IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)
	IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)
	IF (LTRIM(RTRIM(@FechaHoraCarga)) = '' OR @FechaHoraCarga IS NULL)
		RAISERROR(N'La fecha de carga es un campo requerido',
			16,
			1
			)		
	
	---Actualizamos la clase ProSolicitudesViajes
	UPDATE ProSolicitudesViajes SET
	Consecutivo = @Consecutivo,
	Correo = @Correo,
	Telefono = @Telefono,
	LoadNumber = @LoadNumber,
	IdOrigen = @IdOrigen,
	IdDestino = @IdDestino,
	FechaHoraCarga = @FechaHoraCarga,
	FechaHoraDescarga = @FechaHoraDescarga,
	SeRecogeraEn = @SeRecogeraEn,
	SeEntregaraEn = @SeEntregaraEn,
	PesoEstimado = @PesoEstimado,
	IdUnidadMedida = @IdUnidadMedida,
	Observaciones = @Observaciones,
	CantidadPedida = @CantidadPedida,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl
	WHERE IdSolicitudViaje = @IdSolicitudViaje
	
	---Insertamos en la tabla ProSolicitudesViajesDetalleEquipo
	IF @dsDetalleEquipo IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsDetalleEquipo
		
		SELECT ATT_IDTipoEquipo,ATT_CantidadEquipo,ATT_IDSolicitudesViajeDetalleEquipo
		INTO #TempDetalleEquipo
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_DetalleEquipo',2) 
		WITH (ATT_IDTipoEquipo int,ATT_CantidadEquipo smallint, ATT_IDSolicitudesViajeDetalleEquipo int)
		
		EXEC sp_xml_removedocument @docHandle
		
		--Actualizamos lo existente
		UPDATE ProSolicitudesViajesDetalleEquipo 
		SET ProSolicitudesViajesDetalleEquipo.IdSolicitudViaje = @IdSolicitudViaje, 
		ProSolicitudesViajesDetalleEquipo.IdTipoUnidad = #TempDetalleEquipo.ATT_IDTipoEquipo,
		ProSolicitudesViajesDetalleEquipo.CantidadPedida = #TempDetalleEquipo.ATT_CantidadEquipo
		FROM ProSolicitudesViajesDetalleEquipo INNER JOIN #TempDetalleEquipo
		ON ProSolicitudesViajesDetalleEquipo.IdSolicitudViajeDetalleEquipo = #TempDetalleEquipo.ATT_IDSolicitudesViajeDetalleEquipo
		
		--Borramos lo inexistente
		DELETE FROM ProSolicitudesViajesDetalleEquipo WHERE IdSolicitudViaje = @IdSolicitudViaje AND IdSolicitudViajeDetalleEquipo NOT IN (SELECT ATT_IDSolicitudesViajeDetalleEquipo FROM #TempDetalleEquipo WHERE ATT_IDSolicitudesViajeDetalleEquipo <> 0 AND ATT_CantidadEquipo > 0)
		
		--Agregamos lo nuevo
		INSERT INTO ProSolicitudesViajesDetalleEquipo(IdSolicitudViaje,IdTipoUnidad,CantidadPedida)
		SELECT @IdSolicitudViaje,ATT_IDTipoEquipo,ATT_CantidadEquipo FROM #TempDetalleEquipo WHERE ATT_CantidadEquipo > 0 AND ATT_IDSolicitudesViajeDetalleEquipo = 0
	END
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

