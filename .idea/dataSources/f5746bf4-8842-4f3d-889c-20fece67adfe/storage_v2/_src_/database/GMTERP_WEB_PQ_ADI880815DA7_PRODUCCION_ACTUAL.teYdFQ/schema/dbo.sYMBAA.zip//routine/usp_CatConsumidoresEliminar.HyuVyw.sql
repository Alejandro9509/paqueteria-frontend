CREATE PROCEDURE [dbo].[usp_CatConsumidoresEliminar]
@IdConsumidor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdConsumidor,0)= 0
		RAISERROR(N'El identificador del Almacén es un campo requerido',
				16,
				1
				)
				
	IF EXISTS(SELECT TOP 1 IdConsumidor FROM ProMovimientosAlmacen WHERE IdConsumidor = @IdConsumidor)
			RAISERROR(N'El Consumidor esta ligado a un movimiento de almacen, no es posible eliminarlo',
				16,
				1
				)

		DELETE CatConsumidores	
		WHERE 	IdConsumidor=@IdConsumidor
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

