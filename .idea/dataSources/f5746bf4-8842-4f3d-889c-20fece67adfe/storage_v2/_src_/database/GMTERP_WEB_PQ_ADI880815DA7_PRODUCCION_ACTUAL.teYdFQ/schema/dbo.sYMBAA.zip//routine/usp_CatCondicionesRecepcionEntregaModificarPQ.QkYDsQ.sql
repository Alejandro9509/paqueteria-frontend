
CREATE PROCEDURE [dbo].[usp_CatCondicionesRecepcionEntregaModificarPQ](
	@IdCondicionesRecepcionEntrega int,
	@ID int,
	@Descripcion varchar(50),
	@Activo bit)
	AS
BEGIN 
	BEGIN TRANSACTION

	IF ISNULL(@IdCondicionesRecepcionEntrega, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador de Codiciones Recepcion Entrega requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end
			IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La Descripción es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@ID, 0) <= 0 begin
			RAISERROR(N'*INICIO*El ID del producto es un campo requerido*FIN*', 16, 1);
			GOTO CANCELAR_TRANSACCION
			return;
		end

		

		UPDATE CatCondicionesRecepcionEntregas
		SET
		ID=@ID ,
		Descripcion=@Descripcion ,
		Activo=@Activo
		 
		WHERE IdCondicionesRecepcionEntrega = @IdCondicionesRecepcionEntrega;
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

		CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
		END
end
go

