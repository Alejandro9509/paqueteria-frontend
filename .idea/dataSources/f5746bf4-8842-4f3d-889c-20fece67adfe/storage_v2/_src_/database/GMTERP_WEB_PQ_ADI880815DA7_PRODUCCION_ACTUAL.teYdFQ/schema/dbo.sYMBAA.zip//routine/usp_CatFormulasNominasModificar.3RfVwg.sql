CREATE PROCEDURE [dbo].[usp_CatFormulasNominasModificar]
@IdFormulaNomina int,
@Codigo int,
@Nombre  varchar(50), 
@Expresion  ntext,   
@DefinidoPorSistema bit,
@dsVariables ntext,
@ModificadoEl    datetime,    
@ModificadoPor    int,    
@IdPeticion varchar(100),
@dsTodasVariables ntext,
@Ayuda Varchar(100),
@EsFuncion bit

AS
DECLARE	
	@docHandle int,
	@ATT_IdVariable int,
	@ATT_IdFormulaNominaVariable int,
	@ATT_IdVariable2 int,
	@ATT_Nombre Varchar(50),
	@ATT_Query Varchar(Max),
	@ATT_TipoDeDato int,
	@IdVariable int,
	@ATT_Nombre2 Varchar(50),
	@ATT_Categoria int	
BEGIN TRY
    BEGIN TRANSACTION            
    If ISNULL(@IdFormulaNomina ,0) = 0
		RAISERROR(N'El Id de la Fórmula es un campo requerido',
            16,
            1
            )
    IF ISNULL(@Codigo,0)= 0
        RAISERROR(N'El código de la Fórmula es un campo requerido',
            16,
            1
            )
	IF @Expresion is null 
        RAISERROR(N'La definición de la Fórmula es un campo requerido',
            16,
            1
            )    
    Update CatFormulasNominas
    SET
    Codigo=@Codigo,
    Nombre=@Nombre,
    Expresion=@Expresion,
    DefinidoPorSistema=@DefinidoPorSistema,
    ModificadoEl = @ModificadoEl,
    ModificadoPor=@ModificadoPor,
    Ayuda = @Ayuda,
    EsFuncion=@EsFuncion
    Where IdFormulaNomina = @IdFormulaNomina
        
    --SI HAY VARIABLES NUEVAS QUE SE DIERON DE ALTA LAS AGREGAMOS SI Y SI HAY MODIFICADAS SE MODIFICAN SI NO SE BORRAN.
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsTodasVariables
	
	SELECT ATT_IdVariable,ATT_Nombre,ATT_Query,ATT_TipoDeDato,ATT_Categoria
	INTO #TempCatTodasVariables
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatVariables',2) 
	WITH (ATT_IdVariable int,ATT_Nombre Varchar(50),ATT_Query ntext,ATT_TipoDeDato int,ATT_Categoria int )
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatTodasVariables CURSOR FOR
	SELECT * FROM #TempCatTodasVariables
	
	OPEN CursorCatTodasVariables
	FETCH NEXT FROM CursorCatTodasVariables
	INTO @ATT_IdVariable2,@ATT_Nombre,@ATT_Query,@ATT_TipoDeDato,@ATT_Categoria
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    If @ATT_Categoria = 0 
	        Set @ATT_Categoria = NULL
		IF @ATT_IdVariable2 = 0
		begin
			INSERT INTO CatVariables(Nombre,Query,TipoDeDato,CreadoEl,CreadoPor,IdVariableCategoria)
			VALUES(@ATT_Nombre,@ATT_Query,@ATT_TipoDeDato,@ModificadoEl,@ModificadoPor,@ATT_Categoria)		
		end
		else
		begin
			Update CatVariables
			Set Nombre = @ATT_Nombre,
			Query = @ATT_Query,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor,
			TipoDeDato = @ATT_TipoDeDato,
			IdVariableCategoria = @ATT_Categoria
			Where IdVariable = @ATT_IdVariable2
		end

		FETCH NEXT FROM CursorCatTodasVariables
		INTO @ATT_IdVariable2,@ATT_Nombre,@ATT_Query,@ATT_TipoDeDato,@ATT_Categoria
	END
    CLOSE CursorCatTodasVariables
	DEALLOCATE CursorCatTodasVariables
	
	DELETE FROM CatVariables WHERE ((ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl)
	And IdVariable not in(Select IdVariable From CatFormulasNominasVariables)
	
    --SECCION PARA AGREGAR A LA TABLA PUENTE LAS VARIABLES QUE ESTAN CONTENIDAS EN LA FORMULA.
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsVariables
	
	SELECT ATT_IdVariable,ATT_IdFormulaNominaVariable,ATT_Nombre
	INTO #TempCatVariables
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Variables',2) 
	WITH (ATT_IdVariable int,ATT_IdFormulaNominaVariable int,ATT_Nombre Varchar(50))
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatVariables CURSOR FOR
	SELECT * FROM #TempCatVariables
	
	OPEN CursorCatVariables
	FETCH NEXT FROM CursorCatVariables
	INTO @ATT_IdVariable,@ATT_IdFormulaNominaVariable,@ATT_Nombre2
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @ATT_IdFormulaNominaVariable = 0
		BEGIN	
			If @ATT_IdVariable = 0
			begin
				Set @IdVariable  = (Select IdVariable From CatVariables Where Nombre = @ATT_Nombre2 And CreadoEl = @ModificadoEl And CreadoPor = @ModificadoPor)			
			end
			INSERT INTO CatFormulasNominasVariables(IdFormulaNomina,IdVariable,CreadoEl,CreadoPor)
			VALUES(@IdFormulaNomina,@ATT_IdVariable,@ModificadoEl,@ModificadoPor)		
		END
		ELSE
		BEGIN
			Update CatFormulasNominasVariables
			Set IdVariable = @ATT_IdVariable,
			ModificadoEl = @ModificadoEl,
			ModificadoPor = @ModificadoPor
			Where IdFormulaNominaVariable = @ATT_IdFormulaNominaVariable
		END
		

		FETCH NEXT FROM CursorCatVariables
		INTO @ATT_IdVariable,@ATT_IdFormulaNominaVariable,@ATT_Nombre2
	END

	CLOSE CursorCatVariables
	DEALLOCATE CursorCatVariables
	
	DELETE FROM CatFormulasNominasVariables WHERE IdFormulaNomina = @IdFormulaNomina AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

