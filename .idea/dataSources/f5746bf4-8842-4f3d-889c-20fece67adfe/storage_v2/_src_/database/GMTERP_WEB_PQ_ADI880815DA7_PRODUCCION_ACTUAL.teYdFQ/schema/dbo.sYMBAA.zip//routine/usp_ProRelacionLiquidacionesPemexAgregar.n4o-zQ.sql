
CREATE PROC [dbo].[usp_ProRelacionLiquidacionesPemexAgregar]
    @Anio int,
    @NoRelacion int,
    @FechaCreacion datetime,
    @IdCliente int,
    @IdCombustible int,
    @TipoTanque int,
	@VeinteMovs bit,
	@IdOrigenes varchar(500),
	@Estatus int,
    @CreadoEl datetime,
    @CreadoPor int,
    @ModificadoEl datetime,
    @ModificadoPor int,
    @ViajesXML ntext = NULL,
    @IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_ProRelacionLiquidacionesPemexAgregar

Parámetros:
    @Anio              (entrada, entero). Año del número relación de la liquidación PEMEX.
    @NoRelacion        (entrada, entero). Número relación de la liquidación PEMEX.
    @FechaCreacion     (entrada, fecha hora). Fecha y hora en que fue creado la relación liquidación PEMEX.
    @IdCliente         (entrada, entero). Identificador del cliente.
    @IdCombustible     (entrada, entero). Identificador del combustible.
    @TipoTanque        (entrada, entero). Indica el tipo de tanque de la relación liquidación PEMEX.
	@VeinteMovs        (entrada, booleano). Indica si la relación filtró únicamente 20 cartas porte.
	@IdOrigenes        (entrada, texto). Son los Id de los Orígenes por los que filtró las carta porte.
	@Estatus           (entrada, entero). Indica el estado de la Relación.
    @CreadoEl          (entrada, fecha hora). Fecha y hora en la que fue creado el registro.
    @CreadoPor         (entrada, entero). Id del usuario que creo el registro.
    @ModificadoEl      (entrada, fecha hora). Fecha y hora en la que fue modificado el registro.
    @ModificadoPor     (entrada, entero). Id del usuario que modifico el registro.
    @ViajesXML         (entrada, xml). XML que contiene la información de los viajes.
    @IdPeticion        (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para agregar una nueva Relación Liquidación PEMEX.

28/02/2020 - Se creó.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 28/02/2020
Versión ERP: 8.0.50.22

Invocada desde: PAGE_ProRelacionLiquidacionPemexAMC (Solicitud 920)
***************************************************************************************************** */
AS
DECLARE
	@docHandle int,
    @IdProRelacionLiquidacionesPemex int
BEGIN TRY
	BEGIN TRANSACTION
    -- Validaciones
    IF @Anio = 0
        RAISERROR(N'El número de relación es un campo requerido', 16, 1)

    IF @NoRelacion = 0
        RAISERROR(N'El número de relación es un campo requerido', 16, 1)

    IF EXISTS(SELECT NoRelacion FROM ProRelacionLiquidacionesPemex WHERE NoRelacion = @NoRelacion)
        RAISERROR(N'Ya existe una liquidación pemex con el número de relación ingresado, favor de ingresar otro número de relación', 16, 1)

    IF @IdCliente = 0
        RAISERROR(N'El id de cliente es un campo obligatorio', 16, 1)

    IF @IdCombustible = 0
        RAISERROR(N'El id del tipo de material es un campo obligatorio', 16, 1)

    -- Inserta el registro en la tabla principal de la relación PEMEX
    INSERT INTO ProRelacionLiquidacionesPemex(Anio, NoRelacion, FechaCreacion, IdCliente, IdCombustible, TipoTanque, VeinteMovs, IdOrigenes, Estatus, FechaCancelacion, MotivoCancelacion, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor)
    VALUES(@Anio, @NoRelacion, @FechaCreacion, @IdCliente, @IdCombustible, @TipoTanque, @VeinteMovs, @IdOrigenes, @Estatus, NULL, NULL, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor)

    -- Obtiene el valor de Id que se acaba de registrar en ProRelacionLiquidacionesPemex
    SET @IdProRelacionLiquidacionesPemex = (SELECT IDENT_CURRENT('ProRelacionLiquidacionesPemex'))

    -- Extrae información del XML y la almacena en una tabla temporal
    EXEC sp_xml_preparedocument @docHandle OUTPUT, @ViajesXML

    -- Se crea tabla temporal que guardará la información de los viajes
    SELECT ATT_IdViajeCartaPorteConocimientoEmbarque, ATT_IdViajeCartaPorte, ATT_IdViaje, ATT_FolioViaje, ATT_Fecha, ATT_Destino, ATT_NoEmbarque, ATT_Secuencia
    INTO #TempProRelacionLiquidacionesPemex
    FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProRelacionLiquidacionesPemex', 2)
    WITH (ATT_IdViajeCartaPorteConocimientoEmbarque int,
			ATT_IdViajeCartaPorte int,
			ATT_IdViaje int,
			ATT_FolioViaje int,
			ATT_Fecha datetime,
			ATT_Destino varchar(50),
			ATT_NoEmbarque int,
			ATT_Secuencia INT)

    -- Valida que no existe alguna carta porte ligada a otra relación 
    IF EXISTS(SELECT IdViaje FROM ProRelacionLiquidacionesPemexDetalle INNER JOIN #TempProRelacionLiquidacionesPemex ON IdViaje = ATT_IdViaje WHERE CanceladoEl IS NULL)
        RAISERROR(N'Algunas de las cartas porte seleccionadas ya existen en otras relaciones de liquidación, favor de revisar', 16, 1)

    -- Valida que las carta porte no estén canceladas
    IF EXISTS(SELECT IdViaje FROM ProViajes INNER JOIN #TempProRelacionLiquidacionesPemex ON IdViaje = ATT_IdViaje WHERE CanceladoEl != NULL)
        RAISERROR(N'Algunas de las cartas porte seleccionadas están canceladas, favor de revisar', 16, 1)

    -- Inserta información a la tabla
    INSERT INTO ProRelacionLiquidacionesPemexDetalle(IdRelacionLiquidacionPemex, IdViajeCartaPorteConocimientoEmbarque, IdViaje, IdViajeCartaPorte, FolioViaje, Fecha, Destino, NoEmbarque, CreadoEl, CreadoPor, ModificadoEl, ModificadoPor, CanceladoEl, CanceladoPor, Secuencia)
    SELECT @IdProRelacionLiquidacionesPemex, ATT_IdViajeCartaPorteConocimientoEmbarque, ATT_IdViaje, ATT_IdViajeCartaPorte, ATT_FolioViaje, ATT_Fecha, ATT_Destino, ATT_NoEmbarque, @CreadoEl, @CreadoPor, @ModificadoEl, @ModificadoPor, NULL, NULL, ATT_Secuencia
    FROM #TempProRelacionLiquidacionesPemex

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

