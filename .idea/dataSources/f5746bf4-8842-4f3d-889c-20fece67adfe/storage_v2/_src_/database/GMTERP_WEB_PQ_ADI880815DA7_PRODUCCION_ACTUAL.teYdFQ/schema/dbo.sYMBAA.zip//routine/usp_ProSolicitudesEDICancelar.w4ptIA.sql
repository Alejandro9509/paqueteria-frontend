CREATE PROCEDURE [dbo].[usp_ProSolicitudesEDICancelar]
	@IdSolicitudEDI int,
	@IdMotivoCancelacionEDI int,
	@CanceladoEl datetime,
	@CanceladoPor int,
	@IdPeticion varchar(100)
AS
DECLARE @IdViajeTrayecto int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdSolicitudEDI,0) <= 0
		RAISERROR(N'El identificador de la solicitud EDI es un campo requerido',
			16,
			1
			)	
			
	--IF ISNULL(@IdMotivoCancelacionEDI,0) <= 0
	--	RAISERROR(N'El motivo de la cancelación de la solicitud EDI es un campo requerido',
	--		16,
	--		1
	--		)	
						
	IF NOT EXISTS(SELECT IdSolicitudEDI FROM ProSolicitudesEDI WHERE IdSolicitudEDI = @IdSolicitudEDI)
		RAISERROR(N'La solicitud EDI fue eliminado por otro usuario',
			16,
			1
			)
			
	IF (SELECT CanceladoEl FROM ProSolicitudesEDI WHERE IdSolicitudEDI = @IdSolicitudEDI) IS NOT NULL --cancelado
		RAISERROR(N'No puede cancelar esta solicitud EDI porque está cancelada',
			16,
			1
			)
	IF ISNULL(@IdMotivoCancelacionEDI,0) = 0
		set @IdMotivoCancelacionEDI = null
	UPDATE ProSolicitudesEDI SET
		IdMotivoCancelacionEDI = @IdMotivoCancelacionEDI,
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor		
	WHERE IdSolicitudEDI = @IdSolicitudEDI

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

