CREATE PROCEDURE [dbo].[usp_CatServiciosEliminar]
@IdServicio int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdServicio,0)= 0
	RAISERROR(N'El identificador de servicio es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT TOP 1 IdServicio FROM CatPaquetesServicios WHERE IdServicio = @IdServicio)
		RAISERROR(N'El servicio tiene paquetes ligados, no es posible eliminarlo',
				16,
				1
				)
				
	IF EXISTS(SELECT TOP 1 IdServicio FROM CatServiciosPartes WHERE IdServicio = @IdServicio)
		RAISERROR(N'El servicio tiene partes ligados, no es posible eliminarlo',
				16,
				1
				)
								
	IF EXISTS(SELECT TOP 1 IdServicio FROM ProOrdenesServiciosDetalles WHERE IdServicio = @IdServicio)
		RAISERROR(N'El servicio tiene ordenes de servicios ligados, no es posible eliminarlo',
				16,
				1
				)
				
	IF EXISTS(SELECT TOP 1 IdServicio FROM ProServiciosProgramados WHERE IdServicio = @IdServicio)
		RAISERROR(N'El servicio tiene servicios programados ligados, no es posible eliminarlo',
				16,
				1
				)
		
		DELETE FROM CatServicios
		WHERE 	IdServicio=@IdServicio
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

