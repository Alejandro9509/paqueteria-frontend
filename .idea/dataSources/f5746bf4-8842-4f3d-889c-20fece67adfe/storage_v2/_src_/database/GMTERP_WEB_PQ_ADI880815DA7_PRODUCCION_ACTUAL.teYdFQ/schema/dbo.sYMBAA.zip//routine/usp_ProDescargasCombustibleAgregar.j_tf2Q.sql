CREATE PROCEDURE [dbo].[usp_ProDescargasCombustibleAgregar]
@Folio int,
@NumeroOrden varchar(30) ,
@Fecha datetime ,
@LitrosDescarga decimal(15, 4),
@SolicitadaEl datetime,
@LitrosSolicitada decimal(15, 4),
@EstatusSello int ,
@Costo money,
@ExistenciaCombustible decimal(15, 2),
@IdContenedor int,
@IdSucursal int,
@RevisadoPor int,
@CreadoEl datetime,
@CreadoPor int,
@IdPeticion varchar(100),
@PlacasPipa varchar(10),
@Observacion varchar(300)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Folio,0)= 0
		RAISERROR(N'Folio de descarga es un campo requerido',
			16,
			1
			)

	IF ISNULL(@NumeroOrden,'')= ''
		RAISERROR(N'Número de orden es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@Fecha,'') = ''
		RAISERROR(N'Fecha es un campo requerido',
			16,
			1
			)	
			
	IF ISNULL(@LitrosDescarga,0)= 0
		RAISERROR(N'Litros de descarga es un campo requerido',
			16,
			1
			)
	IF ISNULL(@SolicitadaEl,'') = ''
		RAISERROR(N'Fecha solicitada es un campo requerido',
			16,
			1
			)	
			
	IF ISNULL(@LitrosSolicitada,0) = 0
		RAISERROR(N'Litros solicitada es un campo requerido',
			16,
			1
			)	
			
	IF ISNULL(@Costo,0) = 0
		RAISERROR(N'El costo es un campo requerido',
			16,
			1
			)	
			
	IF @Fecha <	@SolicitadaEl
		RAISERROR(N'Fecha de descarga no debe ser menor a la fecha solicitada',
			16,
			1
			)	
	
			
	INSERT INTO ProDescargasCombustible
		(Folio,NumeroOrden ,Fecha,LitrosDescarga,SolicitadaEl, LitrosSolicitada,EstatusSello,Costo,ExistenciaCombustible,
		 IdContenedor,IdSucursal,RevisadoPor,CreadoEl,CreadoPor,PlacasPipa,Observacion)
	VALUES
		(@Folio,@NumeroOrden,@Fecha,@LitrosDescarga,@SolicitadaEl,@LitrosSolicitada,@EstatusSello,@Costo,@ExistenciaCombustible,
		 @IdContenedor,@IdSucursal,@RevisadoPor,@CreadoEl,@CreadoPor,@PlacasPipa,@Observacion)

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

