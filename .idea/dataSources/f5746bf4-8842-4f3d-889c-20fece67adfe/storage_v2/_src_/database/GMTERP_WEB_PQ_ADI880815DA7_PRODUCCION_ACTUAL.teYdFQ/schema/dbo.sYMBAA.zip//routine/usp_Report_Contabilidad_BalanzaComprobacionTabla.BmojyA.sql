CREATE PROCEDURE [dbo].[usp_Report_Contabilidad_BalanzaComprobacionTabla]
@Ejercicio int,
@PeriodoInicial int,
@PeriodoFinal int,
@Fecha Date,
@CuentaOrden int, 
@IdPeticion varchar(100),
@Azure int = 0	
AS		
DECLARE @cnt int = 0

;WITH CTECuentasContables(IdCuentaContable,Codigo,Nombre,TipoCuenta,CuentaMayor,IdCuentaContablePadre,IdCuentaContableSAT,Naturaleza,NombrePadre)
AS
(
	SELECT IdCuentaContable,
	Codigo,
	Nombre,
	TipoCuenta,
	CuentaMayor,
	IdCuentaContablePadre,
	IdCuentaContableSAT,
	CASE TipoCuenta
	WHEN 1 THEN 'D'
	WHEN 2 THEN 'A'
	WHEN 3 THEN 'D'
	WHEN 4 THEN 'A'
	WHEN 5 THEN 'D'
	WHEN 6 THEN 'A'
	WHEN 7 THEN 'D'
	WHEN 8 THEN 'A'
	WHEN 9 THEN 'D'
	WHEN 10 THEN 'A'
	END AS Naturaleza,
	CONVERT(varchar(300),Codigo)+' '+Nombre
	FROM CatCuentasContables
	WHERE IdCuentaContablePadre IS NULL
	UNION ALL
	SELECT cc.IdCuentaContable,
	cc.Codigo,
	cc.Nombre,
	cc.TipoCuenta,
	cc.CuentaMayor,
	cc.IdCuentaContablePadre,
	cc.IdCuentaContableSAT,
	CASE cc.TipoCuenta
	WHEN 1 THEN 'D'
	WHEN 2 THEN 'A'
	WHEN 3 THEN 'D'
	WHEN 4 THEN 'A'
	WHEN 5 THEN 'D'
	WHEN 6 THEN 'A'
	WHEN 7 THEN 'D'
	WHEN 8 THEN 'A'
	WHEN 9 THEN 'D'
	WHEN 10 THEN 'A'
	END AS Naturaleza,
	CONVERT (varchar(300),RTRIM(ctecc.NombrePadre)+ char(9) + CONVERT (varchar(300),cc.Codigo))+' '+cc.Nombre
	FROM CatCuentasContables AS cc 
	JOIN CTECuentasContables AS ctecc ON cc.IdCuentaContablePadre = ctecc.IdCuentaContable
) , CTEPolizasCargosAbonos AS
(
	SELECT ppcc.IdCuentaContable,
	SUM(CASE ppcc.TipoMovimiento
	WHEN 1 THEN ppcc.Importe
	ELSE 0	
	END) AS Cargo,
	SUM(CASE ppcc.TipoMovimiento
	WHEN 2 THEN ppcc.Importe
	ELSE 0
	END) AS Abono
	FROM ProPolizasCuentasContables AS ppcc
	INNER JOIN ProPolizas AS pp ON ppcc.IdPoliza = pp.IdPoliza
	WHERE pp.Ejercicio = @Ejercicio AND pp.Periodo BETWEEN @PeriodoInicial AND @PeriodoFinal
	GROUP BY ppcc.IdCuentaContable
), CTESaldoInicial AS 
(
	SELECT ppcc.IdCuentaContable,
	SUM(CASE ppcc.TipoMovimiento
	WHEN 1 THEN ppcc.Importe
	ELSE 0
	END) AS Cargo,
	SUM(CASE ppcc.TipoMovimiento
	WHEN 2 THEN ppcc.Importe
	ELSE 0
	END) AS Abono,
	ccc.TipoCuenta
	FROM ProPolizasCuentasContables AS ppcc
	INNER JOIN ProPolizas AS pp ON ppcc.IdPoliza = pp.IdPoliza
	INNER JOIN CatCuentasContables AS ccc ON ppcc.IdCuentaContable = ccc.IdCuentaContable
	WHERE pp.Fecha < @Fecha AND ((ccc.TipoCuenta in(7,8) AND pp.Ejercicio = @Ejercicio) OR (ccc.TipoCuenta not in(7,8)))
	GROUP BY ppcc.IdCuentaContable,ccc.TipoCuenta
), CTEImportes as (
	SELECT 
	cte.IdCuentaContable,
	cte.Codigo,
	cte.Nombre,
	cte.TipoCuenta,
	cte.CuentaMayor,
	ccsat.CodigoAgrupadorSAT,
	cte.Naturaleza,
	(CASE cte.TipoCuenta
		WHEN 1 THEN ISNULL(ctesi.Cargo-ctesi.Abono,0)  --TipoCuentaActivoDeudora
		WHEN 3 THEN ISNULL(ctesi.Cargo-ctesi.Abono,0)  --TipoCuentaPasivoDeudora
		WHEN 5 THEN ISNULL(ctesi.Cargo-ctesi.Abono ,0) --TipoCuentaCapitalDeudora
		WHEN 7 THEN ISNULL(ctesi.Cargo-ctesi.Abono ,0) --TipoCuentaResultadoDeudora
		WHEN 9 THEN ISNULL(ctesi.Cargo-ctesi.Abono,0)  --TipoCuentaOrdenDeudora
		ELSE 0
	END) AS SaldoInicialDeudor,
	(CASE cte.TipoCuenta
		WHEN 2 THEN ISNULL(ctesi.Abono-ctesi.Cargo,0)  --TipoCuentaActivoAcreedora
		WHEN 4 THEN ISNULL(ctesi.Abono-ctesi.Cargo,0)  --TipoCuentaPasivoAcreedora
		WHEN 6 THEN ISNULL(ctesi.Abono-ctesi.Cargo ,0) --TipoCuentaCapitalAcreedora
		WHEN 8 THEN ISNULL(ctesi.Abono-ctesi.Cargo ,0) --TipoCuentaResultadoAcreedora
		WHEN 10 THEN ISNULL(ctesi.Abono-ctesi.Cargo,0)  --TipoCuentaOrdenAcreedora
		ELSE 0
	END) AS SaldoInicialAcreedor,
	ISNULL(cteca.Cargo,0) as Cargo,
	ISNULL(cteca.Abono,0) as Abono,
	(CASE cte.TipoCuenta
		WHEN 1 THEN ISNULL((ctesi.Cargo-ctesi.Abono),0) +  ISNULL(cteca.Cargo - cteca.Abono,0)
		WHEN 3 THEN ISNULL((ctesi.Cargo-ctesi.Abono),0) +  ISNULL(cteca.Cargo - cteca.Abono,0)
		WHEN 5 THEN ISNULL((ctesi.Cargo-ctesi.Abono),0) +  ISNULL(cteca.Cargo - cteca.Abono,0)
		WHEN 7 THEN ISNULL((ctesi.Cargo-ctesi.Abono),0) +  ISNULL(cteca.Cargo - cteca.Abono,0)
		WHEN 9 THEN ISNULL((ctesi.Cargo-ctesi.Abono),0) +  ISNULL(cteca.Cargo - cteca.Abono,0)
		ELSE 0
	END) AS SaldoFinalDeudor,
	(CASE cte.TipoCuenta
		WHEN 2 THEN ISNULL((ctesi.Abono-ctesi.Cargo),0) + ISNULL(cteca.Abono - cteca.Cargo,0)
		WHEN 4 THEN ISNULL((ctesi.Abono-ctesi.Cargo),0) + ISNULL(cteca.Abono - cteca.Cargo,0) 
		WHEN 6 THEN ISNULL((ctesi.Abono-ctesi.Cargo),0) + ISNULL(cteca.Abono - cteca.Cargo,0) 
		WHEN 8 THEN ISNULL((ctesi.Abono-ctesi.Cargo),0) + ISNULL(cteca.Abono - cteca.Cargo,0) 
		WHEN 10 THEN ISNULL((ctesi.Abono-ctesi.Cargo),0) + ISNULL(cteca.Abono - cteca.Cargo,0)  
		ELSE 0
	END) AS SaldoFinalAcreedor	
	,ISNULL(cte.IdCuentaContablePadre,0) AS IdPadre
	,cte.NombrePadre
	FROM CTECuentasContables as cte
	LEFT JOIN CatCuentasContablesSAT AS ccsat ON cte.IdCuentaContableSAT = ccsat.IdCuentaContableSAT
	LEFT JOIN CTEPolizasCargosAbonos as cteca ON cte.IdCuentaContable = cteca.IdCuentaContable
	LEFT JOIN CTESaldoInicial as ctesi ON cte.IdCuentaContable = ctesi.IdCuentaContable 
	WHERE cte.CuentaMayor <> 5
	) 

	SELECT * FROM CTEImportes order by NombrePadre
go

