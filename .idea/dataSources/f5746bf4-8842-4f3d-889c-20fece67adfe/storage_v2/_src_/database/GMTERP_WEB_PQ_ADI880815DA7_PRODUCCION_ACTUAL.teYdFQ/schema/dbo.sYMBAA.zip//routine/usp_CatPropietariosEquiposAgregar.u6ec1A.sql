CREATE PROCEDURE [dbo].[usp_CatPropietariosEquiposAgregar]
@Codigo	int,	
@Descripcion varchar(50),
@CreadoEl	datetime,	
@CreadoPor	int,	
@IdPeticion varchar(100),
@RFC varchar(13)='',
@IdPais int =0,
@NoRegistroIdentidadFiscal varchar(20)='',
@CodigoPostal varchar(10)='',
@IdEstado varchar(5)='',
@Municipio varchar(50)='',
@Localidad varchar(50)='',
@Colonia varchar(50)='',
@Calle varchar(50)='',
@NoExterior varchar(10)='',
@NoInterior varchar(10)='',
@Telefono varchar(20)='',
@Correo varchar(100)='',
@Contacto varchar(90)='',
@DescripcionPropietario varchar(50)=''
/******************************************************/
/*
Modificada por:   Yarazeth Lemus Hdez
Fecha de mofidicacion: 26/08/2021
Solicitud:4755
se agregaron campos nuevos para complemento en la tabla CatPropietariosEquipos
*/
/*****************************************************/
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del equipo es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Descripcion,'') = ''
		RAISERROR(N'El nombre es un campo requerido',
			16,
			1
			)			
				
			
	IF EXISTS(SELECT Codigo FROM CatPropietariosEquipos WHERE Codigo = @Codigo)
		RAISERROR(N'El código del equipo ya existe',
			16,
			1
			)	
					
	IF EXISTS(SELECT Descripcion FROM CatPropietariosEquipos WHERE Descripcion = @Descripcion)
		RAISERROR(N'El nombre ya existe',
			16,
			1
			)

	IF EXISTS(SELECT RFC FROM CatPropietariosEquipos WHERE RFC = @RFC  and RFC is not null)
		RAISERROR(N'El RFC ya existe',
			16,
			1
			)
	INSERT INTO CatPropietariosEquipos(Codigo,Descripcion,CreadoEl,CreadoPor,RFC,IdPais,NoRegistroIdentidadFiscal,CodigoPostal,IdEstado
										,Municipio,Localidad,Colonia,Calle,NoExterior,NoInterior,Telefono,Correo,Contacto,DescripcionPropietario)
	VALUES(@Codigo,@Descripcion,@CreadoEl,@CreadoPor,@RFC,@IdPais,@NoRegistroIdentidadFiscal,@CodigoPostal,@IdEstado
			,@Municipio,@Localidad,@Colonia,@Calle,@NoExterior,@NoInterior,@Telefono,@Correo,@Contacto,@DescripcionPropietario)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

