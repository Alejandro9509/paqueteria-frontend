CREATE PROCEDURE [dbo].[usp_ProReposicionesAgregar]
	@FolioReposicion int,
	@Fecha datetime,
	@Concepto varchar(150),
	@Beneficiario varchar(150),
	@IdMoneda int,	
	@ImporteTotal money,
	@TipoBeneficiario tinyint,
	@IdProveedor int,
	@IdBeneficiario int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProReposicionesPasivos ntext,
	@IdPeticion varchar(100)
AS
/* *************************************************************************************************
Procedimiento usp_ProReposicionesAgregar

Parámetros: 
     @FolioReposicion int,
	@Fecha datetime,
	@Concepto varchar(150),
	@Beneficiario varchar(150),
	@IdMoneda int,	
	@ImporteTotal money,
	@TipoBeneficiario tinyint,
	@IdProveedor int,
	@IdBeneficiario int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProReposicionesPasivos ntext,
	@IdPeticion varchar(100)

Descripción: Para agregar una reposicion de pasivos 
             
Modificada por: Enrique Ramos 
Fecha de mofidicacion: 01/10/2019
Versión: 8.0.46.32
SOLICITUD 331
Se agrego la variable  @PesoByte int  para los documentos en los pasivos. 

Modificada por: Enrique Ramos 
Fecha de mofidicacion: 10/02/2020
Versión: 8.0.49.32
SOLICITUD 633
Se quitaron parametros en la creacion de pasivos  

Invocada desde: PAGE_ProReposicionesAM, ClsProReposiciones
***************************************************************************************************** */
/* *************************************************************************************************
Modificada por: Ignacio Perez 
Fecha de mofidicacion: 24/02/2020
Versión: 8.0.50.12
SOLICITUD 1175

Se Agrego un nuevo campo en el cursor al momento en que se lee @dsProReposicionesPasivos esto para que mandara la informacion
del id de la sucursal
 **************************************************************************************************
Modificada por: Enrique Ramos	
Fecha de mofidicacion: 30/02/2020
Versión 8.0.53.35
SOLICITUD 1829
Se modifico el xml para guardar correctamente los valores de los pasivos

 **************************************************************************************************
 Modificada por: Enrique Ramos	
Fecha de mofidicacion: 1/07/2020
Versión 8.0.53.39
SOLICITUD 1829
Se modifico el orden de los datos del xml, ya que ocurria un error de formato
 
Invocada desde: PAGE_ProReposicionesAM, ClsProReposiciones Agregar(), Modificar()
***************************************************************************************************** */
 /**************************************************************************************************
 Modificada por: Ignacio Perez	
Fecha de mofidicacion: 08/07/2020
Versión 8.0.53.51
SOLICITUD 002244
Se modifico al momento de modificar pasivo para enviar una variable que le informe que proviene de reposiciones
 
Invocada desde: PAGE_ProReposicionesAM, ClsProReposiciones Agregar(), Modificar()
***************************************************************************************************** */
/*****************************************************************************************************
Modificada por: Yarazeth Lemus
Fecha de mofidicacion: 19/01/2021
Versión 8.0.58.02
SOLICITUD 003671
se agregaron los parametros que hacian falta y el metodo de pago
*******************************************************************************************************/

DECLARE @docHandle  int,
		@IdReposicion int,
		@FolioPasivo int,
		@IdTipoMovimientoCXP int,
		@return_value int,
		@FolioReposicionConsulta int,	
		@MensajeError varchar(200)
        
SET XACT_ABORT ON	

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@FolioReposicion,0) = 0
		RAISERROR(N'Folio de reposición es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT FolioReposicion FROM ProReposiciones WHERE FolioReposicion = @FolioReposicion)
		RAISERROR(N'El folio de reposición ya existe',
			16,
			1
			)
					
	IF ISDATE(@Fecha) = 0
		RAISERROR(N'Fecha es un campo requerido',
			16,
			1
			)
	IF ISNULL(@Concepto,'') = ''
		RAISERROR(N'Concepto es un campo requerido',
			16,
			1
			)
	IF ISNULL(@IdMoneda,0) = 0
		RAISERROR(N'Identificador de Moneda es un campo requerido',
			16,
			1
			)
	IF ISNULL(@ImporteTotal,0) = 0
		RAISERROR(N'Importe es un campo requerido',
			16,
			1
			)
	IF @TipoBeneficiario = 1  --- 1 Tipo Proveedor
		BEGIN
			IF ISNULL(@IdProveedor,0)= 0
				RAISERROR(N'Identificador de proveedor es un campo requerido',
					16,
					1
					)
			SET @IdBeneficiario = NULL
		END
	IF @TipoBeneficiario = 2  --- 2 Tipo Beneficiario
		BEGIN
			IF ISNULL(@IdBeneficiario ,0)= 0
				RAISERROR(N'Identificador de Beneficiario es un campo requerido',
				16,
				1
				)
				
			SET @IdProveedor = NULL
		END	
--- Agregar Reposición
	INSERT INTO ProReposiciones (FolioReposicion,Fecha,Concepto,Importe,Beneficiario,TipoBeneficiario,IdProveedor,IdBeneficiario,IdMoneda,CreadoPor,CreadoEl)
	VALUES (@FolioReposicion,@Fecha,@Concepto,@ImporteTotal,@Beneficiario,@TipoBeneficiario,@IdProveedor,@IdBeneficiario,@IdMoneda,@CreadoPor,@CreadoEl) 
	SET @IdReposicion = (SELECT IDENT_CURRENT('ProReposiciones'))
	
	 --Inicio seccion para agregar el idReposicion a paremetros y poder obtenerlo de lado del web
    IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdReposicion' AND IdUsuario = @CreadoPor)
    INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdReposicion',@IdReposicion,@CreadoPor)
    ELSE
    UPDATE SisParametrosPagina SET Parametros = @IdReposicion WHERE Pagina = 'IdReposicion' AND IdUsuario = @CreadoPor	
	-- Fin seccion
	
--- Agregar Pasivos     se agrega el campo ImporteTotal del pasivo SOLICITUD 010117
	IF @dsProReposicionesPasivos IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProReposicionesPasivos
		SELECT
		ATT_FolioPasivo
		,ATT_FechaPasivo
		,ATT_IdProveedorPasivo
		,ATT_FolioDocumento
		, ATT_SerieDocumento
		,ATT_FechaVencimiento
		,ATT_Importe
		,ATT_ImporteTotal
		,ATT_TipoCambio
		,  ATT_IdImpuesto
		,ATT_ImporteIVA
		,ATT_ImporteRetensionISR
		,ATT_ImporteRetensionIVA
		, ATT_PDFDescripcion 
		,ATT_PDFNombre
		,ATT_PDFObd 
		,  ATT_IdCategoriaPasivo
		,ATT_IdMonedaPasivo
		,ATT_FechaRecibido
		,ATT_IdTipoMovimientoCXP
		,  ATT_XMLArchivo
		, ATT_FolioFiscalUUID
		,ATT_IntegrarPasivo
		,ATT_ImporteAPagar
		,ATT_IdPasivo
		,ATT_DesdeReposicion
		,ATT_Referencia
		,ATT_ImporteDescuento
		, ATT_IdSucursal
		, ATT_NumeroMetodoPago
		INTO #TempProReposicionesPasivos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProReposicionesPasivos',2) 
		WITH (ATT_FolioPasivo int,ATT_FechaPasivo datetime,ATT_IdProveedorPasivo int,ATT_FolioDocumento varchar(40),
			ATT_SerieDocumento char(25),ATT_FechaVencimiento datetime,ATT_Importe money,ATT_ImporteTotal money,ATT_TipoCambio money,
			ATT_IdImpuesto int,ATT_ImporteIVA money,ATT_ImporteRetensionISR money,ATT_ImporteRetensionIVA money,
		ATT_PDFDescripcion varchar(300),ATT_PDFNombre varchar(300),ATT_PDFObd bit,
		ATT_IdCategoriaPasivo int,ATT_IdMonedaPasivo int,ATT_FechaRecibido datetime,ATT_IdTipoMovimientoCXP int,
		ATT_XMLArchivo varchar(max), ATT_FolioFiscalUUID varchar(36),ATT_IntegrarPasivo tinyint,ATT_ImporteAPagar money
		, ATT_IdPasivo int, ATT_DesdeReposicion bit,ATT_Referencia nvarchar(max),ATT_ImporteDescuento money, ATT_IdSucursal int, ATT_NumeroMetodoPago tinyint )
		
        EXEC sp_xml_removedocument @docHandle
		-----------------------------
		DECLARE @CursorFolioPasivo int, @CursorFechaPasivo datetime,@CursorIdProveedorPasivo int,@CursorFolioDocumento varchar(40),@CursorSerieDocumento char(25),
				@CursorFechaVencimiento datetime,@CursorImporte money,@CursorImporteTotal money,@CursorTipoCambio money,@CursorIdImpuesto int,@CursorImporteIVA money,
				@CursorImporteRetensionISR money,@CursorImporteRetensionIVA money,
				@PDFDescripcionArchivo varchar(300),@PDFNombreArchivo varchar(300),@PDFObs bit,
				@CursorIdCategoriaPasivo int,@CursorIdMonedaPasivo int,
				@CursorFechaRecibido datetime,@CursorIdTipoMovimientoCXP int,
				@CursorXMLArchivo varchar(max), @CursorFolioFiscalUUID varchar(36), @CursorIntegrarPasivo tinyint, @CursorImporteAPagar money, @CursorIdPasivo int,@CursorDesdeReposicion bit,@CursorReferencia nvarchar(max),@CursorDescuento money, @CursorIdSucursal int, @CursorNumeroMetodoPago tinyint
		SET @MensajeError = ''
-- Declaración del cursor
		DECLARE CursorProReposicionesPasivos CURSOR FOR
		SELECT * From #TempProReposicionesPasivos
-- Apertura del cursor
		OPEN CursorProReposicionesPasivos
-- Lectura de la primera fila del cursor
		FETCH CursorProReposicionesPasivos INTO @CursorFolioPasivo,@CursorFechaPasivo,@CursorIdProveedorPasivo,@CursorFolioDocumento,
			   @CursorSerieDocumento,@CursorFechaVencimiento,@CursorImporte,@CursorImporteTotal,@CursorTipoCambio,@CursorIdImpuesto,@CursorImporteIVA,
			   @CursorImporteRetensionISR,@CursorImporteRetensionIVA,@PDFDescripcionArchivo,@PDFNombreArchivo,@PDFObs,
			   @CursorIdCategoriaPasivo,@CursorIdMonedaPasivo,@CursorFechaRecibido,@CursorIdTipoMovimientoCXP,@CursorXMLArchivo, @CursorFolioFiscalUUID ,@CursorIntegrarPasivo,
			   @CursorImporteAPagar, @CursorIdPasivo, @CursorDesdeReposicion,@CursorReferencia,@CursorDescuento,@CursorIdSucursal,@CursorNumeroMetodoPago

		WHILE (@@FETCH_STATUS = 0 )
		BEGIN
			SELECT @IdTipoMovimientoCXP = IdTipoMovimientoCXP from CatTiposMovimientosCXP where Codigo = 1
			
			SELECT @CursorXMLArchivo = XMLArchivo,@PDFDescripcionArchivo = PDFDescripcionArchivo,@PDFNombreArchivo = PDFNombreArchivo FROM ProPasivos where IdPasivo = @CursorIdPasivo
			
			IF @CursorIdCategoriaPasivo = 0
			   SET @CursorIdCategoriaPasivo = NULL
			
			IF @CursorIntegrarPasivo = 1 --- Integración de pasivo
				BEGIN
				
				-- Validación Concurrencia	
				DECLARE @SumaReposiciones int,
				@SaldoPasivo int
				
				SELECT @SumaReposiciones=SUM(ProReposicionesPasivos.Importe)
				From  ProReposicionesPasivos
				INNER JOIN ProReposiciones ON ProReposiciones.IdReposicion= ProReposicionesPasivos .IdReposicion
				where ProReposicionesPasivos.IdPasivo = @CursorIdPasivo AND ProReposicionesPasivos.IdReposicion <> @IdReposicion
				AND ISNULL(ProReposiciones.IdMovimientoBancario,0)=0
								
				SELECT @SaldoPasivo=(SELECT(pp.ImporteTotal-pp.ImportePagado) 
				FROM ProPasivos AS pp WHERE pp.IdPasivo=@CursorIdPasivo)
				
				IF @CursorImporteAPagar > (@SaldoPasivo-@SumaReposiciones)
					RAISERROR(N'El saldo del pasivo es menor al Importe a Pagar',
					16,
					1
					)


				-- Modificar pasivos
				IF (Select IdPasivoContraRecibo from ProPasivos WHERE IdPasivo = @CursorIdPasivo) is not null
					BEGIN
						SET @MensajeError += 'El Pasivo con No.Documento '+rtrim(ltrim(isnull(@CursorSerieDocumento,'')))+'-'+RIGHT(REPLICATE('0', 10)+ CAST(isnull(@CursorFolioDocumento,0) AS VARCHAR(40)),10)+' se encuentra ligado a un Contra Recibo.'+CHAR(13) + CHAR(10) 
					END								
				BEGIN
				EXEC @return_value = usp_ProPasivosModificar 
												@CursorIdPasivo,
												@CursorFolioPasivo,
												@CursorFechaPasivo,
												@CursorIdProveedorPasivo,
												@CursorFolioDocumento,
												@CursorSerieDocumento,
												@CursorFechaVencimiento,
												@CursorImporte,
												@CursorTipoCambio,
												@CursorIdImpuesto,
												@CursorImporteIVA,
												@CursorImporteRetensionISR,
												@CursorImporteRetensionIVA,
												@CursorIdCategoriaPasivo,
												@CursorIdMonedaPasivo,
												@CursorIdSucursal,--SOLICITUD 1175
												@CursorFechaRecibido,
												@IdTipoMovimientoCXP,
												@CreadoPor,
												@CreadoEl,
												@IdPeticion,
												0,
												0,
												0,
												0,
												0,
												0,
												0,
												'',
												@PDFNombreArchivo,
												@PDFDescripcionArchivo,
												@CursorXMLArchivo,
												@CursorFolioFiscalUUID,
												@CursorDescuento,
												--@IdReposicion,
												NULL,
												@CursorReferencia,
												'',
                                                NULL,
												NULL,
												NULL,
												NULL,
												1,
												@CursorImporteTotal,
												NULL,
												1,
												NULL,
												NULL,
												NULL,
												NULL,
												NULL,
												NULL,
												NULL,
												@CursorNumeroMetodoPago

					 IF @return_value <> 0
							RAISERROR(N'Ocurrió un error al agregar pasivos',
								16,
								1
								) 
					-- Se inserta en la tabla puente
					INSERT INTO ProReposicionesPasivos(IdReposicion,IdPasivo,Importe)
					VALUES(@IdReposicion,@CursorIdPasivo,@CursorImporteAPagar)				
				END
					---UPDATE ProPasivos set IdReposicion = @IdReposicion  where IdPasivo = @CursorIdPasivo	
				END
					
			ELSE	
			 BEGIN		
			-- Agregar pasivos
				SET  @FolioPasivo = (Select ISNULL(MAX(FolioPasivo),0)+1 AS FolioPasivo from ProPasivos)
			EXEC @return_value = usp_ProPasivosAgregar
											@FolioPasivo,
											@CursorFechaPasivo,
											@CursorIdProveedorPasivo,
											@CursorFolioDocumento,
											@CursorSerieDocumento,
											@CursorFechaVencimiento,
											@CursorImporte,
											@CursorTipoCambio,
											@CursorIdImpuesto,
											@CursorImporteIVA,
											@CursorImporteRetensionISR,
											@CursorImporteRetensionIVA,
											0,
											@CursorIdCategoriaPasivo,
											@CursorIdMonedaPasivo,
											@CursorIdSucursal,--SOLICITUD 1175
											@CursorFechaRecibido,
											@IdTipoMovimientoCXP,
											@CreadoPor,
											@CreadoEl,
											@IdPeticion,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											@CursorXMLArchivo,
											@CursorFolioFiscalUUID,
											0,@CursorDescuento,
											--@IdReposicion,
											@CursorDesdeReposicion,
											NULL,
											NULL,
											'',
											0,
											NULL,
											NULL,
											NULL,
											NULL,
											NULL,
											1,
											@CursorImporteTotal,
											0,
											NULL,
											NULL,
											NULL,
											NULL,
											NULL,
											NULL,
											NULL,
											NULL,
											NULL,
											0,
											@CursorNumeroMetodoPago
											
			 IF @return_value <> 0
					RAISERROR(N'Ocurrió un error al agregar pasivos',
						16,
						1
						)  
						
				-- Se inserta en la tabla puente	
				DECLARE @IdPasivo int
						 
				SET @IdPasivo = (SELECT IDENT_CURRENT('ProPasivos'))		 
					INSERT INTO ProReposicionesPasivos(IdReposicion,IdPasivo,Importe)
					VALUES(@IdReposicion,@IdPasivo,@CursorImporteAPagar)
			 
			END

			-- Lectura de la siguiente fila del cursor
			 FETCH CursorProReposicionesPasivos INTO @CursorFolioPasivo,@CursorFechaPasivo,@CursorIdProveedorPasivo,@CursorFolioDocumento,
				   @CursorSerieDocumento,@CursorFechaVencimiento,@CursorImporte,@CursorImporteTotal,@CursorTipoCambio,@CursorIdImpuesto,@CursorImporteIVA,
				   @CursorImporteRetensionISR,@CursorImporteRetensionIVA,@PDFDescripcionArchivo,@PDFNombreArchivo,@PDFObs,
				   @CursorIdCategoriaPasivo,@CursorIdMonedaPasivo,@CursorFechaRecibido,@CursorIdTipoMovimientoCXP,@CursorXMLArchivo, @CursorFolioFiscalUUID ,@CursorIntegrarPasivo,
				   @CursorImporteAPagar, @CursorIdPasivo, @CursorDesdeReposicion,@CursorReferencia,@CursorDescuento,@CursorIdSucursal,@CursorNumeroMetodoPago
		END
-- Cierre del cursor
		CLOSE CursorProReposicionesPasivos
-- Liberar los recursos
	DEALLOCATE CursorProReposicionesPasivos
		IF @MensajeError <> ''
			BEGIN
				RAISERROR(@MensajeError,
				16,
				1
				)
			END   
	-----------------------------        
	END
	COMMIT
END TRY
BEGIN CATCH
IF(@@TRANCOUNT>0)
BEGIN
  ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END
END CATCH
go

