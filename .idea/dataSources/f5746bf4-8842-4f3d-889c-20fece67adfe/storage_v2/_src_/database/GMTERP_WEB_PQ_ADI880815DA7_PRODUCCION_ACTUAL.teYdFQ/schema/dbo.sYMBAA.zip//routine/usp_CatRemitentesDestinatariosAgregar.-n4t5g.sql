CREATE PROCEDURE [dbo].[usp_CatRemitentesDestinatariosAgregar]
	@IdCliente int,
	@Numero int,
	@Nombre varchar(150),
	@RFC varchar(13),	
	@Activo bit,	
	@Calle varchar(100),
	@NoExterior varchar(20),
	@NoInterior varchar(20),
	@Colonia varchar(100),
	@Localidad varchar(100),
	@Municipio varchar(100),
	@IdEstado varchar(5),
	@CodigoPostal varchar(10),	
	@IdSucursal int,	
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@Contacto varchar(90),
	@CorreoElectronico varchar(100),
	@Telefono varchar(20),
	@NoRegistroIdentidadFiscal varchar(20)
	
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF @Numero = 0
		RAISERROR(N'El numero de remitente-destinatario es un campo requerido',
			16,
			1
			)			

	IF EXISTS(SELECT Numero FROM CatRemitentesDestinatarios WHERE Numero = @Numero)
		RAISERROR(N'El numero de remitente-destinatario ya existe',
			16,
			1
			)	
			
	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El nombre es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@Calle)) = ''
		RAISERROR(N'La calle es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@Municipio)) = ''
		RAISERROR(N'El municipio es un campo requerido',
			16,
			1
			)		
			
	IF LTRIM(RTRIM(@IdEstado)) = ''
		RAISERROR(N'El estado es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@CodigoPostal)) = ''
		RAISERROR(N'El código postal es un campo requerido',
			16,
			1
			)
						
	IF @IdSucursal = 0 
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)

	IF @IdCliente = 0
		SET @IdCliente = NULL			

	INSERT INTO CatRemitentesDestinatarios(Activo,Calle,CodigoPostal,Colonia,CreadoEl,CreadoPor,IdCliente,IdEstado,IdSucursal,Localidad,Municipio,NoExterior,NoInterior,Nombre,Numero,RFC,Contacto,CorreoElectronico,Telefono, NoRegistroIdentidadFiscal)
	VALUES(@Activo,@Calle,@CodigoPostal,@Colonia,@CreadoEl,@CreadoPor,@IdCliente,@IdEstado,@IdSucursal,@Localidad,@Municipio,@NoExterior,@NoInterior,@Nombre,@Numero,@RFC,@Contacto,@CorreoElectronico,@Telefono, @NoRegistroIdentidadFiscal)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

