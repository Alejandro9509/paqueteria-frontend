CREATE PROCEDURE [dbo].[usp_CatConceptosPDOEliminar]
@IdConceptoPDO int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdConceptoPDO ,0)= 0
		RAISERROR(N'El identificador es un campo requerido',
			16,
			1
			)
				
	IF EXISTS(SELECT TOP 1 * FROM ProNominasReciboConceptos WHERE IdConceptoPDO = @IdConceptoPDO)
		RAISERROR(N'El concepto tiene recibos ligados, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM ProCalculoAnualConfiguracionISR WHERE IdConceptoPDO = @IdConceptoPDO)
		RAISERROR(N'El concepto está ligado a la configuración del cálculo anual, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 * FROM ProCalculoAnualConfiguracionConceptos WHERE IdConceptoPDO = @IdConceptoPDO)
	RAISERROR(N'El concepto está ligado a la configuración del cálculo anual, no es posible eliminarlo',
		16,
		1
		)

		DELETE CatConceptosPDO
		WHERE 	IdConceptoPDO=@IdConceptoPDO
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

