
CREATE PROCEDURE [dbo].[usp_ProDescargasCombustibleCancelar]
@IdDescargaCombustible int,
@MotivoCancelacion varchar(150),
@FechaHoraCancelacion Datetime,
@CanceladoEl Datetime,
@CanceladoPor int,
@IdPeticion varchar(100)

	/* *************************************************************************************************
Procedimiento usp_ProDescargasCombustibleCancelar

Parámetros: 
	@IdDescargaCombustible		(entrada, datetime). Id de descarga de combustible
	@MotivoCancelacion			(entrada, string). Descripción de la cancelaación
	@FechaHoraCancelacion		(entrada, datetime). Fecha y hora de la sucursal
	@CanceladoEl				(entrada, datetime). Fecha y hora de cancelación  del sistema
	@CanceladoPor				(entrada, entero). Id de usuario
	@IdPeticion					(entrada, string). Id de petición
	

Descripción: Procedimiento para cancelar una descarga de combustible



Implementada por: Julio Hermosillo
Fecha de implementacion: 11/06/2020
Versión ERP: 8.0.53.04


Invocada desde: PAGE_ProDescargsCombustibleAM (Solicitud 2096)
***************************************************************************************************** */


AS
BEGIN TRY
	BEGIN TRANSACTION
	


	IF (SELECT Count(*) FROM ProCargasCombustibleDetalle WHERE IdDescargaCombustible = @IdDescargaCombustible) > 0 
		RAISERROR(N'No es posible cancelar la descarga de combustible, se tienen movimientos relacionados',
			16,
			1
			)

	IF ISNULL(@IdDescargaCombustible,0)= 0
		RAISERROR(N'Identificador de descarga de combustible es un campo requerido',
			16,
			1
			)	
	IF ISDATE(@CanceladoEl)= 0
		RAISERROR(N'Fecha de cancelación es un campo requerido',
			16,
			1
			)
	IF ISDATE(@FechaHoraCancelacion)= 0
		RAISERROR(N'Fecha y hora de cancelación de la sucursal es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@MotivoCancelacion,'') = ''
		RAISERROR(N'Motivo de cancelación es un campo requerido',
			16,
			1
			)	
			
			
	IF (SELECT CanceladoEl FROM ProDescargasCombustible WHERE IdDescargaCombustible = @IdDescargaCombustible) IS NOT NULL 
		RAISERROR(N'La descarga de combustible ya está cancelada',
			16,
			1
			)			
			
	IF (SELECT Cast(Fecha as Date)  FROM ProDescargasCombustible WHERE IdDescargaCombustible = @IdDescargaCombustible) > Cast(@FechaHoraCancelacion as Date)
			RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de descarga',
			16,
			1
			)
			

				
    UPDATE ProDescargasCombustible
		SET ExistenciaCombustible = 0,
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		MotivoCancelacion = @MotivoCancelacion,
		FechaHoraCancelacion = @FechaHoraCancelacion			
	WHERE  IdDescargaCombustible= @IdDescargaCombustible
	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

