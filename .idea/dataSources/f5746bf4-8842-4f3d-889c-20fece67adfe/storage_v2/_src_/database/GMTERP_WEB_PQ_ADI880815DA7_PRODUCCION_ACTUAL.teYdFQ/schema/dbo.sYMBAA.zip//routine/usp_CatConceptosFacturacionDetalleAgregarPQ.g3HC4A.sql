


CREATE PROCEDURE [dbo].[usp_CatConceptosFacturacionDetalleAgregarPQ](
	@IdConceptosFacturacion int,
	@IdImpuesto int,
	@Predeterminado bit
)
AS
BEGIN
	declare @id int;
	SET @id = 0;
	BEGIN TRANSACTION
		IF ISNULL(@IdImpuesto, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de Impuesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		INSERT INTO CatConceptosFacturacionDetalle(IdConceptosFacturacion,IdImpuesto,Predeterminado)
		VALUES (@IdConceptosFacturacion,@IdImpuesto,@Predeterminado);
		--
		--
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				SET @id = SCOPE_IDENTITY() ;
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
		RETURN @id;
end
go

