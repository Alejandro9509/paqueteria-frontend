
CREATE PROCEDURE[dbo].[usp_CatPlantillasDistribucionGastosPartidasUnidadesGetMaxCodigo]

AS

SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatPlantillasDistribucionGastosPartidasUnidades
go

