CREATE PROCEDURE [dbo].[usp_CatImpuestosEliminar]
@IdImpuesto int,
@IdPeticion varchar(100)	
AS
DECLARE
@ConceptoFacturacion varchar(max) = '',
@Mensaje varchar(max) = ''
/*
MODIFICADO:
	Se agregaro una validacion para determinar si el impuesto no es predeterminado en un concepto de facturacion, y si no es predeterminado
	se elimina y se asigna un nuevo impuesto predeterminado al concepto de facturacion.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-03-25
SOLICITUD: 
	SOLICITUD 001468
*/
BEGIN TRY
   BEGIN TRANSACTION
   IF EXISTS(SELECT TOP 1 IdImpuesto  FROM ProFacturasImpuestos WHERE ProFacturasImpuestos.IdImpuesto = @IdImpuesto)
				RAISERROR(N'No es posible eliminar el Impuesto, ya que se encuentra ligado a un proceso.',
				16,
				1
				)


	SET @ConceptoFacturacion = (SELECT
							TOP 1
							(CAST(Codigo as varchar)+SpACE(2)+ConceptoFacturacion) AS ImpuestoUnicoPredeterminado
							FROM (
								SELECT
								(SELECT COUNT(subccf.IdImpuesto) 
								FROM CatConceptosFacturacionImpuestos subccf
								INNER JOIN CatImpuestos subci ON subccf.IdImpuesto = subci.IdImpuesto
								WHERE 
								subccf.IdConceptoFacturacion = sccfi.IdConceptoFacturacion 
								AND subccf.Activo = 1 /*Impuesto activo*/
								AND subci.TipoCalculo = sci.TipoCalculo ) AS Unico,
								sccf.Codigo,
								sccf.ConceptoFacturacion

								FROM
								CatConceptosFacturacion sccf
								INNER JOIN CatConceptosFacturacionImpuestos sccfi ON sccf.IdConceptoFacturacion = sccfi.IdConceptoFacturacion
								INNER JOIN CatImpuestos sci ON sccfi.IdImpuesto = sci.IdImpuesto
								WHERE 
								sccfi.Activo = 1 /*Impuesto activo*/
								AND sci.IdImpuesto = @IdImpuesto
							) AS ValidacionConceptoUnido
							WHERE Unico = 1 )

		IF @ConceptoFacturacion <> ''
		BEGIN
			SET @Mensaje = 'No es posible eliminar el impuesto, ya que se encuentra como predeterminado en el concepto de facturación: '+@ConceptoFacturacion+' y este no se puede quedar sin impuesto asignado, favor de validar.'
			
			RAISERROR(@Mensaje,
			16,
			1
			)
		END
		ELSE
		BEGIN
			/*Se inactiva como predeterminado y activo*/
			UPDATE
			CatConceptosFacturacionImpuestos 
			SET
			Predeterminado = 0,
			Activo = 0
			WHERE
			IdImpuesto = @IdImpuesto
			AND Predeterminado = 1

			/*determina el predeterminado*/
			UPDATE
			CatConceptosFacturacionImpuestos 
			SET
			Predeterminado = 1
			WHERE
			IdConceptoFacturacionImpuesto IN (
			SELECT /*Obtiene todos los conceptos de facturacion que tienen el impuesto que se modifico*/
			(SELECT TOP 1 subcfi.IdConceptoFacturacionImpuesto /*Obtiene el siguiente impuesto diponible para marcarlo como predeterminado*/
				FROM CatConceptosFacturacionImpuestos subcfi 
				INNER JOIN CatImpuestos subci ON subcfi.IdImpuesto = subci.IdImpuesto
				WHERE 
				subcfi.IdConceptoFacturacion = cfi.IdConceptoFacturacion
				AND subci.TipoCalculo = ci.TipoCalculo
				AND subcfi.Activo = 1
				AND subci.Activo = 1
				ORDER BY subci.IdImpuesto
			) AS IdConceptoFacturacionImpuesto
			FROM
			CatConceptosFacturacionImpuestos cfi
			INNER JOIN CatImpuestos ci ON cfi.IdImpuesto = ci.IdImpuesto
			WHERE
			ci.IdImpuesto = @IdImpuesto)
		END

		

		DELETE CatConceptosFacturacionImpuestos
		WHERE IdImpuesto=@IdImpuesto

		DELETE CatImpuestos
		WHERE 	IdImpuesto=@IdImpuesto

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

