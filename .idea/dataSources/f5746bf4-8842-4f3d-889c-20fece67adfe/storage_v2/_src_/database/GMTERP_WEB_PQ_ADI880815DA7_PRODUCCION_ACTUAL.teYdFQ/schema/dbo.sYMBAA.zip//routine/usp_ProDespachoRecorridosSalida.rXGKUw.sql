
CREATE PROCEDURE [dbo].[usp_ProDespachoRecorridosSalida]
	@IdRecorridoDespacho int,
	@FechaSalida datetime,
	@IdEstatuViaje int,
	@RutaGoogleMap ntext,
	@ModificadoPor  int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@EstatusGeneradoAutomaticamente bit = 0,
	@TiempoRecorrido decimal(15,2)
	
AS
DECLARE 
	@IdUnidadCamion int,
	@CodigoUnidad varchar(16),
	@IdOperador int
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdRecorridoDespacho,0) = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdEstatuViaje,0) = 0
		RAISERROR(N'El estatus del viaje es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@FechaSalida) = 0
		RAISERROR(N'La fecha y hora de salida es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT FechaSalida FROM ProRecorridosDespacho WHERE IdRecorridoDespacho = @IdRecorridoDespacho AND FechaSalida IS NOT NULL)--tiene salida
		RAISERROR(N'No se puede dar salida a este recorrido porque ya tiene salida',
			16,
			1
			)

	
	
	SELECT @IdUnidadCamion = IdUnidad,
	@IdOperador = IdOperador FROM ProRecorridosDespacho 
	WHERE IdRecorridoDespacho = @IdRecorridoDespacho

	--La unidad que se desea hacer salida tiene ya trayectos
	IF EXISTS(SELECT IdRecorridoDespacho FROM ProRecorridosDespacho WHERE IdUnidad = @IdUnidadCamion AND FechaSalida IS NOT NULL AND FechaLlegada IS NULL)
		RAISERROR(N'La unidad que se desea dar salida ya tiene un recorrido asignado',
			16,
			1
			)
	
	IF @IdOperador is null--cancelado
		RAISERROR(N'No se puede dar salida a este recorrido porque no tiene operador asignado',
			16,
			1
			)
			
	IF @IdUnidadCamion is null--cancelado
		RAISERROR(N'No se puede dar salida a este recorrido porque no tiene Camión asignado',
			16,
			1
			)			

	UPDATE ProRecorridosDespacho SET
		IdEstatuViaje = @IdEstatuViaje,
		FechaHoraRecorridoEstatus = @FechaSalida,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		RutaGoogleMap = @RutaGoogleMap,
		FechaSalida = @FechaSalida,
		TiempoRecorrido = @TiempoRecorrido
	WHERE IdRecorridoDespacho = @IdRecorridoDespacho

	INSERT INTO ProRecorridosDespachoEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatusViaje,IdRecorridoDespacho,GeneradoAutomaticamente)
	VALUES(@ModificadoEl,@ModificadoPor,@FechaSalida,@IdEstatuViaje,@IdRecorridoDespacho,@EstatusGeneradoAutomaticamente)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

