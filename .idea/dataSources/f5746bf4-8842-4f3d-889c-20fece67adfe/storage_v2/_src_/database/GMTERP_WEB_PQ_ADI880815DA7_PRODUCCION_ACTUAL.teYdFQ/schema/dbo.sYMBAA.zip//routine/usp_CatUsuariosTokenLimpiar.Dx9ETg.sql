CREATE PROCEDURE [dbo].[usp_CatUsuariosTokenLimpiar]	
	@Token varchar(max),
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

		UPDATE CatUsuarios SET
		Token = NULL,
		TokenIOS = NULL,
		TipoServicio = NULL
		WHERE Token = @Token

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

