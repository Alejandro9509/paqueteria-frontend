

CREATE PROCEDURE [dbo].[usp_ProViajeDetalleParadasModificarPQ](	
	@IdDetalleParada int,
	@IdViaje int ,
	@IdInforme int ,
	@IdOperador int ,
	@IdUnidad int ,
	@CVR1 int ,
	@CVR2 int ,
	@Referencia varchar(50) ,
	@FechaCarga date ,
	@FechaEntrega date,
	@FechaInforme date ,
	@HoraInforme time(7),
	@IdRemolque int,
	@Total Float, 
	@Entregado int,
	@Estatus int,
	@HoraCarga time(7),
	@HoraEntrega  time(7)
	)
AS
BEGIN
	BEGIN TRANSACTION
	
		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@IdInforme, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		update ProViajeDetalleParadasPQ

		set 
				IdViaje=@IdViaje  ,
	IdInforme=@IdInforme  ,
	IdOperador=@IdOperador  ,
	IdUnidad=@IdUnidad  ,
	CVR1=@CVR1  ,
	CVR2=@CVR2  ,
	Referencia=@Referencia ,
	FechaCarga=@FechaCarga  ,
	FechaEntrega=@FechaEntrega ,
	FechaInforme=@FechaInforme  ,
	HoraInforme=@HoraInforme ,
	IdRemolque=@IdRemolque ,
	Total=@Total , 
	Entregado=@Entregado ,
	Estatus=@Estatus ,
	HoraCarga=@HoraCarga ,
	HoraEntrega=@HoraEntrega  



		where IdInforme = @IdInforme;
		IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

