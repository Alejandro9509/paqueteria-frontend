	
		CREATE PROCEDURE [dbo].[usp_CatLayoutsImportarIncidenciasAgregar]
		@Layout	varchar(50),
		@TipoArchivo tinyint,
		@Separador	varchar(5),
		@RenglonInicial	tinyint,
		@ColumnaCodigoEmpleado tinyint,
		@ColumnaIdIncidencias	tinyint,
		@ColumnaValorIncidencia tinyint,
		@ColumnaEstado tinyint,
		@FechaHoraJuntas bit,
		@ColumnaFechaHora tinyint,
		@FormatoFechaHora	varchar(26),
		@ColumnaFecha	tinyint,
		@FormatoFecha	varchar(15),
		@ColumnaHora	tinyint,
		@FormatoHora	varchar(15),	
		@CreadoEl	datetime,
		@CreadoPor	int,	
		@IdPeticion varchar(150)	
	AS
	BEGIN TRY
		BEGIN TRANSACTION

			IF LTRIM(RTRIM(@Layout)) = ''
				RAISERROR(N'El nombre del layout es un campo requerido',
					16,
					1
					)
			INSERT INTO CatLayoutsImportarIncidencias (Layout, TipoArchivo, Separador, RenglonInicial, ColumnaCodigoEmpleado,
			ColumnaIdIncidencias, ColumnaValorIncidencia, ColumnaEstado, FechaHoraJuntas, ColumnaFechaHora, FormatoFechaHora,
			ColumnaFecha, FormatoFecha, ColumnaHora, FormatoHora, CreadoEl, CreadoPor )	
			VALUES(@Layout, @TipoArchivo, @Separador, @RenglonInicial, @ColumnaCodigoEmpleado,
			@ColumnaIdIncidencias, @ColumnaValorIncidencia, @ColumnaEstado, @FechaHoraJuntas, @ColumnaFechaHora, @FormatoFechaHora,
			@ColumnaFecha, @FormatoFecha, @ColumnaHora, @FormatoHora, @CreadoEl,@CreadoPor )

		
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
        go

