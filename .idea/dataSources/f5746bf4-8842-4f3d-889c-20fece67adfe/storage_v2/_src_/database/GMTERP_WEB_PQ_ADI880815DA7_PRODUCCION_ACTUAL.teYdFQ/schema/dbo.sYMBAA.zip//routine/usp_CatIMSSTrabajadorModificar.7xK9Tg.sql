
CREATE PROCEDURE [dbo].[usp_CatIMSSTrabajadorModificar]
@IdImssTrabajador int,
@FechaVigencia datetime,
@EspecieGastosMedicos decimal(15, 3),
@EspecieFija decimal(15, 3),
@EspecieMasSMDF decimal(15, 3),
@PrestacionesEnDinero decimal(15, 3),
@InvalidezYVida decimal(15, 3),
@CesantiaYVejez decimal(15, 3),
@Guarderias decimal(15, 3),
@Retiro decimal(15, 3),
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)

AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdImssTrabajador,0)= 0
	RAISERROR(N'El identificador del Imms Trabajador es un campo requerido',
			16,
			1
			)
	--Validar si la fecha de vigencia esta registrada
		IF EXISTS(Select * FROM CatIMSSTrabajador where YEAR(FechaVigencia) = YEAR(@FechaVigencia) AND IdImssTrabajador <> @IdImssTrabajador)
	RAISERROR(N'No se permiten registros con fecha de vigencia duplicada',
			16,
			1
			)			
			
	UPDATE CatIMSSTrabajador SET
	FechaVigencia = @FechaVigencia,
    EspecieGastosMedicos =  @EspecieGastosMedicos,
	EspecieFija = @EspecieFija,
	EspecieMasSMDF = @EspecieMasSMDF,
	PrestacionesEnDinero = @PrestacionesEnDinero,
	InvalidezYVida = @InvalidezYVida,
	CesantiaYVejez = @CesantiaYVejez,
	Guarderias = @Guarderias,
	Retiro = @Retiro,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor
	WHERE IdImssTrabajador = @IdImssTrabajador  

  COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

