CREATE PROCEDURE [dbo].[usp_CatClientesContactosUnidadesGrabar]
	@IdClienteContactoUnidad int,
	@IdClienteContacto int,
	@IdUnidad int,
	@Permanente bit,
	@FechaHoraVencimiento datetime,
	@EjecucionPor int,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF @IdClienteContacto = 0
			RAISERROR(N'El campo IdClienteContacto es un campo requerido',
			16,
			1
			)

		IF @IdUnidad = 0
			RAISERROR(N'El campo IdUnidad es un campo requerido',
			16,
			1
			)

		IF @IdClienteContactoUnidad = 0
		BEGIN
			INSERT INTO CatClientesContactosUnidades(IdClienteContacto,IdUnidad,Permanente,FechaHoraVencimiento,CreadoPor,CreadoEl) VALUES(@IdClienteContacto,@IdUnidad,@Permanente,@FechaHoraVencimiento,@EjecucionPor,GETDATE()) 
			INSERT INTO CatClientesContactosUnidadesHistorico(IdClienteContacto,IdUnidad,Permanente,FechaHoraVencimiento,CreadoPor,CreadoEl,FechaHoraActivacion) VALUES(@IdClienteContacto,@IdUnidad,@Permanente,@FechaHoraVencimiento,@EjecucionPor,GETDATE(),GETDATE()) 
		END	
		ELSE
		BEGIN
			UPDATE CatClientesContactosUnidades SET IdClienteContacto = @IdClienteContacto,IdUnidad = @IdUnidad,Permanente = @Permanente,FechaHoraVencimiento = @FechaHoraVencimiento,ModificadoPor = @EjecucionPor,ModificadoEl = GETDATE()	WHERE IdClienteContactoUnidad  = @IdClienteContactoUnidad
			INSERT INTO CatClientesContactosUnidadesHistorico(IdClienteContacto,IdUnidad,Permanente,FechaHoraVencimiento,ModificadoPor,ModificadoEl,FechaHoraActivacion) VALUES(@IdClienteContacto,@IdUnidad,@Permanente,@FechaHoraVencimiento,@EjecucionPor,GETDATE(),GETDATE()) 
		END

		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

