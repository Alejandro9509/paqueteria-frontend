CREATE PROCEDURE [dbo].[usp_ProReportesRoboVecesImpreso]

@IdReportesRobo	int,
@IdPeticion varchar 

AS
DECLARE 
	@Contador int


BEGIN TRY
	BEGIN TRANSACTION
	
		
			IF ISNULL(@IdReportesRobo,0)= 0
				RAISERROR(N'El IdReporteRobo es un campo requerido',
					16,
					1
					)
		
		SET 	@Contador = (SELECT isnull(ContadorImpresiones,0) FROM ProReportesRobo where IdReportesRobo = @IdReportesRobo) +1  			 																					
		
				
				
	UPDATE ProReportesRobo SET
	ContadorImpresiones= @Contador 
	WHERE 	IdReportesRobo=@IdReportesRobo 
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

