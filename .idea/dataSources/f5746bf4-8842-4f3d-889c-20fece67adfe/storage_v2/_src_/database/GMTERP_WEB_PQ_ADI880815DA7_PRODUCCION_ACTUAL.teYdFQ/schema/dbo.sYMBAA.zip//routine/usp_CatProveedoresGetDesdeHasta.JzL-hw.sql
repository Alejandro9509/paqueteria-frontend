





CREATE PROCEDURE [dbo].[usp_CatProveedoresGetDesdeHasta]

AS

SELECT ISNULL(MAX(NumeroProveedor),0) AS Hasta,ISNULL(MIN(NumeroProveedor),0) AS Desde FROM CatProveedores
go

