CREATE PROCEDURE [dbo].[usp_ProRecubrimientosAgregar]  
 @Folio int,  
 @FechaHora datetime,  
 @QuienEntrego varchar(50),  
 @QuienRecibe varchar(50),  
 @FechaHoraEnvio datetime,  
 @FechaHoraProximoRetorno datetime,  
 @FechaHoraRetorno datetime,  
 @dsProRecubrimientosLlantas ntext,
 @Conseptos ntext,  
 @GeneraOrdenDeCompra bit,
 @FolioOC int,
 @FechaOC dateTime,
 @IdProveedor int,  
 @IdAlmacen int,
 @TipoCambio money,  
 @IdMoneda int,     
 @SubTotal money,
 @Total money,  
 @IdEstatusOC int,
 @CreadoPor int,  
 @CreadoEl datetime,   
 @IdPeticion varchar(100),
 @IdImpuestosTrasladadosFederales int,  
 @ImpuestosTrasladadosFederales money,  
 @IdImpuestosRetenidosFederales int,  
 @ImpuestosRetenidosFederales money,  
 @IdImpuestosTrasladadosLocales int,  
 @ImpuestosTrasladadosLocales money,  
 @IdImpuestosRetenidosLocales int,  
 @ImpuestosRetenidosLocales money    
 AS  
DECLARE  
 @docHandle int,  
 @Estatus int,
 @IdOrdenCompra int,
 @IdProRecubrimiento int,
 @ATT_IdLLanta int,
 @ATT_IdArticulo int,
 @ATT_Costo decimal(15,2),
 @EconomicosError varchar(max),
 @EconomicosError2 varchar(max),
 @MsgError varchar(max)
 
SET XACT_ABORT ON 	
BEGIN TRY  
 BEGIN TRANSACTION  
  
 IF Isnull(@Folio,0) = 0  
		  RAISERROR(N'El folio del recubrimiento es un campo requerido',  
		   16,  
		   1  
		   )     

           
 IF EXISTS(SELECT Folio FROM ProRecubrimientos WHERE Folio = @Folio)
		RAISERROR(N'El folio del recubrimiento ya existe',
			16,
			1
			)  
					   
  IF @GeneraOrdenDeCompra  = 1
  Begin
	IF Isnull(@FolioOC,0) = 0  
		  RAISERROR(N'El Folio de la orden de compra es un campo requerido',  
		   16,  
		   1  
		   )  
	IF Isnull(@IdProveedor,0) = 0  
		  RAISERROR(N'El proveedor de la orden de compra es un campo requerido',  
		   16,  
		   1  
		   )  
	IF Isnull(@SubTotal,0) = 0  
		  RAISERROR(N'El subtotal de la orden de compra es un campo requerido',  
		   16,  
		   1  
		   )  
	IF ISDATE(@FechaOC) = 0
		  RAISERROR(N'La fecha de la Orden de compra es un campo requerido',  
		   16,  
		   1  
		   )  
  
	 IF Isnull(@IdMoneda,0) = 0  
	  RAISERROR(N'La moneda es un campo requerido',  
	   16,  
	   1  
	   )
  End
         
 IF ISDATE(@FechaHora) = 0 
		  RAISERROR(N'La fecha del recubrimiento es un campo requerido',  
		   16,  
		   1  
		   )  
    
 IF CAST(@dsProRecubrimientosLlantas AS VARCHAR(MAX))=''
	   RAISERROR(N'Los conceptos de la orden de compra son requeridos',
	   16,  
	   1  
	   )  
         
 Set @Estatus = (Select IdEstatuLlanta from CatEstatusLlantas Where EstatusLLanta = 'EN RECUBRIMIENTO' And DefinidoPorSistema = 1)
 
 INSERT INTO ProRecubrimientos(Folio,Fecha,QuienEntrego,QuienRecibe,FechaEnvio,FechaProximaRetorno,FechaRetorno,Estatus,CreadoPor,CreadoEl)  
 VALUES(@Folio,@FechaHora,@QuienEntrego,@QuienRecibe,@FechaHoraEnvio,@FechaHoraProximoRetorno,@FechaHoraRetorno,1,@CreadoPor,@CreadoEl)  
  
 SET @IdProRecubrimiento = (SELECT IDENT_CURRENT('ProRecubrimientos'))     
 --===========================================================   
 --SECCION PARA AGREGAR EL DETALLE DE LAS LLANTAS ENVIADAS----
 --===========================================================
 
   
 IF @dsProRecubrimientosLlantas IS NOT NULL
 BEGIN
	 Set @EconomicosError  = ''
	 Set @EconomicosError2  = ''
	 EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProRecubrimientosLlantas
	 
	 SELECT ATT_Economico,ATT_IdArticulo,ATT_Costo
	 INTO #TempProRecubrimientosLlantas  
	 FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProLlantasEnviarRecubrimiento',2)   
	 WITH (ATT_Economico int,ATT_IdArticulo int,ATT_Costo decimal(15,4))  
	 
	 EXEC sp_xml_removedocument @docHandle  
	 
	 DECLARE ProRecubrimientosLlantasCursor CURSOR FOR
	 SELECT * FROM #TempProRecubrimientosLlantas  

	 OPEN ProRecubrimientosLlantasCursor
	 FETCH NEXT FROM ProRecubrimientosLlantasCursor
	 INTO @ATT_IdLLanta,@ATT_IdArticulo,@ATT_Costo
		
	 WHILE @@FETCH_STATUS = 0
	 BEGIN		
		IF @ATT_IdArticulo = 0
		SET @ATT_IdArticulo = NULL
		IF (Select IdProcesoLlanta from ProLlantas Where IdLlanta = @ATT_IdLLanta) <> (Select IdProcesoLLanta from CatProcesosLlantas Where ProcesoLlanta = 'DESASIGNADO')		
		Begin
			If @EconomicosError = ''
				Set @EconomicosError = (Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
			else
				Set @EconomicosError = @EconomicosError +', '+(Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
		end
	 
		IF (Select IdEstatuLlanta from ProLlantas Where IdLlanta = @ATT_IdLLanta) = (Select IdEstatuLlanta from CatEstatusLlantas Where EstatusLLanta = 'EN RECUBRIMIENTO' And DefinidoPorSistema = 1)
		Begin
			If @EconomicosError2 = ''
				Set @EconomicosError2 = (Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
			else
				Set @EconomicosError2 = @EconomicosError2 +', '+(Select NumeroEconomico from ProLlantas Where IdLlanta = @ATT_IdLLanta)
		End

		INSERT INTO ProRecubrimientosLlantas(IdRecubrimiento,IdLlanta,IdArticulo,Costo,CreadoPor,CreadoEl)  
        Values (@IdProRecubrimiento,@ATT_IdLLanta,@ATT_IdArticulo,@ATT_Costo,@CreadoPor,@CreadoEl)
                       
        INSERT INTO ProLlantasAuxiliar(IdLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CreadoEl,CreadoPor,IdProcesoLlanta)
        Values(@ATT_IdLLanta
               ,@FechaHora
               ,(Select IdEstatuLlanta from CatEstatusLlantas Where EstatusLLanta = 'EN RECUBRIMIENTO' And DefinidoPorSistema = 1)
               ,(Select PresionActual from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,(Select ProfundidadOriginal from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,(Select KilometrajeLLanta from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,(Select KilometrajeLLanta from ProLlantas Where IdLlanta = @ATT_IdLLanta)
               ,@CreadoEl,@CreadoPor
               ,(Select IdProcesoLLanta from CatProcesosLlantas Where ProcesoLlanta = 'EN RECUBRIMIENTO')
               )
        
        Update ProLlantas Set IdEstatuLlanta = (Select IdEstatuLlanta from CatEstatusLlantas Where EstatusLLanta = 'EN RECUBRIMIENTO' And DefinidoPorSistema = 1),
							  IdProcesoLlanta = (Select IdProcesoLLanta from CatProcesosLlantas Where ProcesoLlanta = 'EN RECUBRIMIENTO')
        Where IdLlanta = @ATT_IdLLanta
        
        
		FETCH NEXT FROM ProRecubrimientosLlantasCursor
		INTO @ATT_IdLLanta,@ATT_IdArticulo,@ATT_Costo
	 END
	 CLOSE ProRecubrimientosLlantasCursor
	 DEALLOCATE ProRecubrimientosLlantasCursor
 END
 IF @EconomicosError <> '' 
 begin
	Set @MsgError = 'La(s) llanta(s) No. '+@EconomicosError+' no se pueden enviar a recubrir esta asignada a una unidad'
	RAISERROR(@MsgError ,  
	16,  
	1  
	) 
end    
 IF @EconomicosError2 <> '' 
 begin
	Set @MsgError = 'La(s) llanta(s) No. '+@EconomicosError2+' ya fueron asignadas a otro Recubrimiento'
	RAISERROR(@MsgError ,  
	16,  
	1  
	) 
end    
 If @GeneraOrdenDeCompra = 1
 Begin
	exec @IdOrdenCompra = usp_ProOrdenCompraAgregar @FolioOC,@IdProveedor,@FechaOC,@SubTotal,NULL,NULL,@IdImpuestosTrasladadosFederales,@ImpuestosTrasladadosFederales,@IdImpuestosRetenidosFederales,@ImpuestosRetenidosFederales,@IdImpuestosTrasladadosLocales,@ImpuestosTrasladadosLocales,@IdImpuestosRetenidosLocales,@ImpuestosRetenidosLocales,@Total,@TipoCambio,@IdMoneda,@IdEstatusOC,NULL,@CreadoPor,@CreadoEl,@Conseptos,@IdPeticion,@IdAlmacen,NULL
	Update ProRecubrimientos Set IdOrdenCompra = @IdOrdenCompra Where IdRecubrimiento = @IdProRecubrimiento
 End
     
    
 COMMIT  
END TRY  
BEGIN CATCH  
 IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

