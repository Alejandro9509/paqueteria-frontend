CREATE PROCEDURE [dbo].[usp_ProMemosAgregar]
	@FechaHora datetime,
	@Memo ntext,
	@NombreArchivo varchar(150),
	@Descripcion varchar(8000),
	@Activa bit,
	@CreadoPor int, 
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@FechaHoraInicio datetime,
	@dsCatUsuariosMemo ntext

	/* *************************************************************************************************
Procedimiento usp_ProMemosAgregar

Parámetros: 
	@FechaHora			(entrada, datetime). Fecha y hora de la creación del memo
	@Memo				(entrada, string). Archivo adjunto del memo
	@NombreArchivo		(entrada, string). Nombre del archivo adjunit
	@Descripcion		(entrada, string). Descripción del memo
	@Activa				(entrada, booleano). Boleano para determinar si el memo está activo o inactivo
	@CreadoPor			(entrada, entero). Id del usuario que crea el memo
	@CreadoEl			(entrada, datetime). Fecha y hora de la creación del memo
	@IdPeticion			(entrada, string). Id de petición
	@FechaHoraInicio	(entrada, datetime). Fecha y hora en la que se mostrará el aviso
	@dsCatUsuariosMemo	(entrada, entero). XML con  los usuarios asignados
	

Descripción: Procedimiento para agregar un memo

22/05/2020 - Se agregaron nuevos parámetros de entrada para ligar a los usuarios destinatarios y crear 
			avisos de notificación

25/05/2020 - Se agregó FechaHoraInicio a la tabla de ProMemos


Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXXX

Modificada por:  Julio Hermosillo
Fecha de mofidicacion: 22/05/2020
Versión ERP: 8.0.52.17

Modificada por:  Julio Hermosillo
Fecha de mofidicacion: 25/05/2020
Versión ERP: 8.0.52.26

------------------------------------------------------------------------------------------------------
Modificada por:  Ignacio Perez
Fecha de mofidicacion: 08/09/2020
Versión ERP: Versión 8.0.55.23

Se modifico para que en SisAvisosDestinatarios mandara la hora correcta (recalculada por sucursal)
-------------------------------------------------------------------------------------------------------

Invocada desde: PAGE_ProMemosAM (Solicitud xxxx)
***************************************************************************************************** */

AS
DECLARE
	@IdMemo int,
	@IdAviso int,
	@docHandle int,
	@Asunto varchar(255) = 'MEMO',
	@RecordarCadaMin int = 5,
	@EnviarTodosLosUsuarios bit = 0,
	@ATT_IdMemoUsuario int,
	@ATT_IdMemo int,
	@ATT_IdUsuario int,
	@ATT_FechaHoraSucursal datetime

BEGIN TRY
	BEGIN TRANSACTION
	IF @CreadoPor = 0
		RAISERROR(N'El usuario solicitante es requerido',
			16,
			1
			)

	IF @FechaHora =''
		RAISERROR(N'Fecha/hora es un campo requerido',
			16,
			1
			)

			IF @FechaHoraInicio =''
		RAISERROR(N'Fecha y hora de inicio es un campo requerido',
			16,
			1
			)
	
	INSERT INTO ProMemos(FechaHora,Memo,NombreArchivo,Descripcion,Activa,FechaHoraInicio,CreadoPor,CreadoEl)	
	VALUES(@FechaHora,@Memo,@NombreArchivo,@Descripcion,@Activa,@FechaHoraInicio,@CreadoPor,@CreadoEl)

	SET @IdMemo = (SELECT IDENT_CURRENT('ProMemos'))

	IF @dsCatUsuariosMemo IS NOT NULL
		BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUsuariosMemo
		
			SELECT ATT_IdUsuario, ATT_IdMemo, ATT_FechaHoraSucursal
			INTO #TempCatUsuariosMemo
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatUsuarios',2) 
			WITH (ATT_IdUsuario int, ATT_IdMemo int, ATT_FechaHoraSucursal datetime)

			EXEC sp_xml_removedocument @docHandle

			INSERT INTO ProMemosUsuarios(IdMemo,IdUsuario)
			SELECT @IdMemo, ATT_IdUsuario
			FROM #TempCatUsuariosMemo
			
			--- se crea un cursor sobre la tabla temporal para reccorrela secuencialmente
				DECLARE ProMemosUsuariosCursor CURSOR FOR
				SELECT ATT_IdMemo, ATT_IdUsuario, ATT_FechaHoraSucursal FROM #TempCatUsuariosMemo 
				OPEN ProMemosUsuariosCursor
			
				FETCH NEXT FROM ProMemosUsuariosCursor
				INTO @ATT_IdMemo, @ATT_IdUsuario, @ATT_FechaHoraSucursal


				WHILE @@FETCH_STATUS = 0
				BEGIN	
			   	
					INSERT INTO SisAvisos(IdMemo,Asunto,Aviso,CreadoEl,CreadoPor,EnviarEl,EnviarTodosLosUsuarios,RecordarCadaMin)
					VALUES(@IdMemo,@Asunto,@Descripcion,@CreadoEl,@CreadoPor,@FechaHoraInicio,@EnviarTodosLosUsuarios,@RecordarCadaMin)
				
					SET @IdAviso = (SELECT IDENT_CURRENT('SisAvisos'))

					INSERT INTO SisAvisosDestinatarios(IdAviso,IdUsuarioDestinatario,UltimaNotificacion)
					VALUES(@IdAviso,@ATT_IdUsuario,@ATT_FechaHoraSucursal)
				

					FETCH NEXT FROM ProMemosUsuariosCursor
					INTO @ATT_IdMemo, @ATT_IdUsuario, @ATT_FechaHoraSucursal
	
				END --- WHILE @@FETCH_STATUS = 0
			
				CLOSE ProMemosUsuariosCursor
				DEALLOCATE ProMemosUsuariosCursor
		END
	COMMIT 
END TRY

BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

