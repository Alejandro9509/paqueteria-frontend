CREATE PROCEDURE [dbo].[usp_CatRemitentesDestinatariosGetNextNumeroPQ]
	
	AS BEGIN 
		
		SELECT TOP 1 * FROM (
    SELECT t1.Numero+1 AS NextNumero
    FROM CatRemitentesDestinatarios t1
    WHERE NOT EXISTS(SELECT * FROM CatRemitentesDestinatarios t2 WHERE t2.Numero = t1.Numero + 1 )
    UNION 
    SELECT 1 AS NextNumero
    WHERE NOT EXISTS (SELECT * FROM CatRemitentesDestinatarios t3 WHERE t3.Numero = 1)) ot
ORDER BY 1
	
END
go

