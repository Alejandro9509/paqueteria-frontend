CREATE PROCEDURE [dbo].[usp_CatUsuariosAgregar]	
	@Usuario varchar(16),
	@Nombre varchar(100),
	@NombreCorto varchar(12),
	@Contrasena varchar (20),
	@TipoUsuario tinyint,
	@CorreoElectronico varchar(100),
	@IdSucursal int,
	@Activo bit,
	@CreadoEl datetime,
	@CreadoPor int,	
	@FiltrarAcceso bit,
	@FiltrarAccesoPorLaIP varchar(15),
	@FiltrarAccesoPorHora bit,
	@Hora0 bit,
	@Hora1 bit,	
	@Hora2 bit,
	@Hora3 bit,
	@Hora4 bit,
	@Hora5 bit,
	@Hora6 bit,
	@Hora7 bit,
	@Hora8 bit,
	@Hora9 bit,
	@Hora10 bit,
	@Hora11 bit,	
	@Hora12 bit,
	@Hora13 bit,
	@Hora14 bit,
	@Hora15 bit,
	@Hora16 bit,
	@Hora17 bit,
	@Hora18 bit,
	@Hora19 bit,
	@Hora20 bit,
	@Hora21 bit,	
	@Hora22 bit,
	@Hora23 bit,
	@Lunes bit,
	@Martes bit,
	@Miercoles bit,
	@Jueves bit,
	@Viernes bit,
	@Sabado bit,
	@Domingo bit,	
	@IdPeticion varchar(100),
	@MostrarCatalogosOtrasSucursales bit,
	@dsUsuariosucursales ntext,
	@dsUsuariosAlmacenes ntext,
	@TraficoNotificacion bit,
	@TraficoNotificacionAsistencia bit,
	@OpPortuariaNotificacion bit,
	@VencimientoCertificadosNotificacion bit

	/* *************************************************************************************************
	SOLICITUD 556

	Descripcion: Se agrego una validacion para enviar un mensaje en caso de que el usuario nuevo ya exista
	en CatUsuarios

	16/06/2020 - Se agrego parámetro de entrada para notificacion de vencimiento de certificados

	04/08/2020 - Se agregó flujo para actualizar el campo SolicitarCambioContrasena

	Modificado por:   Amado Navarro
	Fecha de Creación: 19/12/2019
	Versión: Versión 8.0.48.45

	Modificado por:   Raymundo Espinoza Garcia
	Fecha de Creación: 24/03/2020
	Versión: 8.0.51.15

	Modificado por:   Julio Hermosillo
	Fecha de Modificacion: 16/06/2020
	Versión: 8.0.53.10

	Modificado por:   Julio Hermosillo
	Fecha de Modificacion: 04/08/2020
	Versión: 8.0.54.28

	Invocada desde: <PAGE_CatUsuariosAM>
	************************************************************************************************ */
AS
DECLARE
	@docHandle int,
	@ATT_IdSucursal int,
	@ATT_NumeroProceso int,
	@IdUsuario int,
	@ATT_IdAlmacen int,
	@FechaSolicitarCambioContrasena datetime,
	@SolicitarCambioContrasena bit,
	@CantidadDiasSolicitarContrasena int

	SET @SolicitarCambioContrasena = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'SolicitarCambioContrasena')
	SET @FechaSolicitarCambioContrasena = null
BEGIN TRY
	BEGIN TRANSACTION

	IF LTRIM(RTRIM(@Usuario)) = ''
		RAISERROR(N'El campo de usuario es requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@Nombre)) = ''
		RAISERROR(N'El campo nombre de usuario es requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@CorreoElectronico)) = 'El campo correo electtonico es requerido'
		RAISERROR(N'',
		16,
		1
		)			
	IF LTRIM(RTRIM(@NombreCorto)) = ''
		RAISERROR(N'El campo nombre corto de usuario es requerido',
			16,
			1
			)
	IF LTRIM(RTRIM(@Contrasena)) = ''
		RAISERROR(N'El campo contraseña es requerido',
			16,
			1
			)			
	IF @TipoUsuario =0 
		RAISERROR(N'El campo tipo de usuario es requerido',
			16,
			1
			)			
	IF @IdSucursal <= 0
		RAISERROR(N'El campo sucursal es requerido',
			16,
			1
			)
	--SOLICITUD 556
	IF (SELECT TOP 1 Usuario FROM CatUsuarios WHERE Usuario = @Usuario) <> ''
		RAISERROR(N'El nombre de usuario ya esta registrado, favor de validar',
			16,
			1
			)

	IF @SolicitarCambioContrasena = 1 AND @Usuario <> 'GM' AND @TipoUsuario <> 5
			BEGIN
				SET @CantidadDiasSolicitarContrasena = (SELECT Valor FROM SisParametrosValores WHERE Parametro = 'CantidadDiasSolicitarContrasena')			

				IF @CantidadDiasSolicitarContrasena > 0
					BEGIN
						SET @FechaSolicitarCambioContrasena = (Getdate() + @CantidadDiasSolicitarContrasena)
					END
			END

	INSERT INTO CatUsuarios(Usuario,Nombre,NombreCorto,Contrasena,TipoUsuario,CorreoElectronico,IdSucursal,Activo,CreadoEl,CreadoPor,
	FiltrarAcceso,FiltrarAccesoPorLaIP,FiltrarAccesoPorHora,Hora0,Hora1,Hora2,Hora3,Hora4,Hora5,Hora6,Hora7,
	Hora8,Hora9,Hora10,Hora11,Hora12,Hora13,Hora14,Hora15,Hora16,Hora17,Hora18,Hora19,Hora20,Hora21,Hora22,Hora23,
	Lunes,Martes,Miercoles,Jueves,Viernes,Sabado,Domingo,MostrarCatalogosOtrasSucursales,TraficoNotificaciones,
	TraficoNotificacionesAsistencia,OpPortuariaNotificaciones, VencimientoCertificadosNotificaciones, SolicitarCambioContrasena)
	VALUES(@Usuario,@Nombre,@NombreCorto,@Contrasena,@TipoUsuario,@CorreoElectronico,@IdSucursal,@Activo,@CreadoEl,@CreadoPor,
	@FiltrarAcceso,@FiltrarAccesoPorLaIP,@FiltrarAccesoPorHora,@Hora0,@Hora1,@Hora2,@Hora3,@Hora4,@Hora5,@Hora6,@Hora7,
	@Hora8,@Hora9,@Hora10,@Hora11,@Hora12,@Hora13,@Hora14,@Hora15,@Hora16,@Hora17,@Hora18,@Hora19,@Hora20,@Hora21,@Hora22,@Hora23,
	@Lunes,@Martes,@Miercoles,@Jueves,@Viernes,@Sabado,@Domingo,@MostrarCatalogosOtrasSucursales,@TraficoNotificacion,
	@TraficoNotificacionAsistencia,@OpPortuariaNotificacion, @VencimientoCertificadosNotificacion, @FechaSolicitarCambioContrasena)	
	
	SET @IdUsuario = (SELECT IDENT_CURRENT('CatUsuarios'))
	--SECCION PARA AGREGAR LOS Permisos x sucursal
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsUsuariosucursales
	
	SELECT ATT_IdSucursal,ATT_NumeroProceso
	INTO #TempCatUsuariosucursales
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_UsuariosSucursales',2) 
	WITH (ATT_IdSucursal int,ATT_NumeroProceso int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatUsuariosucursales CURSOR FOR
	SELECT * FROM #TempCatUsuariosucursales
	
	OPEN CursorCatUsuariosucursales
	FETCH NEXT FROM CursorCatUsuariosucursales
	INTO @ATT_IdSucursal,@ATT_NumeroProceso
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatUsuariosSucursales(IdUsuario,IdSucursal,Proceso,CreadoEl,CreadoPor)
		VALUES(@IdUsuario,@ATT_IdSucursal,@ATT_NumeroProceso,@CreadoEl,@CreadoPor)		

		FETCH NEXT FROM CursorCatUsuariosucursales
		INTO @ATT_IdSucursal,@ATT_NumeroProceso
	END

	CLOSE CursorCatUsuariosucursales
	DEALLOCATE CursorCatUsuariosucursales

   --SECCION PARA AGREGAR LOS Permisos x almacen
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsUsuariosAlmacenes
	
	SELECT ATT_IdAlmacen
	INTO #TempCatUsuarioAlmacenes
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_UsuariosAlmacenes',2) 
	WITH (ATT_IdAlmacen int)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatUsuarioAlmacenes CURSOR FOR
	SELECT * FROM #TempCatUsuarioAlmacenes
	
	OPEN CursorCatUsuarioAlmacenes
	FETCH NEXT FROM CursorCatUsuarioAlmacenes
	INTO @ATT_IdAlmacen
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatUsuariosAlmacenes(IdUsuario,IdAlmacen,CreadoEl,CreadoPor)
		VALUES(@IdUsuario,@ATT_IdAlmacen,@CreadoEl,@CreadoPor)		

		FETCH NEXT FROM CursorCatUsuarioAlmacenes
		INTO @ATT_IdAlmacen
	END

	CLOSE CursorCatUsuarioAlmacenes
	DEALLOCATE CursorCatUsuarioAlmacenes

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

