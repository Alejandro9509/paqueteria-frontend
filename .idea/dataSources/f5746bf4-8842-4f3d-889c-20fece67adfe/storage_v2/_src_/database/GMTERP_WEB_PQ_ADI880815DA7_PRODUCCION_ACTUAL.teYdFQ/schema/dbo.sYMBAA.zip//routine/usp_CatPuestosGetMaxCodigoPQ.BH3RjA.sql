CREATE PROCEDURE [dbo].[usp_CatPuestosGetMaxCodigoPQ]
	
	AS BEGIN 
		
		select  max( Codigo ) as Codigo from CatPuestos
	
END
go

