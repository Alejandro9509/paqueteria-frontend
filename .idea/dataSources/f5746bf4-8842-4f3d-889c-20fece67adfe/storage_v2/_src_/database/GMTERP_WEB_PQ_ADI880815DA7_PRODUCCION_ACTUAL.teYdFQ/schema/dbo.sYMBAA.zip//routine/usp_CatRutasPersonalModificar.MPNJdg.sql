CREATE PROCEDURE [dbo].[usp_CatRutasPersonalModificar]	
	@IdRutaPersonal int,
	@IdCliente int,
	@IdOrigen int,
	@IdDestino int,
	@IdTipoUnidad int,
	@IdTurno int,
	@IdClasificacionViaje int,
	@IdTipoRuta int,
	@IdSucursal int,
	@FolioRuta int,
	@Descripcion varchar(140),
	@AccesorioTV bit,
	@AccesorioWIFI bit,
	@AccesorioAC bit,
	@AccesorioDiscapacitados bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@Activa bit,
	@IdPeticion varchar(100),
	@dsCatRutasPersonalConceptosFacturacion ntext,	
	@dsCatRutasPersonalClientesContatos ntext,
	@dsCatRutasPersonalParadas ntext,
	@IdSupervisor int

	/* *************************************************************************************************
Procedimiento usp_CatRutasPersonalModificar
 
Descripción: Procedimiento para modificar una ruta/tarifa

13/05/2020 - Se aplica modificacion para que se puedan agregar mas de una parada a la ruta


Implementada por: XXXXXX
Fecha de implementacion: XXXXXX
Versión ERP: XXXXXX

Modificada por:   Francisco Villela
Fecha de mofidicacion: 13/05/2020
Versión ERP: 8.0.52.05



Invocada desde: PAGE_CatRutasAM
***************************************************************************************************** */
AS
DECLARE
	@docHandle int,
	@CursorIdRutaPersonalConceptoFacturacion int,
	@CursorIdConceptoFacturacion int,
	@CursorImporte money,
	@CursorImporteDlls money,
	@CursorIdRutaPersonalPuntuacion int,
	@CursorIdPuesto int,
	@CursorPuntos int,
	@CursorIdRutaPersonalClienteContacto int, 
	@CursorIdClienteContacto int,
	@CursorIdGeocerca int, 
	@CursorIdEstatuViajeEntrada int, 
	@CursorIdEstatuViajeSalida int, 
	@CursorIdRutaPersonalParada  int,
	@COL_Secuencia int,
	@COL_IdOrigen int,
	@COL_IdDestino int,
	@COL_Kilometros int,
	@COL_Horas decimal(15,2),
	@COL_RutaGoogleMap varchar(max),
	@COL_GastosAutorizados varchar(8000),
	@COL_SueldoBase money,
	@COL_SueldoBaseDlls money,
	@COL_IdGeocercaDisparaSalida int,
	@COL_GeocercaDisparaSalidaES tinyint,
	@COL_IdGeocercaDisparaLlegada int,
	@COL_GeocercaDisparaLlegadaES tinyint,
	@COL_Geocercas varchar(max),
	@COL_IdEstatuViajeSalida int,
	@COL_IdEstatuViajeLlegada int,	
	@IdRutaTrayecto int,
	@COL_TipoTrayecto TINYINT,
	@COL_Puntuaciones varchar(max),
	@COL_HoraSalida datetime,
	@COL_HoraReporte datetime,
	@CursorIdTipoViaje int,
	@CursorIdTipoUnidad int,
	@CursorIdClasificacionViaje int,
	@IdImpuestoTrasladado decimal(15,2),
	@IdImpuestoRetenido decimal(15,2),
	@CursorTraslada bit,
	@CursorRetiene bit,
	@IdRutaConceptoFacturacion int
			
BEGIN TRY
	BEGIN TRANSACTION
		IF (SELECT ModificadoEl FROM CatRutasPersonal WHERE IdRutaPersonal = @IdRutaPersonal) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta ruta fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise',
			16,
			1
			)
		IF @FolioRuta = 0
		RAISERROR(N'El folio de la ruta es un campo requerido',
			16,
			1
			)
		IF EXISTS(SELECT * FROM CatRutasPersonal WHERE FolioRuta = @FolioRuta AND IdRutaPersonal != IdRutaPersonal)			
		RAISERROR(N'El folio de la ruta ya existe en el catálogo',
			16,
			1
			)
		IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
		IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)			
		IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)			
		IF RTRIM(LTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción de la ruta es un campo requerido',
			16,
			1
			)	
		IF @IdSucursal = 0
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)
		IF @IdClasificacionViaje = 0
			SET @IdClasificacionViaje = NULL
		IF @IdTurno = 0 
			SET @IdTurno = NULL
		IF @IdTipoUnidad = 0
			SET	@IdTipoUnidad = NULL
		IF @IdTipoRuta = 0
			SET @IdTipoRuta = NULL	
		IF @IdSupervisor = 0
			SET @IdSupervisor = NULL	
	
	
	--UPDATE A LA TABLA CATRUTASPERSONAL CON LA INFORMACION PROPORCIONADA		
	UPDATE CatRutasPersonal SET
	IdCliente = @IdCliente,
	IdOrigen = @IdOrigen,
	IdDestino = @IdDestino,
	IdTipoUnidad = @IdTipoUnidad,
	IdTurno = @IdTurno,
	IdClasificacionViaje = @IdClasificacionViaje,
	IdTipoRuta = @IdTipoRuta,
	IdSucursal = @IdSucursal,
	FolioRuta = @FolioRuta,
	Descripcion = @Descripcion,
	AccesorioTV = @AccesorioTV,
	AccesorioWIFI = @AccesorioWIFI,
	AccesorioAC = @AccesorioAC,
	AccesorioDiscapacitados = @AccesorioDiscapacitados,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	Activa = @Activa,
	IdSupervisor = @IdSupervisor
	WHERE IdRutaPersonal = @IdRutaPersonal
		
	--SECCION PARA AGREGAR LOS CONCEPTOS
	IF @dsCatRutasPersonalConceptosFacturacion IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalConceptosFacturacion
		
		SELECT ATT_IdRutaPersonalConceptoFacturacion,ATT_IdConceptoFacturacion,ATT_Importe,ATT_ImporteDlls,
		COL_IdTipoViaje,COL_IdTipoUnidad,COL_IdClasificacionViaje,COL_IdImpuestoTrasladado,COL_IdImpuestoRetenido,COL_Traslada,COL_Retiene
		INTO #TempCatRutasPersonalConceptosFacturacion
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalConceptosFacturacion',2) 
		WITH (ATT_IdRutaPersonalConceptoFacturacion int,ATT_IdConceptoFacturacion int,ATT_Importe money ,ATT_ImporteDlls money,
		COL_IdTipoViaje int,COL_IdTipoUnidad int,COL_IdClasificacionViaje int,COL_IdImpuestoTrasladado int, COL_IdImpuestoRetenido int,COL_Traslada bit ,COL_Retiene bit)
		
		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorCatRutasPersonalConceptosFacturacion CURSOR FOR
		SELECT * FROM #TempCatRutasPersonalConceptosFacturacion
		
		OPEN CursorCatRutasPersonalConceptosFacturacion
		FETCH NEXT FROM CursorCatRutasPersonalConceptosFacturacion
		INTO @CursorIdRutaPersonalConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,
		@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
		
		WHILE @@FETCH_STATUS = 0
		BEGIN          
			IF ISNULL(@CursorIdConceptoFacturacion,0) <= 0	
			RAISERROR(N'EL concepto es un campo requerido',
				16,
				1
				)	
			IF @CursorIdTipoViaje = 0
				SET	@CursorIdTipoViaje = NULL

			IF @CursorIdTipoUnidad = 0
				SET	@CursorIdTipoUnidad = NULL

			IF @CursorIdClasificacionViaje = 0
				SET	@CursorIdClasificacionViaje = NULL

			IF @CursorIdRutaPersonalConceptoFacturacion = 0	
			BEGIN
				INSERT INTO CatRutasPersonalConceptosFacturacion(IdRutaPersonal,IdConceptoFacturacion,Importe,ImporteDlls,CreadoPor,CreadoEl,
				IdTipoViaje,IdTipoUnidad,IdClasificacionViaje,TrasladaImpuesto,RetieneImpuesto)
				VALUES(@IdRutaPersonal,@CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,@ModificadoPor,@ModificadoEl,
				@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@CursorTraslada,@CursorRetiene)	

				SET @IdRutaConceptoFacturacion = (SELECT IDENT_CURRENT('CatRutasPersonalConceptosFacturacion'))

				IF @IdImpuestoTrasladado != 0 
				BEGIN
					INSERT INTO CatRutasPersonalConceptosFacturacionImpuestos(IdRutaPersonalConceptoFacturacion,IdImpuesto)
					VALUES( @IdRutaConceptoFacturacion,@IdImpuestoTrasladado )
				END

				IF @IdImpuestoRetenido != 0
				BEGIN
					INSERT INTO CatRutasPersonalConceptosFacturacionImpuestos(IdRutaPersonalConceptoFacturacion,IdImpuesto)
					VALUES( @IdRutaConceptoFacturacion,@IdImpuestoRetenido )
				END
			END
			ELSE
			BEGIN
				UPDATE CatRutasPersonalConceptosFacturacion SET
				IdRutaPersonal = @IdRutaPersonal,
				IdConceptoFacturacion = @CursorIdConceptoFacturacion,
				Importe = @CursorImporte,
				ImporteDlls = @CursorImporteDlls,
				ModificadoPor = @ModificadoPor,
				ModificadoEl = @ModificadoEl,
				IdTipoViaje = @CursorIdTipoViaje,
				IdTipoUnidad = @CursorIdTipoUnidad,
				IdClasificacionViaje = @CursorIdClasificacionViaje,
				TrasladaImpuesto = @CursorTraslada,
				RetieneImpuesto = @CursorRetiene
				WHERE  IdRutaPersonalConceptoFacturacion = @CursorIdRutaPersonalConceptoFacturacion

				DELETE FROM CatRutasPersonalConceptosFacturacionImpuestos WHERE IdRutaPersonalConceptoFacturacion = @CursorIdRutaPersonalConceptoFacturacion

				IF @IdImpuestoTrasladado != 0 
				BEGIN
					INSERT INTO CatRutasPersonalConceptosFacturacionImpuestos(IdRutaPersonalConceptoFacturacion,IdImpuesto)
					VALUES( @CursorIdRutaPersonalConceptoFacturacion,@IdImpuestoTrasladado )
				END

				IF @IdImpuestoRetenido != 0
				BEGIN
					INSERT INTO CatRutasPersonalConceptosFacturacionImpuestos(IdRutaPersonalConceptoFacturacion,IdImpuesto)
					VALUES( @CursorIdRutaPersonalConceptoFacturacion,@IdImpuestoRetenido )
				END
			END
			FETCH NEXT FROM CursorCatRutasPersonalConceptosFacturacion
			INTO @CursorIdRutaPersonalConceptoFacturacion,@CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,
			@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
		END
		CLOSE CursorCatRutasPersonalConceptosFacturacion
		DEALLOCATE CursorCatRutasPersonalConceptosFacturacion
	END--SECCION PARA AGREGAR LOS CONCEPTOS
	DELETE FROM CatRutasPersonalConceptosFacturacion WHERE IdRutaPersonal= @IdRutaPersonal AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	
	----SECCION PARA AGREGAR LAS CONTACTOS
	IF @dsCatRutasPersonalClientesContatos IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalClientesContatos
	
		SELECT ATT_IdClienteContacto,ATT_IdRutaPersonalClienteContacto
		INTO #TempCatRutasPersonalClientesContatos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalClientesContatos',2) 
		WITH (ATT_IdClienteContacto int,ATT_IdRutaPersonalClienteContacto int)
	
		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorCatRutasPersonalClientesContatos CURSOR FOR
		SELECT * FROM #TempCatRutasPersonalClientesContatos

		OPEN CursorCatRutasPersonalClientesContatos
		FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
		INTO @CursorIdClienteContacto, @CursorIdRutaPersonalClienteContacto
			
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @CursorIdRutaPersonalClienteContacto = 0
			BEGIN
				INSERT INTO CatRutasPersonalClientesContatos(IdRutaPersonal,IdClienteContacto,CreadoPor,CreadoEl)
				VALUES(@IdRutaPersonal,@CursorIdClienteContacto,@ModificadoPor,@ModificadoEl)
			END
			ELSE
			BEGIN
				UPDATE CatRutasPersonalClientesContatos 
				SET
				IdRutaPersonal = @IdRutaPersonal,
				IdClienteContacto = @CursorIdClienteContacto,
				ModificadoPor = @ModificadoPor,
				ModificadoEl = @ModificadoEl
				WHERE IdRutaPersonalClienteContacto = @CursorIdRutaPersonalClienteContacto
			END
			FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
			INTO @CursorIdClienteContacto, @CursorIdRutaPersonalClienteContacto
		END
		CLOSE CursorCatRutasPersonalClientesContatos
		DEALLOCATE CursorCatRutasPersonalClientesContatos	
	END----SECCION PARA AGREGAR LAS CONTACTOS
	DELETE FROM CatRutasPersonalClientesContatos WHERE IdRutaPersonal = @IdRutaPersonal AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	----SECCION PARA AGREGAR LAS GEOCERCAS 
	IF @dsCatRutasPersonalParadas IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalParadas

		SELECT COL_IdRutaPersonalParada,COL_Secuencia,COL_IdOrigen,COL_IdDestino,COL_Kilometros,COL_Horas,COL_RutaGoogleMap,COL_GastosAutorizados,
				COL_SueldoBase,COL_SueldoBaseDlls,	
				COL_IdGeocercaDisparaSalida,COL_GeocercaDisparaSalidaES,COL_IdGeocercaDisparaLlegada,COL_GeocercaDisparaLlegadaES,COL_Geocercas,
				COL_IdEstatuViajeSalida,COL_IdEstatuViajeLlegada,COL_TipoTrayecto,COL_Puntuaciones,COL_HoraSalida,COL_HoraReporte
		INTO #TempCatRutasPersonalParadas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalParadas',2) 
		WITH (COL_IdRutaPersonalParada int,COL_Secuencia int,COL_IdOrigen int,COL_IdDestino int,COL_Kilometros int,COL_Horas decimal(15,2),COL_RutaGoogleMap ntext,COL_GastosAutorizados varchar(8000),
			COL_SueldoBase money,COL_SueldoBaseDlls money,
			COL_IdGeocercaDisparaSalida int,COL_GeocercaDisparaSalidaES tinyint,COL_IdGeocercaDisparaLlegada int,COL_GeocercaDisparaLlegadaES tinyint,COL_Geocercas ntext,
			COL_IdEstatuViajeSalida int,COL_IdEstatuViajeLlegada int,COL_TipoTrayecto TINYINT,COL_Puntuaciones ntext,COL_HoraSalida datetime,COL_HoraReporte datetime)
		
        EXEC sp_xml_removedocument @docHandle
	
		DECLARE CursorCatRutasPersonalParadas CURSOR FOR
		SELECT * FROM #TempCatRutasPersonalParadas

		OPEN CursorCatRutasPersonalParadas
		FETCH NEXT FROM CursorCatRutasPersonalParadas
		INTO @CursorIdRutaPersonalParada,@COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
				@COL_SueldoBase,@COL_SueldoBaseDlls,
				@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,
				@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,@COL_TipoTrayecto,@COL_Puntuaciones,@COL_HoraSalida,@COL_HoraReporte
	
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @COL_IdEstatuViajeSalida = 0
				SET @COL_IdEstatuViajeSalida = NULL

			IF @COL_IdEstatuViajeLlegada = 0
				SET @COL_IdEstatuViajeLlegada = NULL
		
			IF ISNULL(@COL_Kilometros,0) <= 0	
			RAISERROR(N'El kilometraje la parada es un campo requerido',
				16,
				1
				)
				
			IF ISNULL(@COL_Horas,0) <= 0	
			RAISERROR(N'Las horas para la parada es un campo requerido',
				16,
				1
				)
			IF  @CursorIdRutaPersonalParada= 0	
			BEGIN
				INSERT INTO CatRutasPersonalParadas(CreadoEl,CreadoPor,Horas,IdDestino,IdOrigen,IdRutaPersonal,Kilometros,RutaGoogleMap,Secuencia,		
						SueldoBase,SueldoBaseDlls,IdGeocercaDisparaSalida,GeocercaDisparaSalidaES,IdGeocercaDisparaLlegada,GeocercaDisparaLlegadaES,IdEstatuViajeSalida,
						IdEstatuViajeEntrada,TipoParada,HoraSalida,HoraReporte)
						VALUES(@ModificadoEl,@ModificadoPor,@COL_Horas,@COL_IdDestino,@COL_IdOrigen,@IdRutaPersonal,@COL_Kilometros,@COL_RutaGoogleMap,@COL_Secuencia,
						@COL_SueldoBase,@COL_SueldoBaseDlls,		
						@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,
						@COL_TipoTrayecto,@COL_HoraSalida,@COL_HoraReporte)

					SET @CursorIdRutaPersonalParada = (SELECT IDENT_CURRENT('CatRutasPersonalParadas'))	
			END
			ELSE
			BEGIN
				UPDATE CatRutasPersonalParadas 
				SET ModificadoEl = @ModificadoEl
				,ModificadoPor = @ModificadoPor
				,Horas = @COL_Horas
				,IdDestino = @COL_IdDestino
				,IdOrigen = @COL_IdOrigen
				,IdRutaPersonal = @IdRutaPersonal
				,Kilometros = @COL_Kilometros
				,RutaGoogleMap = @COL_RutaGoogleMap
				,Secuencia = @COL_Secuencia
				,SueldoBase = @COL_SueldoBase
				,SueldoBaseDlls = @COL_SueldoBaseDlls
				,IdGeocercaDisparaSalida = @COL_IdGeocercaDisparaSalida
				,GeocercaDisparaSalidaES = @COL_GeocercaDisparaSalidaES
				,IdGeocercaDisparaLlegada = @COL_IdGeocercaDisparaLlegada
				,GeocercaDisparaLlegadaES = @COL_GeocercaDisparaLlegadaES
				,IdEstatuViajeSalida = @COL_IdEstatuViajeSalida
				,IdEstatuViajeEntrada = @COL_IdEstatuViajeLlegada
				,TipoParada = @COL_TipoTrayecto
				,HoraSalida =@COL_HoraSalida
				,HoraReporte=@COL_HoraReporte
				WHERE IdRutaPersonalParada = @CursorIdRutaPersonalParada	          				
			END

			IF @COL_GastosAutorizados <> ''
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_GastosAutorizados
			
				SELECT ATT_IdRutaTrayectoGasto,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_LitrosAutorizados,ATT_ImporteAutorizadoState,ATT_LitrosAutorizadosState
				INTO #TempCatRutasTrayectosGastos
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosGastos',2) 
				WITH(ATT_IdRutaTrayectoGasto int,ATT_IdConceptoGastoViaje int,ATT_ImporteAutorizado money,ATT_LitrosAutorizados decimal(15,2),ATT_ImporteAutorizadoState int,ATT_LitrosAutorizadosState int)
			
				EXEC sp_xml_removedocument @docHandle
									
				INSERT INTO CatRutasPersonalParadasGastos(IdRutaPersonalParada,IdConceptoGastoViaje,ImporteAutorizado,ImporteAutorizadoState,LitrosAutorizados,LitrosAutorizadosState,CreadoEl,CreadoPor)
				SELECT @CursorIdRutaPersonalParada,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_ImporteAutorizadoState,ATT_LitrosAutorizados,ATT_LitrosAutorizadosState,@ModificadoEl,@ModificadoPor
				FROM #TempCatRutasTrayectosGastos
				WHERE ATT_IdRutaTrayectoGasto = 0
			
				UPDATE CatRutasPersonalParadasGastos SET
					CatRutasPersonalParadasGastos.ImporteAutorizado = #TempCatRutasTrayectosGastos.ATT_ImporteAutorizado,
					CatRutasPersonalParadasGastos.ImporteAutorizadoState = #TempCatRutasTrayectosGastos.ATT_ImporteAutorizadoState,
					CatRutasPersonalParadasGastos.LitrosAutorizados = #TempCatRutasTrayectosGastos.ATT_LitrosAutorizados,
					CatRutasPersonalParadasGastos.LitrosAutorizadosState = #TempCatRutasTrayectosGastos.ATT_LitrosAutorizadosState,
					CatRutasPersonalParadasGastos.ModificadoEl = @ModificadoEl,
					CatRutasPersonalParadasGastos.ModificadoPor = @ModificadoPor
				FROM CatRutasPersonalParadasGastos
				INNER JOIN #TempCatRutasTrayectosGastos ON CatRutasPersonalParadasGastos.IdRutaPersonalParadaGasto = #TempCatRutasTrayectosGastos.ATT_IdRutaTrayectoGasto
			
				DROP TABLE #TempCatRutasTrayectosGastos						
			END
		
			DELETE FROM CatRutasPersonalParadasGastos WHERE IdRutaPersonalParada = @CursorIdRutaPersonalParada AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

			--seccion para agregar y actualizar las geocercas y estatus automaticos
			IF @COL_Geocercas <> ''
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Geocercas

				SELECT COL_IdEstatuViajeEntrar,COL_IdEstatuViajeSalir,COL_IdGeocerca,COL_IdRutaTrayectoGeocerca
				INTO #TempCatRutasTrayectosGeocercas
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosGeocercas',2) 
				WITH(COL_IdEstatuViajeEntrar int,COL_IdEstatuViajeSalir int,COL_IdGeocerca int,COL_IdRutaTrayectoGeocerca int)
            
				EXEC sp_xml_removedocument @docHandle
            
				INSERT INTO CatRutasPersonalParadasGeocercas(IdRutaPersonalParada,IdEstatuViajeEntrada,IdEstatuViajeSalida,IdGeocerca,CreadoEl,CreadoPor)
				SELECT @CursorIdRutaPersonalParada,
				CASE COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE COL_IdEstatuViajeEntrar END,
				CASE COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE COL_IdEstatuViajeSalir END,
				COL_IdGeocerca,@ModificadoEl,@ModificadoPor
				FROM #TempCatRutasTrayectosGeocercas
				WHERE COL_IdRutaTrayectoGeocerca = 0
            
				UPDATE CatRutasPersonalParadasGeocercas SET
					CatRutasPersonalParadasGeocercas.IdGeocerca = #TempCatRutasTrayectosGeocercas.COL_IdGeocerca,
					CatRutasPersonalParadasGeocercas.IdEstatuViajeEntrada = CASE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeEntrar END,
					CatRutasPersonalParadasGeocercas.IdEstatuViajeSalida = CASE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE #TempCatRutasTrayectosGeocercas.COL_IdEstatuViajeSalir END,
					CatRutasPersonalParadasGeocercas.ModificadoEl = @ModificadoEl,
					CatRutasPersonalParadasGeocercas.ModificadoPor = @ModificadoPor
				FROM CatRutasPersonalParadasGeocercas
				INNER JOIN #TempCatRutasTrayectosGeocercas ON CatRutasPersonalParadasGeocercas.IdRutaPersonalParadaGeocerca = #TempCatRutasTrayectosGeocercas.COL_IdRutaTrayectoGeocerca
            
				DROP TABLE #TempCatRutasTrayectosGeocercas
			END
        
			DELETE FROM CatRutasPersonalParadasGeocercas WHERE IdRutaPersonalParada = @CursorIdRutaPersonalParada AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl

			IF @COL_Puntuaciones <> ''
			BEGIN
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Puntuaciones

				SELECT ATT_IdRutaPersonalPuntuacion,ATT_IdPuesto,ATT_Puntos
				INTO #TempCatRutasPersonalPuntuaciones
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalPuntuaciones',2) 
				WITH(ATT_IdRutaPersonalPuntuacion int,ATT_IdPuesto int,ATT_Puntos int)
			
				EXEC sp_xml_removedocument @docHandle
			
				INSERT INTO CatRutasPersonalPuntuaciones(IdRutaPersonalParada,IdPuesto,Puntos,CreadoEl,CreadoPor)
				SELECT @CursorIdRutaPersonalParada,ATT_IdPuesto,ATT_Puntos,@ModificadoEl,@ModificadoPor
				FROM #TempCatRutasPersonalPuntuaciones
				WHERE ATT_IdRutaPersonalPuntuacion = 0

				UPDATE CatRutasPersonalPuntuaciones SET
				CatRutasPersonalPuntuaciones.IdPuesto = #TempCatRutasPersonalPuntuaciones.ATT_IdPuesto,
				CatRutasPersonalPuntuaciones.Puntos =#TempCatRutasPersonalPuntuaciones.ATT_Puntos,
				CatRutasPersonalPuntuaciones.ModificadoEl=@ModificadoEl,
				CatRutasPersonalPuntuaciones.ModificadoPor =@ModificadoPor
				FROM CatRutasPersonalPuntuaciones
				INNER JOIN #TempCatRutasPersonalPuntuaciones ON CatRutasPersonalPuntuaciones.IdRutaPersonalPuntuacion = #TempCatRutasPersonalPuntuaciones.ATT_IdRutaPersonalPuntuacion
			
				DROP TABLE #TempCatRutasPersonalPuntuaciones
			END
			DELETE FROM CatRutasPersonalPuntuaciones WHERE IdRutaPersonalParada = @CursorIdRutaPersonalParada AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		

			FETCH NEXT FROM CursorCatRutasPersonalParadas
			INTO @CursorIdRutaPersonalParada,@COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
				@COL_SueldoBase,@COL_SueldoBaseDlls,
				@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,
				@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,@COL_TipoTrayecto,@COL_Puntuaciones,@COL_HoraSalida,@COL_HoraReporte
		END
		CLOSE CursorCatRutasPersonalParadas
		DEALLOCATE CursorCatRutasPersonalParadas

		IF EXISTS(SELECT TOP 1 IdRecorrido FROM ProRecorridos WHERE IdRutaPersonal = @IdRutaPersonal) AND EXISTS(SELECT IdRutaPersonalParada FROM CatRutasPersonalParadas WHERE IdRutaPersonal = @IdRutaPersonal AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl)
		RAISERROR(N'La ruta/parada tiene recorridos ligados, no es posible eliminarlo',
			16,
			1
			)

		DELETE FROM CatRutasPersonalParadas WHERE IdRutaPersonal = @IdRutaPersonal AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	END----SECCION PARA AGREGAR LAS GEOCERCAS 
	
    COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

