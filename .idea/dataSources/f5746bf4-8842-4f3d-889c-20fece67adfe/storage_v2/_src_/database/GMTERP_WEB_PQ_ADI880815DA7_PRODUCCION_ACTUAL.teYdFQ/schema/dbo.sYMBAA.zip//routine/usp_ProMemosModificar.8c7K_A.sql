CREATE PROCEDURE [dbo].[usp_ProMemosModificar]
    @IdMemo int,
	@FechaHora datetime,
	@Memo ntext,
	@NombreArchivo varchar(150),
	@Descripcion varchar(8000),
	@Activa bit,
	@ModificadoPor int, 
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@FechaHoraInicio datetime,
	@dsCatUsuariosMemo ntext

	/* *************************************************************************************************
Procedimiento usp_ProMemosModificar

Parámetros: 
	@IdMemo				(entrada, entero). Id del memo
	@FechaHora			(entrada, datetime). Fecha y hora de la creación del memo
	@Memo				(entrada, string). Archivo adjunto del memo
	@NombreArchivo		(entrada, string). Nombre del archivo adjunit
	@Descripcion		(entrada, string). Descripción del memo
	@Activa				(entrada, booleano). Boleano para determinar si el memo está activo o inactivo
	@ModificadoPor		(entrada, entero). Id del usuario que modifica el memo
	@ModificadoEl		(entrada, datetime). Fecha y hora de la modificación del memo
	@IdPeticion			(entrada, string). Id de petición
	@FechaHoraInicio	(entrada, datetime). Fecha y hora en la que se mostrará el aviso
	@dsCatUsuariosMemo	(entrada, string). XML con  los usuarios asignados
	

Descripción: Procedimiento para modificar un memo

22/05/2020 - Se agregaron nuevos parámetros de entrada para ligar a los usuarios destinatarios y crear 
			avisos de notificación

25/05/2020 - Se agrego FechaHoraInicio a la tabla de memos. 


Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXXX

Modificada por:  Julio Hermosillo
Fecha de mofidicacion: 22/05/2020
Versión ERP: 8.0.52.17

Modificada por:  Julio Hermosillo
Fecha de mofidicacion: 25/05/2020
Versión ERP: 8.0.52.26

------------------------------------------------------------------------------------------------------
Modificada por:  Ignacio Perez
Fecha de mofidicacion: 08/09/2020
Versión ERP: Versión 8.0.55.23

Se modifico para que en SisAvisosDestinatarios mandara la hora correcta (recalculada por sucursal)
-------------------------------------------------------------------------------------------------------

Invocada desde: PAGE_ProMemosAM (Solicitud xxxx)
***************************************************************************************************** */

AS
DECLARE
	@docHandle int,
	@ATT_IdMemo int,
	@ATT_IdUsuario int,
	@ATT_IdMemoEliminado int,
	@ATT_IdUsuarioEliminado int,
	@ATT_IdMemoUsuario int,
	@UsuarioSolicitante int = (SELECT CreadoPor FROM ProMemos WHERE IdMemo = @IdMemo),
	@Asunto varchar(255) = 'MEMO',
	@RecordarCadaMin int = 5,
	@EnviarTodosLosUsuarios bit = 0,
	@IdAviso int,
	@IdAvisoEliminar int,
	@IdAvisoNuevo int,
	@CreadoEl datetime = @ModificadoEl,
	@ATT_FechaHoraSucursal datetime
	
BEGIN TRY
	BEGIN TRANSACTION

	IF @UsuarioSolicitante = 0
		RAISERROR(N'El usuario solicitante es requerido',
			16,
			1
			)

	IF @FechaHora =''
		RAISERROR(N'Fecha/hora es un campo requerido',
			16,
			1
			)
			
	IF @FechaHoraInicio =''
		RAISERROR(N'Fecha y hora de inicio es un campo requerido',
			16,
			1
			)
		
		IF EXISTS (SELECT * FROM SisAvisos WHERE IdMemo = @IdMemo AND AtendidoPor IS NOT NULL)
		RAISERROR(N'El memo ya fue atendido por un usuario',
			16,
			1
			)

			


	UPDATE ProMemos SET 
		   FechaHora = @FechaHora,
		   Memo = @Memo,
		   NombreArchivo = @NombreArchivo,
		   Descripcion = @Descripcion,
		   Activa = @Activa,
		   FechaHoraInicio = @FechaHoraInicio,
	       ModificadoPor = @ModificadoPor,
		   ModificadoEl= @ModificadoEl
	WHERE IdMemo = @IdMemo

	IF @dsCatUsuariosMemo IS NOT NULL
		BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatUsuariosMemo
		
			SELECT ATT_IdUsuario, ATT_IdMemo, ATT_IdMemoUsuario, ATT_FechaHoraSucursal
			INTO #TempCatUsuariosMemo
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatUsuarios',2) 
			WITH (ATT_IdUsuario int, ATT_IdMemo int, ATT_IdMemoUsuario int, ATT_FechaHoraSucursal datetime)

			EXEC sp_xml_removedocument @docHandle

			-- Cursor ProMemosUsuarios con los usuarios/memos antes de eliminarlos
			--DECLARE ProMemosUsuariosEliminadosCursor CURSOR FOR
		--	SELECT IdMemo, IdUsuario FROM ProMemosUsuarios WHERE IdMemo = @IdMemo

		--	OPEN ProMemosUsuariosEliminadosCursor

			--Elimina todos los usuarios ligados que no estén en la tabla temporal
			DELETE FROM ProMemosUsuarios WHERE IdMemo = @IdMemo AND IdMemoUsuario NOT IN 
		    (SELECT ATT_IdMemoUsuario FROM #TempCatUsuariosMemo WHERE ATT_IdMemoUsuario <> 0)

			DELETE FROM SisAvisos WHERE IdMemo = @IdMemo 
		
		/*
			FETCH NEXT FROM ProMemosUsuariosEliminadosCursor
			INTO @ATT_IdMemoEliminado, @ATT_IdUsuarioEliminado
			
			
			WHILE @@FETCH_STATUS = 0
				BEGIN
					-- Verifica que no exista en ProMemosUsuarios
					IF NOT EXISTS(SELECT * FROM ProMemosUsuarios PMU
												INNER JOIN SisAvisos SA ON SA.IdMemo = PMU.IdMemo
												INNER JOIN SisAvisosDestinatarios SAD ON SAD.IdAviso = SA.IdAviso
											WHERE PMU.IdMemo = @IdMemo AND PMU.IdUsuario = @ATT_IdUsuarioEliminado 
												AND SAD.IdUsuarioDestinatario = @ATT_IdUsuarioEliminado)
			

						-- Si no existe, se obtiene el IdAviso para poder eliminarlo 
						SET @IdAvisoEliminar = (SELECT SA.IdAviso FROM SisAvisos SA
												INNER JOIN SisAvisosDestinatarios SAD ON SAD.IdAviso = SA.IdAviso
												WHERE SA.IdMemo = @IdMemo AND  SAD.IdUsuarioDestinatario = @ATT_IdUsuarioEliminado)

						-- Se elimina en SisAvisos y en cascada en en SisAvisosDestinatarios
						DELETE FROM SisAvisos WHERE IdAviso = @IdAvisoEliminar AND IdMemo = @IdMemo
				
					END
					
					FETCH NEXT FROM ProMemosUsuariosEliminadosCursor
					INTO @ATT_IdMemoEliminado, @ATT_IdUsuarioEliminado
					
				END

			CLOSE ProMemosUsuariosEliminadosCursor
			DEALLOCATE ProMemosUsuariosEliminadosCursor
			*/
			INSERT INTO ProMemosUsuarios(IdMemo,IdUsuario)
			SELECT @IdMemo, ATT_IdUsuario
			FROM #TempCatUsuariosMemo WHERE ATT_IdMemoUsuario = 0
			
				DECLARE ProMemosUsuariosCursor CURSOR FOR
				SELECT ATT_IdMemo, ATT_IdUsuario,ATT_FechaHoraSucursal FROM #TempCatUsuariosMemo 
				OPEN ProMemosUsuariosCursor
			
				FETCH NEXT FROM ProMemosUsuariosCursor
				INTO @ATT_IdMemo, @ATT_IdUsuario, @ATT_FechaHoraSucursal


				WHILE @@FETCH_STATUS = 0
				BEGIN	
			   
			

				SET @IdAviso = (SELECT SA.IdAviso FROM SisAvisosDestinatarios SAD
						INNER JOIN SisAvisos SA ON SA.IdAviso = SAD.IdAviso
					WHERE SAD.IdUsuarioDestinatario = @ATT_IdUsuario AND SA.IdMemo = @IdMemo)
				


				IF @IdAviso <> 0
					BEGIN
					UPDATE SisAvisos
						SET Asunto = @Asunto,
						Aviso = @Descripcion,
						EnviarEl = @FechaHoraInicio,
						EnviarTodosLosUsuarios = @EnviarTodosLosUsuarios,
						RecordarCadaMin = @RecordarCadaMin
					WHERE IdAviso = @IdAviso AND IdMemo = @IdMemo
					END
				ELSE
					BEGIN
						
						INSERT INTO SisAvisos(IdMemo,Asunto,Aviso,CreadoEl,CreadoPor,EnviarEl,EnviarTodosLosUsuarios,RecordarCadaMin)
						VALUES(@IdMemo,@Asunto,@Descripcion,@CreadoEl,@UsuarioSolicitante,@FechaHoraInicio,@EnviarTodosLosUsuarios,@RecordarCadaMin)
				
						SET @IdAvisoNuevo = (SELECT IDENT_CURRENT('SisAvisos'))
					END
					IF EXISTS(SELECT SA.IdAviso FROM SisAvisosDestinatarios SAD
						INNER JOIN SisAvisos SA ON SA.IdAviso = SAD.IdAviso
						WHERE SAD.IdUsuarioDestinatario = @ATT_IdUsuario AND SA.IdMemo = @IdMemo)
						BEGIN
							UPDATE SisAvisosDestinatarios 
								SET UltimaNotificacion = @ATT_FechaHoraSucursal
							WHERE IdUsuarioDestinatario = @ATT_IdUsuario AND IdAviso = @IdAviso
						END
						ELSE
							BEGIN
								INSERT INTO SisAvisosDestinatarios(IdAviso,IdUsuarioDestinatario,UltimaNotificacion)
								VALUES(@IdAvisoNuevo,@ATT_IdUsuario,@ATT_FechaHoraSucursal)
							END

					FETCH NEXT FROM ProMemosUsuariosCursor
					INTO @ATT_IdMemo, @ATT_IdUsuario, @ATT_FechaHoraSucursal
				
	
				END --- WHILE @@FETCH_STATUS = 0
			
				CLOSE ProMemosUsuariosCursor
				DEALLOCATE ProMemosUsuariosCursor
		END
		ELSE
			BEGIN
				DELETE FROM ProMemosUsuarios WHERE IdMemo = @IdMemo 

				DELETE FROM SisAvisos WHERE IdMemo = @IdMemo
			END


	COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

