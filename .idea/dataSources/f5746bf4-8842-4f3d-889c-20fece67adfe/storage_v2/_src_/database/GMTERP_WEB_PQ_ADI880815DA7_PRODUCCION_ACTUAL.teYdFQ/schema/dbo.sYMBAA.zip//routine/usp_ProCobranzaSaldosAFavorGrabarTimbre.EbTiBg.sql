CREATE PROCEDURE [dbo].[usp_ProCobranzaSaldosAFavorGrabarTimbre]
	@IdMovimientoBancario int,
	@XMLArchivoSaldoAFavor ntext,
	@FolioFiscalUUIDPagos varchar(36),
	@FechaTimbrado datetime,
	@NoSerieCertificadoSAT varchar(20),
	@SelloSAT ntext,
	@CadenaOriginalTimbrado ntext,
	@TimbrePruebas bit,
	@IdPeticion varchar(100),
	@IdCobranzaSaldoAFavor int,
	@Secuencia int
AS
BEGIN TRY
	BEGIN TRANSACTION
				
	UPDATE ProCobranzaSaldosAFavorTimbrados
	SET FolioFiscalUUIDPagos = @FolioFiscalUUIDPagos,
		FechaTimbrado = @FechaTimbrado,
		NoSerieCertificadoSAT = @NoSerieCertificadoSAT,
		SelloSAT = @SelloSAT,
		CadenaOriginalTimbrado = @CadenaOriginalTimbrado,
		XMLArchivoSaldoAFavor = @XMLArchivoSaldoAFavor,
		TimbrePruebas = @TimbrePruebas

	WHERE IdCobranzaSaldoAFavor = @IdCobranzaSaldoAFavor and Secuencia = @Secuencia

	--El commit debe ser la ultima linea para garantizar que se grabe todo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

