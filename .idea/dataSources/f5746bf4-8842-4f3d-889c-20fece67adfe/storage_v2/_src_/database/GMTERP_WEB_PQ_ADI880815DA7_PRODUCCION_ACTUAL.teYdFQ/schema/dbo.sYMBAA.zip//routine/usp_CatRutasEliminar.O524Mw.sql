CREATE PROCEDURE [dbo].[usp_CatRutasEliminar]
	@IdRuta int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM ProViajes WHERE IdRuta = @IdRuta)
		RAISERROR(N'La ruta tiene viajes ligados, no es posible eliminarlo',
			16,
			1
			)
					
	DELETE FROM CatRutasConceptosFacturacionImpuestos
	WHERE IdRutaConceptoFacturacion IN (SELECT IdRutaConceptoFacturacion FROM CatRutasConceptosFacturacion WHERE IdRuta = @IdRuta)

	DELETE FROM CatRutasConceptosFacturacion
	WHERE IdRuta = @IdRuta
	
	DELETE FROM CatRutas
	WHERE IdRuta = @IdRuta
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

