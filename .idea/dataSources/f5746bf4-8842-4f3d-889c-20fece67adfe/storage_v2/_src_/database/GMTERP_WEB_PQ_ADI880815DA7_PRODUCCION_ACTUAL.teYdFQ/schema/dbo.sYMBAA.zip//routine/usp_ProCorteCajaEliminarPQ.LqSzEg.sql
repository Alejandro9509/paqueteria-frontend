
CREATE PROCEDURE [dbo].[usp_ProCorteCajaEliminarPQ](
	@IdCorte int
)
AS
BEGIN
	BEGIN TRANSACTION
		
		Delete from ProCorteCajaPQ where IdCorte = @IdCorte;
		Delete from ProCorteCajaGuiasPQ where IdCorte = @IdCorte;

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

