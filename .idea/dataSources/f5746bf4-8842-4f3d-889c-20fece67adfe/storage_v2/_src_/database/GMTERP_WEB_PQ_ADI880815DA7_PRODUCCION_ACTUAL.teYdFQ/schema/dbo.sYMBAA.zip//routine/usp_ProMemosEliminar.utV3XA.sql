CREATE PROCEDURE [dbo].[usp_ProMemosEliminar]
	@IdMemo int,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS (SELECT * FROM SisAvisos WHERE IdMemo = @IdMemo AND AtendidoPor IS NOT NULL)
		RAISERROR(N'El memo ya fue atendido por un usuario, no puede ser eliminado',
			16,
			1
			)

	DELETE FROM ProMemos
	WHERE IdMemo = @IdMemo
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

