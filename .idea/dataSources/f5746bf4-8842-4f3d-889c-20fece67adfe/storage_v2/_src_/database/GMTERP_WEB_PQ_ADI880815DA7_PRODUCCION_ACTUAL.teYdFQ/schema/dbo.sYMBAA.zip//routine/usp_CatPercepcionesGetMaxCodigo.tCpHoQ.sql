CREATE PROCEDURE [dbo].[usp_CatPercepcionesGetMaxCodigo]

AS

SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatPercepciones
go

