CREATE PROCEDURE [dbo].[usp_ProCotizadorEnviarCotizacionPorCorreo]
@IdCotizacion int,
@IdPeticion as varchar(100)


AS

BEGIN TRY
	BEGIN TRANSACTION

	IF ISNull(@IdCotizacion,0) = 0
	   RAISERROR(N'El Campo IdCotizacion es un campo requerido',
			16,
			1
			) 							  

      --ENVIADA 0=FALSE 1=TRUE
		--verificar si ya fue modificada antes de Guardar Cambios
	--	IF (SELECT COUNT(Enviada) FROM ProCotizaciones WHERE IdCotizacion = @IdCotizacion and Enviada = 1) > 0 
	--	    RAISERROR(N'La Cotizacion ya fue Enviada',
	--		16,
	--		1
	--		)	
	
    
		UPDATE ProCotizaciones
		SET
		    Enviada = 1
		WHERE IdCotizacion = @IdCotizacion		  		
  
	COMMIT
END TRY
BEGIN CATCH    
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion	
END CATCH
go

