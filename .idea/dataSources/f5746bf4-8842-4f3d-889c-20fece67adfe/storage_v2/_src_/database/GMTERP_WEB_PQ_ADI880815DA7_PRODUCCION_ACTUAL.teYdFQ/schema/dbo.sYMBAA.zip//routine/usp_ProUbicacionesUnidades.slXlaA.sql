CREATE PROCEDURE [dbo].[usp_ProUbicacionesUnidades]
	@IdUsuario int,
	@dsProUbicacionesUnidadesTemp ntext,
	@IdPeticion varchar(100),
	@FechaHoraSucursal datetime
AS
/*****************************************************************************************************************************
procedimiento:[usp_ProUbicacionesUnidades]
Parámetros: 
	@IdUsuario int,
	@dsProUbicacionesUnidadesTemp ntext,
	@IdPeticion varchar(100),
	@FechaHoraSucursal datetime
Descripción: El procedimiento se encarga de mandar a guardar la informacion de las ubicaciones de las unidades
			 y procesar parametros especificos que vienen del lado del web como viajes, clientes, color de la unidad
			 entre otros, al final despues de esto pasa la informaicon en una tabla asia el webn
08/11/2019   Se le agregaro el parametro de chapa electromagnetica
Implementada por: Angel Espinoza.
Modificada por Angel Espinoza.
Fecha de implementacion: 05/23/2020
Versión GMTERP_ProcesosEspeciales 1.11.5

Invocada desde: <GMTERP_ProcesosEspeciales, ClsProUbicaciones(Execute usp_ProUbicacionesUnidades)>

Solicitud 2128

*****************************************************************************************************************************/
DECLARE
	@docHandle int,
	@variable VARCHAR (10) = '000000',
	@AplicarFiltroGrupoUnidades bit = 1,--bandera para aplicar filtro en el query
	@FiltrarPorGrupoUnidadesParametro bit = ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'FiltrarPorGrupoUnidades'),0)--valor del parametro
	CREATE TABLE #ProUbicacionesUnidadesTemporal([Unidad] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,
	[Pais] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,[IdGrupo] [int] NULL,
	[Estado] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,[Ciudad] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,
	[Calle] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,[FechaHoraLocalCliente] [datetime] NULL,
	[FechaHoraUTCPaquete] [datetime] NULL,[Velocidad] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[Direccion] [varchar](5) COLLATE Modern_Spanish_CS_AS NULL,[Lat] [float] NULL,[Long] [float] NULL,
	[Evento] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,[Icono] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[Odometro] [float] NULL,[Temperatura] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[CodigoEvento] [int] NULL,[Grupo] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[Viaje] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,[Identificador] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,
	[Ruta] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,[Operador] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Remolque1] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,[Remolque2] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[EstatusViaje] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,[PorcentajeBateria] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[VoltajeVehiculo] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,[CadenaLitros] [varchar](150) COLLATE Modern_Spanish_CS_AS NULL,
	[EstadoMotor] [int] NULL,[RFC] [varchar](15) COLLATE Modern_Spanish_CS_AS NULL,[DentroGeocerca] [bit] NULL,
	[SalidaGeo] [bit] NULL,[EntradaGeo] [bit] NULL,[FueraRuta] [bit] NULL,[Demorado] [bit] NULL,
	[TempAlta] [bit] NULL,[TempBaja] [bit] NULL,[IdUnidad] [int] PRIMARY KEY,
	[ImgAdv] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,[ImgUnidad] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,
	[HASHGPS] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[UnidadOperador] [varchar](200) COLLATE Modern_Spanish_CS_AS NULL,
	[CantidadSatelites] [tinyint] NULL,
	[FechaHoraLocalServidor] [datetime] NULL,
	[TipoSenal] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[EstadoModuloGPS] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[EstadoModoTrabajo] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[NivelGSM] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[VoltajeBateriaInterna] [varchar](50) COLLATE Modern_Spanish_CS_AS NULL,
	[NivelCombustiblePorcentaje] [float] NULL,
	[SumaLitrosTanques] [decimal](15, 4) NULL,
	[TieneSensores] [bit] NULL,[ColorLetraHex] [varchar](6) COLLATE Modern_Spanish_CS_AS NULL,
	[ColorHex] [varchar](6) COLLATE Modern_Spanish_CS_AS NULL,
	[ColorLetraHexViaje] [varchar](6) COLLATE Modern_Spanish_CS_AS NULL,
	[ColorHexViaje] [varchar](6) COLLATE Modern_Spanish_CS_AS NULL,
	[IdViajeTrayecto] [int] NULL,
	[IdSatelital] [varchar](26) COLLATE Modern_Spanish_CS_AS NULL,
	[MinutosParada] [int] NULL,
	[CapacidadTanqueCombustible] [int] NULL,
	[CapacidadTanque1] [decimal](15, 4) NULL,
	[CapacidadTanque2] [decimal](15, 4) NULL,
	[CapacidadTanque3] [decimal](15, 4) NULL,
	[CapacidadTanque4] [decimal](15, 4) NULL,
	[Temperatura2] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Temperatura3] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Temperatura4] [varchar](100) COLLATE Modern_Spanish_CS_AS NULL,
	[Camara] [bit] NULL,
	[FueraRutaEstatus] [bit] NULL,
	[DemoradoEstatus] [bit] NULL,
	[TieneAperturaCierreChapa] [bit] NULL,
	[TieneCanbus] [bit] NULL);

	
BEGIN TRANSACTION

BEGIN TRY
	IF ISNULL(@IdUsuario,0) = 0
	RAISERROR(N'El idusuario es un parámetro requerido',
	16,
	1
	)

	IF ISNULL(CAST(@dsProUbicacionesUnidadesTemp AS VARCHAR(MAX)),'') = ''
	RAISERROR(N'El xml de ubicaciones es un parámetro requerido',
	16,
	1
	)

	--SE EVALUA CRITERIOS PARA APLICAR FILTRO DE GRUPOS DE UNIDADES
	--este codigo esta homologado con el metodo de la clase clscatgruposunidades para saber si se filtra 
	--o no las unidades por grupo de unidades o por tipo de usuario
	IF EXISTS(SELECT * FROM CatUsuarios AS cu WHERE cu.IdUsuario = @IdUsuario AND cu.TipoUsuario IN(1,5)) 
	OR @FiltrarPorGrupoUnidadesParametro = 0
		SET @AplicarFiltroGrupoUnidades = 0

	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProUbicacionesUnidadesTemp

	INSERT INTO #ProUbicacionesUnidadesTemporal([Unidad],[Pais],[IdGrupo],[Estado],[Ciudad],[Calle],
	[FechaHoraLocalCliente],[FechaHoraUTCPaquete],[Velocidad],[Direccion],[Lat],[Long],[Evento],[Icono],
	[Odometro],[Temperatura],[CodigoEvento],[Grupo],[Viaje],[Identificador],[Ruta],[Operador],
	[Remolque1],[Remolque2],[EstatusViaje],[PorcentajeBateria],[VoltajeVehiculo],[CadenaLitros],
	[EstadoMotor],[RFC],[DentroGeocerca],[SalidaGeo],[EntradaGeo],[FueraRuta],[Demorado],[TempAlta],
	[TempBaja],[IdUnidad],[ImgAdv],[ImgUnidad],[HASHGPS],[UnidadOperador],[CantidadSatelites],
	[FechaHoraLocalServidor],[TipoSenal],[EstadoModuloGPS],[EstadoModoTrabajo],[NivelGSM],
	[VoltajeBateriaInterna],[NivelCombustiblePorcentaje],[SumaLitrosTanques],[TieneSensores],
	[ColorLetraHex],[ColorHex],[IdViajeTrayecto],[IdSatelital],[MinutosParada],[CapacidadTanqueCombustible],
	[CapacidadTanque1],[CapacidadTanque2],[CapacidadTanque3],[CapacidadTanque4],[Temperatura2],[Temperatura3],[Temperatura4],[Camara],[FueraRutaEstatus],
	[DemoradoEstatus],[TieneAperturaCierreChapa],[TieneCanbus])
	SELECT cu.Codigo,put.Pais,cu.IdGrupoUnidad,put.Estado,put.Ciudad,
	put.Calle,put.FechaHoraLocalCliente,put.FechaHoraUTCPaquete,
	put.Velocidad,put.Direccion,
	put.Lat,put.Long,put.Evento,
	(CASE 
	WHEN put.Codigo IN(58,59) AND Cast(Replace(put.Velocidad,' km/h','') As int) != 0 THEN put.Icono+put.Direccion
	WHEN put.Codigo = 3 AND Cast(Replace(put.Velocidad,' km/h','') As int) = 0 THEN 'POSICIONMOTOR'
	WHEN put.Codigo = 3 AND Cast(Replace(put.Velocidad,' km/h','') As int) != 0 THEN 
		(CASE ISNULL(cu.NombreImagenUnidad,'')
		WHEN '' THEN 'DIRECCIONMOTOR'
		ELSE cu.NombreImagenUnidad END)+put.Direccion
	WHEN put.Codigo = 62 AND Cast(Replace(put.Velocidad,' km/h','') As int) = 0 THEN 'UBICACION'
	WHEN put.Codigo = 62 AND Cast(Replace(put.Velocidad,' km/h','') As int) != 0 THEN 
		(CASE ISNULL(cu.NombreImagenUnidad,'')
		WHEN '' THEN 'DIRECCIONGPS'
		ELSE cu.NombreImagenUnidad END)+put.Direccion
	ELSE ISNULL(put.Icono,'MARKERG')
	END) AS Icono,
	put.OdometroGPS,put.Temperatura,put.Codigo,
	Replace(cgu.GrupoUnidad,' ',''),
	'',--Viaje
	'',--Identificador
	'',--Ruta
	'',--Operador
	'',--Remolque1
	'',--Remolque2
	'',--EstatusViaje
	put.PorcentajeBateria,
	put.VoltajeVehiculo,put.CadenaLitros,
	put.EstadoMotor,put.RFC,put.DentroGeocerca,ISNULL(put.EventoPSalidaGeo,0),ISNULL(put.EventoPEntradaGeo,0),
	ISNULL(put.EventoPFueraRuta,0),ISNULL(put.EventoPDemorado,0),ISNULL(put.EventoPTempAlta,0),ISNULL(put.EventoPTempBaja,0),cu.IdUnidad,
	put.ImgAdv,	
	(CASE ISNULL(cu.NombreImagenUnidad,'')
		WHEN '' THEN 'DIRECCIONMOTOR'
		ELSE cu.NombreImagenUnidad
		END)+'.png',--ImgUnidad	
	put.HASHGPS,cu.Codigo+(CASE ISNULL(co.Nombre,'')
		WHEN '' THEN ''
		ELSE '/'+co.Nombre
		END), --UnidadOperador
	put.CantidadSatelite,put.FechaHoraLocalServidor,put.TipoSenal,
	put.EstadoModuloGPS,put.EstadoModoTrabajo,put.NivelGSM,put.VoltajeBateriaInterna,put.NivelCombustiblePorcentaje,
	put.SumaLitrosTanques,put.TieneSensores,
	CASE ISNULL(cgu.ColorLetra,16777215) WHEN 0 THEN '000000' ELSE 'FFFFFF' END AS ColorLetraHex,
	ISNULL(cgu.Color,'000000') AS ColorHex,
	put.IdViajeTrayecto,put.NoSerie,put.MinutosParada,cu.CapacidadTanqueCombustible,put.CapacidadTanque1,
	put.CapacidadTanque2,put.CapacidadTanque3,put.CapacidadTanque4,put.Temperatura2,put.Temperatura3,put.Temperatura4,put.Camara,
	put.EventoPFueraRutaEstatus,put.EventoPDemoradoEstatus,put.TieneAperturaCierreChapa,put.TieneCanbus
	FROM OPENXML(@docHandle, N'/Markers/Marker',2) 
	WITH (Pais varchar(150) COLLATE Modern_Spanish_CS_AS,Estado varchar(150) COLLATE Modern_Spanish_CS_AS,
	Ciudad varchar(150) COLLATE Modern_Spanish_CS_AS,Calle varchar(200) COLLATE Modern_Spanish_CS_AS,
	Evento varchar(50) COLLATE Modern_Spanish_CS_AS,Icono varchar(50) COLLATE Modern_Spanish_CS_AS,	
	ImgAdv varchar(200) COLLATE Modern_Spanish_CS_AS,
	DentroGeocerca bit,RFC varchar(15) COLLATE Modern_Spanish_CS_AS,
	FechaHoraLocalCliente datetime,
	FechaHoraUTCPaquete datetime,
	Velocidad varchar(50) COLLATE Modern_Spanish_CS_AS,PorcentajeBateria varchar(50) COLLATE Modern_Spanish_CS_AS,
	VoltajeVehiculo varchar(50) COLLATE Modern_Spanish_CS_AS,CadenaLitros varchar(150) COLLATE Modern_Spanish_CS_AS,
	Direccion varchar(5) COLLATE Modern_Spanish_CS_AS,Lat float,
	Long float,Codigo int,
	NoSerie varchar(50) COLLATE Modern_Spanish_CS_AS,
	OdometroGPS float,
	EstadoMotor int,Temperatura varchar(100) COLLATE Modern_Spanish_CS_AS,
	HASHGPS varchar(50) COLLATE Modern_Spanish_CS_AS,CantidadSatelite tinyint,
	FechaHoraLocalServidor datetime,
	EstadoModoTrabajo varchar(100) COLLATE Modern_Spanish_CS_AS,EstadoModuloGPS varchar(100) COLLATE Modern_Spanish_CS_AS,
	NivelGSM varchar(100) COLLATE Modern_Spanish_CS_AS,TipoSenal varchar(100) COLLATE Modern_Spanish_CS_AS,
	VoltajeBateriaInterna varchar(50) COLLATE Modern_Spanish_CS_AS,
	SumaLitrosTanques decimal(15, 4),
	TieneSensores int,
	NivelCombustiblePorcentaje float,
	EventoPSalidaGeo bit,
	EventoPEntradaGeo bit,
	EventoPDemorado bit,
	EventoPFueraRuta bit,
	EventoPTempAlta bit,
	EventoPTempBaja bit,
	IdViajeTrayecto int,
	MinutosParada int, 
	CapacidadTanque1 decimal(15, 4),
	CapacidadTanque2 decimal(15, 4),
	CapacidadTanque3 decimal(15, 4),
	CapacidadTanque4 decimal(15, 4),
	Temperatura2 varchar(100) COLLATE Modern_Spanish_CS_AS,
	Temperatura3 varchar(100) COLLATE Modern_Spanish_CS_AS,
	Temperatura4 varchar(100) COLLATE Modern_Spanish_CS_AS,
	Camara int,
	EventoPFueraRutaEstatus bit,
	EventoPDemoradoEstatus bit,
	TieneAperturaCierreChapa bit,
	TieneCanbus bit
	) AS put
	INNER JOIN CatUnidades AS cu ON put.NoSerie = cu.IdentificadorSatelital 
	LEFT JOIN CatOperadores as co ON cu.IdOperador = co.IdOperador
	INNER JOIN CatGruposUnidades AS cgu ON cu.IdGrupoUnidad = cgu.IdGrupoUnidad
	INNER JOIN CatUsuarios AS cus ON cus.IdUsuario = @IdUsuario
	WHERE cu.IdentificadorSatelital IS NOT NULL AND  cu.IdentificadorSatelital <> '' AND
	(
	(cu.IdGrupoUnidad IN(SELECT IdGrupoUnidad 
	FROM CatGruposUnidadesUsuarios AS cguu 
	WHERE cguu.IdUsuario = @IdUsuario) AND @AplicarFiltroGrupoUnidades = 1)
	OR @AplicarFiltroGrupoUnidades = 0
	)
	AND cu.Activa = 1
	AND ((cus.TipoUsuario = 5 AND cu.IdUnidad IN(SELECT cueu.IdUnidad 
	FROM CatUsuariosEspejosUnidades  AS cueu 
	WHERE cueu.IdUsuarioEspejo = @IdUsuario AND cueu.FechaVencimiento > @FechaHoraSucursal)) 
	OR(cus.TipoUsuario != 5))
		
	EXEC sp_xml_removedocument @docHandle;

	WITH cte AS ( 
	SELECT cs.Abreviacion,pv.Viaje,pv.NoViajeCliente,cor.OrigenDestino AS Origen,
	cde.OrigenDestino AS Destino,co1.Nombre AS NombreOperadorViaje,pv.CodigoUnidadCarga1,
	pv.CodigoUnidadCarga2,cev.Estatus,cu.IdUnidad,	
	CASE ISNULL(cev.ColorLetra,16777215) WHEN 0 THEN '000000' ELSE 'FFFFFF' END AS ColorLetraHexViaje,
	ISNULL(cev.Color,'000000') AS ColorHexViaje,   
	ROW_NUMBER() OVER (partition by cu.IdentificadorSatelital ORDER BY cu.IdentificadorSatelital) AS rownumber
	FROM CatUnidades AS cu 
	LEFT JOIN ProViajesTrayectos AS pvt ON cu.IdUnidad = pvt.IdUnidadCamion
	LEFT JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
	LEFT JOIN CatOrigenesDestinos AS cor ON pvt.IdOrigen = cor.IdOrigenDestino
	LEFT JOIN CatOrigenesDestinos AS cde ON pvt.IdDestino = cde.IdOrigenDestino
	LEFT JOIN CatSucursales AS cs ON pv.IdSucursal = cs.IdSucursal
	LEFT JOIN CatEstatusViaje AS cev ON cev.IdEstatuViaje = pv.IdEstatuViaje
	LEFT JOIN CatOperadores AS co1 ON pvt.IdOperador = co1.IdOperador 
	WHERE pvt.IdViajeTrayecto IN(SELECT puut.IdViajeTrayecto FROM #ProUbicacionesUnidadesTemporal AS puut)
	)

	UPDATE puut SET 
	puut.Viaje = c.Abreviacion+'-'+LEFT(@variable,6 - LEN(c.Viaje))+cast(c.Viaje as varchar),
	puut.Identificador = c.NoViajeCliente,
	puut.Ruta = c.Origen+' / '+c.Destino,
	puut.Operador = c.NombreOperadorViaje,
	puut.Remolque1 = c.CodigoUnidadCarga1,
	puut.Remolque2 = c.CodigoUnidadCarga2,
	puut.EstatusViaje = c.Estatus,
	puut.ColorLetraHexViaje = c.ColorLetraHexViaje,
	puut.ColorHexViaje = c.ColorHexViaje
	FROM #ProUbicacionesUnidadesTemporal AS puut 
	INNER JOIN cte AS c ON puut.IdUnidad = c.IdUnidad
	WHERE c.rownumber = 1 

	SELECT IdGrupo,Grupo,UnidadOperador,IdUnidad,Lat,Long,Icono,ColorLetraHex,ColorHex,
	SalidaGeo,EntradaGeo,Demorado,FueraRuta,TempAlta,TempBaja,Unidad,FechaHoraLocalServidor,
	REPLACE((ISNULL(Pais,'')+' '+ISNULL(Estado,'')+' '+ISNULL(Ciudad,'')+' '+ISNULL(Calle,'')),'  ',' ') AS Ubicacion,Evento,Direccion,Velocidad,
	FechaHoraLocalCliente,FechaHoraUTCPaquete,CantidadSatelites,NivelGSM,TipoSenal,
	EstadoModuloGPS,EstadoModoTrabajo,Viaje,VoltajeVehiculo,Odometro,EstadoMotor,CadenaLitros,
	VoltajeBateriaInterna,PorcentajeBateria,Temperatura,Identificador,Ruta,Operador,Remolque1,Remolque2,
	EstatusViaje,ColorLetraHexViaje,ColorHexViaje,ImgAdv,ImgUnidad,IdSatelital,HASHGPS,MinutosParada,
	DentroGeocerca,NivelCombustiblePorcentaje,SumaLitrosTanques,TieneSensores,CapacidadTanqueCombustible,
	CapacidadTanque1,CapacidadTanque2,CapacidadTanque3,CapacidadTanque4,Temperatura2,Temperatura3,Temperatura4,Camara,
	FueraRutaEstatus,DemoradoEstatus,TieneAperturaCierreChapa,TieneCanbus
	FROM #ProUbicacionesUnidadesTemporal 
	ORDER BY IdGrupo,Unidad
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION

	EXECUTE usp_SisErrorsGrabar @IdPeticion;
END CATCH

IF @@TRANCOUNT > 0  
    COMMIT TRANSACTION;
go

