CREATE PROCEDURE [dbo].[usp_CatTopesCanacarModificar]
	@IdTopeCanacar int,
	@SalarioDiario decimal(15,2),
	@SalarioDiarioConvenio decimal(15,2),
	@SalarioPorSemanaConvenio decimal(15,2),
	@SalarioConvenioPorHora decimal(15,2),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION
	
	IF @IdTopeCanacar = 0
		RAISERROR(N'El IdNominaReciboVacaciones es un campo requerido',
			16,
			1
			)
			
	UPDATE CatTopesCanacar SET
		SalarioDiario = @SalarioDiario,
		SalarioDiarioConvenio = @SalarioDiarioConvenio,
		SalarioPorSemanaConvenio = @SalarioPorSemanaConvenio,
		SalarioConvenioPorHora = @SalarioConvenioPorHora,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl
	WHERE IdTopeCanacar = @IdTopeCanacar
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

