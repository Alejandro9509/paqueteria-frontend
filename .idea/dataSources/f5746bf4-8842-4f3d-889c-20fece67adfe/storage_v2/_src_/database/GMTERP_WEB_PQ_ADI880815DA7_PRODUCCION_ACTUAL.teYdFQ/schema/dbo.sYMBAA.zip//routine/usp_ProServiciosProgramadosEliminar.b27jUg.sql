CREATE PROCEDURE [dbo].[usp_ProServiciosProgramadosEliminar]  
@IdServicioProgramado int,
@IdPeticion varchar(100)  
AS  
BEGIN TRY  
 BEGIN TRANSACTION  

 IF ISNULL(@IdServicioProgramado,0) = 0
  RAISERROR(N'Identificador del servicio programado es un campo requerido',
   16,
   1
   )
  
  IF NOT EXISTS(SELECT IdServicioProgramado FROM ProServiciosProgramados WHERE IdServicioProgramado = @IdServicioProgramado)
  	 RAISERROR(N'Este registro fue eliminado por otro usuario',
	   16,
	   1
	   )
	   
   
  IF (Select IdOrdenServicio from ProServiciosProgramados where IdServicioProgramado = @IdServicioProgramado) IS Not NULL
     RAISERROR(N'Este servicio programado esta atendido y no se puede eliminar',
	  16,
	  1
	  )
 
 --- Eliminar Servicio Programado
	DELETE FROM ProServiciosProgramados WHERE IdServicioProgramado=@IdServicioProgramado	
     
 COMMIT  
END TRY  
BEGIN CATCH  
 ROLLBACK  
 EXECUTE usp_SisErrorsGrabar @IdPeticion  
END CATCH
go

