
CREATE PROCEDURE [dbo].[usp_ProRecorridosParadasQuitarLlegada]
	@IdRecorrido int,
	@IdRecorridoParada int,
	@IdEstatuViaje int,
	@FechaHoraEstatusViaje datetime,
	@IdEstatuUnidad int,
	@ControlarInventario bit,
	@ModificadoPor  int,
	@ModificadoEl datetime,	
	@IdPeticion varchar(100)
AS

	/*
	CREADO POR:  GUSTAVO PARTIDA NEVAREZ.
	FECHA DE CREACION: 29/05/20206.
	VERSION: V8 8.0.52.36.
	SOLICITUD: 2251.

	SE CREO PARA QUITAR LA LLEGADA DE LA PARADA. 
	*/

DECLARE 
	@return_value int,
	@IdCliente int,
	@IdUnidadCamion int,
	@IdUbicacion int,
	@CodigoUnidad varchar(16),
	@Recorrido int,
	@MensajeError varchar(200),

	@Observacion varchar(250),
	@ViajeMensaje varchar(50),
	@ClienteMensaje varchar(50),
	@KilometrosTrayecto int,
	@MillasTrayecto decimal(15,2),
	@HorometroUnidad decimal(15,2), 
	@OdometroKMUnidad int, 
	@OdometroMillasUnidad decimal(15,2)
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdRecorrido,0) = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdRecorridoParada,0) = 0
		RAISERROR(N'El identificador del recorrido parada es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdEstatuViaje,0) = 0
		RAISERROR(N'El estatus del recorrido es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT CanceladoEl FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido AND CanceladoEl IS NOT NULL)
		RAISERROR(N'No se puede quitar la llegada a este recorrido porque está cancelado',
			16,
			1
			)				
			
	IF EXISTS(SELECT prp.IdRecorridoParada FROM ProRecorridoParadas AS prp INNER JOIN ProLiquidaciones AS pl ON prp.IdLiquidacion = pl.IdLiquidacion WHERE prp.IdRecorrido = @IdRecorrido AND pl.CerradaEl IS NOT NULL AND prp.IdRecorridoParada = @IdRecorridoParada)
		RAISERROR(N'No se puede quitar la llegada porque tiene la liquidación cerrada',
			16,
			1
			)

	SET @IdCliente = (SELECT IdCliente FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido)	
	SET @IdUnidadCamion = (SELECT IdUnidadCamion FROM ProRecorridoParadas WHERE IdRecorridoParada = @IdRecorridoParada)
	SET @IdUbicacion = (SELECT IdOrigen FROM ProRecorridoParadas WHERE IdRecorridoParada = @IdRecorridoParada)

	IF @ControlarInventario = 1
	BEGIN
		IF EXISTS(SELECT ceu.TipoEstatus FROM CatEstatusUnidades AS ceu	INNER JOIN ProInventarioUnidades AS piu ON ceu.IdEstatuUnidad = piu.IdEstatuUnidad 
		WHERE piu.IdUnidad = @IdUnidadCamion AND ceu.TipoEstatus = 1 AND ISNULL(IdRecorrido,0) != @IdRecorrido)
		BEGIN
			SET @CodigoUnidad = (SELECT CodigoUnidadCamion FROM ProRecorridoParadas WHERE IdRecorridoParada = @IdRecorridoParada)
			SET @Recorrido = (SELECT pr.Recorrido FROM ProRecorridos AS pr INNER JOIN ProInventarioUnidades AS piu ON pr.IdRecorrido = piu.IdRecorrido INNER JOIN CatEstatusUnidades AS ceu ON piu.IdEstatuUnidad = ceu.IdEstatuUnidad WHERE piu.IdUnidad = @IdUnidadCamion AND ceu.TipoEstatus = 1)
			IF @Recorrido IS NULL
				SET @MensajeError = 'No se puede quitar la llegada este recorrido porque el camión '+CAST(@CodigoUnidad AS varchar)+' está ocupado.'
			ELSE
				SET @MensajeError = 'No se puede quitar la llegada este recorrido porque el camión '+CAST(@CodigoUnidad AS varchar)+' está ocupado en el recorrido '+CAST(@Recorrido as varchar)+' Termine el recorrido anterior para poder quitar la llegada este.'	

			RAISERROR(@MensajeError,
				16,
				1
				)
		END
	END

	/* SE ACTUALIZA LA TABLA DE RECORRIDOS*/
	UPDATE ProRecorridos SET
		IdEstatuViaje = @IdEstatuViaje,
		FechaHoraRecorridoEstatus = @FechaHoraEstatusViaje,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		RecorridoTerminado = 0,
		TerminadoEl = NULL,
		TerminadoPor = NULL		
	WHERE IdRecorrido = @IdRecorrido

	/* SE AGREGA EL ESTATUS AL RECORRIDO PARADA */
	INSERT INTO ProRecorridosEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatusViaje,IdRecorrido,IdRecorridoParada)
	VALUES(@ModificadoEl,@ModificadoPor,@FechaHoraEstatusViaje,@IdEstatuViaje,@IdRecorrido,@IdRecorridoParada)

	/* SE ACTUALIZA LA TABLA DE PARADAS */ 
	UPDATE ProRecorridoParadas SET
		Llegada = NULL,
		IdLiquidacion = NULL,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdRecorridoParada = @IdRecorridoParada

	/* SE BORRAN LOS BONOS LIGADOS A LA PARADA */ 
	/* DELETE ProLiquidacionesBonos WHERE IdRecorridoParada = @IdRecorridoParada */


	SET @ViajeMensaje = (SELECT CatSucursales.Abreviacion+'-'+SUBSTRING('000000',1,6-len(CAST(ProRecorridos.Recorrido as varchar)))+CAST(ProRecorridos.Recorrido as varchar)  FROM ProRecorridos INNER JOIN CatSucursales ON ProRecorridos.IdSucursal = CatSucursales.IdSucursal WHERE ProRecorridos.IdRecorrido = @IdRecorrido)
	SET @ClienteMensaje = (SELECT NombreFiscal FROM CatClientes WHERE IdCliente = @IdCliente)
	SET @Observacion = 'Unidad ocupada en el recorrido: '+@ViajeMensaje+' del cliente: '+@ClienteMensaje

	IF @IdUnidadCamion IS NOT NULL
	BEGIN
		--Se agrega  seccion para actualizar los odometros de la unidad y registrarlo en el historico de odometros, este cambio proviene de la solicitud 4092
		SET @KilometrosTrayecto = (SELECT ISNULL( Kilometros, 0 ) FROM ProRecorridoParadas WHERE IdRecorridoParada = @IdRecorridoParada)

		EXEC @return_value = usp_ProInventarioUnidadesActualizar @IdUnidadCamion,'',@IdEstatuUnidad,@IdCliente,0,@IdUbicacion,@FechaHoraEstatusViaje,@ModificadoPor,@ModificadoEl,@IdPeticion,@IdRecorrido,@Observacion

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al actualizar el inventario de equipo camión',
			16,
			1
			)

		UPDATE CatUnidades SET
			Odometro = Odometro - @KilometrosTrayecto
		WHERE IdUnidad = @IdUnidadCamion

		SET @OdometroKMUnidad = ( SELECT Odometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCamion )
		SET @OdometroMillasUnidad = ( SELECT OdometroMillas FROM CatUnidades WHERE IdUnidad = @IdUnidadCamion )

		INSERT INTO ProUnidadesOdometros( IdUnidad, Odometro, FechaLectura, OdometroMillas )
		VALUES( @IdUnidadCamion, @OdometroKMUnidad, @FechaHoraEstatusViaje, @OdometroMillasUnidad )

	END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

