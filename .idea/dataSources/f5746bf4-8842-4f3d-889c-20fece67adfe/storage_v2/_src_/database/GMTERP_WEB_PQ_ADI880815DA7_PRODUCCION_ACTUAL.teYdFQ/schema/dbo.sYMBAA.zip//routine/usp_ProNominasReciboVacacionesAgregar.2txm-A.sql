CREATE PROCEDURE [dbo].[usp_ProNominasReciboVacacionesAgregar]
	@IdEmpleado int,
	@TipoCaptura int,
	@FechaInicial datetime,
	@FechaFinal datetime,
	@FechaPago datetime,
	@DiasDescansoOSeptimos int,
	@DiasVacaciones int,
	@PrimaVacacionalDias decimal(15,2),
	@VacacionesAcumuladas int,
	@DiasPrimaAcumulados decimal(15,2),
	@VacacionesPendientes int,
	@DiasPrimaPendientes decimal(15,2),
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@xmlIncidenciaValor ntext,
	@TipoIncidencia int,
	@IdPeriodo int,
	@AgregadoManual bit,
	@dsXmlSeptimos ntext,
	@IdConceptoPDOVacaciones int,
	@IdConceptoPDOPrimaVacacional int
AS
DECLARE
	@docHandle int,
	@IdNominaReciboVacaciones int,
	@FechaFin date, 
	@FechaRepetida int 


/****************************************************************************************************** 
Descripción: El procedimiento agrega los registros de vacaciones de cada empleado.

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 17/08/2021
Versión ERP: 8.0.64.01

Invocada desde: PAGE_ProNominasReciboVacacionesAM (Solicitud 4712)
***************************************************************************************************** */


BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
	
		SET @FechaFin = (SELECT CONVERT (DATE ,DATEADD(DD,@DiasVacaciones,@FechaInicial )))
		
		SET @FechaRepetida = (SELECT TOP 1 IdNominaDiaHora FROM ProNominasDiasHoras WHERE IdEmpleado = @IdEmpleado AND Fecha BETWEEN @FechaInicial AND @FechaFin)
		
		IF ISNULL(@FechaRepetida,0) = 0 
			SET @FechaRepetida = 0
		
		IF  @FechaRepetida > 0 
        RAISERROR(N'Ya existen movimientos registrados para esta fecha',
            16,
            1
            )
	
		IF ISNULL(@IdEmpleado,0) = 0
        RAISERROR(N'El empleado es un campo requerido',
            16,
            1
            )
            
		IF @TipoCaptura = 0
			RAISERROR(N'El tipo de captura es un campo requerido',
				16,
				1
				)
		IF isnull(@FechaInicial,'') = ''			
			RAISERROR(N'La fecha inicial es un campo requerido',
				16,
				1
				)	
		IF isnull(@FechaFinal,'') = ''			
			RAISERROR(N'La fecha final es un campo requerido',
				16,
				1
				)	
		IF isnull(@FechaPago,'') = ''			
			RAISERROR(N'La fecha de pago es un campo requerido',
				16,
				1
				)	
		IF @FechaPago < (SELECT FechaInicio FROM CatPeriodos WHERE IdPeriodo = @IdPeriodo)
			RAISERROR(N'La fecha de pago debe ser mayor o igual a la fecha de inicio del periodo',
				16,
				1
				)			
	
	--Sección para validar si alguno de los dos IdConceptosPDOVacacions-PrimaVacacional viene en 0 ponerlo en null
	IF @IdConceptoPDOVacaciones = 0
	BEGIN
		SET @IdConceptoPDOVacaciones = NULL
	END
	
	IF @IdConceptoPDOPrimaVacacional = 0
	BEGIN 
		SET @IdConceptoPDOPrimaVacacional = NULL
	END
	
	--Sección para Insertar en ProNominasReciboVacaciones
	INSERT INTO ProNominasReciboVacaciones(IdEmpleado,TipoCaptura,FechaInicial,FechaFinal,FechaPago,DiasDescansoOSeptimos,
	DiasVacaciones,PrimaVacacionalDias,VacacionesAcumuladas,DiasPrimaAcumulados,VacacionesPendientes,DiasPrimaPendientes,CreadoPor,CreadoEl,IdPeriodo,IdConceptoPDOVacaciones,IdConceptoPDOPrimaVacacional)
	VALUES(@IdEmpleado,@TipoCaptura,@FechaInicial,@FechaFinal,@FechaPago,@DiasDescansoOSeptimos,
	@DiasVacaciones,@PrimaVacacionalDias,@VacacionesAcumuladas,@DiasPrimaAcumulados,@VacacionesPendientes,@DiasPrimaPendientes,@CreadoPor,@CreadoEl,@IdPeriodo,@IdConceptoPDOVacaciones,@IdConceptoPDOPrimaVacacional)
	SET  @IdNominaReciboVacaciones = (SELECT IDENT_CURRENT('ProNominasReciboVacaciones'))
	
	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	UPDATE ProNominasReciboVacaciones 
	SET VacacionesAcumuladas = @VacacionesAcumuladas,
		DiasPrimaAcumulados = @DiasPrimaAcumulados,
		VacacionesPendientes = @VacacionesPendientes,
		DiasPrimaPendientes = @DiasPrimaPendientes
	WHERE  IdEmpleado = @IdEmpleado
	AND IdNominaReciboVacaciones = @IdNominaReciboVacaciones	
	
	
	IF @AgregadoManual = 1 
	BEGIN 
		select @dsXmlSeptimos
		IF @dsXmlSeptimos IS NOT NULL
			BEGIN
			select 2
				EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsXmlSeptimos	
				SELECT ATT_S_FechaSeptimoDia
				INTO #TempSeptimos
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_SeptimosDias',2) 
				WITH(ATT_S_FechaSeptimoDia date)
				
				EXEC sp_xml_removedocument @docHandle	
				
				INSERT INTO ProNominasReciboVacacionesSeptimosDias(IdNominaReciboVacaciones,FechaSeptimoDia,CreadoEl,CreadoPor)
				SELECT @IdNominaReciboVacaciones,ATT_S_FechaSeptimoDia,@CreadoEl,@CreadoPor
				FROM #TempSeptimos			
				DROP TABLE #TempSeptimos	
			END			
	END
	
	EXEC  usp_ProNominasDiasHorasModificar 
	@IdPeticion,
	@IdEmpleado,
	@xmlIncidenciaValor,
	@FechaInicial,
	@CreadoPor,
	@CreadoEl,
	@TipoIncidencia,
	NULL,
	@IdPeriodo,
	@IdNominaReciboVacaciones
	
	COMMIT
END TRY
BEGIN CATCH	
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

