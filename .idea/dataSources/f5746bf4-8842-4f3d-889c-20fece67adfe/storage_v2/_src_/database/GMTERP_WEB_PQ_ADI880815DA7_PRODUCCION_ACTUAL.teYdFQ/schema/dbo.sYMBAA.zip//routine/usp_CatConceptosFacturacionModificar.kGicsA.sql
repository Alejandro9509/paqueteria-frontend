CREATE PROCEDURE [dbo].[usp_CatConceptosFacturacionModificar]
	@IdConceptoFacturacion int,
	@Codigo Int,
	@ConceptoFacturacion varchar(50),
	@TrasladaImpuesto Bit,
	@RetieneImpuesto Bit,
	@Activo Bit,
	@UnidadMedida varchar(30),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@IncluirCalculoIngresosLiquidacion bit,
	@IncluirCalculoLiquidacionPorcentajeSobreImpFlete bit,
	@ClaveSATProducto varchar(8),
	@ClaveSATUnidad	varchar(8),
	@EquivalenciaEDI varchar(5),
	@ImpuestoTraslada ntext,
	@ImpuestoRetiene ntext,
	@NoIdentificacion varchar(40)
AS
DECLARE
@docHandle int,
@ATT_IDIMPUESTO int,@ATT_PREDETERMINADO int,@ATT_ACTIVO int
/*
MODIFICADO:
	Se agregaron condiciones para actualizar los impuestos retiene y traslada del concepto de facturacion.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-03-30
SOLICITUD: 
	SOLICITUD 001468
*/
/*
MODIFICADO:
	Se agregaro el campo NoIdentificacion
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-09-14
SOLICITUD: 
	SOLICITUD 002927
*/
BEGIN TRY
	BEGIN TRANSACTION	

	IF @Codigo =0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@ConceptoFacturacion)) = ''
		RAISERROR(N'El concepto de facturación es un campo requerido',
			16,
			1
			)

	IF (@ImpuestoTraslada IS NULL) AND (@ImpuestoRetiene IS NOT NULL)
	RAISERROR(N'Es necesario seleccionar al menos un Impuesto Trasladado.',
		16,
		1
		)
	
	IF (SELECT ModificadoEl FROM CatConceptosFacturacion WHERE IdConceptoFacturacion = @IdConceptoFacturacion) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)		

	IF EXISTS(SELECT IdConceptoFacturacion FROM CatConceptosFacturacion WHERE Codigo = @Codigo AND IdConceptoFacturacion <> @IdConceptoFacturacion)		
		RAISERROR(N'El Código del Concepto de Facturación no se puede repetir.',
		16,
		1
		)
						
	UPDATE CatConceptosFacturacion SET
		Codigo = @Codigo,
		ConceptoFacturacion = @ConceptoFacturacion,
		TrasladaImpuesto = @TrasladaImpuesto,
		RetieneImpuesto = @RetieneImpuesto,
		Activo = @Activo,		
		UnidadMedida = @UnidadMedida,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl,
		IncluirCalculoIngresosLiquidacion = @IncluirCalculoIngresosLiquidacion,
		IncluirCalculoLiquidacionPorcentajeSobreImpFlete = @IncluirCalculoLiquidacionPorcentajeSobreImpFlete,
		ClaveSATProducto = @ClaveSATProducto,
		ClaveSATUnidad = @ClaveSATUnidad,
		EquivalenciaEDI = @EquivalenciaEDI,
		NoIdentificacion = @NoIdentificacion
	WHERE IdConceptoFacturacion = @IdConceptoFacturacion


	IF @ImpuestoTraslada IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @ImpuestoTraslada
		
		SELECT ATT_IDIMPUESTO,ATT_PREDETERMINADO,ATT_ACTIVO
		INTO #TempImpuestosTraslada
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_IMPUESTOTRASLADA',2) 
		WITH (ATT_IDIMPUESTO int,ATT_PREDETERMINADO int,ATT_ACTIVO int)
		
		EXEC sp_xml_removedocument @docHandle
		
		UPDATE
			CatConceptosFacturacionImpuestos
		SET
			Predeterminado = 0,
			Activo = 0
		FROM CatConceptosFacturacionImpuestos ccfi
		INNER JOIN CatImpuestos ci ON ccfi.IdImpuesto = ci.IdImpuesto
		WHERE
		ccfi.IdConceptoFacturacion = @IdConceptoFacturacion
		AND ci.TipoCalculo = 1		
		AND ccfi.IdImpuesto NOT IN (SELECT ATT_IDIMPUESTO FROM #TempImpuestosTraslada)


		DECLARE ImpuestoTrasladaCursor CURSOR FOR
		SELECT ATT_IDIMPUESTO,ATT_PREDETERMINADO,ATT_ACTIVO FROM #TempImpuestosTraslada
		OPEN ImpuestoTrasladaCursor
		FETCH NEXT FROM ImpuestoTrasladaCursor
		INTO @ATT_IDIMPUESTO,@ATT_PREDETERMINADO,@ATT_ACTIVO
    
		WHILE @@FETCH_STATUS = 0
		BEGIN

			IF EXISTS(SELECT IdImpuesto FROM CatConceptosFacturacionImpuestos WHERE IdConceptoFacturacion = @IdConceptoFacturacion AND IdImpuesto = @ATT_IDIMPUESTO)
			BEGIN
				UPDATE
					CatConceptosFacturacionImpuestos
				SET
					Predeterminado = @ATT_PREDETERMINADO,
					Activo = @ATT_ACTIVO
				WHERE
				IdConceptoFacturacion = @IdConceptoFacturacion
				AND IdImpuesto = @ATT_IDIMPUESTO
			END
			ELSE
			BEGIN

				INSERT INTO CatConceptosFacturacionImpuestos(IdConceptoFacturacion,IdImpuesto,Predeterminado,Activo)
				VALUES(@IdConceptoFacturacion,@ATT_IDIMPUESTO,@ATT_PREDETERMINADO,@ATT_ACTIVO)

			END

			FETCH NEXT FROM ImpuestoTrasladaCursor
			INTO @ATT_IDIMPUESTO,@ATT_PREDETERMINADO,@ATT_ACTIVO
		END            
		CLOSE ImpuestoTrasladaCursor
		DEALLOCATE ImpuestoTrasladaCursor

	END
	ELSE
	BEGIN
		UPDATE
			CatConceptosFacturacionImpuestos
		SET
			Predeterminado = 0,
			Activo = 0
		FROM CatConceptosFacturacionImpuestos ccfi
		INNER JOIN CatImpuestos ci ON ccfi.IdImpuesto = ci.IdImpuesto
		WHERE
		ccfi.IdConceptoFacturacion = @IdConceptoFacturacion
		AND ci.TipoCalculo = 1
	END

	IF @ImpuestoRetiene IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @ImpuestoRetiene
		
		SELECT ATT_IDIMPUESTO,ATT_PREDETERMINADO,ATT_ACTIVO
		INTO #TempImpuestosRetiene
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_IMPUESTORETIENE',2) 
		WITH (ATT_IDIMPUESTO int,ATT_PREDETERMINADO int,ATT_ACTIVO int)
		
		EXEC sp_xml_removedocument @docHandle

		UPDATE
			CatConceptosFacturacionImpuestos
		SET
			Predeterminado = 0,
			Activo = 0
		FROM CatConceptosFacturacionImpuestos ccfi
		INNER JOIN CatImpuestos ci ON ccfi.IdImpuesto = ci.IdImpuesto
		WHERE
		ccfi.IdConceptoFacturacion = @IdConceptoFacturacion
		AND ci.TipoCalculo = 2	
		AND ccfi.IdImpuesto NOT IN (SELECT ATT_IDIMPUESTO FROM #TempImpuestosRetiene)


		DECLARE ImpuestoRetieneCursos CURSOR FOR
		SELECT ATT_IDIMPUESTO,ATT_PREDETERMINADO,ATT_ACTIVO FROM #TempImpuestosRetiene
		OPEN ImpuestoRetieneCursos
		FETCH NEXT FROM ImpuestoRetieneCursos
		INTO @ATT_IDIMPUESTO,@ATT_PREDETERMINADO,@ATT_ACTIVO
    
		WHILE @@FETCH_STATUS = 0
		BEGIN

			IF EXISTS(SELECT IdImpuesto FROM CatConceptosFacturacionImpuestos WHERE IdConceptoFacturacion = @IdConceptoFacturacion AND IdImpuesto = @ATT_IDIMPUESTO)
			BEGIN
				UPDATE
					CatConceptosFacturacionImpuestos
				SET
					Predeterminado = @ATT_PREDETERMINADO,
					Activo = @ATT_ACTIVO
				WHERE
				IdConceptoFacturacion = @IdConceptoFacturacion
				AND IdImpuesto = @ATT_IDIMPUESTO
			END
			ELSE
			BEGIN

				INSERT INTO CatConceptosFacturacionImpuestos(IdConceptoFacturacion,IdImpuesto,Predeterminado,Activo)
				VALUES(@IdConceptoFacturacion,@ATT_IDIMPUESTO,@ATT_PREDETERMINADO,@ATT_ACTIVO)

			END

			FETCH NEXT FROM ImpuestoRetieneCursos
			INTO @ATT_IDIMPUESTO,@ATT_PREDETERMINADO,@ATT_ACTIVO
		END            
		CLOSE ImpuestoRetieneCursos
		DEALLOCATE ImpuestoRetieneCursos
	END
	ELSE
	BEGIN
		UPDATE
			CatConceptosFacturacionImpuestos
		SET
			Predeterminado = 0,
			Activo = 0
		FROM CatConceptosFacturacionImpuestos ccfi
		INNER JOIN CatImpuestos ci ON ccfi.IdImpuesto = ci.IdImpuesto
		WHERE
		ccfi.IdConceptoFacturacion = @IdConceptoFacturacion
		AND ci.TipoCalculo = 2	
	END
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

