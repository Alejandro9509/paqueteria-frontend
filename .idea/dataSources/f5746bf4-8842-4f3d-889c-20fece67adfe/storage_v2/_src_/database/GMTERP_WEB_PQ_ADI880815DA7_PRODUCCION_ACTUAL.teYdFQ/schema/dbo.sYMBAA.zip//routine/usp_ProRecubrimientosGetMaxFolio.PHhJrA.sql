
CREATE PROCEDURE [dbo].[usp_ProRecubrimientosGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProRecubrimientos
go

