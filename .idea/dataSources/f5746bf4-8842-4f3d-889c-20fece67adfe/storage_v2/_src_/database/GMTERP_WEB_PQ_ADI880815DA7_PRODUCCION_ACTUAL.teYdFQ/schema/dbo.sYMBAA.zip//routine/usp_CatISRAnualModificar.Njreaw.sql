CREATE PROCEDURE [dbo].[usp_CatISRAnualModificar]
@dsCatISRAnual ntext,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)
AS
DECLARE
@docHandle int, 
@CursorT_IdISRAnual int,
@CursorT_LimiteInferior decimal(15, 3),
@CursorT_LimiteSuperior decimal(15, 3),
@CursorT_CuotaFija decimal(15, 3),
@CursorT_Porcentaje decimal(15, 3)--,
--@CursorT_Ejercicio int,
--@CursorT_FechaVigencia datetime

/* *************************************************************************************************
Procedimiento [usp_CatISRAnualModificar]
r
Parámetros: 
    @@dsCatISRAnual	             (entrada, texto).   Es la tabla de registros del ISR Anual.
    @ModificadoEl                (entrada, fecha hora). Fecha en la que se realiza la modificación
    @ModificadoPor               (entrada, entero). Quien solicita la modificación
    @IdPeticion varchar(100)     (entrada, string). Id de la Petición, generada en WEBDEV   
 

Descripción: El procedimiento Modifica las tarifas Anuales del ISR para realizar el calculo de impuestos del periodo  .

Implementada por: N/A
Fecha de implementacion: N/A
Versión ERP: N/A

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 19/02/2021
Versión ERP: 8.0.59.03
Solicitud: 3735

Invocada desde: PAGE_SisParametrosConfiguracionNomina (Solicitud 3735)
***************************************************************************************************** */

BEGIN TRY
	BEGIN TRANSACTION
		IF @dsCatISRAnual IS NULL
           RAISERROR(N'Los ISR Anual son requeridos',
            16,
            1
            )

 IF @dsCatISRAnual IS NOT NULL
    BEGIN
        EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatISRAnual

        SELECT ATT_IdISRAnual,ATT_LimiteInferior,ATT_LimiteSuperior,ATT_CuotaFija,ATT_Porcentaje
		--, ATT_Ejercicio, ATT_FechaVigencia
        INTO #CatISRAnual
        FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CATISRAnual',2) 
        WITH ( ATT_IdISRAnual int,ATT_LimiteInferior decimal(15, 3),ATT_LimiteSuperior decimal(15, 3),ATT_Porcentaje decimal(15, 3),ATT_CuotaFija decimal(15, 3) ) 
		--ATT_Ejercicio int, ATT_FechaVigencia datetime )

        EXEC sp_xml_removedocument @docHandle

        DECLARE CatISRAnualCursor CURSOR LOCAL SCROLL FOR
        SELECT * FROM #CatISRAnual

        OPEN CatISRAnualCursor
        FETCH NEXT FROM CatISRAnualCursor
        INTO @CursorT_IdISRAnual,@CursorT_LimiteInferior,@CursorT_LimiteSuperior,@CursorT_CuotaFija,@CursorT_Porcentaje 
		--, @CursorT_Ejercicio, @CursorT_FechaVigencia

        WHILE @@FETCH_STATUS = 0
        BEGIN
            UPDATE CatISRAnual 
            SET LimiteInferior = @CursorT_LimiteInferior,
            LimiteSuperior = @CursorT_LimiteSuperior,
            CuotaFija = @CursorT_CuotaFija,
            Porcentaje = @CursorT_Porcentaje,
            --Ejercicio = @CursorT_Ejercicio,
            --FechaVigencia = @CursorT_FechaVigencia,
            ModificadoEl = @ModificadoEl,
            ModificadoPor = @ModificadoPor
            WHERE IdISRAnual = @CursorT_IdISRAnual

            FETCH NEXT FROM CatISRAnualCursor
            INTO @CursorT_IdISRAnual,@CursorT_LimiteInferior,@CursorT_LimiteSuperior,@CursorT_CuotaFija,@CursorT_Porcentaje
			--, @CursorT_Ejercicio, @CursorT_FechaVigencia
        END
        CLOSE CatISRAnualCursor
        DEALLOCATE CatISRAnualCursor
	END
  COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

