
CREATE PROCEDURE [dbo].[usp_CatGruposUnidadesEliminarPQ]
	@IdGrupoUnidad INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdGrupoUnidad,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del grupo unidad es un campo requerido*FIN*', 16, 1);
			return
		end
		
		DELETE FROM CatGruposUnidades
		WHERE IdGrupoUnidad = @IdGrupoUnidad
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

