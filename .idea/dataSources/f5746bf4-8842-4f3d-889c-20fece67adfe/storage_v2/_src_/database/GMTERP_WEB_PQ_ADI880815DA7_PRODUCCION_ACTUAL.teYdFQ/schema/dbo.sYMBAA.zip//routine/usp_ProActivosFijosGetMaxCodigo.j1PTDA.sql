
CREATE PROCEDURE [dbo].[usp_ProActivosFijosGetMaxCodigo]
/* *************************************************************************************************
Procedimiento usp_ProActivosFijosGetMaxCodigo
 
Descripción: Procedimiento para obtener el ultimo codigo del activo fijo

Implementada por: Jesús Humberto Morales
Fecha de implementacion: 03/12/2019
Versión ERP: 8.0.48.11

Modificada por:   XXXXX
Fecha de mofidicacion: XXXXX
Versión ERP: XXXXX

Invocada desde: PAGE_ProActivosFijosAM (Solicitud 642)
***************************************************************************************************** */
AS
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM ProActivosFijos
go

