CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosAgregar]
	@NumeroMovimiento int,
	@Fecha datetime,
	@IdCuentaBancaria int,
	@Importe money ,
	@TipoCambio money ,
	@ReferenciaBancaria varchar(150),
	@IdTipoMovimientoBancario int,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@TipoBeneficiario tinyint,
	@IdProveedor int,
	@IdBeneficiario int,
	@PorAnticipo bit,
	@Beneficiario varchar(150),
	@CuentaBancariaProveedor varchar(50),
    @IdBancoProveedor int,
    @XMLArchivo ntext,
	@FolioFiscalUUID varchar(36),
	@FechaCobro datetime,
	@Observaciones varchar(250)

/* *************************************************************************************************
Procedimiento usp_ProConciliacionesAgregar

Parámetros: 
	@NumeroMovimiento (entrada, entero). Numero de movimiento bancario
	@Fecha (entrada, fecha). Fecha del movimiento
	@IdCuentaBancaria  (entrada, entero). Identificador de la cuenta bancaria
	@Importe (entrada, moneda). Importe del movimiento
	@TipoCambio (entrada, moneda). Tipo de cambio
	@ReferenciaBancaria (entrada, texto). Referencia del movmiento
	@IdTipoMovimientoBancario (entrada, entero). Identificador del tipo de movimiento
	@CreadoPor (entrada, entero). Usuario que crea el cheque
	@CreadoEl (entrada, fecha hora). Fecha y hora de creacion
	@IdPeticion (entrada, string). Id de la Petición, generada en WEBDEV
	@TipoBeneficiario (entrada, entero). Tipo de beneficiario
	@IdProveedor (entrada, entero). identificador del proveedor
	@IdBeneficiario (entrada, entero). Identificador del beneficiario
	@PorAnticipo (entrada, booelano). Si es por anticipo
	@Beneficiario (entrada, texto). Nombre del beneficiario
	@CuentaBancariaProveedor (entrada, texto). Cuenta bancaria del proveedor
    @IdBancoProveedor (entrada, entero). Identificador del banco del proveedor
    @XMLArchivo (entrada, texto). XML
	@FolioFiscalUUID (entrada, texto). Folio fiscal 
	@FechaCobro (entrada, fecha). Fecha de cobro
	@Observaciones (entrada, texto). Observaciones del movimiento bancario

Descripción: Procedimiento para agregar un movimiento bancario

06/11/2020 - Se agrego el flujo de asignarle una fecha de cobro, se valido que si viene de otros procesos y son de retiro te permita modificar
07/12/2020 - Se agrego campo de observaciones

Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 07/11/2020
Versión ERP: 8.0.57.04

Invocada desde: PAGE_ProMovimientosBancariosRM (Solicitud 3393)
***************************************************************************************************** */
AS
DECLARE 
	@IdMovimientoBancario int,
	@NumeroMovBancarioError int, --bandera para obtener el número de movimiento bancario del movimiento bancario que tiene el folio fiscal uuid capturado previamente
	@MensajeError varchar(200) 	
BEGIN TRY
	BEGIN TRANSACTION

	SET @IdMovimientoBancario = 0
	SET @NumeroMovBancarioError = ''

	IF ISNULL(@NumeroMovimiento,0)= 0
		RAISERROR(N'El número de movimiento es un campo requerido', 16, 1)
			
	IF EXISTS(SELECT NumeroMovimiento FROM ProMovimientosBancarios WHERE NumeroMovimiento = @NumeroMovimiento AND IdCuentaBancaria=@IdCuentaBancaria)
		RAISERROR(N'El Folio del Movimiento Bancario ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar', 16, 1)
			
	IF ISNULL(@Fecha,'')= ''
		RAISERROR(N'Fecha es un campo requerido', 16, 1)

	IF ISNULL(@FechaCobro,'')= ''
		RAISERROR(N'Fecha de cobro es un campo requerido', 16, 1)
			
	IF ISNULL(@IdCuentaBancaria,0)= 0
		RAISERROR(N'El identificador de cuenta bancaria es un campo requerido', 16, 1)

	IF ISNULL(@TipoCambio,0)= 0
		RAISERROR(N'Tipo de cambio es un campo requerido', 16, 1)
	
	IF ISNULL(@ReferenciaBancaria,'')= ''
		RAISERROR(N'El Referencia bancaria es un campo requerido', 16, 1)

	IF ISNULL(@Importe,0)= 0
			RAISERROR(N'El Importe es un campo requerido', 16, 1)
			
	IF @TipoBeneficiario = 1  --- 1 Tipo Proveedor
	BEGIN
		IF ISNULL(@IdProveedor,0)= 0
			RAISERROR(N'Identificador de proveedor es un campo requerido', 16, 1)
		SET @IdBeneficiario = NULL
	END

	IF @TipoBeneficiario = 2  --- 2 Tipo Beneficiario
	BEGIN
		IF ISNULL(@IdBeneficiario ,0)= 0
			RAISERROR(N'Identificador de Beneficiario es un campo requerido', 16, 1)
		SET @IdProveedor = NULL
	END				
	
	IF ISNULL(@Beneficiario ,'')= ''
		RAISERROR(N'Beneficiario es un campo requerido', 16, 1)

	IF @IdBancoProveedor = 0
	SET @IdBancoProveedor = NULL
	
	--SE VALIDA QUE SI EL FOLIO FISCAL ES DIFERENTE DE VACIO QUE NO EXISTA UN MOVIMIENTO BANCARIO(NO CANCELADO) YA REGISTRADO
	IF @FolioFiscalUUID <> ''
	BEGIN
		SET @NumeroMovBancarioError= (SELECT NumeroMovimiento FROM ProMovimientosBancarios WHERE FolioFiscalUUID = @FolioFiscalUUID AND CanceladoEl IS NULL)
		IF @NumeroMovBancarioError IS NOT NULL
		BEGIN
			SET @MensajeError = 'El movimiento bancario con el número '+CAST(@NumeroMovBancarioError as varchar)+' tiene registrado el Folio Fiscal UUID que intenta agregar el movimiento bancario'

			RAISERROR(@MensajeError, 16, 1)		
		END
	END	
					
	--- Registrar Movimiento Bancario
    INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,TipoCambio,ReferenciaBancaria,IdTipoMovimientoBancario,CreadoPor,CreadoEl,TipoBeneficiario,IdProveedor,IdBeneficiario,PorAnticipo,Beneficiario,CuentaBancariaProveedor,IdBancoProveedor,XMLArchivo,FolioFiscalUUID,FechaCobro,Observaciones)
	VALUES (@NumeroMovimiento,@Fecha,@IdCuentaBancaria,@Importe,@TipoCambio,@ReferenciaBancaria,@IdTipoMovimientoBancario,@CreadoPor,@CreadoEl,@TipoBeneficiario,@IdProveedor,@IdBeneficiario,@PorAnticipo,@Beneficiario,@CuentaBancariaProveedor,@IdBancoProveedor,@XMLArchivo,@FolioFiscalUUID,@FechaCobro,@Observaciones)

	SET @IdMovimientoBancario = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))
	
    --seccion para agregar el idmovimientobancario a paremtros y poder obtenerlo de lado del web
    IF NOT EXISTS(SELECT * FROM SisParametrosPagina WHERE Pagina = 'IdMovimientoBancario' AND IdUsuario = @CreadoPor)
		INSERT INTO SisParametrosPagina(Pagina,Parametros,IdUsuario) VALUES('IdMovimientoBancario',@IdMovimientoBancario,@CreadoPor)
    ELSE
		UPDATE SisParametrosPagina SET Parametros = @IdMovimientoBancario WHERE Pagina = 'IdMovimientoBancario' AND IdUsuario = @CreadoPor
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

