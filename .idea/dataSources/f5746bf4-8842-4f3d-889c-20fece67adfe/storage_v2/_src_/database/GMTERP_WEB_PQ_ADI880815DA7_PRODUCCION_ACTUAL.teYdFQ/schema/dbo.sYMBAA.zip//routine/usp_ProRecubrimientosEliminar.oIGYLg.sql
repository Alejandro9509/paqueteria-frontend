
CREATE PROCEDURE [dbo].[usp_ProRecubrimientosEliminar]
	@IdRecubrimiento int,
	@IdPeticion varchar(100)	
AS
DECLARE
@IdRecubrimientoLlantaCursor int,
@IdLlantaCursor int,
@IdOrdenCompra int

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdRecubrimiento,0)= 0
			RAISERROR(N'El identificador del recubrimiento es un campo requerido',
					16,
					1
					)
	IF (Select Estatus from ProRecubrimientos Where IdRecubrimiento = @IdRecubrimiento ) = 2
			RAISERROR(N'El Envio a Recubrimiento tiene estatus de Completado',
					16,
					1
					)
    If (Select Count(*) from ProRecubrimientosLlantas Where IdRecubrimiento = @IdRecubrimiento and Isnull(FechaRetorno,0) <> 0) > 0
			RAISERROR(N'El Envio a Recubrimiento tiene llantas que ya fueron afectadas.',
					16,
					1
					)
	
					
	IF NOT EXISTS(SELECT IdRecubrimiento FROM ProRecubrimientos WHERE IdRecubrimiento = @IdRecubrimiento) 
			RAISERROR(N'El regitro ya fue eliminado por otro usuario',
					16,
					1
					)
            
	-- Eliminar 
	--Borra los registros que fueron quitados del Recubrimiento
	Declare LLANTASELIMINADASRECUBRIMIENTOSCursor Cursor For
	SELECT IdRecubrimientoLlanta,IdLlanta FROM ProRecubrimientosLlantas WHERE IdRecubrimiento = @IdRecubrimiento

	Open LLANTASELIMINADASRECUBRIMIENTOSCursor
	Fetch Next From LLANTASELIMINADASRECUBRIMIENTOSCursor
	Into @IdRecubrimientoLlantaCursor,@IdLlantaCursor

	While @@Fetch_Status = 0
	Begin
		Delete from ProLlantasAuxiliar 
		Where IdLlantaAuxiliar = (Select top 1 IdLlantaAuxiliar from ProLlantasAuxiliar Where IdLlanta = @IdLlantaCursor order by CreadoEl desc)
		
		Update ProLlantas Set IdEstatuLlanta = (Select top 1 IdEstatuLlanta from ProLlantasAuxiliar Where IdLlanta = @IdLlantaCursor order by CreadoEl desc),
		                      IdProcesoLlanta = (Select top 1 IdProcesoLlanta from ProLlantasAuxiliar Where IdLlanta = @IdLlantaCursor Order by CreadoEl desc)	
		Where IdLlanta = @IdLlantaCursor
		
		Delete ProRecubrimientosLlantas Where IdRecubrimientoLlanta = @IdRecubrimientoLlantaCursor
		
		Fetch Next From LLANTASELIMINADASRECUBRIMIENTOSCursor
		Into @IdRecubrimientoLlantaCursor,@IdLlantaCursor
	End
	Close LLANTASELIMINADASRECUBRIMIENTOSCursor
	Deallocate LLANTASELIMINADASRECUBRIMIENTOSCursor
--Fin del Cursor para Borra los registros que fueron quitados del Recubrimiento 
	DELETE FROM ProRecubrimientos where IdRecubrimiento = @IdRecubrimiento
	Set @IdOrdenCompra = (Select IdOrdenCompra From ProRecubrimientos Where IdRecubrimiento = @IdRecubrimiento)
    IF  @IdOrdenCompra <> 0
		Delete ProOrdenCompra Where IdOrdenCompra = @IdOrdenCompra		

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

