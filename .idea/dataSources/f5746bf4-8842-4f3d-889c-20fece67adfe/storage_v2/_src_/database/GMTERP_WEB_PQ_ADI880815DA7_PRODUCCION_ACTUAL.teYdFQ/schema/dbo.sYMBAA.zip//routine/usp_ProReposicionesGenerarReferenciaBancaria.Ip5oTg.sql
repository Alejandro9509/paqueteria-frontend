CREATE PROCEDURE [dbo].[usp_ProReposicionesGenerarReferenciaBancaria]  
	@IdResposicion int,  
	@Fecha datetime,  
	@TipodeMovimiento int,  
	@IdCuentaBancaria int,  
	@NumeroCheque int,  
	@CodigoCheque int, 
	@TipoCambio money,  
	@Importe money,  
	@TipoBeneficiario int,
	@IdProveedor int,
	@Beneficiario varchar(150),  
	@IdBeneficiario int,
	@CreadoPor int,  
	@CreadoEl datetime,  
	@IdPeticion varchar(100),
	@dsProPasivosDetallePagos ntext,
	@CuentaBancariaProveedor varchar(50),
	@IdBancoProveedor int,
	@UltimaModificacion datetime,
	@FechaCobro datetime
AS  
DECLARE 
	@IdCheque int,  
	@Concepto varchar(50),  
	@IdMovimientoBancario  int,  
	@IdTipoMovimientoBancario int,  
	@IdEstatuCheque int,
	@FolioReposicion  int,
	@NumeroMovimiento int,
	@ReferenciaBancaria varchar(150),
	@Mensaje varchar(500),
	@docHandle int  
/*
MODIFICADO:
	Se agrego en el UPDATE de ProReposiciones que se modifique el campo EsPagoComprobacion como 1 cuando es por Pago.
MODIFICADA POR:
	Diego Rubio
FECHA DE MODIFICACIÓN:
	2020-02-08
SOLICITUD: 
	SOLICITUD 000990
---------------------------------------------------------------------
MODIFICADO:
	Se agrego campo de fecha de cobro para asignarsela al movimiento bancario
MODIFICADA POR:
	Jesús Humberto Morales
FECHA DE MODIFICACIÓN:
	2020-11-09
SOLICITUD: 
	SOLICITUD 003395
*/	

BEGIN TRY  
	BEGIN TRANSACTION  
	
	SET @IdCheque = NULL  
 
	IF ISNULL(@IdResposicion, 0) <= 0  
		RAISERROR(N'El identificador de reposición es un campo requerido', 16, 1)
		
	IF ISNULL((SELECT IdMovimientoBancario FROM ProReposiciones WHERE ProReposiciones.IdReposicion = @IdResposicion), 0) > 0   
		RAISERROR(N'La Reposición ya ha generado movimiento bancario', 16, 1)

	IF (SELECT ModificadoEl FROM ProReposiciones WHERE IdReposicion = @IdResposicion) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario', 16, 1)
	
	IF ISNULL(@Fecha, '') = ''
		RAISERROR(N'Fecha es un campo requerido', 16, 1)

	IF ISNULL(@FechaCobro, '') = ''
		RAISERROR(N'Fecha de cobro es un campo requerido', 16, 1)
		
	IF ISNULL(@IdCuentaBancaria, 0) <= 0  
		RAISERROR(N'El identificador de cuenta bancaria es un campo requerido', 16, 1)
		
	IF ISNULL(@TipodeMovimiento, 0) <= 0
		RAISERROR(N'Tipo de movimiento es un campo requerido', 16, 1)
		
	IF ISNULL(@TipoCambio, 0) = 0
		RAISERROR(N'Tipo de cambio es un campo requerido', 16, 1) 
	
	IF ISNULL(@TipoBeneficiario, 0) = 0
		RAISERROR(N'Tipo de beneficiario es un campo requerido', 16, 1)     
	
	IF ISNULL(@TipoBeneficiario,0)=1
		BEGIN
			IF ISNULL(@IdProveedor, 0) = 0  
				RAISERROR(N'Identificador de proveedor es un campo requerido', 16, 1)  
				
			SET @IdBeneficiario = NULL
		END

	IF ISNULL(@TipoBeneficiario,0)=2
		BEGIN
  			IF ISNULL(@IdBeneficiario,0)= 0  
				RAISERROR(N'Identificador de beneficiario es un campo requerido', 16, 1)     
			
			SET @IdProveedor  = NULL
		END
  
	IF @IdBancoProveedor = 0
		SET @IdBancoProveedor = NULL
	
	------ Folio Reposicion ---------- 
	SELECT @FolioReposicion = FolioReposicion FROM ProReposiciones Where ProReposiciones.IdReposicion = @IdResposicion
	SET @ReferenciaBancaria = 'REPOSICION No '+ CONVERT(VARCHAR(10), @FolioReposicion) + ' ' + @Beneficiario  
	SELECT @IdTipoMovimientoBancario = 3 -- Retiro por transferencia  
  
	------ Generar cheque     --------
	IF @TipodeMovimiento = 1 
		BEGIN  
			SET @IdTipoMovimientoBancario = 2 -- Cheque  
			SELECT @IdEstatuCheque = IdEstatuCheque FROM CatEstatusCheques WHERE CatEstatusCheques.Codigo = @CodigoCheque   
			SET @Concepto = 'REPOSICION '+ CONVERT(VARCHAR(10), @FolioReposicion) + ' ' + @Beneficiario  
			--- Registrar cheque  
			INSERT INTO ProCheques (NumeroCheque,Fecha,IdCuentaBancaria,TipoCambio,Concepto,Beneficiario,Importe,IdEstatuCheque,TipoBeneficiario,IdProveedor,IdBeneficiario,FechaCobro,CreadoPor,CreadoEl,CuentaBancariaProveedor,IdBancoProveedor)
			VALUES (@NumeroCheque,@Fecha,@IdCuentaBancaria,@TipoCambio,@Concepto,@Beneficiario,@Importe,@IdEstatuCheque,@TipoBeneficiario,@IdProveedor,@IdBeneficiario,@FechaCobro,@CreadoPor,@CreadoEl,@CuentaBancariaProveedor,@IdBancoProveedor)  
			SET @IdCheque= (SELECT IDENT_CURRENT('ProCheques'))  
			SET @ReferenciaBancaria = 'CHEQUE No ' +CONVERT(VARCHAR(10), @NumeroCheque)
		END  

	----- Generar movimiento movimiento bancario --------	
	SET @NumeroMovimiento = (SELECT ISNULL(MAX(NumeroMovimiento), 0) + 1 AS NumeroMovimiento FROM ProMovimientosBancarios WHERE IdCuentaBancaria = @IdCuentaBancaria)
	INSERT INTO ProMovimientosBancarios (NumeroMovimiento,Fecha,IdCuentaBancaria,Importe,TipoCambio,ReferenciaBancaria,IdTipoMovimientoBancario,TipoBeneficiario,IdProveedor,IdBeneficiario,Beneficiario,CreadoPor,CreadoEl,IdCheque,CuentaBancariaProveedor,IdBancoProveedor,FechaCobro)  
	VALUES (@NumeroMovimiento,@Fecha,@IdCuentaBancaria,@Importe,@TipoCambio,@ReferenciaBancaria,@IdTipoMovimientoBancario,@TipoBeneficiario,@IdProveedor,@IdBeneficiario,@Beneficiario,@CreadoPor,@CreadoEl,@IdCheque,@CuentaBancariaProveedor,@IdBancoProveedor,@FechaCobro)  
		
	SET @IdMovimientoBancario = (SELECT IDENT_CURRENT('ProMovimientosBancarios'))        


	----- Registrar movimiento bancario en ProReposiciones
	UPDATE ProReposiciones 
		SET IdMovimientoBancario =   @IdMovimientoBancario,
		TipoMovimiento = @TipodeMovimiento,
		EsPagoComprobacion = 1 --Se asigna el movimiento que se le realizo a la reposicion donde 1 significa "Pago de Reposicion"
	WHERE ProReposiciones.IdReposicion = @IdResposicion
  
	---- Registrar detalle de pagos de pasivos.
	IF @dsProPasivosDetallePagos IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProPasivosDetallePagos

		SELECT ATT_IdPasivo, ATT_ImporteAPagar
		INTO #TempProPasivosDetallePagos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_ProPasivosDetallePagos',2) 
		WITH (ATT_IdPasivo int, ATT_ImporteAPagar money)

		---- Nueva seccion validacion de concurrencia --
		DECLARE 
		@ATT_IdPasivo int , 
		@ATT_ImporteAPagar money , 
		@ImportePendiente money, 
		@ImportePagado money, 
		@TotalPasivo money,
		@FolioPasivo int,
		@FolioDocumento varchar(40),
		@SerieDocumento varchar(25)

		DECLARE TempProPasivosDetallePagos CURSOR FOR SELECT ATT_IdPasivo, ATT_ImporteAPagar  From #TempProPasivosDetallePagos

		OPEN TempProPasivosDetallePagos
		--- Recorrido del cursor de pasivoss (xml)
		----
			FETCH TempProPasivosDetallePagos INTO @ATT_IdPasivo, @ATT_ImporteAPagar
			SET @Mensaje = ''
			WHILE (@@FETCH_STATUS = 0 )
				BEGIN
				--- SECCION DE VALIDACION DE LOS PASIVOS
				--- VALIDAR SI EL PASIVO ESTA PAGADA.
				WITH CTE_PasivoPagado as
				(
				SELECT pp.FolioPasivo,
					   pp.FolioDocumento,
					   pp.SerieDocumento,
					   pp.IdPasivo,
					   -- TOTAL DEL PASIVO
					   --Se cambia el calculo por el ImporteTotal del Pasivo SOLICITUD 010117
					   Isnull(ImporteTotal, 0) AS Total,
					   -- PAGO CON MOVIMIENTO BANCARIO
					  (Select SUM(pmb.Importe) From ProPasivosMovimientosBancarios AS pmb  
					   where pmb.IdPasivo = pp.IdPasivo  
						AND  (pmb.FechaHora is not null And pmb.IdMovimientoBancario is not null)) AS  ImportePagadoMovBancario,
		 
					  -- PAGO CON DOCUMENTO
						  (Select SUM(pmb.Importe) From ProPasivosMovimientosBancarios AS pmb  
					   where pmb.IdPasivo = pp.IdPasivo  
						AND  ( pmb.FechaHora is not null And pmb.IdMovimientoBancario is null and pmb.IdPagoProveedorDocumento is not null)) AS  ImportePagadoConDocumento,
		 
					  --- PAGO CON MOVIMIENTOS BANCARIOS ANTICIPADOS.
					  (
						SELECT SUM(ppap.Importe)
						FROM     ProPagosAnticipados as ppa INNER JOIN
										  ProPagosAnticipadosPasivos as ppap ON ppa.IdPagoAnticipado = ppap.IdPagoAnticipado
						WHERE ( ppa.Fecha is not null) And ppap.IdPasivo = pp.IdPasivo	  
					  ) As ImportePagoAnticipo,	
					   pp.IdMoneda
				FROM   ProPasivos AS pp
				   INNER JOIN CatProveedores AS cp
				   ON pp.IdProveedor = cp.IdProveedor
				)
				SELECT  @FolioPasivo	  = cpp.FolioPasivo,
						@FolioDocumento   = cpp.FolioDocumento,
						@SerieDocumento   = cpp.SerieDocumento,
					    @TotalPasivo	  = cpp.Total,
						@ImportePendiente = (cpp.Total - (isnull(cpp.ImportePagadoMovBancario,0) + isnull(cpp.ImportePagadoConDocumento,0) + isnull(cpp.ImportePagoAnticipo,0)) ) , -- as ImportePendiente
						@ImportePagado    = (isnull(cpp.ImportePagadoMovBancario,0) + isnull(cpp.ImportePagadoConDocumento,0) + isnull(cpp.ImportePagoAnticipo,0)) -- as ImportePagado
				FROM CTE_PasivoPagado AS cpp
				WHERE cpp.IdPasivo = @ATT_IdPasivo
				
				-- VALIDA SI EL PASIVO TIENE UN ABONO CON CONTRA RECIBO
				IF ISNULL(@ImportePagado,0) > 0
					BEGIN
						IF EXISTS(Select IdPasivo From ProPasivos Where IdPasivo = @ATT_IdPasivo And IdPasivoContraRecibo Is not null)-- si el pasivo tiene IdContrarecibo y es de pago directo de debe permitir pagarlo
						BEGIN
							SET @Mensaje += 'El Pasivo con No.Documento '+rtrim(ltrim(isnull(@SerieDocumento,'')))+'-'+RIGHT(REPLICATE('0', 10)+ CAST(isnull(@FolioDocumento,0) AS VARCHAR(10)),10)+' se encuentra ligado a un Contra Recibo.'+CHAR(13) + CHAR(10)		
						END
					END

				--- VALIDA SI EL PASIVO ESTA PAGADO
				IF @TotalPasivo=@ImportePagado  
					BEGIN
						SET @Mensaje += 'El pasivo con No.Documento '+rtrim(ltrim(isnull(@SerieDocumento,'')))+'-'+RIGHT(REPLICATE('0', 10)+ CAST(isnull(@FolioDocumento,0) AS VARCHAR(10)),10)+' ya fue pagado por otro usuario, verificar información'+CHAR(13) + CHAR(10)		
					END

				--- VALIDA QUE EL IMPORTE DE PAGO DE PASIVO NO SEA MAYOR AL IMPORTE PENDIENTE DE PAGO
				IF @ATT_ImporteAPagar > @ImportePendiente AND @TotalPasivo <> @ImportePagado
					BEGIN
						SET @Mensaje += 'El pasivo con No.Documento '+rtrim(ltrim(isnull(@SerieDocumento,'')))+'-'+RIGHT(REPLICATE('0', 10)+ CAST(isnull(@FolioDocumento,0) AS VARCHAR(10)),10)+' el importe a pagar es mayor al importe pendiente de pago, verificar información'+CHAR(13) + CHAR(10)	
					END

				FETCH TempProPasivosDetallePagos INTO @ATT_IdPasivo, @ATT_ImporteAPagar
			END
			CLOSE TempProPasivosDetallePagos
			DEALLOCATE TempProPasivosDetallePagos
			
			IF @Mensaje <> ''
				BEGIN
					RAISERROR(@Mensaje, 16, 1)
				END
		
			-- Termina seccion de validacion de concurrencia
			EXEC sp_xml_removedocument @docHandle
			INSERT INTO ProPasivosMovimientosBancarios (IdPasivo,Importe, IdMovimientoBancario, FechaHora)
			SELECT ATT_IdPasivo, ATT_ImporteAPagar, @IdMovimientoBancario, @CreadoEl From #TempProPasivosDetallePagos
		END

	COMMIT  
END TRY  
BEGIN CATCH  
	ROLLBACK  
	EXECUTE usp_SisErrorsGrabar @IdPeticion  
END CATCH
go

