CREATE PROCEDURE [dbo].[usp_Report_Mantenimiento_HistorialReporteFallasTabla]
@fechaInicial date,
@fechaFinal date,
@Filtro nvarchar(max),
@IdUsuario int 
/***********************************************************************************************************************
SOLICITUD 1539

Descripcion: Se agrego el CerradoEl en el query

Modificada por:   Ignacio Perez
Fecha de mofidicacion: 26/03/2030
Versión: Versión 8.0.51.20

Invocada desde: <PAGE_Report_Mantenimiento_HistorialReporteFallasTabla getListado()>
********************************************************************************************************************* */
AS		
DECLARE @SQL nvarchar(max),
		@Parametros nvarchar(max), 
        @str VARCHAR(MAX) ,
        @IdUnidad NVARCHAR(255),
        @pos INT

--Se obtiene los identificadores de las unidades
SET @str= (SELECT Parametros FROM SisParametrosPagina WHERE Pagina = 'PAGE_Report_Mantenimiento_HistorialReporteFallasUnidades' AND IdUsuario = @IdUsuario)

--Se crea una tabla temporal donde se insertan los identificadores
CREATE TABLE #TempReportMantenimientoHistorialReporteFallas( IdUnidad INT)



IF CHARINDEX(',', @str) > 0 
BEGIN

--ciclo para realizar un split e insertar los identificadores en la tabla temporal
	 WHILE CHARINDEX(',', @str) > 0
	 BEGIN
	  SELECT @pos  = CHARINDEX(',', @str)  
	  SELECT @IdUnidad = SUBSTRING(@str, 1, @pos-1)
	 
	  INSERT INTO #TempReportMantenimientoHistorialReporteFallas
	  SELECT @IdUnidad

	  SELECT @str = SUBSTRING(@str, @pos+1, LEN(@str)-@pos)
	 END
	  IF @str <> ''
	  BEGIN
		INSERT INTO #TempReportMantenimientoHistorialReporteFallas
		SELECT @str
	  END
END
 ELSE
 BEGIN
 INSERT INTO #TempReportMantenimientoHistorialReporteFallas
 SELECT @str
 END

------Consulta dinamica		
 SET @SQL =
		N'SELECT
		PRF.Fecha,
		PRF.Folio,
		CU.IdUnidad,
		CU.Codigo,
		CU.Descripcion,
		CTU.TipoUnidad,
		CO.Nombre,
		CCS.ClasificacionServicio,
		PRF.DescripcionFalla,
		PRF.IdOrdenServicio AS OrdenServicio , 
		CS.Sucursal,
		(SELECT CerradoEl FROM ProOrdenesServicios WHERE IdOrdenServicio = PRF.IdOrdenServicio) as CerradoEl
		FROM ProReportesFallas AS PRF
		INNER JOIN CatUnidades AS CU ON PRF.IdUnidad=CU.IdUnidad
		INNER JOIN CatTiposUnidades AS CTU ON CU.IdTipoUnidad=CTU.IdTipoUnidad
		INNER JOIN CatSucursales AS CS ON PRF.IdSucursal=CS.IdSucursal
		LEFT JOIN CatClasificacionesServicios AS CCS ON PRF.IdClasificacionServicio=CCS.IdClasificacionServicio
		LEFT JOIN  CatOperadores AS CO ON PRF.IdOperador=CO.IdOperador
		WHERE
		(CAST(PRF.Fecha AS DATE) >=@FechaI And CAST(PRF.Fecha AS DATE) <= @FechaF )
		AND
		CU.IdUnidad IN (SELECT IdUnidad FROM #TempReportMantenimientoHistorialReporteFallas)
		'+@Filtro;

		print(@Filtro)
 
 SET @Parametros = N'@FechaI date,@FechaF date';
 EXEC sp_executesql @SQL,@Parametros,@FechaI = @fechaInicial,@FechaF = @fechaFinal


--si existe la tabla temporal se elimina
IF OBJECT_ID('#TempReportMantenimientoHistorialReporteFallas') IS NOT NULL
BEGIN
DROP TABLE #TempReportMantenimientoHistorialReporteFallas
END
go

