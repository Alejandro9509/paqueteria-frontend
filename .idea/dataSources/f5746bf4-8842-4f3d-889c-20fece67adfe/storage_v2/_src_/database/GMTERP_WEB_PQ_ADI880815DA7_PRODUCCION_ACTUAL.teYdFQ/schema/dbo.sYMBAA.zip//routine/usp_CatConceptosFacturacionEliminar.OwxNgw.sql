CREATE PROCEDURE [dbo].[usp_CatConceptosFacturacionEliminar]
	@IdConceptoFacturacion int,
	@IdPeticion varchar(100)
AS
/*
MODIFICADO:
	Se agregaro cCatConceptosFacturacionImpuestos para que se eliminen los registros relacionados al concepto que se esta eliminando
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-03-24
SOLICITUD: 
	SOLICITUD 001468
*/
BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(SELECT TOP 1 * FROM ProFacturasConceptosFacturacion WHERE IdConceptoFacturacion = @IdConceptoFacturacion)
		RAISERROR(N'El concepto ya tiene asignado movimientos de facturación, no es posible eliminarlo',
			16,
			1
			)
				
	
	
	DELETE FROM CatConceptosFacturacionImpuestos
	WHERE IdConceptoFacturacion = @IdConceptoFacturacion

	DELETE FROM CatConceptosFacturacion
	WHERE IdConceptoFacturacion = @IdConceptoFacturacion	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

