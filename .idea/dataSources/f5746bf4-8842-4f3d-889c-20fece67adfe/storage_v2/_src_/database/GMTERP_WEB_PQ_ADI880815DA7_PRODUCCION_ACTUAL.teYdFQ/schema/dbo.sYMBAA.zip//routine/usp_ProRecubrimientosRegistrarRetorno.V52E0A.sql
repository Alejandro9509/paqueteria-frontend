CREATE PROCEDURE [dbo].[usp_ProRecubrimientosRegistrarRetorno]  
 @IdRecubrimiento int, 
 @Folio int,
 @QuienRecibe varchar(50),  
 @FechaHoraRetorno datetime,  
 @dsProLlantasNumerosEconomicos ntext,
 @CreadoPor int,  
 @CreadoEl datetime,   
 @IdPeticion varchar(100)
AS  
DECLARE  
 @docHandle int ,
 @ErrorMsg Varchar(500),
 @IdProcesoLlantaRecubierta int,
 @IdEstatusLLantaRecubierta int, 
 @IdProcesoLlantaEnRecubrimiento int,
 @IdEstatusLLantaEnRecubrimiento int,
 @FolioRecubrimiento int
  
BEGIN TRY  
 BEGIN TRANSACTION  
 	SET @IdProcesoLlantaEnRecubrimiento = (SELECT IdProcesoLLanta FROM CatProcesosLlantas WHERE ProcesoLlanta = 'EN RECUBRIMIENTO')
	SET @IdEstatusLLantaEnRecubrimiento = (SELECT IdEstatuLlanta FROM CatEstatusLlantas WHERE EstatusLLanta = 'EN RECUBRIMIENTO' AND DefinidoPorSistema = 1) 

	SET @IdProcesoLlantaRecubierta = (SELECT IdProcesoLLanta FROM CatProcesosLlantas WHERE ProcesoLlanta = 'RECUBIERTA')
	SET @IdEstatusLLantaRecubierta = (SELECT IdEstatuLlanta FROM CatEstatusLlantas WHERE EstatusLLanta = 'RECUBIERTA' AND DefinidoPorSistema = 1) 


	IF ISNULL(@IdRecubrimiento,0) = 0
			RAISERROR(N'El identificador es un campo requerido',
				16,
				1
				)
				
	IF ISDATE(@FechaHoraRetorno) = 0
			RAISERROR(N'La fecha de retorno es un campo requerido',
				16,
				1
				)
  
  IF NOT EXISTS(Select IdRecubrimiento From ProRecubrimientos where ProRecubrimientos.IdRecubrimiento = @IdRecubrimiento )
		BEGIN
			SET @ErrorMsg = 'El recubrimiento folio '+CAST(@Folio AS VARCHAR(50))+' ya fue eliminada por otro usuario, revisar información'
	  		RAISERROR(@ErrorMsg,  
				16,  
				1  
				)   
        END
           
	IF  (Select FechaEnvio From ProRecubrimientos where ProRecubrimientos.IdRecubrimiento = @IdRecubrimiento )> @FechaHoraRetorno
			RAISERROR(N'La fecha de retorno no debe ser menor a la fecha de envío',
				16,
				1
				)

			  
	IF EXISTS(Select IdRecubrimiento From ProRecubrimientos where ProRecubrimientos.Estatus = 2 AND ProRecubrimientos.IdRecubrimiento = @IdRecubrimiento )
		BEGIN
			SET @ErrorMsg = 'El recubrimiento folio '+CAST(@Folio AS VARCHAR(50))+' ya está completa el recubrimiento, revisar información'
	  		RAISERROR(@ErrorMsg,  
				16,  
				1  
				)   
        END
                 
	IF @dsProLlantasNumerosEconomicos IS NULL  
			RAISERROR(N'Los conceptos de la orden de compra son requeridos',  
			16,  
			1  
			) 
			         
	
	UPDATE ProRecubrimientos 
	SET	 QuienRecibe=@QuienRecibe
		,FechaRetorno=@FechaHoraRetorno		
		,ModificadoPor=@CreadoPor
		,ModificadoEl=@CreadoEl
	WHERE IdRecubrimiento = @IdRecubrimiento
	
 IF @dsProLlantasNumerosEconomicos IS NOT NULL
 BEGIN
	 EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProLlantasNumerosEconomicos
	 SELECT ATT_IdLlanta,ATT_NumeroEconomico, ATT_FechaRetorno, ATT_VidaUtil, ATT_CostoRecubrimiento
	 INTO #TempProLlantas
	 FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProLlantas',2) 
	 WITH (ATT_IdLlanta int, ATT_NumeroEconomico varchar(20), ATT_FechaRetorno datetime,ATT_VidaUtil INT, ATT_CostoRecubrimiento money)
	 EXEC sp_xml_removedocument @docHandle
						
	-- Crear cursor
	DECLARE @ATT_IdLlanta int, @ATT_NumeroEconomico varchar(20), @ATT_FechaRetorno datetime,@ATT_VidaUtil INT, @ATT_CostoRecubrimiento money
	DECLARE TempProLlantas CURSOR FOR 
	SELECT 	ATT_IdLlanta , ATT_NumeroEconomico , ATT_FechaRetorno ,ATT_VidaUtil , ATT_CostoRecubrimiento  From #TempProLlantas

	OPEN TempProLlantas 
		FETCH NEXT FROM TempProLlantas INTO @ATT_IdLlanta,@ATT_NumeroEconomico, @ATT_FechaRetorno ,@ATT_VidaUtil , @ATT_CostoRecubrimiento
		 WHILE @@fetch_status = 0
			 BEGIN

						---Valida que la llanta no tenga fecha de recubrimiento					
						IF  exists(SELECT ProRecubrimientos.Folio
							FROM  ProRecubrimientos INNER JOIN
										   ProRecubrimientosLlantas ON ProRecubrimientos.IdRecubrimiento = ProRecubrimientosLlantas.IdRecubrimiento 
										   where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento 
										   And  ProRecubrimientosLlantas.IdLlanta  =@ATT_IdLlanta and ProRecubrimientosLlantas.FechaRetorno is not null)
								BEGIN
									SET @ErrorMsg ='Llanta con número económico '+@ATT_NumeroEconomico+ ' ya tiene fecha de retorno, verificar información'
									RAISERROR(@ErrorMsg ,
												16,
												1
												)
								END					

						
						IF NOT EXISTS(SELECT ProRecubrimientos.Folio
							FROM  ProRecubrimientos INNER JOIN
										   ProRecubrimientosLlantas ON ProRecubrimientos.IdRecubrimiento = ProRecubrimientosLlantas.IdRecubrimiento 
										   where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento 
										   And  ProRecubrimientosLlantas.IdLlanta  =@ATT_IdLlanta)
										   
							BEGIN			     
								SET @ErrorMsg ='Llanta con número económico '+@ATT_NumeroEconomico+ ' no pertenece al envío de recubrimiento, verificar información'
								RAISERROR(@ErrorMsg ,
											16,
											1
											)	               
							END
						               
						-- Valida que la llanta este en recubrimiento
						IF NOT EXISTS(SELECT  IdLlanta from ProLlantas WHERE IdEstatuLlanta = @IdEstatusLLantaEnRecubrimiento AND IdProcesoLlanta = @IdProcesoLlantaEnRecubrimiento and IdLlanta = @ATT_IdLlanta)
							BEGIN
								SET @ErrorMsg ='Llanta con número económico '+@ATT_NumeroEconomico+ ' no está en proceso de recubrimiento, verificar información'
								RAISERROR(@ErrorMsg ,
											16,
											1
											)
							END
							 

						-- Valida que la llanta este en recubrimiento
						IF ISDATE(@ATT_FechaRetorno ) = 0
							BEGIN			
								SET @ErrorMsg ='Fecha de retorno de llanta con número económico '+@ATT_NumeroEconomico+ ' es requerido'
								RAISERROR(@ErrorMsg ,
											16,
											1
											)
							END				
							 												 
						 UPDATE ProRecubrimientosLlantas Set FechaRetorno =  @ATT_FechaRetorno 
											WHERE ProRecubrimientosLlantas.IdRecubrimiento =@IdRecubrimiento 
											    AND  ProRecubrimientosLlantas.IdLlanta  =@ATT_IdLlanta

						 ALTER table ProLlantas disable TRIGGER trg_ProLlantas 						 
						 --  Registrar en auxiliar de llantas
						 --  Cargar datos de la llanta
						 DECLARE 	@ProfundidadRodamiento INT, @KilometrajeHistorico INT,	@VecesRecubierta INT, @PresionActual int
						 SELECT @VecesRecubierta=isnull(VecesRecubierta,0), @PresionActual = PresionActual,@ProfundidadRodamiento=ProfundidadActual, @KilometrajeHistorico= KilometrajeLLanta FROM ProLlantas WHERE IdLlanta = @ATT_IdLlanta 
							
						 --  Actualizar ProLlantas
						 UPDATE ProLlantas SET IdEstatuLlanta = @IdEstatusLLantaRecubierta ,
								IdProcesoLlanta = @IdProcesoLlantaRecubierta,
								CostoLlanta = @ATT_CostoRecubrimiento,
								VidaUtil =@ATT_VidaUtil,
								VecesRecubierta = @VecesRecubierta + 1,
								IdArticulo= Null,
								KilometrajeLLanta = 0					  
						 WHERE IdLlanta = @ATT_IdLlanta
							  
						 --  Registrar en Auxiliar de Llantas															
						 INSERT INTO ProLlantasAuxiliar (IdLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta) 
							   VALUES (@ATT_IdLlanta,@ATT_FechaRetorno,@IdEstatusLLantaRecubierta,@PresionActual,@ProfundidadRodamiento,0,0,@ATT_CostoRecubrimiento,@CreadoPor,@CreadoEl,@IdProcesoLlantaRecubierta) 	
						
						ALTER table ProLlantas enable TRIGGER trg_ProLlantas
											  
					FETCH NEXT FROM TempProLlantas INTO @ATT_IdLlanta,@ATT_NumeroEconomico, @ATT_FechaRetorno,@ATT_VidaUtil , @ATT_CostoRecubrimiento
			  END
			  DROP TABLE #TempProLlantas
			  CLOSE TempProLlantas
			  DEALLOCATE TempProLlantas		
			-- FIN DE SECCION DE RETORNO DE LLANTAS 
			-- Actualiza estatus de prorecubierta
			  DECLARE @CantidadLlantasARecubrir int, @CantidadRecubiertas int
			   
			  SET @CantidadLlantasARecubrir= (SELECT COUNT(ProRecubrimientosLlantas.IdLlanta) AS CantidadLlantas
					FROM  ProRecubrimientosLlantas INNER JOIN
								   ProRecubrimientos ON ProRecubrimientosLlantas.IdRecubrimiento = ProRecubrimientos.IdRecubrimiento
					where ProRecubrimientos.IdRecubrimiento=@IdRecubrimiento )
			
			  SET @CantidadRecubiertas= (SELECT COUNT(ProRecubrimientosLlantas.IdLlanta) AS CantidadLlantas
					FROM  ProRecubrimientosLlantas INNER JOIN
								   ProRecubrimientos ON ProRecubrimientosLlantas.IdRecubrimiento = ProRecubrimientos.IdRecubrimiento
					where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento AND ProRecubrimientosLlantas.FechaRetorno IS NOT NULL)
		
					 IF @CantidadLlantasARecubrir = @CantidadRecubiertas
						UPDATE ProRecubrimientos SET Estatus =2 where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento --Completa
					 ELSE
						UPDATE ProRecubrimientos SET Estatus =3 where ProRecubrimientos.IdRecubrimiento =@IdRecubrimiento --parcialmente surtida
		
			-- fin Actualiza estatus de prorecubierta
	 
	END
    
 COMMIT  
END TRY  
BEGIN CATCH  
	  ROLLBACK
	  EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

