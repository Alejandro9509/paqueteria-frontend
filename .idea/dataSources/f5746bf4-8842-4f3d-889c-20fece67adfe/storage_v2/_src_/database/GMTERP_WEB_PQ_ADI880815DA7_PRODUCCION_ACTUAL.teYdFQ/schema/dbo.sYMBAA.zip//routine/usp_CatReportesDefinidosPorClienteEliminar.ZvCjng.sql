CREATE PROCEDURE [dbo].[usp_CatReportesDefinidosPorClienteEliminar]
@IdReporte int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@IdReporte,0)= 0
		RAISERROR(N'El identificador del reporte es un campo requerido',
				16,
				1
				)	
			
		DELETE CatReportesDefinidosPorCliente Where IdReporteDefinidoPorCliente = @IdReporte
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

