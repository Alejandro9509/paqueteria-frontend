
CREATE PROCEDURE [dbo].[usp_CatGruposUnidadesAgregarPQ](
	@Codigo int,
	@GrupoUnidad varchar(50),
	@DefinidoPorSistema bit,
	@CreadoEl datetime,
	@CreadoPor int,
	@ModificadoEl datetime,
	@ModificadoPor int,
	@Color varchar(6),
	@ColorLetra int)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Codigo,0) <= 0 begin
			RAISERROR(N'*INICIO*El Código del grupo de unidad es un campo requerido*FIN*', 16, 1);
			return
		end
		IF ISNULL(@GrupoUnidad, '') = '' begin
			RAISERROR(N'*INICIO*El Nombre del grupo de unidad es un campo requerido*FIN*', 16, 1);
			return
		end
		IF ISNULL(@DefinidoPorSistema, '') = '' begin
			RAISERROR(N'*INICIO*Definido por sistema es un campo requerido*FIN*', 16, 1);
			return
		end
		IF ISNULL(@Color , '') = '' begin
			RAISERROR(N'*INICIO*El color es un campo requerido*FIN*', 16, 1);
			return
		end
		IF ISNULL(@ColorLetra , '') = '' begin
			RAISERROR(N'*INICIO*El color de la letra es un campo requerido*FIN*', 16, 1);			
			return
		end
		INSERT INTO CatGruposUnidades(Codigo, GrupoUnidad, DefinidoPorSistema,CreadoEl,CreadoPor,ModificadoEl,ModificadoPor,Color,ColorLetra)
		VALUES (@Codigo, @GrupoUnidad, @DefinidoPorSistema,@CreadoEl,@CreadoPor,@ModificadoEl,@ModificadoPor,@Color,@ColorLetra)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

