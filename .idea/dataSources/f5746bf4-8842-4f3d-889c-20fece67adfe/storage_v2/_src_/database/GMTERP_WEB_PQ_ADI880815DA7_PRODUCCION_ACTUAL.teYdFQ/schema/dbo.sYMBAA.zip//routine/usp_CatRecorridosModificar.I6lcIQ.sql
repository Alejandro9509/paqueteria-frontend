CREATE PROCEDURE usp_CatRecorridosModificar 
	
	@IdRecorrido int,
	@IdCliente int,
	@IdOrigen int,
	@IdDestino int,
	@FolioRecorrido int,
	@Descripcion varchar(140),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@Activa bit,
	@RutaGoogleMap ntext,
	@IdPeticion varchar(100),
	@dsCatRutasPersonalClientesContatos ntext,
	@dsCatRutasPersonalParadas ntext,
	@HorasTrayecto decimal(15, 2),
	@KmTrayecto int,
	@GeocercasSalida int,
	@DarSalidaES int,
	@EstatusViajeSalidaAutomatica int,
	@GeocercasLlegada int,
	@DarLlegadaES int,
	@EstatusViajeLlegadaAutomatica int 
AS
DECLARE
	@docHandle int,
	@CursorIdRutaPersonalPuntuacion int,
	@CursorIdPuesto int,
	@CursorPuntos int,
	@CursorIdRutaPersonalClienteContacto int, 
	@CursorIdClienteContacto int,
	@CursorIdGeocerca int, 
	@CursorIdEstatuViajeEntrada int, 
	@CursorIdEstatuViajeSalida int, 
	@CursorIdRutaPersonalParada  int 
			
BEGIN TRY
	BEGIN TRANSACTION
		
		IF (SELECT ModificadoEl FROM CatRecorridos WHERE IdRecorrido = @IdRecorrido) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta ruta fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise',
			16,
			1
			)
		IF @FolioRecorrido = 0 
		RAISERROR(N'El folio de la ruta es un campo requerido',
			16,
			1
			)
		IF EXISTS(SELECT * FROM CatRecorridos WHERE FolioRecorrido = @FolioRecorrido AND IdRecorrido != IdRecorrido)		 	
		RAISERROR(N'El folio de la ruta ya existe en el catálogo',
			16,
			1
			)
		IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
		IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)			
		IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)			
		IF RTRIM(LTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción de la ruta es un campo requerido',
			16,
			1
			)	
		
				
	--UPDATE A LA TABLA CATRUTASPERSONAL CON LA INFORMACION PROPORCIONADA		
	UPDATE CatRecorridos SET
	IdCliente = @IdCliente,
	IdOrigen = @IdOrigen,
	IdDestino = @IdDestino,
	FolioRecorrido = @FolioRecorrido,
	Descripcion = @Descripcion,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	Activa = @Activa,
	RutaGoogleMap = @RutaGoogleMap,
	HorasRecorrido = @HorasTrayecto,
	KmRecorrido = @KmTrayecto,
	GeocercasSalida = @GeocercasSalida, 
	DarSalidaES = @DarSalidaES,
	EstatusViajeSalidaAutomatica = @EstatusViajeSalidaAutomatica,
	GeocercasLlegada = @GeocercasLlegada,
	DarLlegadaES = @DarLlegadaES,
	EstatusViajeLlegadaAutomatica = @EstatusViajeLlegadaAutomatica
	WHERE IdRecorrido = @IdRecorrido 
		
	
	----SECCION PARA AGREGAR LAS CONTACTOS
	IF @dsCatRutasPersonalClientesContatos IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalClientesContatos
	
		SELECT ATT_IdClienteContacto,ATT_IdRutaPersonalClienteContacto
		INTO #TempCatRutasPersonalClientesContatos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalClientesContatos',2) 
		WITH (ATT_IdClienteContacto int,ATT_IdRutaPersonalClienteContacto int)
	
		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorCatRutasPersonalClientesContatos CURSOR FOR
		SELECT * FROM #TempCatRutasPersonalClientesContatos

		OPEN CursorCatRutasPersonalClientesContatos
		FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
		INTO @CursorIdClienteContacto, @CursorIdRutaPersonalClienteContacto
			
		WHILE @@FETCH_STATUS = 0
		BEGIN 
			IF @CursorIdRutaPersonalClienteContacto = 0
			BEGIN
				INSERT INTO CatRecorridosClientesContatos(IdRecorrido,IdClienteContacto,CreadoPor,CreadoEl)
				VALUES(@IdRecorrido,@CursorIdClienteContacto,@ModificadoPor,@ModificadoEl)
			END
			ELSE
			BEGIN
				UPDATE CatRecorridosClientesContatos 
				SET
				IdRecorrido = @IdRecorrido, 
				IdClienteContacto = @CursorIdClienteContacto,
				ModificadoPor = @ModificadoPor,
				ModificadoEl = @ModificadoEl
				WHERE IdRecorridoClienteContacto = @CursorIdRutaPersonalClienteContacto  
			END
			FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
			INTO @CursorIdClienteContacto, @CursorIdRutaPersonalClienteContacto
		END
		CLOSE CursorCatRutasPersonalClientesContatos
		DEALLOCATE CursorCatRutasPersonalClientesContatos	
	END----SECCION PARA AGREGAR LAS CONTACTOS
	DELETE FROM CatRecorridosClientesContatos WHERE IdRecorrido = @IdRecorrido AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
	----SECCION PARA AGREGAR LAS GEOCERCAS 
	IF @dsCatRutasPersonalParadas IS NOT NULL 
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalParadas

		SELECT ATT_IdGeocerca, ATT_IdEstatuViajeEntrada, ATT_IdEstatuViajeSalida, ATT_IdRutaPersonalParada
		INTO #TempCatRutasPersonalParadas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalParadas',2) 
		WITH (ATT_IdGeocerca int, ATT_IdEstatuViajeEntrada int, ATT_IdEstatuViajeSalida int, ATT_IdRutaPersonalParada int )
			
        EXEC sp_xml_removedocument @docHandle
	
		DECLARE CursorCatRutasPersonalParadas CURSOR FOR
		SELECT * FROM #TempCatRutasPersonalParadas

		OPEN CursorCatRutasPersonalParadas
		FETCH NEXT FROM CursorCatRutasPersonalParadas
		INTO @CursorIdGeocerca, @CursorIdEstatuViajeEntrada, @CursorIdEstatuViajeSalida, @CursorIdRutaPersonalParada
			
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF  @CursorIdRutaPersonalParada= 0	 
			BEGIN
				INSERT INTO CatRecorridosSalidasLlegadasGeocercas(IdRecorrido,IdGeocerca,IdEstatuViajeEntrada,IdEstatuViajeSalida,CreadoPor,CreadoEl)
				VALUES( @IdRecorrido,@CursorIdGeocerca,
				CASE @CursorIdEstatuViajeEntrada WHEN 0 THEN NULL ELSE @CursorIdEstatuViajeEntrada END,
				CASE @CursorIdEstatuViajeSalida WHEN 0 THEN NULL ELSE @CursorIdEstatuViajeSalida END,
				@ModificadoPor,@ModificadoEl)
			END
			ELSE
			BEGIN
				UPDATE CatRecorridosSalidasLlegadasGeocercas 
				SET
				IdGeocerca = @CursorIdGeocerca,
				IdEstatuViajeEntrada = CASE @CursorIdEstatuViajeEntrada WHEN 0 THEN NULL ELSE @CursorIdEstatuViajeEntrada END,
				IdEstatuViajeSalida = CASE @CursorIdEstatuViajeSalida WHEN 0 THEN NULL ELSE @CursorIdEstatuViajeSalida END,
				ModificadoEl = @ModificadoEl,
				ModificadoPor = @ModificadoPor
				WHERE IdRecorridosSalidasLlegadasGeocercas = @CursorIdRutaPersonalParada	           				
			END
			FETCH NEXT FROM CursorCatRutasPersonalParadas
			INTO @CursorIdGeocerca, @CursorIdEstatuViajeEntrada, @CursorIdEstatuViajeSalida, @CursorIdRutaPersonalParada
		END
		CLOSE CursorCatRutasPersonalParadas
		DEALLOCATE CursorCatRutasPersonalParadas
	END----SECCION PARA AGREGAR LAS GEOCERCAS 
	DELETE FROM CatRecorridosSalidasLlegadasGeocercas WHERE IdRecorrido = @IdRecorrido AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
	
    COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

