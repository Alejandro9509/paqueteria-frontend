CREATE PROCEDURE [dbo].[usp_ProTableroUnidadesTemporalAgregar]
	@IdUsuario int,
	@dsProTableroUnidadesTemporal ntext,
	@IdPeticion varchar(100),
	@FechaHoraSucursal datetime
AS
DECLARE
	@docHandle int,
	@PorcentajeLitros int
BEGIN TRY
	BEGIN TRANSACTION
	
	Delete from ProTableroUnidadesTemporal where IdUsuario = @IdUsuario	
	
	IF @dsProTableroUnidadesTemporal IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProTableroUnidadesTemporal
		
		SELECT Unidad,
		Ubicacion,
		Evento,
		VoltajeVehiculo,
		Latitud,
		Longitud,
		Codigo,
		NoSerie,
		IdUsuarioWeb,
		FechaModificadoWeb,
		ZonaRiesgo,
		CASE 
		WHEN FechaDeReactivacion IS NULL THEN NULL
		WHEN FechaDeReactivacion = '' THEN NULL
		ELSE FechaDeReactivacion
		END AS FechaDeReactivacion,
		Mantenimiento,
		Icono,
		FechaDeReactivacionCadena,
		SumaLitrosTanques,
		TieneSensor,
		PocentajeCombustible,    --Solicitud 9916 agregar porcentaje combustible y tiempo ralenti al tablero
		TiempoRalenti,			--Solicitud 9916 agregar porcentaje combustible y tiempo ralenti al tablero
		CantidadSatelites,
		FechaHoraUltimoReporte
		INTO #TempProTableroUnidadesTemp
		FROM OPENXML(@docHandle, N'/Markers/Marker',2) 
		WITH (Unidad varchar(16),
		Ubicacion varchar(700),
		Evento varchar(50),
		VoltajeVehiculo decimal(15, 4),
		Latitud float,
		Longitud float,
		Codigo varchar(16),
		NoSerie varchar(26),
		IdUsuarioWeb int,
		FechaModificadoWeb varchar(300),
		ZonaRiesgo varchar(100),
		FechaDeReactivacion datetime,
		Mantenimiento bit,
		Icono varchar(200),
		FechaDeReactivacionCadena varchar(350),
		SumaLitrosTanques decimal(15, 4),
		TieneSensor bit,
		PocentajeCombustible FLOAT,
		TiempoRalenti varchar(30),
		CantidadSatelites int,
		FechaHoraUltimoReporte VARCHAR(30))  
		
		EXEC sp_xml_removedocument @docHandle
		

		INSERT INTO ProTableroUnidadesTemporal (CodigoUnidad,
		UltimaUbicacion,
		UltimoEvento,
		Voltaje,
		Latitud,
		Longitud,
		CodigoEvento,
		IdentificadorSatelital,
		ZonaRiesgo,
		FechaSalida,
		EstaMantenimiento, 
		IdUsuario,
		IdUnidad,
		Placas,
		SerieUnidad,
		IdGrupoUnidad,
		GrupoUnidad,
		IdTipoUnidad,
		TipoUnidad,
		IdOperador,
		Operador,
		IconoUltimoEvento,
		FechaSalidaCadena,
		ModificadoPor,
		FechaModificado,
		PorcentajeCombustible,
		TiempoRalenti,
		ColorUnidad,
		Modelo,
		CantidadSatelites,
		FechaHoraUltimoReporte
		
		)
		SELECT cu.Codigo, 
		tmp.Ubicacion,
		tmp.Evento,
		tmp.VoltajeVehiculo,
		tmp.Latitud,
		tmp.Longitud,
		tmp.Codigo,
		tmp.NoSerie,
		tmp.ZonaRiesgo,
		tmp.FechaDeReactivacion,
		tmp.Mantenimiento, 
		@IdUsuario,
		cu.IdUnidad,
		cu.Placas,
		cu.SerieUnidad,
		cu.IdGrupoUnidad,
		cgu.GrupoUnidad,
		ctu.IdTipoUnidad,
		ctu.TipoUnidad,
		co.IdOperador,
		co.Nombre,
		'Imagenes/'+tmp.Icono+'.png' AS Icono,
		tmp.FechaDeReactivacionCadena,
		case isnull(tmp.IdUsuarioWeb,0) when 0 then ''  
		else (select Usuario from CatUsuarios where IdUsuario = tmp.IdUsuarioWeb)  
		END AS Usuario,
		tmp.FechaModificadoWeb,  --Solicitud 9916 agregar porcentaje combustible y tiempo ralenti al tablero
		CASE 
	        WHEN tmp.TieneSensor = 1 AND cu.CapacidadTanqueCombustible > 0 THEN
		CASE 
			WHEN (CAST((tmp.SumaLitrosTanques * 100)AS INT) / cu.CapacidadTanqueCombustible) > 100 THEN 'N/A' 
			ELSE cast( (CAST((tmp.SumaLitrosTanques * 100)AS INT) / cu.CapacidadTanqueCombustible) as varchar)+'%' 
		END 
			WHEN (tmp.PocentajeCombustible) >= 0 then CAST((tmp.PocentajeCombustible)  AS varchar)+'%'
			ELSE 'N/A'
		END PorcentajeCombustible,
	    tmp.TiempoRalenti,	--Solicitud 9916 agregar porcentaje combustible y tiempo ralenti al tablero
		cu.ColorUnidad,
		cu.Modelo,
		tmp.CantidadSatelites,
		tmp.FechaHoraUltimoReporte
		FROM #TempProTableroUnidadesTemp as tmp
		inner join CatUnidades as cu on cu.IdentificadorSatelital = NoSerie collate Modern_Spanish_CS_AS
		inner join CatGruposUnidades as cgu on cgu.IdGrupoUnidad = cu.IdGrupoUnidad
		inner join CatTiposUnidades as ctu on ctu.IdTipoUnidad = cu.IdTipoUnidad
		left join CatOperadores as co on co.IdOperador = cu.IdOperador
		inner join CatUsuarios as ca on ca.IdUsuario = @IdUsuario
		WHERE ((ca.TipoUsuario = 5 AND cu.IdUnidad IN(SELECT cueu.IdUnidad 
	FROM CatUsuariosEspejosUnidades  AS cueu 
	WHERE cueu.IdUsuarioEspejo = @IdUsuario AND cueu.FechaVencimiento > @FechaHoraSucursal)) 
	OR(ca.TipoUsuario != 5))

	
		DELETE FROM ProTableroUnidadesTemporal where IdUsuario = @IdUsuario AND IdUnidad is null

	END	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

