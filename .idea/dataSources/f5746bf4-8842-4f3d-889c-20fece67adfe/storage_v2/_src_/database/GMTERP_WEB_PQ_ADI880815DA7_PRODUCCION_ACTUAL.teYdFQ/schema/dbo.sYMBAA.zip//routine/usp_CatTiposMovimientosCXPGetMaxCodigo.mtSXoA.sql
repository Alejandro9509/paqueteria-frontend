CREATE PROCEDURE [dbo].[usp_CatTiposMovimientosCXPGetMaxCodigo]
AS
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTiposMovimientosCXP
go

