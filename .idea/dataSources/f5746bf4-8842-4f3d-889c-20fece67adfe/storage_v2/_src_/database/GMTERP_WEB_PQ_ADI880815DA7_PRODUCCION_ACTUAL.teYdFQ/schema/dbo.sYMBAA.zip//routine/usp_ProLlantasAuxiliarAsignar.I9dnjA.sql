
CREATE PROCEDURE [dbo].[usp_ProLlantasAuxiliarAsignar]
@IdLlanta int,
@IdUnidad int,
@NumeroPosicionLlanta int,
@FechaHora datetime,
@IdEstatuLlanta int,
@PresionActual decimal (10, 2),
@ProfundidadRodamiento decimal(10, 2),
@KilometrajeDeLLanta int,
@KilometrajeHistorico int,
@CostoParaUnidad money,
@IdProcesoLlanta int,
@CreadoPor int,
@CreadoEl datetime,
@IdPeticion varchar(100),
@Refaccion bit,
@IdOrdenServicioParte int -- Parte de orden de servicio
--@AsignaOrdenServicio bit -- Bandera para identificar 0= asignacion directa, 1= asignacion por orden de servicio
AS
DECLARE 
	@MessageError varchar(8000)
BEGIN TRY
	BEGIN TRANSACTION
	
	SET @MessageError =''
	IF ISDATE(@FechaHora)= 0 
		RAISERROR(N'Fecha de asignación es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdLlanta,0)= 0 
		RAISERROR(N'Identificador de llanta es un campo requerido',
			16,
			1
			)
	
	IF EXISTS(SELECT PendienteEtiqueta FROM ProLlantas WHERE PendienteEtiqueta = 1 and IdLlanta = @IdLlanta)
				RAISERROR(N'La llanta debe estar etiquetado, no es posible asignar',
				16,
				1
				)
	
	IF ISNULL(@IdOrdenServicioParte,0) = 0
		BEGIN
			SET @IdOrdenServicioParte = NULL
			IF EXISTS(SELECT IdArticulo FROM ProLlantas WHERE IdLlanta = @IdLlanta And IdArticulo is not null) 
				RAISERROR(N'La llanta viene de una compra no se puede asignar',
						16,
						1
						)
		END						
								
	IF ISNULL(@IdUnidad,0)= 0 
		RAISERROR(N'Identificador de unidad es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@NumeroPosicionLlanta,0)= 0 
		RAISERROR(N'No de posición de llanta es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdEstatuLlanta,0)= 0 
		RAISERROR(N'Identificador estatus de unidad es un campo requerido',
			16,
			1
			)
	
	IF EXISTS(SELECT IdUnidad FROM ProLlantas WHERE IdLlanta = @IdLlanta AND IdUnidad IS NOT NULL) 
		BEGIN
			SET @MessageError = (SELECT 'Llanta ya está asignado a la unidad [' +Codigo+' - '+Descripcion +'], revisar información ' AS Mensaje FROM CatUnidades WHERE IdUnidad =  (SELECT IdUnidad FROM ProLlantas WHERE IdLlanta = @IdLlanta AND IdUnidad IS NOT NULL)) 
				RAISERROR(@MessageError ,
					16,
					1
					)
		END
		
	
	IF EXISTS(SELECT IdUnidad FROM ProLlantas WHERE IdUnidad = @IdUnidad And NumeroPosicionLlanta = @NumeroPosicionLlanta) 
		RAISERROR(N'Número de posición de llanta ya está ocupada',
			16,
			1
			)
	
	IF ISNULL(@PresionActual,0)= 0 
		RAISERROR(N'Presión de llanta es un campo requerido',
			16,
			1
			)

	IF ISNULL(@ProfundidadRodamiento,0)= 0 
		RAISERROR(N'Profundidad de rodamiento de llanta es un campo requerido',
			16,
			1
			)
							
	
	IF EXISTS(SELECT IdLlanta FROM ProLlantas WHERE IdLlanta = @IdLlanta AND IdProcesoLlanta = (SELECT IdProcesoLLanta FROM CatProcesosLlantas WHERE ProcesoLlanta = 'DESECHADA')) 
		RAISERROR(N'La llanta ya está desechada, verificar información',
			16,
			1
			)
			
	IF EXISTS(SELECT IdLlanta  FROM ProLlantas WHERE IdLlanta = @IdLlanta AND IdProcesoLlanta = (SELECT IdProcesoLLanta FROM CatProcesosLlantas WHERE ProcesoLlanta = 'EN RECUBRIMIENTO')) 
		RAISERROR(N'La llanta ya está en recubrimiento, verificar información',
			16,
			1
			)
						
	-- Actualizar ProLlantas
	UPDATE ProLlantas SET IdUnidad = @IdUnidad,
						  NumeroPosicionLlanta = @NumeroPosicionLlanta,
						  CostoLlanta = @CostoParaUnidad,
						  ProfundidadActual =@ProfundidadRodamiento,
						  PresionActual = @PresionActual,
						  IdEstatuLlanta = @IdEstatuLlanta,
						  KilometrajeLLanta=isnull(KilometrajeLLanta,0)+@KilometrajeDeLLanta,
						  Refaccion = @Refaccion,
						  IdProcesoLlanta = @IdProcesoLlanta,
						  IdOrdenServicioParte = @IdOrdenServicioParte
	WHERE IdLlanta = @IdLlanta						   
	
	-- Registrar en Auxiliar de Llantas															
	INSERT INTO ProLlantasAuxiliar (IdLlanta,IdUnidad,NumeroPosicionLlanta,FechaHora,IdEstatuLlanta,PresionActual,ProfundidadRodamiento,KilometrajeDeLLanta,KilometrajeHistorico,CostoParaUnidad,CreadoPor,CreadoEl,IdProcesoLlanta,Refaccion,IdOrdenServicioParte) 
		   VALUES (@IdLlanta,@IdUnidad,@NumeroPosicionLlanta,@FechaHora,@IdEstatuLlanta,@PresionActual,@ProfundidadRodamiento,@KilometrajeDeLLanta,@KilometrajeHistorico,@CostoParaUnidad,@CreadoPor,@CreadoEl,@IdProcesoLlanta,@Refaccion,@IdOrdenServicioParte) 	
	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

