CREATE PROCEDURE [dbo].[usp_CatUnidadesEliminar]
	@IdUnidad int,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF EXISTS(Select Top 1 IdViaje from ProViajes Where IdUnidadCarga1 = @IdUnidad OR IdUnidadCarga2 = @IdUnidad OR IdUnidadContenedor1 = @IdUnidad OR IdUnidadContenedor2 = @IdUnidad OR IdUnidadDolly = @IdUnidad) 
	OR EXISTS(SELECT TOP 1 IdViajeTrayecto FROM ProViajesTrayectos WHERE IdUnidadCamion = @IdUnidad)
		RAISERROR(N'La unidad tiene viajes asigandos, no es posible eliminarlo',
			16,
			1
			)
	
	IF EXISTS(SELECT TOP 1 IdValeCombustible FROM ProValesCombustible WHERE IdUnidad = @IdUnidad)
		RAISERROR(N'La unidad tiene vales de combustible asigandos, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 IdCargaAutopista FROM ProCargasAutopistas WHERE IdUnidad = @IdUnidad)
		RAISERROR(N'La unidad tiene autopistas cargadas, no es posible eliminarlo',
			16,
			1
			)

	IF EXISTS(SELECT TOP 1 IdConsumoCombustible FROM ProConsumosCombustible WHERE IdUnidad = @IdUnidad)
		RAISERROR(N'La unidad tiene consumos de combustibles cargados, no es posible eliminarlo',
			16,
			1
			)	
			
	IF ISNULL((Select IdentificadorSatelital from CatUnidades Where IdUnidad = @IdUnidad),'') <> ''
		RAISERROR(N'La unidad cuenta con identificador satelital NO SE PUEDE ELIMINAR, contacte con el departamento de Localización',
			16,
			1
			)		
								
	DELETE FROM CatUnidades
	WHERE IdUnidad = @IdUnidad
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

