
CREATE PROCEDURE [dbo].[usp_CatRemitentesDestinatariosEliminarPQ]
	@IdRemitenteDestinatario int
AS
BEGIN TRY
	BEGIN TRANSACTION
		DELETE FROM CatRemitentesDestinatarios
		WHERE IdRemitenteDestinatario = @IdRemitenteDestinatario
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

