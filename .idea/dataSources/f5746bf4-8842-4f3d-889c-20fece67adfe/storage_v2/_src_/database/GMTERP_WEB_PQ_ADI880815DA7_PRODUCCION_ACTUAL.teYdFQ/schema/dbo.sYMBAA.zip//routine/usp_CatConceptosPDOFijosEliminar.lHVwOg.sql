CREATE PROCEDURE [dbo].[usp_CatConceptosPDOFijosEliminar]
@IdConceptoPDOFijo int,
@IdPeticion varchar(100),
@IdEmpleado int, 
@IdPeriodo int
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdConceptoPDOFijo,0)= 0
	RAISERROR(N'El identificador de conceptos PDO fijos es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT IdConceptoPDOFijo FROM ProNominasReciboConceptos WHERE IdConceptoPDOFijo=@IdConceptoPDOFijo )
	RAISERROR(N'No es posible eliminar el concepto, porque ya se asoció al recibo. ',
			16,
			1	
			)		
		
		DELETE CatConceptosPDOFijos
		WHERE 	IdConceptoPDOFijo=@IdConceptoPDOFijo

		UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

