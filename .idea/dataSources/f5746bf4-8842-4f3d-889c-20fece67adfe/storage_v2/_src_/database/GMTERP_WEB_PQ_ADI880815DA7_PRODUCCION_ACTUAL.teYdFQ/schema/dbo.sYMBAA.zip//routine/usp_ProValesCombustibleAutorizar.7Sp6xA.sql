
CREATE PROCEDURE [dbo].[usp_ProValesCombustibleAutorizar]
-- Declaracion de parámetros 
@IdValeCombustible int,
@AutorizadoEl datetime,
@AutorizadoPor int,
@IdPeticion varchar(100)
/* *************************************************************************************************
Procedimiento usp_ProValesCombustibleAutorizar

Parámetros: 
    @IdValeCombustible int Id del Vale de combustible 
    @AutorizadoEl datetime Fecha de autorizacion 
    @AutorizadoPor int Id Usuario que autorizo 
    @IdPeticion varchar(100) peticion 

Descripción: Para autorizar vales de combistible, para asginar referencias. 

Implementada por: Enrique Ramos Alvarez 
Fecha de implementacion: 19/09/2019 
Versión: 8.0.46.12

Modificada por:   <Nombre del último progrador que lo modificó>
Fecha de mofidicacion: <(dd/mm/yyyy)>
Versión: <Versión ERP en la que fue modificada >

Invocada desde: PAGE_ProValesCombustibleListado, ClsProValesCombustible
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdValeCombustible ,0) <= 0
		RAISERROR(N'El identificador del vale es un campo requerido',
			16,
			1
			)			
	IF NOT EXISTS(SELECT IdValeCombustible  FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible )
		RAISERROR(N'El Vale fue eliminado por otro usuario',
			16,
			1
			)					
	IF EXISTS(SELECT IdValeCombustible  FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible  AND AutorizadoEl IS NOT NULL)
		RAISERROR(N'El Vale fue autorizado por otro usuario',
			16,
			1
			)
	IF EXISTS(SELECT IdValeCombustible  FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible  AND CanceladoEl IS NOT NULL)
		RAISERROR(N'El Vale esta cancelado',
			16,
			1
			)			
	IF @AutorizadoEl = ''		
	RAISERROR(N'La fecha de autorización es un campo requerido',
		16,
		1
		)			
	UPDATE ProValesCombustible SET
		AutorizadoEl = @AutorizadoEl,
		AutorizadoPor = @AutorizadoPor
	WHERE IdValeCombustible  = @IdValeCombustible 
			
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

