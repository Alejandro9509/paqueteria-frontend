



CREATE PROCEDURE [dbo].[usp_ProViajeDetalleParadasAgregarPQ](	
	
	@IdViaje int ,
	@IdInforme int ,
	@IdOperador int ,
	@IdUnidad int ,
	@CVR1 int ,
	@CVR2 int ,
	@Referencia varchar(50) 
	--@FechaCarga date ,
	--@FechaEntrega date,
	--@HoraCarga time(7),
	--@HoraEntrega  time(7)

	)
AS
BEGIN
	BEGIN TRANSACTION
	
	

		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdInforme, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de informe es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

	
	
		/*IF ISNULL(@FechaSalida, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@HoraSalida,'' ) = '' begin
			RAISERROR(N'*INICIO*La hora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/
		/*
		IF ISNULL(@IdEstatusSalida, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus de salida un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@KmViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Los kilometros de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@MillasViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Las millas de viaje esun campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		*/
		insert into ProViajeDetalleParadasPQ(	
		IdViaje ,
		IdInforme,
		IdOperador ,
	IdUnidad  ,
	CVR1  ,
	CVR2,
	Referencia  
	--FechaCarga  ,
	--FechaEntrega ,
	--HoraCarga ,
	--HoraEntrega 
)
	values
	(@IdViaje,
	@IdInforme,
		@IdOperador  ,
	@IdUnidad  ,
	@CVR1  ,
	@CVR2,
	@Referencia  
--	@FechaCarga ,
--	@FechaEntrega ,
--	@HoraCarga,
--	@HoraEntrega  

	);
		IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

