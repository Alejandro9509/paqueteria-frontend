
create PROCEDURE usp_CatRecorridosDespachoGetMaxFolio

AS

SELECT ISNULL(MAX(Folio),0)+1 AS FolioDespacho FROM ProRecorridosDespacho
go

