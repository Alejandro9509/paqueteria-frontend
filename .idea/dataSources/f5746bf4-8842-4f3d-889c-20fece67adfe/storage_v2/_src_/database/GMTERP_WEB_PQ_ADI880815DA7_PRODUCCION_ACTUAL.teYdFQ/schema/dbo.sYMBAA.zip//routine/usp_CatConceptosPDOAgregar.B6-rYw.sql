CREATE PROCEDURE [dbo].[usp_CatConceptosPDOAgregar]
		@NumeroConcepto int,
		@TipoConcepto int,
		@Descripcion varchar(40),
		@Especie bit,
		@AutomaticoGlobal bit,
		@AutomaticoLiquidacion bit,
		@Imprimir bit,
		@LeyendaImporte1 varchar(40),
		@LeyendaImporte2 varchar(40),
		@LeyendaImporte3 varchar(40),
		@LeyendaImporte4 varchar(40),
		@LeyendaValor varchar(40),
		@FormulaImporteTotal ntext,
		@FormulaImporte1 ntext,
		@FormulaImporte2 ntext,
		@FormulaImporte3 ntext,
		@FormulaImporte4 ntext,
		@FormulaValor ntext,
		@ClaveAgrupadoraSAT varchar(20),
		@CreadoEl    datetime,    
		@CreadoPor    int,    
		@IdPeticion varchar(100),
		@dsTiposAcumulados ntext,
		@IdFormulaImporteTotal int,
		@IdFormulaImporte1 int,
		@IdFormulaImporte2 int,
		@IdFormulaImporte3 int,
		@IdFormulaImporte4 int,
		@IdFormulaValor int,
		@LeyendaImporteTotal Varchar(40),
		@ClaveOtrosPagos varchar(5),
		@GravaISRArt142 bit,
		@MantenerValores bit
AS
DECLARE
	@IdConceptoPDO int,
	@docHandle int,
	@ATT_IdTipoAcumulado int,
	@ATT_Pestania int,
	@ATT_AcumuladoFiscal bit
	
BEGIN TRY
    BEGIN TRANSACTION
    IF @NumeroConcepto <= 0
        RAISERROR(N'El Número de Concepto es un campo requerido',
            16,
            1
            )
            
    IF ISNULL(@Descripcion,'')= ''
        RAISERROR(N'La Descripción es un campo requerido',
            16,
            1
            )

	IF EXISTS(SELECT Descripcion FROM CatConceptosPDO WHERE Descripcion=@Descripcion)
		RAISERROR(N'La descripción del concepto ya existe',
			16,
			1
			)
           
	 
	IF EXISTS(SELECT NumeroConcepto FROM CatConceptosPDO WHERE NumeroConcepto = @NumeroConcepto)
		RAISERROR(N'El Código del tipo de periodo ya existe',
			16,
			1
			)                     
      
    	 --Sección para actualizar el campo ClaveOtrosPagos en caso de que el tipo de concepto sea deducción
	IF @TipoConcepto = 3 --con el número 3 se hacer referencia a las obligaciones 
	BEGIN
		SET @ClaveOtrosPagos = null
	END    
	        
		INSERT INTO CatConceptosPDO(NumeroConcepto,TipoConcepto,Descripcion,Especie,AutomaticoGlobal,AutomaticoLiquidacion,Imprimir,LeyendaImporte1,LeyendaImporte2,LeyendaImporte3,LeyendaImporte4,LeyendaValor,FormulaImporteTotal,FormulaImporte1,FormulaImporte2,FormulaImporte3,FormulaImporte4,FormulaValor,ClaveAgrupadoraSAT,CreadoEl,CreadoPor,IdFormulaImporteTotal,IdFormulaImporte1,IdFormulaImporte2,IdFormulaImporte3,IdFormulaImporte4,IdFormulaValor,LeyendaImporteTotal,ClaveOtrosPagos,GravaISRArt142,MantenerValores)
		VALUES(@NumeroConcepto,@TipoConcepto,@Descripcion,@Especie, @AutomaticoGlobal,@AutomaticoLiquidacion,@Imprimir,@LeyendaImporte1,@LeyendaImporte2, @LeyendaImporte3, @LeyendaImporte4, @LeyendaValor,@FormulaImporteTotal,@FormulaImporte1, @FormulaImporte2, @FormulaImporte3, @FormulaImporte4, @FormulaValor,@ClaveAgrupadoraSAT,@CreadoEl,@CreadoPor,@IdFormulaImporteTotal,@IdFormulaImporte1,@IdFormulaImporte2,@IdFormulaImporte3,@IdFormulaImporte4,@IdFormulaValor,@LeyendaImporteTotal,@ClaveOtrosPagos,@GravaISRArt142,@MantenerValores)
		
		SET @IdConceptoPDO = (SELECT IDENT_CURRENT('CatConceptosPDO'))
	
	--SECCION PARA AGREGAR LOS el dtalle de los acumulados
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsTiposAcumulados
	
	SELECT ATT_IdTipoAcumulado,ATT_Pestania,ATT_AcumuladoFiscal
	INTO #TempCatTiposAcumulados
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_TiposAcumulados',2) 
	WITH (ATT_IdTipoAcumulado int,ATT_Pestania int,ATT_AcumuladoFiscal bit)
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatTiposAcumulados CURSOR FOR
	SELECT * FROM #TempCatTiposAcumulados
	
	OPEN CursorCatTiposAcumulados
	FETCH NEXT FROM CursorCatTiposAcumulados
	INTO @ATT_IdTipoAcumulado,@ATT_Pestania,@ATT_AcumuladoFiscal
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
						
		INSERT INTO CatConceptosPDOTiposAcumulados(IdConceptoPDO,IdTipoAcumulado,Pestania,AcumuladoFiscal,CreadoEl,CreadoPor)
		VALUES(@IdConceptoPDO,@ATT_IdTipoAcumulado,@ATT_Pestania,@ATT_AcumuladoFiscal,@CreadoEl,@CreadoPor)		

		FETCH NEXT FROM CursorCatTiposAcumulados
		INTO @ATT_IdTipoAcumulado,@ATT_Pestania,@ATT_AcumuladoFiscal
	END
	
	IF @AutomaticoGlobal=1
	BEGIN
		INSERT INTO CatEmpleadosConceptosPDO(IdEmpleado,IdConceptoPDO,CreadoEl,CreadoPor) 
		SELECT IdEmpleado,@IdConceptoPDO,@CreadoEl,@CreadoPor FROM CatEmpleados WHERE FechaBaja IS NULL
	END
	
	CLOSE CursorCatTiposAcumulados
	DEALLOCATE CursorCatTiposAcumulados						

    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

