
	CREATE PROCEDURE [dbo].[usp_CatTiposServiciosModificar]
	@IdTipoServicio	int,
	@TipoServicio varchar(50),	
	@Activo bit,
	@IdPeticion varchar(100)	
	AS
	BEGIN TRY
		BEGIN TRANSACTION
		
		IF ISNULL(@IdTipoServicio,0)= 0
		RAISERROR(N'El identificador del Tipo de Servicio es un campo requerido',
				16,
				1
				)

		IF ISNULL(@TipoServicio,'')= ''
			RAISERROR(N'El Tipo de Servicio es un campo requerido',
				16,
				1
				)
				
		UPDATE CatTiposServicios SET
		TipoServicio= @TipoServicio,
		Activo= @Activo
		WHERE 	IdTipoServicio=@IdTipoServicio
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

