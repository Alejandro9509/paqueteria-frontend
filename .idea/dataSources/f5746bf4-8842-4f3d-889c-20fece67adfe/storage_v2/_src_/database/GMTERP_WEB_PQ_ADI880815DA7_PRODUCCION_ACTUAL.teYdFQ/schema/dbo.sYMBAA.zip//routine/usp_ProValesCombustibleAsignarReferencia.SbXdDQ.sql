
CREATE PROCEDURE [dbo].[usp_ProValesCombustibleAsignarReferencia]
-- Declaracion de parámetros 
@IdValeCombustible int,
@ReferenciadoEl datetime,
@ReferenciadoPor int,
@Referencia varchar(100),
@IdPeticion varchar(100)
/* *************************************************************************************************
Procedimiento usp_ProValesCombustibleAsignarReferencia

Parámetros: 
    @IdValeCombustible int Id del Vale de combustible 
    @ReferenciadoEl datetime Fecha que se asigno la referencia 
    @ReferenciadoPor int Id Usuario que asigno la referencia 
	@Referencia varchar(100)  Referencia del vale 
    @IdPeticion varchar(100) peticion 

Descripción: Para asginar una referencia, desde el listado de Vales de combistible 
             

Implementada por: Enrique Ramos Alvarez 
Fecha de implementacion: 20/09/2019 
Versión: 8.0.46.15

Modificada por:   <Nombre del último progrador que lo modificó>
Fecha de mofidicacion: <(dd/mm/yyyy)>
Versión: <Versión ERP en la que fue modificada >

Invocada desde: PAGE_ProValesCombustibleListado, ClsProValesCombustible
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdValeCombustible ,0) <= 0
		RAISERROR(N'El identificador del vale es un campo requerido',
			16,
			1
			)			
	IF NOT EXISTS(SELECT IdValeCombustible  FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible )
		RAISERROR(N'El Vale fue eliminado por otro usuario',
			16,
			1
			)					
	IF EXISTS(SELECT IdValeCombustible  FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible  AND ReferenciadoEl IS NOT NULL)
		RAISERROR(N'El Vale fue referenciado por otro usuario',
			16,
			1
			)
	IF EXISTS(SELECT IdValeCombustible  FROM ProValesCombustible WHERE IdValeCombustible = @IdValeCombustible  AND CanceladoEl IS NOT NULL)
		RAISERROR(N'El Vale esta cancelado',
			16,
			1
			)			
	IF @ReferenciadoEl = ''			
	RAISERROR(N'La fecha de autorización es un campo requerido',
		16,
		1
		)			
	UPDATE ProValesCombustible SET
		ReferenciadoEl	=   @ReferenciadoEl ,
		ReferenciadoPor =	@ReferenciadoPor ,
		Referencia =	    @Referencia 
	WHERE IdValeCombustible  = @IdValeCombustible 
			
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

