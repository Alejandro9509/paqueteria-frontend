
CREATE PROC [dbo].[usp_ProRelacionLiquidacionesPemexEliminar]
	@IdRelacionLiquidacionPemex INT,
	@Estatus INT,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Procedimiento usp_ProRelacionLiquidacionesPemexEliminar

Parámetros:
	@IdRelacionLiquidacionPemex    (entrada, entero). Id de la Relación Liquidación PEMEX.
	@Estatus                       (entrada, entero). Indica el estado de la Relación.
    @IdPeticion				       (entrada, string). Id de la Petición, generada en WEBDEV.

Descripción: Procedimiento para eliminar una Relación Liquidación PEMEX cancelada.

09/03/2020 - Se creó.

Implementada por: Ricardo Sinai Miranda Pantoja
Fecha de implementacion: 09/03/2020
Versión ERP: 8.0.50.33

Invocada desde: PAGE_ProRelacionLiquidacionPemexListado (Solicitud 922)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION
	-- Validaciones
	IF @IdRelacionLiquidacionPemex = 0
		RAISERROR(N'El Id de la relación de liquidación es un campo requerido', 16, 1)

	IF @Estatus != 4
		RAISERROR(N'La relación debe estar cancelada para poder eliminar', 16, 1)

	-- Elimina el registro de la tabla puente
	DELETE FROM ProRelacionLiquidacionesPemexDetalle WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex
	-- Luego, elimina el registro de la tabla principal
	DELETE FROM ProRelacionLiquidacionesPemex WHERE IdRelacionLiquidacionPemex = @IdRelacionLiquidacionPemex

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

