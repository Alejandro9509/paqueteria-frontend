

CREATE PROCEDURE [dbo].[usp_ProUnidadAgregarAdicionalPQ](
	@IdUnidad int,
	@NumeroDocumento int,
	@Documento varchar(200),
	@Fecha date
	
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdUnidad, 0) = 0 begin
			RAISERROR(N'El Identificaodr de Unidad es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NumeroDocumento, 0) = 0 begin
			RAISERROR(N'El Numero de documento es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@Documento, '') = '' begin
			RAISERROR(N'La descripcion del documento es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
	
		IF ISNULL(@Fecha, '') = '' begin
			RAISERROR(N'La fecha del documento es un campo requerido', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
	end
		

		Insert into dbo.ProUnidadesAdicionalesPQ(IdUnidad,NumeroDocumento,Documento,
			Fecha) Values (@IdUnidad,@NumeroDocumento,@Documento,@Fecha);
		
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
go

