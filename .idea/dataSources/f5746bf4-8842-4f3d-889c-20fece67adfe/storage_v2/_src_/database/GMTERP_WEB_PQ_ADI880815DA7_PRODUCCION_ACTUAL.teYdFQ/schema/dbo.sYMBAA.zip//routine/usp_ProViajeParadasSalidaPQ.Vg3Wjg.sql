CREATE PROCEDURE [dbo].[usp_ProViajeParadasSalidaPQ](	
	@IdViaje int,
	@IdViajeSalida int
	
	)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de Viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdViajeSalida, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de salida es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		insert into dbo.ProViajeParadasPQ (IdViaje,IdSalida) values(@IdViaje,@IdViajeSalida)
	
	 
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

