
CREATE PROCEDURE [dbo].[usp_CatClientesModificarNombreRFCPQ](
	@IdCliente int,
	@NombreFiscal varchar(12),
	@RFC varchar(13))

	AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdCliente, 0) <= 0 begin
			RAISERROR(N'*INICIO*El id del cliente es campo requerido*FIN*', 16, 1);
			return
		end;

		IF ISNULL(@NombreFiscal, '') = '' begin
			RAISERROR(N'*INICIO*El nombre fiscal del cliente es un campo requerido*FIN*', 16, 1);
			return
		end
		IF ISNULL(@RFC, '') = '' begin		
			RAISERROR(N'*INICIO*El RFC es un campo requerido*FIN*', 16, 1);
			return
		end;
		UPDATE CatClientes SET
		NombreFiscal=@NombreFiscal ,
		RFC=@RFC
		WHERE IdCliente = @IdCliente
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

