
CREATE PROCEDURE [dbo].[usp_CatIMSSPatronAgregar]
@FechaVigencia datetime,
@EspecieGastosMedicos decimal(15, 3),
@EspecieFija decimal(15, 3),
@EspecieMasSMDF decimal(15, 3),
@PrestacionesEnDinero decimal(15, 3),
@InvalidezYVida decimal(15, 3),
@CesantiaYVejez decimal(15, 3),
@Guarderias decimal(15, 3),
@Retiro decimal(15, 3),   
@CreadoEl    datetime,    
@CreadoPor    int, 
@IdPeticion varchar(100) 
AS
BEGIN TRY
    BEGIN TRANSACTION
    
	--Validar si la fecha de vigencia esta registrada
		IF EXISTS(Select * FROM CatIMSSPatron where YEAR(FechaVigencia) = YEAR(@FechaVigencia))
	RAISERROR(N'No se permiten registros con fecha de vigencia duplicada',
			16,
			1
			)		
            
    INSERT INTO CatIMSSPatron(FechaVigencia,EspecieGastosMedicos,EspecieFija,EspecieMasSMDF,PrestacionesEnDinero,InvalidezYVida,CesantiaYVejez,Guarderias,Retiro,CreadoEl,CreadoPor)
    VALUES(@FechaVigencia,@EspecieGastosMedicos,@EspecieFija,@EspecieMasSMDF,@PrestacionesEnDinero,@InvalidezYVida,@CesantiaYVejez,@Guarderias,@Retiro,@CreadoEl,@CreadoPor)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

