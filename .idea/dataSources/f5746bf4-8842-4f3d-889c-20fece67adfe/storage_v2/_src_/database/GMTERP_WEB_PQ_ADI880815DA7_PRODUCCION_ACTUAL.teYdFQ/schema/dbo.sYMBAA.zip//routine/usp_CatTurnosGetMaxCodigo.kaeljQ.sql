

CREATE PROCEDURE [dbo].[usp_CatTurnosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatTurnos
go

