create PROCEDURE [dbo].[usp_CatServiciosGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatServicios
go

