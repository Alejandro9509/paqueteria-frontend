CREATE PROCEDURE [dbo].[usp_CatGruposProveedoresModificar]
@IdGrupoProveedor int,
@Codigo	int,	
@Grupo	varchar(50),	
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdGrupoProveedor,0)= 0
	RAISERROR(N'El identificador de grupo de proveedor es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código de grupo de proveedor es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@Grupo,'')= ''
		RAISERROR(N'El descripción grupo de proveedor es un campo requerido',
			16,
			1
			)
			
	UPDATE CatGruposProveedores SET
	Codigo= @Codigo,
	Grupo= @Grupo,
	ModificadoEl= @ModificadoEl,
	ModificadoPor= @ModificadoPor
	WHERE 	IdGrupoProveedor=@IdGrupoProveedor
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

