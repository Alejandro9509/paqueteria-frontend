CREATE PROCEDURE [dbo].[usp_CatPropietariosEquiposModificar]
@IdPropietarioEquipo int,
@Codigo	int,	
@Descripcion varchar(50),	
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100),
@RFC varchar(13)='',
@IdPais int =0,
@NoRegistroIdentidadFiscal varchar(20)='',
@CodigoPostal varchar(10)='',
@IdEstado varchar(5)='',
@Municipio varchar(50)='',
@Localidad varchar(50)='',
@Colonia varchar(50)='',
@Calle varchar(50)='',
@NoExterior varchar(10)='',
@NoInterior varchar(10)='',
@Telefono varchar(20)='',
@Correo varchar(100)='',
@Contacto varchar(90)='',
@DescripcionPropietario varchar(50)=''
AS
/******************************************************/
/*
Modificada por:   Yarazeth Lemus Hdez
Fecha de mofidicacion: 26/08/2021
Solicitud:4755
se agregaron campos nuevos para complemento en la tabla CatPropietariosEquipos
*/
/*****************************************************/
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdPropietarioEquipo,0)= 0
	RAISERROR(N'El identificador es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código del equipo es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@Descripcion,'') = ''
		RAISERROR(N'El nombre es un campo requerido',
			16,
			1
			)
			
			
	IF EXISTS(SELECT Codigo FROM CatPropietariosEquipos WHERE Codigo = @Codigo And IdPropietarioEquipo <> @IdPropietarioEquipo)
		RAISERROR(N'El código del equipo ya existe',
			16,
			1
			)
			
	IF EXISTS(SELECT Descripcion FROM CatPropietariosEquipos WHERE Descripcion = @Descripcion And IdPropietarioEquipo <> @IdPropietarioEquipo )
		RAISERROR(N'El nombre ya existe',
			16,
			1
			)									

	IF EXISTS(SELECT RFC FROM CatPropietariosEquipos WHERE RFC = @RFC And IdPropietarioEquipo <> @IdPropietarioEquipo and RFC is not null)
		RAISERROR(N'El RFC ya existe',
			16,
			1
			)

			
	UPDATE CatPropietariosEquipos SET
	Codigo = @Codigo,
	Descripcion = @Descripcion,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor,
	RFC = @RFC,
    IdPais = @IdPais,
    NoRegistroIdentidadFiscal = @NoRegistroIdentidadFiscal,
    CodigoPostal = @CodigoPostal,
    IdEstado = @IdEstado,
    Municipio = @Municipio,
    Localidad = @Localidad,
    Colonia = @Colonia,
    Calle = @Calle,
    NoExterior =  @NoExterior,
    NoInterior = @NoInterior,
    Telefono = @Telefono,
    Correo = @Correo,
	Contacto = @Contacto,
	DescripcionPropietario= @DescripcionPropietario
	WHERE IdPropietarioEquipo = @IdPropietarioEquipo
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

