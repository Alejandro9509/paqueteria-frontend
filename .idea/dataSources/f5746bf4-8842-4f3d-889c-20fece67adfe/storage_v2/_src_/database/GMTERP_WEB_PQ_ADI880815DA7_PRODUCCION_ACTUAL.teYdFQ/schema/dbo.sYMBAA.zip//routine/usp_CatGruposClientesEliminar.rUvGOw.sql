
CREATE PROCEDURE [dbo].[usp_CatGruposClientesEliminar]
@IdGrupoCliente int,
@IdPeticion varchar(100)	
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdGrupoCliente,0)= 0
		RAISERROR(N'El identificador de grupo de cliente es un campo requerido',
				16,
				1
				)
	IF EXISTS(SELECT TOP 1 IdCliente FROM CatClientes WHERE IdGrupoCliente = @IdGrupoCliente)
				RAISERROR(N'El grupo tiene clientes ligados, no es posible eliminarlo',
				16,
				1
				)

		DELETE CatGruposClientes
		WHERE 	IdGrupoCliente=@IdGrupoCliente
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

