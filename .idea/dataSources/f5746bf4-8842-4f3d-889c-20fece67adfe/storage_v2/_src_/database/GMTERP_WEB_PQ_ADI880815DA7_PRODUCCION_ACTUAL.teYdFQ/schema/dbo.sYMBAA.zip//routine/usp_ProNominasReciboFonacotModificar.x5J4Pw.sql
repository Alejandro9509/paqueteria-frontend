CREATE PROCEDURE [dbo].[usp_ProNominasReciboFonacotModificar]
	@IdProNominasReciboFonacot int ,
	@IdConceptoFonacot int,	
	@IdEmpleado int,
	@CentroTrabajoFonacot varchar(40),	
	@NumeroFonacot varchar(50),
	@NumeroCreditoFonacot varchar(40),
	@Activo bit,
	@FechaInicioAplicacion datetime,
	@Descripcion varchar(50),
	@TipoCalculoRetencion int,
	@ImporteCredito decimal(15,3),
	@ImporteFijoperiodo decimal(15,3),
	@ImporteFijoMensual decimal(15,3),
	@PagosOtrosPatrones decimal(15,3),
	@MontoAcumuladoRetenido decimal(15,3),
	@SaldoCredito decimal(15,3),
	@FechaRegistro datetime,
	@Observaciones varchar(40),		
	@ModificadoPor int,
	@ModificadoEl datetime,	
	@IdPeticion varchar(100),
	@IdPeriodo int
/* *************************************************************************************************
Procedimiento usp_ProNominasReciboFonacotModificar

Parámetros: 
	@IdConceptoFonacot int,				`(Entrada, Entero), Identificador del Concepto PDO, asociado al credito.
	@IdEmpleado int,					 (Entrada, Entero), Identificador del empleado.
	@CentroTrabajoFonacot varchar(50),	 (Entrada, Cadena), Clave de la sucursal Fonacot en la localidad.
	@NumeroFonacot varchar(50),			 (Entrada, Cadena), Clave asignada al empleado para identificar las operaciones solicitadas.
	@NumeroCreditoFonacot varchar(50),	 (Entrada, Entero), Clave asignada a cada prestamo solicitado por el empleado.
	@Activo bit,						 (Entrada, Bolean), Estatus del Credito, permite que se descuente/No se descuente el improet por sistema.
	@FechaInicioAplicacion datetime,	 (Entrada, Fecha ), Fecha donde se inicia el descuento en el sistema.
	@Descripcion varchar(40),			 (Entrada, Cadena), Se utiliza para identificar cada uno de los prestamos que tenga el empleado.
	@TipoCalculoRetencion int,			 (Entrada, Entero), Identificador que determina si sera descuento Fijo/Porporcional.
	@ImporteCredito decimal(15,3),		 (Entrada, Entero), Valor del credito solicitado.
	@ImporteFijoperiodo decimal(15,3),	 (Entrada, Entero), Valor que se descontara cada periodo en el sistema.
	@ImporteFijoMensual decimal(15,3),	 (Entrada, Entero), Valor Mensual que se le descontara al empelado.
	@PagosOtrosPatrones decimal(15,3),	 (Entrada, Entero), Monto de pagos realizados en otros trabajo(s).
	@MontoAcumuladoRetenido decimal(15,3),(Entrada, Entero), Monto total acumulado al momento.
	@SaldoCredito decimal(15,3),		 (Entrada, Entero), Monto restante a liquidar del credito.
	@FechaRegistro datetime,			 (Entrada, Entero), Fecha en que se registro el credito en sistema.
	@Observaciones varchar(150),		 (Entrada, Entero), Notas adjuntas del credito.
	@CreadoPor int,						 (Entrada, Entero), Identificador del usuario que genero el registro en sistema.
	@CreadoEl datetime,					 (Entrada, Entero), Fecha que se genero el registro.
	@IdPeticion varchar(100),			 (Entrada, Entero), Id de la Petición, generada en WEBDEV 
	@IdPeriodo int						 (Entrada, Entero), Identificador del periodo de registro en nomina.
		

Descripción: El procedimiento modifica el registro de la informacion de los creditos Fonacot que son solicitados por el empleado.

Implementada por: Raymundo Espinoza Garcia
Fecha de implementacion: 23/02/2020
Versión ERP: 8.0.59.05
Solicitud: 3947

Modificada por: Raymundo Espinoza Garcia
Fecha de implementacion: 02/03/2020
Versión ERP: 8.0.59.13
Solicitud: 3947


Invocada desde: PAGE_ProNominasReciboFONACOTAM (Solicitud 3947)
***************************************************************************************************** */
AS
DECLARE
@NumeroConcepto int = 0,
@DescripcionConcepto varchar(40),
@IdConceptoPDOFijoFonacot int,
@TipoConceptoPDOFonacot int =0,
@ImporteValor int=0,
@MontoAcumulado decimal(15,3)=0
BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
		
		IF ISNULL(@NumeroCreditoFonacot,'') = ''
		   RAISERROR(N'El numero de credito es un campo requerido',
				16,
				1
				)
		
		IF @Descripcion = ''
			RAISERROR(N'La descripción es un campo requerido',
				16,
				1
				)

		IF isnull(@FechaInicioAplicacion, '') = ''
			RAISERROR(N'La fecha de inicio de aplicación es un campo requerido',
				16,
				1
				)	

		IF ISNULL(@IdConceptoFonacot,0) = 0
			RAISERROR(N'El concepto de fonacot es un campo requerido',
				16,
				1
				)
    SET @IdConceptoPDOFijoFonacot = (SELECT IdConceptoPDOFijoFonacot FROM ProNominasReciboFonacot WHERE IdNominaReciboFonacot = @IdProNominasReciboFonacot)
	
	UPDATE ProNominasReciboFonacot 
	   SET 	
	    IdConceptoFonacot = @IdConceptoFonacot,
		CentroTrabajoFonacot = @CentroTrabajoFonacot, 
		NumeroFonacot = @NumeroFonacot, 
		NumeroCreditoFonacot = @NumeroCreditoFonacot, 
		Activo = @Activo, 
		FechaInicioAplicacion =  @FechaInicioAplicacion , 
		Descripcion = @Descripcion, 
		TipoCalculoRetencion = @TipoCalculoRetencion, 
		ImporteCredito = @ImporteCredito, 
		ImporteFijoPeriodo = @ImporteFijoperiodo, 
		ImporteFijoMensual = @ImporteFijoMensual, 
		PagosOtrosPatrones = @PagosOtrosPatrones, 
		MontoAcumuladoRetenido = @MontoAcumuladoRetenido, 
		SaldoCredito = @SaldoCredito, 
		FechaRegistro = @FechaRegistro, 
		Observaciones = @Observaciones, 
		ModificadoPor = @ModificadoPor ,	
		ModificadoEl = @ModificadoEl  
	WHERE IdNominaReciboFonacot = @IdProNominasReciboFonacot

	--Sección para modificar en CatConceptosPDOFijos
	IF ISNULL(@IdConceptoFonacot,0) <> 0 AND ISNULL(@IdConceptoPDOFijoFonacot,0) <> 0
	BEGIN
	
		SET @NumeroConcepto = (SELECT NumeroConcepto FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoFonacot)
		SET @DescripcionConcepto = (SELECT Descripcion FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoFonacot)
		SET @TipoConceptoPDOFonacot = (SELECT TipoConcepto FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoFonacot)
		SET @MontoAcumulado = @MontoAcumuladoRetenido + @PagosOtrosPatrones
		SET @ImporteValor = @TipoCalculoRetencion

		UPDATE CatConceptosPDOFijos 
		    SET
			IdConceptoPDO = @IdConceptoFonacot, 
			Descripcion = @Descripcion, 
			FechaInicioAplicacion = @FechaInicioAplicacion, 
			ImporteValor = @ImporteValor, 
			MontoLimite = @ImporteCredito, 
			MontoAcumulado = @MontoAcumulado,	
			FechaRegistro = @FechaRegistro, 
			Activo = @Activo, 
			ModificadoPor = @ModificadoPor, 
			ModificadoEl = @ModificadoPor, 
			Importe = @ImporteFijoperiodo, 
			TipoConcepto = @TipoConceptoPDOFonacot, 
			NumeroConcepto = @NumeroConcepto, 
			DescripcionConcepto = @DescripcionConcepto, 
			IdNominaReciboFonacot = @IdProNominasReciboFonacot 
		WHERE IdConceptoPDOFijo = @IdConceptoPDOFijoFonacot
	END

	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	COMMIT
END TRY
BEGIN CATCH	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

