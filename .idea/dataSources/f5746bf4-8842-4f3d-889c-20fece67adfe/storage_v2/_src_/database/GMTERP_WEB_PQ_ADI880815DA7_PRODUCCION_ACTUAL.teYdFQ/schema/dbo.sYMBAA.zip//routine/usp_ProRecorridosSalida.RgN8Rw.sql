CREATE PROCEDURE [dbo].[usp_ProRecorridosSalida]
	@IdRecorrido int,
	@IdRecorridoParada int,
	@Salida datetime,
	@IdEstatuViaje int,
	@IdEstatuUnidad int,
	@ControlarInventario bit,
	@OdometroInicial int,
	@ModificadoPor  int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@RutaGoogleMap ntext,
	@TiempoRuta decimal(15,2),
	@EstatusGeneradoAutomaticamente bit = 0
	/*
	Modificada por: Gustavo Partida Nevarez
	Fecha de mofidicacion: 22/06/2020
	Versión: Versión 8.0.51.23 
	Solicitud 1912
	*/
AS
DECLARE 
	@IdUnidadCamion int,
	@IdCliente int,
	@IdUbicacion int,
	@return_value int,
	@CodigoUnidad varchar(16),
	@Recorrido int,
	@MensajeError varchar(200),
	@IdOperador int
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdRecorrido,0) = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdRecorridoParada,0) = 0
		RAISERROR(N'El identificador de la parada es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdEstatuViaje,0) = 0
		RAISERROR(N'El estatus del viaje es un campo requerido',
			16,
			1
			)
			
	IF ISDATE(@Salida) = 0
		RAISERROR(N'La fecha y hora de salida es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT CanceladoEl FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido AND CanceladoEl IS NOT NULL)--cancelado
		RAISERROR(N'No se puede dar salida a este recorrido porque está cancelado',
			16,
			1
			)	

	IF EXISTS(SELECT Salida FROM ProRecorridoParadas WHERE IdRecorrido = @IdRecorrido AND IdRecorridoParada = @IdRecorridoParada AND Salida IS NOT NULL)--tiene salida
		RAISERROR(N'No se puede dar salida a esta parada porque ya tiene salida',
			16,
			1
			)
			
	SELECT 
		@IdUbicacion = IdOrigen,
		@IdOperador = IdOperador,
		@IdUnidadCamion = IdUnidadCamion 
	FROM 
	ProRecorridoParadas 
	WHERE IdRecorridoParada = @IdRecorridoParada

	SET @IdCliente = (SELECT IdCliente FROM ProRecorridos WHERE IdRecorrido = @IdRecorrido)
	
	IF @IdOperador is null--cancelado
		RAISERROR(N'No se puede dar salida a este recorrido porque no tiene operador asignado',
			16,
			1
			)
			
	IF @IdUnidadCamion is null--cancelado
		RAISERROR(N'No se puede dar salida a este recorrido porque no tiene Camión asignado',
			16,
			1
			)			

	IF @ControlarInventario = 1
	BEGIN
		IF EXISTS(SELECT ceu.TipoEstatus FROM CatEstatusUnidades AS ceu	INNER JOIN ProInventarioUnidades AS piu ON ceu.IdEstatuUnidad = piu.IdEstatuUnidad 
		WHERE piu.IdUnidad = @IdUnidadCamion AND ceu.TipoEstatus = 1 AND ISNULL(IdRecorrido,0) != @IdRecorrido)
		BEGIN
			SET @CodigoUnidad = (SELECT CodigoUnidadCamion FROM ProRecorridoParadas WHERE IdRecorrido = @IdRecorrido)
			SET @Recorrido = (SELECT pv.Recorrido FROM ProRecorridos AS pv INNER JOIN ProInventarioUnidades AS piu ON pv.IdRecorrido = piu.IdRecorrido INNER JOIN CatEstatusUnidades AS ceu ON piu.IdEstatuUnidad = ceu.IdEstatuUnidad WHERE piu.IdUnidad = @IdUnidadCamion AND ceu.TipoEstatus = 1)
			IF @Recorrido IS NULL
				SET @MensajeError = 'No se puede dar salida a este recorrido porque el camión '+CAST(@CodigoUnidad AS varchar)+' está ocupado.'
			ELSE
				SET @MensajeError = 'No se puede dar salida a este recorrido porque el camión '+CAST(@CodigoUnidad AS varchar)+' está ocupado en el recorrido '+CAST(@Recorrido as varchar)+' Termine el recorrido anterior para poder dar salida a este.'	

			RAISERROR(@MensajeError,
				16,
				1
				)
		END
	END

	UPDATE ProRecorridoParadas SET
		Salida = @Salida,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		OdometroInicial = @OdometroInicial,
		RutaGoogleMap = @RutaGoogleMap,
		Horas = @TiempoRuta
	WHERE IdRecorridoParada = @IdRecorridoParada

	UPDATE ProRecorridos SET
		IdEstatuViaje = @IdEstatuViaje,
		FechaHoraRecorridoEstatus = @Salida,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	WHERE IdRecorrido = @IdRecorrido

	INSERT INTO ProRecorridosEstatus(CreadoEl,CreadoPor,FechaHora,IdEstatusViaje,IdRecorrido,GeneradoAutomaticamente,IdRecorridoParada)
	VALUES(@ModificadoEl,@ModificadoPor,@Salida,@IdEstatuViaje,@IdRecorrido,@EstatusGeneradoAutomaticamente,@IdRecorridoParada)


	IF @IdUnidadCamion IS NOT NULL
	BEGIN
		EXEC @return_value = usp_ProInventarioUnidadesActualizar @IdUnidadCamion,'',@IdEstatuUnidad,@IdCliente,NULL,@IdUbicacion,@Salida,@ModificadoPor,@ModificadoEl,@IdPeticion,@IdRecorrido

		IF @return_value <> 0
		RAISERROR(N'Ocurrió un error al actualizar el inventario de equipo camión',
			16,
			1
			)
			
		IF(SELECT Odometro FROM CatUnidades WHERE IdUnidad = @IdUnidadCamion) > @OdometroInicial
		BEGIN
			RAISERROR(N'El odómetro del camión no puede ser menor al que tiene en el catálogo de unidades.',
				16,
				1
				)			
		END
		ELSE
		BEGIN
			UPDATE CatUnidades SET
			Odometro = @OdometroInicial
			WHERE IdUnidad = @IdUnidadCamion
			
			INSERT INTO ProUnidadesOdometros(IdUnidad,Odometro,FechaLectura)
			VALUES(@IdUnidadCamion,@OdometroInicial,@Salida)				
		END
	END
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

