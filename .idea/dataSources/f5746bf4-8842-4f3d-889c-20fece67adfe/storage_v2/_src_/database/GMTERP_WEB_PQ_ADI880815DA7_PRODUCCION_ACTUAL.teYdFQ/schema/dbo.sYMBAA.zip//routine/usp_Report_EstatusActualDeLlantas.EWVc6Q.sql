CREATE PROCEDURE [dbo].[usp_Report_EstatusActualDeLlantas]
@FechaFinal date ,
@Filtro nvarchar(max) ,
@IdUsuario int 
AS		
DECLARE 
@SQL nvarchar(max),
@Parametros nvarchar(max), 
@CadenaUnidades VARCHAR(MAX) ,
@IdUnidad NVARCHAR(255),
@SigUnidad INT
/*
	Parametros:
	@FechaFinal: Fecha Hasta que selecciona el usuario.
	@Filtro: Todos los estatus de llanta que seleccione el usuario
	@IdUsuario: identificador del usuario que genero el reporte para obtener las unidades que selecciono.

	Descripción:
	Este procedimiento almacenado sustituye el query principal del reporte Reporte Estatus Actual de LLantas, ya que
	hay algunos usuarios que quieren generar el reporte por mas de 30mil unidades y el operador IN no lo soporta.
	Se opto por guardar todas las unidades seleccionadas por el usuario en SisParametros como una cadena y separarlos por 
	la ',' y guardarlos en una tabla temporal para poder obtener el reporte.
	La tabla temporal se elimina al finalizar la consulta.
	
	Se modifico el filtro de FechaHora haciendo un cast con solo la fecha (DATE).
	Modificado por: Luis Edgar Ramos Cadena
	Fecha de Modificacion: 02/10/2019
	Versión: 8.0.46.35
	Solicitud 0146

	Creado por: Luis Edgar Ramos Cadena
	Fecha de Creacion: 28/09/2019
	Versión: 8.0.46.26
	Solicitud 0146

	Modificado por: Jose Amado Navarro
	Fecha de Creacion: 07/04/2020
	Versión 8.0.51.34
	Solicitud 0974

	Modificado por : Luis Edgar Ramos Cadena
	Fecha de modificacion: 09/10/2020
	Versión: 8.0.55.58
	Solicitud 3230
	Se modifico en la subconsulta del query principal , que obtuviera el ultimo movimiento por posicion y unidad.

	Invocado desde: PAGE_Report_Llantas_EstatusActualDeLlantasTabla
*/
--Se obtiene los identificadores de las unidades
SET @CadenaUnidades= (SELECT Parametros FROM SisParametrosPagina WHERE Pagina = 'PAGE_Report_Llantas_EstatusActualDeLlantasUnidades' AND IdUsuario = @IdUsuario)

--Se crea una tabla temporal donde se insertan los identificadores
CREATE TABLE #ReporteEstatusActualDeLlantas( IdUnidad INT)

IF CHARINDEX(',', @CadenaUnidades) > 0 
BEGIN
--ciclo para realizar un split e insertar los identificadores en la tabla temporal
	WHILE CHARINDEX(',', @CadenaUnidades) > 0
	BEGIN
		SELECT @SigUnidad  = CHARINDEX(',', @CadenaUnidades)  
		SELECT @IdUnidad = SUBSTRING(@CadenaUnidades, 1, @SigUnidad-1)
	 
		INSERT INTO #ReporteEstatusActualDeLlantas
		SELECT @IdUnidad

		SELECT @CadenaUnidades = SUBSTRING(@CadenaUnidades, @SigUnidad+1, LEN(@CadenaUnidades)-@SigUnidad)
	END
	IF @CadenaUnidades <> ''
	BEGIN
		INSERT INTO #ReporteEstatusActualDeLlantas
		SELECT @CadenaUnidades
	END
END
 ELSE
 BEGIN
	 INSERT INTO #ReporteEstatusActualDeLlantas
	 SELECT @CadenaUnidades
 END

--Consulta dinamica		
 SET @SQL =
		N'SELECT * FROM
			(
			SELECT DISTINCT
			pl.IdUnidad, 
			CatUnidades.Codigo, 
			CatUnidades.Descripcion, 
			''POS'' + CAST(pl.NumeroPosicionLlanta AS VARCHAR(2)) AS NumeroPosicionLlanta,
			pl.IdEstatuLlanta as IdEstatus
			FROM  ProLlantasAuxiliar AS pl 
			INNER JOIN CatUnidades ON pl.IdUnidad = CatUnidades.IdUnidad
			INNER JOIN #ReporteEstatusActualDeLlantas ON CatUnidades.IdUnidad = #ReporteEstatusActualDeLlantas.IdUnidad
			WHERE	(pl.IdLlantaAuxiliar IN
						(	SELECT MAX(IdLlantaAuxiliar)
							FROM   (SELECT IdLlanta, IdLlantaAuxiliar
							FROM   ProLlantasAuxiliar
							WHERE (CAST(FechaHora AS DATE) <= @QueryFechaFinal)
							AND IdUnidad = pl.IdUnidad
							AND NumeroPosicionLlanta = pl.NumeroPosicionLlanta) AS tr
						)
					)'+
		   ' AND pl.IdEstatuLlanta IN ('+@Filtro+')'+ 
		   ' ) As TablaReporte_CTE	PIVOT (MAX(IdEstatus)  FOR NumeroPosicionLlanta IN ([POS1],[POS2],[POS3],[POS4],[POS5],[POS6],[POS7],[POS8],[POS9],[POS10],[POS11],[POS12],[POS13],[POS14],[POS15],[POS16])) PVT';
 ---AND pl.IdUnidad IN (SELECT IdUnidad FROM #ReporteEstatusActualDeLlantas) se cambio este filtro por la union con catunidades
 SET @Parametros = N'@QueryFechaFinal date';
 EXEC sp_executesql @SQL, @Parametros, @QueryFechaFinal = @FechaFinal

--si existe la tabla temporal se elimina
IF OBJECT_ID('tempdb.dbo.#ReporteEstatusActualDeLlantas') IS NOT NULL
BEGIN
	DROP TABLE #ReporteEstatusActualDeLlantas
END
go

