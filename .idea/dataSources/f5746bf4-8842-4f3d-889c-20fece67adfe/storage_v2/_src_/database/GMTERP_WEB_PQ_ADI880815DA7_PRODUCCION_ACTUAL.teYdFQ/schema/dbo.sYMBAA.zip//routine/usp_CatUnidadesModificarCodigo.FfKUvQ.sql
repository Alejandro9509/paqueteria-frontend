CREATE PROCEDURE [dbo].[usp_CatUnidadesModificarCodigo]
	@IdUnidad int,
	@Codigo varchar(16),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100),
	@IdTipoDeUnidad int
AS
DECLARE
	@IdentificadorUnidad int,
	@IdTipoUnidadOld int,
	@IdentificadorUnidadCompara int 
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdUnidad = 0
		RAISERROR(N'El identificador de la unidad es un campo requerido',
			16,
			1
			)
	
	--solicitud 11684,12131 se cambio la evaluacion para que solo considera hasta los segundos porque en el cambio
	--que se hizo en unidades en el mapa al asignar imagen a la unidad se esta grabando con todo y milesimas de segundo
	IF (SELECT CONVERT(smalldatetime,ModificadoEl) FROM CatUnidades WHERE IdUnidad= @IdUnidad) <> CONVERT(smalldatetime,@UltimaModificacion)
		RAISERROR(N'Los datos de esta unidad fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)	
	
	IF LTRIM(RTRIM(@Codigo)) = ''
		RAISERROR(N'El código de la unidad es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT Codigo FROM CatUnidades WHERE Codigo = @Codigo AND IdUnidad <> @IdUnidad)
		RAISERROR(N'El código de la unidad ya existe',
			16,
			1
			)


	SET @IdTipoUnidadOld = (Select IdTipoUnidad from CatUnidades Where IdUnidad = @IdUnidad)
	Set @IdentificadorUnidad = (Select Identificador from CatTiposUnidades where IdTipoUnidad = @IdTipoUnidadOld)
	Set @IdentificadorUnidadCompara = (Select Identificador from CatTiposUnidades where IdTipoUnidad = @IdTipoDeUnidad)
	IF @IdentificadorUnidad <> @IdentificadorUnidadCompara 
	RAISERROR(N'Solo se pueden modificar tipos de unidades iguales ',
		16,
		1
		)

	ALTER TABLE	CatUnidades DISABLE TRIGGER trg_CatUnidades	

	UPDATE CatUnidades SET 
	Codigo = @Codigo,
	ModificadoEl = @ModificadoEl,
	ModificadoPor = @ModificadoPor,
	IdTipoUnidad = @IdTipoDeUnidad
	WHERE IdUnidad = @IdUnidad	

	ALTER TABLE	CatUnidades ENABLE TRIGGER trg_CatUnidades	
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

