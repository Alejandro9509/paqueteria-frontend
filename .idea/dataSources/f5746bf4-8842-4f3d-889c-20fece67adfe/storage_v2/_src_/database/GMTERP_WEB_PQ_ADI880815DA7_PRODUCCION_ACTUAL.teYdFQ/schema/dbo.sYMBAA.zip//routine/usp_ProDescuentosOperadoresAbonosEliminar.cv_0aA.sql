CREATE PROCEDURE [dbo].[usp_ProDescuentosOperadoresAbonosEliminar]
	@IdAbonoDescuentoOperador int,
	@Abono money,
	@IdDescuentoOperador int,
	@IdPeticion varchar(100)

/*************************************************************************************************************************************
Procedimiento almacenado usp_ProDescuentosOperadoresAbonosEliminar

Parámetros: 
	@IdAbonoDescuentoOperador int	->(Entrada) Se Utiliza para saber cual Ebono es el que se va a eliminar de la tabla
	@IdDescuentoOperador int		->(Entrada) Se utiliza para tener relación con el catalogo de DescuentosOperadores y poder actualizar el campo de ImporteDescontado correspondiente al descuento del operador, a su vez con esta variable se puede saber la concurrencia del usuario 	
	@Abono money					->(Entrada) Se utiliza o se entiende como el Importe el cual se esta abonando sobre el descuento del operador
	@IdPeticion varchar(100)		->(Entrada) Se utiliza para saber la peticion del proceso en casi de que ocurra algun problema
	

Descripción: Elimina los datos de la tabla de abono segun los datos de entrada y actualiza la tabla CatDescuentosOperadores para cuadre de importes

Implementada por: Diego Arturo Rubio Meza
Fecha de implementación: 12/07/2019
Versión: V8 8.0.44.27

Modificada por:   Diego Arturo Rubio Meza
Fecha de modificación: 16/07/2019
Versión: V8 8.0.44.40

Invocada desde: ClsCatDescuentosOperadores
				Solicitud 12512
******************************************************************************************************************* */

AS
BEGIN TRY
	BEGIN TRANSACTION

		--Verifica que no haya sido Borrado con conterioridad o concurrencia el Descuento que se quiere modificar
		IF NOT EXISTS(SELECT * FROM ProDescuentosOperadoresAbonos WHERE IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador)
		Begin
		RAISERROR(N'Se detecto concurrencia de (abono, eliminación o modificación), favor de verificar e intentar nuevamente',
			16,
			1
			) 
		END

		DELETE FROM ProDescuentosOperadoresAbonos
		WHERE IdAbonoDescuentoOperador = @IdAbonoDescuentoOperador

		Update CatDescuentosOperadores
		SET ImporteDescontado = ImporteDescontado - @Abono
		Where IdDescuentoOperador = @IdDescuentoOperador
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

