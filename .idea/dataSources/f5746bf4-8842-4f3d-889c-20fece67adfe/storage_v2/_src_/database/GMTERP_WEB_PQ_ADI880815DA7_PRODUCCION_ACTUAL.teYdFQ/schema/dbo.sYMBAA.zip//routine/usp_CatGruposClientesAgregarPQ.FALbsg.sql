
CREATE PROCEDURE [dbo].[usp_CatGruposClientesAgregarPQ](
	@Codigo int,
	@Grupo varchar(50),
	@CreadoEl datetime,
	@CreadoPor int ,
	@ModificadoEl datetime,
	@ModificadoPor int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@Codigo,  0) <= 0 begin
			RAISERROR(N'*INICIO*El código del grupo es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		IF ISNULL(@Grupo, '') = '' begin
			RAISERROR(N'*INICIO*El nombre del Grupo es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		INSERT INTO CatGruposClientes(Codigo, Grupo,CreadoEl,CreadoPor,ModificadoEl,ModificadoPor)
		VALUES (@Codigo, @Grupo,@CreadoEl,@CreadoPor,@ModificadoEl,@ModificadoPor)
	IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

