
CREATE PROCEDURE [dbo].[usp_ProContenedorPortuarioSetNoticacion] 
@IdDetalleEntregaContenedores     int,
@FechaNotificacion                datetime,
@Operacion                        int,
@AtendidaPor                      int,
@Atendidaen                       datetime,
@Atendido                         bit,
@IdPeticion                       varchar(100)
/* *************************************************************************************************
Procedimiento usp_ProContenedorPortuarioSetNoticacion

Parámetros:
    @IdDetalleEntregaContenedores (entrada, int),
    @FechaNotificacion            (entrada, datetime),
    @Operacion                    (entrada, int),
    @AtendidaPor                  (entrada, int),
    @Atendidaen                   (entrada, fecha)
    @Atendido                     (entrada, bit)
	@IdPeticion varchar(100)	  (entrada, string). Id de la Petición, generada en WEBDEV 	

Descripción: El procedimeinto registra los datos de las diferentes notificaciones sobre los contenedores que corresponden. 
		 

Implementada por: José Luis Cisneros G.
Fecha de implementacion: 13/09/2019
Versión ERP: 8.0.46.15

Invocada desde:  (Solicitud 140)
***************************************************************************************************** */
AS
  DECLARE @FechaPrevia datetime

BEGIN TRY
	BEGIN TRANSACTION
  	
	IF ((@IdDetalleEntregaContenedores IS NULL) OR (@IdDetalleEntregaContenedores = 0))
		RAISERROR(N'No hay identificador del contenedor para la notificación.', 16, 1)

	IF ((@FechaNotificacion IS NULL) OR (@FechaNotificacion = 0))
		RAISERROR(N'La fecha de notificación es necesaria.', 16, 1)

	IF ((@Operacion  IS NULL) OR (@Operacion  = 0))
		RAISERROR(N'El indicador de la operación es necesario.', 16, 1)

    IF ((@Operacion = 4) OR (@Operacion = 5) OR (@Operacion = 6))
    BEGIN
      	IF ((@AtendidaPor  IS NULL) OR (@AtendidaPor  = 0))
		  RAISERROR(N'El indentificador de quien realiza la operación es necesario.', 16, 1) 

        IF ((@AtendidaPor  IS NULL) OR (@AtendidaPor  = 0)) 
		  RAISERROR(N'El indentificador de quien realiza la operación es necesario.', 16, 1) 

      	IF ((@Atendidaen  IS NULL) OR (@Atendidaen = 0))
		  RAISERROR(N'La fecha en la que fue atendida la notificaión es necesaria.', 16, 1) 
    END
    
    ---@Operacion = 1 registrar la fecha de la notificacion de arribo
    IF @Operacion = 1 
    BEGIN
        -- rescata el registro y si ya tiene fecha de notificacion lo deja como esta, solo si es null significa que es un aviso nuevo, estampa la fecha de notificación
        SELECT @FechaPrevia = FechaNotiArribo FROM ProDetalleEntregaContenedores WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores

        IF @FechaPrevia IS NULL
        BEGIN
            UPDATE ProDetalleEntregaContenedores
            SET [FechaNotiArribo] = @FechaNotificacion
            WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores
        END
    END

---@Operacion = 2 registrar la fecha de la notificacion de cita
    IF @Operacion = 2 
    BEGIN
        SELECT @FechaPrevia = FechaNotiCita FROM ProDetalleEntregaContenedores WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores

        IF @FechaPrevia IS NULL
        BEGIN
           UPDATE ProDetalleEntregaContenedores
           SET [FechaNotiCita] = @FechaNotificacion
           WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores  
        END
    END
---@Operacion = 3 registrar la fecha de la notificacion de vencimiento
    IF @Operacion = 3 
    BEGIN
        SELECT @FechaPrevia = FechaNotiLastFreeDate FROM ProDetalleEntregaContenedores WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores

        IF @FechaPrevia IS NULL
        BEGIN
            UPDATE ProDetalleEntregaContenedores
            SET [FechaNotiLastFreeDate] = @FechaNotificacion
            WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores 
        END
    END
---@Operacion = 4 registrar la atención de la notificacion de arribo
    IF @Operacion = 4 
    BEGIN
        UPDATE ProDetalleEntregaContenedores
        SET AtendidaenNotiArribo = @Atendidaen,
            AtendidaNotiArriboX  = @AtendidaPor,
            CheckNotiArribo      = @Atendido
        WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores       
    END
---@Operacion = 5 registrar la atención de la notificacion de cita
    IF @Operacion = 5 
    BEGIN
        UPDATE ProDetalleEntregaContenedores
        SET AtendidaenNotiCita = @Atendidaen,
            AtendidaNotiCitaX  = @AtendidaPor,
            CheckNotiCita      = @Atendido
        WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores        
    END
---@Operacion = 6 registrar la atención de la notificacion de vencimiento
    IF @Operacion = 6 
    BEGIN
        UPDATE ProDetalleEntregaContenedores
        SET AtendidaenNotiLastFreeDate = @Atendidaen,
            AtendidaNotiLastFreeDateX  = @AtendidaPor,
            CheckNotiLastFreeDate      = @Atendido
        WHERE IdDetalleEntregaContenedores = @IdDetalleEntregaContenedores        
    END

   	IF(@@TRANCOUNT > 0)
	  COMMIT
END TRY
BEGIN CATCH
   	IF(@@TRANCOUNT > 0)
	  ROLLBACK
	  	  
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

