CREATE PROCEDURE [dbo].[usp_CatTrazoLibreModificarPQ](
	@IdTrazoLibre int,
	@Latitud decimal(12,9),
	@Longitud decimal(12,9),
	@Descripcion varchar(400),
	@IdDetalle int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdTrazoLibre, 0) <= 0 begin
				RAISERROR(N'*INICIO*El Id de Trazo libre *FIN*', 16, 1)
							GOTO CANCELAR_TRANSACCION

				return;
			end
		IF ISNULL(@Latitud, 0) <= 0 begin
			RAISERROR(N'*INICIO*La Latitud es requerida*FIN*', 16, 1)
						GOTO CANCELAR_TRANSACCION

			return;
		end

		IF ISNULL(@Longitud, 0) <= 0 begin
			RAISERROR(N'*INICIO*La Longitud es requerida*FIN*', 16, 1)
						GOTO CANCELAR_TRANSACCION

			return;
		end
			IF ISNULL(@Descripcion, '') = '' begin
			RAISERROR(N'*INICIO*La descripcion es requerida*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
				IF ISNULL(@IdDetalle, '') = '' begin
			RAISERROR(N'*INICIO*El Id de detalle de rutas requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end


		
		
UPDATE CatTrazoLibrePQ SET Latitud=@Latitud , Longitud=@Longitud,Descripcion= @Descripcion,IdDetalleRuta=@IdDetalle where IdTrazoLibre=@IdTrazoLibre

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
go

