
CREATE PROCEDURE [dbo].[usp_ProContraRecibosClienteCancelar]
@IdContraReciboCliente int,
@CanceladoPor int,
@CanceladoEl datetime,
@IdPeticion varchar(100),
@MotivoCancelacion varchar(500)
AS
DECLARE 
	@EstatusPendPago int,
	@EstatusPagada int,
	@EstatusParcialmentePagada int,
	@EstatusCancelada int,
	@CantidadFacturasPagadas int
	
BEGIN TRY
	BEGIN TRANSACTION
	SET @EstatusPendPago = 0
	SET @EstatusParcialmentePagada = 1
	SET @EstatusPagada = 2
	SET @EstatusCancelada = 3

	IF ISNULL(@IdContraReciboCliente,0)= 0
		RAISERROR(N'El identificador de contra recibo es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Folio FROM ProContraRecibosCliente WHERE IdContraReciboCliente = @IdContraReciboCliente AND CanceladoEl IS NOT NULL)
		RAISERROR(N'El contra recibo de cliente ya fue cancelada por otro usuario, revise la información',
			16,
			1
			)
				
	IF EXISTS(SELECT Folio FROM ProContraRecibosCliente WHERE IdContraReciboCliente = @IdContraReciboCliente AND Estatus =@EstatusParcialmentePagada )
		RAISERROR(N'El contra recibo de cliente ya fue parcialmente pagada por otro usuario, revise la información',
			16,
			1
			)

	IF EXISTS(SELECT Folio FROM ProContraRecibosCliente WHERE IdContraReciboCliente = @IdContraReciboCliente AND Estatus =@EstatusPagada)
		RAISERROR(N'El contra recibo de cliente ya fue pagada por otro usuario, revise la información',
			16,
			1
			)	
						
	UPDATE ProContraRecibosCliente SET 
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		MotivoCancelacion = @MotivoCancelacion,
		Estatus =@EstatusCancelada
	WHERE IdContraReciboCliente = @IdContraReciboCliente

	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

