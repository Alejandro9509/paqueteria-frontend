CREATE PROCEDURE [dbo].[usp_ProNominasActualizarIdCertificado]
@IdNominaRecibo int,
@IdPeticion varchar(100),
@IdCertificado int
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	If @IdCertificado = 0
		SET @IdCertificado = NULL
		
		UPDATE ProNominasRecibo
		SET IdCertificado = @IdCertificado
		WHERE IdNominaRecibo = @IdNominaRecibo
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

