

CREATE PROCEDURE [dbo].[usp_ProViajePQAgregar](	
	@TipoCobro int,
	@FechaHora datetime,
	@NoViajeCliente varchar(30) ,
	@IdCliente int,
	@IdSucursal int,
	@IdRemitente int,
	@IdDestinatario int,
	@IdMoneda int,
	@GeneradoDesde int,
	@FechaEstatus datetime,
	@IdEstatusViaje int,
	@Secuencia int,
	@Origen int,
	@Destino int,
	@Kilometros int,
	@Horas decimal(15,2),
	@IdConcepto int,
	@Importe  decimal(20,6),
	@Viaje int
	--@IdGuia int
	

	)
AS
BEGIN
	BEGIN TRANSACTION
		
		DECLARE @FOLIO int;
		DECLARE @FOLIOSTR varchar(10);	
	DECLARE @FechaRegistroDate date;
	DECLARE @HoraRegistroTime time;
		DECLARE @TRACKINGSTR varchar(10);
		IF ISNULL(@IdSucursal, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de sucursal es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@NoViajeCliente, '') = '' begin
			RAISERROR(N'*INICIO*El numero de viaje cliente es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@IdEstatusViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus del viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@FechaHora, '') = '' begin
			RAISERROR(N'*INICIO*La fecha de registro es campo requerido *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
	

		

		
		
	insert into ProViajes(TipoCobroPorViaje, FechaHora, NoViajeCliente, IdCliente, IdSucursal, IdRemitente, IdDestinatario, IdMoneda, GeneradoDesde, Kilometros,
	FechaHoraEstatuViaje, IdEstatuViaje, Viaje) values
	(
	@TipoCobro ,
	@FechaHora ,
	@NoViajeCliente,
	@IdCliente,
	@IdSucursal,
	@IdRemitente,
	@IdDestinatario,
	@IdMoneda,
	@GeneradoDesde,
	@Kilometros,
	@FechaEstatus,
	@IdEstatusViaje,
	@Viaje
	--@IdGuia

	);
		IF @@TRANCOUNT > 0
			BEGIN
			Declare @id int
			SET @id= @@IDENTITY

			insert into ProViajesTrayectos (IdViaje,Secuencia,IdOrigen,IdDestino,Kilometros,Horas) values (@id,@Secuencia,@Origen,@Destino,@Kilometros,@Horas)					
	
	--insert into ProViajesConceptosFacturacion(IdViaje, IdConceptoFacturacion, Importe) 
--values(@id,@IdConcepto,@Importe)


				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

