Create PROCEDURE [dbo].[usp_CatConceptosCobranzaModificar]
	@IdConceptocobranza int,
	@Codigo int,
	@ConceptoCobranza varchar(50),
	@TipoConcepto tinyint,
	@Activo bit,
	@RequiereCtaBancaria bit,   
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)
AS

BEGIN TRY
	BEGIN TRANSACTION	
	
	IF (SELECT ModificadoEl FROM CatConceptosCobranza WHERE IdConceptoCobranza = @IdConceptocobranza) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)	

	IF @Codigo =0
		RAISERROR(N'El codigo es un campo requerido',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@ConceptoCobranza)) = ''
		RAISERROR(N'El concepto de cobranza es un campo requerido',
			16,
			1
			)
			
	UPDATE CatConceptosCobranza SET
		Codigo = @Codigo,
		ConceptoCobranza = @ConceptoCobranza,
		TipoConcepto = @TipoConcepto,
		Activo = @Activo,
		RequiereCtaBancaria = @RequiereCtaBancaria,		
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl
	WHERE IdConceptoCobranza = @IdConceptocobranza
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

