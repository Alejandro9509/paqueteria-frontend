
CREATE PROCEDURE [dbo].[usp_CatPuestosModificarPQ](
	@IdPuesto INT,
	@Codigo VARCHAR(3),
	@Puesto VARCHAR(50),
	@ModificadoEl DATETIME,
	@ModificadoPor INT)
AS
BEGIN 
	BEGIN TRANSACTION

		IF ISNULL(@IdPuesto, 0) <= 0 begin
			RAISERROR(N'*INICIO*El Identificador del Puesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF ISNULL(@Codigo, '') = '' begin
			RAISERROR(N'*INICIO*El código del Puesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		IF ISNULL(@Puesto, '') = '' begin
			RAISERROR(N'*INICIO*El puesto es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		
		UPDATE CatPuestos SET
		Codigo = @Codigo,
		Puesto = @Puesto,
		ModificadoEl = @ModificadoEl,
		ModificadoPor =@ModificadoPor
		WHERE IdPuesto = @IdPuesto
		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

