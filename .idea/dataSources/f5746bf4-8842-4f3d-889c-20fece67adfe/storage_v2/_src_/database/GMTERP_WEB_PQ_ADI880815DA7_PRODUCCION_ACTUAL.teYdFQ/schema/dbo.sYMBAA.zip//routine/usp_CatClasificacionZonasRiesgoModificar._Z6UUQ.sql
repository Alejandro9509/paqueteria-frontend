create PROCEDURE [dbo].[usp_CatClasificacionZonasRiesgoModificar]
@IdClasificacionZonaRiesgo int,
@Codigo int,
@Descripcion varchar(100),
@ModificadoEl datetime,
@ModificadoPor int,
@UltimaModificacion datetime,
@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@Codigo,0)= 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)

	IF ISNULL(@Descripcion,'')= ''
		RAISERROR(N'La Descripción de la zona de riesgo es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT Codigo FROM CatClasificacionZonasRiesgo WHERE Codigo = @Codigo AND IdClasificacionZonaRiesgo <> @IdClasificacionZonaRiesgo)
		RAISERROR(N'El código de la zona de riesgo ya existe',
			16,
			1
			)			
	IF ISNULL(@IdClasificacionZonaRiesgo,0)= 0
	RAISERROR(N'El identificador de la zona de riesgo es un campo requerido',
			16,
			1
			)		
			
	IF (SELECT ModificadoEl FROM CatClasificacionZonasRiesgo WHERE IdClasificacionZonaRiesgo = @IdClasificacionZonaRiesgo) <> @UltimaModificacion
		RAISERROR(N'Los datos de esta clasificación de zona de riesgo fueron modificados por otro usuario. salga sin grabar sus cambios y entre en modo de consulta para que revise.',
			16,
			1
			)			
			
			
	UPDATE CatClasificacionZonasRiesgo SET
			Codigo= @Codigo,
			Descripcion= @Descripcion,
			ModificadoEl= @ModificadoEl,
			ModificadoPor= @ModificadoPor
	WHERE 	IdClasificacionZonaRiesgo=@IdClasificacionZonaRiesgo

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

