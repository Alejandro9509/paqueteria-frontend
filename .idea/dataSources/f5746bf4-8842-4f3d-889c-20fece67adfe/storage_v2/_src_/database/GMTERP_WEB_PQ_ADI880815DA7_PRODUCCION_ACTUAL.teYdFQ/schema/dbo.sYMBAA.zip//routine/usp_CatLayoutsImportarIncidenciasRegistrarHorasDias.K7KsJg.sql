CREATE PROCEDURE [dbo].[usp_CatLayoutsImportarIncidenciasRegistrarHorasDias]
	@IdPeticion VARCHAR(100),
	@xmlIncedenciaValor NTEXT,    --	@Codigo INT, --@Incidencia int, 	@Valor decimal(5,2), @Estado VARCHAR(40), @fechaHora datetime	
	@FechaHoraJuntas bit,
	@ModificadoPor INT,
	@ModificadoEl DATETIME,
	@IdPeriodo INT 

AS
DECLARE 
	@HorasTurno DECIMAL(15,2),
	@HorasAcumuladas DECIMAL(15,2),
	@docHandle INT,
	@IdTipoIncidenciaCursor INT,	
	@ValorCursorDias INT,
	@IdNominaDiaHoraCursor INT,	
	@ContadorDias INT,	
	@SeguirAgregando BIT,
	@IdPeriodoActual INT,
	@CadenaHorasTurno VARCHAR(10),
	@IdEmpleado int,
	@IdTipoIncidencia int,
	@CodigoCursor int,
	@IncidenciaCursor int,
	@ValorCursor DECIMAL(5,2),
	@EstadoCursor VARCHAR(40),
	@TipoIncidencia int ,
	@Fecha Date,
	@FechaHora Datetime,
	@CadenaFecha varchar(15)
	
BEGIN TRY
 BEGIN TRANSACTION
 
 	IF @IdPeriodo = 0
		RAISERROR(N'El periodo es un campo requerido',
			16,
			1
			)

		SET @ContadorDias = 0
		SET @SeguirAgregando = 1
		SET @HorasAcumuladas = 0
		SET @IdNominaDiaHoraCursor = 0
		
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @xmlIncedenciaValor
			
			SELECT Codigo, Incidencias, Valor, Estado, FechaHora
			INTO #TempProNominasDiasHoras
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_MovimientosIncidencias',2) 
			WITH (Codigo INT, Incidencias INT, Valor DECIMAL(15,2),Estado VARCHAR (40), FechaHora Datetime)	

			EXEC sp_xml_removedocument @docHandle
			
			DECLARE ProNominasDiasHorasCursor CURSOR FOR
			SELECT * FROM #TempProNominasDiasHoras
			OPEN ProNominasDiasHorasCursor
			FETCH NEXT FROM ProNominasDiasHorasCursor
			INTO @CodigoCursor, @IncidenciaCursor, @ValorCursor, @EstadoCursor, @FechaHora
			WHILE @@FETCH_STATUS = 0
			BEGIN	
			    set @Fecha = CONVERT(date,@FechaHora)						    
				SET @IdEmpleado = ( Select IdEmpleado from CatEmpleados where Codigo = @CodigoCursor )
				SET @IdTipoIncidencia = @IncidenciaCursor
				SET @TipoIncidencia = (Select TipoIncidencia From CatTiposIncidencias where IdTipoIncidencia = @IncidenciaCursor)
				
				IF @TipoIncidencia = 1 --Dias 
				BEGIN 		
				    SET @ContadorDias =0		
					SET @ValorCursorDias = @ValorCursor
					WHILE @ContadorDias < @ValorCursorDias
					BEGIN
					
						IF  EXISTS(SELECT IdNominaDiaHora FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado)
						BEGIN 
							SET @CadenaFecha = CONVERT(varchar,@Fecha,103)
							RAISERROR(N'Ya existe una incidencia registrada en la fecha %s.',
							16,
							1,
							@CadenaFecha
							)
						END	
						
						IF  @SeguirAgregando = 1
						BEGIN		
						
							--SET @IdPeriodoActual = (SELECT ISNULL(IdPeriodo,-1) FROM CatPeriodos AS cp 
							--INNER JOIN CatEmpleados AS ce on cp.IdTipoPeriodo = ce.IdTipoPeriodo
							--WHERE cp.FechaInicio <= DATEADD(DAY,@ContadorDias,@Fecha) AND cp.FechaFin >= DATEADD(DAY,@ContadorDias,@Fecha) AND ce.IdEmpleado = @IdEmpleado)
							
							IF @IdPeriodo <> -1 
							BEGIN
							
								IF @IdNominaDiaHoraCursor = 0 OR @ContadorDias > 0
								BEGIN
								declare @fechastring varchar(30);
								set @fechastring =  convert(date,@ModificadoEl)
								
									IF  EXISTS(SELECT * FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado) AND @ContadorDias =0
									BEGIN 
										DELETE FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado
									END 									
									INSERT INTO ProNominasDiasHoras (IdEmpleado,IdPeriodo,IdTipoIncidencia,Fecha,Valor,Estado,CreadoPor,CreadoEl) 
									VALUES(@IdEmpleado,@IdPeriodo,@IdTipoIncidencia,@Fecha,@ValorCursor,@EstadoCursor,@ModificadoPor,@ModificadoEl)												
									--VALUES(@IdEmpleado,@IdPeriodo,@IdTipoIncidenciaCursor,DATEADD(DAY,@ContadorDias,@Fecha),1,@EstadoCursor,@ModificadoPor,@ModificadoEl)																		
									
								END
								ELSE
								BEGIN
									UPDATE ProNominasDiasHoras 
									SET	
									IdTipoIncidencia = @IdTipoIncidenciaCursor,
									Estado = @EstadoCursor,
									ModificadoPor = @ModificadoPor,
									ModificadoEl = @ModificadoEl
									WHERE IdNominaDiaHora = @IdNominaDiaHoraCursor  
								END
							END
						END	--@SeguirAgregando = 1				
					SET @ContadorDias = @ContadorDias + 1
					END	-- @ContadorDias								
				END --TIPOINCIDENCIA =1
				
				IF @TipoIncidencia = 2 --Horas				
				BEGIN
				    SET @HorasAcumuladas = isnull((Select sum(Valor) from ProNominasDiasHoras 					
					where IdEmpleado = @IdEmpleado and 
					Fecha = @Fecha ),0)  
					IF  EXISTS(SELECT pnh.IdNominaDiaHora FROM ProNominasDiasHoras pnh 
							   inner join CatTiposIncidencias cti on cti.IdTipoIncidencia = pnh.IdTipoIncidencia 
							   WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado 
							   and cti.TipoIncidencia = 1							   
							   )
						BEGIN 
							SET @CadenaFecha = CONVERT(varchar,@Fecha,103)
							RAISERROR(N'Ya existe una incidencia registrada en la fecha %s.',
							16,
							1,
							@CadenaFecha
							)
						END	 

			        SET @IdNominaDiaHoraCursor=0
					SET @HorasAcumuladas = @HorasAcumuladas + @ValorCursor
					SET @HorasTurno = (SELECT ISNULL(ct.Horas,0) FROM CatEmpleados AS ce INNER JOIN CatTurnos AS ct ON ce.IdTurno = ct.IdTurno WHERE ce.IdEmpleado = @IdEmpleado)
					IF @HorasAcumuladas <=  @HorasTurno
					BEGIN
						IF @IdNominaDiaHoraCursor <> 0 
						BEGIN
							UPDATE ProNominasDiasHoras 
							SET	IdTipoIncidencia = @IdTipoIncidenciaCursor,
							Valor = @ValorCursor,
							Estado = @EstadoCursor,
							ModificadoPor = @ModificadoPor,
							ModificadoEl = @ModificadoEl
							WHERE IdNominaDiaHora = @IdNominaDiaHoraCursor 
						END
						ELSE
						BEGIN							
							--SET @IdPeriodoActual = (SELECT ISNULL(IdPeriodo,-1) FROM CatPeriodos AS cp 
							--INNER JOIN CatEmpleados AS ce on cp.IdTipoPeriodo = ce.IdTipoPeriodo
							--WHERE cp.FechaInicio <= @Fecha AND cp.FechaFin >= @Fecha AND ce.IdEmpleado = @IdEmpleado )						    
							INSERT INTO ProNominasDiasHoras (IdEmpleado,IdPeriodo,IdTipoIncidencia,Fecha,Valor,Estado,CreadoPor,CreadoEl) 
							VALUES(@IdEmpleado,@IdPeriodo,@IdTipoIncidencia,@Fecha,@ValorCursor,@EstadoCursor,@ModificadoPor,@ModificadoEl)												
						
						END
					END
					ELSE 
					BEGIN
						SET @CadenaHorasTurno = convert(varchar, @HorasTurno)
						RAISERROR(N'El Total de Horas del Turno del Empleado son de %s Horas.',
						16,
						1,
						@CadenaHorasTurno
						)
					END
				END --TIPOINCIDENCIA =2
				IF @TipoIncidencia = 3 --DESTAJOS
				BEGIN
					IF  EXISTS(SELECT pnh.IdNominaDiaHora FROM ProNominasDiasHoras pnh 
							   inner join CatTiposIncidencias cti on cti.IdTipoIncidencia = pnh.IdTipoIncidencia 
							   WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado 
							   and cti.TipoIncidencia = 1							   
							   )
						BEGIN 
							SET @CadenaFecha = CONVERT(varchar,@Fecha,103)
							RAISERROR(N'Ya existe una incidencia registrada en la fecha %s.',
							16,
							1,
							@CadenaFecha
							)
						END	 

					SET @HorasAcumuladas = @HorasAcumuladas + @ValorCursor
					IF 24 >= @HorasAcumuladas  		
					BEGIN
						IF @IdNominaDiaHoraCursor <> 0 
						BEGIN
							UPDATE ProNominasDiasHoras 
							SET	IdTipoIncidencia = @IdTipoIncidenciaCursor,
							Valor = @ValorCursor,	
							Estado = @EstadoCursor,
							ModificadoPor = @ModificadoPor,
							ModificadoEl = @ModificadoEl
							WHERE IdNominaDiaHora = @IdNominaDiaHoraCursor  
						END
						ELSE
						BEGIN
							--SET @IdPeriodoActual = (SELECT ISNULL(IdPeriodo,-1) FROM CatPeriodos AS cp 
							--INNER JOIN CatEmpleados AS ce on cp.IdTipoPeriodo = ce.IdTipoPeriodo
							--WHERE cp.FechaInicio <= @Fecha AND cp.FechaFin >= @Fecha AND ce.IdEmpleado = @IdEmpleado )
							INSERT INTO ProNominasDiasHoras (IdEmpleado,IdPeriodo,IdTipoIncidencia,Fecha,Valor,Estado,CreadoPor,CreadoEl) 
							VALUES(@IdEmpleado,@IdPeriodo,@IdTipoIncidenciaCursor,@Fecha,@ValorCursor,@EstadoCursor,@ModificadoPor,@ModificadoEl)					
						END
					END
					ELSE 
					BEGIN						
						RAISERROR(N'Sobrepaso las Horas de las Incidencias Tipo Destajo que son 24 horas.',
						16,
						1
						)
					END		
				END -- TIPOINCIDENCIA =3

				FETCH NEXT FROM ProNominasDiasHorasCursor
				INTO @CodigoCursor, @IncidenciaCursor, @ValorCursor, @EstadoCursor, @FechaHora

			
			END --WHILE @@FETCH
			CLOSE ProNominasDiasHorasCursor
			DEALLOCATE ProNominasDiasHorasCursor

			--ESTO SE HACE CUANDO SE ENVIA POR EMPLEADO

			--Se  Borran todas aquellas incidencias que no se agregaron o modificaron por fecha y empleado
		--	IF @TipoIncidencia = 2 OR @TipoIncidencia = 3
		--	BEGIN
		--		DELETE FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		--	END
		--END
		--ELSE
		--BEGIN
		--	DELETE FROM ProNominasDiasHoras WHERE Fecha = @Fecha AND IdEmpleado = @IdEmpleado AND (ModificadoEl <> @ModificadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @ModificadoEl
		--END

		--UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo


 COMMIT --BEGIN TRY
END TRY  

BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

