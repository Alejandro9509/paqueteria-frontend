
CREATE PROCEDURE [dbo].[usp_ProMovimientosAlmacenTraspasosCancelar]
@IdMovimientoAlmacen int,
@IdMovimientoAlmacenTraspaso int,
@IdTipoMovimientoAlmacenSalida int,
@IdTipoMovimientoAlmacenEntrada int,
@MotivoCancelacion varchar(500),
@CanceladoEl datetime,
@CanceladoPor int,
@IdPeticion varchar(100),
@UltimaModificacion datetime,
@Folio int
 	/* *************************************************************************************************
	SOLICITUD 171

	Descripcion: se creo el procedimiento Almacenado

	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 25/09/2019
	Versión: Versión 8.0.46.21

	Invocada desde: <PAGE_ProMovimientosAlmacenTraspasosCancelar>
	************************************************************************************************ */
AS
DECLARE
@EsTraspaso bit = 1,
@return_value int
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdMovimientoAlmacen,0) = 0
		RAISERROR(N'El identificador del movimiento de almacén es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@MotivoCancelacion,'')='' 
			RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)	
	
	IF ISDATE(@CanceladoEl)=0 
			RAISERROR(N'La fecha de cancelación es un campo requerido',
			16,
			1
			)	
	
	IF (SELECT ModificadoEl FROM ProMovimientosAlmacen WHERE IdMovimientoAlmacen= @IdMovimientoAlmacen) <> @UltimaModificacion
			RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)

	IF EXISTS(SELECT Folio FROM ProMovimientosAlmacen WHERE Folio = @Folio)
			RAISERROR(N'No se puede cancelar este movimiento de traspaso ya que otro usuario está intentando realizar el mismo proceso, favor de validar e intente de nuevo.',
			16,
			1
			)
					

	-- GENERA CANCELACION SALIDA
	SET @IdMovimientoAlmacen = (SELECT IdMovimientoAlmacenSalida FROM ProMovimientosAlmacenTraspasos WHERE IdMovimientoAlmacenTraspaso = @IdMovimientoAlmacenTraspaso)

	 EXEC @return_value = usp_ProMovimientosAlmacenSalidaCancelar 
						@IdMovimientoAlmacen,
						@MotivoCancelacion,
						@IdTipoMovimientoAlmacenSalida,
						@CanceladoEl,
						@CanceladoPor,
						@IdPeticion,
						@UltimaModificacion,
						@EsTraspaso

			 IF @return_value <> 0
					RAISERROR(N'Ocurrió un error al cancelar la salida',
							16,
							1
							)
							
	--GENERA CANCELACION DE ENTRADA
	SET @IdMovimientoAlmacen = (SELECT IdMovimientoAlmacenEntrada FROM ProMovimientosAlmacenTraspasos WHERE IdMovimientoAlmacenTraspaso = @IdMovimientoAlmacenTraspaso)

	 EXEC @return_value = usp_ProMovimientosAlmacenCancelar 
						@IdMovimientoAlmacen,
						@MotivoCancelacion,
						@CanceladoEl,
						@CanceladoPor,
						@IdPeticion,
						@UltimaModificacion,
						@EsTraspaso

			 IF @return_value <> 0
					RAISERROR(N'Ocurrió un error al cancelar la salida',
							16,
							1
							)		

		UPDATE ProMovimientosAlmacenTraspasos set MotivoCancelacion = @MotivoCancelacion, CanceladoEl = @CanceladoEl, CanceladoPor = @CanceladoPor WHERE IdMovimientoAlmacenTraspaso = @IdMovimientoAlmacenTraspaso
	

 COMMIT  
END TRY  
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
	  ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

