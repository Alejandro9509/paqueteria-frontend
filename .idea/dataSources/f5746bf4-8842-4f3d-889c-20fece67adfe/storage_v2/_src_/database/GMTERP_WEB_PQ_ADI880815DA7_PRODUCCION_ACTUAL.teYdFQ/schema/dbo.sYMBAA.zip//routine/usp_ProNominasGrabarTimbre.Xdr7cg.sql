CREATE PROCEDURE [dbo].[usp_ProNominasGrabarTimbre]
	@IdNominaRecibo int,
	@CadenaOriginal ntext,
	@SelloDigital ntext, 
	@XMLArchivo ntext,
	@FolioFiscalUUID varchar(36),
	@FechaTimbrado datetime,
	@NoSerieCertificadoSAT varchar(20),
	@SelloSAT ntext,
	@CadenaOriginalTimbrado ntext,
	@TimbrePruebas bit,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
	--SE ACTUALIZA LA INFORMACION DEL TIMBRADO EN LA TABLA 'ProNominasRecibo' DE DICHO RECIBO 
	
	UPDATE ProNominasRecibo
	SET FolioFiscalUUID = @FolioFiscalUUID,
		FechaTimbrado = @FechaTimbrado,
		NoSerieCertificadoSAT = @NoSerieCertificadoSAT,
		SelloSAT = @SelloSAT,
		CadenaOriginalTimbrado = @CadenaOriginalTimbrado,
		XMLArchivo = @XMLArchivo,
		TimbrePruebas = @TimbrePruebas,
		CadenaOriginal = @CadenaOriginal,
		SelloDigital = @SelloDigital
	WHERE IdNominaRecibo = @IdNominaRecibo
	
	UPDATE ProNominasReciboCancelacion
	SET FolioFiscalUUIDSustitucion = @FolioFiscalUUID
	WHERE IdNominaRecibo = @IdNominaRecibo AND FolioFiscalUUIDSustitucion IS NULL

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

