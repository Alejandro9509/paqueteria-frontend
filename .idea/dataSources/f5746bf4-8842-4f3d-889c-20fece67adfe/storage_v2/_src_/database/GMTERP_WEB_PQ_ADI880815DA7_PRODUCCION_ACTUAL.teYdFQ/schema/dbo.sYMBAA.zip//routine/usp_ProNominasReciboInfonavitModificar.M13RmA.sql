CREATE PROCEDURE [dbo].[usp_ProNominasReciboInfonavitModificar]
	@IdNominaReciboInfonavit int,
	@NumeroCredito varchar(40),
	@Descripcion varchar(40),
	@IdConceptoInfonavit int,
	@IdConceptoSeguro int,
	@IdConceptoPDOFijoInfonavit int,
	@IdConceptoPDOFijoSeguro int,
	@IdEmpleado int,
	@Activo bit,
	@TipoCaptura int,
	@TipoCredito int,
	@FechaInicioAplicacion datetime,
	@FechaRegistro datetime,
	@Importe money,
	@VecesAplicado int,
	@ModificadoPor int,
	@ModificadoEl datetime,	
	@IdPeticion varchar(100),
	@IdPeriodo int
AS
DECLARE
@NumeroConcepto int = 0,
@DescripcionConcepto varchar(40),
@IdConceptoPDOFijo int =0,
@ImporteValor int = 1,
@Valor decimal(7,2) = 0
BEGIN TRY
	BEGIN TRANSACTION
	--Sección de validaciones
		
		IF ISNULL(@NumeroCredito,'') = ''
		   RAISERROR(N'El numero de credito es un campo requerido',
				16,
				1
				)
		
		IF @Descripcion = ''
			RAISERROR(N'La descripción es un campo requerido',
				16,
				1
				)

		IF isnull(@FechaInicioAplicacion, '') = ''
			RAISERROR(N'La fecha de inicio de aplicación es un campo requerido',
				16,
				1
				)	
		IF @TipoCaptura = 1
		BEGIN
			IF ISNULL(@IdConceptoInfonavit,0) = 0
			RAISERROR(N'El concepto de infonavit es un campo requerido',
				16,
				1
				)
			IF ISNULL(@IdConceptoSeguro,0) = 0
			RAISERROR(N'El concepto de seguro es un campo requerido',
				16,
				1
				)
		END
		ELSE
		BEGIN
			IF ISNULL(@IdConceptoInfonavit,0) = 0
				RAISERROR(N'El concepto de infonavit es un campo requerido',
					16,
					1
					)
		END
	
	--Validacion para eliminar el concepto de seguro de CatConceptosPDOFijos
	IF @TipoCaptura <> 1 AND @IdConceptoPDOFijoSeguro <> 0
	BEGIN

	 	IF EXISTS(SELECT IdConceptoPDOFijo FROM ProNominasReciboConceptos WHERE IdConceptoPDOFijo=@IdConceptoPDOFijoSeguro )
	RAISERROR(N'No es posible eliminar el concepto SEGURO DE VIVIENDA del infonavit, porque ya se asoció al recibo. ',
			16,
			1	
			)

	 DELETE FROM CatConceptosPDOFijos WHERE IdConceptoPDOFijo = @IdConceptoPDOFijoSeguro
	 SET @IdConceptoPDOFijoSeguro = NULL
	 SET @IdConceptoSeguro = NULL
	END

	UPDATE ProNominasReciboInfonavit SET 
	IdConceptoPDOFijoSeguro = @IdConceptoPDOFijoSeguro,
	IdConceptoInfonavit = @IdConceptoInfonavit,
	IdConceptoSeguro = @IdConceptoSeguro,
	Descripcion = @Descripcion,
	Activo = @Activo,
	FechaInicioAplicacion = @FechaInicioAplicacion,
	FechaRegistro = @FechaRegistro,
	TipoCaptura = @TipoCaptura,
	TipoCredito = @TipoCredito,
	Importe = @Importe,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl
	WHERE IdNominaReciboInfonavit = @IdNominaReciboInfonavit

	IF @TipoCredito <> 1 
	BEGIN
		SET @ImporteValor  = 2
		SET @Valor  = @Importe
		SET @Importe = 0
	END

	--Sección para modificar en CatConceptosPDOFijos
	IF ISNULL(@IdConceptoInfonavit,0) <> 0 AND ISNULL(@IdConceptoPDOFijoInfonavit,0) <> 0
	BEGIN
	
	SET @NumeroConcepto = (SELECT NumeroConcepto FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoInfonavit)
    SET @DescripcionConcepto = (SELECT Descripcion FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoInfonavit)
	
	UPDATE CatConceptosPDOFijos SET
	Descripcion =  @Descripcion,
	IdConceptoPDO =  @IdConceptoInfonavit,
	FechaInicioAplicacion = @FechaInicioAplicacion,
	FechaRegistro = @FechaRegistro ,
	Activo = @Activo,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	Importe = @Importe,
	NumeroConcepto = @NumeroConcepto,
	DescripcionConcepto = @DescripcionConcepto,
	ImporteValor = @ImporteValor,
	Valor = @Valor
	WHERE IdConceptoPDOFijo = @IdConceptoPDOFijoInfonavit
	END

	IF ISNULL(@IdConceptoSeguro,0) <> 0 AND ISNULL(@IdConceptoPDOFijoSeguro,0) = 0
	BEGIN
	
	SET @NumeroConcepto = (SELECT NumeroConcepto FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoSeguro)
    SET @DescripcionConcepto = (SELECT Descripcion FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoSeguro)
	
	INSERT INTO CatConceptosPDOFijos(Descripcion,IdConceptoPDO,FechaInicioAplicacion,
	VecesAplicado,MontoAcumulado,FechaRegistro,Activo,CreadoPor,
	CreadoEl,Importe,TipoConcepto,NumeroConcepto,DescripcionConcepto,IdEmpleado,NumeroControl,IdNominaReciboInfonavit,VecesAplicar,MontoLimite,ImporteValor,Valor)
	VALUES('SEGURO VIVIENDA',@IdConceptoSeguro,@FechaInicioAplicacion,
	@VecesAplicado,0,@FechaRegistro,@Activo,@ModificadoPor,
	@ModificadoEl,0,2,@NumeroConcepto,@DescripcionConcepto,@IdEmpleado,0,@IdNominaReciboInfonavit,9999,9999999,2,0)
	
	SET @IdConceptoPDOFijo  = (SELECT IDENT_CURRENT('CatConceptosPDOFijos'))
	UPDATE ProNominasReciboInfonavit SET IdConceptoPDOFijoSeguro = @IdConceptoPDOFijo WHERE IdNominaReciboInfonavit =@IdNominaReciboInfonavit 
	
	END


	IF ISNULL(@IdConceptoSeguro,0) <> 0 AND ISNULL(@IdConceptoPDOFijoSeguro,0) <> 0
	BEGIN
	
	SET @NumeroConcepto = (SELECT NumeroConcepto FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoSeguro)
    SET @DescripcionConcepto = (SELECT Descripcion FROM CatConceptosPDO WHERE IdConceptoPDO = @IdConceptoSeguro)
	
	UPDATE CatConceptosPDOFijos SET 
	Descripcion = 'SEGURO VIVIENDA',
	IdConceptoPDO = @IdConceptoSeguro,
	FechaInicioAplicacion = @FechaInicioAplicacion,
	FechaRegistro = @FechaRegistro,
	Activo = @Activo,
	ModificadoPor = @ModificadoPor,
	ModificadoEl = @ModificadoEl,
	NumeroConcepto = @NumeroConcepto,
	DescripcionConcepto = @DescripcionConcepto
	WHERE IdConceptoPDOFijo = @IdConceptoPDOFijoSeguro
	END

	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	COMMIT
END TRY
BEGIN CATCH	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

