CREATE PROCEDURE [dbo].[usp_ProComprasMaxFolioDocumento]    
	AS    
	Select ISNULL(MAX(FolioDocumento),0)+1 AS FolioDocumento from ProCompras where SerieDocumento='SIN SERIE'
go

