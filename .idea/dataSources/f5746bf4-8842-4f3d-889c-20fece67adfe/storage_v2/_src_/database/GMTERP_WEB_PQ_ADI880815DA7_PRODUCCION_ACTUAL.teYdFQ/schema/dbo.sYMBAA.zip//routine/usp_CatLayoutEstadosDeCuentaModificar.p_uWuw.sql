CREATE PROCEDURE [dbo].[usp_CatLayoutEstadosDeCuentaModificar]
	@IdLayoutEstadoCuenta int,
	@Codigo int,
	@Descripcion varchar(150),
	@TipoFormato tinyint,
	@RenglonInicial tinyint,
	@Separador Varchar(5),
	@ColumnaCheque tinyint,
	@ColumnaFecha tinyint,
	@FormatoFecha varchar(20),
	@ColumnaReferencia tinyint,
	@ColumnaDeposito tinyint,
	@ColumnaRetiro tinyint,
	@ModificadoEl	datetime,
	@ModificadoPor	int,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdLayoutEstadoCuenta,0) = 0
			RAISERROR(N'El id del layout es un campo requerido',
				16,
				1
				)
		IF ISNULL(@Codigo,0) = 0
			RAISERROR(N'El código del layout es un campo requerido',
				16,
				1
				)
		IF exists(Select * from CatLayoutEstadosDeCuenta Where Codigo = @Codigo and IdLayoutEstadoCuenta <> @IdLayoutEstadoCuenta)
			RAISERROR(N'El código del layout ya existe',
				16,
				1
				)
		IF LTRIM(RTRIM(@Descripcion)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)

				UPDATE CatLayoutEstadosDeCuenta
				SET Codigo=@Codigo,
				Descripcion=@Descripcion,
				TipoFormato=@TipoFormato,
				RenglonInicial=@RenglonInicial,
				Separador=@Separador,
				ColumnaCheque=@ColumnaCheque,
				ColumnaFecha=@ColumnaFecha,
				FormatoFecha=@FormatoFecha,
				ColumnaReferencia = @ColumnaReferencia,
				ColumnaDeposito=@ColumnaDeposito,
				ColumnaRetiro=@ColumnaRetiro,
				ModificadoEl=@ModificadoEl,
				ModificadoPor=@ModificadoPor
			Where IdLayoutEstadoCuenta = @IdLayoutEstadoCuenta
									
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

