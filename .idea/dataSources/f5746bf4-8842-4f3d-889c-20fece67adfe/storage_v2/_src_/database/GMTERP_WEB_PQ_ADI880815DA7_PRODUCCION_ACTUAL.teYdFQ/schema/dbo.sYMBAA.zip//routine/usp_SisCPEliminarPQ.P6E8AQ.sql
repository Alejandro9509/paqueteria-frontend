	CREATE PROCEDURE [dbo].[usp_SisCPEliminarPQ](@IdCP int)
AS
BEGIN
	BEGIN TRANSACTION
		IF ISNULL(@IdCP, 0) <= 0 begin
			RAISERROR(N'El Identificador de codigo postal es un campo requerido', 16, 1);
			return;
			end
		
		DELETE from CatCodigosPostales
		where IdCodigoPostal = @IdCP

IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfo;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
    go

