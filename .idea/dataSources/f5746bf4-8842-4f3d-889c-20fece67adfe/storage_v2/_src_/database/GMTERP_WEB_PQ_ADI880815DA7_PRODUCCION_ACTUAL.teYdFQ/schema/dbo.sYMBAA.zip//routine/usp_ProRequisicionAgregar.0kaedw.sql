CREATE PROCEDURE [dbo].[usp_ProRequisicionAgregar]
	@Folio int,
	@IdProveedor int,
	@FechaHora datetime,
	@SubTotal money,
	@Descuento money,
	@MotivoDescuento varchar(100),
	@IdImpuestosTrasladadosFederales int,
    @ImpuestosTrasladadosFederales money,
    @IdImpuestosRetenidosFederales int,
    @ImpuestosRetenidosFederales money,
    @IdImpuestosTrasladadosLocales int,
    @ImpuestosTrasladadosLocales money,
    @IdImpuestosRetenidosLocales int,
    @ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Estatus tinyint,
	@Observaciones varchar(512),
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProRequisicionConceptos ntext,
	@IdPeticion varchar(100),
	@IdAlmacen int,
	@CargarA varchar(100)
/*************************************************************************************************************************************
Procedimiento almacenado usp_ProRequisicionAgregar
Parámetros: 
	@Folio int,
	@IdProveedor int,
	@FechaHora datetime,
	@SubTotal money,
	@Descuento money,
	@MotivoDescuento varchar(100),
	@IdImpuestosTrasladadosFederales int,
    @ImpuestosTrasladadosFederales money,
    @IdImpuestosRetenidosFederales int,
    @ImpuestosRetenidosFederales money,
    @IdImpuestosTrasladadosLocales int,
    @ImpuestosTrasladadosLocales money,
    @IdImpuestosRetenidosLocales int,
    @ImpuestosRetenidosLocales money,
	@Total money,
	@TipoCambio money,
	@IdMoneda int,
	@Estatus tinyint,
	@Observaciones varchar(512),
	@CreadoPor int,
	@CreadoEl datetime,
	@dsProRequisicionConceptos ntext,
	@IdPeticion varchar(100),
	@IdAlmacen int,
	@CargarA varchar(100)

Descripción: Agrega las Requisiciones de Ordenes de Compra

Modificada por:  Diego Arturo Rubio Meza
Fecha de modificación: 20/08/2019
Versión: V8 8.0.45.25
Descripción: Se agrego la Validacion de concurrencia del folio 

Invocada desde: ClsProRequisicion
Solicitud 104

*************************************************************************************************************************************/

	AS
DECLARE
	@docHandle int,
	@IdRequisicion int,
	@IdOrdenCompra int,
	@FolioOrdenCompra int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@Folio,0) = 0
		RAISERROR(N'El folio de la requisicion es un campo requerido',
			16,
			1
			)
	--Se Agrego la Validacion de la concurrencia del Folio para la Solicitud 104
	IF EXISTS(SELECT Folio FROM ProRequisicion WHERE Folio = @Folio)
		RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva a hacer clic en aceptar.',
			16,
			1
			)		
			
	IF ISNULL(@FechaHora,'') = ''			
		RAISERROR(N'La fecha es un campo requerido',
			16,
			1
			)

	IF ISNULL(@SubTotal,0) = 0
		RAISERROR(N'El subtotal es un campo requerido',
			16,
			1
			)

	IF ISNULL(@IdMoneda,0) = 0
		RAISERROR(N'La moneda es un campo requerido',
			16,
			1
			)
			
	IF @dsProRequisicionConceptos IS NULL
		RAISERROR(N'Los conceptos de la requisicion son requeridos',
			16,
			1
			)	
			
	IF ISNULL(@IdProveedor,0) = 0
			SET @IdProveedor = NULL
							
	---	Se guarda la requequisión
	INSERT INTO ProRequisicion(CreadoEl,CreadoPor,Descuento,Estatus,FechaHora,IdProveedor,Folio,IdMoneda,MotivoDescuento,Observaciones,SubTotal,TipoCambio,Total,IdImpuestosTrasladadosFederales,ImpuestosTrasladadosFederales,IdImpuestosRetenidosFederales,ImpuestosRetenidosFederales,IdImpuestosTrasladadosLocales,ImpuestosTrasladadosLocales,IdImpuestosRetenidosLocales,ImpuestosRetenidosLocales,IdAlmacen,CargarA)
	VALUES(@CreadoEl,@CreadoPor,@Descuento,@Estatus,@FechaHora,@IdProveedor,@Folio,@IdMoneda,@MotivoDescuento,@Observaciones,@SubTotal,@TipoCambio,@Total,@IdImpuestosTrasladadosFederales,@ImpuestosTrasladadosFederales,@IdImpuestosRetenidosFederales,@ImpuestosRetenidosFederales,@IdImpuestosTrasladadosLocales,@ImpuestosTrasladadosLocales,@IdImpuestosRetenidosLocales,@ImpuestosRetenidosLocales,@IdAlmacen,@CargarA)
	SET @IdRequisicion = (SELECT IDENT_CURRENT('ProRequisicion'))	
	
	--SECCION PARA AGREGAR LOS CONCEPTOS DE LA REQUISICION
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProRequisicionConceptos

	SELECT ATT_IdArticulo,ATT_Cantidad,ATT_Entregado,ATT_Pendiente,ATT_PrecioUnitario,ATT_Importe,ATT_Observaciones,ATT_UnidadMedida
	INTO #TempProRequisicionConceptos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_ProRequisicionConceptos',2) 
	WITH (ATT_IdArticulo int,ATT_Cantidad decimal(15,4),ATT_Entregado decimal(15,4),ATT_Pendiente decimal(15,4),ATT_PrecioUnitario decimal(19,6),ATT_Importe money,ATT_Observaciones varchar(256),ATT_UnidadMedida varchar(30))

	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO ProRequisicionConceptos(IdRequisicion,IdArticulo,Cantidad,Entregado,Pendiente,PrecioUnitario,Importe,Observaciones,UnidadMedida,CreadoPor,CreadoEl)
	SELECT @IdRequisicion,ATT_IdArticulo,ATT_Cantidad,ATT_Entregado,ATT_Pendiente,ATT_PrecioUnitario,ATT_Importe,ATT_Observaciones,ATT_UnidadMedida,@CreadoPor,@CreadoEl
	FROM #TempProRequisicionConceptos
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

