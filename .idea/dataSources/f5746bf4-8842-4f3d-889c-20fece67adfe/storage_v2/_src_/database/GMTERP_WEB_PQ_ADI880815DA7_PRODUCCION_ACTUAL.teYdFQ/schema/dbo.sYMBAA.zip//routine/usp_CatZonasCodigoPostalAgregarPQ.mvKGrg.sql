
	CREATE PROCEDURE [dbo].[usp_CatZonasCodigoPostalAgregarPQ](
	@IdZona int,
	@IdCodigoPostal int)
AS
BEGIN
		BEGIN TRANSACTION
		IF ISNULL(@IdZona, 0) <= 0 begin
			RAISERROR(N'*INICIO*El identificadora de la zona es un campo requerido*FIN*', 16, 1); 
			return;
			end
INSERT INTO CatZonasCodigoPostalPQ(IdZona, IdCodigoPostal)

VALUES (@IdZona, @IdCodigoPostal)

---------------------------------------------------------------------------------------------------------
IF @@TRANCOUNT > 0
    BEGIN
        COMMIT TRANSACTION
    END
ELSE
    BEGIN            
        GOTO CANCELAR_TRANSACCION
    END

CANCELAR_TRANSACCION:
        IF @@TRANCOUNT > 0
        BEGIN
		EXECUTE usp_GetErrorInfoPQ;
                ROLLBACK TRANSACTION
                RETURN -1
        END
END
    go

