CREATE  PROCEDURE [dbo].[usp_ProMovimientosBancariosTraspasosEliminar]
@IdMovimientoBancarioTraspaso int,
@IdPeticion varchar(100)	
AS
DECLARE
@IdMovimientoBancarioOrigen int,
@IdMovimientoBancarioDestino int,
@ConciliadoOrigen bit, 
@ConciliadoDestino bit ,
@IdCheque int
/*
MODIFICADO:
	Se agregaro un exec usp_ProPolizasActualizarSaldos
	para acutalizar los asientos contables del catalogo CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-09-30
SOLICITUD: 
	SOLICITUD 000266

MODIFICADO:
	Se agregaro  que eliminara el cheque y la poliza del cheque
MODIFICADA POR:
	Yarazeth Lemus Hernandez
FECHA DE MODIFICACIÓN:
	2020-12-10
SOLICITUD: 
	SOLICITUD 003498
VERSION:
	Versión 8.0.57.10
*/
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdMovimientoBancarioTraspaso,0)= 0
		RAISERROR(N'Identificador de movimiento bancario traspaso es un campo requerido',
			16,
			1
			)
	SELECT @IdMovimientoBancarioOrigen =   IdMovimientoBancarioOrigen,
		   @IdMovimientoBancarioDestino =   IdMovimientoBancarioDestino
	FROM ProMovimientosBancariosTraspasos 
	WHERE  ProMovimientosBancariosTraspasos.IdMovimientoBancarioTraspaso = @IdMovimientoBancarioTraspaso
	
	-- valida que el movimiento origen exista en ProMovimientosBancariosTraspaso
	IF NOT EXISTS(SELECT IdMovimientoBancarioOrigen 
	                 FROM ProMovimientosBancariosTraspasos 
	                  WHERE IdMovimientoBancarioOrigen = @IdMovimientoBancarioOrigen 
	                    AND IdMovimientoBancarioDestino= @IdMovimientoBancarioDestino )
	  BEGIN
		RAISERROR(N'No puede eliminar los movimiento origen y destino por que no pertenece a una operación de traspaso',
			16,
			1
			)
	  END
	--- valida conciliado movimiento origen
	 SET @ConciliadoOrigen = (SELECT Conciliado FROM ProMovimientosBancarios WHERE  IdMovimientoBancario = @IdMovimientoBancarioOrigen) 
	 IF ISNULL(@ConciliadoOrigen,0) = 1
	  BEGIN
		RAISERROR(N'El movimiento origen ya está conciliado no puede eliminar',
			16,
			1
			)
	  END
	--- valida conciliado movimiento destino 
	 SET @ConciliadoDestino = (SELECT Conciliado FROM ProMovimientosBancarios WHERE  IdMovimientoBancario = @IdMovimientoBancarioDestino) 
	 IF ISNULL(@ConciliadoDestino,0) = 1
	  BEGIN
		RAISERROR(N'El movimiento origen ya está conciliado no puede eliminar',
			16,
			1
			)
	  END
	  ---ELIMINA CHEQUE
	SET @IdCheque = (Select IdCheque from ProMovimientosBancarios Where IdMovimientoBancario = @IdMovimientoBancarioOrigen)
	
	--- Eliminar Movimiento Bancario
	DELETE FROM ProMovimientosBancariosTraspasos WHERE IdMovimientoBancarioTraspaso = @IdMovimientoBancarioTraspaso
	DELETE FROM ProMovimientosBancarios WHERE IdMovimientoBancario in (@IdMovimientoBancarioOrigen,@IdMovimientoBancarioDestino)
	Delete from ProCheques Where IdCheque = @IdCheque
	

    --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
		/*Antes de que se elimine la poliza, se van a quitar los asientos contables de CatCuentasContablesSaldos*/
		DECLARE @CondicionQuery nvarchar(max)  = ' pp.ProcesoLigado = ''ProMovimientosBancariosTraspasos'' AND pp.IdProcesoLigado IN ( '+CAST(@IdMovimientoBancarioTraspaso AS varchar)+') ' 
		EXEC usp_ProPolizasActualizarSaldos @IdPeticion,0,@CondicionQuery
        DELETE FROM ProPolizas 
        WHERE ProcesoLigado = 'ProMovimientosBancariosTraspasos' AND IdProcesoLigado = @IdMovimientoBancarioTraspaso
		/*Antes de que se elimine la poliza, se van a quitar los asientos contables de CatCuentasContablesSaldos*/
		SET @CondicionQuery = ' pp.ProcesoLigado = ''ProCheques'' AND pp.IdProcesoLigado IN ( '+CAST(@IdCheque AS varchar)+') ' 
		EXEC usp_ProPolizasActualizarSaldos @IdPeticion,0,@CondicionQuery
		DELETE FROM ProPolizas Where ProcesoLigado = 'ProCheques' And IdProcesoLigado = @IdCheque
    END		
    	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

