CREATE PROCEDURE [dbo].[usp_CatProveedoresGetMaxNumeroProveedor]

AS

SELECT ISNULL(MAX(NumeroProveedor),0)+1 AS NumeroProveedor FROM CatProveedores
go

