
CREATE PROCEDURE [dbo].[usp_ProLiquidacionesTPersonalRegistrarPagoSinMovimientoBancario]
@XMLLiquidaciones text,
@PagadoEl datetime,
@IdOperador int,
@IdPeticion varchar(100),
@PagadoPor int,
@IdCertificado int,
@BUnaLiquidacion bit,
@IdLiquidacion int,
@Folio int
/* *************************************************************************************************
Procedimiento usp_ProLiquidacionesTPersonalRegistrarPagoSinMovimientoBancario

Parámetros: 
@XMLLiquidaciones text		XML que trae consigo las liquidaciones a pagar
@PagadoEl datetime			fecha de pago	
@IdOperador int				Operador de las liquidaciones
@IdPeticion varchar(100)	Id de la peticion generada por WebDev
@PagadoPor int				Usuario que hace los pagos
@IdCertificado int			Certificado de los pagos
@BUnaLiquidacion bit		Indica que solo se paga una liquidacion
@nIdLiquidacion int			Id de la unica liquidacion que se pagará
@Folio int					Folio de la unica liquidacion que se pagará

Descripcion: Se agrego el parametro @IdCertificado y se modifico el update a la tabla ProLiquidaciones
para aceptar el nuevo parametro, esto con el fin de permitir timbrar liquidaciones que no tienen
un movimiento bancario.
	
Creado por:  Francisco Villela
Fecha de mofidicacion: 24/07/2019


Invocada desde: <PAGE_ProLiquidacionesTPersonalRegistrarPago>
	************************************************************************************************ */
AS
DECLARE
@ATT_IdLiquidacion int,
@ATT_Folio varchar(150),
@Mensaje varchar(150),
@docHandle int

BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISDATE(@PagadoEl) = 0
		RAISERROR(N'Fecha de pago es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@IdOperador,0) <= 0
			RAISERROR(N'El identificador de operador es un campo requerido',
			16,
			1
			)	

	--Se agregó validación para detectar cuando se van a pagar liquidaciones por xml o una sola liquidacion
	IF @BUnaLiquidacion = 0
	BEGIN
		--Se modifico toda esta seccion para recorrer el xml y validar cada una de las liquidaciones de manera individual
		IF @XMLLiquidaciones IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @XMLLiquidaciones

			SELECT ATT_IdLiquidacion, ATT_Folio
			INTO #TempLiquidacionesPorPagar
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_Liquidaciones',3) 
			WITH (ATT_IdLiquidacion int, ATT_Folio varchar(150))

			EXEC sp_xml_removedocument @docHandle
			DECLARE LiquidacionesPagarCursor CURSOR FOR
			SELECT * FROM #TempLiquidacionesPorPagar

			OPEN LiquidacionesPagarCursor
			FETCH NEXT FROM LiquidacionesPagarCursor
			INTO @ATT_IdLiquidacion, @ATT_Folio

			WHILE @@FETCH_STATUS = 0
			BEGIN
				--Se valida que cada liquidacion contenga un id de liquidacion, este autorizada y no haya sido pagada
				IF ISNULL(@ATT_IdLiquidacion,0) <= 0
					RAISERROR(N'El identificador de liquidación es un campo requerido',
						16,
						1
						)	

				IF ISDATE((Select AutorizadaEl From ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @ATT_IdLiquidacion)) = 0
				BEGIN
					SET @Mensaje = 'La liquidación '+@ATT_Folio+' no esta autorizada para registrar pago'
					RAISERROR(@Mensaje,
						16,
						1)
				END

				IF  ISNULL((Select IdMovimientoBancario  from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @ATT_IdLiquidacion),0) > 0 OR ISDATE((Select PagadoEl  from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @ATT_IdLiquidacion)) <> 0 
				BEGIN
					SET @Mensaje = 'La liquidación ' + @ATT_Folio + ' ya fue pagada por otro usuario'
					RAISERROR(@Mensaje,
						16,
						1)
				END
				--Se realiza el update con las fechas de pago y usuario que paga
				UPDATE ProLiquidacionesTPersonal SET
				   PagadoEl = @PagadoEl,
				   PagadoPor = @PagadoPor,
				   FechaCancelacionPago = NULL,
				   MotivoCancelacionPago = NULL,
				   UsuarioCanceloPago = NULL,
				   IdCertificado = @IdCertificado
				WHERE  IdLiquidacionTPersonal =  @ATT_IdLiquidacion

				FETCH NEXT FROM LiquidacionesPagarCursor
				INTO @ATT_IdLiquidacion, @ATT_Folio
			END

			CLOSE LiquidacionesPagarCursor
			DEALLOCATE LiquidacionesPagarCursor
		END
	END
	ELSE
	BEGIN
		--Se valida que cada liquidacion contenga un id de liquidacion, este autorizada y no haya sido pagada
		IF ISNULL(@IdLiquidacion,0) <= 0
			RAISERROR(N'El identificador de liquidación es un campo requerido',
				16,
				1
				)	

		IF ISDATE((Select AutorizadaEl From ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion)) = 0
		BEGIN
			SET @Mensaje = 'La liquidación '+@Folio+' no esta autorizada para registrar pago'
			RAISERROR(@Mensaje,
				16,
				1)
		END

		IF  ISNULL((Select IdMovimientoBancario from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion),0) > 0 OR ISDATE((Select PagadoEl  from ProLiquidacionesTPersonal WHERE IdLiquidacionTPersonal =  @IdLiquidacion)) <> 0 
		BEGIN
			SET @Mensaje = 'La liquidación ' + @Folio + ' ya fue pagada por otro usuario'
			RAISERROR(@Mensaje,
				16,
				1)
		END

		--Se realiza el update con las fechas de pago y usuario que paga
		UPDATE ProLiquidacionesTPersonal SET
			PagadoEl = @PagadoEl,
			PagadoPor = @PagadoPor,
			FechaCancelacionPago = NULL,
			MotivoCancelacionPago = NULL,
			UsuarioCanceloPago = NULL,
			IdCertificado = @IdCertificado
		WHERE  IdLiquidacionTPersonal =  @IdLiquidacion
	END
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

