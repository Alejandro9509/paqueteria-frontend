CREATE PROCEDURE [dbo].[usp_ProMovimientosBancariosModificar]
    @IdMovimientoBancario int,
	@Fecha datetime,
	@IdCuentaBancaria int,
	@Importe money ,
	@TipoCambio money ,
	@ReferenciaBancaria varchar(150),
	@IdTipoMovimientoBancario int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),	
	@TipoBeneficiario tinyint,
	@IdProveedor int,
	@IdBeneficiario int,
	@PorAnticipo bit,
	@Beneficiario varchar(150),
	@CuentaBancariaProveedor varchar(50),
    @IdBancoProveedor int,
    @XMLArchivo ntext,
	@FolioFiscalUUID varchar(36),
	@FechaCobro datetime,
	@Observaciones varchar(250),
	@EsOtroProceso bit = 0

/* *************************************************************************************************
Procedimiento usp_ProMovimientosBancariosModificar

Parámetros: 
	@IdMovimientoBancario (entrada, entero). Identificador del movimiento bancario
	@NumeroMovimiento (entrada, entero). Numero de movimiento bancario
	@Fecha (entrada, fecha). Fecha del movimiento
	@IdCuentaBancaria  (entrada, entero). Identificador de la cuenta bancaria
	@Importe (entrada, moneda). Importe del movimiento
	@TipoCambio (entrada, moneda). Tipo de cambio
	@ReferenciaBancaria (entrada, texto). Referencia del movmiento
	@IdTipoMovimientoBancario (entrada, entero). Identificador del tipo de movimiento
	@ModificadoPor (entrada, entero). Usuario que modifica
	@ModificadoEl (entrada, fecha hora). Fecha y hora de modificacion
	@IdPeticion (entrada, string). Id de la Petición, generada en WEBDEV
	@TipoBeneficiario (entrada, entero). Tipo de beneficiario
	@IdProveedor (entrada, entero). identificador del proveedor
	@IdBeneficiario (entrada, entero). Identificador del beneficiario
	@PorAnticipo (entrada, booelano). Si es por anticipo
	@Beneficiario (entrada, texto). Nombre del beneficiario
	@CuentaBancariaProveedor (entrada, texto). Cuenta bancaria del proveedor
    @IdBancoProveedor (entrada, entero). Identificador del banco del proveedor
    @XMLArchivo (entrada, texto). XML
	@FolioFiscalUUID (entrada, texto). Folio fiscal 
	@FechaCobro (entrada, fecha). Fecha de cobro
	@Observaciones (entrada, texto). Observaciones
	@EsOtroProceso (entrada, booleano) Valida si el movimiento bancario pertenece a otro proceso. Default = False

Descripción: Procedimiento para modificar un movimiento bancario

06/11/2020 - Se agrego el flujo de asignarle una fecha de cobro, se valido que si viene de otros procesos y son de retiro te permita modificar
07/12/2020 - Se agrego el campo de observaciones y validaciones para cuando es movimiento bancario de otro proceso

Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 07/12/2020
Versión ERP: 8.0.57.04

Invocada desde: PAGE_ProMovimientosBancariosRM (Solicitud 3393)
***************************************************************************************************** */
AS
DECLARE
	@IdCheque int,
	@EsRetiro int,
	@NumeroMovBancarioError int, --bandera para obtener el número de movimiento bancario del movimiento bancario que tiene el folio fiscal uuid capturado previamente
	@MensajeError varchar(200) 
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdMovimientoBancario,0)= 0
		RAISERROR(N'Identificador de movimiento bancario es un campo requerido', 16, 1)
	
	IF @EsOtroProceso = 0 
	BEGIN
		--Movimiento bancario que no pertenece a otro proceso
		-- valida que el movimiento no exista en cobranza
		IF EXISTS(SELECT IdMovimientoBancario FROM ProCobranza WHERE IdMovimientoBancario = @IdMovimientoBancario)
			BEGIN
			SET @EsRetiro = (SELECT TipoMovimiento FROM CatTiposMovimientosBancarios WHERE IdTipoMovimientoBancario = @IdTipoMovimientoBancario)
			IF @EsRetiro != 2 
				RAISERROR(N'No puede modificar este movimiento, los datos pertenecen a cobranza', 16, 1)
			END
		-- valida que el movimiento no exista en liquidaciones
		IF EXISTS(SELECT IdMovimientoBancario FROM ProLiquidaciones WHERE IdMovimientoBancario = @IdMovimientoBancario)
			BEGIN
			SET @EsRetiro = (SELECT TipoMovimiento FROM CatTiposMovimientosBancarios WHERE IdTipoMovimientoBancario = @IdTipoMovimientoBancario)
			IF @EsRetiro != 2 
				RAISERROR(N'No puede modificar este movimiento, los datos pertenecen a liquidación', 16, 1)
			END

		IF EXISTS(SELECT IdMovimientoBancario FROM ProLiquidacionesFiscales WHERE IdMovimientoBancario = @IdMovimientoBancario)
			BEGIN
				SET @EsRetiro = (SELECT TipoMovimiento FROM CatTiposMovimientosBancarios WHERE IdTipoMovimientoBancario = @IdTipoMovimientoBancario)
				IF @EsRetiro != 2 
					RAISERROR(N'No puede modificar este movimiento, los datos pertenecen a liquidación fiscal', 16, 1)
			END
	  
		-- valida que el movimiento no exista en cheques rapidos
		SET @IdCheque = (SELECT IdCheque FROM ProMovimientosBancarios WHERE IdMovimientoBancario = @IdMovimientoBancario)
		IF ISNULL(@IdCheque, 0) > 0
			BEGIN
				RAISERROR(N'No puede modificar este movimiento, los datos pertenecen a un cheque', 16, 1)
			END

		IF ISNULL(@Fecha,'')= ''
			RAISERROR(N'Fecha es un campo requerido', 16, 1)

		IF ISNULL(@FechaCobro,'')= ''
			RAISERROR(N'Fecha de cobro es un campo requerido', 16, 1)
			
		IF ISNULL(@IdCuentaBancaria,0)= 0
			RAISERROR(N'El identificador de cuenta bancaria es un campo requerido', 16, 1)

		IF ISNULL(@TipoCambio,0)= 0
			RAISERROR(N'Tipo de cambio es un campo requerido', 16, 1)
	
		IF ISNULL(@ReferenciaBancaria,'')= ''
			RAISERROR(N'El Referencia bancaria es un campo requerido', 16, 1)

		IF ISNULL(@Importe,0)= 0
			RAISERROR(N'El Importe es un campo requerido', 16, 1)
			
		IF @TipoBeneficiario = 1  --- 1 Tipo Proveedor
		BEGIN
			IF ISNULL(@IdProveedor,0)= 0
				RAISERROR(N'Identificador de proveedor es un campo requerido', 16, 1)
			SET @IdBeneficiario = NULL
		END

		IF @TipoBeneficiario = 2  --- 2 Tipo Beneficiario
		BEGIN
			IF ISNULL(@IdBeneficiario, 0)= 0
				RAISERROR(N'Identificador de Beneficiario es un campo requerido', 16, 1)
			SET @IdProveedor = NULL
		END				
	
		IF ISNULL(@Beneficiario ,'')= ''
			RAISERROR(N'Beneficiario es un campo requerido', 16, 1)	
			
		IF @IdBancoProveedor = 0
			SET @IdBancoProveedor = NULL

		--SE VALIDA QUE SI EL FOLIO FISCAL ES DIFERENTE DE VACIO QUE NO EXISTA UN MOVIMIENTO BANCARIO(NO CANCELADO) YA REGISTRADO	
		IF @FolioFiscalUUID <> ''
		BEGIN
			SET @NumeroMovBancarioError = (SELECT NumeroMovimiento FROM ProMovimientosBancarios WHERE FolioFiscalUUID = @FolioFiscalUUID AND CanceladoEl IS NULL AND IdMovimientoBancario != @IdMovimientoBancario)
			IF @NumeroMovBancarioError IS NOT NULL
			BEGIN
				SET @MensajeError = 'El movimiento bancario con el número '+CAST(@NumeroMovBancarioError as varchar)+' tiene registrado el Folio Fiscal UUID que intenta agregar en el movimiento bancario'
				RAISERROR(@MensajeError, 16, 1)		
			END
		END	
					
		--- Modificar Movimiento Bancario
		UPDATE ProMovimientosBancarios
			SET Fecha  = @Fecha,
			IdCuentaBancaria =@IdCuentaBancaria,
			Importe = @Importe ,
			TipoCambio = @TipoCambio ,
			ReferenciaBancaria = @ReferenciaBancaria,
			IdTipoMovimientoBancario = @IdTipoMovimientoBancario,
			ModificadoPor = @ModificadoPor,
			ModificadoEl = @ModificadoEl, 
			TipoBeneficiario = @TipoBeneficiario,
			IdProveedor  = @IdProveedor,
			IdBeneficiario = @IdBeneficiario,
			PorAnticipo =@PorAnticipo, 
			Beneficiario = @Beneficiario,
			CuentaBancariaProveedor = @CuentaBancariaProveedor,
			IdBancoProveedor = @IdBancoProveedor, 
			XMLArchivo = @XMLArchivo,
			FolioFiscalUUID = @FolioFiscalUUID,
			FechaCobro = @FechaCobro,
			Observaciones = @Observaciones
		WHERE IdMovimientoBancario =  @IdMovimientoBancario
	END
	ELSE
	BEGIN
		-- Movimiento bancario que pertenece a otro proceso
		--- Modificar Movimiento Bancario
		UPDATE ProMovimientosBancarios
			SET ModificadoPor = @ModificadoPor,
			ModificadoEl = @ModificadoEl, 
			FechaCobro = @FechaCobro,
			Observaciones = @Observaciones
		WHERE IdMovimientoBancario =  @IdMovimientoBancario
	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

