CREATE PROCEDURE [dbo].[usp_CatRutasAgregar]
	@FolioRuta int,
	@IdCliente int,
	@IdOrigen int,
	@IdDestino int,
	@DescripcionRuta varchar(140),
	@Activa bit,
	@IdTipoUnidad int,
	@Kilometros int,
	@Horas decimal(15,2),
	@IdSucursal int,
	@Item varchar(50),
	@Planta varchar(50),
	@Convenio varchar(50),
	@IdRemitente int,
	@IdDestinatario int,
	@CreadoPor int,
	@CreadoEl datetime,
	@dsCatRutasConceptosFacturacion ntext,	
	@dsCatRutasDescripcionesCargaTarifas ntext,
	@dsCatRutasTrayectos ntext,
	@IdPeticion varchar(100),
	@ViajeFacturable bit,
	@dsCatRutasClienteContactos ntext,
	@ImporteBase money,
	@IdTipoViaje int,
	@IdClasificacionViaje int,
	@Millas decimal(15,2),
	@ETA decimal(15,2),
	@PTVContratado bit = 0,--para identificar si el cliente contrato el modulo de ptv
	@dsCatRutasTarifasMaterialesPemex ntext,
	@dsCatRutasTrayectosDistribucionConceptosFacturacion XML = NULL,
	@ViajeInternacional bit = NULL,
	@ImportacionExportacion tinyint = NULL,
	@ViajeRepartoRecolecta bit = NULL,
	@FechaAlta datetime = NULL,
	@FechaVigencia datetime = NULL
/* *************************************************************************************************
Procedimiento usp_CatRutasAgregar
 
Descripción: Procedimiento para agregar una ruta/tarifa

14/02/2020 - Se agrego parametro dsCatRutasTarifasMaterialesPemex para el xml del nuevo catalogo de Materiales Pemex
24/03/2020 - se agregó seccion para insertar los porcentajes de impuestos de cada concepto de facturacion de la ruta, ademas
			de los campos de @IdImpuestoTrasladado,@IdImpuestoRetenido,@IdRutaConceptoFacturacion para obtener dichos datos 
			del xml de  @dsCatRutasConceptosFacturacion
2/04/2020 - se agregó seccion para evitar que se agreguen idImpuesto en cero
22/02/2021 - Se modifico el tipo de dato money a float en las tarifas pesos y dolares de los materiales

Implementada por: XXXXXX
Fecha de implementacion: XXXXXX
Versión ERP: XXXXXX

Modificada por: Edgar Ramos
Fecha de modificación: 14/05/2021
Versión: 8.0.61.13
Solicitud: 4208
Descripción: Se agrego la distribucion de ingresos en los trayectos.


Modificada por: Edgar Ramos
Fecha de modificación: 08/06/2021
Versión: 8.0.62.05
Solicitud: 4333
Descripción: Se agregaron campos ViajeInternacional , ExportacionImportacion y claves del sat a los materiales, se cerraron cursores

Modificada por: Edgar Ramos
Fecha de modificación: 18/06/2021
Versión:  8.0.62.14
Solicitud: 4450
Descripción: Se agrego el parametro ViajeRepartoRecolecta y una seccion para guardar las ubicaciones del remitente y destinatario para la carta porte

Invocada desde: PAGE_CatRutasAM (Solicitud 902)

Modificada por:Yarazeth Lemus
Fecha de modificación: 18/08/2021
Versión: 8.0.63.02
Solicitud: 4667
Descripción: se cambio el varchar de la clave de sat a 10

Modificada por: Ignacio Perez
Fecha de modificación: 26/08/2021
Versión: 8.0.64.13
Solicitud: 4683
Descripción: Se agregaron las nuevas columnas de catrutas FechaAlta y FechaVigencia

Modificada por: Jesús Humberto Morales
Fecha de modificación: 27/08/2021
Versión: 8.0.64.13
Solicitud: 4527
Descripción: Se modifico el tipo de valor de Importe base en la descripcion de materiales

***************************************************************************************************** */

AS
DECLARE
	@IdRuta int,
	@docHandle int,
	@CursorIdConceptoFacturacion int,
	@CursorImporte money,
	@CursorImporteDlls money,
	@CursorDescripcionCarga varchar(1024),
	@CursorIdUnidadMedidaEmbalaje int,
	@CursorIdUnidadMedidaPeso int,
	@CursorTarifa float,
	@CursorTarifaDlls float,
	@CursorIdTipoViaje int,
	@CursorIdTipoUnidad int,
	@CursorIdClasificacionViaje int,
	@CursorImporteBaseLiquidacion float,
	@CursorAplicarTarifaPor tinyint,
	@CursorIdMaterialPemex int,
	@CursorTarifaPemex money,
	@CursorPeaje5Pemex money,
	@CursorPeaje6Pemex money,
	@CursorPeaje9Pemex money,
	@CursorSueldoBaseSencilloPemex money,
	@CursorSueldoBaseFullPemex money,
	@CursorComisionSencilloPemex money,
	@CursorComisionFullPemex money,
	@COL_Secuencia int,
	@COL_IdOrigen int,
	@COL_IdDestino int,
	@COL_Kilometros int,
	@COL_Horas decimal(15,2),
	@COL_RutaGoogleMap varchar(max),
	@COL_GastosAutorizados varchar(8000),
	@COL_SueldoBaseSencilloCargado money,
	@COL_SueldoBaseSencilloVacio money,
	@COL_SueldoBaseFullCargado money,
	@COL_SueldoBaseFullVacio money,
	@COL_SueldoBaseFullVacioCargado_CargadoVacio money,	
	@COL_SueldoBaseDllsSencilloCargado money,
	@COL_SueldoBaseDllsSencilloVacio money,
	@COL_SueldoBaseDllsFullCargado money,
	@COL_SueldoBaseDllsFullVacio money,
	@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio money,	
	@COL_PorcentajeComisionPermisionario int,	
	@COL_CuotaPorKilometro money,
	@COL_CuotaDiaria money,
	@COL_ImporteSeguro money,
	@COL_IdGeocercaDisparaSalida int,
	@COL_GeocercaDisparaSalidaES tinyint,
	@COL_IdGeocercaDisparaLlegada int,
	@COL_GeocercaDisparaLlegadaES tinyint,
	@COL_Geocercas varchar(max),
	@COL_IdEstatuViajeSalida int,
	@COL_IdEstatuViajeLlegada int,	
	@IdRutaTrayecto int,
	@COL_FactorLiqKmsSencilloCargado decimal(15,2),
	@COL_FactorLiqKmsSencilloVacio decimal(15,2), 
	@COL_FactorLiqKmsFullCargado decimal(15,2),
	@COL_FactorLiqKmsFullVacio decimal(15,2),
	@COL_FactorLiqKmsFullVacioCargado_CargadoVacio decimal(15,2),	
	@COL_Casetas varchar(max),
	@COL_FactorLiqKmsDllsSencilloCargado decimal(15, 2),
	@COL_FactorLiqKmsDllsSencilloVacio decimal(15, 2),
	@COL_FactorLiqKmsDllsFullCargado decimal(15, 2),
	@COL_FactorLiqKmsDllsFullVacio decimal(15, 2),
	@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio decimal(15, 2),
	@COL_Permisionarios varchar(max),
	@COL_TipoTrayecto TINYINT,
	@COL_Millas decimal (15,2),
	@COL_ETA decimal(15,2),
	@COL_LocationIdLoad VARCHAR(100),
	@COL_NameLoad VARCHAR(100),
	@COL_AddressLoad VARCHAR(100),
	@COL_CityLoad varchar(100),
	@COL_StateLoad VARCHAR(100),
	@COL_PostalCodeLoad VARCHAR(100),
	@COL_CountryLoad VARCHAR(100),
	@COL_LatitudeLoad float,
	@COL_LongitudeLoad float,
	@COL_LocationIdUnload VARCHAR(100),
	@COL_NameUnload varchar(100),
	@COL_AddressUnload VARCHAR(100),
	@COL_CityUnload VARCHAR(100), 
	@COL_StateUnload varchar(100),
	@COL_PostalCodeUnload VARCHAR(100),
	@COL_CountryUnload VARCHAR(100),
	@COL_LatitudeUnload VARCHAR(100),
	@COL_LongitudeUnload varchar(100),
	@COL_TieneLocation bit,
	@IdImpuestoTrasladado int,
	@IdImpuestoRetenido int,
	@IdRutaConceptoFacturacion int,
	@CursorTraslada bit,
	@CursorRetiene bit,
	@COL_ClavesSatXML varchar(max),
	@IdRutaDescripcionCarga int,
	@COL_UbicacionesXML varchar(max)

	/*SOLICITUD 4208*/
	DECLARE @TempCatRutasTrayectosDistribucionConceptosFacturacion AS TABLE 
		(
		 COL_Secuencia int
		,COL_IdConceptoFacturacion int
		,COL_Importe money
		,COL_ImporteDlls money)

BEGIN TRY
	BEGIN TRANSACTION

	IF @FolioRuta = 0
		RAISERROR(N'El folio de la ruta es un campo requerido',
			16,
			1
			)

	IF EXISTS(SELECT * FROM CatRutas WHERE FolioRuta = @FolioRuta)			
		RAISERROR(N'El folio de la ruta ya existe en el catálogo',
			16,
			1
			)

	IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)

	IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)			

	IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)			
				
	IF RTRIM(LTRIM(@DescripcionRuta)) = ''
		RAISERROR(N'La descripción de la ruta es un campo requerido',
			16,
			1
			)	

	IF @IdSucursal = 0
		RAISERROR(N'La sucursal es un campo requerido',
			16,
			1
			)

	IF @dsCatRutasTrayectos IS NULL
		RAISERROR(N'Los trayectos son requeridos',
			16,
			1
			)	
			
	IF @IdTipoUnidad = 0
		SET @IdTipoUnidad = NULL

	IF @IdRemitente = 0 
		SET @IdRemitente = NULL
		
	IF @IdDestinatario = 0 
		SET @IdDestinatario = NULL		

	IF @IdTipoViaje = 0 
		SET @IdTipoViaje = NULL

	IF @IdClasificacionViaje = 0 
		SET @IdClasificacionViaje = NULL
								
	INSERT INTO CatRutas(FolioRuta,IdCliente,IdOrigen,IdDestino,DescripcionRuta,Activa,IdTipoUnidad,Kilometros,Horas,IdSucursal,Item,Planta,Convenio,IdRemitente,IdDestinatario,CreadoPor,CreadoEl,ViajeFacturable,ImporteBase,IdClasificacionViaje,IdTipoViaje,Millas,ETA,ViajeInternacional,ImportacionExportacion,ViajeRepartoRecolecta,FechaAlta,FechaVigencia)
	VALUES(@FolioRuta,@IdCliente,@IdOrigen,@IdDestino,@DescripcionRuta,@Activa,@IdTipoUnidad,@Kilometros,@Horas,@IdSucursal,@Item,@Planta,@Convenio,@IdRemitente,@IdDestinatario,@CreadoPor,@CreadoEl,@ViajeFacturable,@ImporteBase,@IdClasificacionViaje,@IdTipoViaje,@Millas,@ETA,@ViajeInternacional,@ImportacionExportacion,@ViajeRepartoRecolecta,@FechaAlta,@FechaVigencia)	

	SET @IdRuta = (SELECT IDENT_CURRENT('CatRutas'))
	/*SOLICITUD 4208 SECCION PARA AGREGAR LA DISTRIBUCION DE LOS CONCEPTOS EN UNA VARIABLE TABLA*/
	IF @dsCatRutasTrayectosDistribucionConceptosFacturacion IS NOT NULL
	BEGIN
		
		INSERT INTO @TempCatRutasTrayectosDistribucionConceptosFacturacion(COL_Secuencia,COL_IdConceptoFacturacion,COL_Importe,COL_ImporteDlls)
		SELECT  COL_Secuencia = T.Item.value('COL_Secuencia[1]', 'int')
			   ,COL_IdConceptoFacturacion = T.Item.value('COL_IdConceptoFacturacion[1]', 'int')
			   ,COL_Importe = T.Item.value('COL_Importe[1]', 'money')
			   ,COL_ImporteDlls = T.Item.value('COL_ImporteDlls[1]', 'money')
		FROM   @dsCatRutasTrayectosDistribucionConceptosFacturacion.nodes('WINDEV_TABLE/CatRutasTrayectosDistribucionConceptosFacturacion') AS T(Item);

	END
	/*FIN SOLICITUD 4208*/
	--SECCION PARA AGREGAR LOS trayectos
	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTrayectos
	
	SELECT COL_Secuencia,COL_IdOrigen,COL_IdDestino,COL_Kilometros,COL_Horas,COL_RutaGoogleMap,COL_GastosAutorizados,
	COL_SueldoBaseSencilloCargado,COL_SueldoBaseSencilloVacio,COL_SueldoBaseFullCargado,
	COL_SueldoBaseFullVacio,COL_SueldoBaseFullVacioCargado_CargadoVacio,
	COL_SueldoBaseDllsSencilloCargado,COL_SueldoBaseDllsSencilloVacio,COL_SueldoBaseDllsFullCargado,
	COL_SueldoBaseDllsFullVacio,COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,	
	COL_IdGeocercaDisparaSalida,COL_GeocercaDisparaSalidaES,COL_IdGeocercaDisparaLlegada,COL_GeocercaDisparaLlegadaES,COL_Geocercas,
	COL_IdEstatuViajeSalida,COL_IdEstatuViajeLlegada,COL_FactorLiqKmsSencilloCargado,COL_FactorLiqKmsSencilloVacio,COL_FactorLiqKmsFullCargado,
	COL_FactorLiqKmsFullVacio,COL_FactorLiqKmsFullVacioCargado_CargadoVacio,COL_Casetas,
	COL_FactorLiqKmsDllsSencilloCargado,COL_FactorLiqKmsDllsSencilloVacio,COL_FactorLiqKmsDllsFullCargado,
	COL_FactorLiqKmsDllsFullVacio,COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,COL_Permisionarios,COL_TipoTrayecto,COL_Millas,COL_ETA,COL_LocationIdLoad,COL_NameLoad,
	COL_AddressLoad,COL_CityLoad,COL_StateLoad,COL_PostalCodeLoad,COL_CountryLoad,COL_LatitudeLoad,COL_LongitudeLoad,COL_LocationIdUnload,COL_NameUnload,COL_AddressUnload,COL_CityUnload, COL_StateUnload,COL_PostalCodeUnload,COL_CountryUnload,COL_LatitudeUnload,COL_LongitudeUnload,COL_TieneLocation,COL_UbicacionesXML
	INTO #TempCatRutasTrayectos
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectos',2) 
	WITH (COL_Secuencia int,COL_IdOrigen int,COL_IdDestino int,COL_Kilometros int,COL_Horas decimal(15,2),COL_RutaGoogleMap ntext,COL_GastosAutorizados ntext,
	COL_SueldoBaseSencilloCargado money,COL_SueldoBaseSencilloVacio money,COL_SueldoBaseFullCargado money,
	COL_SueldoBaseFullVacio money,COL_SueldoBaseFullVacioCargado_CargadoVacio money,
	COL_SueldoBaseDllsSencilloCargado money,COL_SueldoBaseDllsSencilloVacio money,COL_SueldoBaseDllsFullCargado money,
	COL_SueldoBaseDllsFullVacio money,COL_SueldoBaseDllsFullVacioCargado_CargadoVacio money,	
	COL_IdGeocercaDisparaSalida int,COL_GeocercaDisparaSalidaES tinyint,COL_IdGeocercaDisparaLlegada int,COL_GeocercaDisparaLlegadaES tinyint,COL_Geocercas ntext,
	COL_IdEstatuViajeSalida int,COL_IdEstatuViajeLlegada int,COL_FactorLiqKmsSencilloCargado decimal(15,2),COL_FactorLiqKmsSencilloVacio decimal(15,2),COL_FactorLiqKmsFullCargado decimal(15,2),
	COL_FactorLiqKmsFullVacio decimal(15,2),COL_FactorLiqKmsFullVacioCargado_CargadoVacio decimal(15,2),COL_Casetas ntext,
	COL_FactorLiqKmsDllsSencilloCargado decimal(15,2),COL_FactorLiqKmsDllsSencilloVacio decimal(15,2),COL_FactorLiqKmsDllsFullCargado decimal(15,2),
	COL_FactorLiqKmsDllsFullVacio decimal(15,2),COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio decimal(15,2),COL_Permisionarios varchar(max),COL_TipoTrayecto TINYINT,COL_Millas decimal(15,2),COL_ETA decimal(15,2),COL_LocationIdLoad VARCHAR(100),COL_NameLoad VARCHAR(100),COL_AddressLoad VARCHAR(100),COL_CityLoad varchar(100),COL_StateLoad VARCHAR(100),COL_PostalCodeLoad VARCHAR(100),COL_CountryLoad VARCHAR(100),COL_LatitudeLoad float,COL_LongitudeLoad float,COL_LocationIdUnload VARCHAR(100),COL_NameUnload varchar(100),COL_AddressUnload VARCHAR(100),COL_CityUnload VARCHAR(100), COL_StateUnload varchar(100),COL_PostalCodeUnload VARCHAR(100),COL_CountryUnload VARCHAR(100),COL_LatitudeUnload VARCHAR(100),COL_LongitudeUnload varchar(100), COL_TieneLocation bit,COL_UbicacionesXML varchar(max) )
	
	EXEC sp_xml_removedocument @docHandle
	
	DECLARE CursorCatRutasTrayectos CURSOR LOCAL FOR
	SELECT * FROM #TempCatRutasTrayectos
	
	OPEN CursorCatRutasTrayectos
	FETCH NEXT FROM CursorCatRutasTrayectos
	INTO @COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
	@COL_SueldoBaseSencilloCargado,@COL_SueldoBaseSencilloVacio,@COL_SueldoBaseFullCargado,
	@COL_SueldoBaseFullVacio,@COL_SueldoBaseFullVacioCargado_CargadoVacio,
	@COL_SueldoBaseDllsSencilloCargado,@COL_SueldoBaseDllsSencilloVacio,@COL_SueldoBaseDllsFullCargado,
	@COL_SueldoBaseDllsFullVacio,@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,	
	@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,
	@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,@COL_FactorLiqKmsSencilloCargado,@COL_FactorLiqKmsSencilloVacio,@COL_FactorLiqKmsFullCargado,
	@COL_FactorLiqKmsFullVacio,@COL_FactorLiqKmsFullVacioCargado_CargadoVacio,@COL_Casetas,
	@COL_FactorLiqKmsDllsSencilloCargado,@COL_FactorLiqKmsDllsSencilloVacio,@COL_FactorLiqKmsDllsFullCargado,
	@COL_FactorLiqKmsDllsFullVacio,@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,@COL_Permisionarios,@COL_TipoTrayecto,@COL_Millas,@COL_ETA, @COL_LocationIdLoad, @COL_NameLoad, @COL_AddressLoad, @COL_CityLoad, @COL_StateLoad, @COL_PostalCodeLoad, @COL_CountryLoad, @COL_LatitudeLoad, @COL_LongitudeLoad, @COL_LocationIdUnload, @COL_NameUnload, @COL_AddressUnload, @COL_CityUnload, @COL_StateUnload, @COL_PostalCodeUnload, @COL_CountryUnload, @COL_LatitudeUnload, @COL_LongitudeUnload, @COL_TieneLocation,@COL_UbicacionesXML
	
	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF @COL_IdEstatuViajeSalida = 0
			SET @COL_IdEstatuViajeSalida = NULL

		IF @COL_IdEstatuViajeLlegada = 0
			SET @COL_IdEstatuViajeLlegada = NULL
		
		IF ISNULL(@COL_Kilometros,0) <= 0	
		RAISERROR(N'El kilometraje del trayecto es un campo requerido',
			16,
			1
			)
				
		IF ISNULL(@COL_Horas,0) <= 0	
		RAISERROR(N'Las horas para el trayecto es un campo requerido',
			16,
			1
			)
			
		INSERT INTO CatRutasTrayectos(CreadoEl,CreadoPor,Horas,IdDestino,IdOrigen,IdRuta,Kilometros,RutaGoogleMap,Secuencia,
		SueldoBaseSencilloCargado,SueldoBaseSencilloVacio,SueldoBaseFullCargado,
		SueldoBaseFullVacio,SueldoBaseFullVacioCargado_CargadoVacio,
		SueldoBaseDllsSencilloCargado,SueldoBaseDllsSencilloVacio,SueldoBaseDllsFullCargado,
		SueldoBaseDllsFullVacio,SueldoBaseDllsFullVacioCargado_CargadoVacio,		
		IdGeocercaDisparaSalida,GeocercaDisparaSalidaES,IdGeocercaDisparaLlegada,GeocercaDisparaLlegadaES,IdEstatuViajeSalida,IdEstatuViajeLlegada,
		FactorLiqKmsSencilloCargado,FactorLiqKmsSencilloVacio,FactorLiqKmsFullCargado,FactorLiqKmsFullVacio,FactorLiqKmsFullVacioCargado_CargadoVacio,
		FactorLiqKmsDllsSencilloCargado,FactorLiqKmsDllsSencilloVacio,FactorLiqKmsDllsFullCargado,FactorLiqKmsDllsFullVacio,FactorLiqKmsDllsFullVacioCargado_CargadoVacio,TipoTrayecto,Millas,ETA)
		VALUES(@CreadoEl,@CreadoPor,@COL_Horas,@COL_IdDestino,@COL_IdOrigen,@IdRuta,@COL_Kilometros,@COL_RutaGoogleMap,@COL_Secuencia,
		@COL_SueldoBaseSencilloCargado,@COL_SueldoBaseSencilloVacio,@COL_SueldoBaseFullCargado,
		@COL_SueldoBaseFullVacio,@COL_SueldoBaseFullVacioCargado_CargadoVacio,
		@COL_SueldoBaseDllsSencilloCargado,@COL_SueldoBaseDllsSencilloVacio,@COL_SueldoBaseDllsFullCargado,
		@COL_SueldoBaseDllsFullVacio,@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,		
		@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,
		@COL_FactorLiqKmsSencilloCargado,@COL_FactorLiqKmsSencilloVacio,@COL_FactorLiqKmsFullCargado,@COL_FactorLiqKmsFullVacio,@COL_FactorLiqKmsFullVacioCargado_CargadoVacio,
		@COL_FactorLiqKmsDllsSencilloCargado,@COL_FactorLiqKmsDllsSencilloVacio,@COL_FactorLiqKmsDllsFullCargado,@COL_FactorLiqKmsDllsFullVacio,@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,@COL_TipoTrayecto,@COL_Millas,@COL_ETA)

		SET @IdRutaTrayecto = (SELECT IDENT_CURRENT('CatRutasTrayectos'))
		--Se agregó sección por la solicitud 12255 para insertar los valores de location en las rutas trayectos cuando retransmision de feight verify
		---------------------------------------------------------------------------------------------------
		IF @COL_TieneLocation = 1 
		BEGIN
			INSERT INTO CatRutasTrayectosLocation ( IdRutaTrayecto, LocationIdLoad, NameLoad, AddressLoad, CityLoad, StateLoad, PostalCodeLoad, CountryLoad, LatitudeLoad, LongitudeLoad, LocationIdUnload, NameUnload, AddressUnload, CityUnload, StateUnload, PostalCodeUnload, CountryUnload, LatitudeUnload, LongitudeUnload )
			VALUES( @IdRutaTrayecto, @COL_LocationIdLoad, @COL_NameLoad, @COL_AddressLoad, @COL_CityLoad, @COL_StateLoad, @COL_PostalCodeLoad, @COL_CountryLoad, @COL_LatitudeLoad,
			@COL_LongitudeLoad,@COL_LocationIdUnload,@COL_NameUnload, @COL_AddressUnload, @COL_CityUnload, @COL_StateUnload, @COL_PostalCodeUnload, @COL_CountryUnload, @COL_LatitudeUnload, @COL_LongitudeUnload)
		END
		---------------------------------------------------------------------------------------------------
		/*Seccion para agregar las ubicaciones para el complemento de carta porte*/
		----------------------------------------------
		IF @COL_UbicacionesXML <> ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_UbicacionesXML
			
			SELECT ATT_IdRemitente,ATT_FechaCarga,ATT_DatosRemitente,ATT_IdDestinatario,ATT_FechaEntrega,ATT_DatosDestinatario
			INTO #TempCatRutasTrayectosUbicaciones
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosUbicaciones',2) 
			WITH(ATT_IdRemitente int,ATT_FechaCarga datetime,ATT_DatosRemitente nvarchar(max),ATT_IdDestinatario int,ATT_FechaEntrega datetime,ATT_DatosDestinatario nvarchar(max))
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasTrayectosUbicaciones(IdRutaTrayecto,IdRemitente,FechaCarga,DatosRemitente,IdDestinatario,FechaEntrega,DatosDestinatario,UltimaFechaModificacion)
			SELECT @IdRutaTrayecto,ATT_IdRemitente,CASE WHEN ATT_FechaCarga = '' THEN NULL ELSE ATT_FechaCarga END,ATT_DatosRemitente,ATT_IdDestinatario,CASE WHEN ATT_FechaEntrega = '' THEN NULL ELSE ATT_FechaEntrega END,ATT_DatosDestinatario,@CreadoEl
			FROM #TempCatRutasTrayectosUbicaciones
			
			DROP TABLE #TempCatRutasTrayectosUbicaciones
		END
		-----------------------------------------------
		IF @COL_GastosAutorizados <> ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_GastosAutorizados
			
			SELECT ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_LitrosAutorizados,ATT_ImporteAutorizadoState,ATT_LitrosAutorizadosState,ATT_GalonesAutorizados
			INTO #TempCatRutasTrayectosGastos
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosGastos',2) 
			WITH(ATT_IdConceptoGastoViaje int,ATT_ImporteAutorizado money,ATT_LitrosAutorizados decimal(15,2),ATT_ImporteAutorizadoState int,ATT_LitrosAutorizadosState int,ATT_GalonesAutorizados decimal(15,2))
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasTrayectosGastos(IdRutaTrayecto,IdConceptoGastoViaje,ImporteAutorizado,ImporteAutorizadoState,LitrosAutorizados,LitrosAutorizadosState,CreadoEl,CreadoPor,GalonesAutorizados)
			SELECT @IdRutaTrayecto,ATT_IdConceptoGastoViaje,ATT_ImporteAutorizado,ATT_ImporteAutorizadoState,ATT_LitrosAutorizados,ATT_LitrosAutorizadosState,@CreadoEl,@CreadoPor,ATT_GalonesAutorizados
			FROM #TempCatRutasTrayectosGastos
			
			DROP TABLE #TempCatRutasTrayectosGastos
		END
		
		IF @COL_Geocercas <> ''
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Geocercas

			SELECT COL_IdEstatuViajeEntrar,COL_IdEstatuViajeSalir,COL_IdGeocerca
			INTO #TempCatRutasTrayectosGeocercas
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosGeocercas',2) 
			WITH(COL_IdEstatuViajeEntrar int,COL_IdEstatuViajeSalir int,COL_IdGeocerca int)
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasTrayectosGeocercas(IdRutaTrayecto,IdEstatuViajeEntrada,IdEstatuViajeSalida,IdGeocerca,CreadoEl,CreadoPor)
			SELECT @IdRutaTrayecto,
			CASE COL_IdEstatuViajeEntrar WHEN 0 THEN NULL ELSE COL_IdEstatuViajeEntrar END,
			CASE COL_IdEstatuViajeSalir WHEN 0 THEN NULL ELSE COL_IdEstatuViajeSalir END,
			COL_IdGeocerca,@CreadoEl,@CreadoPor
			FROM #TempCatRutasTrayectosGeocercas
			
			DROP TABLE #TempCatRutasTrayectosGeocercas
		END
		
		IF @COL_Casetas <> ''		
		BEGIN
			--se agrego en la solicitud 11783 los campos de nomenclaturasat y numero de ejes para usarlo cuando tenga ptv activado

			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Casetas
			
			SELECT ATT_IdCaseta,ATT_IdConceptoGastoViaje,ATT_Importe,
			ATT_NomenclaturaSCT,ATT_NumeroEjes
			INTO #TempCatRutasTrayectosCasetas
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasTrayectosCasetas',2) 
			WITH (ATT_IdCaseta int,ATT_IdConceptoGastoViaje int,ATT_Importe money,
			ATT_NomenclaturaSCT varchar(1),ATT_NumeroEjes tinyint)
			
			EXEC sp_xml_removedocument @docHandle
			
			INSERT INTO CatRutasTrayectosCasetas(CreadoEl,CreadoPor,IdRutaTrayecto,IdCaseta,IdConceptoGastoViaje,
			Importe,NomenclaturaSCT,NumeroEjes)
			SELECT @CreadoEl,@CreadoPor,@IdRutaTrayecto,ATT_IdCaseta,ATT_IdConceptoGastoViaje,
			ATT_Importe,ATT_NomenclaturaSCT,ATT_NumeroEjes
			FROM #TempCatRutasTrayectosCasetas			
			
			DROP TABLE #TempCatRutasTrayectosCasetas
		END

		--despues de agregar/modificar/eliminar las casetas autorizadas se valida
		--que los gastos autorizados de autopistas y autopistas iave sean igual a la suma de de las casetas autorizadas
		--solo si el modulo de ptv "NO esta contratado" esta seccion debe estar despues de casetas autorizadas y gastos autorizados
		--solicitud 11783
		IF @PTVContratado = 0
		BEGIN
			DECLARE @GastoAutorizado money,@CasetaAutorizado money,
			@GastoAutorizadoText nvarchar(20),@CasetaAutorizadoText nvarchar(20)

			--seccion para evaluar autopistas a contado IdConceptoGastoViaje = 3
			SET @GastoAutorizado = ISNULL((SELECT SUM(ImporteAutorizado) FROM CatRutasTrayectosGastos where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 3),0)
			SET @CasetaAutorizado = ISNULL((SELECT SUM(Importe) FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 3 AND ISNULL(NomenclaturaSCT,'') = '' AND ISNULL(NumeroEjes,0) = 0),0)

			IF @GastoAutorizado <> @CasetaAutorizado AND EXISTS(SELECT * FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 3)
			BEGIN
				SET @GastoAutorizadoText = CAST(@GastoAutorizado AS nvarchar(20))
				SET @CasetaAutorizadoText = CAST(@CasetaAutorizado AS nvarchar(20))
				RAISERROR(N'En el trayecto %d el importe autorizado para autopistas (contado/efectivo) $%s no coincide con la suma de los importes de las casetas a contado $%s',
					16,
					1,
					@COL_Secuencia,
					@GastoAutorizadoText,
					@CasetaAutorizadoText
					)
			END

			--seccion para evaluar autopistas a credito IdConceptoGastoViaje = 4
			SET @GastoAutorizado = ISNULL((SELECT SUM(ImporteAutorizado) FROM CatRutasTrayectosGastos where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 4),0)
			SET @CasetaAutorizado = ISNULL((SELECT SUM(Importe) FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 4 AND ISNULL(NomenclaturaSCT,'') = '' AND ISNULL(NumeroEjes,0) = 0),0)

			IF @GastoAutorizado <> @CasetaAutorizado AND EXISTS(SELECT * FROM CatRutasTrayectosCasetas where IdRutaTrayecto = @IdRutaTrayecto AND IdConceptoGastoViaje = 4)
			BEGIN
				SET @GastoAutorizadoText = CAST(@GastoAutorizado AS nvarchar(20))
				SET @CasetaAutorizadoText = CAST(@CasetaAutorizado AS nvarchar(20))
				RAISERROR(N'En el trayecto %d el importe autorizado para autopistas IAVE(crédito) $%s no coincide con la suma de los importes de las casetas a crédito $%s',
					16,
					1,
					@COL_Secuencia,
					@GastoAutorizadoText,
					@CasetaAutorizadoText
					)
			END
		END

		--Se registra los permisionarios por trayecto.
		IF @COL_Permisionarios<> ''	AND  @COL_Permisionarios<> '1'		
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_Permisionarios
			
			SELECT 	COL_SueldoBaseSencilloCargado,
					COL_SueldoBaseFullCargado,
					COL_SueldoBaseFullVacioCargado_CargadoVacio,
					COL_SueldoBaseSencilloVacio,
					COL_SueldoBaseFullVacio,
					COL_SueldoBaseDllsSencilloCargado,
					COL_SueldoBaseDllsFullCargado,
					COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,
					COL_SueldoBaseDllsSencilloVacio,
					COL_SueldoBaseDllsFullVacio,
					COL_IdOperador,
					COL_PorcentajeComisionPermisionario,	
					COL_CuotaPorKilometro,
					COL_CuotaDiaria,
					COL_ImporteSeguro
			INTO #TempCatRutasTrayectosPermisionarios
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatRutasTrayectosPermisionarios',2) 
			WITH ( COL_SueldoBaseSencilloCargado money,
				   COL_SueldoBaseFullCargado money,
				   COL_SueldoBaseFullVacioCargado_CargadoVacio money,
				   COL_SueldoBaseSencilloVacio money,
				   COL_SueldoBaseFullVacio money,
				   COL_SueldoBaseDllsSencilloCargado money,
				   COL_SueldoBaseDllsFullCargado money,
				   COL_SueldoBaseDllsFullVacioCargado_CargadoVacio money,
				   COL_SueldoBaseDllsSencilloVacio money,
				   COL_SueldoBaseDllsFullVacio money,
				   COL_IdOperador int,
				   COL_PorcentajeComisionPermisionario int,	
				   COL_CuotaPorKilometro money,
				   COL_CuotaDiaria money,
				   COL_ImporteSeguro money )
			
			EXEC sp_xml_removedocument @docHandle

			INSERT INTO CatRutasTrayectosPermisionarios(CreadoEl,CreadoPor,IdRutaTrayecto,IdOperador,SueldoBaseFullCargado,SueldoBaseFullVacio,
					SueldoBaseFullVacioCargado_CargadoVacio,SueldoBaseSencilloCargado,SueldoBaseSencilloVacio,SueldoBaseDllsFullCargado,
					SueldoBaseDllsFullVacio,SueldoBaseDllsFullVacioCargado_CargadoVacio,SueldoBaseDllsSencilloCargado,SueldoBaseDllsSencilloVacio,
					PorcentajeComisionPermisionario,CuotaPorKilometro,CuotaDiaria,ImporteSeguro )
			SELECT @CreadoEl,@CreadoPor,@IdRutaTrayecto,COL_IdOperador,COL_SueldoBaseFullCargado,COL_SueldoBaseFullVacio,
				   COL_SueldoBaseFullVacioCargado_CargadoVacio,COL_SueldoBaseSencilloCargado,COL_SueldoBaseSencilloVacio,
				   COL_SueldoBaseDllsFullCargado,COL_SueldoBaseDllsFullVacio,COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,
				   COL_SueldoBaseDllsSencilloCargado,COL_SueldoBaseDllsSencilloVacio,COL_PorcentajeComisionPermisionario,
				   COL_CuotaPorKilometro,COL_CuotaDiaria,COL_ImporteSeguro 
			FROM #TempCatRutasTrayectosPermisionarios		
			
			DROP TABLE #TempCatRutasTrayectosPermisionarios
		END
		/*SOLICITUD 4208*/
		INSERT INTO CatRutasTrayectosDistribucionConceptosFacturacion(IdRutaTrayecto,IdConceptoFacturacion,Secuencia,Importe,ImporteDlls,UltimaModificacion)
		SELECT 
		@IdRutaTrayecto
		,COL_IdConceptoFacturacion
		,COL_Secuencia
		,COL_Importe
		,COL_ImporteDlls
		,@CreadoEl
		FROM @TempCatRutasTrayectosDistribucionConceptosFacturacion
		WHERE COL_Secuencia = @COL_Secuencia
		/*SOLICITUD 4208*/

		FETCH NEXT FROM CursorCatRutasTrayectos
		INTO @COL_Secuencia,@COL_IdOrigen,@COL_IdDestino,@COL_Kilometros,@COL_Horas,@COL_RutaGoogleMap,@COL_GastosAutorizados,
		@COL_SueldoBaseSencilloCargado,@COL_SueldoBaseSencilloVacio,@COL_SueldoBaseFullCargado,
		@COL_SueldoBaseFullVacio,@COL_SueldoBaseFullVacioCargado_CargadoVacio,
		@COL_SueldoBaseDllsSencilloCargado,@COL_SueldoBaseDllsSencilloVacio,@COL_SueldoBaseDllsFullCargado,
		@COL_SueldoBaseDllsFullVacio,@COL_SueldoBaseDllsFullVacioCargado_CargadoVacio,		
		@COL_IdGeocercaDisparaSalida,@COL_GeocercaDisparaSalidaES,@COL_IdGeocercaDisparaLlegada,@COL_GeocercaDisparaLlegadaES,@COL_Geocercas,
		@COL_IdEstatuViajeSalida,@COL_IdEstatuViajeLlegada,@COL_FactorLiqKmsSencilloCargado,@COL_FactorLiqKmsSencilloVacio,@COL_FactorLiqKmsFullCargado,
		@COL_FactorLiqKmsFullVacio,@COL_FactorLiqKmsFullVacioCargado_CargadoVacio,@COL_Casetas,
		@COL_FactorLiqKmsDllsSencilloCargado,@COL_FactorLiqKmsDllsSencilloVacio,@COL_FactorLiqKmsDllsFullCargado,
		@COL_FactorLiqKmsDllsFullVacio,@COL_FactorLiqKmsDllsFullVacioCargado_CargadoVacio,@COL_Permisionarios,@COL_TipoTrayecto,@COL_Millas,@COL_ETA, @COL_LocationIdLoad, @COL_NameLoad, @COL_AddressLoad, @COL_CityLoad, @COL_StateLoad, @COL_PostalCodeLoad, @COL_CountryLoad, @COL_LatitudeLoad, @COL_LongitudeLoad, @COL_LocationIdUnload, @COL_NameUnload, @COL_AddressUnload, @COL_CityUnload, @COL_StateUnload, @COL_PostalCodeUnload, @COL_CountryUnload, @COL_LatitudeUnload, @COL_LongitudeUnload, @COL_TieneLocation,@COL_UbicacionesXML
		

	END

	CLOSE CursorCatRutasTrayectos
	DEALLOCATE CursorCatRutasTrayectos						
		
	--AGREGA LOS CONCEPTOS DE FACTURACION	
	IF @dsCatRutasConceptosFacturacion IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasConceptosFacturacion

		SELECT COL_IdConceptoFacturacion,COL_Importe,COL_ImporteDlls,COL_IdTipoViaje,COL_IdTipoUnidad,COL_IdClasificacionViaje,COL_IdImpuestoTrasladado,COL_IdImpuestoRetenido,COL_Traslada,COL_Retiene
		INTO #TempCatRutasConceptosFacturacion
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasConceptosFacturacion',2) 
		WITH (COL_IdConceptoFacturacion int,COL_Importe money,COL_ImporteDlls money,COL_IdTipoViaje int,COL_IdTipoUnidad int,COL_IdClasificacionViaje int,COL_IdImpuestoTrasladado int,COL_IdImpuestoRetenido int,COL_Traslada bit ,COL_Retiene bit)
		
		EXEC sp_xml_removedocument @docHandle
		
		DECLARE CursorCatRutasConceptosFacturacion CURSOR LOCAL FOR
		SELECT * FROM #TempCatRutasConceptosFacturacion
		
		OPEN CursorCatRutasConceptosFacturacion
		FETCH NEXT FROM CursorCatRutasConceptosFacturacion
		INTO @CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @CursorIdTipoViaje = 0
				SET	@CursorIdTipoViaje = NULL

			IF @CursorIdTipoUnidad = 0
				SET	@CursorIdTipoUnidad = NULL

			IF @CursorIdClasificacionViaje = 0
				SET	@CursorIdClasificacionViaje = NULL
								
			INSERT INTO CatRutasConceptosFacturacion(CreadoEl,CreadoPor,IdConceptoFacturacion,IdRuta,
			Importe,ImporteDlls,IdTipoViaje,IdTipoUnidad,IdClasificacionViaje,TrasladaImpuesto,RetieneImpuesto)
			VALUES(@CreadoEl,@CreadoPor,@CursorIdConceptoFacturacion,@IdRuta,
			@CursorImporte,@CursorImporteDlls,@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@CursorTraslada,@CursorRetiene)

			SET @IdRutaConceptoFacturacion = (SELECT IDENT_CURRENT('CatRutasConceptosFacturacion'))

			IF @IdImpuestoTrasladado > 0
			BEGIN
				INSERT INTO CatRutasConceptosFacturacionImpuestos(IdRutaConceptoFacturacion,IdImpuesto)
				VALUES( @IdRutaConceptoFacturacion,@IdImpuestoTrasladado )
			END

			IF @IdImpuestoRetenido > 0
			BEGIN
				INSERT INTO CatRutasConceptosFacturacionImpuestos(IdRutaConceptoFacturacion,IdImpuesto)
				VALUES( @IdRutaConceptoFacturacion,@IdImpuestoRetenido )
			END
		
			FETCH NEXT FROM CursorCatRutasConceptosFacturacion
			INTO @CursorIdConceptoFacturacion,@CursorImporte,@CursorImporteDlls,@CursorIdTipoViaje,@CursorIdTipoUnidad,@CursorIdClasificacionViaje,@IdImpuestoTrasladado,@IdImpuestoRetenido,@CursorTraslada,@CursorRetiene
		END

		CLOSE CursorCatRutasConceptosFacturacion
		DEALLOCATE CursorCatRutasConceptosFacturacion						
	END
	
	--AGREGA LAS DESCRIPCION/MATERIALES
	IF @dsCatRutasDescripcionesCargaTarifas IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasDescripcionesCargaTarifas

		SELECT COL_DescripcionCarga,COL_IdUnidadMedidaEmbalaje,COL_IdUnidadMedidaPeso,COL_Tarifa,COL_AplicarTarifaPor,COL_TarifaDlls,COL_ImporteBaseLiquidacion,COL_ClavesSatXML
		INTO #TempCatRutasDescripcionesCargaTarifas
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasDescripcionesCargaTarifas',2) 
		WITH (COL_DescripcionCarga varchar(1024),COL_IdUnidadMedidaEmbalaje int,COL_IdUnidadMedidaPeso int,COL_Tarifa float,COL_AplicarTarifaPor tinyint,COL_TarifaDlls float,COL_ImporteBaseLiquidacion float,COL_ClavesSatXML varchar(max))

		EXEC sp_xml_removedocument @docHandle		

		DECLARE CursorCatRutasDescripcionesCargaTarifas CURSOR LOCAL FOR
		SELECT * FROM #TempCatRutasDescripcionesCargaTarifas
		
		OPEN CursorCatRutasDescripcionesCargaTarifas
		FETCH NEXT FROM CursorCatRutasDescripcionesCargaTarifas
		INTO @CursorDescripcionCarga,@CursorIdUnidadMedidaEmbalaje,@CursorIdUnidadMedidaPeso,@CursorTarifa,@CursorAplicarTarifaPor,@CursorTarifaDlls,@CursorImporteBaseLiquidacion,@COL_ClavesSatXML
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			INSERT INTO CatRutasDescripcionesCargaTarifas(AplicarTarifaPor,CreadoEl,CreadoPor,DescripcionCarga,IdRuta,IdUnidadMedidaEmbalaje,IdUnidadMedidaPeso,Tarifa,TarifaDlls,ImporteBaseLiquidacion)
			VALUES(@CursorAplicarTarifaPor,@CreadoEl,@CreadoPor,@CursorDescripcionCarga,@IdRuta,@CursorIdUnidadMedidaEmbalaje,@CursorIdUnidadMedidaPeso,@CursorTarifa,@CursorTarifaDlls,@CursorImporteBaseLiquidacion)
			
			SET @IdRutaDescripcionCarga = (SELECT IDENT_CURRENT('CatRutasDescripcionesCargaTarifas'))

			--Seccion para las claves del sat de los materiales
			IF ISNULL(@COL_ClavesSatXML,'') <> ''
				BEGIN
					EXEC sp_xml_preparedocument @docHandle OUTPUT, @COL_ClavesSatXML
					SELECT
						 @IdRutaDescripcionCarga AS ATT_IdRutaDescripcionCarga
						,ATT_ClaveSAT
						,ATT_DescripcionSAT
						,ATT_CatalogoSAT
						,ATT_Opcional
					INTO #TempCatRutasDescripcionesCargaTarifasClavesSAT
					FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasDescripcionesCargaTarifasClavesSAT',2) 
					WITH (
						 ATT_IdRutaDescripcionCarga int
						,ATT_ClaveSAT varchar(10)
						,ATT_DescripcionSAT varchar(max)
						,ATT_CatalogoSAT varchar(50)
						,ATT_Opcional nvarchar(100))

			
					EXEC sp_xml_removedocument @docHandle

					INSERT INTO CatRutasDescripcionesCargaTarifasClavesSAT(IdRutaDescripcionCarga,ClaveSAT,CatalogoSAT,Opcional,UltimaModificacion)
					SELECT 
					ATT_IdRutaDescripcionCarga
				   ,ATT_ClaveSAT 
				   ,ATT_CatalogoSAT 
				   ,ATT_Opcional 
				   ,GETDATE()
					FROM #TempCatRutasDescripcionesCargaTarifasClavesSAT

					DROP TABLE #TempCatRutasDescripcionesCargaTarifasClavesSAT
				END


			FETCH NEXT FROM CursorCatRutasDescripcionesCargaTarifas
			INTO @CursorDescripcionCarga,@CursorIdUnidadMedidaEmbalaje,@CursorIdUnidadMedidaPeso,@CursorTarifa,@CursorAplicarTarifaPor,@CursorTarifaDlls,@CursorImporteBaseLiquidacion,@COL_ClavesSatXML
		END

		CLOSE CursorCatRutasDescripcionesCargaTarifas
		DEALLOCATE CursorCatRutasDescripcionesCargaTarifas								
	END

	IF @dsCatRutasClienteContactos IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasClienteContactos
		
		SELECT ATT_IdClienteContacto
		INTO #TempCatRutasClienteContactos
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_CatRutasClienteContactos',2) 
		WITH (ATT_IdClienteContacto int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatRutasClientesContactos(CreadoEl,CreadoPor,IdRuta,IdClienteContacto)
		SELECT @CreadoEl,@CreadoPor,@IdRuta,ATT_IdClienteContacto
		FROM #TempCatRutasClienteContactos
	END	
	
	--AGREGA LAS TARIFAS MATERIALES PEMEX -- SOLICITUD 902
	IF @dsCatRutasTarifasMaterialesPemex IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasTarifasMaterialesPemex

		SELECT COL_IdMaterialPemex,COL_Tarifa,COL_Peaje5,COL_Peaje6,COL_Peaje9,COL_SueldoBaseSencillo,COL_SueldoBaseFull,COL_ComisionSencillo,COL_ComisionFull
		INTO #TempCatRutasTarifasMaterialesPemex
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasTarifasMaterialesPemex',2) 
		WITH (COL_IdMaterialPemex int,COL_Tarifa money,COL_Peaje5 money,COL_Peaje6 money,COL_Peaje9 money,COL_SueldoBaseSencillo money,COL_SueldoBaseFull money,COL_ComisionSencillo money,COL_ComisionFull money)

		EXEC sp_xml_removedocument @docHandle		

		DECLARE CursorCatRutasTarifasMaterialesPemex CURSOR LOCAL FOR
		SELECT * FROM #TempCatRutasTarifasMaterialesPemex
		
		OPEN CursorCatRutasTarifasMaterialesPemex
		FETCH NEXT FROM CursorCatRutasTarifasMaterialesPemex
		INTO @CursorIdMaterialPemex,@CursorTarifaPemex,@CursorPeaje5Pemex,@CursorPeaje6Pemex,@CursorPeaje9Pemex,@CursorSueldoBaseSencilloPemex,@CursorSueldoBaseFullPemex,@CursorComisionSencilloPemex,@CursorComisionFullPemex
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			INSERT INTO CatRutasTarifasMateriales(IdRuta,IdMaterialPemex,CreadoEl,CreadoPor,Tarifa,Peaje5,Peaje6,Peaje9,SueldoBaseSencillo,SueldoBaseFull,ComisionSencillo,ComisionFull)
			VALUES(@IdRuta,@CursorIdMaterialPemex,@CreadoEl,@CreadoPor,@CursorTarifaPemex,@CursorPeaje5Pemex,@CursorPeaje6Pemex,@CursorPeaje9Pemex,@CursorSueldoBaseSencilloPemex,@CursorSueldoBaseFullPemex,@CursorComisionSencilloPemex,@CursorComisionFullPemex)
		
			FETCH NEXT FROM CursorCatRutasTarifasMaterialesPemex
			INTO @CursorIdMaterialPemex,@CursorTarifaPemex,@CursorPeaje5Pemex,@CursorPeaje6Pemex,@CursorPeaje9Pemex,@CursorSueldoBaseSencilloPemex,@CursorSueldoBaseFullPemex,@CursorComisionSencilloPemex,@CursorComisionFullPemex
		END

		CLOSE CursorCatRutasTarifasMaterialesPemex
		DEALLOCATE CursorCatRutasTarifasMaterialesPemex								
	END
	
	COMMIT
END TRY
BEGIN CATCH
	 --Se cierran los cursores
	 IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasTrayectos')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','')) > -1
		BEGIN
			CLOSE CursorCatRutasTrayectos
		END
	  DEALLOCATE CursorCatRutasTrayectos
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasConceptosFacturacion')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasConceptosFacturacion')) > -1
		BEGIN
			CLOSE CursorCatRutasConceptosFacturacion
		END
	  DEALLOCATE CursorCatRutasConceptosFacturacion
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasDescripcionesCargaTarifas')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasDescripcionesCargaTarifas')) > -1
		BEGIN
			CLOSE CursorCatRutasDescripcionesCargaTarifas
		END
	  DEALLOCATE CursorCatRutasDescripcionesCargaTarifas
	  END

	   IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasTarifasMaterialesPemex')) >= -1
	  BEGIN
		IF (SELECT CURSOR_STATUS('LOCAL','CursorCatRutasTarifasMaterialesPemex')) > -1
		BEGIN
			CLOSE CursorCatRutasTarifasMaterialesPemex
		END
	  DEALLOCATE CursorCatRutasTarifasMaterialesPemex
	  END

	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

