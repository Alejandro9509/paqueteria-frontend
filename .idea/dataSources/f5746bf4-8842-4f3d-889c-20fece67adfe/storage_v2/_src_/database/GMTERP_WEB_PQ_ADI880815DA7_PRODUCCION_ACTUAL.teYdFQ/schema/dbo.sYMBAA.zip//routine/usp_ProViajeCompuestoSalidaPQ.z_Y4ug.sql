

CREATE PROCEDURE [dbo].[usp_ProViajeCompuestoSalidaPQ](	
	@IdViaje int,
	@Salida datetime
	)
AS
BEGIN
	BEGIN TRANSACTION

	DECLARE @IdViajeTrayecto int;
	DECLARE @IdEstatusViaje int;
	DECLARE @IdViajeHijo int;

	IF @@TRANCOUNT > 0
			BEGIN

			set @IdEstatusViaje=3;--TRANSITO

			update ProViajesTrayectos set Salida=@Salida where IdViaje=@IdViaje;
			update ProViajes set IdEstatuViaje=@IdEstatusViaje where IdViaje=@IdViaje;

			DECLARE ProdTrayectos CURSOR FOR select pvt.IdViajeTrayecto,pvt.IdViaje from ProViajesTrayectos pvt
										inner join ProViajes pv on pv.IdViaje=pvt.IdViaje
										where pv.IdViajeCompuestoPadre=@IdViaje
				OPEN ProdTrayectos
					FETCH NEXT FROM ProdTrayectos INTO @IdViajeTrayecto,@IdViajeHijo
					WHILE @@fetch_status = 0
					BEGIN
    
						update ProViajesTrayectos set Salida=@Salida where IdViajeTrayecto=@IdViajeTrayecto;
						update ProViajes set IdEstatuViaje=@IdEstatusViaje where IdViaje=@IdViajeHijo;

						FETCH NEXT FROM ProdTrayectos INTO @IdViajeTrayecto,@IdViajeHijo
					END
				CLOSE ProdTrayectos
				DEALLOCATE ProdTrayectos

			

				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfo;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

