CREATE  PROCEDURE [dbo].[usp_ProMovimientosBancariosTraspasosModificar]  
	@IdMovimientoBancarioTraspaso int,
	@IdMovimientoBancarioOrigen int,  
	@IdCuentaBancariaOrigen int,  
	@IdMovimientoBancarioDestino int,  
	@IdCuentaBancariaDestino int,  
	@Fecha datetime,  
	@TipoCambio money ,  
	@Importe money ,  
	@ReferenciaBancaria varchar(150),  
	@ModificadoPor int,  
	@ModificadoEl datetime,  
	@IdPeticion varchar(100),
	@ImporteDestino money,
	@TipoPago INT,
	@FechaCobro datetime

/* *************************************************************************************************
Procedimiento usp_ProMovimientosBancariosTraspasosModificar

Parámetros: 
	@IdMovimientoBancarioTraspaso (entrada, entero). Identificador del traspaso
	@IdMovimientoBancarioOrigen (entrada, entero). Identificador de la cuenta origen
	@IdCuentaBancariaOrigen (entrada, entero). Identificador de la cuenta bancaria origen
	@IdMovimientoBancarioDestino (entrada, entero). Identificador de la cuenta destino 
	@IdCuentaBancariaDestino (entrada, entero). Identificador de la cuenta destino
	@Fecha (entrada, Fecha). Fecha del traspaso  
	@TipoCambio (entrada, moneda). Tipo de cambio
	@Importe (entrada, moneda). Importe del traspaso
	@ReferenciaBancaria (entrada, texto). Referencia del traspaso 
	@ModificadoPor (entrada, entero). Usuario que modifica
	@ModificadoEl (entrada, fecha hora). Fecha y hora de modificacion
	@IdPeticion (entrada, string). Id de la Petición, generada en WEBDEV
	@ImporteDestino (entrada, moneda). Importe del traspaso destino
	@TipoPago (entrada, entero). Tipo de pago
	@FechaCobro (entrada, fecha). Fecha de cobro

Descripción: Procedimiento para modificar un traspaso

06/11/2020 - Se agrego el flujo de asignarle una fecha de cobro a los movimientos bancarios y cheques

Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 06/11/2020
Versión ERP: 8.0.56.12

Invocada desde: PAGE_ProMovimientosBancariosTraspasosRM (Solicitud 3393)
***************************************************************************************************** */
AS  
DECLARE     
	@IdMonedaOrigen int,   
	@IdMonedaDestino int,  
	@IdDolar int   
BEGIN TRY  
	BEGIN TRANSACTION  

	SET @IdDolar = 2  
	IF ISNULL(@IdCuentaBancariaOrigen,0)= 0  
	RAISERROR(N'El identificador de cuenta bancaria origen es un campo requerido', 16, 1)  
  
	IF ISNULL(@IdCuentaBancariaDestino,0)= 0  
	RAISERROR(N'El identificador de cuenta bancaria origen es un campo requerido', 16, 1)  
 
	IF @IdCuentaBancariaOrigen = @IdCuentaBancariaDestino   
	RAISERROR(N'Las cuentas no pueden ser iguales', 16, 1)  
      
	IF ISNULL(@Fecha,'')= ''  
	RAISERROR(N'Fecha es un campo requerido', 16, 1)  

	IF ISNULL(@FechaCobro,'')= ''  
	RAISERROR(N'Fecha de cobro es un campo requerido', 16, 1) 
  
	IF ISNULL(@TipoCambio,0)= 0  
	RAISERROR(N'Tipo de cambio es un campo requerido', 16, 1)  
   
	IF ISNULL(@ReferenciaBancaria,'')= ''  
	RAISERROR(N'El Referencia bancaria es un campo requerido', 16, 1)  
  
	IF ISNULL(@Importe,0)= 0  
	RAISERROR(N'El Importe es un campo requerido', 16, 1)  
  
	--- Modificar Movimiento Bancario Traspaso Origen  
	SET @IdMonedaOrigen =(SELECT IdMoneda FROM CatCuentasBancarias WHERE  CatCuentasBancarias.IdCuentaBancaria =@IdCuentaBancariaOrigen)  
	UPDATE ProMovimientosBancarios 
			SET Fecha = @Fecha,
			Importe = @Importe,
			TipoCambio = @TipoCambio ,
			ReferenciaBancaria = @ReferenciaBancaria,
			ModificadoPor = @ModificadoPor,
			ModificadoEl = @ModificadoEl,
			FechaCobro = @FechaCobro
	WHERE  ProMovimientosBancarios.IdMovimientoBancario =  @IdMovimientoBancarioOrigen 		
 
		--- Modificar Movimiento Bancario Traspaso Destino 
  
	UPDATE ProMovimientosBancarios
	SET Fecha = @Fecha,
		Importe = @ImporteDestino,
		TipoCambio =@TipoCambio,
		ReferenciaBancaria = @ReferenciaBancaria,
		ModificadoPor= @ModificadoPor,
		ModificadoEl= @ModificadoEl,
		FechaCobro = @FechaCobro
	WHERE  ProMovimientosBancarios.IdMovimientoBancario =  @IdMovimientoBancarioDestino
   
	SET @IdMovimientoBancarioDestino= (SELECT IDENT_CURRENT('ProMovimientosBancarios'))       
   
		--- Se Modificar translado  
	UPDATE ProMovimientosBancariosTraspasos 
	SET ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor,
		TipoPago = @TipoPago
	WHERE ProMovimientosBancariosTraspasos.IdMovimientoBancarioTraspaso= @IdMovimientoBancarioTraspaso

	COMMIT  
END TRY  
BEGIN CATCH  
	ROLLBACK  
	EXECUTE usp_SisErrorsGrabar @IdPeticion  
END CATCH
go

