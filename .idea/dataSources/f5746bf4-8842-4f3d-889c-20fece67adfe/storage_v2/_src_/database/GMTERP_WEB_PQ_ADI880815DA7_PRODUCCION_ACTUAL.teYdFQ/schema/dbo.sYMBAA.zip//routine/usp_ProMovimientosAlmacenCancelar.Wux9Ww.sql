CREATE PROCEDURE [dbo].[usp_ProMovimientosAlmacenCancelar]
@IdMovimientoAlmacen int,
@MotivoCancelacion varchar(500),
@CanceladoEl datetime,
@CanceladoPor int,
@IdPeticion varchar(100),
@UltimaModificacion datetime,
@EsTraspaso bit = 0 -- se agrego por parte de la solicitud 171


	/*
	SOLICITUD 1681

	Descripcion: Se incluyó el campo Observaciones al insertar en la tabla ProMoimientosAlmacenConceptos, ya que se estaba 
				 omitiendo

	Modificada por:   Julio Hermosillo
	Fecha de mofidicacion: 15/05/2020
	Versión: Versión Versión 8.0.52.11

	Invocada desde: <PAGE_ProMovimientosAlmacenEntradaCancelar>
	************************************************************************************************ */

 	/* *************************************************************************************************
	SOLICITUD 601

	Descripcion: Se modifico el rollback para que ahora se ejecute correctamente al aplicar
	el trigger de bloqueo ubicado en ProMovimientosAlmacenConceptos
	
	Modificada por:   Amado Navarro
	Fecha de mofidicacion: 15/11/2019
	Versión: Versión 8.0.47.47

	Invocada desde: <PAGE_ProMovimientosAlmacenEntradaCancelar>
	************************************************************************************************ */

	/* *************************************************************************************************
	SOLICITUD 103

	Descripcion: se quito la validacion para que no permita cancelar movimientos si contiene articulos de tipo llanta,
				 Se agrego para que borre los numeros economicos una ves cancelado el movimiento

	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 26/08/2019
	Versión: Versión Versión 8.0.45.32

	Invocada desde: <PAGE_ProMovimientosAlmacenEntradaCancelar>
	************************************************************************************************ */
		/* *************************************************************************************************
	SOLICITUD 171

	Descripcion: 

	Modificada por:   Ignacio Perez
	Fecha de mofidicacion: 25/09/2019
	Versión: Versión 8.0.46.21

	Invocada desde: <PAGE_ProMovimientosAlmacenTraspasosCancelar>
	************************************************************************************************ */

AS
DECLARE
@IdTipoMovimientoAlmacen int,
@TipoMovimiento int,
@FolioMovimientoAlmacen  int,
@IdMovimientoAlmacenSalida int,
@ExistenciaActual decimal(15,4),
@ImporteTotalPromedioActual money,
@ImporteTotalPromedioActualDlls money,
@CostoPromedioActual money,
@CostoPromedioActualDlls money,
@EsLlanta bit,
@IdArticuloLlanta int
BEGIN TRY
	BEGIN TRANSACTION
	
	SET @ExistenciaActual = 0
	SET @ImporteTotalPromedioActual = 0
	SET @CostoPromedioActual  = 0
	SET @ImporteTotalPromedioActualDlls = 0
	SET @CostoPromedioActualDlls  = 0	
	SET @TipoMovimiento = 1 -- Entrada
	
	IF ISNULL(@IdMovimientoAlmacen,0) = 0
		RAISERROR(N'El identificador del movimiento de almacén es un campo requerido',
			16,
			1
			)
	
	IF ISNULL(@MotivoCancelacion,'')='' 
			RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)	
	
	IF ISDATE(@CanceladoEl)=0 
			RAISERROR(N'La fecha de cancelación es un campo requerido',
			16,
			1
			)	
	
	IF (SELECT ModificadoEl FROM ProMovimientosAlmacen WHERE IdMovimientoAlmacen= @IdMovimientoAlmacen) <> @UltimaModificacion
			RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)
							
	-- Valida que el movimiento  no este cancelada		
	IF (SELECT CanceladoEl FROM ProMovimientosAlmacen WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen) IS NOT NULL --cancelado
		RAISERROR(N'No puede cancelar este movimiento porque está cancelada',
			16,
			1
			)			

	-- Valida tipo de  movimiento sea de entrada
	IF ISNULL((SELECT  CatTiposMovimientosAlmacen.Tipo FROM ProMovimientosAlmacen INNER JOIN
				CatTiposMovimientosAlmacen ON ProMovimientosAlmacen.IdTipoMovimientoAlmacen = CatTiposMovimientosAlmacen.IdTipoMovimientoAlmacen
				WHERE    ProMovimientosAlmacen.IdMovimientoAlmacen =  @IdMovimientoAlmacen),0) <> @TipoMovimiento 
		RAISERROR(N'El tipo de movimiento debe ser entrada al almacén',
			16,
			1
			)		 
	
	-- Valida que movimiento de entrada al almacén no tenga salidas registradas
	IF @EsTraspaso = 0
	IF EXISTS(SELECT   TOP 1  ProMovimientosAlmacen.IdMovimientoAlmacen
					FROM         ProMovimientosAlmacen INNER JOIN
										  ProMovimientosAlmacenConceptos ON ProMovimientosAlmacen.IdMovimientoAlmacen = ProMovimientosAlmacenConceptos.IdMovimientoAlmacen INNER JOIN
										  CatTiposMovimientosAlmacen ON ProMovimientosAlmacen.IdTipoMovimientoAlmacen = CatTiposMovimientosAlmacen.IdTipoMovimientoAlmacen INNER JOIN
										  ProMovimientosAlmacenConceptosPEPS ON 
										  ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto = ProMovimientosAlmacenConceptosPEPS.IdMovimientoAlmacenConceptoEntrada
					WHERE     (ProMovimientosAlmacen.IdMovimientoAlmacen = @IdMovimientoAlmacen))
			RAISERROR(N'El movimiento de entrada al almacén ya tiene salidas registradas',
				16,
				1
				)
			
	-- Valida que el movimiento no sea por entrada por traspaso
	IF @EsTraspaso = 0 -- que no entre a esta validacion si @EsTraspaso = 1
	IF EXISTS(SELECT  IdMovimientoAlmacenEntrada FROM ProMovimientosAlmacenTraspasos WHERE  IdMovimientoAlmacenEntrada =@IdMovimientoAlmacen)
			RAISERROR(N'El movimiento de entrada al almacén pertence a un movimiento por traspaso',
					16,
					1
					)
					
	-- Valida que la fecha de cancelación no sea menor que la fecha de elaboración
	IF (SELECT FechaHora FROM ProMovimientosAlmacen WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen) > @CanceladoEl
				RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de elaboración',
					16,
					1
					)
	-- Valida que el movimiento de entrada a almacén no sea de compras
	IF ISNULL((SELECT IdCompra FROM ProMovimientosAlmacen where IdMovimientoAlmacen = @IdMovimientoAlmacen),0)<>0
				RAISERROR(N'El movimiento de entrada al almacén pertence a un movimiento por compra',
					16,
					1
					)	
     
 
	-- Valida que el movimiento de entrada a almacén no sea por devolución de partes de la orden de servicio
	IF EXISTS(SELECT     ProMovimientosAlmacen.IdMovimientoAlmacen, ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto
				FROM         ProMovimientosAlmacen INNER JOIN
									  ProMovimientosAlmacenConceptos ON ProMovimientosAlmacen.IdMovimientoAlmacen = ProMovimientosAlmacenConceptos.IdMovimientoAlmacen INNER JOIN
									  ProOrdenesServiciosPartesDevolucionPEPS ON ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto = ProOrdenesServiciosPartesDevolucionPEPS.IdMovimientoAlmacenConcepto
				 WHERE     (ProMovimientosAlmacen.IdMovimientoAlmacen = @IdMovimientoAlmacen))
				RAISERROR(N'El movimiento de entrada al almacén pertence a un movimiento por devolución de partes de orden de servicio',
					16,
					1
					)
	
	
	-- Valida que la entrada al almacen no sea por devolución
	
	IF EXISTS(SELECT    CatTiposMovimientosAlmacen.Codigo
		FROM      ProMovimientosAlmacen INNER JOIN
            CatTiposMovimientosAlmacen 
        ON ProMovimientosAlmacen.IdTipoMovimientoAlmacen = CatTiposMovimientosAlmacen.IdTipoMovimientoAlmacen
        WHERE  CatTiposMovimientosAlmacen.Codigo= 11 and ProMovimientosAlmacen.IdMovimientoAlmacen = @IdMovimientoAlmacen)
  				RAISERROR(N'No puede cancelar este movimiento porque pertenece a un movimiento de entrada por devolución',
					16,
					1
					)

	-- Valida que la entrada al almacen no sea por devolución
	
	IF EXISTS(SELECT    CatTiposMovimientosAlmacen.Codigo
		FROM      ProMovimientosAlmacen INNER JOIN
            CatTiposMovimientosAlmacen 
        ON ProMovimientosAlmacen.IdTipoMovimientoAlmacen = CatTiposMovimientosAlmacen.IdTipoMovimientoAlmacen
        WHERE  CatTiposMovimientosAlmacen.Codigo= 18 and ProMovimientosAlmacen.IdMovimientoAlmacen = @IdMovimientoAlmacen)
  				RAISERROR(N'No puede cancelar este movimiento porque pertenece a un movimiento de entrada por devolución de orden de servicio',
					16,
					1
					)	
					                    
	-- Tipo Movimiento almacen [11] = Entrada por Devolución.
	If @EsTraspaso = 0 --Si no es traspaso el flujo se comporta de forma normal
		SELECT @IdTipoMovimientoAlmacen = IdTipoMovimientoAlmacen FROM CatTiposMovimientosAlmacen WHERE Codigo = 11
	ELSE -- Si es un traspaso se obtendra el id mediante el movimiento llamado 'ENTRADA POR DEVOLUCION TRASPASO' y que sea definido por el sistema
		SELECT @IdTipoMovimientoAlmacen = IdTipoMovimientoAlmacen FROM CatTiposMovimientosAlmacen WHERE Movimiento = 'ENTRADA POR DEVOLUCION TRASPASO' AND DefinidoPorSistema = 1
	
	SET @FolioMovimientoAlmacen  = (SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProMovimientosAlmacen)
		
	-- Registrar salida por devolución
	INSERT INTO ProMovimientosAlmacen(
				Estatus,
				FechaHora,
				IdProveedor,
				Folio,
				IdMoneda,
				Observaciones,
				SubTotal,
				SubTotalDlls,
				TipoCambio,
				Total,
				TotalDlls,
				IdImpuestosTrasladadosFederales,
				ImpuestosTrasladadosFederales,
				ImpuestosTrasladadosFederalesDlls,
				IdImpuestosRetenidosFederales,
				ImpuestosRetenidosFederales,
				ImpuestosRetenidosFederalesDlls,
				IdImpuestosTrasladadosLocales,
				ImpuestosTrasladadosLocales,
				ImpuestosTrasladadosLocalesDlls,
				IdImpuestosRetenidosLocales,
				ImpuestosRetenidosLocales,
				ImpuestosRetenidosLocalesDlls,
				IdTipoMovimientoAlmacen,
				CreadoEl,
				CreadoPor,
				Referencia)
			SELECT 
				pma.Estatus,
				pma.FechaHora,
				pma.IdProveedor,
				@FolioMovimientoAlmacen,
				pma.IdMoneda,
				pma.Observaciones,
				-ISNULL(pma.SubTotal,0),
				-ISNULL(pma.SubTotalDlls,0),
				pma.TipoCambio,
				-ISNULL(pma.Total,0),
				-ISNULL(pma.TotalDlls,0),
				pma.IdImpuestosTrasladadosFederales,
				-ISNULL(pma.ImpuestosTrasladadosFederales,0),
				-ISNULL(pma.ImpuestosTrasladadosFederalesDlls,0),
				pma.IdImpuestosRetenidosFederales,
				-ISNULL(pma.ImpuestosRetenidosFederales,0),
				-ISNULL(pma.ImpuestosRetenidosFederalesDlls,0),
				pma.IdImpuestosTrasladadosLocales,
				-ISNULL(pma.ImpuestosTrasladadosLocales,0),
				-ISNULL(pma.ImpuestosTrasladadosLocalesDlls,0),
				pma.IdImpuestosRetenidosLocales,
				-ISNULL(pma.ImpuestosRetenidosLocales,0),
				-ISNULL(pma.ImpuestosRetenidosLocalesDlls,0),
				@IdTipoMovimientoAlmacen,
				@CanceladoEl,
				@CanceladoPor,
				'SE CANCELA EL MOVIMIENTO DE ALMACEN, FOLIO: ' + CAST(pma.Folio as varchar(10))+', DE LA FECHA '+CONVERT(varchar, CONVERT(datetime, FechaHora), 103)
	FROM ProMovimientosAlmacen AS pma WHERE pma.IdMovimientoAlmacen = @IdMovimientoAlmacen
	--
	SET @IdMovimientoAlmacenSalida = (SELECT IDENT_CURRENT('ProMovimientosAlmacen'))
	
	--SE ELIMINA LOS ARTICULOS DETALLADOS SOLICITUD 12325
	IF @EsTraspaso = 0 -- no permita borrar si @EsTraspaso = 1
	DELETE ProMovimientosAlmacenDetallado WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen
	
	--DELETE ProLlantas WHERE IdCompra = @IdCompra SE ELIMINAN LOS ARTICULOS LLANTAS | SOLICITUD 103
	DELETE FROM ProLlantas WHERE IdLlanta in (
		SELECT IdLlanta FROM ProLlantas WHERE CreadoEl = (
			SELECT top 1 pmac.CreadoEl FROM ProMovimientosAlmacenConceptos as pmac 
			inner join CatArticulos ca on pmac.IdArticulo = ca.IdArticulo
			WHERE pmac.IdMovimientoAlmacen = @IdMovimientoAlmacen and ca.EsLlanta = 1
		)
	)
	
	-- Registrar detalle 
	
	DECLARE @ATT_IdArticulo int,
			@ATT_Cantidad decimal(15,4),
			@ATT_Entregado decimal(15,4),
			@ATT_Pendiente decimal(15,4),
			@ATT_PrecioUnitario money,
			@ATT_PrecioUnitarioDlls money,
			@ATT_Importe money,
			@ATT_ImporteDlls money,
			@ATT_Observaciones varchar(255),
			@ATT_UnidadMedida varchar(30),
			@ATT_IdAlmacen int, 
			@ATT_IdMovimientoAlmacenConcepto int
	DECLARE TempProMovimientoAlmacenConceptos CURSOR FOR 
    SELECT IdArticulo,
			-ISNULL(Cantidad,0),
			-ISNULL(Entregado,0) AS Entregado,
			-ISNULL(Pendiente,0) As Pendiente,
			PrecioUnitario,
			PrecioUnitarioDlls,
			-ISNULL(Importe,0),
			-ISNULL(ImporteDlls,0),
			Observaciones,
			UnidadMedida,
			IdAlmacen,
			IdMovimientoAlmacenConcepto 
	FROM ProMovimientosAlmacenConceptos WHERE IdMovimientoAlmacen = @IdMovimientoAlmacen

	OPEN TempProMovimientoAlmacenConceptos
	FETCH NEXT FROM TempProMovimientoAlmacenConceptos INTO 
		@ATT_IdArticulo,
		@ATT_Cantidad,
		@ATT_Entregado,
		@ATT_Pendiente,
		@ATT_PrecioUnitario,
		@ATT_PrecioUnitarioDlls,
		@ATT_Importe,
		@ATT_ImporteDlls,
		@ATT_Observaciones,
		@ATT_UnidadMedida,
		@ATT_IdAlmacen,
		@ATT_IdMovimientoAlmacenConcepto  

	WHILE @@fetch_status = 0
		BEGIN
			-- Registrar costo y existencia.
				SELECT  @ExistenciaActual = Existencia ,
						@ImporteTotalPromedioActual = ImporteTotalPromedio,
						--Dolares
						@ImporteTotalPromedioActualDlls = ImporteTotalPromedioDlls
				FROM ProInventarioAlmacen
				WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo			
				
				SET @ExistenciaActual = @ExistenciaActual+@ATT_Cantidad
				IF @ExistenciaActual =0 
					BEGIN
						SET @CostoPromedioActual = 0
						SET @ImporteTotalPromedioActual = 0
						--Dolares
						SET @CostoPromedioActualDlls = 0
						SET @ImporteTotalPromedioActualDlls = 0
					END
					ELSE
					BEGIN
						SET @CostoPromedioActual = (@ImporteTotalPromedioActual+@ATT_Importe)/@ExistenciaActual
						SET @ImporteTotalPromedioActual = @ExistenciaActual*@CostoPromedioActual 
						--Dolares
						SET @CostoPromedioActualDlls = (@ImporteTotalPromedioActualDlls+@ATT_ImporteDlls)/@ExistenciaActual
						SET @ImporteTotalPromedioActualDlls = @ExistenciaActual*@CostoPromedioActualDlls 

					END	
		   -- Registrar costo
					UPDATE ProInventarioAlmacen
							 SET  Existencia = @ExistenciaActual,
								  CostoPromedio=@CostoPromedioActual,
								  ImporteTotalPromedio=@ImporteTotalPromedioActual,
								  --Dolares
								  CostoPromedioDlls=@CostoPromedioActualDlls,
								  ImporteTotalPromedioDlls=@ImporteTotalPromedioActualDlls,
								  ModificadoEl= @CanceladoEl,
							      ModificadoPor = @CanceladoPor
						WHERE IdAlmacen = @ATT_IdAlmacen AND IdArticulo = @ATT_IdArticulo	
				
			--  Registrar detalle de movimiento
				INSERT INTO ProMovimientosAlmacenConceptos (
					IdArticulo,
					Cantidad,
					PrecioUnitario,
					PrecioUnitarioDlls,
					Importe,
					ImporteDlls,
					Observaciones,
					UnidadMedida,
					IdAlmacen,
					CreadoPor,
					CreadoEl,
					IdMovimientoAlmacen,
					ExistenciaControlPEPS,
					CostoPromedio,
					CostoPromedioDlls)
				VALUES	(@ATT_IdArticulo,
					@ATT_Cantidad,
					@ATT_PrecioUnitario,
					@ATT_PrecioUnitarioDlls,
					@ATT_Importe,
					@ATT_ImporteDlls,
					@ATT_Observaciones,
					@ATT_UnidadMedida,
					@ATT_IdAlmacen,
					@CanceladoPor,
					@CanceladoEl,
					@IdMovimientoAlmacenSalida,
					0,
					@CostoPromedioActual,
					@CostoPromedioActualDlls)				
				UPDATE ProMovimientosAlmacenConceptos
				SET ExistenciaControlPEPS = 0
				WHERE ProMovimientosAlmacenConceptos.IdMovimientoAlmacenConcepto  = @ATT_IdMovimientoAlmacenConcepto 
 			
		FETCH NEXT FROM TempProMovimientoAlmacenConceptos INTO 
		@ATT_IdArticulo,
		@ATT_Cantidad,
		@ATT_Entregado,
		@ATT_Pendiente,
		@ATT_PrecioUnitario,
		@ATT_PrecioUnitarioDlls,
		@ATT_Importe,
		@ATT_ImporteDlls,
		@ATT_Observaciones,
		@ATT_UnidadMedida,
		@ATT_IdAlmacen,
		@ATT_IdMovimientoAlmacenConcepto  
		END
	CLOSE TempProMovimientoAlmacenConceptos
	DEALLOCATE TempProMovimientoAlmacenConceptos	
	--	
	-- Registrar datos de cancelación en ProMovimientosAlmacen
	UPDATE ProMovimientosAlmacen
	 SET MotivoCancelacion = @MotivoCancelacion ,
		 CanceladoPor = @CanceladoPor ,
		 CanceladoEl = @CanceladoEl
	WHERE ProMovimientosAlmacen.IdMovimientoAlmacen = @IdMovimientoAlmacen
	
	COMMIT
END TRY
BEGIN CATCH
	IF(@@TRANCOUNT>0)
	BEGIN
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END
END CATCH
go

