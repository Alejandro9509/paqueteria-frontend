
CREATE PROCEDURE [dbo].[usp_ProCorteCajaGuiaAgregarPQ](
	@IdCorte int,
	@IdGuia int
)
AS
BEGIN
	BEGIN TRANSACTION
		/*IF ISNULL(@IdCliente, 0) = 0 begin
			RAISERROR(N'*INICIO*El cliente es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end

		IF @Vigencia IS NOT NULL AND LEN(@Vigencia) > 0 begin
			set @VigenciaDate = CAST(@Vigencia as date)
		end*/
		
		/*INSERT INTO ProCorteCajaPQ (IdSucursal, FechaRegistro, HoraRegistro, IdDestino, IdTipoMoneda, IdTipoPago, Total)
		values(@IdSucursal, @FechaRegistro, @HoraRegistro, @IdDestino, @IdTipoMoneda, @IdTipoPago, @Total) 
		*/
		INSERT INTO ProCorteCajaGuiasPQ (IdCorte, IdGuia)
		values(@IdCorte, @IdGuia)

		IF @@TRANCOUNT > 0
			BEGIN
				COMMIT TRANSACTION
			END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

