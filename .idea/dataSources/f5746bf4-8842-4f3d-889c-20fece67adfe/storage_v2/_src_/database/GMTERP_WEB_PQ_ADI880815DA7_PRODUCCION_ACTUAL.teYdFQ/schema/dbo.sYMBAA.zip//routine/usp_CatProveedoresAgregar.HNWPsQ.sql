CREATE PROCEDURE [dbo].[usp_CatProveedoresAgregar]
	@NumeroProveedor int,
	@RFC varchar(13),
	@NombreFiscal varchar(150),
	@NombreCorto varchar(12),
	@Calle varchar(100),
	@NoExterior varchar(20),
	@NoInterior varchar(20),
	@Colonia varchar(100),
	@Localidad varchar(100),
	@Municipio varchar(100),
	@IdEstado varchar(5),
	@CodigoPostal varchar(10),
	@Telefono varchar(20),
	@Celular varchar(20),
	@Nextel varchar(20),
	@CorreoElectronico varchar(100),
	@Activo bit,
	@Credito money,
	@CreditoDLLS money,
	@DiasCredito int,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@ProveedorDeCombustible bit,
	@TipoProveedor int,
	@ProveedorDeBien bit,
    @ProveedorDeServicio bit,
    @IdGrupoProveedor int,
    @CuentaBancaria varchar(50),
    @IdBanco int,
    @ClabeInterBancaria varchar (18),
    @IdTipoDeOperacion int,
    @IdTipoDeTercero int,
	@NOIdEstado bit = 0,
	@IDFiscal varchar(40)
AS
DECLARE 
	@IdProveedor int,
    @IdCuentaContable3 int,
    @Codigo varchar(25),--auxiliar para formatear los cuentas contables xxx-xxx-xxxxxx o la que el usuario desee
    @num int,--numero inciial de la cuenta ver archivo de excel con listado detallado
    @Niveles tinyint,
    @PrimerNivel tinyint,
    @SegundoNivel tinyint,
    @TercerNivel tinyint,
    @CuartoNivel tinyint,
	@IdMonedaPadre int  
/*
MODIFICADO:
	Se agrego  exec usp_CatCuentasContablesSaldosAgregar
	para agregar la cuenta contable generada por el proveedor al catalogo CatCuentasContablesSaldos.
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2019-10-01
SOLICITUD: 
	SOLICITUD 000266
*/    
	/* *************************************************************************************************
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 06/07/2020
	Versión 8.0.53.46
	SOLICITUD 001466

	-Se modifico para que cuando cuando el codigo postal del proveedor no se encuentre registrado permita agregar
	el proveedor

	Invocada desde: ClsProPasivos - Agregar
	***************************************************************************************************** */
	/* *************************************************************************************************
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 12/11/2020
	Versión 8.0.56.18
	SOLICITUD 002446

	-Se agrego una validacion que no permite que se realize el agregado del proveedor si ya se a registrado con anterioridad un proveedor con el mismo RFC y codigo postal 
	-Se metio una validacion para la concurrencia de RFC y codigo postal

	Invocada desde: ClsProPasivos - Agregar
	***************************************************************************************************** */
	/* *************************************************************************************************
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 26/01/2021
	Versión 8.0.58.08
	SOLICITUD 003792

	-se modifico para que la validacion de RFC y codigo postal solo la realice con proveedores de tipos nacionales

	Invocada desde: ClsProPasivos - Agregar

	Modificada por: Raymundo Espinoza Garcia
	Fecha de mofidicacion: 13/07/2021
	Versión 8.0.63.00
	SOLICITUD 004293

	***************************************************************************************************** */
	/* *************************************************************************************************
	Modificada por: Ignacio Perez
	Fecha de mofidicacion: 20/08/2021
	Versión 8.0.64.06
	SOLICITUD 004520

	-se modifico para agregar el nuevo campo de IDFiscal

	Invocada desde: ClsProPasivos - Agregar

	***************************************************************************************************** */
BEGIN TRY
	BEGIN TRANSACTION

	
	IF @NumeroProveedor = 0
		RAISERROR(N'El numero de proveedor es un campo requerido',
			16,
			1
			)
	IF @TipoProveedor = 0
		RAISERROR(N'El tipo de proveedor es un campo requerido',
			16,
			1
			)
			
	IF EXISTS(SELECT NumeroProveedor FROM CatProveedores WHERE NumeroProveedor = @NumeroProveedor)
		RAISERROR(N'El numero de proveedor ya existe',
			16,
			1
			)				
			
	IF LTRIM(RTRIM(@RFC)) = ''
		RAISERROR(N'El RFC es un campo requerido',
			16,
			1
			)

	IF LTRIM(RTRIM(@NombreFiscal)) = ''
		RAISERROR(N'El nombre es un campo requerido',
			16,
			1
			)
			
	IF LTRIM(RTRIM(@CodigoPostal)) = ''
		RAISERROR(N'El código postal es un campo requerido',
			16,
			1
			)

	--Sol 2446
	IF EXISTS(SELECT * FROM CatProveedores 
			WHERE RFC = @RFC 
			AND CodigoPostal = @CodigoPostal
			AND TipoProveedor = 1)--3792
		RAISERROR(N'El RFC y Codigo Postal a ha sido registrado anteriormente en el sistema',
		16,
		1
		)

	IF EXISTS(SELECT TOP 1 IdProveedor FROM CatProveedores 
			WHERE RFC = @RFC 
			AND CodigoPostal = @CodigoPostal
			AND TipoProveedor = 1)--3792
		RAISERROR(N'El RFC y Codigo Postal a ha sido registrado anteriormente en el sistema, favor validar',
		16,
		1
		)
	--

	IF @NOIdEstado = 0 --SOL 1466
	BEGIN

		IF LTRIM(RTRIM(@Calle)) = ''
			RAISERROR(N'La calle es un campo requerido',
				16,
				1
				)

		IF LTRIM(RTRIM(@Municipio)) = ''
			RAISERROR(N'El municipio es un campo requerido',
				16,
				1
				)		
			
		IF LTRIM(RTRIM(@IdEstado)) = ''
			RAISERROR(N'El estado es un campo requerido',
				16,
				1
				)
	END
	ELSE
	BEGIN
		SET @Municipio = ''
		SET @Calle = ''
		SET @IdEstado = null
	END --1466

	IF @IdGrupoProveedor = 0
	SET @IdGrupoProveedor = Null
	
	IF @IdBanco = 0
	SET @IdBanco = NULL
	
	IF @IdTipoDeOperacion = 0
	SET @IdTipoDeOperacion = NULL
	
	IF @IdTipoDeTercero = 0
	SET @IdTipoDeTercero = NULL
		
	INSERT INTO CatProveedores(Activo,Calle,Celular,CodigoPostal,Colonia,CorreoElectronico,CreadoEl,CreadoPor,Credito,CreditoDLLS,DiasCredito,IdEstado,Localidad,Municipio,Nextel,NoExterior,NoInterior,NombreCorto,NombreFiscal,NumeroProveedor,RFC,Telefono,ProveedorDeCombustible,TipoProveedor,ProveedorDeBien,ProveedorDeServicio,IdGrupoProveedor,CuentaBancaria,IdBanco,ClabeInterBancaria,IdTipoDeOperacion,IdTipoDeTercero,IDFiscal)
	VALUES(@Activo,@Calle,@Celular,@CodigoPostal,@Colonia,@CorreoElectronico,@CreadoEl,@CreadoPor,@Credito,@CreditoDLLS,@DiasCredito,@IdEstado,@Localidad,@Municipio,@Nextel,@NoExterior,@NoInterior,@NombreCorto,@NombreFiscal,@NumeroProveedor,@RFC,@Telefono,@ProveedorDeCombustible,@TipoProveedor,@ProveedorDeBien,@ProveedorDeServicio,@IdGrupoProveedor,@CuentaBancaria,@IdBanco,@ClabeInterBancaria,@IdTipoDeOperacion,@IdTipoDeTercero,@IDFiscal)

  --SI TIENE ESTRUCTURA CONTABLE DEFINIDA SE AGREGA EN CUENTAS CONTABLES
    IF ISNULL((SELECT Valor FROM SisParametrosValores WHERE Parametro = 'EstructuraCatalogoCuentas'),'') <> ''
    BEGIN
		SET @IdProveedor = (SELECT IDENT_CURRENT('CatProveedores'))
        SET @Niveles =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'NivelesEstructuraCatalogoCuentas')
        SET @PrimerNivel =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'PrimerNivelEstructuraCatalogoCuentas')
        SET @SegundoNivel=(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'SegundoNivelEstructuraCatalogoCuentas')
        SET @TercerNivel =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'TercerNivelEstructuraCatalogoCuentas')
        SET @CuartoNivel =(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'CuartoNivelEstructuraCatalogoCuentas')
        
        IF NOT EXISTS(SELECT Valor FROM SisParametrosValores WHERE Parametro = 'CargarCatalogoDeCuentasContablesDefinidoPorSAT')
		BEGIN
		 --se arma la cuenta contable de proveedor pesos
		    SET @num = 201
		    IF @Niveles = 3
		    BEGIN
		        SET @Codigo = 
		        SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
		        +'-'+
		        SUBSTRING(replicate('0',@SegundoNivel),1,@SegundoNivel-len(CAST(1 as varchar)))+SUBSTRING(CAST(1 as varchar),1,len(CAST(1 as varchar)))
		        +'-'+
		        replicate('0',@TercerNivel)                
		    END
		    ELSE
		    BEGIN
			    SET @Codigo = 
			    SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
			    +'-'+
			    replicate('0',@SegundoNivel)
			    +'-'+
			    SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(1 as varchar)))+SUBSTRING(CAST(1 as varchar),1,len(CAST(1 as varchar)))
			    +'-'+
			    replicate('0',@CuartoNivel)
			END    
			
			SET @IdCuentaContable3 = (SELECT IdCuentaContable FROM CatCuentasContables WHERE Codigo = @Codigo)
	
	        SET @num = 201
	        IF @Niveles = 3
	        BEGIN
	            SET @Codigo = 
	                SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
	                +'-'+
	                SUBSTRING(replicate('0',@SegundoNivel),1,@SegundoNivel-len(CAST(1 as varchar)))+SUBSTRING(CAST(1 as varchar),1,len(CAST(1 as varchar)))
	                +'-'+
	                SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
		            END
		    ELSE
		    BEGIN
				SET @Codigo = 
	             SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
	             +'-'+
	             replicate('0',@SegundoNivel)
	             +'-'+
	             SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(1 as varchar)))+SUBSTRING(CAST(1 as varchar),1,len(CAST(1 as varchar)))
	             +'-'+
	             SUBSTRING(replicate('0',@CuartoNivel),1,@CuartoNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
			END					

			--------------Heredar La Moneda de La cuenta Padre---------------------
			Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable3)
			--------------------------------------------------------------------------  
			INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
			VALUES(1,@Codigo,GETDATE(),@CreadoPor,2,@IdCuentaContable3,@NombreFiscal,4,'CatProveedores',@IdProveedor,@IdMonedaPadre)        
			
			/*Se agrega la cuenta contable a al catalogo CatCuentasContablesSaldos*/
			EXEC usp_CatCuentasContablesSaldosAgregar @IdPeticion,@IdMonedaPadre,0	
			
			UPDATE CatProveedores SET EquivalenciaCuentaContable1 = @Codigo WHERE IdProveedor = @IdProveedor
			
			--se arma la cuenta contable de proveedor dolares
			SET @num = 201
		    IF @Niveles = 3
		    BEGIN
		        SET @Codigo = 
		        SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
		        +'-'+
		        SUBSTRING(replicate('0',@SegundoNivel),1,@SegundoNivel-len(CAST(2 as varchar)))+SUBSTRING(CAST(2 as varchar),1,len(CAST(2 as varchar)))
		        +'-'+
		        replicate('0',@TercerNivel)                
		    END
		    ELSE
		    BEGIN
		        SET @Codigo = 
		        SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
		        +'-'+
			    replicate('0',@SegundoNivel)
			    +'-'+
				SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(2 as varchar)))+SUBSTRING(CAST(2 as varchar),1,len(CAST(2 as varchar)))
		        +'-'+
				replicate('0',@CuartoNivel)
			END    
        
			SET @IdCuentaContable3 = (SELECT IdCuentaContable FROM CatCuentasContables WHERE Codigo = @Codigo)

			SET @num = 201
			IF @Niveles = 3
			BEGIN
			    SET @Codigo = 
			        SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
			        +'-'+
			        SUBSTRING(replicate('0',@SegundoNivel),1,@SegundoNivel-len(CAST(2 as varchar)))+SUBSTRING(CAST(2 as varchar),1,len(CAST(2 as varchar)))
			        +'-'+
			        SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
			END
			ELSE
			BEGIN
				SET @Codigo = 
				    SUBSTRING(CAST(@num as varchar),1,1)+SUBSTRING(replicate('0',@PrimerNivel),1,@PrimerNivel-len(CAST(@num as varchar)))+SUBSTRING(CAST(@num as varchar),2,len(CAST(@num as varchar)))
					+'-'+
			        replicate('0',@SegundoNivel)
					+'-'+
				    SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(2 as varchar)))+SUBSTRING(CAST(2 as varchar),1,len(CAST(2 as varchar)))
				    +'-'+
				    SUBSTRING(replicate('0',@CuartoNivel),1,@CuartoNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
			END		           

			--------------Heredar La Moneda de La cuenta Padre---------------------
			Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable3)
			--------------------------------------------------------------------------              
			INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
			VALUES(1,@Codigo,GETDATE(),@CreadoPor,2,@IdCuentaContable3,@NombreFiscal,4,'CatProveedores',@IdProveedor,@IdMonedaPadre)
			
			/*Se agrega la cuenta contable a al catalogo CatCuentasContablesSaldos*/
			EXEC usp_CatCuentasContablesSaldosAgregar @IdPeticion,@IdMonedaPadre,0
		
			UPDATE CatProveedores SET EquivalenciaCuentaContable2 = @Codigo WHERE IdProveedor = @IdProveedor
		END
		ELSE
		BEGIN
			IF (Select isnull(Valor,0) From SisParametrosValores where Parametro = 'ParametrosContabilidadProveedoresPesosCBOX')<> 0
			BEGIN
			
				SET @Codigo = (Select TOP 1 Valor from SisParametrosValores where Parametro = 'ParametrosContabilidadProveedoresPesos')
				SET @IdCuentaContable3 = (Select TOP 1 IdCuentaContable From CatCuentasContables where Codigo = @Codigo)

				IF @Niveles = 3
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+1)
					+'-'+
					SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
				END
				ELSE
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+@TercerNivel+2)
					+'-'+
					SUBSTRING(replicate('0',@CuartoNivel),1,@CuartoNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
				END					
			
				--------------Heredar La Moneda de La cuenta Padre---------------------
				Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable3)
				--------------------------------------------------------------------------              
				INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
				VALUES(1,@Codigo,GETDATE(),@CreadoPor,2,@IdCuentaContable3,@NombreFiscal,4,'CatProveedores',@IdProveedor,1)						
				
				/*Se agrega la cuenta contable a al catalogo CatCuentasContablesSaldos*/
				EXEC usp_CatCuentasContablesSaldosAgregar @IdPeticion,@IdMonedaPadre,0
			
				UPDATE CatProveedores SET EquivalenciaCuentaContable1 = @Codigo WHERE IdProveedor = @IdProveedor

			END

--PROVEEDORES DOLARES
			IF (Select isnull(Valor,0) From SisParametrosValores where Parametro = 'ParametrosContabilidadProveedoresDolaresCBOX')<> 0
			BEGIN
			
				SET @Codigo = (Select TOP 1 Valor from SisParametrosValores where Parametro = 'ParametrosContabilidadProveedoresDolares')
				SET @IdCuentaContable3 = (Select TOP 1 IdCuentaContable From CatCuentasContables where Codigo = @Codigo)

				IF @Niveles = 3
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+1)
					+'-'+
					SUBSTRING(replicate('0',@TercerNivel),1,@TercerNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
				END
				ELSE
				BEGIN
					SET @Codigo = 
					SUBSTRING(CAST(@Codigo as varchar),1,@PrimerNivel+@SegundoNivel+@TercerNivel+2)
					+'-'+
					SUBSTRING(replicate('0',@CuartoNivel),1,@CuartoNivel-len(CAST(@NumeroProveedor as varchar)))+SUBSTRING(CAST(@NumeroProveedor as varchar),1,len(CAST(@NumeroProveedor as varchar)))
				END			
			
				--------------Heredar La Moneda de La cuenta Padre---------------------
				Set @IdMonedaPadre = (Select IdMoneda From CatCuentasContables Where IdCuentaContable = @IdCuentaContable3)
				--------------------------------------------------------------------------              
				INSERT INTO CatCuentasContables(Activa,Codigo,CreadoEl,CreadoPor,CuentaMayor,IdCuentaContablePadre,Nombre,TipoCuenta,CatalogoLigado,IdCatalogoLigado,IdMoneda)
				VALUES(1,@Codigo,GETDATE(),@CreadoPor,2,@IdCuentaContable3,@NombreFiscal,4,'CatProveedores',@IdProveedor,2)
				
				/*Se agrega la cuenta contable a al catalogo CatCuentasContablesSaldos*/
				EXEC usp_CatCuentasContablesSaldosAgregar @IdPeticion,@IdMonedaPadre,0
			
				UPDATE CatProveedores SET EquivalenciaCuentaContable2 = @Codigo WHERE IdProveedor = @IdProveedor			

			END
		END
	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

