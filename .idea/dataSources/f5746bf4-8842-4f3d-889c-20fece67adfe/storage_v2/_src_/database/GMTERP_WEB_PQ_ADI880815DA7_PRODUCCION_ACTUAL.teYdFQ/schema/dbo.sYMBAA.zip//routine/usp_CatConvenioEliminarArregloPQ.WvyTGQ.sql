
CREATE PROCEDURE [dbo].[usp_CatConvenioEliminarArregloPQ](
	@IdConvenio INT)
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdConvenio,0) <= 0 begin
			RAISERROR(N'*INICIO*El Identidicador del convenio es un campo requerido*FIN*', 16, 1);
			return 
		end;

		DELETE FROM CatTarifaConvenioPQ
		WHERE IdConvenio= @IdConvenio

	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

