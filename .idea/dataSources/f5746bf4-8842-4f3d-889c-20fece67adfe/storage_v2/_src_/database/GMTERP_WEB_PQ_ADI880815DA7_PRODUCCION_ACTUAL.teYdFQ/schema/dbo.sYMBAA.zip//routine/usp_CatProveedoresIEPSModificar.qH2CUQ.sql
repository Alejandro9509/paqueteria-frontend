CREATE PROCEDURE [dbo].[usp_CatProveedoresIEPSModificar]
@IdProveedorIEPS int,
@IdProveedor int,
@Anio int,
@Enero decimal(15,6),
@Febrero decimal(15,6),
@Marzo decimal(15,6), 
@Abril decimal(15,6), 
@Mayo decimal(15,6),
@Junio decimal(15,6), 
@Julio decimal(15,6), 
@Agosto decimal(15,6), 
@Septiembre decimal(15,6),
@Octubre decimal(15,6), 
@Noviembre decimal(15,6), 
@Diciembre decimal(15,6), 
@ModificadoEl    datetime,    
@ModificadoPor    int,    
@IdPeticion varchar(100),
@IdCombustible int
AS
BEGIN TRY
    BEGIN TRANSACTION
    IF ISNULL(@IdProveedorIEPS ,0)= 0
        RAISERROR(N'Identificador de proveedor IEPS es un campo requerido',
            16,
            1
            )
            
    IF ISNULL(@IdProveedor,0)= 0
        RAISERROR(N'Identificador de proveedor es un campo requerido',
            16,
            1
            )

    IF ISNULL(@Anio,0)= 0
        RAISERROR(N'El año es un campo requerido',
            16,
            1
            )
    IF @IdCombustible =0 
       SET @IdCombustible = NULL

-- Modificar proveedorIEPS
    UPDATE CatProveedoresIEPS
     SET IdProveedor = @IdProveedor,
         Anio = @Anio,
         Enero = @Enero,
         Febrero = @Febrero,
         Marzo = @Marzo, 
         Abril = @Abril, 
         Mayo = @Mayo,
         Junio = @Junio, 
         Julio = @Julio, 
         Agosto = @Agosto, 
         Septiembre = @Septiembre,
         Octubre = @Octubre, 
         Noviembre = @Noviembre, 
         Diciembre = @Diciembre,
         ModificadoPor = @ModificadoPor, 
         ModificadoEl = @ModificadoEl,
         IdCombustible = @IdCombustible
    WHERE IdProveedorIEPS  = @IdProveedorIEPS 
    
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

