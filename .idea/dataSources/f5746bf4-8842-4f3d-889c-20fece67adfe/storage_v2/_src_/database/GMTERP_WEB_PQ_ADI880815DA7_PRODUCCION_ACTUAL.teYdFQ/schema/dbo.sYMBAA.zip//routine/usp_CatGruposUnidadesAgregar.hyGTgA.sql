

CREATE PROCEDURE [dbo].[usp_CatGruposUnidadesAgregar]
	@Codigo int,
	@GrupoUnidad varchar(50),
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@Color varchar(6),
	@ColorLetra int
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@Codigo,0) <= 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)	

	IF EXISTS(SELECT Codigo FROM CatGruposUnidades WHERE Codigo = @Codigo)
		RAISERROR(N'El código ya existe',
			16,
			1
			)

	IF LTRIM(RTRIM(@GrupoUnidad)) = ''
		RAISERROR(N'El campo grupo de unidad es requerido',
			16,
			1
			)
            
	INSERT INTO CatGruposUnidades(Codigo,CreadoEl,CreadoPor,DefinidoPorSistema,GrupoUnidad,Color,ColorLetra)
	VALUES(@Codigo,@CreadoEl,@CreadoPor,0,@GrupoUnidad,@Color,@ColorLetra)
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

