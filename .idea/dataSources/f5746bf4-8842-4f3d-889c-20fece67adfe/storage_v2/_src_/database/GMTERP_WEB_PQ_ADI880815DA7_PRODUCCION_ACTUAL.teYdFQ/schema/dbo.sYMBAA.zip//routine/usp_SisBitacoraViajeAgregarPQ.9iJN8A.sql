
CREATE PROCEDURE [dbo].[usp_SisBitacoraViajeAgregarPQ](	
	@IdViaje int ,
	@ModificadoPor int ,
	@ModificadoEl date ,
	@Actual varchar(100),
	@Anterior varchar(100)

	)
AS
BEGIN
	BEGIN TRANSACTION
	
		IF ISNULL(@IdViaje, 0) = 0 begin
			RAISERROR(N'*INICIO* El identificado de viaje es obligatorio *FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
			IF ISNULL(@ModificadoPor, 0) = 0 begin
			RAISERROR(N'*INICIO* El usuario que modifico el viaje es obligatorio*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
	
		end

		IF ISNULL(@ModificadoEl, '') = '' begin
			RAISERROR(N'*INICIO* La fecha de modificacion es obligatoria*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
	
	end

		
		insert into SisBitacoraViajesPQ(	
		IdViaje,
		ModificadoPor ,
		ModificadoEl,
		Actual,
		Anterior
	)
	values
	(
	@IdViaje,
	@ModificadoPor ,
	@ModificadoEl ,
	@Actual,
	@Anterior

	);
		IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

