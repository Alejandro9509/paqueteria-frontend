
CREATE PROCEDURE [dbo].[usp_ProAnticiposGetMaxFolio]

AS

SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProAnticipos
go

