
CREATE PROCEDURE [dbo].[usp_ProRecorridosParadasAsignarUnidadOperador]
	@IdRecorridoParada int,
	@IdUnidadCamion int,
	@CodigoUnidadCamion varchar(16),
	@PlacasUnidadCamion varchar(9),
	@IdOperador int,
	@NombreOperador varchar(100),
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@IdPeticion varchar(100)
	/*
	CREADO POR:  GUSTAVO PARTIDA NEVAREZ.
	FECHA DE CREACION: 30/05/20206.
	VERSION: V8 8.0.52.36.
	SOLICITUD: 2124.

	SE CREO PARA ASIGNAR OPERADOR A LA PARADA. 
	*/
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF @IdRecorridoParada = 0
		RAISERROR(N'El identificador del recorrido es un campo requerido',
			16,
			1
			)
			
	IF (SELECT ModificadoEl FROM ProRecorridoParadas WHERE IdRecorridoParada = @IdRecorridoParada) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)

	IF EXISTS(SELECT pv.CanceladoEl FROM ProRecorridos AS pv INNER JOIN ProRecorridoParadas AS pvt ON pv.IdRecorrido = pvt.IdRecorrido WHERE pvt.IdRecorridoParada = @IdRecorridoParada AND pv.CanceladoEl IS NOT NULL)
		RAISERROR(N'No se puede asignar unidad/operador a este recorrido porque está cancelado',
			16,
			1
			)

	IF EXISTS(SELECT pv.TerminadoEl FROM ProRecorridos AS pv INNER JOIN ProRecorridoParadas AS pvt ON pv.IdRecorrido = pvt.IdRecorrido WHERE pvt.IdRecorridoParada = @IdRecorridoParada AND pv.TerminadoEl IS NOT NULL)
		RAISERROR(N'No se puede asignar unidad/operador a este recorrido porque está terminado',
			16,
			1
			)

	IF EXISTS(SELECT pvt.Salida FROM ProRecorridoParadas AS pvt WHERE pvt.IdRecorridoParada = @IdRecorridoParada AND pvt.Salida IS NOT NULL)
		RAISERROR(N'No se puede asignar unidad/operador a este recorrido/parada porque ya tiene salida',
			16,
			1
			)

	IF EXISTS(SELECT * FROM ProRecorridoParadas AS pvt WHERE pvt.IdRecorridoParada = @IdRecorridoParada AND ((pvt.IdUnidadCamion IS NOT NULL AND pvt.IdUnidadCamion <> 0) OR pvt.CodigoUnidadCamion <> ''))
		RAISERROR(N'No se puede asignar unidad a este recorrido/parada porque ya tiene unidad asignada',
			16,
			1
			)

	IF EXISTS(SELECT * FROM ProRecorridoParadas AS pvt WHERE pvt.IdRecorridoParada = @IdRecorridoParada AND ((pvt.IdOperador IS NOT NULL AND pvt.IdOperador <> 0) OR pvt.NombreOperador <> ''))
		RAISERROR(N'No se puede asignar operador a este recorrido/parada porque ya tiene operador asignado',
			16,
			1
			)

	/*SE ACTUALIZA LA INFORMACION DE PRORECORRIDOSPARADAS*/
	UPDATE ProRecorridoParadas SET
		IdUnidadCamion = CASE @IdUnidadCamion WHEN 0 THEN NULL ELSE @IdUnidadCamion END,
		CodigoUnidadCamion = @CodigoUnidadCamion,
		PlacasUnidadCamion = @PlacasUnidadCamion,
		IdOperador = CASE @IdOperador WHEN 0 THEN NULL ELSE @IdOperador END,	
		NombreOperador = @NombreOperador,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
	FROM ProRecorridoParadas 
	WHERE IdRecorridoParada = @IdRecorridoParada

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

