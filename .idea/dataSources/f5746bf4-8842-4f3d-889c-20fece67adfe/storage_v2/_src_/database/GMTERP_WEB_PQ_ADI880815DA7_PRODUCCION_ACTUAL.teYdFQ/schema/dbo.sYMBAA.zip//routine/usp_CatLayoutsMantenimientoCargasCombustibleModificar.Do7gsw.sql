
CREATE PROCEDURE [dbo].[usp_CatLayoutsMantenimientoCargasCombustibleModificar]
	@Layout	varchar(50),
	@TipoArchivo tinyint,
	@Separador	varchar(1),
	@RenglonInicial	tinyint,
	@ColumnaNumeroComprobante tinyint,
	@ColumnaTarjeta	tinyint,
	@FechaHoraJuntas bit,
	@ColumnaFechaHora tinyint,
	@FormatoFechaHora	varchar(26),
	@ColumnaFecha	tinyint,
	@FormatoFecha	varchar(15),
	@ColumnaHora	tinyint,
	@FormatoHora	varchar(15),
	@ColumnaLitros	tinyint,
	@TieneColumnaImporteIVA bit,
	@ColumnaImporteIVA	tinyint,
	@ColumnaTotal	tinyint,
	@ColumnaOdometro tinyint,
	@ColumnaOperador tinyint,
	@ColumnaReferencia tinyint,
	@ColumnaContenedor tinyint,
	@ModificadoEl	datetime,
	@ModificadoPor	int,
	@IdPeticion varchar(100),
	@IdLayoutMantenimientoCargasCombustible	int

	/* *************************************************************************************************
	SOLICITUD 12798

	Descripcion: Se creo el procedimiento almacenado para la modificacion de formatos de importacion de cargas de combustible por el modulo de mantenimiento
	
	Implementada por:   Ignacio Perez
	Fecha de mofidicacion: 17/07/2019
	Versión: Versión 8.0.44.

	Invocada desde: <PAGE_CatLayoutsMantenimientoCargasCombustibleAM>
	************************************************************************************************ */
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF @IdLayoutMantenimientoCargasCombustible = 0
			RAISERROR(N'El identificador del layout es un campo requerido',
				16,
				1
				)

		IF LTRIM(RTRIM(@Layout)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
	
		UPDATE CatLayoutsMantenimientoCargasCombustible SET 
		Layout = @Layout,
		TipoArchivo = @TipoArchivo,
		Separador = @Separador,
		RenglonInicial = @RenglonInicial,
		ColumnaNumeroComprobante = @ColumnaNumeroComprobante,
		ColumnaTarjeta = @ColumnaTarjeta,
		FechaHoraJuntas = @FechaHoraJuntas,
		ColumnaFechaHora = @ColumnaFechaHora,
		FormatoFechaHora = @FormatoFechaHora,
		ColumnaFecha = @ColumnaFecha,
		FormatoFecha = @FormatoFecha,
		ColumnaHora = @ColumnaHora,
		FormatoHora = @FormatoHora,
		ColumnaLitros = @ColumnaLitros,
		TieneColumnaImporteIVA = @TieneColumnaImporteIVA,
		ColumnaImporteIVA = @ColumnaImporteIVA,
		ColumnaTotal = @ColumnaTotal,
		ColumnaOdometro = @ColumnaOdometro,
		ColumnaOperador = @ColumnaOperador,
		ColumnaReferencia = @ColumnaReferencia,
		ColumnaContenedor = @ColumnaContenedor,
		ModificadoEl = @ModificadoEl,
		ModificadoPor = @ModificadoPor
		WHERE IdLayoutsMantenimientoCargasCombustible = @IdLayoutMantenimientoCargasCombustible
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

