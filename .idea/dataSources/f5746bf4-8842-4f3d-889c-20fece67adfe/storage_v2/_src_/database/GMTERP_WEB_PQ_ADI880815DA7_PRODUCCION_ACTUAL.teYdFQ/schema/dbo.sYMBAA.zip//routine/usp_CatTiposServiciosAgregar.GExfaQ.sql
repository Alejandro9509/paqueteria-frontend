
	CREATE PROCEDURE [dbo].[usp_CatTiposServiciosAgregar]
	@TipoServicio	varchar(50),	
	@Activo bit,
	@IdPeticion varchar(100)
	AS
	BEGIN TRY
		BEGIN TRANSACTION
		IF ISNULL(@TipoServicio,'')= ''
			RAISERROR(N'El Tipo de Servicio es un campo requerido',
				16,
				1
				)
		INSERT INTO CatTiposServicios(TipoServicio,Activo)
		VALUES(@TipoServicio,@Activo)
		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

