CREATE PROCEDURE [dbo].[usp_CatConceptosPDOFijosModificar]
	@IdConceptoPDOFijo int,
	@Descripcion Varchar(40),
	@IdConceptoPDO int,
	@FechaInicioAplicacion datetime,
	@ImporteValor tinyint,
	@VecesAplicar int,
	@VecesAplicado int,
	@MontoLimite decimal(15,2),
	@MontoAcumulado decimal(15,2),
	@FechaRegistro datetime,
	@Activo bit,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@Valor decimal(7,2),
	@Importe money,
	@TipoConcepto int,
	@NumeroConcepto int,
	@DescripcionConcepto Varchar(40),
	@IdEmpleado int,
	@NumeroControl int,
	@IdPeticion varchar(100),
	@IdPeriodo int 
AS	
BEGIN TRY
	BEGIN TRANSACTION
	IF @Descripcion = ''
			RAISERROR(N'La descripción es un campo requerido',
				16,
				1
				)
		IF isnull(@FechaInicioAplicacion, '') = ''
			RAISERROR(N'La fecha de inicio de aplicación es un campo requerido',
				16,
				1
				)	
		IF @ImporteValor = 0
			RAISERROR(N'El ImporteValor es un campo requerido',
				16,
				1
				)
		IF @VecesAplicar = 0
			RAISERROR(N'Veces a aplicar es un campo requerido',
				16,
				1
				)
					
	--UPDATE A LA TABLA CatConceptosPDOFijos CON LA INFORMACION PROPORCIONADA		
	UPDATE CatConceptosPDOFijos SET
	Descripcion= @Descripcion,
	FechaInicioAplicacion= @FechaInicioAplicacion,
	ImporteValor= @ImporteValor,
	VecesAplicar =@VecesAplicar,
	VecesAplicado =@VecesAplicado,
	MontoLimite= @MontoLimite,
	MontoAcumulado= @MontoAcumulado,
	FechaRegistro= @FechaRegistro,
	Activo= @Activo,
	ModificadoPor=@ModificadoPor,
	ModificadoEl=@ModificadoEl,
	Valor=@Valor,
	Importe= @Importe,
	TipoConcepto = @TipoConcepto,
	NumeroConcepto = @NumeroConcepto,
	NumeroControl=@NumeroControl,
	DescripcionConcepto = @DescripcionConcepto,
	IdConceptoPDO = @IdConceptoPDO
	WHERE IdConceptoPDOFijo = @IdConceptoPDOFijo

	UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

	COMMIT
END TRY
BEGIN CATCH	
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

