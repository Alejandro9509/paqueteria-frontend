
	CREATE PROCEDURE [dbo].[usp_ProNominasReciboInfonavitEliminar]
	@IdNominaReciboInfonavit int,
	@IdPeticion varchar(100),
	@IdEmpleado int, 
	@IdPeriodo int
	AS
	DECLARE
	@IdConceptoPDOFijoInfonavit int,
	@IdConceptoPDOFijoSeguro int = 0
	BEGIN TRY
		BEGIN TRANSACTION
		
		SET @IdConceptoPDOFijoInfonavit = (SELECT IdConceptoPDOFijoInfonavit FROM ProNominasReciboInfonavit WHERE IdNominaReciboInfonavit = @IdNominaReciboInfonavit)
		SET @IdConceptoPDOFijoSeguro = (SELECT IdConceptoPDOFijoSeguro FROM ProNominasReciboInfonavit WHERE IdNominaReciboInfonavit = @IdNominaReciboInfonavit)
		
		IF ISNULL(@IdNominaReciboInfonavit,0)= 0
		RAISERROR(N'El identificador de Infonavit es un campo requerido',
				16,
				1
				)
				
		IF EXISTS(SELECT IdConceptoPDOFijo FROM ProNominasReciboConceptos WHERE IdConceptoPDOFijo=@IdConceptoPDOFijoInfonavit ) OR EXISTS(SELECT IdConceptoPDOFijo FROM ProNominasReciboConceptos WHERE IdConceptoPDOFijo=@IdConceptoPDOFijoSeguro ) 
		RAISERROR(N'No es posible eliminar el infonavit, porque ya se asoció al recibo. ',
				16,
				1	
				)		
			
			DELETE	ProNominasReciboInfonavit
			WHERE 	IdNominaReciboInfonavit=@IdNominaReciboInfonavit

			IF ISNULL(@IdConceptoPDOFijoInfonavit,0) <> 0
			BEGIN
				DELETE	CatConceptosPDOFijos
				WHERE 	IdConceptoPDOFijo=@IdConceptoPDOFijoInfonavit
			END

			IF ISNULL(@IdConceptoPDOFijoSeguro,0) <> 0
			BEGIN
				DELETE	CatConceptosPDOFijos
				WHERE 	IdConceptoPDOFijo=@IdConceptoPDOFijoSeguro
			END

			UPDATE ProNominasRecibo SET Calculado = 0 WHERE IdEmpleado = @IdEmpleado AND IdPeriodo = @IdPeriodo

		COMMIT
	END TRY
	BEGIN CATCH
		ROLLBACK
		EXECUTE usp_SisErrorsGrabar @IdPeticion
	END CATCH
    go

