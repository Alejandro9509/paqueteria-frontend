CREATE PROCEDURE [dbo].[usp_ProReportesFallasImagenesAgregar]
	@IdReporteFalla  int,
	@Imagen ntext,
	@ImagenNombreArchivo varchar(3000),
	@Descripcion varchar(150),
	@CreadoPor int, 
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@Obs int = 0
AS
/*************************************************************************************************************************************
	@IdReporteFalla  Idproceso,
	@Imagen ntext,
	@ImagenNombreArchivo varchar(3000),
	@Descripcion varchar(150),
	@CreadoPor int, 
	@CreadoEl datetime,
	@IdPeticion varchar(100)

	
	Modificado por: Enrique Ramos Alvarez
	Fecha de Modificacion:  13/02/2020
	Versión: 8.0.51.05
	Solicitud 1514
	Se cambio el tamaño del los parametros recibidos, se agrego el campo del obs 1 al agregar el registro 

		Modificado por: Enrique Ramos Alvarez
	Fecha de Modificacion:  02/04/2020
	Versión: 8.0.51.31
	Solicitud 1514
	Se cambio el obs a un variable para los clientes con la ap movil desactualizada 

	***************************************/
BEGIN TRY
	BEGIN TRANSACTION
	IF ISNULL(@IdReporteFalla ,0) = 0
		RAISERROR(N'El identificador del reporte  es un campo requerido',
			16,
			1
			)
	
	INSERT INTO ProReportesFallasImagenes(IdReporteFalla,Imagen,ImagenNombreArchivo,Descripcion,CreadoPor,CreadoEl,Obs)	
	VALUES(@IdReporteFalla,@Imagen,@ImagenNombreArchivo,@Descripcion,@CreadoPor,@CreadoEl,@Obs)
	COMMIT 
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

