CREATE PROCEDURE [dbo].[usp_ProRequisicionCancelar]
	@IdRequisicion int,
	@Estatus tinyint,
	@MotivoCancelacion varchar(500),
	@CanceladoEl datetime,
	@CanceladoPor int,
	@IdPeticion varchar(100)
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF Isnull(@IdRequisicion,0) = 0
		RAISERROR(N'El identificador de la requisicion es un campo requerido',
			16,
			1
			)

	IF (SELECT FechaHora FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) > @CanceladoEl
		RAISERROR(N'La fecha de cancelación no puede ser menor a la fecha de elaboración',
			16,
			1
			)

	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) = 1--cerrada
		RAISERROR(N'No puede cancelar esta requisicion porque está cerrada',
			16,
			1
			)

	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) = 2--cancelada
		RAISERROR(N'No puede cancelar esta requisicion porque está cancelada',
			16,
			1
			)
	IF (SELECT Estatus FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) = 9--autorizada
		RAISERROR(N'No puede cancelar esta requisicion porque está autorizada',
			16,
			1
			)
			
	IF (SELECT CanceladoEl FROM ProRequisicion WHERE IdRequisicion = @IdRequisicion) IS NOT NULL --cancelado
		RAISERROR(N'No puede cancelar esta requisicion porque está cancelada',
			16,
			1
			)			

	IF LTRIM(RTRIM(@MotivoCancelacion)) = ''
		RAISERROR(N'El motivo de cancelación es un campo requerido',
			16,
			1
			)
																
	UPDATE ProRequisicion
	SET Estatus = @Estatus,
		MotivoCancelacion = @MotivoCancelacion,	
		CanceladoEl = @CanceladoEl,
		CanceladoPor = @CanceladoPor,
		ModificadoEl = @CanceladoEl,
		ModificadoPor = @CanceladoPor
	WHERE IdRequisicion = @IdRequisicion

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

