
CREATE PROCEDURE [dbo].[usp_CatGruposUnidadesUsuariosAsignar]
	@IdGrupoUnidad int,
	@dsCatGruposUnidadesUsuarios ntext,
	@CreadoPor int,
	@CreadoEl datetime,	
	@IdPeticion varchar(100)
AS
DECLARE
	@docHandle int
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdGrupoUnidad,0) <= 0
		RAISERROR(N'El identificador del grupo de unidades es un campo requerido',
			16,
			1
			)
			
	IF @dsCatGruposUnidadesUsuarios IS NULL
		RAISERROR(N'Los Usuarios son requeridos',
			16,
			1
			)

	EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatGruposUnidadesUsuarios

	SELECT COL_IdGrupoUnidadUsuario,COL_IdUsuario
	INTO #TempCatGruposUnidadesUsuarios
	FROM OPENXML(@docHandle, N'/WINDEV_TABLE/TABLE_CatGruposUnidadesUsuarios',2) 
	WITH (COL_IdGrupoUnidadUsuario int,COL_IdUsuario int)
	
	EXEC sp_xml_removedocument @docHandle
	
	INSERT INTO CatGruposUnidadesUsuarios(CreadoEl,CreadoPor,IdGrupoUnidad,IdUsuario)
	SELECT @CreadoEl,@CreadoPor,@IdGrupoUnidad,COL_IdUsuario
	FROM #TempCatGruposUnidadesUsuarios
	WHERE COL_IdGrupoUnidadUsuario = 0
	
	UPDATE CatGruposUnidadesUsuarios SET
		CatGruposUnidadesUsuarios.ModificadoEl = @CreadoEl,
		CatGruposUnidadesUsuarios.ModificadoPor = @CreadoPor
	FROM CatGruposUnidadesUsuarios
	INNER JOIN #TempCatGruposUnidadesUsuarios ON CatGruposUnidadesUsuarios.IdGrupoUnidadUsuario = #TempCatGruposUnidadesUsuarios.COL_IdGrupoUnidadUsuario
	
	DELETE FROM CatGruposUnidadesUsuarios WHERE IdGrupoUnidad = @IdGrupoUnidad AND (ModificadoEl <> @CreadoEl OR ModificadoEl IS NULL) AND CreadoEl <> @CreadoEl
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

