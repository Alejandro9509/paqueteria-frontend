
CREATE PROCEDURE [dbo].[usp_CatCondicionesRecepcionEntregaEliminarPQ]
	@IdCondicionesRecepcionEntrega INT
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdCondicionesRecepcionEntrega,0) <= 0 begin
			RAISERROR(N'*INICIO*Identificador del Codiciones Recepcion Entrega es un campo requerido*FIN*', 16, 1);
			return
		end;
		
		DELETE FROM CatCondicionesRecepcionEntregas
		WHERE IdCondicionesRecepcionEntrega = @IdCondicionesRecepcionEntrega
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfo;
END CATCH
go

