CREATE PROCEDURE [dbo].[usp_ProConsumosCombustibleAsignarViaje]
	@IdConsumoCombustible int,
	@IdViajeTrayecto int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@NoConsiderarFechaSalidaViaje bit,
	@IdPeticion varchar(100)

	/*************************************************************************************************************************************
Procedimiento almacenado usp_ProConsumosCombustibleAsignarViaje

Parámetros: 
	@IdConsumoCombustible int,
	@IdViajeTrayecto int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@UltimaModificacion datetime,
	@NoConsiderarFechaSalidaViaje bit,
	@IdPeticion varchar(100)

Descripción: Asgina Viajes a consumos de combustible con los campos e informacion correspondiente

Fecha de modificación: 29/02/2020
Versión: Versión 8.0.50.23
Solicitud 1217
Se agrega valor de parámetro para no considerar la fecha de salida del viaje para asignarlo a
consumo de combustible independintemente de que no coincida la fecha de salida de via con la fecha
de carga de combustible.

Invocada desde: ClsProConsumosCombustible
    Solicitud 1217
******************************************************************************************************************* */
AS
DECLARE 
	@IdUnidad	int,
	@FechaHora	datetime
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@IdConsumoCombustible,0) <= 0
		RAISERROR(N'El identificador del consumo de combustible es un campo requerido',
			16,
			1
			)	
	
	IF ISNULL(@IdViajeTrayecto,0) <= 0
		RAISERROR(N'El viaje/trayecto es un campo requerido',
			16,
			1
			)	
	
	IF (SELECT ModificadoEl FROM ProConsumosCombustible WHERE IdConsumoCombustible = @IdConsumoCombustible) <> @UltimaModificacion
		RAISERROR(N'Este registro fue modificado por otro usuario',
			16,
			1
			)	
	
	IF (SELECT IdGastoViaje FROM ProConsumosCombustible WHERE IdConsumoCombustible = @IdConsumoCombustible) IS NOT NULL
		RAISERROR(N'Este registro está asignado a un gasto de viaje y no se puede modificar.',
			16,
			1
			)	

	SET @IdUnidad = (SELECT IdUnidad FROM ProConsumosCombustible WHERE IdConsumoCombustible = @IdConsumoCombustible)
	SET @FechaHora = (SELECT FechaHora FROM ProConsumosCombustible WHERE IdConsumoCombustible = @IdConsumoCombustible)

	IF @NoConsiderarFechaSalidaViaje = 1
	BEGIN
	-- Solicitud 1217 - Asigna viaje independientemente de que la fecha de salida del viaje
	-- no sea igual a la  fecha y hora  de carga de combustible.
    IF NOT EXISTS(SELECT pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt 
			INNER JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
			LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion			
			WHERE pvt.IdUnidadCamion = @IdUnidad AND pv.CanceladoEl IS NULL	AND pl.CerradaEl IS NULL AND pvt.IdViajeTrayecto = @IdViajeTrayecto)
		RAISERROR(N'No se puede asignar al viaje/trayecto porque no cumple con alguna de las sig. condiciones: Viaje no cancelado, Liquidación Abierta.',
			16,
			1
			)
	END
	ELSE
	BEGIN
	IF NOT EXISTS(SELECT pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt 
			INNER JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
			LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion			
			WHERE pvt.IdUnidadCamion = @IdUnidad AND pv.CanceladoEl IS NULL	AND pvt.Salida <= @FechaHora AND pl.CerradaEl IS NULL AND pvt.IdViajeTrayecto = @IdViajeTrayecto)
		RAISERROR(N'No se puede asignar al viaje/trayecto porque no cumple con alguna de las sig. condiciones: Viaje no cancelado, Liquidación Abierta, Fecha del consumo mayor o igual a la fecha de salida.',
			16,
			1
			)
	END

	IF EXISTS(SELECT pv.IdViajeCompuestoPadre FROM ProViajes AS pv INNER JOIN ProViajesTrayectos AS pvt ON pv.IdViaje = pvt.IdViaje WHERE pvt.IdViajeTrayecto = @IdViajeTrayecto AND pv.IdViajeCompuestoPadre IS NOT NULL AND pvt.EsCompuesto = 1)--es un viajes compuesto hijo depende de otro viaje
		RAISERROR(N'No se puede asignar el viaje porque es un viaje compuesto y depende de otro viaje',
			16,
			1
			)			
								
	UPDATE ProConsumosCombustible SET		
		IdViajeTrayecto = @IdViajeTrayecto,
		ModificadoPor = @ModificadoPor,
		ModificadoEl = @ModificadoEl
	WHERE IdConsumoCombustible = @IdConsumoCombustible
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

