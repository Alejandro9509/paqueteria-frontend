CREATE PROCEDURE [dbo].[usp_ProCargasCombustibleGetMaxFolio]  
AS  
SELECT ISNULL(MAX(Folio),0)+1 AS Folio FROM ProCargasCombustible
go

