
CREATE PROCEDURE [dbo].[usp_SisAtajoAgregarPQ](
	@IdUsuario INT,
	@IdProceso INT,
	@NombreAtajo varchar(50),
	@URLAtajo varchar(100)
	)
AS
BEGIN TRY
	BEGIN TRANSACTION
	
		IF ISNULL(@IdUsuario, '') = '' begin			
			RAISERROR(N'*INICIO*El identificador del Usuario es un campo requerido*FIN*', 16, 1);
			return
		end;
		IF ISNULL(@IdProceso, '') = '' begin			
			RAISERROR(N'*INICIO*El identificador del Proceso es un campo requerido*FIN*', 16, 1);
			return
		end;
		IF ISNULL(@NombreAtajo, '') = '' begin
			RAISERROR(N'*INICIO*El nombre del atajo es un campo requerido*FIN*', 16, 1);
			return 
		end;
		IF ISNULL(@URLAtajo, '') = '' begin
			RAISERROR(N'*INICIO*La URL del atajo es un campo requerido*FIN*', 16, 1);
			return 
		end;

		INSERT INTO SisAtajosPQ(IdUsuario, IdProceso, NombreAtajo, URLAtajo)
		VALUES (@IdUsuario, @IdProceso, @NombreAtajo, @URLAtajo)


	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0 
		ROLLBACK TRANSACTION
	EXECUTE usp_GetErrorInfoPQ;
END CATCH
go

