CREATE PROCEDURE [dbo].[usp_CatTurnosAgregar]
@Codigo    int,    
@Turno    varchar(40),    
@CreadoEl    datetime,    
@CreadoPor    int, 
@Horas      decimal(15,2), 
@ClaveSAT varchar(5),  
@IdPeticion varchar(100)    
AS
BEGIN TRY
    BEGIN TRANSACTION
    IF ISNULL(@Codigo,0)= 0
        RAISERROR(N'El código del Turno es un campo requerido',
            16,
            1
            )
                    
    IF ISNULL(@Turno,'')= ''
        RAISERROR(N'El nombre del Turno es un campo requerido',
            16,
            1
            )
    IF EXISTS(SELECT Turno FROM CatTurnos WHERE Turno = @Turno)
		RAISERROR(N'La Descripción del Turno ya existe',
			16,
			1
			)
            
    IF ISNULL(@Horas,0)= 0
        RAISERROR(N'El número de Horas del Turno es un campo requerido',
            16,
            1
            )
            
    IF ISNULL(@ClaveSAT,'')= ''
        RAISERROR(N'La Clave SAT es un campo requerido',
            16,
            1
            )
            
    INSERT INTO CatTurnos(Codigo,Turno,CreadoEl,CreadoPor,Horas,ClaveTipoJornada)
    VALUES(@Codigo,@Turno,@CreadoEl,@CreadoPor,@Horas,@ClaveSAT)
    COMMIT
END TRY
BEGIN CATCH
    ROLLBACK
    EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

