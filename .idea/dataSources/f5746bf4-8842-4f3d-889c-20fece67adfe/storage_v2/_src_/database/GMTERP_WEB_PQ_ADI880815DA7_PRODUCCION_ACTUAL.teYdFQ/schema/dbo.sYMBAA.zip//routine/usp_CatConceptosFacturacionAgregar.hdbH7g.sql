CREATE PROCEDURE [dbo].[usp_CatConceptosFacturacionAgregar]
	@Codigo int,
	@ConceptoFacturacion varchar(50),
	@TrasladaImpuesto bit,
	@RetieneImpuesto Bit,
	@Activo Bit,
	@UnidadMedida varchar(30),
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100),
	@IncluirCalculoIngresosLiquidacion bit,
	@IncluirCalculoLiquidacionPorcentajeSobreImpFlete bit,
	@ClaveSATProducto varchar(8),
	@ClaveSATUnidad varchar(8),
	@EquivalenciaEDI varchar(5),
	@ImpuestoTraslada ntext,
	@ImpuestoRetiene ntext,
	@NoIdentificacion varchar(40)
AS
DECLARE
@docHandle int,
@IdConceptoFacturacion int
/*
MODIFICADO:
	Se agregaro condiciones para registrar los impuestos retiene y traslada del concepto de facturacion
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-03-30
SOLICITUD: 
	SOLICITUD 001464
*/
/*
MODIFICADO:
	Se agregaro el campo NoIdentificacion
MODIFICADA POR:
	Abril CG
FECHA DE MODIFICACIÓN:
	2020-09-14
SOLICITUD: 
	SOLICITUD 002927
*/

BEGIN TRY
	BEGIN TRANSACTION
	

	IF @Codigo <= 0
	RAISERROR(N'El Codigo es un campo requerido',
		16,
		1
		)

	IF LTRIM(RTRIM(@ConceptoFacturacion)) = ''
	RAISERROR(N'El Concepto de facturación es un campo requerido',
		16,
		1
		)

	IF (@ImpuestoTraslada IS NULL) AND (@ImpuestoRetiene IS NOT NULL)
	RAISERROR(N'Es necesario seleccionar al menos un Impuesto Trasladado.',
		16,
		1
		)

	IF EXISTS(SELECT IdConceptoFacturacion FROM CatConceptosFacturacion WHERE Codigo = @Codigo)		
	RAISERROR(N'El código del concepto de facturación no se puede repetir',
		16,
		1
		)
						
	INSERT INTO CatConceptosFacturacion(Codigo,ConceptoFacturacion,TrasladaImpuesto,RetieneImpuesto,Activo,CreadoPor,CreadoEl,UnidadMedida,DefinidoPorSistema,IncluirCalculoIngresosLiquidacion,IncluirCalculoLiquidacionPorcentajeSobreImpFlete,ClaveSATProducto,ClaveSATUnidad,EquivalenciaEDI,NoIdentificacion)
	VALUES(@Codigo,@ConceptoFacturacion,@TrasladaImpuesto,@RetieneImpuesto,@Activo,@CreadoPor,@CreadoEl,@UnidadMedida,0,@IncluirCalculoIngresosLiquidacion,@IncluirCalculoLiquidacionPorcentajeSobreImpFlete,@ClaveSATProducto,@ClaveSATUnidad,@EquivalenciaEDI,@NoIdentificacion)
	
	SET @IdConceptoFacturacion = (SELECT IDENT_CURRENT('CatConceptosFacturacion'))


	IF @ImpuestoTraslada IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @ImpuestoTraslada
		
		SELECT ATT_IDIMPUESTO,ATT_PREDETERMINADO
		INTO #TempImpuestosTraslada
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_IMPUESTOTRASLADA',2) 
		WITH (ATT_IDIMPUESTO int,ATT_PREDETERMINADO int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatConceptosFacturacionImpuestos(IdConceptoFacturacion,IdImpuesto,Predeterminado,Activo)
		SELECT @IdConceptoFacturacion,ATT_IDIMPUESTO,ATT_PREDETERMINADO,1 FROM #TempImpuestosTraslada
	END

	IF @ImpuestoRetiene IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @ImpuestoRetiene
		
		SELECT ATT_IDIMPUESTO,ATT_PREDETERMINADO
		INTO #TempImpuestosRetiene
		FROM OPENXML(@docHandle, N'/WINDEV_TABLE/LOOP_IMPUESTORETIENE',2) 
		WITH (ATT_IDIMPUESTO int,ATT_PREDETERMINADO int)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO CatConceptosFacturacionImpuestos(IdConceptoFacturacion,IdImpuesto,Predeterminado,Activo)
		SELECT @IdConceptoFacturacion,ATT_IDIMPUESTO,ATT_PREDETERMINADO,1 FROM #TempImpuestosRetiene
	END

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

