


CREATE PROCEDURE [dbo].[usp_ProViajeSalidaModificarPQ](
	
	@IdViaje int ,
	@IdInforme int ,

	@CV1Km float ,
	@CV2Km float ,
	@CV1Millas float ,
	@CV2Millas float ,
	@CV1Estatus bit ,
	@CV2Estatus bit ,
	@FechaSalida date ,
	@HoraSalida varchar(5) ,
	@IdEstatusSalida int ,
	@KmViaje float ,
	@MillasViaje float ,
	@IdViajeSalida int,
	@MotivoRetraso varchar(100)
	)
AS
BEGIN
	BEGIN TRANSACTION
		DECLARE @IdGuia int;
		DECLARE @FOLIO int;
		DECLARE @FOLIOSTR varchar(10);		
		DECLARE @TRACKINGSTR varchar(10);
		declare @horas time;
		--declare @HoraSalida time;
		if @HoraSalida != null begin
			set @horas = cast(@HoraSalida as time);
		end
		IF ISNULL(@IdViajeSalida, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de salida del viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		/*IF ISNULL(@IdInforme, 0) = 0 begin
			RAISERROR(N'*INICIO*El Identificador de informe es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end*/

		/*
		IF ISNULL(@FechaSalida, '') = '' begin
			RAISERROR(N'*INICIO*La fecha es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@HoraSalida,'' ) = '' begin
			RAISERROR(N'*INICIO*La hora es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end */
		/*
		IF ISNULL(@IdEstatusSalida, 0) = 0 begin
			RAISERROR(N'*INICIO*El identificador del estatus de salida un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@KmViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Los kilometros de viaje es un campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		IF ISNULL(@MillasViaje, 0) = 0 begin
			RAISERROR(N'*INICIO*Las millas de viaje esun campo requerido*FIN*', 16, 1)
			GOTO CANCELAR_TRANSACCION
			return;
		end
		*/
		update ProViajeSalidaPQ
		set 
		CV1Km = @CV1Km,
		CV2Km = @CV2Km,
		CV1Millas = @CV1Millas,
		CV2Millas = @CV2Millas,
		CV1Estatus = @CV1Estatus,
		CV2Estatus = @CV2Estatus,
		FechaSalida = @FechaSalida,
		HoraSalida = @horas,
		IdEstatusSalida =@IdEstatusSalida,
		KmViaje = @KmViaje,
		MillasViaje = @MillasViaje,
		MotivoRetraso=@MotivoRetraso
		where IdViajeSalida = @IdViajeSalida ;

		IF @@TRANCOUNT > 0
			BEGIN
	
				COMMIT TRANSACTION
				END
		ELSE
		BEGIN            
			GOTO CANCELAR_TRANSACCION
		

			CANCELAR_TRANSACCION:
			IF @@TRANCOUNT > 0
			BEGIN
			EXECUTE usp_GetErrorInfoPQ;
					ROLLBACK TRANSACTION
					RETURN -1
			END
		END
end
go

