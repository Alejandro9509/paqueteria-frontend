CREATE PROCEDURE [dbo].[usp_ProConsumosCombustibleAgregar]
	@Tarjeta	varchar(26),
	@FechaHora	datetime,
	@NumeroComprobante	bigint,
	@IdProveedor int,
	@IdUnidad int,
	@Litros decimal(15,6),
	@Total	money,
	@Odometro int,
	@IdImpuestoTraslado int,
	@ImporteImpuesto money,
	@AsignaViajeTrayecto bit,
	@CreadoEl	datetime,
	@CreadoPor	int,	
	@IdPeticion varchar(100),
	@Subtotal money,
	@MillasGalonesDolares bit,
	@ValidarViajesDocumentacion bit = 0 --Solicitud 12490 - Para identificar si se filtrarán los viajes con documentación adjunta
AS
DECLARE 
	@IdViajeTrayecto	int
BEGIN TRY
	BEGIN TRANSACTION

		IF LTRIM(RTRIM(@Tarjeta)) = ''
			RAISERROR(N'La tarjeta es un campo requerido',
				16,
				1
				)

		IF ISDATE(@FechaHora) = 0
		RAISERROR(N'La fecha/hora es un campo requerido',
			16,
			1
			)
						
		IF ISNULL(@IdUnidad,0) <= 0
		RAISERROR(N'La unidad es un campo requerido',
			16,
			1
			)						

		IF ISNULL(@IdProveedor,0) <= 0
		RAISERROR(N'El proveedor es un campo requerido',
			16,
			1
			)

		IF ISNULL(@NumeroComprobante,0) <= 0
		RAISERROR(N'El número de comprobante es un campo requerido',
			16,
			1
			)

		IF ISNULL(@IdImpuestoTraslado,0) <= 0
		RAISERROR(N'El impuesto es un campo requerido',
			16,
			1
			)
			
		IF ISNULL(@Litros,0) <= 0
		RAISERROR(N'Los litros son un campo requerido',
			16,
			1
			)			

		IF ISNULL(@Total,0) <= 0
		RAISERROR(N'El total es un campo requerido',
			16,
			1
			)	

		IF ISNULL(@Subtotal,0) <= 0
			RAISERROR(N'El subtotal es un campo requerido',
				16,
				1
				)					
						
		IF EXISTS(SELECT * FROM ProConsumosCombustible WHERE IdProveedor = @IdProveedor AND NumeroComprobante = @NumeroComprobante)
		RAISERROR(N'Registro duplicado',
			16,
			1
			)		

		IF @AsignaViajeTrayecto = 1
		BEGIN
			SET @IdViajeTrayecto = (SELECT TOP 1 pvt.IdViajeTrayecto 
			FROM ProViajesTrayectos AS pvt 
			INNER JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
			LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion			
			WHERE pvt.IdUnidadCamion = @IdUnidad 
			AND pv.CanceladoEl IS NULL
			AND pvt.Salida <= @FechaHora AND ISNULL(pvt.Llegada,GETDATE()) >= @FechaHora 
			AND pl.CerradaEl IS NULL
			AND (pv.IdViajeCompuestoPadre IS NULL or (pv.IdViajeCompuestoPadre IS not NULL and isnull(pvt.EsCompuesto,0)= 0)))

			IF NOT EXISTS(SELECT pvt.IdViajeTrayecto FROM ProViajesTrayectos AS pvt 
				INNER JOIN ProViajes AS pv ON pvt.IdViaje = pv.IdViaje
				LEFT JOIN ProLiquidaciones AS pl ON pvt.IdLiquidacion = pl.IdLiquidacion			
				WHERE pvt.IdUnidadCamion = @IdUnidad AND pv.CanceladoEl IS NULL	AND pvt.Salida <= @FechaHora AND pl.CerradaEl IS NULL AND pvt.IdViajeTrayecto = @IdViajeTrayecto)
				RAISERROR(N'No se puede asignar al viaje/trayecto porque no cumple con alguna de las sig. condiciones: Viaje no cancelado, Liquidación Abierta, Fecha del consumo mayor o igual a la fecha de salida.',
					16,
					1
					)

			-- Solicitud 12490 - No se asignarán viajes sin documentación adjunta
			IF @ValidarViajesDocumentacion = 1
			Begin
				IF NOT EXISTS(SELECT pvi.IdViaje FROM ProViajesImagenes AS pvi
					INNER JOIN ProViajesTrayectos AS pvt ON pvi.IdViaje = pvt.IdViaje
					WHERE pvt.IdViajeTrayecto = @IdViajeTrayecto)
					RAISERROR(N'No se puede asignar al viaje/trayecto porque no cuenta con evidencias adjuntas, favor de cargar evidencias e intentar nuevamente.',
						16,
						1
						)
			End

			IF EXISTS(SELECT pv.IdViajeCompuestoPadre FROM ProViajes AS pv INNER JOIN ProViajesTrayectos AS pvt ON pv.IdViaje = pvt.IdViaje WHERE pvt.IdViajeTrayecto = @IdViajeTrayecto AND pv.IdViajeCompuestoPadre IS NOT NULL AND pvt.EsCompuesto = 1)--es un viajes compuesto hijo depende de otro viaje
				RAISERROR(N'No se puede asignar el viaje porque es un viaje compuesto y depende de otro viaje',
					16,
					1
					)
									
		END
				
		INSERT INTO ProConsumosCombustible(CreadoEl,CreadoPor,FechaHora,IdImpuestoTraslado,IdProveedor,IdUnidad,IdViajeTrayecto,ImporteImpuesto,Litros,
		NumeroComprobante,Odometro,Tarjeta,Total,Subtotal,MillasGalonesDolares)
		VALUES(@CreadoEl,@CreadoPor,@FechaHora,@IdImpuestoTraslado,@IdProveedor,@IdUnidad,@IdViajeTrayecto,@ImporteImpuesto,@Litros,
		@NumeroComprobante,@Odometro,@Tarjeta,@Total,@Subtotal,@MillasGalonesDolares)
				
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

