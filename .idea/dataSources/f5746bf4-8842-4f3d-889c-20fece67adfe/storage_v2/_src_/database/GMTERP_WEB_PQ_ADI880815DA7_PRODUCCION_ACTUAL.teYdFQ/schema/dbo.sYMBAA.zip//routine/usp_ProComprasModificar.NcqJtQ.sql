CREATE PROCEDURE [dbo].[usp_ProComprasModificar]
@IdCompra int,
@SerieDocumento varchar(25),
@Observaciones varchar(512),
@FolioDocumento varchar(40), -- solicitud 10866 Se cambio de bigint a varchar en los pasivos y procesos donde se generen 
@ModificadoPor int,
@ModificadoEl datetime,
@UltimaModificacion datetime,
@IdPeticion varchar(100)
AS
DECLARE
	@FolioPasivo int
BEGIN TRY
	BEGIN TRANSACTION

	  IF ISNULL(@IdCompra,0) = 0
			RAISERROR(N'El identificador de la compra es un campo requerido',
				16,
				1
				)


	  IF (SELECT ModificadoEl FROM ProCompras WHERE IdCompra = @IdCompra) <> @UltimaModificacion
		    RAISERROR(N'Este registro fue modificado por otro usuario',
			   16,
			   1
			   )	


	  IF (Select CanceladoEl from ProCompras where IdCompra = @IdCompra) IS Not NULL
		   RAISERROR(N'La Compra esta cancelada',
			  16,
			  1
			  ) 		  

   		  
		  
   

		UPDATE ProCompras SET
				Observaciones = @Observaciones,
				FolioDocumento = @FolioDocumento,
				SerieDocumento = @SerieDocumento,
				ModificadoPor = @ModificadoPor,
				ModificadoEl = @ModificadoEl
		WHERE IdCompra = @IdCompra
		
		
		UPDATE ProPasivos SET
				FolioDocumento = @FolioDocumento,
				SerieDocumento = @SerieDocumento,
				ModificadoPor = @ModificadoPor,
				ModificadoEl = @ModificadoEl
		WHERE IdCompra = @IdCompra		

	COMMIT

END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

