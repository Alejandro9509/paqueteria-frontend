CREATE PROCEDURE [dbo].[usp_Report_Contabilidad_AuxiliarTabla]
@Ejercicio int,
@Inicial date,
@Final date,
@FiltroCC varchar(200), 
@IdPeticion varchar(100),
@Azure int = 0,
@CuentaInicial varchar(25) = '',
@CuentaFinal varchar(25) = '',
@TipoCuenta int = 0
AS		
DECLARE @cnt int = 0


;WITH CTECuentasContables(IdCuentaContable,CuentaContable,Codigo,Nombre,IdCuentaContablePadre,CuentaContablePadre,NombrePadre,CuentaMayorPadre,IdCuentaContableAbuelo,CuentaContableAbuelo,NombreAbuelo,CuentaMayorAbuelo,IdCuentaContableBisabuelo,CuentaContableBisabuelo,NombreBisabuelo,CuentaMayorBisabuelo,SaldoInicialBisabuelo,SaldoInicialAbuelo,SaldoInicialPadre,SaldoInicialCuentaContable)
 AS (
SELECT cc.IdCuentaContable,
cc.Codigo AS CuentaContable,
cc.Codigo,
cc.Nombre,
ccp.IdCuentaContable AS IdCuentaContablePadre,
ccp.Codigo AS CuentaContablePadre,
ccp.Nombre AS NombrePadre,
ccp.CuentaMayor AS CuentaMayorPadre,

cca.IdCuentaContable AS IdCuentaContableAbuelo,
cca.Codigo AS CuentaContableAbuelo,
cca.Nombre AS NombreAbuelo,
cca.CuentaMayor AS CuentaMayorAbuelo,

ccb.IdCuentaContable AS IdCuentaContableBisabuelo,
ccb.Codigo AS CuentaContableBisabuelo,
ccb.Nombre AS NombreBisabuelo,
ccb.CuentaMayor AS CuentaMayorBisabuelo,
------------------------------------------------------------------------------------ SALDO INICIAL BISABUELO
(
SELECT top 1
(CASE cc.TipoCuenta
WHEN 1 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 3 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 5 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 7 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 9 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 2 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 4 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 6 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 8 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 10 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
END) AS SaldoInicialBisAbuelo
FROM ProPolizasCuentasContables AS ppcc
INNER JOIN ProPolizas AS pp ON ppcc.IdPoliza = pp.IdPoliza
INNER JOIN CatCuentasContables AS cc ON ppcc.IdCuentaContable = cc.IdCuentaContable --afecttable
LEFT JOIN CatCuentasContables AS cc1 ON cc.IdCuentaContablePadre = cc1.IdCuentaContable -- padre
LEFT JOIN CatCuentasContables AS cc2 ON cc1.IdCuentaContablePadre = cc2.IdCuentaContable -- abuelo
LEFT JOIN CatCuentasContables AS cc3 ON cc2.IdCuentaContablePadre = cc3.IdCuentaContable -- bisabuelo
WHERE 
cc3.IdCuentaContable = ccb.IdCuentaContable 
AND 
pp.Fecha < @Inicial
AND cc3.CuentaMayor = 1
AND ((cc.TipoCuenta in(7,8,9,10) AND pp.Ejercicio = @Ejercicio ) OR (cc.TipoCuenta not in(7,8,9,10)))
GROUP BY cc3.IdCuentaContable,cc.TipoCuenta
) AS SaldoInicialBisabuelo ,
------------------------------------------------------------------------------------ SALDOINICIAL ABUELO
(
SELECT top 1
(CASE cc.TipoCuenta
WHEN 1 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 3 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 5 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 7 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 9 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)  --Cargo-Abono
WHEN 2 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 4 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 6 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 8 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 10 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
END) AS SaldoInicial 
FROM ProPolizasCuentasContables AS ppcc
INNER JOIN ProPolizas AS pp ON ppcc.IdPoliza = pp.IdPoliza
INNER JOIN CatCuentasContables AS cc ON ppcc.IdCuentaContable = cc.IdCuentaContable --afecttable
LEFT JOIN CatCuentasContables AS cc1 ON cc.IdCuentaContablePadre = cc1.IdCuentaContable -- padre
LEFT JOIN CatCuentasContables AS cc2 ON cc1.IdCuentaContablePadre = cc2.IdCuentaContable -- abuelo
WHERE cc2.IdCuentaContable = cca.IdCuentaContable
AND pp.Fecha < @Inicial
AND cc2.CuentaMayor = 1
AND ((cc.TipoCuenta in(7,8,9,10) AND pp.Ejercicio = @Ejercicio ) OR (cc.TipoCuenta not in(7,8,9,10)))
GROUP BY cc2.IdCuentaContable,cc.TipoCuenta
) AS SaldoInicialAbuelo ,
-------------------------------------------------------------------------- SALDO INICIAL PADRE
(
SELECT top 1
(CASE cc.TipoCuenta
WHEN 1 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 3 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 5 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 7 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 9 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 2 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 4 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 6 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 8 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 10 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
END) AS SaldoInicial 
FROM ProPolizasCuentasContables AS ppcc
INNER JOIN ProPolizas AS pp ON ppcc.IdPoliza = pp.IdPoliza
INNER JOIN CatCuentasContables AS cc ON ppcc.IdCuentaContable = cc.IdCuentaContable --afecttable
LEFT JOIN CatCuentasContables AS cc1 ON cc.IdCuentaContablePadre = cc1.IdCuentaContable -- padre
WHERE cc1.IdCuentaContable = ccp.IdCuentaContable 
AND pp.Fecha < @Inicial
AND cc1.CuentaMayor = 1
AND ((cc.TipoCuenta in(7,8,9,10) AND pp.Ejercicio = @Ejercicio ) OR (cc.TipoCuenta not in(7,8,9,10)))
GROUP BY cc1.IdCuentaContable,cc.TipoCuenta
) AS SaldoInicialPadre ,

---------------------------------------------------------------------- SALDO INICIAL CUENTA CONTABLE
(
SELECT 
(CASE ccs.TipoCuenta
WHEN 1 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 3 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 5 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 7 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 9 THEN SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END) --Cargo-Abono
WHEN 2 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 4 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 6 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 8 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
WHEN 10 THEN SUM(CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END)-SUM(CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END) --Abono-Cargo
END) AS SaldoInicialCuentaContable
FROM ProPolizasCuentasContables AS ppcc
INNER JOIN ProPolizas AS pp ON ppcc.IdPoliza = pp.IdPoliza
INNER JOIN CatCuentasContables AS ccs ON ppcc.IdCuentaContable = ccs.IdCuentaContable
WHERE ccs.IdCuentaContable = cc.IdCuentaContable
AND pp.Fecha <  @Inicial 
AND ((ccs.TipoCuenta in(7,8) AND pp.Ejercicio = @Ejercicio) OR (ccs.TipoCuenta not in(7,8)))
GROUP BY ccs.Codigo,ccs.TipoCuenta
)AS SaldoInicialCuentaContable

FROM CatCuentasContables AS cc
LEFT JOIN CatCuentasContables AS ccp ON cc.IdCuentaContablePadre = ccp.IdCuentaContable -- padre
LEFT JOIN CatCuentasContables AS cca ON ccp.IdCuentaContablePadre = cca.IdCuentaContable -- abuelo
LEFT JOIN CatCuentasContables AS ccb ON cca.IdCuentaContablePadre = ccb.IdCuentaContable -- bisabuelo
WHERE cc.CuentaMayor = @FiltroCC AND ((@CuentaFinal = '' AND @CuentaInicial = '' AND @TipoCuenta IN(11,13)) OR
(@CuentaFinal <> '' AND @CuentaInicial <> '' AND @TipoCuenta = 12 AND cc.Codigo BETWEEN @CuentaInicial AND @CuentaFinal) OR
(@CuentaFinal = '' AND @CuentaInicial = '' AND @TipoCuenta NOT IN(11,12,13) AND cc.TipoCuenta = @TipoCuenta)
)
--ORDER BY cc.Codigo
) 

, CTEMovimientosCuentasContables AS (
SELECT 
ppcc.IdCuentaContable as IdCuentaContableM,
pp.Fecha,
ctp.Nombre As TipoPoliza,
pp.Numero,
ppcc.Concepto,
ppcc.Referencia,
CASE ppcc.TipoMovimiento WHEN 1 THEN ppcc.Importe ELSE 0 END AS Cargo,
CASE ppcc.TipoMovimiento WHEN 2 THEN ppcc.Importe ELSE 0 END AS Abono,
ccc.TipoCuenta
FROM ProPolizasCuentasContables AS ppcc
full outer join CTECuentasContables ctemcc ON ppcc.IdCuentaContable = ctemcc.IdCuentaContable
LEFT JOIN ProPolizas AS pp ON ppcc.IdPoliza = pp.IdPoliza
LEFT JOIN CatTiposPolizas AS ctp ON pp.IdTipoPoliza = ctp.IdTipoPoliza
INNER JOIN CatCuentasContables AS ccc ON ppcc.IdCuentaContable = ccc.IdCuentaContable

WHERE 
ppcc.IdCuentaContable = ctemcc.IdCuentaContable
--ppcc.IdCuentaContable = %1 
AND 
CAST(pp.Fecha AS date) >= @Inicial AND CAST(pp.Fecha AS date) <= @Final
AND ((ccc.TipoCuenta in(7,8,9,10) AND pp.Ejercicio = @Ejercicio) OR (ccc.TipoCuenta not in(7,8,9,10)))
--ORDER BY pp.Fecha
) 

, CTEReporte AS (
SELECT 
ctecc.* , ctemcc.* 
FROM
CTEMovimientosCuentasContables ctemcc
full outer join CTECuentasContables ctecc ON ctecc.IdCuentaContable = ctemcc.IdCuentaContableM

)

SELECT 
cte.IdCuentaContable,
cte.CuentaContable,
cte.Codigo,
cte.Nombre,
cte.IdCuentaContablePadre,
cte.CuentaContablePadre,
cte.NombrePadre,
cte.CuentaMayorPadre,
cte.IdCuentaContableAbuelo,
cte.CuentaContableAbuelo,
cte.NombreAbuelo,
cte.CuentaMayorAbuelo,
cte.IdCuentaContableBisabuelo,
cte.CuentaContableBisabuelo,
cte.NombreBisabuelo,
cte.CuentaMayorBisabuelo,
cte.SaldoInicialBisabuelo,
cte.SaldoInicialAbuelo,
cte.SaldoInicialPadre,
cte.SaldoInicialCuentaContable,
cte.IdCuentaContableM,
cte.Fecha,
cte.TipoPoliza,
cte.Numero,
cte.Concepto,
cte.Referencia,
cte.Cargo,
cte.Abono,
cte.TipoCuenta
FROM CTEReporte cte 
ORDER BY cte.Codigo,cte.Fecha 
--ORDER BY cte.Codigo,cte.IdCuentaContable,cte.IdCuentaContableM desc
go

