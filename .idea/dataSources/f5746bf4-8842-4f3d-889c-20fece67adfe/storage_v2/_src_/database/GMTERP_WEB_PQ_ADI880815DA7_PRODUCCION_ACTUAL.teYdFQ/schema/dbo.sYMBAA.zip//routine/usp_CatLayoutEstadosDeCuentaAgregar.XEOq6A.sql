CREATE PROCEDURE [dbo].[usp_CatLayoutEstadosDeCuentaAgregar]
	@Codigo int,
	@Descripcion varchar(150),
	@TipoFormato tinyint,
	@RenglonInicial tinyint,
	@Separador Varchar(5),
	@ColumnaCheque tinyint,
	@ColumnaFecha tinyint,
	@FormatoFecha varchar(20),
	@ColumnaReferencia tinyint,
	@ColumnaDeposito tinyint,
	@ColumnaRetiro tinyint,
	@CreadoEl	datetime,
	@CreadoPor	int,
	@IdPeticion varchar(100)
	
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@Codigo,0) = 0
			RAISERROR(N'El código del layout es un campo requerido',
				16,
				1
				)
		IF exists(Select * from CatLayoutEstadosDeCuenta Where Codigo = @Codigo)
			RAISERROR(N'El código del layout ya existe',
				16,
				1
				)

		IF LTRIM(RTRIM(@Descripcion)) = ''
			RAISERROR(N'El nombre del layout es un campo requerido',
				16,
				1
				)
	
		INSERT INTO CatLayoutEstadosDeCuenta(Codigo,Descripcion,TipoFormato,RenglonInicial,Separador,ColumnaCheque,ColumnaFecha,FormatoFecha,ColumnaReferencia,
	ColumnaDeposito,ColumnaRetiro,CreadoEl,CreadoPor)
		VALUES(@Codigo,@Descripcion,@TipoFormato,@RenglonInicial,@Separador,@ColumnaCheque,@ColumnaFecha,@FormatoFecha,@ColumnaReferencia,
	@ColumnaDeposito,@ColumnaRetiro,@CreadoEl,@CreadoPor)
	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

