create PROCEDURE [dbo].[usp_CatPaquetesGetMaxCodigo]  
AS  
SELECT ISNULL(MAX(Codigo),0)+1 AS Codigo FROM CatPaquetes
go

