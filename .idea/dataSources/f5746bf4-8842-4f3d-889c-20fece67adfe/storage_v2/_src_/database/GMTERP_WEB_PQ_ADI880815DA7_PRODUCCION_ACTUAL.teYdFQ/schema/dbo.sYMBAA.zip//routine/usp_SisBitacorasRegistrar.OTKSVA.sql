CREATE PROCEDURE [dbo].[usp_SisBitacorasRegistrar]
	@IdUsuario int,
	@IdSesion varchar(100),
	@IdProceso int,
	@FechaHora datetime,
	@Referencia varchar(250),
	@Adicional ntext
AS

INSERT INTO SisBitacoras (IdUsuario,IdSesion,IdProceso,FechaHora,Referencia, Adicional)
VALUES(@IdUsuario,@IdSesion,@IdProceso,@FechaHora,@Referencia, @Adicional)
go

