CREATE PROCEDURE [dbo].[usp_ProCobranzaSaldarPagosAbonos]
	@IdMovimientoBancario int,
	@ModificadoPor int,
	@ModificadoEl datetime,
	@IdPeticion varchar(100),
	@SaldadoEl datetime
AS
BEGIN TRY
	BEGIN TRANSACTION
		IF ISNULL(@IdMovimientoBancario,0) <= 0
		RAISERROR(N'El movimiento bancario es un campo requerido',
			16,
			1
			)
		IF EXISTS(SELECT pf.IdFactura FROM ProFacturas as pf INNER JOIN ProCobranza AS pc ON pf.IdFactura = pc.IdFactura
				  WHERE pc.IdMovimientoBancario = @IdMovimientoBancario AND pf.FechaPagoFactoraje IS NOT NULL)
		RAISERROR(N'El Pago/Abono fue saldado por otro usuario',
			16,
			1
			)
		UPDATE ProFacturas SET
		ProFacturas.FechaPagoFactoraje = @SaldadoEl
		WHERE IdFactura IN (SELECT pf.IdFactura FROM ProFacturas as pf INNER JOIN ProCobranza AS pc ON pf.IdFactura = pc.IdFactura WHERE pc.IdMovimientoBancario = @IdMovimientoBancario)
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

