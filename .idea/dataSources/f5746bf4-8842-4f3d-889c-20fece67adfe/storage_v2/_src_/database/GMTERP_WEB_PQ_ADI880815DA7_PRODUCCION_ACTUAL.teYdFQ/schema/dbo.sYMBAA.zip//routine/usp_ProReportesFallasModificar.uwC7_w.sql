CREATE PROCEDURE [dbo].[usp_ProReportesFallasModificar]
@IdReporteFalla int,
@Folio int, 
@Fecha datetime,
@IdUnidad int,
@IdOperador int,
@DescripcionFalla Text,
@IdSucursal int,
@ModificadoEl datetime,
@ModificadoPor int,
@IdPeticion varchar(100),
@IdClasificacionServicio int,
@dsProReportesFallasImagenes ntext,
@Codigo nvarchar(50) 

/*************************************************************************************************************************************
@IdReporteFalla int
@Folio int
@Fecha datetime
@IdUnidad int
@IdOperador int
@DescripcionFalla Text
@IdSucursal int
@ModificadoEl datetime
@ModificadoPor int
@IdPeticion varchar(100)
@IdClasificacionServicio int
@dsProReportesFallasImagenes ntext
@Codigo nvarchar(50) 

Modificado por: Enrique 
Fecha de Modificacion:  19/02/2020
Versión: 8.0.50.06

Se creo para guardar los datos de los archivos en base de datos 
***************************************/
AS
DECLARE 
@docHandle int
BEGIN TRY
	BEGIN TRANSACTION
	
	IF ISNULL(@IdReporteFalla ,0)= 0
		RAISERROR(N'El identificador de reporte de falla es un campo requerido',
			16,
			1
			)
	
	--SOLICITUD 2978
    --IF EXISTS(SELECT IdOrdenServicio FROM ProReportesFallas WHERE ProReportesFallas.IdReporteFalla = @IdReporteFalla AND IdOrdenServicio IS NOT NULL)
	--	RAISERROR(N'Reporte de falla esta atendido, no puede ser modificado',
	--		16,
	--		1
	--		)

	IF ISNULL(@Folio,0)= 0
		RAISERROR(N'El folio de reporte de falla es un campo requerido',
			16,
			1
			)
			
	IF ISNULL(@IdUnidad,0)= 0
		RAISERROR(N'Identificador de unidad es un campo requerido',
			16,
			1
			)
	IF EXISTS(SELECT Folio FROM ProReportesFallas WHERE ProReportesFallas.Folio = @Folio AND ProReportesFallas.IdReporteFalla <> @IdReporteFalla)
		RAISERROR(N'El numero de folio ya existe',
			16,
			1
			)

	IF ISNULL(@IdOperador,0)= 0
		SET @IdOperador = NULL

	IF ISNULL(@IdClasificacionServicio,0)= 0
		SET @IdClasificacionServicio = NULL
	
	UPDATE ProReportesFallas SET
				Folio=@Folio,
				Fecha=@Fecha,
				IdUnidad=@IdUnidad,
				IdOperador=@IdOperador,
				DescripcionFalla=@DescripcionFalla,
				IdSucursal=@IdSucursal,
				ModificadoEl=@ModificadoEl,
				ModificadoPor=@ModificadoPor,
				IdClasificacionServicio = @IdClasificacionServicio,
				Codigo = @Codigo
	WHERE 	IdReporteFalla=@IdReporteFalla
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

