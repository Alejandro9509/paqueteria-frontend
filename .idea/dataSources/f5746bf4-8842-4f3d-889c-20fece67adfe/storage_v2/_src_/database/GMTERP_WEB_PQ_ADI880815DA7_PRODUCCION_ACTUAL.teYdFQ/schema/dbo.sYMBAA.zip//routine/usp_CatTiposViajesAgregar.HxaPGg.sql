CREATE PROCEDURE [dbo].[usp_CatTiposViajesAgregar]
	@Codigo int,
	@TipoViaje varchar(50),
	@Activo bit,
	@CreadoPor int,
	@CreadoEl datetime,
	@IdPeticion varchar(100)

/* *************************************************************************************************
Procedimiento usp_CatTiposViajesAgregar

Parámetros: 
	@Codigo  		(entrada, entero). Codigo del tipo de viaje
	@TipoViaje 		(entrada, texto). Descripcion del tipo de viaje
	@Activo	        (entrada, boleano). Bandera para saber si el tipo de viaje esta activa/no activa
	@CreadoPor	    (entrada, entero). Usuario que crea el tipo de viaje
	@CreadoEl	    (entrada, fecha hora). Fecha y hora de creacion
	@IdPeticion   	(entrada, string). Id de la Petición, generada en WEBDEV 	
 
Descripción: Procedimiento para agregar un nuevo tipo de viaje

23/10/2019   Se agrego el parametro de Activo a la tabla

Implementada por: XXXXX
Fecha de implementacion: XXXXX
Versión ERP: XXXX

Modificada por:   Jesús Humberto Morales
Fecha de mofidicacion: 23/10/2019
Versión ERP: 8.0.47.09

Invocada desde: PAGE_CatTiposViajesAM (Solicitud 368)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION

	IF ISNULL(@Codigo,0) <= 0
		RAISERROR(N'El código es un campo requerido',
			16,
			1
			)	

	IF EXISTS(SELECT Codigo FROM CatTiposViajes WHERE Codigo = @Codigo)
		RAISERROR(N'El código ya existe',
			16,
			1
			)

	IF LTRIM(RTRIM(@TipoViaje)) = ''
		RAISERROR(N'El campo tipo de viaje es requerido',
			16,
			1
			)

	INSERT INTO CatTiposViajes(Codigo,CreadoEl,CreadoPor,TipoViaje,Activo)
	VALUES(@Codigo,@CreadoEl,@CreadoPor,@TipoViaje,@Activo)
		
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

