CREATE PROCEDURE [dbo].[usp_CatRecorridosAgregar]
	@IdCliente int,
	@IdOrigen int,
	@IdDestino int,
	@FolioRecorrido int,
	@Descripcion varchar(140),
	@CreadoPor int,
	@CreadoEl datetime,
	@Activa bit,
	@RutaGoogleMap ntext,
	@HorasTrayecto decimal(15, 2),
	@KmTrayecto int,
	@IdPeticion varchar(100),
	@dsCatRutasPersonalClientesContatos ntext,
	@dsCatRutasPersonalParadas ntext,
	@GeocercasSalida int,
	@DarSalidaES int,
	@EstatusViajeSalidaAutomatica int,
	@GeocercasLlegada int,
	@DarLlegadaES int,
	@EstatusViajeLlegadaAutomatica int 
	
AS
DECLARE
	@IdRecorrido int,
	@docHandle int,
	@CursorIdConceptoFacturacion int,
	@CursorImporte money,
	@CursorImporteDlls money,
	@CursorIdPuesto int,
	@CursorPuntos int,
	@CursorIdClienteContacto int,
	@CursorIdGeocerca int,
	@CursorIdEstatuViajeEntrada int,
	@CursorIdEstatuViajeSalida int 
BEGIN TRY
	BEGIN TRANSACTION
		
		
		IF @IdCliente = 0
		RAISERROR(N'El cliente es un campo requerido',
			16,
			1
			)
		IF @IdOrigen = 0
		RAISERROR(N'El origen es un campo requerido',
			16,
			1
			)			
		IF @IdDestino = 0
		RAISERROR(N'El destino es un campo requerido',
			16,
			1
			)			
		IF RTRIM(LTRIM(@Descripcion)) = ''
		RAISERROR(N'La descripción de la ruta es un campo requerido',
			16,
			1
			)	
		IF EXISTS(SELECT FolioRecorrido FROM CatRecorridos WHERE FolioRecorrido = @FolioRecorrido) 
		RAISERROR(N'El folio ya fue utilizado por otro usuario, se le asignará el siguiente folio disponible, revise la información y vuelva hacer click en aceptar.',
			16,
			1
			)	
								
		INSERT INTO CatRecorridos(IdCliente,IdOrigen,IdDestino,FolioRecorrido,Descripcion,CreadoPor,CreadoEl,Activa,RutaGoogleMap,HorasRecorrido,KmRecorrido,GeocercasSalida,DarSalidaES,EstatusViajeSalidaAutomatica,GeocercasLlegada,DarLlegadaES,EstatusViajeLlegadaAutomatica)
		VALUES(@IdCliente,@IdOrigen,@IdDestino,@FolioRecorrido,@Descripcion,@CreadoPor,@CreadoEl,@Activa,@RutaGoogleMap,@HorasTrayecto,@KmTrayecto,@GeocercasSalida,@DarSalidaES,@EstatusViajeSalidaAutomatica,@GeocercasLlegada,@DarLlegadaES,@EstatusViajeLlegadaAutomatica)	

		SET @IdRecorrido = (SELECT IDENT_CURRENT('CatRecorridos')) 

		
	
		--AGREGAR LAS NOTIFICACIONES 
		IF @dsCatRutasPersonalClientesContatos IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalClientesContatos
			
			SELECT ATT_IdClienteContacto
			INTO #TempCatRutasPersonalClientesContatos
				FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalClientesContatos',2) 
			WITH (ATT_IdClienteContacto int)
			
			EXEC sp_xml_removedocument @docHandle
			
			DECLARE CursorCatRutasPersonalClientesContatos CURSOR FOR
			SELECT * FROM #TempCatRutasPersonalClientesContatos
			
			OPEN CursorCatRutasPersonalClientesContatos
			FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
			INTO @CursorIdClienteContacto
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
									
				INSERT INTO CatRecorridosClientesContatos(IdRecorrido,IdClienteContacto,CreadoPor,CreadoEl)
				VALUES(@IdRecorrido,@CursorIdClienteContacto,@CreadoPor,@CreadoEl) 
			
				FETCH NEXT FROM CursorCatRutasPersonalClientesContatos
				INTO @CursorIdClienteContacto
			END
			CLOSE CursorCatRutasPersonalClientesContatos
			DEALLOCATE CursorCatRutasPersonalClientesContatos					
		END

		--AGREGAR LAS PARADAS 
		IF @dsCatRutasPersonalParadas IS NOT NULL
		BEGIN
			EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsCatRutasPersonalParadas
		
			SELECT ATT_IdGeocerca, ATT_IdEstatuViajeEntrada, ATT_IdEstatuViajeSalida 
			INTO #TempCatRutasPersonalParadas
			FROM OPENXML(@docHandle, N'/WINDEV_TABLE/CatRutasPersonalParadas',2) 
			WITH (ATT_IdGeocerca int, ATT_IdEstatuViajeEntrada int, ATT_IdEstatuViajeSalida int)
		
			EXEC sp_xml_removedocument @docHandle
		
			DECLARE CursorCatRutasPersonalParadas CURSOR FOR
			SELECT * FROM #TempCatRutasPersonalParadas
		
			OPEN CursorCatRutasPersonalParadas
			FETCH NEXT FROM CursorCatRutasPersonalParadas
			INTO @CursorIdGeocerca, @CursorIdEstatuViajeEntrada, @CursorIdEstatuViajeSalida 
			WHILE @@FETCH_STATUS = 0
			BEGIN
				INSERT INTO CatRecorridosSalidasLlegadasGeocercas(IdRecorrido,IdGeocerca,IdEstatuViajeEntrada,IdEstatuViajeSalida,CreadoPor,CreadoEl)
				VALUES(@IdRecorrido,@CursorIdGeocerca,
				--SE METIO ESTA VALIDACION PARA QUE CUANDO UN ESTATUS SEA SIN ASIGNAR LO GUARDE COMO NULLO  SOL 9793
				CASE @CursorIdEstatuViajeEntrada WHEN 0 THEN NULL ELSE @CursorIdEstatuViajeEntrada END,
				CASE @CursorIdEstatuViajeSalida WHEN 0 THEN NULL ELSE @CursorIdEstatuViajeSalida END,
				--SE METIO ESTA VALIDACION PARA QUE CUANDO UN ESTATUS SEA SIN ASIGNAR LO GUARDE COMO NULLO  SOL 9793
				@CreadoPor,@CreadoEl)
		
				FETCH NEXT FROM CursorCatRutasPersonalParadas
			INTO @CursorIdGeocerca, @CursorIdEstatuViajeEntrada, @CursorIdEstatuViajeSalida
			END
			CLOSE CursorCatRutasPersonalParadas
			DEALLOCATE CursorCatRutasPersonalParadas
	END
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

