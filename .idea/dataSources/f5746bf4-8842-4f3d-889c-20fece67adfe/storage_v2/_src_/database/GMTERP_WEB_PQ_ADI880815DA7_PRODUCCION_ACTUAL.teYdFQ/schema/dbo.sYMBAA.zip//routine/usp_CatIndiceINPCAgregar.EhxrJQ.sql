
CREATE PROCEDURE [dbo].[usp_CatIndiceINPCAgregar]
	@Ejercicio INT,
	@Enero DECIMAL(10,6),
	@Febrero DECIMAL(10,6),
	@Marzo DECIMAL(10,6),
	@Abril DECIMAL(10,6),
	@Mayo DECIMAL(10,6),
	@Junio DECIMAL(10,6),
	@Julio DECIMAL(10,6),
	@Agosto DECIMAL(10,6),
	@Septiembre DECIMAL(10,6),
	@Octubre DECIMAL(10,6),
	@Noviembre DECIMAL(10,6),
	@Diciembre DECIMAL(10,6),
	@CreadoEl DATETIME,
	@CreadoPor INT,
	@IdPeticion VARCHAR(100)

/* *************************************************************************************************
Procedimiento usp_CatIndiceINPCAgregar

Parámetros: 
	@Ejercicio			(entrada, entero). Numero del ejercicio
	@Enero				(entrada, decimal). Valor del ejercicio del mes de Enero
	@Febrero			(entrada, decimal). Valor del ejercicio del mes de Febrero
	@Marzo				(entrada, decimal). Valor del ejercicio del mes de Marzo
	@Abril				(entrada, decimal). Valor del ejercicio del mes de Abril
	@Mayo				(entrada, decimal). Valor del ejercicio del mes de Mayo
	@Junio				(entrada, decimal). Valor del ejercicio del mes de Junio
	@Julio				(entrada, decimal). Valor del ejercicio del mes de Julio
	@Agosto				(entrada, decimal). Valor del ejercicio del mes de Agosto
	@Septiembre			(entrada, decimal). Valor del ejercicio del mes de Septiembre
	@Octubre			(entrada, decimal). Valor del ejercicio del mes de Octubre
	@Noviembre			(entrada, decimal). Valor del ejercicio del mes de Noviembre
	@Diciembre			(entrada, decimal). Valor del ejercicio del mes de Diciembre
	@CreadoEl			(entrada, fecha hora). Fecha y hora de creacion
	@CreadoPor			(entrada, entero). Usuario que crea el indice INPC
	@IdPeticion			(entrada, string). Id de la Petición, generada en WEBDEV 		
 
Descripción: Procedimiento para agregar un nuevo ejercicio al catalogo de Indice INPC

Implementada por: Jesús Humberto Morales
Fecha de implementacion: 10/12/2019
Versión ERP: 8.0.48.22

Modificada por:   XXXXX
Fecha de mofidicacion: XXXXX
Versión ERP: XXXXX

Invocada desde: PAGE_CatIndiceINPCAM (Solicitud 648)
***************************************************************************************************** */
AS
BEGIN TRY
	BEGIN TRANSACTION

		IF ISNULL(@Ejercicio, 0) <= 0
			RAISERROR(N'El ejercicio es un campo requerido', 16, 1)

		IF EXISTS(SELECT Ejercicio FROM CatIndiceINPC WHERE Ejercicio = @Ejercicio)
			RAISERROR(N'El ejercicio ya existe', 16, 1)

		INSERT INTO CatIndiceINPC (Ejercicio, Enero, Febrero, Marzo, Abril, Mayo, Junio, Julio, Agosto, Septiembre, Octubre,
		Noviembre, Diciembre, CreadoEl, CreadoPor)
		VALUES (@Ejercicio, @Enero, @Febrero, @Marzo, @Abril, @Mayo, @Junio, @Julio, @Agosto, @Septiembre, @Octubre,
		@Noviembre, @Diciembre, @CreadoEl, @CreadoPor)

	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

