CREATE PROCEDURE [dbo].[usp_ProServiciosProgramadosModificar]  
@IdServicioProgramado int,
@Fecha datetime,
@IdUnidad int,
@IdServicio int,
@FechaProgramada datetime,
@KilometrajeActual int,
@KilometrajeProximo int,
@Observacion varchar(500),
@ModificadoEl datetime,
@ModificadoPor int,
@UltimaModificacion datetime,
@IdPeticion varchar(100),
@FechaHoraAsignacion datetime,
@HorasActuales int,
@HorasProximoServicio int
  
AS

/* *************************************************************************************************
	SOLICITUD 1178

	Descripcion: Se agrego una validacion para actualizar el campo @HorasTrabajadasMotorNoGPS en CatUnidades
	en caso de que el servicio programado sea para una unidad sin GPS.

	Modificada por:   Amado Navarro
	Fecha de mofidicacion: 27/02/2020
	Versión: Versión 8.0.50.18

	Invocada desde: <PAGE_ProServiciosProgramadosR>
	************************************************************************************************ */
BEGIN TRY  
 BEGIN TRANSACTION  

 IF ISNULL(@IdServicioProgramado,0) = 0
  RAISERROR(N'Identificador de reposición es un campo requerido',
   16,
   1
   ) 

 IF isdate(@Fecha) = 0
  RAISERROR(N'Fecha es un campo requerido',  
   16,  
   1  
   )
   
 IF isdate(@FechaProgramada) = 0  
  RAISERROR(N'Fecha programada es un campo requerido',  
   16,  
   1  
   )      
     
 IF ISNULL(@IdServicio,0)= 0  
  RAISERROR(N'Identificador de servicio es un campo requerido',  
   16,  
   1  
   )  

     
 IF ISNULL(@IdUnidad,0)= 0  
  RAISERROR(N'Identificador de unidad es un campo requerido',  
   16,  
   1  
   )  
   
  IF  @FechaProgramada < @Fecha
  RAISERROR(N'Fecha programada es menor a la fecha de emisión',  
   16,  
   1  
   )  
  
  IF (SELECT ModificadoEl FROM ProServiciosProgramados WHERE IdServicioProgramado = @IdServicioProgramado) <> @UltimaModificacion
    RAISERROR(N'Este registro fue modificado por otro usuario',
	   16,
	   1
	   )
  
  IF NOT EXISTS(SELECT IdServicioProgramado FROM ProServiciosProgramados WHERE IdServicioProgramado = @IdServicioProgramado)
  	 RAISERROR(N'Este registro fue eliminado por otro usuario',
	   16,
	   1
	   )
	   
   
  IF (Select IdOrdenServicio from ProServiciosProgramados where IdServicioProgramado = @IdServicioProgramado) IS Not NULL
     RAISERROR(N'Este servicio programado ya esta atendido',
	  16,
	  1
	  )
 
 	UPDATE ProServiciosProgramados SET
	       Fecha = @Fecha,
	       IdUnidad = @IdUnidad,
	       IdServicio = @IdServicio,
	       FechaProgramada = @FechaProgramada,
	       KilometrajeActual = @KilometrajeActual,
	       KilometrajeProximo = @KilometrajeProximo,
	       Observacion = @Observacion,
	       ModificadoEl = @ModificadoEl,
	       ModificadoPor = @ModificadoPor,
	       FechaHoraAsignacion = @FechaHoraAsignacion,
		   HorasActuales = @HorasActuales,
		   HorasProximoServicio = @HorasProximoServicio
	WHERE IdServicioProgramado=@IdServicioProgramado

	IF (SELECT IdentificadorSatelital FROM CatUnidades WHERE IdUnidad =@IdUnidad) = ''
	BEGIN
		UPDATE CatUnidades
		SET HorasTrabajadasMotorNoGPS = @HorasActuales WHERE IdUnidad = @IdUnidad
	END
     
   
 
 COMMIT  
END TRY  
BEGIN CATCH  
 ROLLBACK  
 EXECUTE usp_SisErrorsGrabar @IdPeticion  
END CATCH
go

