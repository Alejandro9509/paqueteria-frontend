
CREATE PROCEDURE [dbo].[usp_ProTableroUnidadesTemporalActualizarMantenimiento]
	@IdUsuario int,
	@IdUnidad int,
	@FechaSalida date,
	@Mantenimiento bit,
	@IdPeticion varchar(100),
	@FechaFormat varchar(350),
	@FechaModificado varchar(300)
	

AS
DECLARE 
@Usuario varchar(200)  
	
BEGIN TRY
SET @Usuario = (SELECT Usuario FROM CatUsuarios WHERE IdUsuario = @IdUsuario) 
	BEGIN TRANSACTION
	IF @Mantenimiento = 0 
	BEGIN			
		SET @FechaSalida = NULL
		SET @FechaFormat = NULL 
			
	END
		

		UPDATE ProTableroUnidadesTemporal set
		EstaMantenimiento = @Mantenimiento,
		FechaSalida = @FechaSalida,
		FechaSalidaCadena = @FechaFormat,
		ModificadoPor =  @Usuario,
		FechaModificado = @FechaModificado 
		where 
		IdUnidad = @IdUnidad



	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

