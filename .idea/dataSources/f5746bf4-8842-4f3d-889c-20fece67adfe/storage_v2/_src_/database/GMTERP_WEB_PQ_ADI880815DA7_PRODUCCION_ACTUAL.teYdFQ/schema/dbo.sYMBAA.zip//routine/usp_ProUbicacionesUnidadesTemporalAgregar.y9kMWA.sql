--cambios solicitudes 9725,9917,9901
CREATE PROCEDURE [dbo].[usp_ProUbicacionesUnidadesTemporalAgregar]
	@IdUsuario int,
	@dsProUbicacionesUnidadesTemp ntext,
	@IdPeticion varchar(100),
	@sIdentificadoresUnidades varchar(MAX) = ''
AS
DECLARE
	@docHandle int,
	@Consulta nvarchar(3000),
	@ConsultaValores nvarchar(3000)
BEGIN TRY
	BEGIN TRANSACTION
	--Esta seccion indica que es el primero el primer registro de todas las unidades como valor @sIdentificadoresUnidades = ''
	--caso contrario, indicara que es ya existe unidades registradas y solo se requiere eliminar las unidades que se movieron
	IF @sIdentificadoresUnidades = '' 
	BEGIN
		Delete from ProUbicacionesUnidadesTemporal where IdUsuario = @IdUsuario	
	END
	ELSE
	BEGIN
		set @Consulta = N'DELETE FROM ProUbicacionesUnidadesTemporal WHERE NoSerie IN ('+@sIdentificadoresUnidades+') and IdUsuario = '+cast(@IdUsuario as varchar)
		EXEC dbo.sp_executesql @Consulta
	END

	IF @dsProUbicacionesUnidadesTemp IS NOT NULL
	BEGIN
		EXEC sp_xml_preparedocument @docHandle OUTPUT, @dsProUbicacionesUnidadesTemp
		
		SELECT Unidad,Pais,
		Estado,Ciudad,
		Calle,Evento,
		Icono,
		ExisteAlertaReporteo,DireccionImagenAdvertencia,
		DentroGeocerca,RFC,
		FechaHoraPaquete,
		TiempoEstimadoUltimoReporte,
		Velocidad,PorcentajeBateria,
		VoltajeVehiculo,CadenaLitros,
		Direccion,Latitud,
		Longitud,Codigo,
		Posicion,NoSerie,
		OdometroGPS,
		EstadoMotor,Temperatura,
		FechaHoraUltimaPeticion,FechaHoraUnidad,
		HASHGPS,CantidadSatelite,
		LinkGoogleMaps,FechaHoraServidor,
		EstadoModoTrabajo,EstadoModuloGPS,
		NivelGSM,TipoSenal,
		VoltajeBateriaInterna,
		SumaLitrosTanques,
		TieneSensores,
		NivelCombustiblePorcentaje,
		EventoPSalidaGeo,
		EventoPEntradaGeo,
		EventoPDemorado,
		EventoPFueraRuta,
		EventoPTempAlta,
		EventoPTempBaja
		INTO #TempProUbicacionesUnidadesTemp
		FROM OPENXML(@docHandle, N'/Markers/Marker',2) 
		WITH (Unidad varchar(150),Pais varchar(150),
		Estado varchar(150),Ciudad varchar(150),
		Calle varchar(200),Evento varchar(50),
		Icono varchar(50),
		ExisteAlertaReporteo bit,DireccionImagenAdvertencia varchar(200),
		DentroGeocerca bit,RFC varchar(15),
		FechaHoraPaquete varchar(110),
		TiempoEstimadoUltimoReporte varchar(150),
		Velocidad varchar(50),PorcentajeBateria varchar(50),
		VoltajeVehiculo varchar(50),CadenaLitros varchar(150),
		Direccion varchar(5),Latitud float,
		Longitud float,Codigo int,
		Posicion varchar(100),NoSerie varchar(50),
		OdometroGPS float,
		EstadoMotor int,Temperatura varchar(50),
		FechaHoraUltimaPeticion datetime,FechaHoraUnidad datetime,
		HASHGPS varchar(50),CantidadSatelite tinyint,
		LinkGoogleMaps varchar(400),FechaHoraServidor datetime,
		EstadoModoTrabajo varchar(100),EstadoModuloGPS varchar(100),
		NivelGSM varchar(100),TipoSenal varchar(100),
		VoltajeBateriaInterna varchar(50),
		SumaLitrosTanques decimal(15, 4),
		TieneSensores int,
		NivelCombustiblePorcentaje float,
		EventoPSalidaGeo bit,
		EventoPEntradaGeo bit,
		EventoPDemorado bit,
		EventoPFueraRuta bit,
		EventoPTempAlta bit,
		EventoPTempBaja bit
		)
		
		EXEC sp_xml_removedocument @docHandle
		
		INSERT INTO ProUbicacionesUnidadesTemporal (Unidad,Pais,
		Estado,Ciudad,
		Calle,Evento,
		Icono,
		ExisteAlertaReporteo,DireccionImagenAdvertencia,
		DentroGeocerca,RFC,
		FechaHoraPaquete,
		TiempoEstimado,
		Velocidad,PorcentajeBateria,
		VoltajeVehiculo,CadenaLitros,
		Direccion,Latitud,
		Longitud,CodigoEvento,
		Posicion,NoSerie,
		Odometro,
		EstadoMotor,Temperatura,
		FechaHoraUltimaPeticion,FechaHoraUnidad,
		HASHGPS,CantidadSatelites,
		LinkGoogleMaps,
		FechaHoraServidor,
		IdUsuario,
		EstadoModoTrabajo,
		EstadoModuloGPS,
		NivelGSM,
		TipoSenal,
		VoltajeBateriaInterna,
		SumaLitrosTanques,
		TieneSensores,
		NivelCombustiblePorcentaje,
		DireccionImagenInfo,
		DireccionImagenSeguimiento,
		UnidadSeleccionada,
		EventoPSalidaGeo,
		EventoPEntradaGeo,
		EventoPDemorado,
		EventoPFueraRuta,
		EventoPTempAlta,
		EventoPTempBaja
		)
		SELECT Unidad,Pais,
		Estado,Ciudad,
		Calle,Evento,
		Icono,
		ExisteAlertaReporteo,DireccionImagenAdvertencia,
		DentroGeocerca,RFC,
		FechaHoraPaquete,
		TiempoEstimadoUltimoReporte,
		Velocidad,PorcentajeBateria,
		VoltajeVehiculo,CadenaLitros,
		Direccion,Latitud,
		Longitud,Codigo,
		Posicion,NoSerie,
		OdometroGPS,
		EstadoMotor,Temperatura,
		FechaHoraUltimaPeticion,FechaHoraUnidad,
		HASHGPS,CantidadSatelite,
		LinkGoogleMaps,FechaHoraServidor,
		@IdUsuario,
		EstadoModoTrabajo,
		EstadoModuloGPS,
		NivelGSM,
		TipoSenal,
		VoltajeBateriaInterna,
		SumaLitrosTanques,
		TieneSensores,
		NivelCombustiblePorcentaje,
		'/GMTERPV8_WEB/Imagenes/Info.png',
		'/GMTERPV8_WEB/Imagenes/OJOINACTIVO.png',
		1,
		ISNULL(EventoPSalidaGeo,0),
		ISNULL(EventoPEntradaGeo,0),
		ISNULL(EventoPDemorado,0),
		ISNULL(EventoPFueraRuta,0),
		ISNULL(EventoPTempAlta,0),
		ISNULL(EventoPTempBaja,0)
		FROM #TempProUbicacionesUnidadesTemp
		
	END	
	COMMIT
END TRY
BEGIN CATCH
	ROLLBACK
	EXECUTE usp_SisErrorsGrabar @IdPeticion
END CATCH
go

